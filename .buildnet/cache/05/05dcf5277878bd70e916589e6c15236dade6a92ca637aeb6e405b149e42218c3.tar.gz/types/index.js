"use strict";
/**
 * @musclemap/core - Domain Types
 *
 * Single source of truth for all domain types across the monorepo.
 * These types are used by backend, frontend, and plugins.
 */
Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=index.js.map