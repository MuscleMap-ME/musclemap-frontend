/**
 * Credit Calculation Utilities
 *
 * Shared logic for calculating credit costs, bonuses, and transactions.
 */
export interface CreditTransaction {
    amount: number;
    type: 'credit' | 'debit';
    description: string;
    balanceAfter: number;
}
/**
 * Calculate credits for a given dollar amount.
 */
export declare function dollarsToCredits(dollars: number): number;
/**
 * Calculate dollar amount for given credits.
 */
export declare function creditsToDollars(credits: number): number;
/**
 * Get the best pricing tier for a given amount in cents.
 */
export declare function getBestTier(amountCents: number): {
    tierId: string;
    credits: number;
    bonusPercentage: number;
} | null;
/**
 * Validate a purchase amount.
 */
export declare function validatePurchaseAmount(amountCents: number): {
    valid: boolean;
    error?: string;
};
/**
 * Check if user has enough credits for an action.
 */
export declare function hasEnoughCredits(balance: number, cost: number): boolean;
/**
 * Calculate workout credit cost based on complexity.
 */
export declare function calculateWorkoutCost(exerciseCount: number, options?: {
    baseCost?: number;
    perExerciseCost?: number;
    maxCost?: number;
}): number;
/**
 * Format credits for display.
 */
export declare function formatCredits(credits: number): string;
/**
 * Format dollar amount for display.
 */
export declare function formatDollars(cents: number): string;
/**
 * Calculate the value proposition text for a tier.
 */
export declare function getTierValueText(tierId: string): string | null;
//# sourceMappingURL=credit-calculation.d.ts.map