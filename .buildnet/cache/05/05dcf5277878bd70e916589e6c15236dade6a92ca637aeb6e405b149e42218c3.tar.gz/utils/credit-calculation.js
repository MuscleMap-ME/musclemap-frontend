"use strict";
/**
 * Credit Calculation Utilities
 *
 * Shared logic for calculating credit costs, bonuses, and transactions.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.dollarsToCredits = dollarsToCredits;
exports.creditsToDollars = creditsToDollars;
exports.getBestTier = getBestTier;
exports.validatePurchaseAmount = validatePurchaseAmount;
exports.hasEnoughCredits = hasEnoughCredits;
exports.calculateWorkoutCost = calculateWorkoutCost;
exports.formatCredits = formatCredits;
exports.formatDollars = formatDollars;
exports.getTierValueText = getTierValueText;
const constants_1 = require("../constants");
/**
 * Calculate credits for a given dollar amount.
 */
function dollarsToCredits(dollars) {
    return Math.floor(dollars * constants_1.CREDITS_PER_DOLLAR);
}
/**
 * Calculate dollar amount for given credits.
 */
function creditsToDollars(credits) {
    return credits / constants_1.CREDITS_PER_DOLLAR;
}
/**
 * Get the best pricing tier for a given amount in cents.
 */
function getBestTier(amountCents) {
    // Find the matching tier
    const tier = constants_1.PRICING_TIERS.find((t) => t.priceCents === amountCents);
    if (!tier) {
        return null;
    }
    const baseCredits = amountCents; // 1 cent = 1 credit base
    const bonusCredits = tier.credits - baseCredits;
    const bonusPercentage = (bonusCredits / baseCredits) * 100;
    return {
        tierId: tier.id,
        credits: tier.credits,
        bonusPercentage: Math.round(bonusPercentage * 10) / 10,
    };
}
/**
 * Validate a purchase amount.
 */
function validatePurchaseAmount(amountCents) {
    if (!Number.isInteger(amountCents) || amountCents < 0) {
        return { valid: false, error: 'Invalid amount' };
    }
    if (amountCents < constants_1.MINIMUM_PURCHASE_CENTS) {
        return {
            valid: false,
            error: `Minimum purchase is $${constants_1.MINIMUM_PURCHASE_CENTS / 100}`,
        };
    }
    // Check if it matches a valid tier
    const tier = constants_1.PRICING_TIERS.find((t) => t.priceCents === amountCents);
    if (!tier) {
        return {
            valid: false,
            error: 'Amount does not match a valid pricing tier',
        };
    }
    return { valid: true };
}
/**
 * Check if user has enough credits for an action.
 */
function hasEnoughCredits(balance, cost) {
    return balance >= cost;
}
/**
 * Calculate workout credit cost based on complexity.
 */
function calculateWorkoutCost(exerciseCount, options = {}) {
    const { baseCost = constants_1.DEFAULT_WORKOUT_COST, perExerciseCost = 5, maxCost = 100, } = options;
    const totalCost = baseCost + (exerciseCount * perExerciseCost);
    return Math.min(totalCost, maxCost);
}
/**
 * Format credits for display.
 */
function formatCredits(credits) {
    if (credits >= 1000) {
        return `${(credits / 1000).toFixed(1)}k`;
    }
    return credits.toString();
}
/**
 * Format dollar amount for display.
 */
function formatDollars(cents) {
    const dollars = cents / 100;
    return new Intl.NumberFormat('en-US', {
        style: 'currency',
        currency: 'USD',
    }).format(dollars);
}
/**
 * Calculate the value proposition text for a tier.
 */
function getTierValueText(tierId) {
    const tier = constants_1.PRICING_TIERS.find((t) => t.id === tierId);
    if (!tier)
        return null;
    const baseCredits = tier.priceCents;
    const bonusCredits = tier.credits - baseCredits;
    if (bonusCredits <= 0) {
        return 'Standard rate';
    }
    const bonusPercentage = Math.round((bonusCredits / baseCredits) * 100);
    return `+${bonusPercentage}% bonus`;
}
//# sourceMappingURL=credit-calculation.js.map