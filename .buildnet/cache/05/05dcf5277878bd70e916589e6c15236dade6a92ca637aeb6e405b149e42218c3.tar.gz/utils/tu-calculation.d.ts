/**
 * Training Units (TU) Calculation
 *
 * TU is the core metric in MuscleMap that quantifies training volume
 * in a way that accounts for exercise difficulty, muscle activation,
 * and progressive overload.
 *
 * Formula: TU = SUM(sets * reps * weight_factor * activation_factor)
 * Where:
 *   - weight_factor: Normalized weight relative to bodyweight or reference
 *   - activation_factor: How much the exercise activates target muscles (0-1)
 */
export interface TUInput {
    sets: number;
    reps: number;
    weight?: number;
    bodyweight?: number;
    activationFactor: number;
    isBodyweight?: boolean;
}
export interface TUResult {
    raw: number;
    normalized: number;
    breakdown: {
        volume: number;
        weightFactor: number;
        activationFactor: number;
    };
}
/**
 * Calculate Training Units for a single exercise performance.
 */
export declare function calculateTU(input: TUInput): TUResult;
/**
 * Calculate total TU for a workout (multiple exercises).
 */
export declare function calculateWorkoutTU(exercises: TUInput[]): {
    total: number;
    average: number;
    perExercise: number[];
};
/**
 * Estimate TU from basic inputs (for quick calculations).
 */
export declare function estimateTU(sets: number, reps: number, intensity?: 'light' | 'moderate' | 'heavy'): number;
//# sourceMappingURL=tu-calculation.d.ts.map