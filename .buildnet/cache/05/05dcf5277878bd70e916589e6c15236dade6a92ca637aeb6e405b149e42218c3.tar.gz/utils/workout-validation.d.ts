/**
 * Workout Validation Utilities
 *
 * Shared validation logic for workout data across all platforms.
 */
export interface WorkoutSetInput {
    reps: number;
    weight?: number;
    duration?: number;
    distance?: number;
}
export interface WorkoutExerciseInput {
    exerciseId: string;
    sets: WorkoutSetInput[];
}
export interface WorkoutInput {
    exercises: WorkoutExerciseInput[];
    startedAt?: Date | string;
    completedAt?: Date | string;
}
export interface ValidationError {
    field: string;
    message: string;
    code: string;
}
export interface ValidationResult {
    valid: boolean;
    errors: ValidationError[];
}
/**
 * Validate a single set input.
 */
export declare function validateSet(set: WorkoutSetInput, setIndex: number): ValidationError[];
/**
 * Validate a workout exercise input.
 */
export declare function validateWorkoutExercise(exercise: WorkoutExerciseInput, exerciseIndex: number): ValidationError[];
/**
 * Validate a complete workout input.
 */
export declare function validateWorkout(workout: WorkoutInput): ValidationResult;
/**
 * Check if a workout has any completed sets (non-zero reps).
 */
export declare function hasCompletedSets(workout: WorkoutInput): boolean;
/**
 * Calculate workout summary statistics.
 */
export declare function getWorkoutSummary(workout: WorkoutInput): {
    totalExercises: number;
    totalSets: number;
    totalReps: number;
    totalWeight: number;
    completedSets: number;
};
//# sourceMappingURL=workout-validation.d.ts.map