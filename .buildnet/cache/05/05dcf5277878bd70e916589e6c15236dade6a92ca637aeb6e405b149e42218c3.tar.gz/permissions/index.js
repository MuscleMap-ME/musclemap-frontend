"use strict";
/**
 * @musclemap/core - Permissions System
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.GroupRolePermissions = exports.RolePermissions = exports.CorePermissions = void 0;
exports.hasPermission = hasPermission;
exports.hasAnyPermission = hasAnyPermission;
exports.hasAllPermissions = hasAllPermissions;
exports.getAllPermissions = getAllPermissions;
exports.hasGroupPermission = hasGroupPermission;
exports.pluginPermission = pluginPermission;
exports.CorePermissions = {
    USERS_READ: 'users.read',
    USERS_WRITE: 'users.write',
    USERS_DELETE: 'users.delete',
    USERS_BAN: 'users.ban',
    GROUPS_CREATE: 'groups.create',
    GROUPS_READ: 'groups.read',
    GROUPS_WRITE: 'groups.write',
    GROUPS_DELETE: 'groups.delete',
    GROUPS_MANAGE_MEMBERS: 'groups.manage_members',
    GROUPS_MANAGE_POLICIES: 'groups.manage_policies',
    ECONOMY_READ: 'economy.read',
    ECONOMY_CHARGE: 'economy.charge',
    ECONOMY_REFUND: 'economy.refund',
    ECONOMY_GRANT: 'economy.grant',
    ECONOMY_MANAGE_TIERS: 'economy.manage_tiers',
    WORKOUTS_CREATE: 'workouts.create',
    WORKOUTS_READ: 'workouts.read',
    WORKOUTS_READ_ALL: 'workouts.read_all',
    WORKOUTS_DELETE: 'workouts.delete',
    COMPETITIONS_CREATE: 'competitions.create',
    COMPETITIONS_READ: 'competitions.read',
    COMPETITIONS_JOIN: 'competitions.join',
    COMPETITIONS_MANAGE: 'competitions.manage',
    ADMIN_ACCESS: 'admin.access',
    ADMIN_USERS: 'admin.users',
    ADMIN_GROUPS: 'admin.groups',
    ADMIN_ECONOMY: 'admin.economy',
    ADMIN_PLUGINS: 'admin.plugins',
    ADMIN_SYSTEM: 'admin.system',
    PLUGINS_INSTALL: 'plugins.install',
    PLUGINS_CONFIGURE: 'plugins.configure',
    PLUGINS_DISABLE: 'plugins.disable',
};
exports.RolePermissions = {
    user: [
        exports.CorePermissions.USERS_READ,
        exports.CorePermissions.GROUPS_READ,
        exports.CorePermissions.ECONOMY_READ,
        exports.CorePermissions.WORKOUTS_CREATE,
        exports.CorePermissions.WORKOUTS_READ,
        exports.CorePermissions.COMPETITIONS_READ,
        exports.CorePermissions.COMPETITIONS_JOIN,
    ],
    moderator: [
        exports.CorePermissions.USERS_READ,
        exports.CorePermissions.USERS_BAN,
        exports.CorePermissions.GROUPS_READ,
        exports.CorePermissions.GROUPS_MANAGE_MEMBERS,
        exports.CorePermissions.ECONOMY_READ,
        exports.CorePermissions.WORKOUTS_READ_ALL,
        exports.CorePermissions.COMPETITIONS_READ,
        exports.CorePermissions.COMPETITIONS_MANAGE,
        exports.CorePermissions.ADMIN_ACCESS,
    ],
    developer: [
        exports.CorePermissions.USERS_READ,
        exports.CorePermissions.GROUPS_READ,
        exports.CorePermissions.ECONOMY_READ,
        exports.CorePermissions.WORKOUTS_CREATE,
        exports.CorePermissions.WORKOUTS_READ,
        exports.CorePermissions.COMPETITIONS_READ,
        exports.CorePermissions.COMPETITIONS_JOIN,
        exports.CorePermissions.PLUGINS_INSTALL,
        exports.CorePermissions.PLUGINS_CONFIGURE,
    ],
    admin: Object.values(exports.CorePermissions),
};
exports.GroupRolePermissions = {
    viewer: ['group.view'],
    member: ['group.view', 'group.participate'],
    admin: ['group.view', 'group.participate', 'group.manage_members', 'group.settings'],
    owner: ['group.view', 'group.participate', 'group.manage_members', 'group.settings', 'group.delete', 'group.transfer'],
};
function hasPermission(ctx, permission) {
    const userPermissions = new Set();
    for (const role of ctx.userRoles) {
        const rolePerms = exports.RolePermissions[role] || [];
        for (const perm of rolePerms) {
            userPermissions.add(perm);
        }
    }
    if (ctx.pluginPermissions) {
        for (const perm of ctx.pluginPermissions) {
            userPermissions.add(perm);
        }
    }
    if (userPermissions.has(permission))
        return true;
    const parts = permission.split('.');
    if (parts.length === 2) {
        if (userPermissions.has(`${parts[0]}.*`))
            return true;
    }
    return false;
}
function hasAnyPermission(ctx, permissions) {
    return permissions.some(p => hasPermission(ctx, p));
}
function hasAllPermissions(ctx, permissions) {
    return permissions.every(p => hasPermission(ctx, p));
}
function getAllPermissions(ctx) {
    const permissions = new Set();
    for (const role of ctx.userRoles) {
        const rolePerms = exports.RolePermissions[role] || [];
        for (const perm of rolePerms) {
            permissions.add(perm);
        }
    }
    if (ctx.pluginPermissions) {
        for (const perm of ctx.pluginPermissions) {
            permissions.add(perm);
        }
    }
    return Array.from(permissions).sort();
}
function hasGroupPermission(ctx, groupId, permission) {
    if (!ctx.groupMemberships)
        return false;
    const role = ctx.groupMemberships.get(groupId);
    if (!role)
        return false;
    return (exports.GroupRolePermissions[role] || []).includes(permission);
}
function pluginPermission(pluginId, action) {
    return `plugin:${pluginId}:${action}`;
}
//# sourceMappingURL=index.js.map