/**
 * @musclemap/core - Permissions System
 */
type UserRole = 'user' | 'admin' | 'moderator' | 'developer';
type GroupRole = 'owner' | 'admin' | 'member' | 'viewer';
export declare const CorePermissions: {
    readonly USERS_READ: "users.read";
    readonly USERS_WRITE: "users.write";
    readonly USERS_DELETE: "users.delete";
    readonly USERS_BAN: "users.ban";
    readonly GROUPS_CREATE: "groups.create";
    readonly GROUPS_READ: "groups.read";
    readonly GROUPS_WRITE: "groups.write";
    readonly GROUPS_DELETE: "groups.delete";
    readonly GROUPS_MANAGE_MEMBERS: "groups.manage_members";
    readonly GROUPS_MANAGE_POLICIES: "groups.manage_policies";
    readonly ECONOMY_READ: "economy.read";
    readonly ECONOMY_CHARGE: "economy.charge";
    readonly ECONOMY_REFUND: "economy.refund";
    readonly ECONOMY_GRANT: "economy.grant";
    readonly ECONOMY_MANAGE_TIERS: "economy.manage_tiers";
    readonly WORKOUTS_CREATE: "workouts.create";
    readonly WORKOUTS_READ: "workouts.read";
    readonly WORKOUTS_READ_ALL: "workouts.read_all";
    readonly WORKOUTS_DELETE: "workouts.delete";
    readonly COMPETITIONS_CREATE: "competitions.create";
    readonly COMPETITIONS_READ: "competitions.read";
    readonly COMPETITIONS_JOIN: "competitions.join";
    readonly COMPETITIONS_MANAGE: "competitions.manage";
    readonly ADMIN_ACCESS: "admin.access";
    readonly ADMIN_USERS: "admin.users";
    readonly ADMIN_GROUPS: "admin.groups";
    readonly ADMIN_ECONOMY: "admin.economy";
    readonly ADMIN_PLUGINS: "admin.plugins";
    readonly ADMIN_SYSTEM: "admin.system";
    readonly PLUGINS_INSTALL: "plugins.install";
    readonly PLUGINS_CONFIGURE: "plugins.configure";
    readonly PLUGINS_DISABLE: "plugins.disable";
};
export type CorePermission = typeof CorePermissions[keyof typeof CorePermissions];
export declare const RolePermissions: Record<UserRole, CorePermission[]>;
export declare const GroupRolePermissions: Record<GroupRole, string[]>;
export interface PermissionContext {
    userId: string;
    userRoles: UserRole[];
    groupMemberships?: Map<string, GroupRole>;
    pluginPermissions?: string[];
}
export declare function hasPermission(ctx: PermissionContext, permission: string): boolean;
export declare function hasAnyPermission(ctx: PermissionContext, permissions: string[]): boolean;
export declare function hasAllPermissions(ctx: PermissionContext, permissions: string[]): boolean;
export declare function getAllPermissions(ctx: PermissionContext): string[];
export declare function hasGroupPermission(ctx: PermissionContext, groupId: string, permission: string): boolean;
export declare function pluginPermission(pluginId: string, action: string): string;
export {};
//# sourceMappingURL=index.d.ts.map