"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports, p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.pluginPermission = exports.hasGroupPermission = exports.getAllPermissions = exports.hasAllPermissions = exports.hasAnyPermission = exports.hasPermission = exports.GroupRolePermissions = exports.RolePermissions = exports.CorePermissions = void 0;
// Re-export all types
__exportStar(require("./types/index"), exports);
// Re-export all constants
__exportStar(require("./constants/index"), exports);
// Re-export permissions
var index_1 = require("./permissions/index");
Object.defineProperty(exports, "CorePermissions", { enumerable: true, get: function () { return index_1.CorePermissions; } });
Object.defineProperty(exports, "RolePermissions", { enumerable: true, get: function () { return index_1.RolePermissions; } });
Object.defineProperty(exports, "GroupRolePermissions", { enumerable: true, get: function () { return index_1.GroupRolePermissions; } });
Object.defineProperty(exports, "hasPermission", { enumerable: true, get: function () { return index_1.hasPermission; } });
Object.defineProperty(exports, "hasAnyPermission", { enumerable: true, get: function () { return index_1.hasAnyPermission; } });
Object.defineProperty(exports, "hasAllPermissions", { enumerable: true, get: function () { return index_1.hasAllPermissions; } });
Object.defineProperty(exports, "getAllPermissions", { enumerable: true, get: function () { return index_1.getAllPermissions; } });
Object.defineProperty(exports, "hasGroupPermission", { enumerable: true, get: function () { return index_1.hasGroupPermission; } });
Object.defineProperty(exports, "pluginPermission", { enumerable: true, get: function () { return index_1.pluginPermission; } });
// Re-export utilities
__exportStar(require("./utils/index"), exports);
//# sourceMappingURL=index.js.map