/**
 * @musclemap/core - Constants
 *
 * Shared constants across the application.
 */
interface CreditTier {
    id: string;
    credits: number;
    priceCents: number;
    label: string;
    popular?: boolean;
}
export declare const CREDITS_PER_DOLLAR = 100;
export declare const DEFAULT_WORKOUT_COST = 25;
export declare const MINIMUM_PURCHASE_CENTS = 100;
/**
 * Official pricing tiers - must match /api/economy/pricing response
 */
export declare const PRICING_TIERS: CreditTier[];
export declare const PRICING_RATE = "1 credit = $0.01";
export declare const COLOR_TIERS: {
    readonly 0: {
        readonly name: "Inactive";
        readonly hex: "#2A2A4A";
        readonly rgb: readonly [42, 42, 74];
    };
    readonly 1: {
        readonly name: "Light";
        readonly hex: "#3B82F6";
        readonly rgb: readonly [59, 130, 246];
    };
    readonly 2: {
        readonly name: "Moderate";
        readonly hex: "#22C55E";
        readonly rgb: readonly [34, 197, 94];
    };
    readonly 3: {
        readonly name: "Working";
        readonly hex: "#EAB308";
        readonly rgb: readonly [234, 179, 8];
    };
    readonly 4: {
        readonly name: "High";
        readonly hex: "#F97316";
        readonly rgb: readonly [249, 115, 22];
    };
    readonly 5: {
        readonly name: "Maximum";
        readonly hex: "#EF4444";
        readonly rgb: readonly [239, 68, 68];
    };
};
export declare function getColorTier(normalizedActivation: number): 0 | 1 | 2 | 3 | 4 | 5;
export declare const ArchetypeIds: {
    readonly BALANCED: "ARCH-001";
    readonly JUDOKA: "ARCH-002";
    readonly SPRINTER: "ARCH-003";
    readonly SWIMMER: "ARCH-004";
    readonly TENNIS: "ARCH-005";
    readonly SAMOAN: "ARCH-006";
    readonly CLIMBER: "ARCH-007";
    readonly POWERLIFTER: "ARCH-008";
    readonly SOCCER: "ARCH-009";
    readonly GYMNAST: "ARCH-010";
};
export declare const ExerciseTypes: {
    readonly BODYWEIGHT: "bodyweight";
    readonly KETTLEBELL: "kettlebell";
    readonly FREEWEIGHT: "freeweight";
    readonly MACHINE: "machine";
    readonly CABLE: "cable";
};
export declare const CompetitionDefaults: {
    MIN_DURATION_DAYS: number;
    MAX_DURATION_DAYS: number;
    DEFAULT_MAX_PARTICIPANTS: number;
    MAX_PARTICIPANTS_LIMIT: number;
};
export declare const ApiVersions: {
    readonly CURRENT: "v1";
    readonly LEGACY: "legacy";
};
export declare const ApiHeaders: {
    readonly REQUEST_ID: "x-request-id";
    readonly CORRELATION_ID: "x-correlation-id";
    readonly API_VERSION: "x-api-version";
    readonly IDEMPOTENCY_KEY: "idempotency-key";
};
export declare const RateLimits: {
    readonly AUTH_ATTEMPTS: {
        readonly windowMs: number;
        readonly max: 5;
    };
    readonly API_GENERAL: {
        readonly windowMs: number;
        readonly max: 100;
    };
    readonly API_EXPENSIVE: {
        readonly windowMs: number;
        readonly max: 10;
    };
    readonly WEBHOOK: {
        readonly windowMs: number;
        readonly max: 1000;
    };
};
export declare const PluginConstants: {
    readonly ENGINE_VERSION: "2.0.0";
    readonly MANIFEST_FILENAME: "manifest.json";
    readonly MAX_PERMISSIONS: 50;
    readonly MAX_CREDIT_ACTIONS: 20;
};
export * from './wealth-tiers.js';
//# sourceMappingURL=index.d.ts.map