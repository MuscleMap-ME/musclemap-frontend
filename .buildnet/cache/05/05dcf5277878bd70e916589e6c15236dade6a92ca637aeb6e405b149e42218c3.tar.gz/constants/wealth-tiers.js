"use strict";
/**
 * Wealth Tier System Constants
 *
 * Defines the wealth tier system for MuscleMap users based on credit balance.
 * Wealth tiers provide visual indicators and prestige for users who have
 * accumulated credits through platform activity or purchases.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.WEALTH_TIERS_BY_NAME = exports.WEALTH_TIERS_BY_LEVEL = exports.WEALTH_TIERS = void 0;
exports.calculateWealthTier = calculateWealthTier;
exports.getWealthTierForCredits = getWealthTierForCredits;
exports.getWealthTierByLevel = getWealthTierByLevel;
exports.creditsToNextTier = creditsToNextTier;
exports.wealthTierProgress = wealthTierProgress;
// ============================================
// WEALTH TIER DEFINITIONS
// ============================================
/**
 * Complete wealth tier definitions with all metadata.
 * Order is from lowest (Broke) to highest (Obsidian).
 */
exports.WEALTH_TIERS = [
    {
        tier: 0,
        name: 'Broke',
        minCredits: 0,
        color: '#666666',
        icon: 'none',
        description: 'Just getting started',
    },
    {
        tier: 1,
        name: 'Bronze',
        minCredits: 10,
        color: '#CD7F32',
        icon: 'bronze_ring',
        description: 'Building momentum',
    },
    {
        tier: 2,
        name: 'Silver',
        minCredits: 100,
        color: '#C0C0C0',
        icon: 'silver_ring',
        description: 'Consistent contributor',
    },
    {
        tier: 3,
        name: 'Gold',
        minCredits: 1000,
        color: '#FFD700',
        icon: 'gold_ring',
        description: 'Dedicated athlete',
    },
    {
        tier: 4,
        name: 'Platinum',
        minCredits: 10000,
        color: '#E5E4E2',
        icon: 'platinum_ring',
        description: 'Elite performer',
    },
    {
        tier: 5,
        name: 'Diamond',
        minCredits: 100000,
        color: '#B9F2FF',
        icon: 'diamond_ring',
        description: 'Exceptional dedication',
    },
    {
        tier: 6,
        name: 'Obsidian',
        minCredits: 1000000,
        color: '#0D0D0D',
        icon: 'obsidian_crown',
        description: 'Legendary status',
    },
];
/**
 * Wealth tiers indexed by tier number for quick lookup.
 */
exports.WEALTH_TIERS_BY_LEVEL = {
    0: exports.WEALTH_TIERS[0],
    1: exports.WEALTH_TIERS[1],
    2: exports.WEALTH_TIERS[2],
    3: exports.WEALTH_TIERS[3],
    4: exports.WEALTH_TIERS[4],
    5: exports.WEALTH_TIERS[5],
    6: exports.WEALTH_TIERS[6],
};
/**
 * Wealth tiers indexed by name for quick lookup.
 */
exports.WEALTH_TIERS_BY_NAME = {
    Broke: exports.WEALTH_TIERS[0],
    Bronze: exports.WEALTH_TIERS[1],
    Silver: exports.WEALTH_TIERS[2],
    Gold: exports.WEALTH_TIERS[3],
    Platinum: exports.WEALTH_TIERS[4],
    Diamond: exports.WEALTH_TIERS[5],
    Obsidian: exports.WEALTH_TIERS[6],
};
// ============================================
// UTILITY FUNCTIONS
// ============================================
/**
 * Calculate the wealth tier level based on credit balance.
 * Matches the PostgreSQL calculate_wealth_tier function.
 *
 * @param credits - The user's current credit balance
 * @returns The tier level (0-6)
 */
function calculateWealthTier(credits) {
    if (credits >= 1000000)
        return 6; // Obsidian
    if (credits >= 100000)
        return 5; // Diamond
    if (credits >= 10000)
        return 4; // Platinum
    if (credits >= 1000)
        return 3; // Gold
    if (credits >= 100)
        return 2; // Silver
    if (credits >= 10)
        return 1; // Bronze
    return 0; // Broke
}
/**
 * Get the full wealth tier definition for a given credit balance.
 *
 * @param credits - The user's current credit balance
 * @returns The complete wealth tier definition
 */
function getWealthTierForCredits(credits) {
    const tierLevel = calculateWealthTier(credits);
    return exports.WEALTH_TIERS_BY_LEVEL[tierLevel];
}
/**
 * Get the full wealth tier definition for a given tier level.
 *
 * @param tier - The tier level (0-6)
 * @returns The complete wealth tier definition
 */
function getWealthTierByLevel(tier) {
    return exports.WEALTH_TIERS_BY_LEVEL[tier];
}
/**
 * Calculate credits needed to reach the next tier.
 *
 * @param currentCredits - The user's current credit balance
 * @returns Credits needed for next tier, or null if at max tier
 */
function creditsToNextTier(currentCredits) {
    const currentTier = calculateWealthTier(currentCredits);
    if (currentTier >= 6)
        return null; // Already at max tier
    const nextTier = exports.WEALTH_TIERS[currentTier + 1];
    return nextTier.minCredits - currentCredits;
}
/**
 * Calculate progress percentage within current tier.
 *
 * @param credits - The user's current credit balance
 * @returns Progress percentage (0-100) within current tier
 */
function wealthTierProgress(credits) {
    const currentTier = calculateWealthTier(credits);
    if (currentTier >= 6)
        return 100; // At max tier
    const currentTierDef = exports.WEALTH_TIERS[currentTier];
    const nextTierDef = exports.WEALTH_TIERS[currentTier + 1];
    const tierRange = nextTierDef.minCredits - currentTierDef.minCredits;
    const progress = credits - currentTierDef.minCredits;
    return Math.min(100, Math.max(0, Math.round((progress / tierRange) * 100)));
}
//# sourceMappingURL=wealth-tiers.js.map