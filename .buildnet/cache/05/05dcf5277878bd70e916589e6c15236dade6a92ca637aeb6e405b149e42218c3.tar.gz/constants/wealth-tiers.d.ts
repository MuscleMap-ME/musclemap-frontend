/**
 * Wealth Tier System Constants
 *
 * Defines the wealth tier system for MuscleMap users based on credit balance.
 * Wealth tiers provide visual indicators and prestige for users who have
 * accumulated credits through platform activity or purchases.
 */
export interface WealthTierDefinition {
    /** Tier level (0-6) */
    tier: number;
    /** Display name for the tier */
    name: string;
    /** Minimum credits required for this tier */
    minCredits: number;
    /** Hex color code for tier display */
    color: string;
    /** Icon identifier for the tier */
    icon: string;
    /** Description of the tier */
    description: string;
}
export type WealthTierLevel = 0 | 1 | 2 | 3 | 4 | 5 | 6;
export type WealthTierName = 'Broke' | 'Bronze' | 'Silver' | 'Gold' | 'Platinum' | 'Diamond' | 'Obsidian';
/**
 * Complete wealth tier definitions with all metadata.
 * Order is from lowest (Broke) to highest (Obsidian).
 */
export declare const WEALTH_TIERS: readonly WealthTierDefinition[];
/**
 * Wealth tiers indexed by tier number for quick lookup.
 */
export declare const WEALTH_TIERS_BY_LEVEL: Record<WealthTierLevel, WealthTierDefinition>;
/**
 * Wealth tiers indexed by name for quick lookup.
 */
export declare const WEALTH_TIERS_BY_NAME: Record<WealthTierName, WealthTierDefinition>;
/**
 * Calculate the wealth tier level based on credit balance.
 * Matches the PostgreSQL calculate_wealth_tier function.
 *
 * @param credits - The user's current credit balance
 * @returns The tier level (0-6)
 */
export declare function calculateWealthTier(credits: number): WealthTierLevel;
/**
 * Get the full wealth tier definition for a given credit balance.
 *
 * @param credits - The user's current credit balance
 * @returns The complete wealth tier definition
 */
export declare function getWealthTierForCredits(credits: number): WealthTierDefinition;
/**
 * Get the full wealth tier definition for a given tier level.
 *
 * @param tier - The tier level (0-6)
 * @returns The complete wealth tier definition
 */
export declare function getWealthTierByLevel(tier: WealthTierLevel): WealthTierDefinition;
/**
 * Calculate credits needed to reach the next tier.
 *
 * @param currentCredits - The user's current credit balance
 * @returns Credits needed for next tier, or null if at max tier
 */
export declare function creditsToNextTier(currentCredits: number): number | null;
/**
 * Calculate progress percentage within current tier.
 *
 * @param credits - The user's current credit balance
 * @returns Progress percentage (0-100) within current tier
 */
export declare function wealthTierProgress(credits: number): number;
//# sourceMappingURL=wealth-tiers.d.ts.map