"use strict";
/**
 * @musclemap/core - Constants
 *
 * Shared constants across the application.
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports, p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PluginConstants = exports.RateLimits = exports.ApiHeaders = exports.ApiVersions = exports.CompetitionDefaults = exports.ExerciseTypes = exports.ArchetypeIds = exports.COLOR_TIERS = exports.PRICING_RATE = exports.PRICING_TIERS = exports.MINIMUM_PURCHASE_CENTS = exports.DEFAULT_WORKOUT_COST = exports.CREDITS_PER_DOLLAR = void 0;
exports.getColorTier = getColorTier;
// ============================================
// CREDIT SYSTEM CONSTANTS
// ============================================
exports.CREDITS_PER_DOLLAR = 100;
exports.DEFAULT_WORKOUT_COST = 25;
exports.MINIMUM_PURCHASE_CENTS = 100; // $1.00
/**
 * Official pricing tiers - must match /api/economy/pricing response
 */
exports.PRICING_TIERS = [
    { id: 'starter', credits: 100, priceCents: 100, label: '$1 = 100 credits' },
    { id: 'value', credits: 550, priceCents: 500, label: '$5 = 550 credits (+10%)' },
    { id: 'popular', credits: 1200, priceCents: 1000, label: '$10 = 1,200 credits (+20%)', popular: true },
    { id: 'premium', credits: 2750, priceCents: 2000, label: '$20 = 2,750 credits (+37.5%)' },
    { id: 'mega', credits: 6000, priceCents: 4000, label: '$40 = 6,000 credits (+50%)' },
    { id: 'ultimate', credits: 15000, priceCents: 8000, label: '$80 = 15,000 credits (+87.5%)' },
];
exports.PRICING_RATE = '1 credit = $0.01';
// ============================================
// COLOR TIER SYSTEM
// ============================================
exports.COLOR_TIERS = {
    0: { name: 'Inactive', hex: '#2A2A4A', rgb: [42, 42, 74] },
    1: { name: 'Light', hex: '#3B82F6', rgb: [59, 130, 246] },
    2: { name: 'Moderate', hex: '#22C55E', rgb: [34, 197, 94] },
    3: { name: 'Working', hex: '#EAB308', rgb: [234, 179, 8] },
    4: { name: 'High', hex: '#F97316', rgb: [249, 115, 22] },
    5: { name: 'Maximum', hex: '#EF4444', rgb: [239, 68, 68] },
};
function getColorTier(normalizedActivation) {
    if (normalizedActivation <= 0)
        return 0;
    if (normalizedActivation <= 20)
        return 1;
    if (normalizedActivation <= 40)
        return 2;
    if (normalizedActivation <= 60)
        return 3;
    if (normalizedActivation <= 80)
        return 4;
    return 5;
}
// ============================================
// ARCHETYPE IDS
// ============================================
exports.ArchetypeIds = {
    BALANCED: 'ARCH-001',
    JUDOKA: 'ARCH-002',
    SPRINTER: 'ARCH-003',
    SWIMMER: 'ARCH-004',
    TENNIS: 'ARCH-005',
    SAMOAN: 'ARCH-006',
    CLIMBER: 'ARCH-007',
    POWERLIFTER: 'ARCH-008',
    SOCCER: 'ARCH-009',
    GYMNAST: 'ARCH-010',
};
// ============================================
// EXERCISE TYPES
// ============================================
exports.ExerciseTypes = {
    BODYWEIGHT: 'bodyweight',
    KETTLEBELL: 'kettlebell',
    FREEWEIGHT: 'freeweight',
    MACHINE: 'machine',
    CABLE: 'cable',
};
// ============================================
// COMPETITION CONSTANTS
// ============================================
exports.CompetitionDefaults = {
    MIN_DURATION_DAYS: 1,
    MAX_DURATION_DAYS: 90,
    DEFAULT_MAX_PARTICIPANTS: 100,
    MAX_PARTICIPANTS_LIMIT: 10000,
};
// ============================================
// API CONSTANTS
// ============================================
exports.ApiVersions = {
    CURRENT: 'v1',
    LEGACY: 'legacy',
};
exports.ApiHeaders = {
    REQUEST_ID: 'x-request-id',
    CORRELATION_ID: 'x-correlation-id',
    API_VERSION: 'x-api-version',
    IDEMPOTENCY_KEY: 'idempotency-key',
};
// ============================================
// RATE LIMITS
// ============================================
exports.RateLimits = {
    AUTH_ATTEMPTS: { windowMs: 15 * 60 * 1000, max: 5 }, // 5 per 15 min
    API_GENERAL: { windowMs: 60 * 1000, max: 100 }, // 100 per minute
    API_EXPENSIVE: { windowMs: 60 * 1000, max: 10 }, // 10 per minute
    WEBHOOK: { windowMs: 60 * 1000, max: 1000 }, // 1000 per minute
};
// ============================================
// PLUGIN SYSTEM
// ============================================
exports.PluginConstants = {
    ENGINE_VERSION: '2.0.0',
    MANIFEST_FILENAME: 'manifest.json',
    MAX_PERMISSIONS: 50,
    MAX_CREDIT_ACTIONS: 20,
};
// ============================================
// WEALTH TIERS
// ============================================
__exportStar(require("./wealth-tiers.js"), exports);
//# sourceMappingURL=index.js.map