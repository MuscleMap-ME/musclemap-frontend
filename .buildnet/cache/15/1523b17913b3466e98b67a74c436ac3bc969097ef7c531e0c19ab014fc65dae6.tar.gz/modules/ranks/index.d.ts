/**
 * Ranks Module
 *
 * Handles the rank/level system for MuscleMap:
 * - 8 rank tiers: Novice → Trainee → Apprentice → Practitioner → Journeyperson → Expert → Master → Grandmaster
 * - Military-inspired insignia (chevrons, stars, shields)
 * - XP-based progression with configurable thresholds
 * - Veteran badges based on account tenure
 *
 * This module provides:
 * - Rank definitions and lookups
 * - User rank information
 * - Veteran tier calculations
 * - Leaderboard integration
 */
export declare const RANK_TIERS: {
    readonly NOVICE: 1;
    readonly TRAINEE: 2;
    readonly APPRENTICE: 3;
    readonly PRACTITIONER: 4;
    readonly JOURNEYPERSON: 5;
    readonly EXPERT: 6;
    readonly MASTER: 7;
    readonly GRANDMASTER: 8;
};
export type RankTier = (typeof RANK_TIERS)[keyof typeof RANK_TIERS];
export type RankName = 'novice' | 'trainee' | 'apprentice' | 'practitioner' | 'journeyperson' | 'expert' | 'master' | 'grandmaster';
export interface RankDefinition {
    id: string;
    tier: RankTier;
    name: RankName;
    displayName: string;
    xpThreshold: number;
    badgeIcon: string;
    badgeColor: string;
    perks: string[];
}
export interface UserRankInfo {
    userId: string;
    currentRank: RankName;
    currentTier: RankTier;
    totalXp: number;
    xpToNextRank: number | null;
    progressPercent: number;
    nextRank: RankDefinition | null;
    currentRankDef: RankDefinition;
    rankUpdatedAt: Date | null;
    veteranTier: number;
    veteranLabel: string | null;
}
export interface VeteranBadge {
    tier: 0 | 1 | 2 | 3;
    label: string | null;
    icon: string;
    color: string;
    monthsActive: number;
}
export declare const rankService: {
    /**
     * Get all rank definitions
     */
    getRankDefinitions(): Promise<RankDefinition[]>;
    /**
     * Get rank definition by name
     */
    getRankByName(name: RankName): Promise<RankDefinition | null>;
    /**
     * Get rank definition by tier
     */
    getRankByTier(tier: RankTier): Promise<RankDefinition | null>;
    /**
     * Get the rank for a given XP amount
     */
    getRankForXp(totalXp: number): Promise<RankDefinition>;
    /**
     * Get next rank after a given rank
     */
    getNextRank(currentRankName: RankName): Promise<RankDefinition | null>;
    /**
     * Get complete rank info for a user
     */
    getUserRankInfo(userId: string): Promise<UserRankInfo | null>;
    /**
     * Calculate veteran tier from account creation date
     */
    calculateVeteranTier(createdAt: Date): 0 | 1 | 2 | 3;
    /**
     * Get veteran badge info for a user
     */
    getVeteranBadge(userId: string): Promise<VeteranBadge | null>;
    /**
     * Update veteran tier for a user (called by nightly job)
     */
    updateVeteranTier(userId: string): Promise<number>;
    /**
     * Update veteran tiers for all users (batch operation)
     */
    updateAllVeteranTiers(): Promise<{
        updated: number;
    }>;
    /**
     * Refresh the XP rankings materialized view
     */
    refreshRankings(): Promise<void>;
    /**
     * Get XP leaderboard from materialized view
     */
    getXpLeaderboard(options?: {
        limit?: number;
        offset?: number;
        country?: string;
        state?: string;
        city?: string;
    }): Promise<{
        entries: Array<{
            rank: number;
            userId: string;
            username: string;
            displayName?: string;
            avatarUrl?: string;
            totalXp: number;
            currentRank: RankName;
            veteranTier: number;
            country?: string;
        }>;
        total: number;
    }>;
};
export { xpService } from './xp.service';
export default rankService;
