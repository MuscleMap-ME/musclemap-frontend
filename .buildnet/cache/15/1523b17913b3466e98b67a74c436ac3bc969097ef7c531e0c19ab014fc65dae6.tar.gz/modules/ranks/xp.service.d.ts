/**
 * XP Service
 *
 * Handles XP (experience point) management for the ranking system:
 * - Award XP for various activities
 * - Track XP history for auditing
 * - Calculate rank from total XP
 * - Check and process rank-ups
 *
 * XP Sources and Amounts:
 * - Workout complete: 25 base + duration bonus
 * - Goal complete: 50 base
 * - Archetype level up: 100
 * - Daily streak: 10 per day
 * - Achievements: 25-500 based on rarity
 * - First workout: 100 (one-time)
 *
 * Velocity Limits (anti-cheat):
 * - Max 500 XP per day
 * - Max 200 XP per hour
 * - Max 100 XP per single workout
 * - 5-minute cooldown between same-source awards
 */
export declare const XP_AMOUNTS: {
    readonly WORKOUT_BASE: 25;
    readonly WORKOUT_DURATION_PER_10MIN: 5;
    readonly GOAL_COMPLETE: 50;
    readonly ARCHETYPE_LEVEL_UP: 100;
    readonly ARCHETYPE_COMPLETE: 500;
    readonly STREAK_DAILY: 10;
    readonly STREAK_7_DAY_BONUS: 50;
    readonly STREAK_30_DAY_BONUS: 200;
    readonly STREAK_100_DAY_BONUS: 500;
    readonly ACHIEVEMENT_COMMON: 25;
    readonly ACHIEVEMENT_UNCOMMON: 50;
    readonly ACHIEVEMENT_RARE: 100;
    readonly ACHIEVEMENT_EPIC: 200;
    readonly ACHIEVEMENT_LEGENDARY: 500;
    readonly FIRST_WORKOUT: 100;
};
export declare const XP_LIMITS: {
    readonly MAX_PER_DAY: 2000;
    readonly MAX_PER_HOUR: 500;
    readonly MAX_PER_WORKOUT: 200;
    readonly COOLDOWN_MINUTES: 1;
};
export type XpSourceType = 'workout' | 'goal' | 'archetype' | 'streak' | 'achievement' | 'special' | 'backfill' | 'admin';
export interface XpAwardParams {
    userId: string;
    amount: number;
    sourceType: XpSourceType;
    sourceId?: string;
    reason: string;
    metadata?: Record<string, unknown>;
    bypassLimits?: boolean;
}
export interface XpAwardResult {
    success: boolean;
    xpAwarded: number;
    newTotalXp: number;
    rankUp: boolean;
    previousRank?: string;
    newRank: string;
    error?: string;
}
export interface XpHistoryEntry {
    id: string;
    amount: number;
    sourceType: XpSourceType;
    sourceId?: string;
    reason: string;
    metadata: Record<string, unknown>;
    createdAt: Date;
}
export declare const xpService: {
    /**
     * Award XP to a user
     */
    awardXp(params: XpAwardParams): Promise<XpAwardResult>;
    /**
     * Check velocity limits for XP award
     * Note: Owner accounts bypass all velocity limits for testing purposes
     */
    checkVelocityLimits(userId: string, amount: number, sourceType: XpSourceType, sourceId?: string): Promise<{
        allowed: boolean;
        reason?: string;
    }>;
    /**
     * Get XP history for a user
     */
    getHistory(userId: string, options?: {
        limit?: number;
        offset?: number;
        sourceType?: XpSourceType;
    }): Promise<{
        entries: XpHistoryEntry[];
        total: number;
    }>;
    /**
     * Get daily XP earned
     */
    getDailyXp(userId: string): Promise<number>;
    /**
     * Get weekly XP earned
     */
    getWeeklyXp(userId: string): Promise<number>;
    /**
     * Award XP for workout completion
     */
    onWorkoutComplete(params: {
        userId: string;
        workoutId: string;
        durationMinutes: number;
    }): Promise<XpAwardResult>;
    /**
     * Award XP for goal completion
     */
    onGoalComplete(params: {
        userId: string;
        goalId: string;
        goalName?: string;
    }): Promise<XpAwardResult>;
    /**
     * Award XP for archetype level up
     */
    onArchetypeLevelUp(params: {
        userId: string;
        archetypeId: string;
        archetypeName: string;
        newLevel: number;
    }): Promise<XpAwardResult>;
    /**
     * Award XP for streak milestone
     */
    onStreakMilestone(params: {
        userId: string;
        streakDays: number;
    }): Promise<XpAwardResult | null>;
    /**
     * Award XP for achievement unlock
     */
    onAchievementUnlock(params: {
        userId: string;
        achievementId: string;
        achievementName: string;
        rarity: "common" | "uncommon" | "rare" | "epic" | "legendary";
    }): Promise<XpAwardResult>;
    /**
     * Award first workout bonus (one-time)
     */
    onFirstWorkout(params: {
        userId: string;
        workoutId: string;
    }): Promise<XpAwardResult>;
};
export default xpService;
