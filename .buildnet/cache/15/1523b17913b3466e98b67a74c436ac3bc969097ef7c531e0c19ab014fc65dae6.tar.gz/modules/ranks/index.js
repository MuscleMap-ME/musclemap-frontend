"use strict";
/**
 * Ranks Module
 *
 * Handles the rank/level system for MuscleMap:
 * - 8 rank tiers: Novice → Trainee → Apprentice → Practitioner → Journeyperson → Expert → Master → Grandmaster
 * - Military-inspired insignia (chevrons, stars, shields)
 * - XP-based progression with configurable thresholds
 * - Veteran badges based on account tenure
 *
 * This module provides:
 * - Rank definitions and lookups
 * - User rank information
 * - Veteran tier calculations
 * - Leaderboard integration
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.xpService = exports.rankService = exports.RANK_TIERS = void 0;
const client_1 = require("../../db/client");
const logger_1 = require("../../lib/logger");
const log = logger_1.loggers.economy;
// Rank tier constants
exports.RANK_TIERS = {
    NOVICE: 1,
    TRAINEE: 2,
    APPRENTICE: 3,
    PRACTITIONER: 4,
    JOURNEYPERSON: 5,
    EXPERT: 6,
    MASTER: 7,
    GRANDMASTER: 8,
};
// Default rank definitions (used if DB not seeded)
const DEFAULT_RANKS = [
    { id: 'rank_novice', tier: 1, name: 'novice', displayName: 'Novice', xpThreshold: 0, badgeIcon: 'chevron-outline', badgeColor: '#6B7280', perks: ['Basic profile'] },
    { id: 'rank_trainee', tier: 2, name: 'trainee', displayName: 'Trainee', xpThreshold: 100, badgeIcon: 'chevron-1', badgeColor: '#22C55E', perks: ['Basic leaderboards'] },
    { id: 'rank_apprentice', tier: 3, name: 'apprentice', displayName: 'Apprentice', xpThreshold: 500, badgeIcon: 'chevron-2', badgeColor: '#3B82F6', perks: ['Custom bio'] },
    { id: 'rank_practitioner', tier: 4, name: 'practitioner', displayName: 'Practitioner', xpThreshold: 1500, badgeIcon: 'chevron-3', badgeColor: '#8B5CF6', perks: ['Extended history'] },
    { id: 'rank_journeyperson', tier: 5, name: 'journeyperson', displayName: 'Journeyperson', xpThreshold: 4000, badgeIcon: 'star-bronze', badgeColor: '#EAB308', perks: ['Create groups'] },
    { id: 'rank_expert', tier: 6, name: 'expert', displayName: 'Expert', xpThreshold: 10000, badgeIcon: 'star-silver', badgeColor: '#F97316', perks: ['Beta features'] },
    { id: 'rank_master', tier: 7, name: 'master', displayName: 'Master', xpThreshold: 25000, badgeIcon: 'star-gold', badgeColor: '#EF4444', perks: ['Mentor status'] },
    { id: 'rank_grandmaster', tier: 8, name: 'grandmaster', displayName: 'Grandmaster', xpThreshold: 60000, badgeIcon: 'shield-diamond', badgeColor: '#EC4899', perks: ['Elite status'] },
];
// Veteran tier thresholds (in months)
const VETERAN_TIERS = {
    0: { months: 0, label: null, icon: '', color: '' },
    1: { months: 6, label: '6 Months', icon: 'veteran-bronze', color: '#CD7F32' },
    2: { months: 12, label: '1 Year', icon: 'veteran-silver', color: '#C0C0C0' },
    3: { months: 24, label: '2+ Years', icon: 'veteran-gold', color: '#FFD700' },
};
// Cache for rank definitions
let rankDefinitionsCache = null;
let rankDefinitionsCacheTime = 0;
const CACHE_TTL = 60 * 1000; // 1 minute
exports.rankService = {
    /**
     * Get all rank definitions
     */
    async getRankDefinitions() {
        // Check cache
        if (rankDefinitionsCache && Date.now() - rankDefinitionsCacheTime < CACHE_TTL) {
            return rankDefinitionsCache;
        }
        try {
            const rows = await (0, client_1.queryAll)('SELECT * FROM rank_definitions ORDER BY tier ASC');
            if (rows.length === 0) {
                return DEFAULT_RANKS;
            }
            const ranks = rows.map((r) => ({
                id: r.id,
                tier: r.tier,
                name: r.name,
                displayName: r.display_name,
                xpThreshold: r.xp_threshold,
                badgeIcon: r.badge_icon,
                badgeColor: r.badge_color,
                perks: r.perks || [],
            }));
            // Update cache
            rankDefinitionsCache = ranks;
            rankDefinitionsCacheTime = Date.now();
            return ranks;
        }
        catch (error) {
            log.warn({ error }, 'Failed to fetch rank definitions, using defaults');
            return DEFAULT_RANKS;
        }
    },
    /**
     * Get rank definition by name
     */
    async getRankByName(name) {
        const ranks = await this.getRankDefinitions();
        return ranks.find((r) => r.name === name) || null;
    },
    /**
     * Get rank definition by tier
     */
    async getRankByTier(tier) {
        const ranks = await this.getRankDefinitions();
        return ranks.find((r) => r.tier === tier) || null;
    },
    /**
     * Get the rank for a given XP amount
     */
    async getRankForXp(totalXp) {
        const ranks = await this.getRankDefinitions();
        // Find the highest rank where XP meets or exceeds threshold
        let currentRank = ranks[0];
        for (const rank of ranks) {
            if (totalXp >= rank.xpThreshold) {
                currentRank = rank;
            }
            else {
                break;
            }
        }
        return currentRank;
    },
    /**
     * Get next rank after a given rank
     */
    async getNextRank(currentRankName) {
        const ranks = await this.getRankDefinitions();
        const currentIndex = ranks.findIndex((r) => r.name === currentRankName);
        if (currentIndex === -1 || currentIndex >= ranks.length - 1) {
            return null; // No next rank (already at max or not found)
        }
        return ranks[currentIndex + 1];
    },
    /**
     * Get complete rank info for a user
     */
    async getUserRankInfo(userId) {
        const user = await (0, client_1.queryOne)('SELECT total_xp, current_rank, rank_updated_at, veteran_tier, created_at FROM users WHERE id = $1', [userId]);
        if (!user) {
            return null;
        }
        const ranks = await this.getRankDefinitions();
        const currentRankDef = ranks.find((r) => r.name === user.current_rank) || ranks[0];
        const currentIndex = ranks.findIndex((r) => r.name === user.current_rank);
        const nextRank = currentIndex < ranks.length - 1 ? ranks[currentIndex + 1] : null;
        // Calculate progress to next rank
        let xpToNextRank = null;
        let progressPercent = 100;
        if (nextRank) {
            xpToNextRank = nextRank.xpThreshold - user.total_xp;
            const xpInCurrentTier = user.total_xp - currentRankDef.xpThreshold;
            const xpForTier = nextRank.xpThreshold - currentRankDef.xpThreshold;
            progressPercent = Math.min(100, Math.max(0, (xpInCurrentTier / xpForTier) * 100));
        }
        // Calculate veteran tier if not already set
        const veteranTier = user.veteran_tier || this.calculateVeteranTier(user.created_at);
        const veteranLabel = VETERAN_TIERS[veteranTier]?.label || null;
        return {
            userId,
            currentRank: user.current_rank,
            currentTier: currentRankDef.tier,
            totalXp: user.total_xp,
            xpToNextRank,
            progressPercent,
            nextRank,
            currentRankDef,
            rankUpdatedAt: user.rank_updated_at,
            veteranTier,
            veteranLabel,
        };
    },
    /**
     * Calculate veteran tier from account creation date
     */
    calculateVeteranTier(createdAt) {
        const now = new Date();
        const monthsActive = (now.getFullYear() - createdAt.getFullYear()) * 12 +
            (now.getMonth() - createdAt.getMonth());
        if (monthsActive >= 24)
            return 3;
        if (monthsActive >= 12)
            return 2;
        if (monthsActive >= 6)
            return 1;
        return 0;
    },
    /**
     * Get veteran badge info for a user
     */
    async getVeteranBadge(userId) {
        const user = await (0, client_1.queryOne)('SELECT veteran_tier, created_at FROM users WHERE id = $1', [userId]);
        if (!user)
            return null;
        const tier = user.veteran_tier || this.calculateVeteranTier(user.created_at);
        const tierInfo = VETERAN_TIERS[tier];
        const now = new Date();
        const monthsActive = (now.getFullYear() - user.created_at.getFullYear()) * 12 +
            (now.getMonth() - user.created_at.getMonth());
        return {
            tier: tier,
            label: tierInfo.label,
            icon: tierInfo.icon,
            color: tierInfo.color,
            monthsActive,
        };
    },
    /**
     * Update veteran tier for a user (called by nightly job)
     */
    async updateVeteranTier(userId) {
        const user = await (0, client_1.queryOne)('SELECT created_at, veteran_tier FROM users WHERE id = $1', [userId]);
        if (!user)
            return 0;
        const newTier = this.calculateVeteranTier(user.created_at);
        if (newTier !== user.veteran_tier) {
            await (0, client_1.query)('UPDATE users SET veteran_tier = $1 WHERE id = $2', [newTier, userId]);
            log.info({ userId, previousTier: user.veteran_tier, newTier }, 'Veteran tier updated');
        }
        return newTier;
    },
    /**
     * Update veteran tiers for all users (batch operation)
     */
    async updateAllVeteranTiers() {
        const result = await (0, client_1.query)(`
      UPDATE users
      SET veteran_tier = CASE
        WHEN created_at <= NOW() - INTERVAL '24 months' THEN 3
        WHEN created_at <= NOW() - INTERVAL '12 months' THEN 2
        WHEN created_at <= NOW() - INTERVAL '6 months' THEN 1
        ELSE 0
      END
      WHERE veteran_tier IS DISTINCT FROM CASE
        WHEN created_at <= NOW() - INTERVAL '24 months' THEN 3
        WHEN created_at <= NOW() - INTERVAL '12 months' THEN 2
        WHEN created_at <= NOW() - INTERVAL '6 months' THEN 1
        ELSE 0
      END
    `);
        const updated = result.rowCount || 0;
        log.info({ updated }, 'Batch veteran tier update complete');
        return { updated };
    },
    /**
     * Refresh the XP rankings materialized view
     */
    async refreshRankings() {
        try {
            await (0, client_1.query)('REFRESH MATERIALIZED VIEW CONCURRENTLY mv_xp_rankings');
            log.info('XP rankings materialized view refreshed');
        }
        catch (error) {
            // If concurrent refresh fails, try non-concurrent
            if (error.message?.includes('CONCURRENTLY')) {
                await (0, client_1.query)('REFRESH MATERIALIZED VIEW mv_xp_rankings');
                log.info('XP rankings materialized view refreshed (non-concurrent)');
            }
            else {
                throw error;
            }
        }
    },
    /**
     * Get XP leaderboard from materialized view
     */
    async getXpLeaderboard(options = {}) {
        const { limit = 50, offset = 0, country, state, city } = options;
        let whereClause = '1=1';
        const params = [];
        let paramIndex = 1;
        if (country) {
            whereClause += ` AND country = $${paramIndex++}`;
            params.push(country);
        }
        if (state) {
            whereClause += ` AND state = $${paramIndex++}`;
            params.push(state);
        }
        if (city) {
            whereClause += ` AND city = $${paramIndex++}`;
            params.push(city);
        }
        params.push(limit, offset);
        const rows = await (0, client_1.queryAll)(`SELECT user_id, username, display_name, avatar_url, total_xp, current_rank, veteran_tier, country, global_xp_rank
       FROM mv_xp_rankings
       WHERE ${whereClause}
       ORDER BY global_xp_rank ASC
       LIMIT $${paramIndex++} OFFSET $${paramIndex++}`, params);
        const countResult = await (0, client_1.queryOne)(`SELECT COUNT(*) as count FROM mv_xp_rankings WHERE ${whereClause}`, params.slice(0, -2));
        return {
            entries: rows.map((r) => ({
                rank: r.global_xp_rank,
                userId: r.user_id,
                username: r.username,
                displayName: r.display_name || undefined,
                avatarUrl: r.avatar_url || undefined,
                totalXp: r.total_xp,
                currentRank: r.current_rank,
                veteranTier: r.veteran_tier,
                country: r.country || undefined,
            })),
            total: parseInt(countResult?.count || '0'),
        };
    },
};
var xp_service_1 = require("./xp.service");
Object.defineProperty(exports, "xpService", { enumerable: true, get: function () { return xp_service_1.xpService; } });
exports.default = exports.rankService;
//# sourceMappingURL=index.js.map