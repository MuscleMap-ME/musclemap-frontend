/**
 * Marketplace Service
 *
 * Handles marketplace listings, offers, watchlist, and transactions.
 * Uses raw pg queries for all database operations.
 */
export interface CreateListingInput {
    sellerId: string;
    cosmeticId: string;
    userCosmeticId: string;
    listingType: 'buy_now' | 'auction' | 'offer_only' | 'reserved';
    price?: number;
    minOffer?: number;
    reservePrice?: number;
    buyNowPrice?: number;
    bidIncrement?: number;
    durationHours?: number;
    allowOffers?: boolean;
    reservedForUserId?: string;
    sellerNote?: string;
}
export interface ListingFilters {
    category?: string;
    rarity?: string;
    minPrice?: number;
    maxPrice?: number;
    listingType?: 'buy_now' | 'auction' | 'offer_only';
    sellerId?: string;
    search?: string;
    sortBy?: 'price_asc' | 'price_desc' | 'newest' | 'ending_soon' | 'popular';
    cursor?: string;
    limit?: number;
}
export interface MakeOfferInput {
    listingId: string;
    offererId: string;
    amount: number;
    message?: string;
}
export declare const marketplaceService: {
    createListing(input: CreateListingInput): Promise<{
        id: string;
        seller_id: string;
        cosmetic_id: string;
        user_cosmetic_id: string;
        listing_type: string;
        price: number;
        min_offer: number;
        reserve_price: number;
        buy_now_price: number;
        current_bid: number;
        bid_count: number;
        allow_offers: boolean;
        seller_note: string;
        status: string;
        expires_at: string;
        created_at: string;
        cosmetic_name: string;
        cosmetic_description: string;
        cosmetic_icon: string;
        rarity: string;
        category: string;
        seller_username: string;
        view_count: number;
    } | undefined>;
    getListing(listingId: string): Promise<{
        id: string;
        seller_id: string;
        cosmetic_id: string;
        user_cosmetic_id: string;
        listing_type: string;
        price: number;
        min_offer: number;
        reserve_price: number;
        buy_now_price: number;
        current_bid: number;
        bid_count: number;
        allow_offers: boolean;
        seller_note: string;
        status: string;
        expires_at: string;
        created_at: string;
        cosmetic_name: string;
        cosmetic_description: string;
        cosmetic_icon: string;
        rarity: string;
        category: string;
        seller_username: string;
        view_count: number;
    } | undefined>;
    browseListings(filters: ListingFilters): Promise<{
        listings: {
            id: string;
            seller_id: string;
            listing_type: string;
            price: number;
            current_bid: number;
            bid_count: number;
            expires_at: string;
            created_at: string;
            cosmetic_name: string;
            cosmetic_icon: string;
            rarity: string;
            category: string;
            seller_username: string;
        }[];
        nextCursor: string | null;
        hasMore: boolean;
    }>;
    updateListing(listingId: string, sellerId: string, updates: {
        price?: number;
        sellerNote?: string;
        allowOffers?: boolean;
    }): Promise<{
        id: string;
        seller_id: string;
        cosmetic_id: string;
        user_cosmetic_id: string;
        listing_type: string;
        price: number;
        min_offer: number;
        reserve_price: number;
        buy_now_price: number;
        current_bid: number;
        bid_count: number;
        allow_offers: boolean;
        seller_note: string;
        status: string;
        expires_at: string;
        created_at: string;
        cosmetic_name: string;
        cosmetic_description: string;
        cosmetic_icon: string;
        rarity: string;
        category: string;
        seller_username: string;
        view_count: number;
    } | undefined>;
    cancelListing(listingId: string, sellerId: string): Promise<void>;
    buyNow(listingId: string, buyerId: string): Promise<{
        success: boolean;
        price: any;
        platformFee: number;
        sellerProceeds: number;
    }>;
    makeOffer(input: MakeOfferInput): Promise<Record<string, unknown> | undefined>;
    respondToOffer(offerId: string, sellerId: string, action: "accept" | "decline" | "counter", counterAmount?: number, counterMessage?: string): Promise<{
        success: boolean;
        action: string;
        price: number;
    } | {
        success: boolean;
        action: string;
        counterOfferId?: undefined;
    } | {
        success: boolean;
        action: string;
        counterOfferId: string;
    }>;
    getListingOffers(listingId: string, sellerId: string): Promise<Record<string, unknown>[]>;
    getUserOffers(userId: string): Promise<Record<string, unknown>[]>;
    withdrawOffer(offerId: string, offererId: string): Promise<void>;
    getUserWatchlist(userId: string): Promise<Record<string, unknown>[]>;
    addToWatchlist(userId: string, listingId: string, priceAlert?: number): Promise<void>;
    removeFromWatchlist(userId: string, listingId: string): Promise<void>;
    getUserStats(userId: string): Promise<{
        totalSales: number;
        totalPurchases: number;
        totalRevenue: number;
        avgRating: number;
        sellerLevel: number;
        feeDiscount: number;
    }>;
    getSellerLevel(userId: string): Promise<number>;
    getPriceHistory(cosmeticId: string, period?: "7d" | "30d" | "90d" | "all"): Promise<Record<string, unknown>[]>;
    getPriceSuggestion(cosmeticId: string): Promise<{
        suggestedPrice: number;
        minRecentPrice: number;
        maxRecentPrice: number;
        recentSales: number;
    }>;
    getMarketOverview(): Promise<{
        totalActiveListings: number;
        volume24h: number;
        sales24h: number;
        trending: {
            cosmetic_id: string;
            name: string;
            icon: string;
            sales: string;
        }[];
    }>;
    placeBid(listingId: string, bidderId: string, amount: number): Promise<{
        success: boolean;
        bidId: string;
        amount: number;
        previousBid: any;
        outbidUserId: any;
        isReserveMet: boolean;
    }>;
    getListingBids(listingId: string): Promise<{
        id: string;
        bidder_id: string;
        bid_amount: number;
        status: string;
        created_at: string;
        bidder_username: string;
    }[]>;
    getUserBids(userId: string): Promise<{
        id: string;
        listing_id: string;
        bid_amount: number;
        status: string;
        created_at: string;
        cosmetic_name: string;
        cosmetic_icon: string;
        rarity: string;
        listing_status: string;
        current_bid: number;
        auction_end_time: string;
    }[]>;
    processEndedAuctions(): Promise<number>;
};
