import { PoolClient } from 'pg';
export interface CreateTradeInput {
    initiatorId: string;
    receiverId: string;
    initiatorItems?: string[];
    initiatorCredits?: number;
    receiverItems?: string[];
    receiverCredits?: number;
    message?: string;
}
export interface CounterTradeInput {
    initiatorItems?: string[];
    initiatorCredits?: number;
    receiverItems?: string[];
    receiverCredits?: number;
    message?: string;
}
interface TradeRequest {
    id: string;
    initiator_id: string;
    receiver_id: string;
    initiator_items: string[];
    initiator_credits: number;
    receiver_items: string[];
    receiver_credits: number;
    initiator_estimated_value: number;
    receiver_estimated_value: number;
    status: string;
    message: string | null;
    counter_count: number;
    expires_at: Date;
    created_at: Date;
    updated_at: Date;
    completed_at: Date | null;
}
interface UserBasic {
    id: string;
    username: string;
    avatar_url: string | null;
}
export declare const tradingService: {
    createTradeRequest(input: CreateTradeInput): Promise<{
        trade: {
            initiator: UserBasic | undefined;
            receiver: UserBasic | undefined;
            initiatorItemDetails: Record<string, unknown>[];
            receiverItemDetails: Record<string, unknown>[];
            id: string;
            initiator_id: string;
            receiver_id: string;
            initiator_items: string[];
            initiator_credits: number;
            receiver_items: string[];
            receiver_credits: number;
            initiator_estimated_value: number;
            receiver_estimated_value: number;
            status: string;
            message: string | null;
            counter_count: number;
            expires_at: Date;
            created_at: Date;
            updated_at: Date;
            completed_at: Date | null;
        };
        valueWarning: string | null;
    }>;
    getTradeRequest(tradeId: string, userId: string): Promise<{
        initiator: UserBasic | undefined;
        receiver: UserBasic | undefined;
        initiatorItemDetails: Record<string, unknown>[];
        receiverItemDetails: Record<string, unknown>[];
        id: string;
        initiator_id: string;
        receiver_id: string;
        initiator_items: string[];
        initiator_credits: number;
        receiver_items: string[];
        receiver_credits: number;
        initiator_estimated_value: number;
        receiver_estimated_value: number;
        status: string;
        message: string | null;
        counter_count: number;
        expires_at: Date;
        created_at: Date;
        updated_at: Date;
        completed_at: Date | null;
    } | null>;
    getIncomingTrades(userId: string): Promise<{
        initiator: UserBasic | undefined;
        receiver: UserBasic | undefined;
        initiatorItemDetails: Record<string, unknown>[];
        receiverItemDetails: Record<string, unknown>[];
        id: string;
        initiator_id: string;
        receiver_id: string;
        initiator_items: string[];
        initiator_credits: number;
        receiver_items: string[];
        receiver_credits: number;
        initiator_estimated_value: number;
        receiver_estimated_value: number;
        status: string;
        message: string | null;
        counter_count: number;
        expires_at: Date;
        created_at: Date;
        updated_at: Date;
        completed_at: Date | null;
    }[]>;
    getOutgoingTrades(userId: string): Promise<{
        initiator: UserBasic | undefined;
        receiver: UserBasic | undefined;
        initiatorItemDetails: Record<string, unknown>[];
        receiverItemDetails: Record<string, unknown>[];
        id: string;
        initiator_id: string;
        receiver_id: string;
        initiator_items: string[];
        initiator_credits: number;
        receiver_items: string[];
        receiver_credits: number;
        initiator_estimated_value: number;
        receiver_estimated_value: number;
        status: string;
        message: string | null;
        counter_count: number;
        expires_at: Date;
        created_at: Date;
        updated_at: Date;
        completed_at: Date | null;
    }[]>;
    getTradeHistory(userId: string, limit?: number): Promise<Record<string, unknown>[]>;
    acceptTrade(tradeId: string, receiverId: string): Promise<{
        success: boolean;
        trade: {
            status: string;
            id: string;
            initiator_id: string;
            receiver_id: string;
            initiator_items: string[];
            initiator_credits: number;
            receiver_items: string[];
            receiver_credits: number;
            initiator_estimated_value: number;
            receiver_estimated_value: number;
            message: string | null;
            counter_count: number;
            expires_at: Date;
            created_at: Date;
            updated_at: Date;
            completed_at: Date | null;
        };
    }>;
    declineTrade(tradeId: string, receiverId: string): Promise<{
        success: boolean;
    }>;
    counterTrade(tradeId: string, receiverId: string, counter: CounterTradeInput): Promise<{
        trade: {
            initiator: UserBasic | undefined;
            receiver: UserBasic | undefined;
            initiatorItemDetails: Record<string, unknown>[];
            receiverItemDetails: Record<string, unknown>[];
            id: string;
            initiator_id: string;
            receiver_id: string;
            initiator_items: string[];
            initiator_credits: number;
            receiver_items: string[];
            receiver_credits: number;
            initiator_estimated_value: number;
            receiver_estimated_value: number;
            status: string;
            message: string | null;
            counter_count: number;
            expires_at: Date;
            created_at: Date;
            updated_at: Date;
            completed_at: Date | null;
        };
    }>;
    cancelTrade(tradeId: string, initiatorId: string): Promise<{
        success: boolean;
    }>;
    calculateTradeValue(itemIds: string[], credits: number): Promise<number>;
    estimateTradeValue(itemIds: string[]): Promise<{
        itemValues: {
            itemId: string;
            name: string;
            estimatedValue: number;
        }[];
        totalValue: number;
    }>;
    enrichTrade(trade: TradeRequest): Promise<{
        initiator: UserBasic | undefined;
        receiver: UserBasic | undefined;
        initiatorItemDetails: Record<string, unknown>[];
        receiverItemDetails: Record<string, unknown>[];
        id: string;
        initiator_id: string;
        receiver_id: string;
        initiator_items: string[];
        initiator_credits: number;
        receiver_items: string[];
        receiver_credits: number;
        initiator_estimated_value: number;
        receiver_estimated_value: number;
        status: string;
        message: string | null;
        counter_count: number;
        expires_at: Date;
        created_at: Date;
        updated_at: Date;
        completed_at: Date | null;
    }>;
    updateTradeStatsWithClient(client: PoolClient, userId: string, valueExchanged: number): Promise<void>;
    expireOldTrades(): Promise<number>;
};
export {};
