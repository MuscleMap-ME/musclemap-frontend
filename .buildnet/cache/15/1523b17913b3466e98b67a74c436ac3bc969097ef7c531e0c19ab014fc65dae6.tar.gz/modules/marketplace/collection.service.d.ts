export interface CollectionStats {
    totalOwned: number;
    totalValue: number;
    rarityBreakdown: {
        rarity: string;
        count: number;
    }[];
    categoryBreakdown: {
        category: string;
        count: number;
    }[];
    recentAcquisitions: Record<string, unknown>[];
}
export interface SetReward {
    threshold: number;
    reward: {
        type: 'credits' | 'cosmetic' | 'title' | 'badge' | 'xp';
        value: string | number;
    };
}
interface CollectionSet {
    id: string;
    name: string;
    description: string | null;
    theme: string | null;
    items: string[];
    rewards: SetReward[];
    is_limited: boolean;
    expiration_date: Date | null;
    created_at: Date;
}
export declare const collectionService: {
    getUserCollectionStats(userId: string): Promise<CollectionStats>;
    getUserCollection(userId: string, filters?: {
        category?: string;
        rarity?: string;
        sortBy?: "acquired" | "name" | "rarity" | "value";
        limit?: number;
        offset?: number;
    }): Promise<{
        items: Record<string, unknown>[];
        total: number;
        hasMore: boolean;
    }>;
    getCollectionSets(): Promise<CollectionSet[]>;
    getSetWithProgress(setId: string, userId: string): Promise<{
        set: CollectionSet;
        progress: {
            ownedCount: number;
            totalCount: number;
            completionPercent: number;
            rewardsClaimed: number[];
        };
        items: Record<string, unknown>[];
        claimableRewards: SetReward[];
    } | null>;
    getUserSetsProgress(userId: string): Promise<{
        id: string;
        name: string;
        theme: string | null;
        isLimited: boolean;
        expirationDate: Date | null;
        progress: {
            ownedCount: number;
            totalCount: number;
            completionPercent: number;
            rewardsClaimed: number[];
        } | undefined;
        claimableRewardsCount: number;
    }[]>;
    claimSetReward(userId: string, setId: string, threshold: number): Promise<{
        success: boolean;
        reward: SetReward;
    }>;
    getUserShowcase(userId: string): Promise<{
        loadout: Record<string, unknown> | undefined;
        featuredItems: Record<string, unknown>[];
        stats: CollectionStats;
    }>;
    updateShowcase(userId: string, featuredItemIds: string[], _layout?: string, _showcaseEffect?: string): Promise<{
        success: boolean;
    }>;
    checkAndAwardMilestones(userId: string): Promise<string[]>;
    getUserDuplicates(_userId: string): Promise<never[]>;
    toggleFavorite(userId: string, userCosmeticId: string): Promise<{
        isFavorite: boolean;
    }>;
    getUserFavorites(userId: string): Promise<Record<string, unknown>[]>;
    markItemAsSeen(userId: string, userCosmeticId: string): Promise<{
        success: boolean;
    }>;
    markAllAsSeen(userId: string): Promise<{
        success: boolean;
    }>;
    getNewItemsCount(userId: string): Promise<number>;
};
export {};
