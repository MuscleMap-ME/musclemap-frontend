/**
 * Health Multiplier Service
 *
 * Calculates and applies earning multipliers based on healthy behaviors:
 * - Workout streaks
 * - Sleep quality
 * - Nutrition goals
 * - Recovery metrics
 *
 * These multipliers incentivize users to maintain consistent healthy habits
 * by boosting their credit earnings from various activities.
 */
export interface HealthMultiplier {
    userId: string;
    baseMultiplier: number;
    workoutBonus: number;
    sleepBonus: number;
    nutritionBonus: number;
    streakBonus: number;
    totalMultiplier: number;
    tier: 'bronze' | 'silver' | 'gold' | 'platinum' | 'diamond';
    validUntil: Date;
}
export interface DailyHealthMetrics {
    userId: string;
    date: string;
    workoutCompleted?: boolean;
    workoutIntensity?: 'low' | 'medium' | 'high';
    sleepHours?: number;
    sleepQuality?: number;
    nutritionScore?: number;
    hydrationLiters?: number;
    stepsCount?: number;
    activeMinutes?: number;
}
export interface HealthTierInfo {
    tier: 'bronze' | 'silver' | 'gold' | 'platinum' | 'diamond';
    multiplier: number;
    streakDays: number;
    nextTier?: string;
    daysToNextTier?: number;
}
declare class HealthMultiplierService {
    /**
     * Log daily health metrics for a user
     */
    logDailyMetrics(userId: string, metrics: Omit<DailyHealthMetrics, 'userId' | 'date'>): Promise<DailyHealthMetrics>;
    /**
     * Get today's health metrics for a user
     */
    getTodayMetrics(userId: string): Promise<DailyHealthMetrics | null>;
    /**
     * Get health metrics history for a user
     */
    getMetricsHistory(userId: string, days?: number): Promise<DailyHealthMetrics[]>;
    /**
     * Calculate current workout streak
     */
    calculateWorkoutStreak(userId: string): Promise<number>;
    /**
     * Get the health tier based on streak
     */
    getStreakTier(streakDays: number): HealthTierInfo;
    /**
     * Update user's health tier in the database
     */
    updateUserHealthTier(userId: string): Promise<void>;
    /**
     * Calculate full multiplier including all bonuses
     */
    calculateFullMultiplier(userId: string): Promise<HealthMultiplier>;
    /**
     * Get user's current multiplier (cached version from database)
     */
    getUserMultiplier(userId: string): Promise<HealthMultiplier | null>;
    /**
     * Apply multiplier to a credit amount
     */
    applyMultiplier(userId: string, baseAmount: number): Promise<{
        baseAmount: number;
        multiplier: number;
        bonusAmount: number;
        totalAmount: number;
    }>;
    /**
     * Get health stats summary for a user
     */
    getHealthStatsSummary(userId: string): Promise<{
        currentStreak: number;
        longestStreak: number;
        totalWorkouts: number;
        avgSleepHours: number;
        avgNutritionScore: number;
        currentTier: HealthTierInfo;
        weeklyProgress: {
            workoutsCompleted: number;
            workoutsGoal: number;
            sleepGoalMet: number;
            nutritionGoalMet: number;
        };
    }>;
    /**
     * Get leaderboard by streak
     */
    getStreakLeaderboard(limit?: number): Promise<Array<{
        userId: string;
        username: string;
        streakDays: number;
        tier: string;
        multiplier: number;
    }>>;
    /**
     * Automatically log workout completion (called by workout service)
     */
    onWorkoutCompleted(userId: string, intensity: 'low' | 'medium' | 'high'): Promise<void>;
    /**
     * Sync sleep data from wearables (called by wearables module)
     */
    onSleepDataReceived(userId: string, sleepHours: number, sleepQuality: number): Promise<void>;
    /**
     * Update nutrition score (called by nutrition module)
     */
    onNutritionScoreUpdated(userId: string, nutritionScore: number): Promise<void>;
}
export declare const healthMultiplierService: HealthMultiplierService;
export {};
