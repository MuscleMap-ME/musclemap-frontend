/**
 * Gift Service
 *
 * Handles gifting of cosmetics, credits, and mystery boxes between users.
 * Supports scheduled delivery, anonymous gifting, and various wrapping styles.
 */
import { PoolClient } from 'pg';
export interface CreateGiftInput {
    senderId: string;
    recipientId: string;
    cosmeticId?: string;
    creditAmount?: number;
    mysteryBoxId?: string;
    wrappingStyle?: 'standard' | 'birthday' | 'holiday' | 'congrats' | 'custom';
    message?: string;
    isAnonymous?: boolean;
    scheduledDelivery?: Date;
}
interface Gift {
    id: string;
    sender_id: string | null;
    recipient_id: string;
    cosmetic_id: string | null;
    credit_amount: number | null;
    mystery_box_id: string | null;
    wrapping_style: string;
    message: string | null;
    is_anonymous: boolean;
    scheduled_delivery: Date | null;
    status: string;
    delivered_at: Date | null;
    opened_at: Date | null;
    created_at: Date;
}
export declare const giftService: {
    createGift(input: CreateGiftInput): Promise<Gift>;
    deliverGiftWithClient(client: PoolClient, giftId: string, userCosmeticId?: string): Promise<void>;
    getReceivedGifts(userId: string, status?: "pending" | "delivered" | "opened"): Promise<Record<string, unknown>[]>;
    getSentGifts(userId: string, limit?: number): Promise<Record<string, unknown>[]>;
    getGiftDetails(giftId: string, userId: string): Promise<Record<string, unknown> | undefined>;
    openGift(giftId: string, userId: string): Promise<{
        justOpened: boolean;
    }>;
    returnGift(giftId: string, userId: string): Promise<{
        success: boolean;
    }>;
    deliverScheduledGifts(): Promise<number>;
    getUserGiftStats(userId: string): Promise<{
        giftsSent: number;
        giftsReceived: number;
        totalCreditsGifted: number;
        totalCreditsReceived: number;
    }>;
    getUnopenedGiftCount(userId: string): Promise<number>;
};
export {};
