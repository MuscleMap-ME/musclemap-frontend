import { PoolClient } from 'pg';
export interface DropRates {
    common?: number;
    uncommon?: number;
    rare?: number;
    epic?: number;
    legendary?: number;
    mythic?: number;
    divine?: number;
}
export interface BoxOpeningResult {
    cosmetic: Record<string, unknown>;
    rarity: string;
    wasPityReward: boolean;
    pityCounters: {
        epic: number;
        legendary: number;
    };
}
interface MysteryBox {
    id: string;
    name: string;
    description: string | null;
    box_type: string;
    price: number;
    drop_rates: DropRates;
    item_pool: Array<{
        id: string;
        rarity: string;
    }> | string[];
    available_from: Date | null;
    available_until: Date | null;
    max_purchases_per_day: number | null;
    created_at: Date;
}
export declare const mysteryBoxService: {
    getAvailableBoxes(): Promise<MysteryBox[]>;
    getBoxDetails(boxId: string): Promise<{
        box: MysteryBox;
        recentDrops: {
            rarity_received: string;
            opened_at: Date;
            name: string;
            preview_url: string | null;
            username: string;
        }[];
        dropStats: {
            rarity_received: string;
            count: string;
        }[];
    } | null>;
    openBox(userId: string, boxId: string, quantity?: number): Promise<BoxOpeningResult[]>;
    rollRarity(dropRates: DropRates, epicCounter: number, legendaryCounter: number): {
        rarity: string;
        wasPityReward: boolean;
        newCounters: {
            epic: number;
            legendary: number;
        };
    };
    getUserPityCounters(userId: string): Promise<{
        boxType: string;
        epicCounter: number;
        legendaryCounter: number;
        epicThreshold: number;
        legendaryThreshold: number;
        lastEpicAt: Date | null;
        lastLegendaryAt: Date | null;
    }[]>;
    getUserOpeningHistory(userId: string, limit?: number): Promise<Record<string, unknown>[]>;
    awardCosmeticWithClient(client: PoolClient, userId: string, cosmeticId: string, creditsSpent: number, boxId: string, rarityReceived: string, wasPityReward: boolean, pityCounter: number): Promise<{
        duplicate: boolean;
        refundAmount: number;
    } | {
        duplicate: boolean;
        refundAmount?: undefined;
    }>;
    getBoxStatistics(boxId: string): Promise<{
        totalOpenings: number;
        rarityDistribution: {
            rarity_received: string;
            count: string;
        }[];
        pityTriggerRate: number;
    }>;
};
export {};
