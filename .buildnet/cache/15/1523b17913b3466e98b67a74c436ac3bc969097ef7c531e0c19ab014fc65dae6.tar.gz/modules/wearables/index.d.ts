/**
 * Wearables Router
 *
 * REST API endpoints for wearable device integrations.
 * Supports Apple Health, Google Fit (Health Connect), Fitbit, Garmin, Whoop, and Oura.
 */
import type { FastifyInstance } from 'fastify';
export declare function registerWearablesRoutes(fastify: FastifyInstance): void;
export * from './types';
export * from './service';
