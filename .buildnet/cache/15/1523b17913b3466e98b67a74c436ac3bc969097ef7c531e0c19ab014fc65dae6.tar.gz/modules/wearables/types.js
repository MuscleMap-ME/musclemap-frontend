"use strict";
/**
 * Wearables Types
 *
 * Type definitions for wearable device integrations (Apple Watch, Fitbit, etc.)
 */
Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=types.js.map