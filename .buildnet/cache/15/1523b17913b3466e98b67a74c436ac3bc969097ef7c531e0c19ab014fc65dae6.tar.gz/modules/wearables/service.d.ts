import type { WearableConnection, WearableProvider, HealthSyncPayload, HealthSummary, WorkoutSample, HealthSyncResult, HealthSyncStatus, SyncOptions } from './types';
/**
 * Get user's wearable connections
 */
export declare function getConnections(userId: string): Promise<WearableConnection[]>;
/**
 * Create or update a wearable connection
 */
export declare function upsertConnection(userId: string, provider: WearableProvider, data: {
    providerUserId?: string;
    accessToken?: string;
    refreshToken?: string;
    tokenExpiresAt?: string;
}): Promise<WearableConnection>;
/**
 * Disconnect a wearable provider
 */
export declare function disconnectProvider(userId: string, provider: WearableProvider): Promise<void>;
/**
 * Get sync status for all providers
 */
export declare function getSyncStatus(userId: string): Promise<HealthSyncStatus[]>;
/**
 * Get sync status for a specific provider
 */
export declare function getProviderSyncStatus(userId: string, provider: WearableProvider): Promise<HealthSyncStatus | null>;
/**
 * Update sync status (for showing sync in progress)
 */
export declare function updateSyncStatus(userId: string, provider: WearableProvider, status: 'syncing' | 'success' | 'error', error?: string): Promise<void>;
/**
 * Sync health data from a wearable with conflict resolution
 */
export declare function syncHealthData(userId: string, provider: WearableProvider, payload: HealthSyncPayload, options?: SyncOptions): Promise<HealthSyncResult>;
/**
 * Get workouts from MuscleMap to push to wearable
 */
export declare function getWorkoutsForExport(userId: string, options?: {
    startDate?: string;
    endDate?: string;
    limit?: number;
}): Promise<WorkoutSample[]>;
/**
 * Get health summary for a user
 */
export declare function getHealthSummary(userId: string): Promise<HealthSummary>;
/**
 * Get recent workouts from wearables
 */
export declare function getRecentWearableWorkouts(userId: string, limit?: number): Promise<WorkoutSample[]>;
