/**
 * Slack Notification Service
 *
 * Comprehensive Slack integration for MuscleMap Empire notifications.
 * Sends real-time updates about:
 * - System health (CPU, memory, errors)
 * - Deployments
 * - New users
 * - Achievements & milestones
 * - Bug reports & feedback
 * - Daily/weekly digests
 * - Economy events
 * - Community activity
 */
export type SlackNotificationType = 'system_alert' | 'deployment' | 'new_user' | 'achievement' | 'milestone' | 'bug_report' | 'feedback' | 'error' | 'daily_digest' | 'weekly_digest' | 'economy_event' | 'community_activity' | 'message' | 'security';
interface SlackConfig {
    webhook_url: string;
    enabled_notifications: SlackNotificationType[];
    quiet_hours?: {
        start: number;
        end: number;
    };
    digest_time?: string;
    mention_on_critical?: boolean;
    user_id_to_mention?: string;
}
/**
 * Get Slack configuration from database or environment
 */
declare function getSlackConfig(): Promise<SlackConfig | null>;
/**
 * Save Slack configuration to database
 */
export declare function saveSlackConfig(config: SlackConfig): Promise<boolean>;
/**
 * System Alert - CPU, memory, error rate thresholds
 */
export declare function notifySystemAlert(alert: {
    metric: string;
    value: number;
    threshold: number;
    severity: 'warning' | 'critical';
}): Promise<boolean>;
/**
 * Deployment Notification
 */
export declare function notifyDeployment(deployment: {
    status: 'started' | 'completed' | 'failed';
    commit?: string;
    branch?: string;
    duration?: number;
    error?: string;
}): Promise<boolean>;
/**
 * New User Signup
 */
export declare function notifyNewUser(user: {
    id: string;
    username: string;
    email?: string;
    archetype?: string;
    referrer?: string;
}): Promise<boolean>;
/**
 * Achievement/Milestone Notification
 */
export declare function notifyAchievement(achievement: {
    userId: string;
    username: string;
    type: 'achievement' | 'level_up' | 'wealth_tier' | 'streak' | 'pr';
    name: string;
    description?: string;
    value?: number;
}): Promise<boolean>;
/**
 * Bug Report Notification
 */
export declare function notifyBugReport(bug: {
    id: string;
    title: string;
    description: string;
    severity: 'low' | 'medium' | 'high' | 'critical';
    reporter?: string;
    url?: string;
    userAgent?: string;
}): Promise<boolean>;
/**
 * Feedback Notification
 */
export declare function notifyFeedback(feedback: {
    id: string;
    type: 'feedback' | 'feature_request' | 'question' | 'praise';
    title: string;
    message: string;
    user?: string;
    email?: string;
    rating?: number;
}): Promise<boolean>;
/**
 * Error Notification (for uncaught errors)
 */
export declare function notifyError(error: {
    message: string;
    stack?: string;
    endpoint?: string;
    userId?: string;
    count?: number;
}): Promise<boolean>;
/**
 * Security Alert
 */
export declare function notifySecurityAlert(alert: {
    type: 'failed_login' | 'suspicious_activity' | 'rate_limit' | 'blocked_ip';
    ip?: string;
    userId?: string;
    details: string;
}): Promise<boolean>;
/**
 * Economy Event (large transactions, tier changes)
 */
export declare function notifyEconomyEvent(event: {
    type: 'large_transaction' | 'tier_change' | 'marketplace_sale';
    userId: string;
    username: string;
    amount?: number;
    oldTier?: string;
    newTier?: string;
    item?: string;
}): Promise<boolean>;
/**
 * Daily Digest - comprehensive daily summary
 */
export declare function sendDailyDigest(): Promise<boolean>;
/**
 * Weekly Digest - comprehensive weekly summary
 */
export declare function sendWeeklyDigest(): Promise<boolean>;
/**
 * Community Activity (crew events, competitions)
 */
export declare function notifyCommunityActivity(activity: {
    type: 'crew_created' | 'competition_started' | 'competition_ended' | 'milestone';
    name: string;
    details: string;
    participants?: number;
    winner?: string;
}): Promise<boolean>;
/**
 * Direct Message to Owner (for important communications)
 */
export declare function notifyDirectMessage(message: {
    from: string;
    subject: string;
    preview: string;
    messageId?: string;
}): Promise<boolean>;
/**
 * Test the Slack connection
 */
export declare function testSlackConnection(webhookUrl?: string): Promise<{
    success: boolean;
    error?: string;
}>;
export declare const SlackNotifications: {
    getConfig: typeof getSlackConfig;
    saveConfig: typeof saveSlackConfig;
    testConnection: typeof testSlackConnection;
    systemAlert: typeof notifySystemAlert;
    deployment: typeof notifyDeployment;
    newUser: typeof notifyNewUser;
    achievement: typeof notifyAchievement;
    bugReport: typeof notifyBugReport;
    feedback: typeof notifyFeedback;
    error: typeof notifyError;
    security: typeof notifySecurityAlert;
    economy: typeof notifyEconomyEvent;
    community: typeof notifyCommunityActivity;
    message: typeof notifyDirectMessage;
    dailyDigest: typeof sendDailyDigest;
    weeklyDigest: typeof sendWeeklyDigest;
};
export default SlackNotifications;
