/**
 * Skills Module
 *
 * Handles gymnastics/calisthenics skill progression tracking:
 * - Skill trees (handstands, planche, levers, etc.)
 * - Skill nodes with prerequisites and criteria
 * - User progress tracking and achievement
 * - Practice logging
 */
export interface SkillTree {
    id: string;
    name: string;
    description?: string;
    category: string;
    icon?: string;
    color?: string;
    orderIndex: number;
}
export interface SkillNode {
    id: string;
    treeId: string;
    name: string;
    description?: string;
    difficulty: number;
    prerequisites: string[];
    criteriaType: 'hold' | 'reps' | 'time' | 'form_check';
    criteriaValue?: number;
    criteriaDescription?: string;
    xpReward: number;
    creditReward: number;
    achievementId?: string;
    videoUrl?: string;
    thumbnailUrl?: string;
    tips: string[];
    commonMistakes: string[];
    tier: number;
    position: number;
}
export interface UserSkillProgress {
    id: string;
    userId: string;
    skillNodeId: string;
    status: 'locked' | 'available' | 'in_progress' | 'achieved';
    bestValue?: number;
    attemptCount: number;
    practiceMinutes: number;
    achievedAt?: Date;
    verified: boolean;
    verificationVideoUrl?: string;
    notes?: string;
    createdAt: Date;
    updatedAt: Date;
}
export interface SkillPracticeLog {
    id: string;
    userId: string;
    skillNodeId: string;
    practiceDate: Date;
    durationMinutes: number;
    valueAchieved?: number;
    notes?: string;
    createdAt: Date;
}
export interface SkillTreeWithNodes extends SkillTree {
    nodes: SkillNode[];
}
export interface SkillNodeWithProgress extends SkillNode {
    progress?: UserSkillProgress;
}
export declare const skillService: {
    /**
     * Get all skill trees (cached)
     */
    getSkillTrees(): Promise<SkillTree[]>;
    /**
     * Get a skill tree by ID with all its nodes (cached)
     */
    getSkillTree(treeId: string): Promise<SkillTreeWithNodes | null>;
    /**
     * Get a specific skill node
     */
    getSkillNode(nodeId: string): Promise<SkillNode | null>;
    /**
     * Get user progress for a skill tree
     */
    getUserTreeProgress(userId: string, treeId: string): Promise<SkillNodeWithProgress[]>;
    /**
     * Get user's overall skill progress summary
     */
    getUserSkillSummary(userId: string): Promise<{
        totalSkills: number;
        achievedSkills: number;
        inProgressSkills: number;
        availableSkills: number;
        totalPracticeMinutes: number;
        recentProgress: {
            skillName: string;
            achievedAt: Date;
        }[];
    }>;
    /**
     * Log a practice session for a skill
     */
    logPractice(params: {
        userId: string;
        skillNodeId: string;
        durationMinutes: number;
        valueAchieved?: number;
        notes?: string;
    }): Promise<SkillPracticeLog>;
    /**
     * Mark a skill as achieved
     */
    achieveSkill(params: {
        userId: string;
        skillNodeId: string;
        verificationVideoUrl?: string;
    }): Promise<{
        success: boolean;
        creditsAwarded?: number;
        xpAwarded?: number;
        error?: string;
    }>;
    /**
     * Get practice history for a user
     */
    getPracticeHistory(userId: string, options?: {
        limit?: number;
        offset?: number;
        skillNodeId?: string;
    }): Promise<{
        logs: (SkillPracticeLog & {
            skillName: string;
        })[];
        total: number;
    }>;
    /**
     * Update user notes for a skill
     */
    updateNotes(userId: string, skillNodeId: string, notes: string): Promise<void>;
    /**
     * Get leaderboard for a specific skill
     */
    getSkillLeaderboard(skillNodeId: string, options?: {
        limit?: number;
    }): Promise<{
        userId: string;
        username: string;
        bestValue: number;
        achievedAt: Date;
    }[]>;
};
export default skillService;
