"use strict";
/**
 * Skills Module
 *
 * Handles gymnastics/calisthenics skill progression tracking:
 * - Skill trees (handstands, planche, levers, etc.)
 * - Skill nodes with prerequisites and criteria
 * - User progress tracking and achievement
 * - Practice logging
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.skillService = void 0;
const crypto_1 = __importDefault(require("crypto"));
const client_1 = require("../../db/client");
const logger_1 = require("../../lib/logger");
const earning_service_1 = require("../economy/earning.service");
const cache_service_1 = __importStar(require("../../lib/cache.service"));
const log = logger_1.loggers.core;
// Service
exports.skillService = {
    /**
     * Get all skill trees (cached)
     */
    async getSkillTrees() {
        return cache_service_1.default.getOrSet(cache_service_1.CACHE_PREFIX.SKILL_TREES, cache_service_1.CACHE_TTL.SKILL_TREES, async () => {
            const rows = await (0, client_1.queryAll)(`SELECT * FROM skill_trees ORDER BY order_index`);
            return rows.map((r) => ({
                id: r.id,
                name: r.name,
                description: r.description ?? undefined,
                category: r.category,
                icon: r.icon ?? undefined,
                color: r.color ?? undefined,
                orderIndex: r.order_index,
            }));
        });
    },
    /**
     * Get a skill tree by ID with all its nodes (cached)
     */
    async getSkillTree(treeId) {
        const cacheKey = `${cache_service_1.CACHE_PREFIX.SKILL_TREE}${treeId}`;
        const cached = await cache_service_1.default.get(cacheKey);
        if (cached !== null) {
            return cached;
        }
        const tree = await (0, client_1.queryOne)(`SELECT * FROM skill_trees WHERE id = $1`, [treeId]);
        if (!tree) {
            await cache_service_1.default.set(cacheKey, null, 60);
            return null;
        }
        const nodes = await (0, client_1.queryAll)(`SELECT * FROM skill_nodes WHERE tree_id = $1 ORDER BY tier, position`, [treeId]);
        const result = {
            id: tree.id,
            name: tree.name,
            description: tree.description ?? undefined,
            category: tree.category,
            icon: tree.icon ?? undefined,
            color: tree.color ?? undefined,
            orderIndex: tree.order_index,
            nodes: nodes.map((n) => ({
                id: n.id,
                treeId: n.tree_id,
                name: n.name,
                description: n.description ?? undefined,
                difficulty: n.difficulty,
                prerequisites: n.prerequisites || [],
                criteriaType: n.criteria_type,
                criteriaValue: n.criteria_value ?? undefined,
                criteriaDescription: n.criteria_description ?? undefined,
                xpReward: n.xp_reward,
                creditReward: n.credit_reward,
                achievementId: n.achievement_id ?? undefined,
                videoUrl: n.video_url ?? undefined,
                thumbnailUrl: n.thumbnail_url ?? undefined,
                tips: n.tips || [],
                commonMistakes: n.common_mistakes || [],
                tier: n.tier,
                position: n.position,
            })),
        };
        await cache_service_1.default.set(cacheKey, result, cache_service_1.CACHE_TTL.SKILL_TREES);
        return result;
    },
    /**
     * Get a specific skill node
     */
    async getSkillNode(nodeId) {
        const n = await (0, client_1.queryOne)(`SELECT * FROM skill_nodes WHERE id = $1`, [nodeId]);
        if (!n)
            return null;
        return {
            id: n.id,
            treeId: n.tree_id,
            name: n.name,
            description: n.description ?? undefined,
            difficulty: n.difficulty,
            prerequisites: n.prerequisites || [],
            criteriaType: n.criteria_type,
            criteriaValue: n.criteria_value ?? undefined,
            criteriaDescription: n.criteria_description ?? undefined,
            xpReward: n.xp_reward,
            creditReward: n.credit_reward,
            achievementId: n.achievement_id ?? undefined,
            videoUrl: n.video_url ?? undefined,
            thumbnailUrl: n.thumbnail_url ?? undefined,
            tips: n.tips || [],
            commonMistakes: n.common_mistakes || [],
            tier: n.tier,
            position: n.position,
        };
    },
    /**
     * Get user progress for a skill tree
     */
    async getUserTreeProgress(userId, treeId) {
        const tree = await this.getSkillTree(treeId);
        if (!tree)
            return [];
        // Get all user progress for this tree
        const progressRows = await (0, client_1.queryAll)(`SELECT * FROM user_skill_progress
       WHERE user_id = $1 AND skill_node_id IN (
         SELECT id FROM skill_nodes WHERE tree_id = $2
       )`, [userId, treeId]);
        const progressMap = new Map();
        for (const p of progressRows) {
            progressMap.set(p.skill_node_id, {
                id: p.id,
                userId: p.user_id,
                skillNodeId: p.skill_node_id,
                status: p.status,
                bestValue: p.best_value ?? undefined,
                attemptCount: p.attempt_count,
                practiceMinutes: p.practice_minutes,
                achievedAt: p.achieved_at ?? undefined,
                verified: p.verified,
                verificationVideoUrl: p.verification_video_url ?? undefined,
                notes: p.notes ?? undefined,
                createdAt: p.created_at,
                updatedAt: p.updated_at,
            });
        }
        // For each node, calculate availability based on prerequisites
        const achievedSkills = new Set(progressRows.filter((p) => p.status === 'achieved').map((p) => p.skill_node_id));
        return tree.nodes.map((node) => {
            const progress = progressMap.get(node.id);
            // Calculate if prerequisites are met
            const prerequisitesMet = node.prerequisites.every((prereq) => achievedSkills.has(prereq));
            // If no progress record exists, create a virtual one
            if (!progress) {
                return {
                    ...node,
                    progress: {
                        id: '',
                        userId,
                        skillNodeId: node.id,
                        status: prerequisitesMet ? 'available' : 'locked',
                        attemptCount: 0,
                        practiceMinutes: 0,
                        verified: false,
                        createdAt: new Date(),
                        updatedAt: new Date(),
                    },
                };
            }
            // Update status if prerequisites now met and was locked
            if (progress.status === 'locked' && prerequisitesMet) {
                progress.status = 'available';
            }
            return {
                ...node,
                progress,
            };
        });
    },
    /**
     * Get user's overall skill progress summary
     */
    async getUserSkillSummary(userId) {
        // Get counts
        const counts = await (0, client_1.queryOne)(`SELECT
        (SELECT COUNT(*) FROM skill_nodes) as total,
        COUNT(*) FILTER (WHERE status = 'achieved') as achieved,
        COUNT(*) FILTER (WHERE status = 'in_progress') as in_progress,
        COUNT(*) FILTER (WHERE status = 'available') as available,
        COALESCE(SUM(practice_minutes), 0) as practice_minutes
       FROM user_skill_progress
       WHERE user_id = $1`, [userId]);
        // Get recent achievements
        const recent = await (0, client_1.queryAll)(`SELECT sn.name as skill_name, usp.achieved_at
       FROM user_skill_progress usp
       JOIN skill_nodes sn ON sn.id = usp.skill_node_id
       WHERE usp.user_id = $1 AND usp.status = 'achieved'
       ORDER BY usp.achieved_at DESC
       LIMIT 5`, [userId]);
        return {
            totalSkills: parseInt(counts?.total || '0'),
            achievedSkills: parseInt(counts?.achieved || '0'),
            inProgressSkills: parseInt(counts?.in_progress || '0'),
            availableSkills: parseInt(counts?.available || '0'),
            totalPracticeMinutes: parseInt(counts?.practice_minutes || '0'),
            recentProgress: recent.map((r) => ({
                skillName: r.skill_name,
                achievedAt: r.achieved_at,
            })),
        };
    },
    /**
     * Log a practice session for a skill
     */
    async logPractice(params) {
        const { userId, skillNodeId, durationMinutes, valueAchieved, notes } = params;
        const logId = `spl_${crypto_1.default.randomBytes(12).toString('hex')}`;
        await (0, client_1.transaction)(async (client) => {
            // Insert practice log
            await client.query(`INSERT INTO skill_practice_logs (id, user_id, skill_node_id, duration_minutes, value_achieved, notes)
         VALUES ($1, $2, $3, $4, $5, $6)`, [logId, userId, skillNodeId, durationMinutes, valueAchieved, notes]);
            // Update or insert user progress
            await client.query(`INSERT INTO user_skill_progress (user_id, skill_node_id, status, attempt_count, practice_minutes, best_value)
         VALUES ($1, $2, 'in_progress', 1, $3, $4)
         ON CONFLICT (user_id, skill_node_id) DO UPDATE SET
           status = CASE WHEN user_skill_progress.status = 'locked' THEN 'in_progress' ELSE user_skill_progress.status END,
           attempt_count = user_skill_progress.attempt_count + 1,
           practice_minutes = user_skill_progress.practice_minutes + EXCLUDED.practice_minutes,
           best_value = GREATEST(COALESCE(user_skill_progress.best_value, 0), COALESCE(EXCLUDED.best_value, 0)),
           updated_at = NOW()`, [userId, skillNodeId, durationMinutes, valueAchieved]);
        });
        log.info({ userId, skillNodeId, durationMinutes }, 'Skill practice logged');
        return {
            id: logId,
            userId,
            skillNodeId,
            practiceDate: new Date(),
            durationMinutes,
            valueAchieved,
            notes,
            createdAt: new Date(),
        };
    },
    /**
     * Mark a skill as achieved
     */
    async achieveSkill(params) {
        const { userId, skillNodeId, verificationVideoUrl } = params;
        // Get skill node
        const skill = await this.getSkillNode(skillNodeId);
        if (!skill) {
            return { success: false, error: 'Skill not found' };
        }
        // Check prerequisites
        const progress = await this.getUserTreeProgress(userId, skill.treeId);
        const nodeProgress = progress.find((p) => p.id === skillNodeId);
        if (!nodeProgress) {
            return { success: false, error: 'Skill not found in tree' };
        }
        if (nodeProgress.progress?.status === 'locked') {
            return { success: false, error: 'Prerequisites not met' };
        }
        if (nodeProgress.progress?.status === 'achieved') {
            return { success: false, error: 'Skill already achieved' };
        }
        // Mark as achieved
        await (0, client_1.query)(`INSERT INTO user_skill_progress (user_id, skill_node_id, status, achieved_at, verification_video_url)
       VALUES ($1, $2, 'achieved', NOW(), $3)
       ON CONFLICT (user_id, skill_node_id) DO UPDATE SET
         status = 'achieved',
         achieved_at = NOW(),
         verification_video_url = COALESCE(EXCLUDED.verification_video_url, user_skill_progress.verification_video_url),
         updated_at = NOW()`, [userId, skillNodeId, verificationVideoUrl]);
        log.info({ userId, skillNodeId, skillName: skill.name }, 'Skill achieved');
        // Award credits and XP
        let creditsAwarded = 0;
        try {
            const result = await earning_service_1.earningService.processEarning({
                userId,
                ruleCode: 'skill_unlock',
                sourceType: 'skill_achievement',
                sourceId: skillNodeId,
                metadata: {
                    skillId: skill.id,
                    skillName: skill.name,
                    difficulty: skill.difficulty,
                    treeId: skill.treeId,
                },
            });
            if (result.success) {
                creditsAwarded = result.creditsAwarded || skill.creditReward;
            }
        }
        catch (err) {
            log.error({ err, userId, skillNodeId }, 'Failed to award credits for skill achievement');
        }
        return {
            success: true,
            creditsAwarded: creditsAwarded || skill.creditReward,
            xpAwarded: skill.xpReward,
        };
    },
    /**
     * Get practice history for a user
     */
    async getPracticeHistory(userId, options = {}) {
        const { limit = 20, offset = 0, skillNodeId } = options;
        let whereClause = 'spl.user_id = $1';
        const params = [userId];
        if (skillNodeId) {
            whereClause += ` AND spl.skill_node_id = $${params.length + 1}`;
            params.push(skillNodeId);
        }
        const rows = await (0, client_1.queryAll)(`SELECT spl.*, sn.name as skill_name
       FROM skill_practice_logs spl
       JOIN skill_nodes sn ON sn.id = spl.skill_node_id
       WHERE ${whereClause}
       ORDER BY spl.practice_date DESC
       LIMIT $${params.length + 1} OFFSET $${params.length + 2}`, [...params, limit, offset]);
        const countResult = await (0, client_1.queryOne)(`SELECT COUNT(*) as count FROM skill_practice_logs spl WHERE ${whereClause}`, params);
        return {
            logs: rows.map((r) => ({
                id: r.id,
                userId: r.user_id,
                skillNodeId: r.skill_node_id,
                skillName: r.skill_name,
                practiceDate: r.practice_date,
                durationMinutes: r.duration_minutes,
                valueAchieved: r.value_achieved ?? undefined,
                notes: r.notes ?? undefined,
                createdAt: r.created_at,
            })),
            total: parseInt(countResult?.count || '0'),
        };
    },
    /**
     * Update user notes for a skill
     */
    async updateNotes(userId, skillNodeId, notes) {
        await (0, client_1.query)(`INSERT INTO user_skill_progress (user_id, skill_node_id, status, notes)
       VALUES ($1, $2, 'available', $3)
       ON CONFLICT (user_id, skill_node_id) DO UPDATE SET
         notes = EXCLUDED.notes,
         updated_at = NOW()`, [userId, skillNodeId, notes]);
    },
    /**
     * Get leaderboard for a specific skill
     */
    async getSkillLeaderboard(skillNodeId, options = {}) {
        const { limit = 10 } = options;
        const rows = await (0, client_1.queryAll)(`SELECT usp.user_id, u.username, usp.best_value, usp.achieved_at
       FROM user_skill_progress usp
       JOIN users u ON u.id = usp.user_id
       WHERE usp.skill_node_id = $1 AND usp.status = 'achieved'
       ORDER BY usp.best_value DESC, usp.achieved_at ASC
       LIMIT $2`, [skillNodeId, limit]);
        return rows.map((r) => ({
            userId: r.user_id,
            username: r.username,
            bestValue: r.best_value,
            achievedAt: r.achieved_at,
        }));
    },
};
exports.default = exports.skillService;
//# sourceMappingURL=index.js.map