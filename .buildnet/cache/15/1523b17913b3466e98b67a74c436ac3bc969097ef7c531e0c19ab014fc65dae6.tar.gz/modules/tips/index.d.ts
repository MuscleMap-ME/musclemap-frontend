/**
 * Tips Module
 *
 * Provides contextual tips, insights, and milestone tracking for users.
 */
import type { FastifyInstance } from 'fastify';
interface Tip {
    id: string;
    title: string | null;
    content: string;
    source: string | null;
    category: string;
    subcategory: string | null;
    trigger_type: string;
    trigger_value: string | null;
    display_context: string | null;
    times_shown: number;
    times_liked: number;
}
interface Milestone {
    id: string;
    name: string;
    description: string | null;
    metric: string;
    threshold: number;
    reward_type: string | null;
    reward_value: string | null;
}
interface UserStats {
    workouts_completed: number;
    exercises_done: number;
    total_reps: number;
    total_minutes: number;
}
export declare const tipsService: {
    /**
     * Get a contextual tip for the current exercise
     */
    getExerciseTip(exerciseId: string, userId: string): Promise<Tip | null>;
    /**
     * Get a tip for workout completion
     */
    getCompletionTip(userId: string, goals: string[]): Promise<{
        tip: Tip | null;
        milestone: Milestone | null;
    }>;
    /**
     * Get a daily tip for the dashboard
     */
    getDailyTip(userId: string): Promise<Tip | null>;
    /**
     * Check and return any newly achieved milestones
     */
    checkMilestones(userId: string): Promise<{
        tip: Tip | null;
        milestone: Milestone;
    } | null>;
    /**
     * Get user workout stats for milestone calculation
     */
    getUserStats(userId: string): Promise<UserStats>;
    /**
     * Calculate current streak (consecutive days with workouts)
     */
    calculateStreak(userId: string): Promise<number>;
    /**
     * Mark a tip as seen by the user
     */
    markSeen(tipId: string, userId: string): Promise<void>;
    /**
     * Like a tip
     */
    likeTip(tipId: string, userId: string): Promise<void>;
    /**
     * Get user's milestones with progress
     */
    getMilestones(userId: string): Promise<(Milestone & {
        current_value: number;
        completed_at: string | null;
        progress: number;
    })[]>;
    /**
     * Get tips the user has liked
     */
    getLikedTips(userId: string, limit?: number, offset?: number): Promise<Tip[]>;
};
/**
 * Register tips routes
 */
export declare function registerTipsRoutes(fastify: FastifyInstance): void;
export {};
