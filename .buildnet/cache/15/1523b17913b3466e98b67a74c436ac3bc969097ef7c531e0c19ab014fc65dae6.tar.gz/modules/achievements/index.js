"use strict";
/**
 * Achievements Module
 *
 * Handles achievement tracking, earning, and display:
 * - Personal records (PR)
 * - Hangout records
 * - Global records
 * - Streak achievements
 * - Milestone achievements (workout count, etc.)
 * - Social achievements (hangout memberships)
 * - Top rank achievements
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.achievementService = exports.ACHIEVEMENT_RARITIES = exports.ACHIEVEMENT_CATEGORIES = void 0;
const crypto_1 = __importDefault(require("crypto"));
const client_1 = require("../../db/client");
const logger_1 = require("../../lib/logger");
const earning_service_1 = require("../economy/earning.service");
const cache_service_1 = __importStar(require("../../lib/cache.service"));
const log = logger_1.loggers.core;
// Achievement categories
exports.ACHIEVEMENT_CATEGORIES = {
    RECORD: 'record',
    STREAK: 'streak',
    FIRST_TIME: 'first_time',
    TOP_RANK: 'top_rank',
    MILESTONE: 'milestone',
    SOCIAL: 'social',
    SPECIAL: 'special',
};
// Achievement rarities
exports.ACHIEVEMENT_RARITIES = {
    COMMON: 'common',
    UNCOMMON: 'uncommon',
    RARE: 'rare',
    EPIC: 'epic',
    LEGENDARY: 'legendary',
};
// Service
exports.achievementService = {
    /**
     * Get all achievement definitions (cached)
     */
    async getDefinitions(options = {}) {
        const { category, enabledOnly = true } = options;
        const cacheKey = `${cache_service_1.CACHE_PREFIX.ACHIEVEMENT_DEFS}:${category || 'all'}:${enabledOnly}`;
        return cache_service_1.default.getOrSet(cacheKey, cache_service_1.CACHE_TTL.ACHIEVEMENT_DEFINITIONS, async () => {
            let whereClause = enabledOnly ? 'enabled = TRUE' : '1=1';
            const params = [];
            if (category) {
                whereClause += ` AND category = $${params.length + 1}`;
                params.push(category);
            }
            const rows = await (0, client_1.queryAll)(`SELECT * FROM achievement_definitions WHERE ${whereClause} ORDER BY category, points DESC`, params);
            return rows.map((r) => ({
                id: r.id,
                key: r.key,
                name: r.name,
                description: r.description ?? undefined,
                icon: r.icon ?? undefined,
                category: r.category,
                points: r.points,
                rarity: r.rarity,
                enabled: r.enabled,
            }));
        });
    },
    /**
     * Get a specific achievement definition by key (cached)
     */
    async getDefinitionByKey(key) {
        const cacheKey = `${cache_service_1.CACHE_PREFIX.ACHIEVEMENT_DEF}${key}`;
        const cached = await cache_service_1.default.get(cacheKey);
        if (cached !== null) {
            return cached;
        }
        const row = await (0, client_1.queryOne)('SELECT * FROM achievement_definitions WHERE key = $1', [key]);
        if (!row) {
            // Cache null result for a short time to prevent repeated lookups
            await cache_service_1.default.set(cacheKey, null, 60);
            return null;
        }
        const result = {
            id: row.id,
            key: row.key,
            name: row.name,
            description: row.description ?? undefined,
            icon: row.icon ?? undefined,
            category: row.category,
            points: row.points,
            rarity: row.rarity,
            enabled: row.enabled,
        };
        await cache_service_1.default.set(cacheKey, result, cache_service_1.CACHE_TTL.ACHIEVEMENT_DEFINITIONS);
        return result;
    },
    /**
     * Grant an achievement to a user
     */
    async grant(params) {
        const { userId, achievementKey, hangoutId, virtualHangoutId, exerciseId, metricKey, value, showInHangoutFeed = true, showOnProfile = true, } = params;
        // Get achievement definition
        const definition = await this.getDefinitionByKey(achievementKey);
        if (!definition || !definition.enabled) {
            log.warn({ achievementKey }, 'Attempted to grant non-existent or disabled achievement');
            return null;
        }
        // Check if user already has this achievement (with same context)
        const existing = await (0, client_1.queryOne)(`SELECT id FROM achievement_events
       WHERE user_id = $1 AND achievement_id = $2
         AND COALESCE(hangout_id::text, 'null') = COALESCE($3::text, 'null')
         AND COALESCE(virtual_hangout_id::text, 'null') = COALESCE($4::text, 'null')
         AND COALESCE(exercise_id, 'null') = COALESCE($5, 'null')`, [userId, definition.id, hangoutId, virtualHangoutId, exerciseId]);
        if (existing) {
            log.debug({ userId, achievementKey }, 'User already has this achievement');
            return null;
        }
        // Grant the achievement
        const eventId = `ae_${crypto_1.default.randomBytes(12).toString('hex')}`;
        await (0, client_1.transaction)(async (client) => {
            // Insert achievement event
            await client.query(`INSERT INTO achievement_events
         (id, user_id, achievement_id, hangout_id, virtual_hangout_id, exercise_id, metric_key, value, show_in_hangout_feed, show_on_profile)
         VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)`, [eventId, userId, definition.id, hangoutId, virtualHangoutId, exerciseId, metricKey, value, showInHangoutFeed, showOnProfile]);
            // Update user's total points
            await client.query(`UPDATE users SET achievement_points = COALESCE(achievement_points, 0) + $1 WHERE id = $2`, [definition.points, userId]);
        });
        log.info({ userId, achievementKey, points: definition.points }, 'Achievement granted');
        // Award credits for achievement (non-blocking)
        try {
            await earning_service_1.earningService.processEarning({
                userId,
                ruleCode: 'achievement_unlock',
                sourceType: 'achievement',
                sourceId: definition.key,
                metadata: {
                    achievementKey: definition.key,
                    category: definition.category,
                    rarity: definition.rarity,
                    points: definition.points,
                },
            });
        }
        catch (earningError) {
            log.error({ earningError, userId, achievementKey }, 'Failed to process achievement earning');
        }
        return {
            id: eventId,
            userId,
            achievementId: definition.id,
            achievementKey: definition.key,
            achievementName: definition.name,
            achievementDescription: definition.description,
            achievementIcon: definition.icon,
            category: definition.category,
            points: definition.points,
            rarity: definition.rarity,
            hangoutId,
            virtualHangoutId,
            exerciseId,
            metricKey,
            value,
            showInHangoutFeed,
            showOnProfile,
            earnedAt: new Date(),
        };
    },
    /**
     * Check and grant streak achievements
     */
    async checkStreakAchievements(userId) {
        const granted = [];
        // Calculate current streak
        const streakResult = await (0, client_1.queryOne)(`WITH daily_workouts AS (
        SELECT DISTINCT DATE(date) as workout_date
        FROM workouts
        WHERE user_id = $1 AND date >= CURRENT_DATE - INTERVAL '365 days'
        ORDER BY workout_date DESC
      ),
      streak_calc AS (
        SELECT workout_date,
               workout_date - (ROW_NUMBER() OVER (ORDER BY workout_date DESC))::int as streak_group
        FROM daily_workouts
      )
      SELECT COUNT(*) as streak
      FROM streak_calc
      WHERE streak_group = (
        SELECT streak_group FROM streak_calc WHERE workout_date = CURRENT_DATE
        UNION
        SELECT streak_group FROM streak_calc WHERE workout_date = CURRENT_DATE - 1
        LIMIT 1
      )`, [userId]);
        const currentStreak = parseInt(streakResult?.streak || '0');
        // Check streak milestones
        const streakMilestones = [
            { days: 7, key: 'streak_7' },
            { days: 30, key: 'streak_30' },
            { days: 100, key: 'streak_100' },
        ];
        for (const milestone of streakMilestones) {
            if (currentStreak >= milestone.days) {
                const event = await this.grant({
                    userId,
                    achievementKey: milestone.key,
                    value: currentStreak,
                });
                if (event)
                    granted.push(event);
            }
        }
        return granted;
    },
    /**
     * Check and grant workout milestone achievements
     */
    async checkWorkoutMilestones(userId) {
        const granted = [];
        const countResult = await (0, client_1.queryOne)('SELECT COUNT(*) as count FROM workouts WHERE user_id = $1', [userId]);
        const workoutCount = parseInt(countResult?.count || '0');
        const milestones = [
            { count: 10, key: 'workouts_10' },
            { count: 100, key: 'workouts_100' },
            { count: 500, key: 'workouts_500' },
            { count: 1000, key: 'workouts_1000' },
        ];
        for (const milestone of milestones) {
            if (workoutCount >= milestone.count) {
                const event = await this.grant({
                    userId,
                    achievementKey: milestone.key,
                    value: workoutCount,
                });
                if (event)
                    granted.push(event);
            }
        }
        return granted;
    },
    /**
     * Check and grant social achievements (hangout memberships)
     */
    async checkSocialAchievements(userId) {
        const granted = [];
        // Count hangout memberships
        const hangoutCount = await (0, client_1.queryOne)(`SELECT COUNT(*) as count FROM hangout_memberships WHERE user_id = $1`, [userId]);
        const virtualCount = await (0, client_1.queryOne)(`SELECT COUNT(*) as count FROM virtual_hangout_memberships WHERE user_id = $1`, [userId]);
        const totalMemberships = parseInt(hangoutCount?.count || '0') + parseInt(virtualCount?.count || '0');
        // First hangout join
        if (totalMemberships >= 1) {
            const event = await this.grant({ userId, achievementKey: 'first_hangout_join' });
            if (event)
                granted.push(event);
        }
        // Social milestones
        const milestones = [
            { count: 5, key: 'hangouts_5' },
            { count: 10, key: 'hangouts_10' },
        ];
        for (const milestone of milestones) {
            if (totalMemberships >= milestone.count) {
                const event = await this.grant({
                    userId,
                    achievementKey: milestone.key,
                    value: totalMemberships,
                });
                if (event)
                    granted.push(event);
            }
        }
        return granted;
    },
    /**
     * Check and grant top rank achievements
     */
    async checkTopRankAchievements(userId, rank, hangoutId, virtualHangoutId, exerciseId, metricKey) {
        const granted = [];
        if (rank === 1) {
            const event = await this.grant({
                userId,
                achievementKey: 'number_one',
                hangoutId,
                virtualHangoutId,
                exerciseId,
                metricKey,
                value: rank,
            });
            if (event)
                granted.push(event);
        }
        if (rank <= 3) {
            const event = await this.grant({
                userId,
                achievementKey: 'top_3_entry',
                hangoutId,
                virtualHangoutId,
                exerciseId,
                metricKey,
                value: rank,
            });
            if (event)
                granted.push(event);
        }
        if (rank <= 10) {
            const event = await this.grant({
                userId,
                achievementKey: 'top_10_entry',
                hangoutId,
                virtualHangoutId,
                exerciseId,
                metricKey,
                value: rank,
            });
            if (event)
                granted.push(event);
        }
        return granted;
    },
    /**
     * Check and grant record achievements
     */
    async checkRecordAchievements(userId, isPersonalRecord, isHangoutRecord, isGlobalRecord, hangoutId, virtualHangoutId, exerciseId, metricKey, value) {
        const granted = [];
        if (isPersonalRecord) {
            const event = await this.grant({
                userId,
                achievementKey: 'personal_record',
                hangoutId,
                virtualHangoutId,
                exerciseId,
                metricKey,
                value,
            });
            if (event)
                granted.push(event);
        }
        if (isHangoutRecord && (hangoutId || virtualHangoutId)) {
            const event = await this.grant({
                userId,
                achievementKey: 'hangout_record',
                hangoutId,
                virtualHangoutId,
                exerciseId,
                metricKey,
                value,
            });
            if (event)
                granted.push(event);
        }
        if (isGlobalRecord) {
            const event = await this.grant({
                userId,
                achievementKey: 'global_record',
                exerciseId,
                metricKey,
                value,
            });
            if (event)
                granted.push(event);
        }
        return granted;
    },
    /**
     * Get user's achievements
     */
    async getUserAchievements(userId, options = {}) {
        const { limit = 50, offset = 0, category } = options;
        let whereClause = 'ae.user_id = $1';
        const params = [userId];
        if (category) {
            whereClause += ` AND ad.category = $${params.length + 1}`;
            params.push(category);
        }
        const rows = await (0, client_1.queryAll)(`SELECT ae.*, ad.key, ad.name, ad.description, ad.icon, ad.category, ad.points, ad.rarity
       FROM achievement_events ae
       JOIN achievement_definitions ad ON ad.id = ae.achievement_id
       WHERE ${whereClause}
       ORDER BY ae.earned_at DESC
       LIMIT $${params.length + 1} OFFSET $${params.length + 2}`, [...params, limit, offset]);
        const countResult = await (0, client_1.queryOne)(`SELECT COUNT(*) as count FROM achievement_events ae
       JOIN achievement_definitions ad ON ad.id = ae.achievement_id
       WHERE ${whereClause}`, params);
        return {
            achievements: rows.map((r) => ({
                id: r.id,
                userId: r.user_id,
                achievementId: r.achievement_id,
                achievementKey: r.key,
                achievementName: r.name,
                achievementDescription: r.description ?? undefined,
                achievementIcon: r.icon ?? undefined,
                category: r.category,
                points: r.points,
                rarity: r.rarity,
                hangoutId: r.hangout_id ?? undefined,
                virtualHangoutId: r.virtual_hangout_id ?? undefined,
                exerciseId: r.exercise_id ?? undefined,
                metricKey: r.metric_key ?? undefined,
                value: r.value ? parseFloat(r.value) : undefined,
                showInHangoutFeed: r.show_in_hangout_feed,
                showOnProfile: r.show_on_profile,
                earnedAt: r.earned_at,
            })),
            total: parseInt(countResult?.count || '0'),
        };
    },
    /**
     * Get user's achievement summary
     */
    async getUserSummary(userId) {
        // Get total points
        const pointsResult = await (0, client_1.queryOne)('SELECT COALESCE(achievement_points, 0) as points FROM users WHERE id = $1', [userId]);
        // Get counts by category and rarity
        const stats = await (0, client_1.queryAll)(`SELECT ad.category, ad.rarity, COUNT(*) as count
       FROM achievement_events ae
       JOIN achievement_definitions ad ON ad.id = ae.achievement_id
       WHERE ae.user_id = $1
       GROUP BY ad.category, ad.rarity`, [userId]);
        // Initialize counts
        const byCategory = {
            record: 0,
            streak: 0,
            first_time: 0,
            top_rank: 0,
            milestone: 0,
            social: 0,
            special: 0,
        };
        const byRarity = {
            common: 0,
            uncommon: 0,
            rare: 0,
            epic: 0,
            legendary: 0,
        };
        let totalAchievements = 0;
        for (const stat of stats) {
            const count = parseInt(stat.count);
            totalAchievements += count;
            if (stat.category in byCategory) {
                byCategory[stat.category] += count;
            }
            if (stat.rarity in byRarity) {
                byRarity[stat.rarity] += count;
            }
        }
        // Get recent achievements
        const { achievements: recentAchievements } = await this.getUserAchievements(userId, { limit: 5 });
        return {
            totalPoints: parseInt(pointsResult?.points || '0'),
            totalAchievements,
            byCategory,
            byRarity,
            recentAchievements,
        };
    },
    /**
     * Get achievement feed for a hangout
     */
    async getHangoutFeed(hangoutId, options = {}) {
        const { limit = 20, offset = 0 } = options;
        const rows = await (0, client_1.queryAll)(`SELECT ae.*, ad.key, ad.name, ad.description, ad.icon, ad.category, ad.points, ad.rarity, u.username
       FROM achievement_events ae
       JOIN achievement_definitions ad ON ad.id = ae.achievement_id
       JOIN users u ON u.id = ae.user_id
       WHERE ae.hangout_id = $1 AND ae.show_in_hangout_feed = TRUE
       ORDER BY ae.earned_at DESC
       LIMIT $2 OFFSET $3`, [hangoutId, limit, offset]);
        const countResult = await (0, client_1.queryOne)(`SELECT COUNT(*) as count FROM achievement_events
       WHERE hangout_id = $1 AND show_in_hangout_feed = TRUE`, [hangoutId]);
        return {
            achievements: rows.map((r) => ({
                id: r.id,
                userId: r.user_id,
                achievementId: r.achievement_id,
                achievementKey: r.key,
                achievementName: r.name,
                achievementDescription: r.description ?? undefined,
                achievementIcon: r.icon ?? undefined,
                category: r.category,
                points: r.points,
                rarity: r.rarity,
                hangoutId: r.hangout_id ?? undefined,
                virtualHangoutId: r.virtual_hangout_id ?? undefined,
                exerciseId: r.exercise_id ?? undefined,
                metricKey: r.metric_key ?? undefined,
                value: r.value ? parseFloat(r.value) : undefined,
                showInHangoutFeed: r.show_in_hangout_feed,
                showOnProfile: r.show_on_profile,
                earnedAt: r.earned_at,
            })),
            total: parseInt(countResult?.count || '0'),
        };
    },
    /**
     * Run all achievement checks after a workout
     */
    async checkAllAfterWorkout(userId) {
        const granted = [];
        // Check streak achievements
        const streakAchievements = await this.checkStreakAchievements(userId);
        granted.push(...streakAchievements);
        // Check workout milestones
        const milestoneAchievements = await this.checkWorkoutMilestones(userId);
        granted.push(...milestoneAchievements);
        return granted;
    },
};
exports.default = exports.achievementService;
//# sourceMappingURL=index.js.map