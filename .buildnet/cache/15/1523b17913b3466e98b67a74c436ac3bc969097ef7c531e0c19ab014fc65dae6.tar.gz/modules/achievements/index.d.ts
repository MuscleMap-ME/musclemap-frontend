/**
 * Achievements Module
 *
 * Handles achievement tracking, earning, and display:
 * - Personal records (PR)
 * - Hangout records
 * - Global records
 * - Streak achievements
 * - Milestone achievements (workout count, etc.)
 * - Social achievements (hangout memberships)
 * - Top rank achievements
 */
export declare const ACHIEVEMENT_CATEGORIES: {
    readonly RECORD: "record";
    readonly STREAK: "streak";
    readonly FIRST_TIME: "first_time";
    readonly TOP_RANK: "top_rank";
    readonly MILESTONE: "milestone";
    readonly SOCIAL: "social";
    readonly SPECIAL: "special";
};
export type AchievementCategory = (typeof ACHIEVEMENT_CATEGORIES)[keyof typeof ACHIEVEMENT_CATEGORIES];
export declare const ACHIEVEMENT_RARITIES: {
    readonly COMMON: "common";
    readonly UNCOMMON: "uncommon";
    readonly RARE: "rare";
    readonly EPIC: "epic";
    readonly LEGENDARY: "legendary";
};
export type AchievementRarity = (typeof ACHIEVEMENT_RARITIES)[keyof typeof ACHIEVEMENT_RARITIES];
export interface AchievementDefinition {
    id: string;
    key: string;
    name: string;
    description?: string;
    icon?: string;
    category: AchievementCategory;
    points: number;
    rarity: AchievementRarity;
    enabled: boolean;
}
export interface AchievementEvent {
    id: string;
    userId: string;
    achievementId: string;
    achievementKey: string;
    achievementName: string;
    achievementDescription?: string;
    achievementIcon?: string;
    category: AchievementCategory;
    points: number;
    rarity: AchievementRarity;
    hangoutId?: number;
    virtualHangoutId?: number;
    exerciseId?: string;
    metricKey?: string;
    value?: number;
    showInHangoutFeed: boolean;
    showOnProfile: boolean;
    earnedAt: Date;
}
export interface UserAchievementSummary {
    totalPoints: number;
    totalAchievements: number;
    byCategory: Record<AchievementCategory, number>;
    byRarity: Record<AchievementRarity, number>;
    recentAchievements: AchievementEvent[];
}
export declare const achievementService: {
    /**
     * Get all achievement definitions (cached)
     */
    getDefinitions(options?: {
        category?: AchievementCategory;
        enabledOnly?: boolean;
    }): Promise<AchievementDefinition[]>;
    /**
     * Get a specific achievement definition by key (cached)
     */
    getDefinitionByKey(key: string): Promise<AchievementDefinition | null>;
    /**
     * Grant an achievement to a user
     */
    grant(params: {
        userId: string;
        achievementKey: string;
        hangoutId?: number;
        virtualHangoutId?: number;
        exerciseId?: string;
        metricKey?: string;
        value?: number;
        showInHangoutFeed?: boolean;
        showOnProfile?: boolean;
    }): Promise<AchievementEvent | null>;
    /**
     * Check and grant streak achievements
     */
    checkStreakAchievements(userId: string): Promise<AchievementEvent[]>;
    /**
     * Check and grant workout milestone achievements
     */
    checkWorkoutMilestones(userId: string): Promise<AchievementEvent[]>;
    /**
     * Check and grant social achievements (hangout memberships)
     */
    checkSocialAchievements(userId: string): Promise<AchievementEvent[]>;
    /**
     * Check and grant top rank achievements
     */
    checkTopRankAchievements(userId: string, rank: number, hangoutId?: number, virtualHangoutId?: number, exerciseId?: string, metricKey?: string): Promise<AchievementEvent[]>;
    /**
     * Check and grant record achievements
     */
    checkRecordAchievements(userId: string, isPersonalRecord: boolean, isHangoutRecord: boolean, isGlobalRecord: boolean, hangoutId?: number, virtualHangoutId?: number, exerciseId?: string, metricKey?: string, value?: number): Promise<AchievementEvent[]>;
    /**
     * Get user's achievements
     */
    getUserAchievements(userId: string, options?: {
        limit?: number;
        offset?: number;
        category?: AchievementCategory;
    }): Promise<{
        achievements: AchievementEvent[];
        total: number;
    }>;
    /**
     * Get user's achievement summary
     */
    getUserSummary(userId: string): Promise<UserAchievementSummary>;
    /**
     * Get achievement feed for a hangout
     */
    getHangoutFeed(hangoutId: number, options?: {
        limit?: number;
        offset?: number;
    }): Promise<{
        achievements: AchievementEvent[];
        total: number;
    }>;
    /**
     * Run all achievement checks after a workout
     */
    checkAllAfterWorkout(userId: string): Promise<AchievementEvent[]>;
};
export default achievementService;
