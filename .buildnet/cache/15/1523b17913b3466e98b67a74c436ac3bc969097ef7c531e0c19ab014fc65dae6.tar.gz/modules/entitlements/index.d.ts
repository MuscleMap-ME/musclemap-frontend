/**
 * Entitlements Module
 *
 * Determines user access based on:
 * 1. Trial period (first 90 days free)
 * 2. Active subscription ($1/month)
 * 3. Credit balance (for non-subscribers after trial)
 */
export interface Entitlements {
    unlimited: boolean;
    creditsVisible: boolean;
    creditBalance: number | null;
    reason: 'trial' | 'subscribed' | 'credits';
    trialEndsAt: string | null;
    subscriptionStatus: string | null;
    daysLeftInTrial: number | null;
}
export declare const entitlementsService: {
    /**
     * Get user's current entitlements
     */
    getEntitlements(userId: string): Promise<Entitlements>;
    /**
     * Grant 150 free credits when user first enters credit mode (after trial ends)
     * This is idempotent - only grants once
     */
    grantInitialCreditsIfNeeded(userId: string): Promise<boolean>;
    /**
     * Check if user can perform an action (has unlimited access or sufficient credits)
     */
    canPerformAction(userId: string, creditCost: number): Promise<{
        allowed: boolean;
        reason: string;
    }>;
};
