/**
 * Mentorship Service
 *
 * Handles mentor/mentee relationships:
 * - Mentor profile management
 * - Mentorship matching and requests
 * - Check-in tracking
 * - Rating and feedback
 */
export interface MentorProfile {
    userId: string;
    isAvailable: boolean;
    maxMentees: number;
    currentMenteeCount: number;
    specialties: string[];
    experienceYears: number;
    bio?: string;
    hourlyRate?: number;
    isPro: boolean;
    rating: number;
    totalRatings: number;
    totalMentorships: number;
    successfulMentorships: number;
    verifiedAt?: Date;
    createdAt: Date;
}
export interface MentorProfileWithUser extends MentorProfile {
    username: string;
    displayName?: string;
    avatarUrl?: string;
}
export interface Mentorship {
    id: string;
    mentorId: string;
    menteeId: string;
    status: 'pending' | 'active' | 'completed' | 'cancelled';
    focusAreas: string[];
    goals?: string;
    startDate?: Date;
    expectedEndDate?: Date;
    actualEndDate?: Date;
    menteeRating?: number;
    menteeFeedback?: string;
    mentorRating?: number;
    mentorFeedback?: string;
    createdAt: Date;
}
export interface MentorshipWithUsers extends Mentorship {
    mentorUsername: string;
    mentorDisplayName?: string;
    mentorAvatarUrl?: string;
    menteeUsername: string;
    menteeDisplayName?: string;
    menteeAvatarUrl?: string;
}
export interface MentorshipCheckIn {
    id: string;
    mentorshipId: string;
    initiatedBy: string;
    notes?: string;
    mood?: 'great' | 'good' | 'okay' | 'struggling';
    progressUpdate?: string;
    nextSteps?: string;
    scheduledFor?: Date;
    completedAt?: Date;
    createdAt: Date;
}
export interface MentorSearchOptions {
    specialties?: string[];
    minRating?: number;
    isPro?: boolean;
    maxHourlyRate?: number;
    limit?: number;
    offset?: number;
}
export declare const mentorshipService: {
    /**
     * Create or update mentor profile
     */
    upsertMentorProfile(userId: string, profile: Partial<Omit<MentorProfile, "userId" | "createdAt" | "rating" | "totalRatings" | "currentMenteeCount">>): Promise<MentorProfile>;
    /**
     * Get mentor profile
     */
    getMentorProfile(userId: string): Promise<MentorProfileWithUser | null>;
    /**
     * Search for available mentors
     */
    searchMentors(options?: MentorSearchOptions): Promise<{
        mentors: MentorProfileWithUser[];
        total: number;
    }>;
    /**
     * Request a mentorship
     */
    requestMentorship(menteeId: string, mentorId: string, options?: {
        focusAreas?: string[];
        goals?: string;
    }): Promise<Mentorship>;
    /**
     * Accept mentorship request (mentor action)
     */
    acceptMentorship(mentorId: string, mentorshipId: string): Promise<Mentorship>;
    /**
     * Decline mentorship request (mentor action)
     */
    declineMentorship(mentorId: string, mentorshipId: string): Promise<void>;
    /**
     * Complete mentorship
     */
    completeMentorship(userId: string, mentorshipId: string, feedback: {
        rating: number;
        comment?: string;
    }): Promise<void>;
    /**
     * Cancel mentorship
     */
    cancelMentorship(userId: string, mentorshipId: string): Promise<void>;
    /**
     * Get pending mentorship requests (for mentor)
     */
    getPendingRequests(mentorId: string): Promise<MentorshipWithUsers[]>;
    /**
     * Get active mentorships
     */
    getActiveMentorships(userId: string): Promise<MentorshipWithUsers[]>;
    /**
     * Get mentorship history
     */
    getMentorshipHistory(userId: string, options?: {
        limit?: number;
        offset?: number;
    }): Promise<{
        mentorships: MentorshipWithUsers[];
        total: number;
    }>;
    /**
     * Create a check-in
     */
    createCheckIn(userId: string, mentorshipId: string, checkIn: {
        notes?: string;
        mood?: MentorshipCheckIn["mood"];
        progressUpdate?: string;
        nextSteps?: string;
        scheduledFor?: Date;
    }): Promise<MentorshipCheckIn>;
    /**
     * Complete a check-in
     */
    completeCheckIn(userId: string, checkInId: string): Promise<void>;
    /**
     * Get check-ins for a mentorship
     */
    getCheckIns(mentorshipId: string, options?: {
        limit?: number;
        offset?: number;
    }): Promise<{
        checkIns: MentorshipCheckIn[];
        total: number;
    }>;
};
export default mentorshipService;
