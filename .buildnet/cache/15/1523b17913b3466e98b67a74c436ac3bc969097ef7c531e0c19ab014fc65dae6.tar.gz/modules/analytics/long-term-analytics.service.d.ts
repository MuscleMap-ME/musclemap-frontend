/**
 * Long-Term Analytics Service
 *
 * Provides comprehensive analytics for tracking yearly TU (Training Units),
 * trends, and progress over time:
 *
 * - getYearlyStats(userId, year) - Get stats for a specific year
 * - getMonthlyTrends(userId, months) - Get monthly trend data
 * - getProgressVelocity(userId) - Calculate rate of progress
 * - getProjectedMilestones(userId) - Predict when milestones will be reached
 * - getYearInReview(userId, year) - Comprehensive year summary
 * - aggregateUserStats(userId) - Recalculate all aggregates
 */
export interface YearlyStats {
    userId: string;
    year: number;
    totalTu: number;
    avgTuPerWorkout: number;
    maxTuSingleWorkout: number;
    tuTrendPercent: number | null;
    totalWorkouts: number;
    totalExercises: number;
    totalSets: number;
    totalReps: number;
    totalDurationMinutes: number;
    totalVolumeLbs: number;
    avgWorkoutDurationMinutes: number;
    avgSetsPerWorkout: number;
    avgRepsPerSet: number;
    activeDays: number;
    workoutDays: number;
    longestStreak: number;
    avgWorkoutsPerWeek: number;
    consistencyScore: number;
    strengthGained: number;
    constitutionGained: number;
    dexterityGained: number;
    powerGained: number;
    enduranceGained: number;
    vitalityGained: number;
    creditsEarned: number;
    creditsSpent: number;
    xpEarned: number;
    levelsGained: number;
    highFivesSent: number;
    highFivesReceived: number;
    competitionsEntered: number;
    competitionsWon: number;
    prsSet: number;
    topExercises: Array<{
        exerciseId: string;
        name: string;
        count: number;
    }>;
    topMuscleGroups: Array<{
        muscleGroup: string;
        volume: number;
    }>;
    monthlyBreakdown: Array<{
        month: number;
        tu: number;
        workouts: number;
    }>;
    achievementsUnlocked: number;
    milestonesCompleted: number;
    calculatedAt: Date;
    isComplete: boolean;
}
export interface MonthlyStats {
    userId: string;
    year: number;
    month: number;
    totalTu: number;
    avgTuPerWorkout: number;
    tuChangeFromPrevMonth: number | null;
    totalWorkouts: number;
    totalExercises: number;
    totalSets: number;
    totalReps: number;
    totalDurationMinutes: number;
    totalVolumeLbs: number;
    avgWorkoutDurationMinutes: number;
    activeDays: number;
    workoutDays: number;
    currentStreak: number;
    consistencyScore: number;
    strengthDelta: number;
    constitutionDelta: number;
    dexterityDelta: number;
    powerDelta: number;
    enduranceDelta: number;
    vitalityDelta: number;
    creditsEarned: number;
    creditsSpent: number;
    xpEarned: number;
    highFivesSent: number;
    highFivesReceived: number;
    prsSet: number;
    topExercises: Array<{
        exerciseId: string;
        name: string;
        count: number;
    }>;
    weeklyBreakdown: Array<{
        week: number;
        tu: number;
        workouts: number;
    }>;
    calculatedAt: Date;
    isComplete: boolean;
}
export interface ProgressTrends {
    userId: string;
    tuVelocity: number;
    workoutVelocity: number;
    volumeVelocity: number;
    xpVelocity: number;
    strengthVelocity: number;
    tuAcceleration: number;
    workoutAcceleration: number;
    strengthAcceleration: number;
    tuTrend: 'accelerating' | 'steady' | 'decelerating' | 'stagnant' | 'new';
    workoutTrend: 'accelerating' | 'steady' | 'decelerating' | 'stagnant' | 'new';
    overallTrend: 'excellent' | 'good' | 'stable' | 'declining' | 'at_risk' | 'new';
    projectedMilestones: Array<{
        name: string;
        targetValue: number;
        currentValue: number;
        projectedDate: string | null;
        daysRemaining: number | null;
    }>;
    projectedTuNextMonth: number | null;
    projectedTuNextQuarter: number | null;
    projectedTuNextYear: number | null;
    projectedWorkoutsNextMonth: number | null;
    projectedLevelUpDate: string | null;
    tuVsPrevMonthPct: number | null;
    tuVsPrevQuarterPct: number | null;
    tuVsPrevYearPct: number | null;
    workoutsVsPrevMonthPct: number | null;
    bestMonth: {
        year: number;
        month: number;
        tu: number;
    } | null;
    bestQuarter: {
        year: number;
        quarter: number;
        tu: number;
    } | null;
    bestYear: {
        year: number;
        tu: number;
    } | null;
    projectionConfidence: number;
    currentStreak: number;
    longestStreak: number;
    streakHealth: 'strong' | 'healthy' | 'at_risk' | 'broken' | 'new';
    daysUntilStreakMilestone: number | null;
    dataPointsCount: number;
    earliestDataDate: string | null;
    latestDataDate: string | null;
    calculatedAt: Date;
}
export interface YearInReview {
    year: number;
    summary: {
        totalTu: number;
        totalWorkouts: number;
        totalVolumeLbs: number;
        activeDays: number;
        longestStreak: number;
        prsSet: number;
        creditsEarned: number;
        xpEarned: number;
    } | null;
    comparison: {
        tuChange: number | null;
        workoutsChange: number | null;
        volumeChange: number | null;
    } | null;
    monthlyBreakdown: Array<{
        month: number;
        tu: number;
        workouts: number;
        volume: number;
    }>;
    topExercises: Array<{
        exerciseId: string;
        name: string;
        count: number;
    }>;
    topMuscleGroups: Array<{
        muscleGroup: string;
        volume: number;
    }>;
    highlights: {
        bestMonth: {
            month: number;
            tu: number;
        } | null;
        biggestPr: {
            exerciseId: string;
            name: string;
            weight: number;
        } | null;
        totalHighFives: number;
        achievementsUnlocked: number;
    };
    ranking: {
        tuRank: number | null;
        percentile: number | null;
        totalUsers: number;
    };
}
export interface ProjectedMilestone {
    name: string;
    description: string;
    targetValue: number;
    currentValue: number;
    projectedDate: string | null;
    daysRemaining: number | null;
    confidence: number;
    category: 'tu' | 'workouts' | 'volume' | 'streak' | 'level' | 'custom';
}
export declare const longTermAnalyticsService: {
    /**
     * Get yearly stats for a specific year
     */
    getYearlyStats(userId: string, year: number): Promise<YearlyStats | null>;
    /**
     * Get all years with stats for a user
     */
    getYearsList(userId: string): Promise<number[]>;
    /**
     * Get monthly trends for the last N months
     */
    getMonthlyTrends(userId: string, months?: number): Promise<MonthlyStats[]>;
    /**
     * Get progress velocity and trends
     */
    getProgressVelocity(userId: string): Promise<ProgressTrends | null>;
    /**
     * Get projected milestones
     */
    getProjectedMilestones(userId: string): Promise<ProjectedMilestone[]>;
    /**
     * Get comprehensive year-in-review
     */
    getYearInReview(userId: string, year: number): Promise<YearInReview>;
    /**
     * Recalculate all user stats (run as background job)
     */
    aggregateUserStats(userId: string): Promise<void>;
    /**
     * Calculate monthly stats for a specific month
     */
    calculateMonthlyStats(userId: string, year: number, month: number, client?: any): Promise<void>;
    /**
     * Calculate yearly stats
     */
    calculateYearlyStats(userId: string, year: number, client?: any): Promise<void>;
    /**
     * Update progress trends for a user
     */
    updateProgressTrends(userId: string, client?: any): Promise<void>;
    /**
     * Get all-time TU leaderboard
     */
    getAllTimeTuLeaderboard(limit?: number, offset?: number): Promise<Array<{
        userId: string;
        username: string;
        avatarUrl: string | null;
        lifetimeTu: number;
        lifetimeWorkouts: number;
        lifetimeVolumeLbs: number;
        lifetimePrs: number;
        activeYears: number;
        rank: number;
    }>>;
    /**
     * Refresh materialized views
     */
    refreshMaterializedViews(): Promise<void>;
};
export default longTermAnalyticsService;
