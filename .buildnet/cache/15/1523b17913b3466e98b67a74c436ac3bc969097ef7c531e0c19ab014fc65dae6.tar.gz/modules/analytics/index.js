"use strict";
/**
 * Analytics Module
 *
 * Exports long-term analytics services for tracking TU, trends,
 * and progress over time.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.longTermAnalyticsService = void 0;
var long_term_analytics_service_1 = require("./long-term-analytics.service");
Object.defineProperty(exports, "longTermAnalyticsService", { enumerable: true, get: function () { return long_term_analytics_service_1.longTermAnalyticsService; } });
//# sourceMappingURL=index.js.map