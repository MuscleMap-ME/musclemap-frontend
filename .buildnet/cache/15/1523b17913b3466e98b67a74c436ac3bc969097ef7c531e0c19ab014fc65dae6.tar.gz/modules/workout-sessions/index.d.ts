/**
 * Workout Sessions Module
 *
 * Provides real-time workout logging with:
 * - Session lifecycle management (start, pause, resume, complete, abandon)
 * - Individual set logging with TU calculation
 * - PR detection per set
 * - Muscle activation tracking
 * - Session recovery from crashes/refreshes
 *
 * Uses existing tables from migrations:
 * - active_workout_sessions (119)
 * - workout_sets (070)
 * - archived_workout_sessions (119)
 */
export interface LoggedSet {
    id: string;
    exerciseId: string;
    exerciseName: string;
    setNumber: number;
    reps: number | null;
    weightKg: number | null;
    rpe: number | null;
    rir: number | null;
    durationSeconds: number | null;
    restSeconds: number | null;
    tag: string;
    notes: string | null;
    tu: number;
    muscleActivations: MuscleActivation[];
    isPRWeight: boolean;
    isPRReps: boolean;
    isPR1RM: boolean;
    performedAt: Date;
}
export interface MuscleActivation {
    muscleId: string;
    muscleName: string;
    activation: number;
    tu: number;
}
export interface MuscleActivationSummary {
    muscleId: string;
    muscleName: string;
    totalTU: number;
    setCount: number;
    percentageOfMax: number | null;
}
export interface SessionPR {
    exerciseId: string;
    exerciseName: string;
    prType: string;
    previousValue: number | null;
    newValue: number;
    improvementPercent: number | null;
    achievedAt: Date;
}
export interface WorkoutSession {
    id: string;
    userId: string;
    startedAt: Date;
    pausedAt: Date | null;
    totalPausedTime: number;
    lastActivityAt: Date;
    workoutPlan: any | null;
    currentExerciseIndex: number;
    currentSetIndex: number;
    sets: LoggedSet[];
    totalVolume: number;
    totalReps: number;
    estimatedCalories: number;
    musclesWorked: MuscleActivationSummary[];
    sessionPRs: SessionPR[];
    restTimerRemaining: number | null;
    restTimerTotalDuration: number | null;
    restTimerStartedAt: Date | null;
    clientVersion: number;
    serverVersion: number;
    createdAt: Date;
    updatedAt: Date;
}
export interface LogSetInput {
    sessionId: string;
    exerciseId: string;
    setNumber: number;
    reps?: number;
    weightKg?: number;
    rpe?: number;
    rir?: number;
    durationSeconds?: number;
    restSeconds?: number;
    tag?: string;
    notes?: string;
    clientSetId?: string;
}
export interface CompleteWorkoutInput {
    sessionId: string;
    notes?: string;
    isPublic?: boolean;
}
declare class WorkoutSessionService {
    /**
     * Start a new workout session
     */
    startSession(userId: string, workoutPlan?: any, clientId?: string): Promise<WorkoutSession>;
    /**
     * Get current active session for user
     */
    getActiveSession(userId: string): Promise<WorkoutSession | null>;
    /**
     * Get session by ID
     */
    getSession(userId: string, sessionId: string): Promise<WorkoutSession>;
    /**
     * Log a single set
     */
    logSet(userId: string, input: LogSetInput): Promise<{
        session: WorkoutSession;
        setLogged: LoggedSet;
        prsAchieved: SessionPR[];
    }>;
    /**
     * Update an existing set
     */
    updateSet(userId: string, setId: string, updates: Partial<LogSetInput>): Promise<LoggedSet>;
    /**
     * Delete a set from the session
     */
    deleteSet(userId: string, setId: string): Promise<boolean>;
    /**
     * Pause the workout session
     */
    pauseSession(userId: string, sessionId: string): Promise<WorkoutSession>;
    /**
     * Resume a paused session
     */
    resumeSession(userId: string, sessionId: string): Promise<WorkoutSession>;
    /**
     * Update rest timer state
     */
    updateRestTimer(userId: string, sessionId: string, remaining: number, total: number): Promise<WorkoutSession>;
    /**
     * Complete the workout session and convert to permanent workout
     */
    completeSession(userId: string, input: CompleteWorkoutInput): Promise<any>;
    /**
     * Abandon workout session (discard without saving)
     */
    abandonSession(userId: string, sessionId: string, reason?: string): Promise<boolean>;
    /**
     * Get recoverable sessions (archived but not recovered)
     */
    getRecoverableSessions(userId: string, limit?: number): Promise<any[]>;
    /**
     * Recover an archived session
     */
    recoverSession(userId: string, archivedSessionId: string): Promise<WorkoutSession>;
    /**
     * Get muscle breakdown for a session
     */
    getMuscleBreakdown(userId: string, sessionId: string): Promise<MuscleActivationSummary[]>;
    private calculateSetTU;
    private checkForPRs;
    private updateMuscleSummary;
    private recalculateMuscleSummary;
    private estimateCalories;
    private insertNormalizedSet;
    private convertSetsToExerciseData;
    private convertMuscleWorkedToActivations;
    private mapRowToSession;
}
export declare const workoutSessionService: WorkoutSessionService;
export {};
