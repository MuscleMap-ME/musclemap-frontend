/**
 * Identity Communities Service
 *
 * Handles automatic community joining based on user identities:
 * - Link identities to default communities
 * - Auto-join users when they select an identity
 * - Suggest identity-related communities
 *
 * Note: This module uses the new "identity" terminology but queries
 * the renamed tables (identities, identity_community_links)
 */
export interface IdentityCommunityLink {
    id: string;
    identityId: string;
    communityId: number;
    isDefault: boolean;
    priority: number;
    createdAt: Date;
}
export interface LinkedCommunity {
    communityId: number;
    communityName: string;
    communityDescription?: string;
    communitySlug: string;
    memberCount: number;
    isDefault: boolean;
    priority: number;
}
export interface IdentitySuggestion {
    identityId: string;
    identityName: string;
    communities: LinkedCommunity[];
}
export interface Identity {
    id: string;
    name: string;
    philosophy?: string;
    description?: string;
    focusAreas?: string[];
    iconUrl?: string;
    categoryId?: string;
    ptTestId?: string;
    institution?: string;
    recommendedEquipment?: string[];
}
export declare const identityCommunitiesService: {
    /**
     * Get all identities
     */
    getAllIdentities(): Promise<Identity[]>;
    /**
     * Get identity by ID
     */
    getIdentityById(identityId: string): Promise<Identity | null>;
    /**
     * Get identities by category
     */
    getIdentitiesByCategory(categoryId: string): Promise<Identity[]>;
    /**
     * Link a community to an identity
     */
    linkCommunity(identityId: string, communityId: number, options?: {
        isDefault?: boolean;
        priority?: number;
    }): Promise<IdentityCommunityLink>;
    /**
     * Unlink a community from an identity
     */
    unlinkCommunity(identityId: string, communityId: number): Promise<void>;
    /**
     * Get linked communities for an identity
     */
    getLinkedCommunities(identityId: string): Promise<LinkedCommunity[]>;
    /**
     * Get default communities for an identity (ones to auto-join)
     */
    getDefaultCommunities(identityId: string): Promise<LinkedCommunity[]>;
    /**
     * Auto-join user to identity's default communities
     * Called when user selects an identity
     */
    autoJoinDefaultCommunities(userId: string, identityId: string): Promise<number[]>;
    /**
     * Get suggested communities for a user based on their identity
     * Excludes communities they're already a member of
     */
    getSuggestedCommunities(userId: string): Promise<LinkedCommunity[]>;
    /**
     * Get all identities with their linked communities
     */
    getAllIdentitiesWithCommunities(): Promise<IdentitySuggestion[]>;
    /**
     * Handle identity change for a user
     * - Leave old identity's auto-join communities (optional)
     * - Join new identity's default communities
     */
    handleIdentityChange(userId: string, oldIdentityId: string | null, newIdentityId: string, options?: {
        leaveOldCommunities?: boolean;
    }): Promise<{
        joined: number[];
        left: number[];
    }>;
    /**
     * Bulk link communities to an identity (admin function)
     */
    bulkLinkCommunities(identityId: string, communityLinks: Array<{
        communityId: number;
        isDefault?: boolean;
        priority?: number;
    }>): Promise<number>;
};
export default identityCommunitiesService;
