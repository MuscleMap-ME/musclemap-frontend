"use strict";
/**
 * Identity Communities Service
 *
 * Handles automatic community joining based on user identities:
 * - Link identities to default communities
 * - Auto-join users when they select an identity
 * - Suggest identity-related communities
 *
 * Note: This module uses the new "identity" terminology but queries
 * the renamed tables (identities, identity_community_links)
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.identityCommunitiesService = void 0;
const client_1 = require("../../db/client");
const logger_1 = require("../../lib/logger");
const log = logger_1.loggers.core;
// ============================================
// SERVICE
// ============================================
exports.identityCommunitiesService = {
    /**
     * Get all identities
     */
    async getAllIdentities() {
        const rows = await (0, client_1.queryAll)('SELECT * FROM identities ORDER BY name');
        return rows.map((r) => ({
            id: r.id,
            name: r.name,
            philosophy: r.philosophy || undefined,
            description: r.description || undefined,
            focusAreas: r.focus_areas || undefined,
            iconUrl: r.icon_url || undefined,
            categoryId: r.category_id || undefined,
            ptTestId: r.pt_test_id || undefined,
            institution: r.institution || undefined,
            recommendedEquipment: r.recommended_equipment || undefined,
        }));
    },
    /**
     * Get identity by ID
     */
    async getIdentityById(identityId) {
        const row = await (0, client_1.queryOne)('SELECT * FROM identities WHERE id = $1', [identityId]);
        if (!row)
            return null;
        return {
            id: row.id,
            name: row.name,
            philosophy: row.philosophy || undefined,
            description: row.description || undefined,
            focusAreas: row.focus_areas || undefined,
            iconUrl: row.icon_url || undefined,
            categoryId: row.category_id || undefined,
            ptTestId: row.pt_test_id || undefined,
            institution: row.institution || undefined,
            recommendedEquipment: row.recommended_equipment || undefined,
        };
    },
    /**
     * Get identities by category
     */
    async getIdentitiesByCategory(categoryId) {
        const rows = await (0, client_1.queryAll)('SELECT * FROM identities WHERE category_id = $1 ORDER BY name', [categoryId]);
        return rows.map((r) => ({
            id: r.id,
            name: r.name,
            philosophy: r.philosophy || undefined,
            description: r.description || undefined,
            focusAreas: r.focus_areas || undefined,
            iconUrl: r.icon_url || undefined,
            categoryId: r.category_id || undefined,
            ptTestId: r.pt_test_id || undefined,
            institution: r.institution || undefined,
            recommendedEquipment: r.recommended_equipment || undefined,
        }));
    },
    /**
     * Link a community to an identity
     */
    async linkCommunity(identityId, communityId, options = {}) {
        const { isDefault = false, priority = 100 } = options;
        const id = `icl_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
        await (0, client_1.query)(`INSERT INTO identity_community_links (id, identity_id, community_id, auto_join, recommended, priority)
       VALUES ($1, $2, $3, $4, $5, $6)
       ON CONFLICT DO NOTHING`, [id, identityId, communityId, isDefault, true, priority]);
        return {
            id,
            identityId,
            communityId,
            isDefault,
            priority,
            createdAt: new Date(),
        };
    },
    /**
     * Unlink a community from an identity
     */
    async unlinkCommunity(identityId, communityId) {
        await (0, client_1.query)('DELETE FROM identity_community_links WHERE identity_id = $1 AND community_id = $2', [identityId, communityId]);
    },
    /**
     * Get linked communities for an identity
     */
    async getLinkedCommunities(identityId) {
        const rows = await (0, client_1.queryAll)(`SELECT c.id as community_id, c.name, c.description, c.slug,
              (SELECT COUNT(*) FROM community_members WHERE community_id = c.id AND status = 'active') as member_count,
              icl.auto_join, icl.priority
       FROM identity_community_links icl
       JOIN communities c ON c.id = icl.community_id
       WHERE icl.identity_id = $1
       ORDER BY icl.priority ASC, c.name ASC`, [identityId]);
        return rows.map((r) => ({
            communityId: r.community_id,
            communityName: r.name,
            communityDescription: r.description || undefined,
            communitySlug: r.slug,
            memberCount: parseInt(r.member_count),
            isDefault: r.auto_join,
            priority: r.priority,
        }));
    },
    /**
     * Get default communities for an identity (ones to auto-join)
     */
    async getDefaultCommunities(identityId) {
        const rows = await (0, client_1.queryAll)(`SELECT c.id as community_id, c.name, c.description, c.slug,
              (SELECT COUNT(*) FROM community_members WHERE community_id = c.id AND status = 'active') as member_count,
              icl.auto_join, icl.priority
       FROM identity_community_links icl
       JOIN communities c ON c.id = icl.community_id
       WHERE icl.identity_id = $1 AND icl.auto_join = true
       ORDER BY icl.priority ASC`, [identityId]);
        return rows.map((r) => ({
            communityId: r.community_id,
            communityName: r.name,
            communityDescription: r.description || undefined,
            communitySlug: r.slug,
            memberCount: parseInt(r.member_count),
            isDefault: r.auto_join,
            priority: r.priority,
        }));
    },
    /**
     * Auto-join user to identity's default communities
     * Called when user selects an identity
     */
    async autoJoinDefaultCommunities(userId, identityId) {
        const defaultCommunities = await this.getDefaultCommunities(identityId);
        if (defaultCommunities.length === 0) {
            log.info({ userId, identityId }, 'No default communities for identity');
            return [];
        }
        const joinedCommunityIds = [];
        await (0, client_1.transaction)(async (client) => {
            for (const community of defaultCommunities) {
                // Check if already a member
                const existing = await client.query('SELECT id, status FROM community_members WHERE user_id = $1 AND community_id = $2', [userId, community.communityId]);
                if (existing.rowCount && existing.rowCount > 0) {
                    const member = existing.rows[0];
                    if (member.status === 'active') {
                        // Already an active member
                        continue;
                    }
                    // Reactivate membership
                    await client.query(`UPDATE community_members SET status = 'active', joined_at = NOW() WHERE id = $1`, [member.id]);
                }
                else {
                    // Create new membership
                    const memberId = `cm_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
                    await client.query(`INSERT INTO community_members (id, user_id, community_id, role, status, joined_by)
             VALUES ($1, $2, $3, 'member', 'active', 'identity_auto_join')`, [memberId, userId, community.communityId]);
                }
                joinedCommunityIds.push(community.communityId);
                log.info({ userId, communityId: community.communityId, identityId }, 'Auto-joined user to identity community');
            }
        });
        return joinedCommunityIds;
    },
    /**
     * Get suggested communities for a user based on their identity
     * Excludes communities they're already a member of
     */
    async getSuggestedCommunities(userId) {
        // Get user's identity
        const user = await (0, client_1.queryOne)('SELECT current_identity_id FROM users WHERE id = $1', [userId]);
        if (!user?.current_identity_id) {
            return [];
        }
        const rows = await (0, client_1.queryAll)(`SELECT c.id as community_id, c.name, c.description, c.slug,
              (SELECT COUNT(*) FROM community_members WHERE community_id = c.id AND status = 'active') as member_count,
              icl.auto_join, icl.priority
       FROM identity_community_links icl
       JOIN communities c ON c.id = icl.community_id
       WHERE icl.identity_id = $1
         AND NOT EXISTS (
           SELECT 1 FROM community_members cm
           WHERE cm.user_id = $2 AND cm.community_id = c.id AND cm.status = 'active'
         )
       ORDER BY icl.priority ASC, c.name ASC`, [user.current_identity_id, userId]);
        return rows.map((r) => ({
            communityId: r.community_id,
            communityName: r.name,
            communityDescription: r.description || undefined,
            communitySlug: r.slug,
            memberCount: parseInt(r.member_count),
            isDefault: r.auto_join,
            priority: r.priority,
        }));
    },
    /**
     * Get all identities with their linked communities
     */
    async getAllIdentitiesWithCommunities() {
        const identities = await (0, client_1.queryAll)('SELECT id, name FROM identities ORDER BY name');
        const results = [];
        for (const identity of identities) {
            const communities = await this.getLinkedCommunities(identity.id);
            results.push({
                identityId: identity.id,
                identityName: identity.name,
                communities,
            });
        }
        return results;
    },
    /**
     * Handle identity change for a user
     * - Leave old identity's auto-join communities (optional)
     * - Join new identity's default communities
     */
    async handleIdentityChange(userId, oldIdentityId, newIdentityId, options = {}) {
        const { leaveOldCommunities = false } = options;
        let leftCommunities = [];
        let joinedCommunities = [];
        await (0, client_1.transaction)(async (client) => {
            // Optionally leave old identity's auto-joined communities
            if (leaveOldCommunities && oldIdentityId) {
                const oldDefaults = await this.getDefaultCommunities(oldIdentityId);
                const newDefaults = await this.getDefaultCommunities(newIdentityId);
                const newDefaultIds = new Set(newDefaults.map((c) => c.communityId));
                for (const community of oldDefaults) {
                    // Only leave if not also in new identity's defaults
                    if (!newDefaultIds.has(community.communityId)) {
                        // Check if joined via auto-join
                        const membership = await client.query(`SELECT id FROM community_members
               WHERE user_id = $1 AND community_id = $2 AND joined_by = 'identity_auto_join'`, [userId, community.communityId]);
                        if (membership.rowCount && membership.rowCount > 0) {
                            await client.query(`UPDATE community_members SET status = 'left', left_at = NOW()
                 WHERE user_id = $1 AND community_id = $2`, [userId, community.communityId]);
                            leftCommunities.push(community.communityId);
                        }
                    }
                }
            }
            // Update user's current identity
            await client.query('UPDATE users SET current_identity_id = $1, updated_at = NOW() WHERE id = $2', [newIdentityId, userId]);
        });
        // Join new identity's default communities
        joinedCommunities = await this.autoJoinDefaultCommunities(userId, newIdentityId);
        return {
            joined: joinedCommunities,
            left: leftCommunities,
        };
    },
    /**
     * Bulk link communities to an identity (admin function)
     */
    async bulkLinkCommunities(identityId, communityLinks) {
        let linked = 0;
        await (0, client_1.transaction)(async (client) => {
            for (const link of communityLinks) {
                await client.query(`INSERT INTO identity_community_links (id, identity_id, community_id, auto_join, recommended, priority)
           VALUES ($1, $2, $3, $4, $5, $6)
           ON CONFLICT DO NOTHING`, [
                    `icl_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
                    identityId,
                    link.communityId,
                    link.isDefault ?? false,
                    true,
                    link.priority ?? 100,
                ]);
                linked++;
            }
        });
        return linked;
    },
};
exports.default = exports.identityCommunitiesService;
//# sourceMappingURL=index.js.map