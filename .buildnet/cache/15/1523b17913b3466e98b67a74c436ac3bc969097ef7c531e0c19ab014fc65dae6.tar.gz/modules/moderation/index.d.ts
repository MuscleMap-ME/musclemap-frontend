/**
 * Moderation Module
 *
 * Handles hangout moderation actions:
 * - Ban/unban users from hangouts
 * - Remove leaderboard records
 * - Approve/reject membership requests
 * - Warn and mute users
 * - Audit logging of all actions
 */
export declare const ACTION_TYPES: {
    readonly REMOVE_RECORD: "remove_record";
    readonly FLAG_SUSPICIOUS: "flag_suspicious";
    readonly BAN_USER: "ban_user";
    readonly UNBAN_USER: "unban_user";
    readonly APPROVE_MEMBERSHIP: "approve_membership";
    readonly REJECT_MEMBERSHIP: "reject_membership";
    readonly PIN_ACHIEVEMENT: "pin_achievement";
    readonly UNPIN_ACHIEVEMENT: "unpin_achievement";
    readonly WARN_USER: "warn_user";
    readonly MUTE_USER: "mute_user";
    readonly UNMUTE_USER: "unmute_user";
};
export type ActionType = (typeof ACTION_TYPES)[keyof typeof ACTION_TYPES];
export interface ModerationAction {
    id: string;
    hangoutId?: number;
    virtualHangoutId?: number;
    moderatorId: string;
    moderatorUsername?: string;
    targetUserId?: string;
    targetUsername?: string;
    targetEntryId?: string;
    actionType: ActionType;
    reason?: string;
    metadata: Record<string, unknown>;
    createdAt: Date;
}
export interface UserModerationStatus {
    userId: string;
    isBanned: boolean;
    isMuted: boolean;
    mutedUntil?: Date;
    warningCount: number;
    lastWarningAt?: Date;
}
export declare const moderationService: {
    /**
     * Check if a user has permission to perform a moderation action
     */
    checkPermission(moderatorId: string, hangoutId?: number, virtualHangoutId?: number, action?: ActionType): Promise<{
        hasPermission: boolean;
        role: number;
    }>;
    /**
     * Log a moderation action
     */
    logAction(params: {
        hangoutId?: number;
        virtualHangoutId?: number;
        moderatorId: string;
        targetUserId?: string;
        targetEntryId?: string;
        actionType: ActionType;
        reason?: string;
        metadata?: Record<string, unknown>;
    }): Promise<ModerationAction>;
    /**
     * Ban a user from a hangout
     */
    banUser(params: {
        hangoutId?: number;
        virtualHangoutId?: number;
        moderatorId: string;
        targetUserId: string;
        reason?: string;
    }): Promise<ModerationAction>;
    /**
     * Unban a user from a hangout
     */
    unbanUser(params: {
        hangoutId?: number;
        virtualHangoutId?: number;
        moderatorId: string;
        targetUserId: string;
        reason?: string;
    }): Promise<ModerationAction>;
    /**
     * Remove a leaderboard record
     */
    removeRecord(params: {
        hangoutId?: number;
        virtualHangoutId?: number;
        moderatorId: string;
        entryId: string;
        reason?: string;
    }): Promise<ModerationAction>;
    /**
     * Warn a user
     */
    warnUser(params: {
        hangoutId?: number;
        virtualHangoutId?: number;
        moderatorId: string;
        targetUserId: string;
        reason: string;
    }): Promise<ModerationAction>;
    /**
     * Mute a user with optional duration
     */
    muteUser(params: {
        hangoutId?: number;
        virtualHangoutId?: number;
        moderatorId: string;
        targetUserId: string;
        reason: string;
        durationMinutes?: number;
    }): Promise<ModerationAction>;
    /**
     * Unmute a user
     */
    unmuteUser(params: {
        hangoutId?: number;
        virtualHangoutId?: number;
        moderatorId: string;
        targetUserId: string;
        reason?: string;
    }): Promise<ModerationAction>;
    /**
     * Get moderation action history for a hangout
     */
    getHangoutActions(hangoutId?: number, virtualHangoutId?: number, options?: {
        limit?: number;
        offset?: number;
        actionType?: ActionType;
    }): Promise<{
        actions: ModerationAction[];
        total: number;
    }>;
    /**
     * Get moderation actions against a user
     */
    getUserActions(targetUserId: string, options?: {
        limit?: number;
        offset?: number;
    }): Promise<{
        actions: ModerationAction[];
        total: number;
    }>;
    /**
     * Get user's moderation status in a hangout
     */
    getUserModerationStatus(userId: string, hangoutId?: number, virtualHangoutId?: number): Promise<UserModerationStatus>;
    /**
     * Get banned users in a hangout
     */
    getBannedUsers(hangoutId?: number, virtualHangoutId?: number): Promise<Array<{
        userId: string;
        username: string;
        bannedAt?: Date;
    }>>;
};
export default moderationService;
