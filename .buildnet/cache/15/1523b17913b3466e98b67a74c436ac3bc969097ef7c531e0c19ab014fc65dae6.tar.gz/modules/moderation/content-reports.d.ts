/**
 * Content Reports Service
 *
 * Handles user reporting of inappropriate content:
 * - Report posts, comments, messages, users
 * - Track report status and resolution
 * - Automatic flagging for review
 * - Moderation history
 */
export type ContentType = 'post' | 'comment' | 'message' | 'user' | 'resource' | 'event' | 'hangout';
export type ReportReason = 'spam' | 'harassment' | 'hate_speech' | 'violence' | 'nudity' | 'misinformation' | 'self_harm' | 'impersonation' | 'copyright' | 'other';
export type ReportStatus = 'pending' | 'reviewing' | 'resolved' | 'dismissed' | 'escalated';
export type ModerationAction = 'warning' | 'content_removed' | 'content_hidden' | 'user_muted' | 'user_suspended' | 'user_banned' | 'no_action';
export interface ContentReport {
    id: string;
    reporterId: string;
    contentType: ContentType;
    contentId: string;
    reportedUserId: string;
    communityId?: number;
    reason: ReportReason;
    description?: string;
    status: ReportStatus;
    assignedTo?: string;
    resolvedAt?: Date;
    resolvedBy?: string;
    resolution?: string;
    actionTaken?: ModerationAction;
    createdAt: Date;
}
export interface ContentReportWithDetails extends ContentReport {
    reporterUsername: string;
    reportedUsername: string;
    communityName?: string;
    contentPreview?: string;
}
export interface UserModerationHistory {
    id: string;
    userId: string;
    action: ModerationAction;
    reason: string;
    contentReportId?: string;
    moderatorId: string;
    expiresAt?: Date;
    notes?: string;
    createdAt: Date;
}
export interface ModerationStats {
    pendingReports: number;
    resolvedToday: number;
    totalReports: number;
    byReason: Record<ReportReason, number>;
    byStatus: Record<ReportStatus, number>;
}
export declare const contentReportsService: {
    /**
     * Submit a content report
     */
    submitReport(reporterId: string, report: {
        contentType: ContentType;
        contentId: string;
        reportedUserId: string;
        communityId?: number;
        reason: ReportReason;
        description?: string;
    }): Promise<ContentReport>;
    /**
     * Check if content should be auto-escalated based on report volume
     */
    checkAutoEscalation(contentType: ContentType, contentId: string): Promise<void>;
    /**
     * Get report by ID
     */
    getReport(reportId: string): Promise<ContentReportWithDetails | null>;
    /**
     * Get pending reports (for moderators)
     */
    getPendingReports(options?: {
        communityId?: number;
        status?: ReportStatus | ReportStatus[];
        reason?: ReportReason;
        limit?: number;
        offset?: number;
    }): Promise<{
        reports: ContentReportWithDetails[];
        total: number;
    }>;
    /**
     * Resolve a report
     */
    resolveReport(reportId: string, moderatorId: string, resolution: {
        status: "resolved" | "dismissed";
        resolution: string;
        actionTaken: ModerationAction;
    }): Promise<void>;
    /**
     * Assign report to moderator
     */
    assignReport(reportId: string, moderatorId: string): Promise<void>;
    /**
     * Get user's moderation history
     */
    getUserModerationHistory(userId: string): Promise<UserModerationHistory[]>;
    /**
     * Check if user is currently under moderation action
     */
    getActiveModeration(userId: string): Promise<UserModerationHistory | null>;
    /**
     * Apply moderation action to user
     */
    applyModerationAction(userId: string, moderatorId: string, action: {
        action: ModerationAction;
        reason: string;
        durationHours?: number;
        notes?: string;
    }): Promise<UserModerationHistory>;
    /**
     * Get moderation statistics
     */
    getStats(communityId?: number): Promise<ModerationStats>;
    /**
     * Get reports for a specific user (as reporter or reported)
     */
    getUserReports(userId: string, role: "reporter" | "reported"): Promise<ContentReport[]>;
};
export default contentReportsService;
