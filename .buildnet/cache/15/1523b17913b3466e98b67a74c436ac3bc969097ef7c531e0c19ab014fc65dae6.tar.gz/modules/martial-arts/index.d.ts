/**
 * Martial Arts Module
 *
 * Handles martial arts technique tracking:
 * - Disciplines (Boxing, BJJ, Wrestling, MCMAP, etc.)
 * - Techniques with progressions and prerequisites
 * - User progress and proficiency tracking
 * - Practice logging
 */
export interface MartialArtsDiscipline {
    id: string;
    name: string;
    description?: string;
    originCountry?: string;
    focusAreas: string[];
    icon?: string;
    color?: string;
    orderIndex: number;
    isMilitary: boolean;
}
export interface MartialArtsCategory {
    id: string;
    disciplineId: string;
    name: string;
    description?: string;
    orderIndex: number;
}
export interface MartialArtsTechnique {
    id: string;
    disciplineId: string;
    categoryId?: string;
    name: string;
    description?: string;
    category: string;
    difficulty: number;
    prerequisites: string[];
    keyPoints: string[];
    commonMistakes: string[];
    drillSuggestions: string[];
    videoUrl?: string;
    thumbnailUrl?: string;
    muscleGroups: string[];
    xpReward: number;
    creditReward: number;
    tier: number;
    position: number;
}
export interface UserTechniqueProgress {
    id: string;
    userId: string;
    techniqueId: string;
    status: 'locked' | 'available' | 'learning' | 'proficient' | 'mastered';
    proficiency: number;
    practiceCount: number;
    totalPracticeMinutes: number;
    lastPracticed?: Date;
    masteredAt?: Date;
    notes?: string;
    createdAt: Date;
    updatedAt: Date;
}
export interface TechniquePracticeLog {
    id: string;
    userId: string;
    techniqueId: string;
    practiceDate: Date;
    durationMinutes: number;
    repsPerformed?: number;
    roundsPerformed?: number;
    partnerDrill: boolean;
    notes?: string;
    createdAt: Date;
}
export interface DisciplineWithCategories extends MartialArtsDiscipline {
    categories: MartialArtsCategory[];
}
export interface TechniqueWithProgress extends MartialArtsTechnique {
    progress?: UserTechniqueProgress;
}
export declare const martialArtsService: {
    /**
     * Get all martial arts disciplines
     */
    getDisciplines(options?: {
        militaryOnly?: boolean;
    }): Promise<MartialArtsDiscipline[]>;
    /**
     * Get a discipline by ID with its categories
     */
    getDiscipline(disciplineId: string): Promise<DisciplineWithCategories | null>;
    /**
     * Get all techniques for a discipline
     */
    getTechniques(disciplineId: string): Promise<MartialArtsTechnique[]>;
    /**
     * Get a specific technique
     */
    getTechnique(techniqueId: string): Promise<MartialArtsTechnique | null>;
    /**
     * Get user progress for a discipline's techniques
     */
    getUserDisciplineProgress(userId: string, disciplineId: string): Promise<TechniqueWithProgress[]>;
    /**
     * Get user's overall martial arts progress summary
     */
    getUserSummary(userId: string): Promise<{
        totalTechniques: number;
        masteredTechniques: number;
        learningTechniques: number;
        availableTechniques: number;
        totalPracticeMinutes: number;
        disciplineProgress: {
            disciplineId: string;
            disciplineName: string;
            mastered: number;
            total: number;
        }[];
    }>;
    /**
     * Log a practice session for a technique
     */
    logPractice(params: {
        userId: string;
        techniqueId: string;
        durationMinutes: number;
        repsPerformed?: number;
        roundsPerformed?: number;
        partnerDrill?: boolean;
        notes?: string;
    }): Promise<TechniquePracticeLog>;
    /**
     * Mark a technique as mastered
     */
    masterTechnique(params: {
        userId: string;
        techniqueId: string;
    }): Promise<{
        success: boolean;
        creditsAwarded?: number;
        xpAwarded?: number;
        error?: string;
    }>;
    /**
     * Get practice history for a user
     */
    getPracticeHistory(userId: string, options?: {
        limit?: number;
        offset?: number;
        disciplineId?: string;
    }): Promise<{
        logs: (TechniquePracticeLog & {
            techniqueName: string;
            disciplineName: string;
        })[];
        total: number;
    }>;
    /**
     * Update user notes for a technique
     */
    updateNotes(userId: string, techniqueId: string, notes: string): Promise<void>;
    /**
     * Get leaderboard for a discipline
     */
    getDisciplineLeaderboard(disciplineId: string, options?: {
        limit?: number;
    }): Promise<{
        userId: string;
        username: string;
        masteredCount: number;
        totalPracticeMinutes: number;
    }[]>;
};
export default martialArtsService;
