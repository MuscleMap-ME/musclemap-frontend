/**
 * Community Analytics Service
 *
 * Tracks and analyzes community health and engagement:
 * - Daily analytics aggregation
 * - Health scoring
 * - Growth trends
 * - Engagement metrics
 */
export interface CommunityDailyAnalytics {
    communityId: number;
    date: Date;
    totalMembers: number;
    newMembers: number;
    activeMembers: number;
    posts: number;
    comments: number;
    reactions: number;
    events: number;
    eventAttendees: number;
    hangoutCheckIns: number;
    uniquePosters: number;
    avgResponseTimeMinutes?: number;
}
export interface CommunityHealthScore {
    communityId: number;
    calculatedAt: Date;
    overallScore: number;
    engagementScore: number;
    growthScore: number;
    retentionScore: number;
    contentQualityScore: number;
    moderationScore: number;
    trend: 'improving' | 'stable' | 'declining';
    insights: string[];
}
export interface CommunityGrowthTrend {
    period: string;
    memberCount: number;
    change: number;
    changePercent: number;
}
export interface EngagementBreakdown {
    posts: number;
    comments: number;
    reactions: number;
    events: number;
    checkIns: number;
    total: number;
}
export interface TopContributor {
    userId: string;
    username: string;
    displayName?: string;
    avatarUrl?: string;
    contributions: number;
    posts: number;
    comments: number;
    reactions: number;
}
export declare const communityAnalyticsService: {
    /**
     * Record or update daily analytics for a community
     */
    recordDailyAnalytics(communityId: number): Promise<CommunityDailyAnalytics>;
    /**
     * Get daily analytics for a date range
     */
    getDailyAnalytics(communityId: number, options?: {
        startDate?: Date;
        endDate?: Date;
        limit?: number;
    }): Promise<CommunityDailyAnalytics[]>;
    /**
     * Calculate and store community health score
     */
    calculateHealthScore(communityId: number): Promise<CommunityHealthScore>;
    /**
     * Get latest health score for a community
     */
    getLatestHealthScore(communityId: number): Promise<CommunityHealthScore | null>;
    /**
     * Get health score history
     */
    getHealthScoreHistory(communityId: number, options?: {
        limit?: number;
    }): Promise<CommunityHealthScore[]>;
    /**
     * Get membership growth trends
     */
    getGrowthTrends(communityId: number, period?: "daily" | "weekly" | "monthly", limit?: number): Promise<CommunityGrowthTrend[]>;
    /**
     * Get engagement breakdown for a period
     */
    getEngagementBreakdown(communityId: number, options?: {
        startDate?: Date;
        endDate?: Date;
    }): Promise<EngagementBreakdown>;
    /**
     * Get top contributors
     */
    getTopContributors(communityId: number, options?: {
        days?: number;
        limit?: number;
    }): Promise<TopContributor[]>;
    /**
     * Get community comparison (for admins/moderators)
     */
    compareCommunities(communityIds: number[]): Promise<Array<{
        communityId: number;
        communityName: string;
        healthScore: number;
        memberCount: number;
        weeklyGrowth: number;
        weeklyEngagement: number;
    }>>;
};
export default communityAnalyticsService;
