/**
 * Venue Records Service
 *
 * Manages exercise-specific records at venues:
 * - Record claiming (manual and auto-detected from workouts)
 * - Leaderboard management
 * - Verification (video/witness) for top 3 positions
 * - Privacy-aware queries
 */
export type RecordType = 'max_weight' | 'max_reps' | 'fastest_time' | 'max_distance' | 'max_1rm';
export type VerificationStatus = 'unverified' | 'self_verified' | 'witness_verified' | 'video_verified' | 'pending_verification';
export interface VenueExerciseRecord {
    id: string;
    venueId: string;
    exerciseId: string;
    userId: string;
    recordType: RecordType;
    recordValue: number;
    recordUnit: string;
    workoutSessionId?: string;
    setId?: string;
    repsAtWeight?: number;
    weightAtReps?: number;
    verificationStatus: VerificationStatus;
    videoUrl?: string;
    witnessCount: number;
    achievedAt: Date;
    verifiedAt?: Date;
    conditions?: Record<string, unknown>;
    notes?: string;
    previousRecordValue?: number;
    previousRecordHolderId?: string;
    createdAt: Date;
    updatedAt: Date;
}
export interface ClaimRecordInput {
    venueId: string;
    exerciseId: string;
    recordType: RecordType;
    recordValue: number;
    recordUnit: string;
    repsAtWeight?: number;
    weightAtReps?: number;
    workoutSessionId?: string;
    setId?: string;
    conditions?: Record<string, unknown>;
    notes?: string;
}
export interface RecordClaimResult {
    record: VenueExerciseRecord;
    isNewRecord: boolean;
    isVenueBest: boolean;
    previousValue?: number;
    previousHolderId?: string;
    rank: number;
    requiresVerification: boolean;
    achievements: string[];
}
export interface LeaderboardEntry {
    rank: number;
    userId: string;
    username: string;
    avatarUrl?: string;
    value: number;
    unit: string;
    achievedAt: Date;
    verificationStatus: VerificationStatus;
    isCurrentUser: boolean;
}
export interface VenueLeaderboard {
    venueId: string;
    exerciseId: string;
    recordType: RecordType;
    entries: LeaderboardEntry[];
    totalParticipants: number;
    myRank?: number;
    myRecord?: VenueExerciseRecord;
    lastUpdatedAt: Date;
}
/**
 * Claim a record at a venue
 */
export declare function claimRecord(userId: string, input: ClaimRecordInput): Promise<RecordClaimResult>;
/**
 * Auto-detect records from a completed workout session
 */
export declare function autoDetectRecords(userId: string, workoutSessionId: string, venueId: string): Promise<RecordClaimResult[]>;
/**
 * Get leaderboard for a venue/exercise/record type
 */
export declare function getVenueLeaderboard(venueId: string, exerciseId: string, recordType: RecordType, limit?: number, currentUserId?: string): Promise<VenueLeaderboard>;
/**
 * Get user's records at venues
 */
export declare function getMyVenueRecords(userId: string, venueId?: string, limit?: number, cursor?: {
    achievedAt: Date;
    id: string;
}): Promise<{
    records: VenueExerciseRecord[];
    hasMore: boolean;
}>;
/**
 * Submit video verification for a record
 */
export declare function submitVideoVerification(userId: string, recordId: string, videoUrl: string): Promise<VenueExerciseRecord>;
/**
 * Witness a record
 */
export declare function witnessRecord(witnessUserId: string, recordId: string, latitude?: number, longitude?: number, attestation?: string): Promise<VenueExerciseRecord>;
/**
 * Refresh leaderboard cache
 */
export declare function refreshLeaderboard(venueId: string, exerciseId: string, recordType: RecordType): Promise<void>;
/**
 * Get global records for an exercise across all venues
 */
export declare function getGlobalExerciseRecords(exerciseId: string, recordType: RecordType, limit?: number): Promise<LeaderboardEntry[]>;
export declare const venueRecordsService: {
    claimRecord: typeof claimRecord;
    autoDetectRecords: typeof autoDetectRecords;
    getVenueLeaderboard: typeof getVenueLeaderboard;
    getMyVenueRecords: typeof getMyVenueRecords;
    submitVideoVerification: typeof submitVideoVerification;
    witnessRecord: typeof witnessRecord;
    refreshLeaderboard: typeof refreshLeaderboard;
    getGlobalExerciseRecords: typeof getGlobalExerciseRecords;
};
