/**
 * Streaks Service
 *
 * Manages multiple streak types:
 * - workout: consecutive days with completed workouts
 * - nutrition: consecutive days logging food
 * - sleep: consecutive days logging sleep
 * - social: consecutive days with social interactions
 *
 * Each streak type has its own milestones and rewards.
 */
export type StreakType = 'workout' | 'nutrition' | 'sleep' | 'social' | 'login';
interface StreakInfo {
    streakType: StreakType;
    currentStreak: number;
    longestStreak: number;
    lastActivityDate: string | null;
    milestonesClaimed: Record<string, boolean>;
    nextMilestone: {
        days: number;
        credits: number;
        xp: number;
        badge?: string;
    } | null;
    unclaimedMilestones: Array<{
        days: number;
        credits: number;
        xp: number;
        badge?: string;
    }>;
}
interface AllStreaks {
    streaks: StreakInfo[];
    totalCurrentDays: number;
    totalLongestDays: number;
}
export declare const streaksService: {
    /**
     * Get all streaks for a user
     */
    getAllStreaks(userId: string): Promise<AllStreaks>;
    /**
     * Get a specific streak type
     */
    getStreak(userId: string, streakType: StreakType): Promise<StreakInfo>;
    /**
     * Record activity for a streak type
     * Call this when user completes relevant action (workout, logs food, etc.)
     */
    recordActivity(userId: string, streakType: StreakType): Promise<{
        newStreak: number;
        isNewRecord: boolean;
        unlockedMilestones: Array<{
            days: number;
            credits: number;
            xp: number;
        }>;
    }>;
    /**
     * Claim a milestone reward
     */
    claimMilestone(userId: string, streakType: StreakType, milestoneDays: number): Promise<{
        credits: number;
        xp: number;
        badge?: string;
    }>;
    /**
     * Get streak leaderboard
     */
    getLeaderboard(streakType: StreakType, limit?: number): Promise<Array<{
        userId: string;
        username: string;
        avatarUrl: string | null;
        currentStreak: number;
        longestStreak: number;
    }>>;
    /**
     * Get milestone definitions
     */
    getMilestoneDefinitions(streakType: StreakType): Array<{
        days: number;
        credits: number;
        xp: number;
        badge?: string;
    }>;
};
export {};
