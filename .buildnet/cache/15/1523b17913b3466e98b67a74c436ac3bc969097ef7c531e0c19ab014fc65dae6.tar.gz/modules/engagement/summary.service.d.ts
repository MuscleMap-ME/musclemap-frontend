/**
 * Engagement Summary Service
 *
 * Provides a unified dashboard view of all engagement systems:
 * - Daily login status and rewards
 * - All streak types and progress
 * - Daily and weekly challenges
 * - Active events
 * - Recovery score
 * - Unread notifications
 */
export interface EngagementSummary {
    dailyLogin: {
        canClaim: boolean;
        currentStreak: number;
        longestStreak: number;
        todayReward: {
            credits: number;
            xp: number;
            mysteryBoxTier: string | null;
            isMilestone: boolean;
        } | null;
        streakAtRisk: boolean;
        nextMilestone: {
            days: number;
            credits: number;
            xp: number;
        } | null;
        streakFreezesOwned: number;
    };
    streaks: {
        workout: {
            current: number;
            longest: number;
            isActive: boolean;
        };
        nutrition: {
            current: number;
            longest: number;
            isActive: boolean;
        };
        sleep: {
            current: number;
            longest: number;
            isActive: boolean;
        };
        social: {
            current: number;
            longest: number;
            isActive: boolean;
        };
        totalUnclaimedMilestones: number;
    };
    challenges: {
        daily: {
            total: number;
            completed: number;
            claimable: number;
            totalCredits: number;
            totalXp: number;
        };
        weekly: {
            progress: number;
            target: number;
            isComplete: boolean;
            isClaimable: boolean;
            credits: number;
            xp: number;
        } | null;
    };
    events: {
        active: number;
        upcoming: number;
        hasDoubleCredits: boolean;
        hasDoubleXp: boolean;
    };
    recovery: {
        score: number;
        recommendation: string;
        optimalTrainingWindow: string;
    };
    engagementScore: number;
    engagementLevel: 'low' | 'medium' | 'high' | 'excellent';
    quickActions: Array<{
        type: string;
        title: string;
        priority: number;
        action: string;
    }>;
}
export declare const engagementSummaryService: {
    /**
     * Get comprehensive engagement summary for dashboard
     */
    getSummary(userId: string): Promise<EngagementSummary>;
    /**
     * Get engagement statistics for admin dashboard
     */
    getEngagementStats(): Promise<{
        dailyActiveUsers: number;
        weeklyActiveUsers: number;
        monthlyActiveUsers: number;
        averageLoginStreak: number;
        averageEngagementScore: number;
        challengeCompletionRate: number;
        activeEvents: number;
    }>;
    /**
     * Seed sample engagement events for testing
     */
    seedSampleEvents(): Promise<number>;
};
export default engagementSummaryService;
