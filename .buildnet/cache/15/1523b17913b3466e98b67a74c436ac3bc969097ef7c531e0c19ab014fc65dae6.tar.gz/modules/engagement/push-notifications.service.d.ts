/**
 * Push Notifications Service
 *
 * Manages push notification tokens and scheduling:
 * - Token registration/unregistration
 * - Notification scheduling
 * - Smart notification timing
 * - Re-engagement campaigns
 */
export type Platform = 'ios' | 'android' | 'web';
export type NotificationType = 'streak_at_risk' | 'challenge_expiring' | 'rival_activity' | 'daily_reward' | 'event_starting' | 'workout_reminder' | 'weekly_digest' | 're_engagement';
interface PushToken {
    id: string;
    userId: string;
    token: string;
    platform: Platform;
    isActive: boolean;
    createdAt: Date;
    lastUsedAt: Date | null;
}
interface ScheduledNotification {
    id: string;
    userId: string;
    notificationType: NotificationType;
    scheduledFor: Date;
    payload: Record<string, unknown>;
    isSent: boolean;
    sentAt: Date | null;
}
export declare const pushNotificationsService: {
    /**
     * Register a push notification token
     */
    registerToken(userId: string, token: string, platform: Platform): Promise<PushToken>;
    /**
     * Unregister a push notification token
     */
    unregisterToken(userId: string, token: string): Promise<void>;
    /**
     * Get active tokens for a user
     */
    getActiveTokens(userId: string): Promise<PushToken[]>;
    /**
     * Schedule a notification
     */
    scheduleNotification(userId: string, notificationType: NotificationType, scheduledFor: Date, payload: Record<string, unknown>): Promise<ScheduledNotification>;
    /**
     * Get pending notifications ready to send
     */
    getPendingNotifications(limit?: number): Promise<ScheduledNotification[]>;
    /**
     * Mark notification as sent
     */
    markAsSent(notificationId: string): Promise<void>;
    /**
     * Cancel a scheduled notification
     */
    cancelNotification(notificationId: string): Promise<void>;
    /**
     * Schedule streak at risk notification
     */
    scheduleStreakAtRiskNotification(userId: string, streakType: string, currentStreak: number): Promise<void>;
    /**
     * Schedule challenge expiring notification
     */
    scheduleChallengeExpiringNotification(userId: string, challengeId: string, challengeName: string, expiresAt: Date): Promise<void>;
    /**
     * Schedule daily reward reminder
     */
    scheduleDailyRewardReminder(userId: string): Promise<void>;
    /**
     * Schedule re-engagement notification for inactive user
     */
    scheduleReEngagement(userId: string, daysSinceLastActivity: number): Promise<void>;
    /**
     * Check if notification can be sent (rate limits)
     */
    checkRateLimits(userId: string, scheduledFor: Date): Promise<boolean>;
    /**
     * Adjust notification time for quiet hours
     */
    adjustForQuietHours(userId: string, scheduledFor: Date): Promise<Date>;
    /**
     * Get notification history for user
     */
    getNotificationHistory(userId: string, limit?: number): Promise<ScheduledNotification[]>;
};
export {};
