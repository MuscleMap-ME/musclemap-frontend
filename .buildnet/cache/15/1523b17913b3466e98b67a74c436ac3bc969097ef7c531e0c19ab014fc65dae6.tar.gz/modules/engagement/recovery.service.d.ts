/**
 * Recovery Service
 *
 * Manages recovery tracking and rest day engagement:
 * - Overall recovery score calculation
 * - Per-muscle recovery tracking
 * - Rest day activities and rewards
 */
interface RecoveryScore {
    overallScore: number;
    muscleScores: Record<string, number>;
    factors: {
        sleep: number;
        nutrition: number;
        hydration: number;
        stress: number;
        lastWorkout: number;
    };
    recommendation: string;
    optimalTrainingWindow: string;
}
interface MuscleRecovery {
    muscle: string;
    recoveryPercent: number;
    hoursSinceTraining: number | null;
    lastTrainedAt: Date | null;
    isFullyRecovered: boolean;
}
export declare const recoveryService: {
    /**
     * Get today's recovery score
     */
    getRecoveryScore(userId: string): Promise<RecoveryScore>;
    /**
     * Calculate recovery score from various factors
     */
    calculateRecoveryScore(userId: string): Promise<RecoveryScore>;
    /**
     * Get per-muscle recovery percentages
     */
    getMuscleRecoveryMap(userId: string): Promise<Record<string, number>>;
    /**
     * Get detailed muscle recovery info
     */
    getMuscleRecoveryDetails(userId: string): Promise<MuscleRecovery[]>;
    /**
     * Log a rest day activity
     */
    logRestDayActivity(userId: string, activityType: string, metadata?: Record<string, unknown>): Promise<{
        credits: number;
        dailyCount: number;
        dailyLimit: number;
    }>;
    /**
     * Get today's rest day activity summary
     */
    getRestDayActivities(userId: string): Promise<{
        activities: Array<{
            type: string;
            name: string;
            count: number;
            limit: number;
            creditsEarned: number;
            creditsRemaining: number;
        }>;
        totalCreditsEarned: number;
        totalCreditsAvailable: number;
    }>;
    /**
     * Get available rest day activities
     */
    getActivityDefinitions(): Array<{
        type: string;
        name: string;
        credits: number;
        dailyLimit: number;
    }>;
    getSleepFactor(userId: string): Promise<number>;
    getNutritionFactor(userId: string): Promise<number>;
    getLastWorkoutFactor(userId: string): Promise<number>;
    generateRecommendation(overall: number, muscles: Record<string, number>, _factors: Record<string, number>): string;
    getOptimalWindow(score: number): string;
    /**
     * Get recovery score history
     */
    getRecoveryHistory(userId: string, days?: number): Promise<Array<{
        date: string;
        score: number;
    }>>;
};
export {};
