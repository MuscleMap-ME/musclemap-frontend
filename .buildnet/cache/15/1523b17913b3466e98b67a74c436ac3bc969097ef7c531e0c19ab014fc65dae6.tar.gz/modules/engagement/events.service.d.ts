/**
 * Events Service
 *
 * Manages time-limited engagement events:
 * - Flash sales
 * - Double credit weekends
 * - Challenge bonuses
 * - Seasonal events
 * - Community goals
 */
export type EventType = 'flash_sale' | 'double_credits' | 'challenge_bonus' | 'seasonal' | 'community_goal';
interface EventConfig {
    creditMultiplier?: number;
    xpMultiplier?: number;
    challengeMultiplier?: number;
    discountPercent?: number;
    communityTarget?: number;
    rewards?: Array<{
        threshold: number;
        credits: number;
        xp: number;
    }>;
    [key: string]: unknown;
}
interface EngagementEvent {
    id: string;
    eventType: EventType;
    name: string;
    description: string | null;
    config: EventConfig;
    startsAt: Date;
    endsAt: Date;
    isActive: boolean;
    isCurrentlyActive: boolean;
    timeRemaining: number;
}
interface EventParticipation {
    eventId: string;
    userId: string;
    progress: Record<string, unknown>;
    rewardsClaimed: Record<string, boolean>;
    joinedAt: Date;
}
export declare const eventsService: {
    /**
     * Get all currently active events
     */
    getActiveEvents(): Promise<EngagementEvent[]>;
    /**
     * Get a specific event
     */
    getEvent(eventId: string): Promise<EngagementEvent | null>;
    /**
     * Get upcoming events
     */
    getUpcomingEvents(limit?: number): Promise<EngagementEvent[]>;
    /**
     * Join an event
     */
    joinEvent(userId: string, eventId: string): Promise<EventParticipation>;
    /**
     * Get user's participation in an event
     */
    getParticipation(userId: string, eventId: string): Promise<EventParticipation | null>;
    /**
     * Update event progress
     */
    updateProgress(userId: string, eventId: string, progressUpdate: Record<string, unknown>): Promise<EventParticipation>;
    /**
     * Get current credit multiplier from active events
     */
    getCreditMultiplier(): Promise<number>;
    /**
     * Get current XP multiplier from active events
     */
    getXpMultiplier(): Promise<number>;
    /**
     * Get user's event history
     */
    getEventHistory(userId: string, limit?: number): Promise<Array<{
        event: EngagementEvent;
        participation: EventParticipation;
    }>>;
    /**
     * Create a new event (admin only)
     */
    createEvent(params: {
        eventType: EventType;
        name: string;
        description?: string;
        config: EventConfig;
        startsAt: Date;
        endsAt: Date;
    }): Promise<EngagementEvent>;
    /**
     * Deactivate an event (admin only)
     */
    deactivateEvent(eventId: string): Promise<void>;
};
export {};
