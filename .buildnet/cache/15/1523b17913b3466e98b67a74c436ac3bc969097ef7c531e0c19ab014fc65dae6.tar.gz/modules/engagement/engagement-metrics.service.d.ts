/**
 * Engagement Metrics Service
 *
 * Provides analytics and metrics for the engagement system:
 * - User retention metrics
 * - Streak statistics
 * - Challenge completion rates
 * - Notification effectiveness
 * - Daily/weekly active users
 */
interface StreakStats {
    streakType: string;
    totalUsers: number;
    avgCurrentStreak: number;
    maxCurrentStreak: number;
    avgLongestStreak: number;
    maxLongestStreak: number;
    usersWithActiveStreak: number;
    milestonesClaimedToday: number;
}
interface ChallengeStats {
    totalChallengesGenerated: number;
    totalChallengesCompleted: number;
    completionRate: number;
    avgCompletionsByDifficulty: {
        easy: number;
        medium: number;
        hard: number;
    };
    creditsAwarded: number;
    xpAwarded: number;
}
interface DailyEngagementMetrics {
    date: string;
    dailyActiveUsers: number;
    newUsers: number;
    returningUsers: number;
    workoutsCompleted: number;
    challengesCompleted: number;
    challengesClaimed: number;
    loginRewardsClaimed: number;
    streakFreezesPurchased: number;
    totalCreditsEarned: number;
    totalXpEarned: number;
    avgSessionDuration: number | null;
}
interface RetentionMetrics {
    day1: number;
    day7: number;
    day14: number;
    day30: number;
    day60: number;
    day90: number;
}
interface NotificationEffectiveness {
    notificationType: string;
    sent: number;
    opened: number;
    actionTaken: number;
    openRate: number;
    conversionRate: number;
}
interface UserEngagementScore {
    userId: string;
    username: string;
    totalScore: number;
    components: {
        loginStreak: number;
        workoutStreak: number;
        challengeCompletion: number;
        socialActivity: number;
        consistencyBonus: number;
    };
    tier: 'inactive' | 'casual' | 'engaged' | 'power' | 'champion';
}
export declare const engagementMetricsService: {
    /**
     * Get streak statistics across all users
     */
    getStreakStats(streakType?: string): Promise<StreakStats[]>;
    /**
     * Get challenge statistics for a date range
     */
    getChallengeStats(daysBack?: number): Promise<ChallengeStats>;
    /**
     * Get daily engagement metrics
     */
    getDailyMetrics(date?: Date): Promise<DailyEngagementMetrics>;
    /**
     * Get retention metrics (cohort-based)
     */
    getRetentionMetrics(cohortDate: Date): Promise<RetentionMetrics>;
    /**
     * Get notification effectiveness metrics
     */
    getNotificationEffectiveness(daysBack?: number): Promise<NotificationEffectiveness[]>;
    /**
     * Calculate user engagement score
     */
    getUserEngagementScore(userId: string): Promise<UserEngagementScore | null>;
    /**
     * Get aggregated metrics summary for dashboard
     */
    getDashboardSummary(): Promise<{
        today: DailyEngagementMetrics;
        weeklyTrend: {
            dau: number[];
            challenges: number[];
            workouts: number[];
        };
        topStreakTypes: StreakStats[];
        challengeStats: ChallengeStats;
        engagementTiers: Record<string, number>;
    }>;
};
export default engagementMetricsService;
