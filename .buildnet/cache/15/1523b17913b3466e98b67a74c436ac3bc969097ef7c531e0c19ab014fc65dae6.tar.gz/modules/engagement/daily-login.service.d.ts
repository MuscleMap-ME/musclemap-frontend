/**
 * Daily Login Service
 *
 * Manages daily login rewards and streak tracking:
 * - Escalating daily rewards based on consecutive logins
 * - Streak freeze mechanics
 * - Mystery box rewards at milestones
 */
declare const DAILY_REWARDS: Record<number, {
    credits: number;
    xp: number;
    mysteryBoxTier?: string;
}>;
export declare const STREAK_FREEZE_COST = 250;
interface LoginStatus {
    currentStreak: number;
    longestStreak: number;
    lastLoginDate: string | null;
    streakFreezesOwned: number;
    totalLogins: number;
    todayReward: {
        credits: number;
        xp: number;
        mysteryBoxTier: string | null;
        isMilestone: boolean;
    } | null;
    canClaim: boolean;
    streakAtRisk: boolean;
    nextMilestone: {
        days: number;
        reward: typeof DAILY_REWARDS[number];
    } | null;
}
interface ClaimResult {
    credits: number;
    xp: number;
    newStreak: number;
    mysteryBoxId: string | null;
    isMilestone: boolean;
}
export declare const dailyLoginService: {
    /**
     * Get user's login status and today's potential reward
     */
    getStatus(userId: string): Promise<LoginStatus>;
    /**
     * Claim today's daily login reward
     */
    claimReward(userId: string, useFreeze?: boolean): Promise<ClaimResult>;
    /**
     * Use a streak freeze to protect streak
     */
    useStreakFreeze(userId: string): Promise<{
        success: boolean;
        freezesRemaining: number;
    }>;
    /**
     * Purchase a streak freeze
     */
    purchaseStreakFreeze(userId: string): Promise<{
        success: boolean;
        freezesOwned: number;
    }>;
    /**
     * Get login calendar (last 30 days)
     */
    getCalendar(userId: string, days?: number): Promise<Array<{
        date: string;
        claimed: boolean;
        dayNumber: number;
        credits: number;
        xp: number;
    }>>;
    /**
     * Get reward schedule preview
     */
    getRewardSchedule(): Array<{
        day: number;
        credits: number;
        xp: number;
        mysteryBoxTier: string | null;
        isMilestone: boolean;
    }>;
};
export {};
