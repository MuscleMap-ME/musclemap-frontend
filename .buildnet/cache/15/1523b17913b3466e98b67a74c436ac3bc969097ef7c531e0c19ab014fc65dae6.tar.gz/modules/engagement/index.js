"use strict";
/**
 * Engagement Module
 *
 * Comprehensive engagement system for driving daily active usage:
 * - Daily login rewards with streak tracking
 * - Multiple streak types (workout, nutrition, sleep, social)
 * - Daily and weekly challenges
 * - Time-limited events
 * - Recovery tracking for rest days
 * - Push notifications
 * - Engagement summary for dashboard
 * - Challenge progress auto-tracking
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.engagementMetricsService = exports.notificationTriggersService = exports.challengeProgressMiddleware = exports.engagementSummaryService = exports.pushNotificationsService = exports.recoveryService = exports.eventsService = exports.CHALLENGE_TYPES = exports.challengesService = exports.streaksService = exports.STREAK_FREEZE_COST = exports.dailyLoginService = void 0;
var daily_login_service_1 = require("./daily-login.service");
Object.defineProperty(exports, "dailyLoginService", { enumerable: true, get: function () { return daily_login_service_1.dailyLoginService; } });
Object.defineProperty(exports, "STREAK_FREEZE_COST", { enumerable: true, get: function () { return daily_login_service_1.STREAK_FREEZE_COST; } });
var streaks_service_1 = require("./streaks.service");
Object.defineProperty(exports, "streaksService", { enumerable: true, get: function () { return streaks_service_1.streaksService; } });
var challenges_service_1 = require("./challenges.service");
Object.defineProperty(exports, "challengesService", { enumerable: true, get: function () { return challenges_service_1.challengesService; } });
Object.defineProperty(exports, "CHALLENGE_TYPES", { enumerable: true, get: function () { return challenges_service_1.CHALLENGE_TYPES; } });
var events_service_1 = require("./events.service");
Object.defineProperty(exports, "eventsService", { enumerable: true, get: function () { return events_service_1.eventsService; } });
var recovery_service_1 = require("./recovery.service");
Object.defineProperty(exports, "recoveryService", { enumerable: true, get: function () { return recovery_service_1.recoveryService; } });
var push_notifications_service_1 = require("./push-notifications.service");
Object.defineProperty(exports, "pushNotificationsService", { enumerable: true, get: function () { return push_notifications_service_1.pushNotificationsService; } });
var summary_service_1 = require("./summary.service");
Object.defineProperty(exports, "engagementSummaryService", { enumerable: true, get: function () { return summary_service_1.engagementSummaryService; } });
var challenge_progress_middleware_1 = require("./challenge-progress.middleware");
Object.defineProperty(exports, "challengeProgressMiddleware", { enumerable: true, get: function () { return challenge_progress_middleware_1.challengeProgressMiddleware; } });
var notification_triggers_service_1 = require("./notification-triggers.service");
Object.defineProperty(exports, "notificationTriggersService", { enumerable: true, get: function () { return notification_triggers_service_1.notificationTriggersService; } });
var engagement_metrics_service_1 = require("./engagement-metrics.service");
Object.defineProperty(exports, "engagementMetricsService", { enumerable: true, get: function () { return engagement_metrics_service_1.engagementMetricsService; } });
//# sourceMappingURL=index.js.map