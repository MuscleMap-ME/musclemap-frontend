/**
 * Challenge Progress Middleware
 *
 * Automatically updates challenge progress when relevant actions occur:
 * - Workout completion -> LOG_SETS, COMPLETE_WORKOUT, HIT_MUSCLE_GROUPS, TOTAL_VOLUME
 * - Set logged -> LOG_SETS, TOTAL_VOLUME
 * - PR set -> BEAT_PR
 * - High five sent -> HIGH_FIVE_FRIENDS
 * - XP earned -> EARN_XP
 * - New exercise tried -> EXPLORE_EXERCISE
 */
import { FastifyInstance } from 'fastify';
export declare const challengeProgressMiddleware: {
    /**
     * Register hooks on the Fastify instance
     */
    register(app: FastifyInstance): void;
    /**
     * Manually update challenge progress (for use by other services)
     */
    updateProgress(userId: string, trackingKey: string, increment?: number): Promise<{
        updatedChallenges: Array<{
            id: string;
            newProgress: number;
            isComplete: boolean;
        }>;
    }>;
    /**
     * Update XP tracking (called from xpService)
     */
    trackXpEarned(userId: string, xpAmount: number): Promise<void>;
    /**
     * Update PR tracking (called from workout/1RM services)
     */
    trackPrSet(userId: string): Promise<void>;
    /**
     * Update new exercise tracking
     */
    trackNewExercise(userId: string): Promise<void>;
    /**
     * Update total volume tracking (called after set logging)
     */
    trackVolume(userId: string, volume: number): Promise<void>;
    /**
     * Update muscle groups hit (called after workout with muscle data)
     */
    trackMuscleGroups(userId: string, muscleCount: number): Promise<void>;
};
export default challengeProgressMiddleware;
