/**
 * Notification Triggers Service
 *
 * Automatically schedules notifications based on user activity:
 * - Streak at risk (no activity by 8pm)
 * - Challenge expiring (2 hours before midnight)
 * - Daily reward ready (9am daily)
 * - Re-engagement (1, 3, 7, 14, 30 days inactive)
 * - Rival activity (immediate on significant events)
 */
export declare const notificationTriggersService: {
    /**
     * Check and schedule streak-at-risk notifications
     * Should run at ~6-7pm daily to catch users before 8pm deadline
     */
    scheduleStreakAtRiskNotifications(): Promise<number>;
    /**
     * Check and schedule challenge-expiring notifications
     * Should run hourly to catch challenges expiring in ~2 hours
     */
    scheduleChallengeExpiringNotifications(): Promise<number>;
    /**
     * Check and schedule daily reward reminders
     * Should run at ~8am to notify users about their daily reward
     */
    scheduleDailyRewardReminders(): Promise<number>;
    /**
     * Check and schedule re-engagement notifications
     * Should run daily to catch inactive users at different intervals
     */
    scheduleReEngagementNotifications(): Promise<number>;
    /**
     * Trigger rival activity notification (called immediately on significant events)
     */
    triggerRivalActivityNotification(rivalUserId: string, activityType: "workout" | "pr" | "milestone", activityData: Record<string, unknown>): Promise<void>;
    /**
     * Process and send all pending notifications
     * Should run every minute or so
     */
    processPendingNotifications(): Promise<number>;
    /**
     * Run all scheduled triggers (for cron job)
     */
    runAllTriggers(): Promise<{
        streakAtRisk: number;
        challengeExpiring: number;
        dailyReward: number;
        reEngagement: number;
        processed: number;
    }>;
};
export default notificationTriggersService;
