/**
 * Challenges Service
 *
 * Manages daily and weekly challenges:
 * - Daily challenges: 3 per day (easy, medium, hard)
 * - Weekly challenges: 1 per week
 * - Auto-progress tracking
 * - Reward claiming
 */
export declare const CHALLENGE_TYPES: {
    LOG_SETS: {
        id: string;
        title: string;
        description: string;
        icon: string;
        category: string;
        targets: {
            easy: number;
            medium: number;
            hard: number;
        };
        rewards: {
            xp: {
                easy: number;
                medium: number;
                hard: number;
            };
            credits: {
                easy: number;
                medium: number;
                hard: number;
            };
        };
        trackingKey: string;
    };
    WORKOUT_STREAK: {
        id: string;
        title: string;
        description: string;
        icon: string;
        category: string;
        targets: {
            easy: number;
            medium: number;
            hard: number;
        };
        rewards: {
            xp: {
                easy: number;
                medium: number;
                hard: number;
            };
            credits: {
                easy: number;
                medium: number;
                hard: number;
            };
        };
        trackingKey: string;
    };
    HIT_MUSCLE_GROUPS: {
        id: string;
        title: string;
        description: string;
        icon: string;
        category: string;
        targets: {
            easy: number;
            medium: number;
            hard: number;
        };
        rewards: {
            xp: {
                easy: number;
                medium: number;
                hard: number;
            };
            credits: {
                easy: number;
                medium: number;
                hard: number;
            };
        };
        trackingKey: string;
    };
    HIGH_FIVE_FRIENDS: {
        id: string;
        title: string;
        description: string;
        icon: string;
        category: string;
        targets: {
            easy: number;
            medium: number;
            hard: number;
        };
        rewards: {
            xp: {
                easy: number;
                medium: number;
                hard: number;
            };
            credits: {
                easy: number;
                medium: number;
                hard: number;
            };
        };
        trackingKey: string;
    };
    BEAT_PR: {
        id: string;
        title: string;
        description: string;
        icon: string;
        category: string;
        targets: {
            easy: number;
            medium: number;
            hard: number;
        };
        rewards: {
            xp: {
                easy: number;
                medium: number;
                hard: number;
            };
            credits: {
                easy: number;
                medium: number;
                hard: number;
            };
        };
        trackingKey: string;
    };
    COMPLETE_WORKOUT: {
        id: string;
        title: string;
        description: string;
        icon: string;
        category: string;
        targets: {
            easy: number;
            medium: number;
            hard: number;
        };
        rewards: {
            xp: {
                easy: number;
                medium: number;
                hard: number;
            };
            credits: {
                easy: number;
                medium: number;
                hard: number;
            };
        };
        trackingKey: string;
    };
    EXPLORE_EXERCISE: {
        id: string;
        title: string;
        description: string;
        icon: string;
        category: string;
        targets: {
            easy: number;
            medium: number;
            hard: number;
        };
        rewards: {
            xp: {
                easy: number;
                medium: number;
                hard: number;
            };
            credits: {
                easy: number;
                medium: number;
                hard: number;
            };
        };
        trackingKey: string;
    };
    EARN_XP: {
        id: string;
        title: string;
        description: string;
        icon: string;
        category: string;
        targets: {
            easy: number;
            medium: number;
            hard: number;
        };
        rewards: {
            xp: {
                easy: number;
                medium: number;
                hard: number;
            };
            credits: {
                easy: number;
                medium: number;
                hard: number;
            };
        };
        trackingKey: string;
    };
    TOTAL_VOLUME: {
        id: string;
        title: string;
        description: string;
        icon: string;
        category: string;
        targets: {
            easy: number;
            medium: number;
            hard: number;
        };
        rewards: {
            xp: {
                easy: number;
                medium: number;
                hard: number;
            };
            credits: {
                easy: number;
                medium: number;
                hard: number;
            };
        };
        trackingKey: string;
    };
};
type Difficulty = 'easy' | 'medium' | 'hard';
interface Challenge {
    id: string;
    userId: string;
    challengeDate: string;
    challengeType: string;
    difficulty: Difficulty;
    targetValue: number;
    currentProgress: number;
    isComplete: boolean;
    isClaimed: boolean;
    xpReward: number;
    creditReward: number;
    expiresAt: Date;
    title: string;
    description: string;
    icon: string;
    percentage: number;
}
interface WeeklyChallenge {
    id: string;
    userId: string;
    weekStart: string;
    challengeType: string;
    targetValue: number;
    currentProgress: number;
    isComplete: boolean;
    isClaimed: boolean;
    xpReward: number;
    creditReward: number;
    expiresAt: Date;
    title: string;
    description: string;
    icon: string;
    percentage: number;
}
export declare const challengesService: {
    /**
     * Get today's daily challenges (generates if needed)
     */
    getDailyChallenges(userId: string): Promise<Challenge[]>;
    /**
     * Generate daily challenges for a user
     */
    generateDailyChallenges(userId: string, date?: Date): Promise<void>;
    /**
     * Update challenge progress
     */
    updateProgress(userId: string, trackingKey: string, increment?: number): Promise<{
        updatedChallenges: Array<{
            id: string;
            newProgress: number;
            isComplete: boolean;
        }>;
    }>;
    /**
     * Claim a completed challenge reward
     */
    claimChallenge(userId: string, challengeId: string): Promise<{
        credits: number;
        xp: number;
    }>;
    /**
     * Get weekly challenge (generates if needed)
     */
    getWeeklyChallenge(userId: string): Promise<WeeklyChallenge | null>;
    /**
     * Generate weekly challenge
     */
    generateWeeklyChallenge(userId: string, date?: Date): Promise<void>;
    /**
     * Claim weekly challenge reward
     */
    claimWeeklyChallenge(userId: string): Promise<{
        credits: number;
        xp: number;
    }>;
    /**
     * Get challenge history
     */
    getHistory(userId: string, limit?: number): Promise<Array<{
        id: string;
        challengeType: string;
        difficulty: string;
        date: string;
        wasCompleted: boolean;
        wasClaimed: boolean;
        credits: number;
        xp: number;
    }>>;
    /**
     * Format challenge from DB row
     */
    formatChallenge(row: {
        id: string;
        user_id: string;
        challenge_date: string;
        challenge_type: string;
        difficulty: string;
        target_value: number;
        current_progress: number;
        is_complete: boolean;
        is_claimed: boolean;
        xp_reward: number;
        credit_reward: number;
        expires_at: Date;
    }): Challenge;
    /**
     * Get challenge type definitions
     */
    getChallengeTypes(): typeof CHALLENGE_TYPES;
};
export {};
