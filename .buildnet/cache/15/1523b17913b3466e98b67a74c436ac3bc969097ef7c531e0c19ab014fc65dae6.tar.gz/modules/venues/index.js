"use strict";
/**
 * Venue Records Module
 *
 * Location-based achievement records system for fitness venues.
 *
 * Features:
 * - Fitness venue management (parks, gyms, rec centers)
 * - Record claims with GPS verification
 * - Witness attestation system
 * - Video proof upload and validation
 * - Venue leaderboards
 * - Check-in/check-out tracking
 * - Anti-spoofing measures
 * - Economy integration (credit fees and rewards)
 * - NYC Open Data integration (recreation centers, parks)
 * - OpenStreetMap integration (fitness stations)
 * - Crowdsourced venue submissions and verification
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports, p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = exports.crowdsourcingService = exports.calisthenicsParksIngestionService = exports.osmDataIngestionService = exports.nycDataIngestionService = exports.locationVerificationService = exports.recordClaimService = exports.checkinService = exports.venueService = void 0;
__exportStar(require("./types"), exports);
var venue_service_1 = require("./venue.service");
Object.defineProperty(exports, "venueService", { enumerable: true, get: function () { return venue_service_1.venueService; } });
var checkin_service_1 = require("./checkin.service");
Object.defineProperty(exports, "checkinService", { enumerable: true, get: function () { return checkin_service_1.checkinService; } });
var record_claim_service_1 = require("./record-claim.service");
Object.defineProperty(exports, "recordClaimService", { enumerable: true, get: function () { return record_claim_service_1.recordClaimService; } });
var location_verification_service_1 = require("./location-verification.service");
Object.defineProperty(exports, "locationVerificationService", { enumerable: true, get: function () { return location_verification_service_1.locationVerificationService; } });
// Data ingestion services
var nyc_data_ingestion_service_1 = require("./nyc-data-ingestion.service");
Object.defineProperty(exports, "nycDataIngestionService", { enumerable: true, get: function () { return nyc_data_ingestion_service_1.nycDataIngestionService; } });
var osm_data_ingestion_service_1 = require("./osm-data-ingestion.service");
Object.defineProperty(exports, "osmDataIngestionService", { enumerable: true, get: function () { return osm_data_ingestion_service_1.osmDataIngestionService; } });
var calisthenics_parks_ingestion_service_1 = require("./calisthenics-parks-ingestion.service");
Object.defineProperty(exports, "calisthenicsParksIngestionService", { enumerable: true, get: function () { return calisthenics_parks_ingestion_service_1.calisthenicsParksIngestionService; } });
// Crowdsourcing service
var crowdsourcing_service_1 = require("./crowdsourcing.service");
Object.defineProperty(exports, "crowdsourcingService", { enumerable: true, get: function () { return crowdsourcing_service_1.crowdsourcingService; } });
// Re-export for convenience
var venue_service_2 = require("./venue.service");
Object.defineProperty(exports, "default", { enumerable: true, get: function () { return venue_service_2.venueService; } });
//# sourceMappingURL=index.js.map