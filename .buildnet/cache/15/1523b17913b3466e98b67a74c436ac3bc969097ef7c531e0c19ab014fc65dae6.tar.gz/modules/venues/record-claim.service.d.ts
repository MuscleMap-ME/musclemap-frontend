/**
 * Record Claim Service
 *
 * Handles the full lifecycle of venue record claims:
 * - Initiating claims with location verification
 * - Video upload and processing
 * - Witness assignment and attestation
 * - Record verification and finalization
 * - Economy integration (credit fees and rewards)
 */
import { query } from '../../db/client';
import { VenueRecord, InitiateClaimParams, UploadVideoParams, AssignWitnessParams, WitnessAttestationParams, VenueRecordStatus } from './types';
export declare const recordClaimService: {
    /**
     * Initiate a new record claim
     */
    initiateClaim(params: InitiateClaimParams): Promise<VenueRecord>;
    /**
     * Upload video proof for a claim
     */
    uploadVideo(params: UploadVideoParams): Promise<VenueRecord>;
    /**
     * Assign a witness to a claim
     */
    assignWitness(params: AssignWitnessParams): Promise<VenueRecord>;
    /**
     * Process witness attestation (confirm or decline)
     */
    processWitnessAttestation(params: WitnessAttestationParams): Promise<VenueRecord>;
    /**
     * Verify a record (called when witness confirms)
     */
    verifyRecord(recordId: string, witnessUserId: string, attestationText: string, witnessLat: number, witnessLng: number): Promise<VenueRecord>;
    /**
     * Cancel a pending claim
     */
    cancelClaim(recordId: string, userId: string): Promise<void>;
    /**
     * Get record by ID
     */
    getRecordById(recordId: string): Promise<VenueRecord | null>;
    /**
     * Get record with full details (user, venue, type info)
     */
    getRecordWithDetails(recordId: string): Promise<VenueRecord | null>;
    /**
     * Get user's record claims
     */
    getUserRecords(userId: string, options?: {
        status?: VenueRecordStatus;
        limit?: number;
        cursor?: {
            claimedAt: Date;
            id: string;
        };
    }): Promise<{
        records: VenueRecord[];
        hasMore: boolean;
    }>;
    /**
     * Get user's current (verified) records
     */
    getUserCurrentRecords(userId: string): Promise<VenueRecord[]>;
    /**
     * Get pending witness requests for a user
     */
    getWitnessRequests(witnessUserId: string): Promise<(VenueRecord & {
        claimerUsername: string;
        venueName: string;
        recordTypeName: string;
    })[]>;
    /**
     * Expire old claims (run periodically)
     */
    expireOldClaims(): Promise<number>;
    /**
     * Deduct claim fee from user
     */
    deductClaimFee(userId: string, amount: number): Promise<{
        success: boolean;
        ledgerId?: string;
    }>;
    /**
     * Award credits for verified record and witness
     */
    awardRecordRewards(claimerId: string, witnessId: string, brokeRecord: boolean, trx?: {
        query: typeof query;
    }): Promise<void>;
    /**
     * Check and grant achievements after record verification
     */
    checkAchievements(userId: string, venueId: string, witnessUserId: string): Promise<void>;
};
export default recordClaimService;
