/**
 * Venue Service
 *
 * Handles CRUD operations for fitness venues and related queries.
 */
import { FitnessVenue, VenueRecordType, VenueMembership, CreateVenueParams, UpdateVenueParams, SearchVenuesParams, NearbyVenuesParams, VenueLeaderboard } from './types';
export declare const venueService: {
    /**
     * Create a new venue
     */
    createVenue(params: CreateVenueParams, createdBy: string): Promise<FitnessVenue>;
    /**
     * Get venue by ID
     */
    getVenueById(id: string): Promise<FitnessVenue | null>;
    /**
     * Get venue by slug
     */
    getVenueBySlug(slug: string): Promise<FitnessVenue | null>;
    /**
     * Update venue
     */
    updateVenue(id: string, params: UpdateVenueParams, updatedBy: string): Promise<FitnessVenue>;
    /**
     * Search venues with filters
     */
    searchVenues(params: SearchVenuesParams): Promise<{
        venues: FitnessVenue[];
        hasMore: boolean;
    }>;
    /**
     * Find nearby venues using Haversine formula
     */
    getNearbyVenues(params: NearbyVenuesParams): Promise<FitnessVenue[]>;
    /**
     * Get all active record types
     */
    getRecordTypes(): Promise<VenueRecordType[]>;
    /**
     * Get record type by ID
     */
    getRecordTypeById(id: string): Promise<VenueRecordType | null>;
    /**
     * Get record type by key
     */
    getRecordTypeByKey(key: string): Promise<VenueRecordType | null>;
    /**
     * Get record types available at a venue (based on equipment)
     */
    getRecordTypesForVenue(venueId: string): Promise<VenueRecordType[]>;
    /**
     * Get leaderboard for a specific record type at a venue
     */
    getVenueLeaderboard(venueId: string, recordTypeId: string, options?: {
        limit?: number;
        userId?: string;
    }): Promise<VenueLeaderboard>;
    /**
     * Get all leaderboards for a venue
     */
    getVenueAllLeaderboards(venueId: string, userId?: string): Promise<VenueLeaderboard[]>;
    /**
     * Join a venue (become a member)
     */
    joinVenue(venueId: string, userId: string): Promise<VenueMembership>;
    /**
     * Leave a venue
     */
    leaveVenue(venueId: string, userId: string): Promise<void>;
    /**
     * Get venue members
     */
    getVenueMembers(venueId: string, options?: {
        limit?: number;
        cursor?: {
            joinedAt: Date;
            oduserId: string;
        };
    }): Promise<{
        members: (VenueMembership & {
            username: string;
            displayName?: string;
            avatarUrl?: string;
        })[];
        hasMore: boolean;
    }>;
    /**
     * Check if user is a member of venue
     */
    isMember(venueId: string, userId: string): Promise<boolean>;
    /**
     * Get user's venue membership
     */
    getMembership(venueId: string, userId: string): Promise<VenueMembership | null>;
    /**
     * Update venue stats (call periodically or after significant events)
     */
    updateVenueStats(venueId: string): Promise<void>;
    /**
     * Get venue statistics summary
     */
    getVenueStats(venueId: string): Promise<{
        memberCount: number;
        activeRecordCount: number;
        totalRecordClaims: number;
        checkinCountToday: number;
        checkinCountTotal: number;
        topRecordHolders: {
            userId: string;
            username: string;
            recordCount: number;
        }[];
    }>;
    /**
     * Find potential duplicate venues within a radius
     * Uses Haversine formula to calculate distance
     */
    findNearbyDuplicates(latitude: number, longitude: number, radiusMeters?: number, excludeId?: string): Promise<Array<{
        id: string;
        name: string;
        distance: number;
        dataSource: string;
    }>>;
    /**
     * Merge duplicate venues into a single venue
     * Keeps the venue with the richest data (most equipment, photos, verifications)
     * Preserves all external IDs and data sources
     */
    mergeVenues(primaryVenueId: string, duplicateVenueIds: string[]): Promise<{
        merged: number;
        failed: number;
    }>;
    /**
     * Run deduplication across all venues from a specific data source
     * Groups nearby venues and suggests merges
     */
    findAllDuplicates(options?: {
        dataSource?: string;
        radiusMeters?: number;
        limit?: number;
    }): Promise<Array<{
        primaryVenue: {
            id: string;
            name: string;
            dataSource: string;
        };
        duplicates: Array<{
            id: string;
            name: string;
            distance: number;
            dataSource: string;
        }>;
    }>>;
};
export default venueService;
