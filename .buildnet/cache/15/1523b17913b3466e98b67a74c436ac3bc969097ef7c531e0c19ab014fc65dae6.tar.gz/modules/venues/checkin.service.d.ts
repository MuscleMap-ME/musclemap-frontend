/**
 * Checkin Service
 *
 * Handles venue check-in/check-out operations and active presence tracking.
 */
import { VenueCheckin, CheckinParams } from './types';
export declare const checkinService: {
    /**
     * Check in to a venue
     */
    checkin(params: CheckinParams): Promise<VenueCheckin>;
    /**
     * Check out from a venue
     */
    checkout(venueId: string, userId: string, autoCheckout?: boolean): Promise<void>;
    /**
     * Get user's active checkin (if any)
     */
    getActiveCheckin(userId: string): Promise<VenueCheckin | null>;
    /**
     * Get users currently checked in at a venue
     */
    getUsersAtVenue(venueId: string, excludeUserId?: string): Promise<{
        checkin: VenueCheckin;
        user: {
            id: string;
            username: string;
            displayName?: string;
            avatarUrl?: string;
        };
    }[]>;
    /**
     * Check if user is currently at a specific venue
     */
    isUserAtVenue(userId: string, venueId: string): Promise<boolean>;
    /**
     * Get user's checkin history
     */
    getUserCheckinHistory(userId: string, options?: {
        limit?: number;
        venueId?: string;
        cursor?: {
            checkedInAt: Date;
            id: string;
        };
    }): Promise<{
        checkins: (VenueCheckin & {
            venueName: string;
        })[];
        hasMore: boolean;
    }>;
    /**
     * Auto-checkout stale checkins (run periodically)
     */
    autoCheckoutStale(): Promise<number>;
    /**
     * Get venue checkin count for today
     */
    getVenueCheckinCountToday(venueId: string): Promise<number>;
    /**
     * Update checkin with workout ID (when user starts workout at venue)
     */
    linkWorkout(userId: string, workoutId: string): Promise<void>;
};
export default checkinService;
