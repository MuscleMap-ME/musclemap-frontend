"use strict";
/**
 * Venue Service
 *
 * Handles CRUD operations for fitness venues and related queries.
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.venueService = void 0;
const client_1 = require("../../db/client");
const errors_1 = require("../../lib/errors");
const logger_1 = require("../../lib/logger");
const cache_service_1 = __importDefault(require("../../lib/cache.service"));
const types_1 = require("./types");
const log = logger_1.loggers.core;
// Helper to generate slug from name
function generateSlug(name) {
    return name
        .toLowerCase()
        .replace(/[^a-z0-9\s-]/g, '')
        .replace(/\s+/g, '-')
        .replace(/-+/g, '-')
        .substring(0, 50);
}
// Helper to convert DB row to FitnessVenue
function rowToVenue(row) {
    return {
        id: row.id,
        name: row.name,
        slug: row.slug,
        description: row.description,
        venueType: row.venue_type,
        latitude: parseFloat(row.latitude),
        longitude: parseFloat(row.longitude),
        address: row.address,
        city: row.city,
        stateProvince: row.state_province,
        country: row.country,
        postalCode: row.postal_code,
        radiusMeters: row.radius_meters,
        boundaryPolygon: row.boundary_polygon,
        equipment: row.equipment || [],
        hasFreeWeights: row.has_free_weights,
        hasCalisthenicsEquipment: row.has_calisthenics_equipment,
        hasCardioEquipment: row.has_cardio_equipment,
        hasParkourFeatures: row.has_parkour_features,
        isIndoor: row.is_indoor,
        is24Hour: row.is_24_hour,
        isFree: row.is_free,
        photos: row.photos || [],
        coverPhotoUrl: row.cover_photo_url,
        memberCount: row.member_count,
        activeRecordCount: row.active_record_count,
        totalRecordClaims: row.total_record_claims,
        checkinCountToday: row.checkin_count_today,
        checkinCountTotal: row.checkin_count_total,
        isVerified: row.is_verified,
        verifiedBy: row.verified_by,
        verifiedAt: row.verified_at ? new Date(row.verified_at) : undefined,
        isActive: row.is_active,
        isFlagged: row.is_flagged,
        flagReason: row.flag_reason,
        hoursOfOperation: row.hours_of_operation,
        amenities: row.amenities || [],
        externalLinks: row.external_links || {},
        createdBy: row.created_by,
        createdAt: new Date(row.created_at),
        updatedAt: new Date(row.updated_at),
    };
}
// Helper to convert DB row to VenueRecordType
function rowToRecordType(row) {
    return {
        id: row.id,
        name: row.name,
        key: row.key,
        description: row.description,
        icon: row.icon,
        category: row.category,
        metricType: row.metric_type,
        unit: row.unit,
        direction: row.direction,
        requiresVideo: row.requires_video,
        requiresWitness: row.requires_witness,
        requiresLocationVerification: row.requires_location_verification,
        minVideoDurationSeconds: row.min_video_duration_seconds,
        maxVideoDurationSeconds: row.max_video_duration_seconds,
        exerciseId: row.exercise_id,
        requiredEquipment: row.required_equipment || [],
        displayOrder: row.display_order,
        isActive: row.is_active,
        isFeatured: row.is_featured,
        createdAt: new Date(row.created_at),
    };
}
exports.venueService = {
    // ============================================
    // VENUE CRUD
    // ============================================
    /**
     * Create a new venue
     */
    async createVenue(params, createdBy) {
        const { name, description, venueType, latitude, longitude, address, city, stateProvince, country = 'USA', postalCode, radiusMeters = types_1.VENUE_CONSTANTS.DEFAULT_VENUE_RADIUS_METERS, equipment = [], hasFreeWeights = false, hasCalisthenicsEquipment = false, hasCardioEquipment = false, hasParkourFeatures = false, isIndoor = false, is24Hour = false, isFree = true, coverPhotoUrl, hoursOfOperation, amenities = [], } = params;
        // Validate
        if (!name || name.trim().length < 3) {
            throw new errors_1.ValidationError('Venue name must be at least 3 characters');
        }
        if (latitude < -90 || latitude > 90) {
            throw new errors_1.ValidationError('Invalid latitude');
        }
        if (longitude < -180 || longitude > 180) {
            throw new errors_1.ValidationError('Invalid longitude');
        }
        if (radiusMeters > types_1.VENUE_CONSTANTS.MAX_VENUE_RADIUS_METERS) {
            throw new errors_1.ValidationError(`Radius cannot exceed ${types_1.VENUE_CONSTANTS.MAX_VENUE_RADIUS_METERS} meters`);
        }
        // Generate unique slug
        let slug = generateSlug(name);
        const existingSlug = await (0, client_1.queryOne)('SELECT id FROM fitness_venues WHERE slug = $1', [slug]);
        if (existingSlug) {
            slug = `${slug}-${Date.now().toString(36)}`;
        }
        const result = await (0, client_1.queryOne)(`INSERT INTO fitness_venues (
        name, slug, description, venue_type, latitude, longitude, address, city,
        state_province, country, postal_code, radius_meters, equipment,
        has_free_weights, has_calisthenics_equipment, has_cardio_equipment,
        has_parkour_features, is_indoor, is_24_hour, is_free, cover_photo_url,
        hours_of_operation, amenities, created_by
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17, $18, $19, $20, $21, $22, $23, $24)
      RETURNING *`, [
            name.trim(),
            slug,
            description,
            venueType,
            latitude,
            longitude,
            address,
            city,
            stateProvince,
            country,
            postalCode,
            radiusMeters,
            JSON.stringify(equipment),
            hasFreeWeights,
            hasCalisthenicsEquipment,
            hasCardioEquipment,
            hasParkourFeatures,
            isIndoor,
            is24Hour,
            isFree,
            coverPhotoUrl,
            hoursOfOperation ? JSON.stringify(hoursOfOperation) : null,
            JSON.stringify(amenities),
            createdBy,
        ]);
        if (!result) {
            throw new Error('Failed to create venue');
        }
        log.info({ venueId: result.id, name }, 'Venue created');
        return rowToVenue(result);
    },
    /**
     * Get venue by ID
     */
    async getVenueById(id) {
        const cacheKey = `cache:venue:${id}`;
        const cached = await cache_service_1.default.get(cacheKey);
        if (cached)
            return cached;
        const result = await (0, client_1.queryOne)('SELECT * FROM fitness_venues WHERE id = $1', [id]);
        if (!result)
            return null;
        const venue = rowToVenue(result);
        await cache_service_1.default.set(cacheKey, venue, 300); // 5 minutes
        return venue;
    },
    /**
     * Get venue by slug
     */
    async getVenueBySlug(slug) {
        const result = await (0, client_1.queryOne)('SELECT * FROM fitness_venues WHERE slug = $1 AND is_active = TRUE', [slug]);
        if (!result)
            return null;
        return rowToVenue(result);
    },
    /**
     * Update venue
     */
    async updateVenue(id, params, updatedBy) {
        const existing = await this.getVenueById(id);
        if (!existing) {
            throw new errors_1.NotFoundError('Venue not found');
        }
        const updates = [];
        const values = [];
        let paramIndex = 1;
        const fieldMap = {
            name: 'name',
            description: 'description',
            venueType: 'venue_type',
            latitude: 'latitude',
            longitude: 'longitude',
            address: 'address',
            city: 'city',
            stateProvince: 'state_province',
            country: 'country',
            postalCode: 'postal_code',
            radiusMeters: 'radius_meters',
            hasFreeWeights: 'has_free_weights',
            hasCalisthenicsEquipment: 'has_calisthenics_equipment',
            hasCardioEquipment: 'has_cardio_equipment',
            hasParkourFeatures: 'has_parkour_features',
            isIndoor: 'is_indoor',
            is24Hour: 'is_24_hour',
            isFree: 'is_free',
            coverPhotoUrl: 'cover_photo_url',
            isActive: 'is_active',
        };
        for (const [key, dbField] of Object.entries(fieldMap)) {
            if (key in params && params[key] !== undefined) {
                updates.push(`${dbField} = $${paramIndex}`);
                values.push(params[key]);
                paramIndex++;
            }
        }
        // Handle JSON fields
        if (params.equipment) {
            updates.push(`equipment = $${paramIndex}`);
            values.push(JSON.stringify(params.equipment));
            paramIndex++;
        }
        if (params.hoursOfOperation) {
            updates.push(`hours_of_operation = $${paramIndex}`);
            values.push(JSON.stringify(params.hoursOfOperation));
            paramIndex++;
        }
        if (params.amenities) {
            updates.push(`amenities = $${paramIndex}`);
            values.push(JSON.stringify(params.amenities));
            paramIndex++;
        }
        if (updates.length === 0) {
            return existing;
        }
        values.push(id);
        const result = await (0, client_1.queryOne)(`UPDATE fitness_venues SET ${updates.join(', ')} WHERE id = $${paramIndex} RETURNING *`, values);
        if (!result) {
            throw new Error('Failed to update venue');
        }
        // Invalidate cache
        await cache_service_1.default.del(`cache:venue:${id}`);
        log.info({ venueId: id, updatedBy }, 'Venue updated');
        return rowToVenue(result);
    },
    /**
     * Search venues with filters
     */
    async searchVenues(params) {
        const { query: searchQuery, city, venueType, hasEquipment, isFree, isIndoor, limit = 20, cursor } = params;
        const conditions = ['is_active = TRUE'];
        const values = [];
        let paramIndex = 1;
        if (searchQuery) {
            conditions.push(`(name ILIKE $${paramIndex} OR description ILIKE $${paramIndex} OR city ILIKE $${paramIndex})`);
            values.push(`%${searchQuery}%`);
            paramIndex++;
        }
        if (city) {
            conditions.push(`city ILIKE $${paramIndex}`);
            values.push(`%${city}%`);
            paramIndex++;
        }
        if (venueType) {
            conditions.push(`venue_type = $${paramIndex}`);
            values.push(venueType);
            paramIndex++;
        }
        if (hasEquipment && hasEquipment.length > 0) {
            conditions.push(`equipment ?& $${paramIndex}`);
            values.push(hasEquipment);
            paramIndex++;
        }
        if (isFree !== undefined) {
            conditions.push(`is_free = $${paramIndex}`);
            values.push(isFree);
            paramIndex++;
        }
        if (isIndoor !== undefined) {
            conditions.push(`is_indoor = $${paramIndex}`);
            values.push(isIndoor);
            paramIndex++;
        }
        // Keyset pagination
        if (cursor) {
            conditions.push(`(created_at, id) < ($${paramIndex}, $${paramIndex + 1})`);
            values.push(cursor.createdAt, cursor.id);
            paramIndex += 2;
        }
        values.push(limit + 1);
        const rows = await (0, client_1.queryAll)(`SELECT * FROM fitness_venues
       WHERE ${conditions.join(' AND ')}
       ORDER BY member_count DESC, created_at DESC, id DESC
       LIMIT $${paramIndex}`, values);
        const hasMore = rows.length > limit;
        const venues = rows.slice(0, limit).map(rowToVenue);
        return { venues, hasMore };
    },
    /**
     * Find nearby venues using Haversine formula
     */
    async getNearbyVenues(params) {
        const { latitude, longitude, radiusMiles = 5, venueType, limit = 20 } = params;
        const radiusKm = radiusMiles * 1.60934;
        const conditions = ['is_active = TRUE'];
        const values = [latitude, longitude, radiusKm];
        let paramIndex = 4;
        if (venueType) {
            conditions.push(`venue_type = $${paramIndex}`);
            values.push(venueType);
            paramIndex++;
        }
        values.push(limit);
        // Haversine formula for distance calculation
        const rows = await (0, client_1.queryAll)(`SELECT *,
        (6371 * acos(
          cos(radians($1)) * cos(radians(latitude)) *
          cos(radians(longitude) - radians($2)) +
          sin(radians($1)) * sin(radians(latitude))
        )) AS distance_km
       FROM fitness_venues
       WHERE ${conditions.join(' AND ')}
         AND (6371 * acos(
           cos(radians($1)) * cos(radians(latitude)) *
           cos(radians(longitude) - radians($2)) +
           sin(radians($1)) * sin(radians(latitude))
         )) < $3
       ORDER BY distance_km ASC
       LIMIT $${paramIndex}`, values);
        return rows.map((row) => ({
            ...rowToVenue(row),
            distanceKm: parseFloat(row.distance_km),
        }));
    },
    // ============================================
    // RECORD TYPES
    // ============================================
    /**
     * Get all active record types
     */
    async getRecordTypes() {
        const cacheKey = `cache:venue_record_types`;
        const cached = await cache_service_1.default.get(cacheKey);
        if (cached)
            return cached;
        const rows = await (0, client_1.queryAll)(`SELECT * FROM venue_record_types WHERE is_active = TRUE ORDER BY display_order, name`);
        const types = rows.map(rowToRecordType);
        await cache_service_1.default.set(cacheKey, types, 3600); // 1 hour
        return types;
    },
    /**
     * Get record type by ID
     */
    async getRecordTypeById(id) {
        const result = await (0, client_1.queryOne)('SELECT * FROM venue_record_types WHERE id = $1', [id]);
        if (!result)
            return null;
        return rowToRecordType(result);
    },
    /**
     * Get record type by key
     */
    async getRecordTypeByKey(key) {
        const result = await (0, client_1.queryOne)('SELECT * FROM venue_record_types WHERE key = $1', [key]);
        if (!result)
            return null;
        return rowToRecordType(result);
    },
    /**
     * Get record types available at a venue (based on equipment)
     */
    async getRecordTypesForVenue(venueId) {
        const venue = await this.getVenueById(venueId);
        if (!venue) {
            throw new errors_1.NotFoundError('Venue not found');
        }
        const allTypes = await this.getRecordTypes();
        // Filter to types where venue has required equipment
        return allTypes.filter((type) => {
            if (type.requiredEquipment.length === 0)
                return true;
            return type.requiredEquipment.every((eq) => venue.equipment.includes(eq));
        });
    },
    // ============================================
    // LEADERBOARDS
    // ============================================
    /**
     * Get leaderboard for a specific record type at a venue
     */
    async getVenueLeaderboard(venueId, recordTypeId, options = {}) {
        const { limit = 50, userId } = options;
        const [venue, recordType] = await Promise.all([this.getVenueById(venueId), this.getRecordTypeById(recordTypeId)]);
        if (!venue)
            throw new errors_1.NotFoundError('Venue not found');
        if (!recordType)
            throw new errors_1.NotFoundError('Record type not found');
        const rows = await (0, client_1.queryAll)(`SELECT vr.id as record_id, vr.value, vr.verified_at, vr.user_id,
              u.username, u.display_name, u.avatar_url,
              ROW_NUMBER() OVER (ORDER BY vr.value DESC, vr.verified_at ASC) as rank
       FROM venue_records vr
       JOIN users u ON u.id = vr.user_id
       WHERE vr.venue_id = $1 AND vr.record_type_id = $2 AND vr.status = 'verified'
       ORDER BY vr.value DESC, vr.verified_at ASC
       LIMIT $3`, [venueId, recordTypeId, limit]);
        const entries = rows.map((row) => ({
            rank: parseInt(row.rank),
            userId: row.user_id,
            username: row.username,
            displayName: row.display_name,
            avatarUrl: row.avatar_url,
            value: parseFloat(row.value),
            recordId: row.record_id,
            verifiedAt: new Date(row.verified_at),
            isCurrentUser: userId ? row.user_id === userId : false,
        }));
        // Get total count
        const countResult = await (0, client_1.queryOne)(`SELECT COUNT(*) as count FROM venue_records
       WHERE venue_id = $1 AND record_type_id = $2 AND status = 'verified'`, [venueId, recordTypeId]);
        return {
            venueId,
            recordTypeId,
            recordTypeName: recordType.name,
            unit: recordType.unit,
            entries,
            totalEntries: parseInt(countResult?.count || '0'),
            currentRecord: entries[0] || undefined,
        };
    },
    /**
     * Get all leaderboards for a venue
     */
    async getVenueAllLeaderboards(venueId, userId) {
        const recordTypes = await this.getRecordTypesForVenue(venueId);
        const leaderboards = await Promise.all(recordTypes.map((type) => this.getVenueLeaderboard(venueId, type.id, { limit: 5, userId })));
        // Filter out empty leaderboards
        return leaderboards.filter((lb) => lb.entries.length > 0);
    },
    // ============================================
    // MEMBERSHIPS
    // ============================================
    /**
     * Join a venue (become a member)
     */
    async joinVenue(venueId, userId) {
        const venue = await this.getVenueById(venueId);
        if (!venue) {
            throw new errors_1.NotFoundError('Venue not found');
        }
        // Check if already a member
        const existing = await (0, client_1.queryOne)('SELECT * FROM venue_memberships WHERE venue_id = $1 AND user_id = $2', [venueId, userId]);
        if (existing) {
            return {
                venueId: existing.venue_id,
                userId: existing.user_id,
                role: existing.role,
                recordCount: existing.record_count,
                currentRecordsHeld: existing.current_records_held,
                checkinCount: existing.checkin_count,
                lastCheckinAt: existing.last_checkin_at ? new Date(existing.last_checkin_at) : undefined,
                lastRecordClaimAt: existing.last_record_claim_at ? new Date(existing.last_record_claim_at) : undefined,
                notificationsEnabled: existing.notifications_enabled,
                showInMembersList: existing.show_in_members_list,
                joinedAt: new Date(existing.joined_at),
            };
        }
        // Insert membership
        const result = await (0, client_1.queryOne)(`INSERT INTO venue_memberships (venue_id, user_id)
       VALUES ($1, $2)
       ON CONFLICT (venue_id, user_id) DO UPDATE SET joined_at = NOW()
       RETURNING *`, [venueId, userId]);
        // Update member count
        await (0, client_1.query)('UPDATE fitness_venues SET member_count = member_count + 1 WHERE id = $1', [venueId]);
        // Invalidate cache
        await cache_service_1.default.del(`cache:venue:${venueId}`);
        return {
            venueId: result.venue_id,
            userId: result.user_id,
            role: result.role,
            recordCount: result.record_count,
            currentRecordsHeld: result.current_records_held,
            checkinCount: result.checkin_count,
            lastCheckinAt: undefined,
            lastRecordClaimAt: undefined,
            notificationsEnabled: result.notifications_enabled,
            showInMembersList: result.show_in_members_list,
            joinedAt: new Date(result.joined_at),
        };
    },
    /**
     * Leave a venue
     */
    async leaveVenue(venueId, userId) {
        const result = await (0, client_1.query)('DELETE FROM venue_memberships WHERE venue_id = $1 AND user_id = $2', [venueId, userId]);
        if (result.rowCount && result.rowCount > 0) {
            await (0, client_1.query)('UPDATE fitness_venues SET member_count = GREATEST(0, member_count - 1) WHERE id = $1', [venueId]);
            await cache_service_1.default.del(`cache:venue:${venueId}`);
        }
    },
    /**
     * Get venue members
     */
    async getVenueMembers(venueId, options = {}) {
        const { limit = 50, cursor } = options;
        const conditions = ['vm.venue_id = $1', 'vm.show_in_members_list = TRUE'];
        const values = [venueId];
        let paramIndex = 2;
        if (cursor) {
            conditions.push(`(vm.joined_at, vm.user_id) < ($${paramIndex}, $${paramIndex + 1})`);
            values.push(cursor.joinedAt, cursor.oduserId);
            paramIndex += 2;
        }
        values.push(limit + 1);
        const rows = await (0, client_1.queryAll)(`SELECT vm.*, u.username, u.display_name, u.avatar_url
       FROM venue_memberships vm
       JOIN users u ON u.id = vm.user_id
       WHERE ${conditions.join(' AND ')}
       ORDER BY vm.current_records_held DESC, vm.checkin_count DESC, vm.joined_at DESC
       LIMIT $${paramIndex}`, values);
        const hasMore = rows.length > limit;
        const members = rows.slice(0, limit).map((row) => ({
            venueId: row.venue_id,
            userId: row.user_id,
            role: row.role,
            recordCount: row.record_count,
            currentRecordsHeld: row.current_records_held,
            checkinCount: row.checkin_count,
            lastCheckinAt: row.last_checkin_at ? new Date(row.last_checkin_at) : undefined,
            lastRecordClaimAt: row.last_record_claim_at ? new Date(row.last_record_claim_at) : undefined,
            notificationsEnabled: row.notifications_enabled,
            showInMembersList: row.show_in_members_list,
            joinedAt: new Date(row.joined_at),
            username: row.username,
            displayName: row.display_name,
            avatarUrl: row.avatar_url,
        }));
        return { members, hasMore };
    },
    /**
     * Check if user is a member of venue
     */
    async isMember(venueId, userId) {
        const result = await (0, client_1.queryOne)('SELECT 1 FROM venue_memberships WHERE venue_id = $1 AND user_id = $2', [venueId, userId]);
        return !!result;
    },
    /**
     * Get user's venue membership
     */
    async getMembership(venueId, userId) {
        const result = await (0, client_1.queryOne)('SELECT * FROM venue_memberships WHERE venue_id = $1 AND user_id = $2', [venueId, userId]);
        if (!result)
            return null;
        return {
            venueId: result.venue_id,
            userId: result.user_id,
            role: result.role,
            recordCount: result.record_count,
            currentRecordsHeld: result.current_records_held,
            checkinCount: result.checkin_count,
            lastCheckinAt: result.last_checkin_at ? new Date(result.last_checkin_at) : undefined,
            lastRecordClaimAt: result.last_record_claim_at ? new Date(result.last_record_claim_at) : undefined,
            notificationsEnabled: result.notifications_enabled,
            showInMembersList: result.show_in_members_list,
            joinedAt: new Date(result.joined_at),
        };
    },
    // ============================================
    // STATS
    // ============================================
    /**
     * Update venue stats (call periodically or after significant events)
     */
    async updateVenueStats(venueId) {
        await (0, client_1.query)(`UPDATE fitness_venues SET
        active_record_count = (
          SELECT COUNT(DISTINCT record_type_id) FROM venue_records
          WHERE venue_id = $1 AND status = 'verified'
        ),
        total_record_claims = (
          SELECT COUNT(*) FROM venue_records WHERE venue_id = $1
        ),
        checkin_count_today = (
          SELECT COUNT(*) FROM venue_checkins
          WHERE venue_id = $1 AND DATE(checked_in_at) = CURRENT_DATE
        ),
        checkin_count_total = (
          SELECT COUNT(*) FROM venue_checkins WHERE venue_id = $1
        )
       WHERE id = $1`, [venueId]);
        await cache_service_1.default.del(`cache:venue:${venueId}`);
    },
    /**
     * Get venue statistics summary
     */
    async getVenueStats(venueId) {
        const venue = await this.getVenueById(venueId);
        if (!venue) {
            throw new errors_1.NotFoundError('Venue not found');
        }
        const topHolders = await (0, client_1.queryAll)(`SELECT vr.user_id, u.username, COUNT(*) as record_count
       FROM venue_records vr
       JOIN users u ON u.id = vr.user_id
       WHERE vr.venue_id = $1 AND vr.status = 'verified'
       GROUP BY vr.user_id, u.username
       ORDER BY record_count DESC
       LIMIT 5`, [venueId]);
        return {
            memberCount: venue.memberCount,
            activeRecordCount: venue.activeRecordCount,
            totalRecordClaims: venue.totalRecordClaims,
            checkinCountToday: venue.checkinCountToday,
            checkinCountTotal: venue.checkinCountTotal,
            topRecordHolders: topHolders.map((row) => ({
                userId: row.user_id,
                username: row.username,
                recordCount: parseInt(row.record_count),
            })),
        };
    },
    // ============================================
    // DEDUPLICATION
    // ============================================
    /**
     * Find potential duplicate venues within a radius
     * Uses Haversine formula to calculate distance
     */
    async findNearbyDuplicates(latitude, longitude, radiusMeters = 50, excludeId) {
        const radiusKm = radiusMeters / 1000;
        const rows = await (0, client_1.queryAll)(`SELECT id, name, data_source,
        (6371 * acos(
          LEAST(1, GREATEST(-1,
            cos(radians($1)) * cos(radians(latitude)) *
            cos(radians(longitude) - radians($2)) +
            sin(radians($1)) * sin(radians(latitude))
          ))
        )) AS distance_km
       FROM fitness_venues
       WHERE is_active = TRUE
         ${excludeId ? 'AND id != $4' : ''}
         AND (6371 * acos(
           LEAST(1, GREATEST(-1,
             cos(radians($1)) * cos(radians(latitude)) *
             cos(radians(longitude) - radians($2)) +
             sin(radians($1)) * sin(radians(latitude))
           ))
         )) < $3
       ORDER BY distance_km ASC
       LIMIT 10`, excludeId ? [latitude, longitude, radiusKm, excludeId] : [latitude, longitude, radiusKm]);
        return rows.map((row) => ({
            id: row.id,
            name: row.name,
            distance: parseFloat(row.distance_km) * 1000, // Convert back to meters
            dataSource: row.data_source,
        }));
    },
    /**
     * Merge duplicate venues into a single venue
     * Keeps the venue with the richest data (most equipment, photos, verifications)
     * Preserves all external IDs and data sources
     */
    async mergeVenues(primaryVenueId, duplicateVenueIds) {
        let merged = 0;
        let failed = 0;
        for (const duplicateId of duplicateVenueIds) {
            try {
                // Get both venues
                const primary = await this.getVenueById(primaryVenueId);
                const duplicate = await this.getVenueById(duplicateId);
                if (!primary || !duplicate) {
                    failed++;
                    continue;
                }
                // Merge equipment (combine unique items)
                const mergedEquipment = [...new Set([...primary.equipment, ...duplicate.equipment])];
                // Merge photos (combine unique items)
                const mergedPhotos = [...new Set([...primary.photos, ...duplicate.photos])];
                // Update primary venue with merged data
                await (0, client_1.query)(`UPDATE fitness_venues SET
            equipment = $2::jsonb,
            photos = $3::jsonb,
            has_calisthenics_equipment = $4,
            has_cardio_equipment = $5,
            verification_count = GREATEST(verification_count, $6),
            updated_at = NOW()
           WHERE id = $1`, [
                    primaryVenueId,
                    JSON.stringify(mergedEquipment),
                    JSON.stringify(mergedPhotos),
                    mergedEquipment.some((e) => ['pull_up_bar', 'parallel_bars', 'dip_station', 'rings', 'monkey_bars'].includes(e)),
                    mergedEquipment.some((e) => ['elliptical_outdoor', 'stationary_bike_outdoor', 'rowing_machine_outdoor'].includes(e)),
                    duplicate.isVerified ? 1 : 0,
                ]);
                // Move all check-ins, records, and memberships to primary venue
                await (0, client_1.query)('UPDATE venue_checkins SET venue_id = $1 WHERE venue_id = $2', [primaryVenueId, duplicateId]);
                await (0, client_1.query)('UPDATE venue_records SET venue_id = $1 WHERE venue_id = $2', [primaryVenueId, duplicateId]);
                await (0, client_1.query)('UPDATE venue_memberships SET venue_id = $1 WHERE venue_id = $2', [primaryVenueId, duplicateId]);
                await (0, client_1.query)('UPDATE venue_contributions SET venue_id = $1 WHERE venue_id = $2', [primaryVenueId, duplicateId]);
                // Deactivate the duplicate venue (keep for historical reference)
                await (0, client_1.query)(`UPDATE fitness_venues SET
            is_active = FALSE,
            flag_reason = $2,
            updated_at = NOW()
           WHERE id = $1`, [duplicateId, `Merged into venue ${primaryVenueId}`]);
                merged++;
                log.info({ primaryVenueId, duplicateId }, 'Merged duplicate venue');
            }
            catch (error) {
                log.error({ error, primaryVenueId, duplicateId }, 'Failed to merge venue');
                failed++;
            }
        }
        return { merged, failed };
    },
    /**
     * Run deduplication across all venues from a specific data source
     * Groups nearby venues and suggests merges
     */
    async findAllDuplicates(options = {}) {
        const { dataSource, radiusMeters = 50, limit = 100 } = options;
        // Get all venues, ordered by verification/richness
        const conditions = ['is_active = TRUE'];
        const values = [];
        let paramIndex = 1;
        if (dataSource) {
            conditions.push(`data_source = $${paramIndex}`);
            values.push(dataSource);
            paramIndex++;
        }
        values.push(limit);
        const venues = await (0, client_1.queryAll)(`SELECT id, name, latitude, longitude, data_source
       FROM fitness_venues
       WHERE ${conditions.join(' AND ')}
       ORDER BY is_verified DESC, verification_count DESC, created_at ASC
       LIMIT $${paramIndex}`, values);
        const duplicateGroups = [];
        const processedIds = new Set();
        for (const venue of venues) {
            if (processedIds.has(venue.id))
                continue;
            const duplicates = await this.findNearbyDuplicates(parseFloat(venue.latitude), parseFloat(venue.longitude), radiusMeters, venue.id);
            // Filter out already processed venues
            const unprocessedDuplicates = duplicates.filter((d) => !processedIds.has(d.id));
            if (unprocessedDuplicates.length > 0) {
                duplicateGroups.push({
                    primaryVenue: { id: venue.id, name: venue.name, dataSource: venue.data_source },
                    duplicates: unprocessedDuplicates,
                });
                // Mark all as processed
                processedIds.add(venue.id);
                for (const dup of unprocessedDuplicates) {
                    processedIds.add(dup.id);
                }
            }
        }
        return duplicateGroups;
    },
};
exports.default = exports.venueService;
//# sourceMappingURL=venue.service.js.map