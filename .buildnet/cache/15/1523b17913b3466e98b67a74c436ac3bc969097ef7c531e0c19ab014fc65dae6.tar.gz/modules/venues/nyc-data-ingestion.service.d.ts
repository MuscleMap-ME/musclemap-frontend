/**
 * NYC Open Data Ingestion Service
 *
 * Handles ingestion of outdoor exercise equipment data from NYC Open Data APIs:
 * - Recreation Centers directory
 * - Parks properties and boundaries
 * - Athletic facilities
 *
 * Also handles scraping the NYC Parks fitness equipment page for additional data.
 */
import { FitnessVenue, EquipmentType } from './types';
interface NYCExerciseEquipment {
    borough?: string;
    propid?: string;
    propname?: string;
    propnum?: string;
    sitename?: string;
    featuretype?: string;
    status?: string;
    closuretype?: string;
    zipcode?: string;
    point?: {
        type: string;
        coordinates: [number, number];
    };
}
interface NYCParkProperty {
    park_name?: string;
    park_id?: string;
    borough?: string;
    acreage?: string;
    prop_type?: string;
    the_geom?: {
        type: string;
        coordinates: number[] | number[][] | number[][][];
    };
}
interface SyncLogEntry {
    id: string;
    dataSource: string;
    sourceDataset: string;
    syncType: string;
    status: string;
    recordsFetched: number;
    recordsCreated: number;
    recordsUpdated: number;
    recordsSkipped: number;
    recordsFailed: number;
    errorMessage?: string;
    startedAt: Date;
    completedAt?: Date;
}
export declare const nycDataIngestionService: {
    /**
     * Create a sync log entry
     */
    createSyncLog(dataSource: string, sourceDataset: string, syncType: "full" | "incremental" | "manual"): Promise<string>;
    /**
     * Update sync log with results
     */
    updateSyncLog(logId: string, stats: {
        status: "completed" | "failed" | "partial";
        recordsFetched?: number;
        recordsCreated?: number;
        recordsUpdated?: number;
        recordsSkipped?: number;
        recordsFailed?: number;
        errorMessage?: string;
    }): Promise<void>;
    /**
     * Get recent sync logs
     */
    getRecentSyncLogs(dataSource?: string, limit?: number): Promise<SyncLogEntry[]>;
    /**
     * Fetch exercise equipment locations from NYC Open Data
     * This replaces the old recreation centers endpoint which is no longer tabular
     */
    fetchExerciseEquipment(): Promise<NYCExerciseEquipment[]>;
    /**
     * Ingest exercise equipment locations into the database
     */
    ingestExerciseEquipment(): Promise<{
        created: number;
        updated: number;
        skipped: number;
        failed: number;
    }>;
    ingestRecreationCenters(): Promise<{
        created: number;
        updated: number;
        skipped: number;
        failed: number;
    }>;
    /**
     * Fetch parks properties from NYC Open Data
     */
    fetchParksProperties(): Promise<NYCParkProperty[]>;
    /**
     * Update venues with park property IDs for linking
     */
    linkVenuesToParks(): Promise<{
        linked: number;
        notFound: number;
    }>;
    /**
     * Get venues by data source
     */
    getVenuesBySource(dataSource: "manual" | "nyc_open_data" | "openstreetmap" | "crowdsourced" | "scraped", limit?: number): Promise<FitnessVenue[]>;
    /**
     * Get venues by borough
     */
    getVenuesByBorough(borough: "Manhattan" | "Brooklyn" | "Queens" | "Bronx" | "Staten Island", options?: {
        limit?: number;
        hasEquipment?: EquipmentType[];
    }): Promise<FitnessVenue[]>;
    /**
     * Get ingestion statistics
     */
    getIngestionStats(): Promise<{
        totalVenues: number;
        bySource: Record<string, number>;
        byBorough: Record<string, number>;
        byType: Record<string, number>;
        lastSync: Record<string, Date | null>;
    }>;
};
export default nycDataIngestionService;
