/**
 * Calisthenics-Parks.com Data Ingestion Service
 *
 * Handles ingestion of outdoor fitness equipment data from Calisthenics-Parks.com.
 * This site has 26,000+ spots globally but requires authentication to access their API.
 *
 * NOTE: This service is currently a placeholder. To use it:
 * 1. Contact Calisthenics-Parks.com for data sharing partnership, OR
 * 2. Implement authenticated scraping with proper rate limiting
 *
 * Reference: https://calisthenics-parks.com/spots
 */
interface CPSpot {
    id: number;
    name: string;
    latitude: number;
    longitude: number;
    country: string;
    region?: string;
    city?: string;
    address?: string;
    description?: string;
    tags?: string[];
    equipment?: string[];
    illuminated?: boolean;
    roofed?: boolean;
    accessible?: boolean;
    imageUrl?: string;
}
export declare const calisthenicsParksIngestionService: {
    /**
     * Check if the service is available (has authentication)
     */
    isAvailable(): boolean;
    /**
     * Fetch spots from Calisthenics-Parks.com
     * NOTE: This requires authentication which is not yet implemented
     */
    fetchSpots(options?: {
        limit?: number;
        offset?: number;
        latitude?: number;
        longitude?: number;
        radius?: number;
    }): Promise<CPSpot[]>;
    /**
     * Ingest spots from Calisthenics-Parks.com into the database
     * NOTE: This is a placeholder implementation
     */
    ingestCalisthenicsParksSpots(): Promise<{
        created: number;
        updated: number;
        skipped: number;
        failed: number;
    }>;
    /**
     * Get statistics about Calisthenics-Parks data in our database
     */
    getIngestionStats(): Promise<{
        totalVenues: number;
        byCountry: Record<string, number>;
        lastSyncAt: Date | null;
    }>;
};
export default calisthenicsParksIngestionService;
