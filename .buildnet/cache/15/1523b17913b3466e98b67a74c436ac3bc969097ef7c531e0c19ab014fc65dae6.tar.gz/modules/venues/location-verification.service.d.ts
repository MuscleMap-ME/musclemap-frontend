/**
 * Location Verification Service
 *
 * Handles GPS verification, distance calculations, and anti-spoofing measures.
 */
import { LocationCoordinates, LocationVerificationResult, GpsSpoofingCheckResult } from './types';
export declare const locationVerificationService: {
    /**
     * Verify user is at a specific venue
     */
    verifyUserAtVenue(userId: string, venueId: string, coordinates: LocationCoordinates): Promise<LocationVerificationResult>;
    /**
     * Check for GPS spoofing indicators
     */
    checkGpsSpoofing(userId: string, coordinates: LocationCoordinates): Promise<GpsSpoofingCheckResult>;
    /**
     * Verify witness is near claimer (within MAX_WITNESS_DISTANCE_METERS)
     */
    verifyWitnessProximity(claimerCoordinates: LocationCoordinates, witnessCoordinates: LocationCoordinates): Promise<{
        verified: boolean;
        distanceMeters: number;
        warning?: string;
    }>;
    /**
     * Calculate distance between two coordinates
     */
    calculateDistance(lat1: number, lng1: number, lat2: number, lng2: number): number;
    /**
     * Get users currently checked in at a venue
     */
    getUsersAtVenue(venueId: string, excludeUserId?: string): Promise<{
        userId: string;
        username: string;
        displayName?: string;
        avatarUrl?: string;
        checkedInAt: Date;
    }[]>;
    /**
     * Check if user has had suspicious activity recently
     */
    hasRecentSuspiciousActivity(userId: string): Promise<boolean>;
    /**
     * Log location verification attempt for auditing
     */
    logVerificationAttempt(userId: string, venueId: string, coordinates: LocationCoordinates, result: LocationVerificationResult): Promise<void>;
};
export default locationVerificationService;
