"use strict";
/**
 * Calisthenics-Parks.com Data Ingestion Service
 *
 * Handles ingestion of outdoor fitness equipment data from Calisthenics-Parks.com.
 * This site has 26,000+ spots globally but requires authentication to access their API.
 *
 * NOTE: This service is currently a placeholder. To use it:
 * 1. Contact Calisthenics-Parks.com for data sharing partnership, OR
 * 2. Implement authenticated scraping with proper rate limiting
 *
 * Reference: https://calisthenics-parks.com/spots
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.calisthenicsParksIngestionService = void 0;
const client_1 = require("../../db/client");
const logger_1 = require("../../lib/logger");
const log = logger_1.loggers.core;
// API configuration (requires authentication)
const CP_BASE_URL = 'https://calisthenics-parks.com';
// Rate limiting for API/scraping
const API_DELAY_MS = 500; // Be conservative
// Mapping Calisthenics-Parks equipment tags to our equipment types
const CP_EQUIPMENT_MAPPING = {
    // Common equipment names
    high_bar: 'pull_up_bar',
    pullup_bar: 'pull_up_bar',
    pull_up_bar: 'pull_up_bar',
    chin_up_bar: 'pull_up_bar',
    parallel_bars: 'parallel_bars',
    p_bars: 'parallel_bars',
    dip_bars: 'dip_station',
    dip_station: 'dip_station',
    dips: 'dip_station',
    monkey_bars: 'monkey_bars',
    horizontal_ladder: 'monkey_bars',
    rings: 'rings',
    gymnastics_rings: 'rings',
    low_bar: 'pull_up_bar', // Map to pull_up_bar (low bars are still pull-up bars)
    low_pull_up_bar: 'pull_up_bar',
    incline_bench: 'ab_bench',
    sit_up_bench: 'ab_bench',
    ab_bench: 'ab_bench',
    wall_bars: 'swedish_wall',
    swedish_wall: 'swedish_wall',
    stall_bars: 'swedish_wall',
    balance_beam: 'balance_beam',
    rope: 'climbing_rope',
    rope_climb: 'climbing_rope',
    box: 'box_jump_platform',
    plyo_box: 'box_jump_platform',
    multi_station: 'multi_station',
    workout_station: 'multi_station',
};
// Helper function to parse equipment from CP tags
function parseCPEquipment(tags) {
    const equipment = [];
    for (const tag of tags) {
        const normalizedTag = tag.toLowerCase().replace(/[\s-]/g, '_');
        const mapped = CP_EQUIPMENT_MAPPING[normalizedTag];
        if (mapped && !equipment.includes(mapped)) {
            equipment.push(mapped);
        }
    }
    // If no specific equipment mapped, add generic multi_station
    if (equipment.length === 0 && tags.length > 0) {
        equipment.push('multi_station');
    }
    return equipment;
}
// Helper function to generate unique slug
function generateCPSlug(spotId, name) {
    const nameSlug = name
        .toLowerCase()
        .replace(/[^a-z0-9\s-]/g, '')
        .replace(/\s+/g, '-')
        .replace(/-+/g, '-')
        .substring(0, 40);
    return `cp-${spotId}-${nameSlug}`;
}
// Delay helper
function delay(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
}
exports.calisthenicsParksIngestionService = {
    /**
     * Check if the service is available (has authentication)
     */
    isAvailable() {
        // Check for authentication credentials
        const hasAuth = !!process.env.CALISTHENICS_PARKS_API_KEY;
        return hasAuth;
    },
    /**
     * Fetch spots from Calisthenics-Parks.com
     * NOTE: This requires authentication which is not yet implemented
     */
    async fetchSpots(options = {}) {
        const { limit = 100, offset = 0 } = options;
        // Check if service is available
        if (!this.isAvailable()) {
            log.warn('Calisthenics-Parks ingestion not available - missing API credentials');
            throw new Error('Calisthenics-Parks API credentials not configured. ' +
                'Set CALISTHENICS_PARKS_API_KEY environment variable or contact them for data partnership.');
        }
        // Placeholder for actual API call
        // When implemented, this would:
        // 1. Authenticate with their API
        // 2. Fetch spots with pagination
        // 3. Handle rate limiting
        log.info({ limit, offset }, 'Would fetch from Calisthenics-Parks API');
        // For now, return empty array
        return [];
    },
    /**
     * Ingest spots from Calisthenics-Parks.com into the database
     * NOTE: This is a placeholder implementation
     */
    async ingestCalisthenicsParksSpots() {
        // Check availability first
        if (!this.isAvailable()) {
            log.warn('Calisthenics-Parks ingestion skipped - service not available');
            return {
                created: 0,
                updated: 0,
                skipped: 0,
                failed: 0,
            };
        }
        const logId = await (0, client_1.queryOne)(`INSERT INTO venue_data_sync_log (data_source, source_dataset, sync_type, status)
       VALUES ('calisthenics_parks', 'global_spots', 'full', 'running')
       RETURNING id`);
        try {
            let created = 0;
            let updated = 0;
            let skipped = 0;
            let failed = 0;
            let offset = 0;
            const batchSize = 100;
            // Paginate through all spots
            while (true) {
                const spots = await this.fetchSpots({ limit: batchSize, offset });
                if (spots.length === 0) {
                    break;
                }
                for (const spot of spots) {
                    try {
                        await delay(50); // Light rate limiting for database writes
                        const slug = generateCPSlug(spot.id, spot.name);
                        const equipment = parseCPEquipment(spot.equipment || spot.tags || []);
                        // Check if venue already exists
                        const existing = await (0, client_1.queryOne)(`SELECT id FROM fitness_venues
               WHERE external_id = $1 AND data_source = 'calisthenics_parks'
               OR slug = $2`, [String(spot.id), slug]);
                        const venueData = {
                            name: spot.name,
                            slug,
                            venueType: 'calisthenics_park',
                            latitude: spot.latitude,
                            longitude: spot.longitude,
                            address: spot.address,
                            city: spot.city,
                            country: spot.country,
                            equipment: JSON.stringify(equipment),
                            hasCalisthenicsEquipment: equipment.some((e) => ['pull_up_bar', 'parallel_bars', 'dip_station', 'rings', 'monkey_bars'].includes(e)),
                            hasFreeWeights: false,
                            hasCardioEquipment: false,
                            isIndoor: spot.roofed || false,
                            isFree: true, // Assume free unless stated otherwise
                            is24Hour: spot.illuminated || false, // Illuminated suggests night access
                            isVerified: false,
                            isAccessible: spot.accessible || false,
                            dataSource: 'calisthenics_parks',
                            externalId: String(spot.id),
                            description: spot.description,
                            photos: spot.imageUrl ? JSON.stringify([{ url: spot.imageUrl, source: 'calisthenics_parks' }]) : null,
                        };
                        if (existing) {
                            // Update existing
                            await (0, client_1.query)(`UPDATE fitness_venues SET
                  name = $2, latitude = $3, longitude = $4, address = $5,
                  city = $6, equipment = $7::jsonb,
                  has_calisthenics_equipment = $8, is_indoor = $9, is_24_hour = $10,
                  is_accessible = $11, description = $12,
                  last_synced_at = NOW(), updated_at = NOW()
                 WHERE id = $1`, [
                                existing.id,
                                venueData.name,
                                venueData.latitude,
                                venueData.longitude,
                                venueData.address,
                                venueData.city,
                                venueData.equipment,
                                venueData.hasCalisthenicsEquipment,
                                venueData.isIndoor,
                                venueData.is24Hour,
                                venueData.isAccessible,
                                venueData.description,
                            ]);
                            updated++;
                        }
                        else {
                            // Create new
                            await (0, client_1.query)(`INSERT INTO fitness_venues (
                  name, slug, venue_type, latitude, longitude, address, city,
                  equipment, has_calisthenics_equipment, has_free_weights,
                  has_cardio_equipment, is_indoor, is_free, is_24_hour,
                  is_verified, is_accessible, data_source, external_id,
                  description, photos, last_synced_at
                ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8::jsonb, $9, $10, $11, $12, $13, $14, $15, $16, $17, $18, $19, $20::jsonb, NOW())
                ON CONFLICT (slug) DO UPDATE SET
                  external_id = EXCLUDED.external_id,
                  data_source = EXCLUDED.data_source,
                  last_synced_at = NOW()`, [
                                venueData.name,
                                venueData.slug,
                                venueData.venueType,
                                venueData.latitude,
                                venueData.longitude,
                                venueData.address,
                                venueData.city,
                                venueData.equipment,
                                venueData.hasCalisthenicsEquipment,
                                venueData.hasFreeWeights,
                                venueData.hasCardioEquipment,
                                venueData.isIndoor,
                                venueData.isFree,
                                venueData.is24Hour,
                                venueData.isVerified,
                                venueData.isAccessible,
                                venueData.dataSource,
                                venueData.externalId,
                                venueData.description,
                                venueData.photos,
                            ]);
                            created++;
                        }
                    }
                    catch (error) {
                        log.error({ error, spotId: spot.id }, 'Failed to process CP spot');
                        failed++;
                    }
                }
                offset += batchSize;
                await delay(API_DELAY_MS); // Rate limit between batches
            }
            // Update sync log
            await (0, client_1.query)(`UPDATE venue_data_sync_log SET
          status = $2,
          records_fetched = $3,
          records_created = $4,
          records_updated = $5,
          records_skipped = $6,
          records_failed = $7,
          completed_at = NOW()
         WHERE id = $1`, [logId.id, failed > 0 ? 'partial' : 'completed', created + updated + skipped + failed, created, updated, skipped, failed]);
            log.info({ created, updated, skipped, failed }, 'Calisthenics-Parks ingestion complete');
            return { created, updated, skipped, failed };
        }
        catch (error) {
            await (0, client_1.query)(`UPDATE venue_data_sync_log SET
          status = 'failed',
          error_message = $2,
          completed_at = NOW()
         WHERE id = $1`, [logId.id, error instanceof Error ? error.message : 'Unknown error']);
            throw error;
        }
    },
    /**
     * Get statistics about Calisthenics-Parks data in our database
     */
    async getIngestionStats() {
        const stats = await (0, client_1.queryOne)(`SELECT COUNT(*) as count, MAX(last_synced_at) as last_sync
       FROM fitness_venues
       WHERE data_source = 'calisthenics_parks'`);
        const byCountry = await (0, client_1.queryAll)(`SELECT COALESCE(country, 'Unknown') as country, COUNT(*) as count
       FROM fitness_venues
       WHERE data_source = 'calisthenics_parks'
       GROUP BY country
       ORDER BY count DESC
       LIMIT 20`);
        return {
            totalVenues: parseInt(stats?.count || '0'),
            byCountry: Object.fromEntries(byCountry.map((row) => [row.country, parseInt(row.count)])),
            lastSyncAt: stats?.last_sync || null,
        };
    },
};
exports.default = exports.calisthenicsParksIngestionService;
//# sourceMappingURL=calisthenics-parks-ingestion.service.js.map