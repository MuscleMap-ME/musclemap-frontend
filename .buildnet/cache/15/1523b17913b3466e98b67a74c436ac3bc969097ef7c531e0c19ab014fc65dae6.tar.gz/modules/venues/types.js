"use strict";
/**
 * Venue Records System Types
 *
 * Type definitions for the location-based achievement records system.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.RECORD_CATEGORY_LABELS = exports.EQUIPMENT_LABELS = exports.VENUE_CONSTANTS = void 0;
// ============================================
// CONSTANTS
// ============================================
exports.VENUE_CONSTANTS = {
    // Claim limits
    MAX_PENDING_CLAIMS_PER_USER: 2,
    CLAIM_EXPIRY_DAYS: 7,
    // Witness requirements
    MIN_WITNESS_ACCOUNT_AGE_DAYS: 30,
    WITNESS_COOLDOWN_HOURS: 24,
    MAX_WITNESS_DISTANCE_METERS: 50,
    // Location verification
    DEFAULT_VENUE_RADIUS_METERS: 100,
    MAX_VENUE_RADIUS_METERS: 500,
    MIN_LOCATION_CONFIDENCE_METERS: 100,
    // Video requirements
    MIN_VIDEO_DURATION_SECONDS: 5,
    MAX_VIDEO_DURATION_SECONDS: 120,
    MAX_VIDEO_SIZE_BYTES: 100 * 1024 * 1024, // 100MB
    // Economy
    CLAIM_FEE_CREDITS: 15,
    VERIFIED_RECORD_REWARD: 100,
    RECORD_BREAKER_BONUS: 500,
    WITNESS_REWARD: 25,
    // Anti-cheat
    MAX_LOCATION_JUMP_METERS_PER_SECOND: 100,
    SUSPICIOUS_DEVICE_COOLDOWN_HOURS: 24,
    // Auto-checkout
    AUTO_CHECKOUT_MINUTES: 240, // 4 hours
};
exports.EQUIPMENT_LABELS = {
    // Calisthenics/Bodyweight
    pull_up_bar: 'Pull-Up Bar',
    dip_bars: 'Dip Bars',
    dip_station: 'Dip Station',
    parallel_bars: 'Parallel Bars',
    monkey_bars: 'Monkey Bars',
    vertical_pole: 'Vertical Pole',
    climbing_boulder: 'Climbing Boulder',
    climbing_rope: 'Climbing Rope',
    pegboard: 'Pegboard',
    box_jump_platform: 'Box Jump Platform',
    rings: 'Gymnastic Rings',
    swedish_wall: 'Swedish Wall/Stall Bars',
    balance_beam: 'Balance Beam',
    // Free Weights
    bench_press: 'Bench Press',
    squat_rack: 'Squat Rack',
    barbell: 'Barbell',
    dumbbells: 'Dumbbells',
    weight_belt: 'Weight Belt',
    weight_room: 'Weight Room',
    // Machines
    cable_machine: 'Cable Machine',
    leg_press: 'Leg Press',
    chest_press: 'Chest Press',
    lat_pull: 'Lat Pulldown',
    shoulder_press: 'Shoulder Press',
    ab_bench: 'Ab Bench',
    back_extension: 'Back Extension',
    multi_station: 'Multi-Station',
    // Cardio (outdoor)
    elliptical_outdoor: 'Outdoor Elliptical',
    stationary_bike_outdoor: 'Outdoor Bike',
    rowing_machine_outdoor: 'Outdoor Rower',
    stepper_outdoor: 'Outdoor Stepper',
    cardio_room: 'Cardio Room',
    // Facilities
    pool: 'Pool',
    track: 'Track',
    basketball_court: 'Basketball Court',
    tennis_court: 'Tennis Court',
    other: 'Other',
};
exports.RECORD_CATEGORY_LABELS = {
    calisthenics_reps: 'Calisthenics (Reps)',
    calisthenics_hold: 'Static Holds',
    weight_lift: 'Weight Lifting',
    gymnastics_skill: 'Gymnastics Skills',
    parkour_move: 'Parkour',
    endurance: 'Endurance',
    bodyweight_weighted: 'Weighted Bodyweight',
};
//# sourceMappingURL=types.js.map