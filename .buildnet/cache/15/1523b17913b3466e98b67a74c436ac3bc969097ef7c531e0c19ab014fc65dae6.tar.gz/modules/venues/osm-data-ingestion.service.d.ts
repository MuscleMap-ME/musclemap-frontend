/**
 * OpenStreetMap Data Ingestion Service
 *
 * Handles ingestion of outdoor fitness equipment data from OpenStreetMap via Overpass API.
 * OSM uses the "leisure=fitness_station" tag for outdoor fitness equipment.
 *
 * Reference: https://wiki.openstreetmap.org/wiki/Tag:leisure%3Dfitness_station
 */
import { EquipmentType } from './types';
interface OSMNode {
    type: 'node';
    id: number;
    lat: number;
    lon: number;
    tags?: Record<string, string>;
}
interface OSMWay {
    type: 'way';
    id: number;
    center?: {
        lat: number;
        lon: number;
    };
    nodes?: number[];
    tags?: Record<string, string>;
}
type OSMElement = OSMNode | OSMWay;
export declare const osmDataIngestionService: {
    /**
     * Query Overpass API for fitness stations in NYC
     */
    queryOverpassForFitnessStations(): Promise<OSMElement[]>;
    /**
     * Ingest OpenStreetMap fitness stations into the database
     */
    ingestOsmFitnessStations(): Promise<{
        created: number;
        updated: number;
        skipped: number;
        failed: number;
    }>;
    /**
     * Get all OSM-sourced venues
     */
    getOsmVenues(options?: {
        limit?: number;
        hasEquipment?: EquipmentType[];
        borough?: string;
    }): Promise<Array<{
        id: string;
        name: string;
        osmId: number;
        latitude: number;
        longitude: number;
        equipment: EquipmentType[];
        borough: string | null;
        osmTags: Record<string, string>;
    }>>;
    /**
     * Update OSM venue with user-provided equipment data
     */
    updateOsmVenueEquipment(venueId: string, equipment: EquipmentType[], userId: string): Promise<void>;
};
export default osmDataIngestionService;
