/**
 * Crowdsourcing Service
 *
 * Handles user-contributed venue data:
 * - New venue submissions
 * - Venue verification ("I was here")
 * - Equipment condition updates
 * - Photo contributions
 * - Issue reports
 * - Credits/rewards for contributions
 */
import { EquipmentType, VenueType } from './types';
export interface VenueSubmission {
    id: string;
    userId: string;
    status: 'pending' | 'under_review' | 'approved' | 'rejected' | 'merged' | 'duplicate';
    proposedName: string;
    proposedVenueType: VenueType;
    latitude: number;
    longitude: number;
    proposedAddress?: string;
    proposedCity: string;
    proposedBorough?: string;
    proposedPostalCode?: string;
    proposedEquipment: EquipmentType[];
    proposedHours?: Record<string, string>;
    proposedIsFree: boolean;
    proposedIs24Hour: boolean;
    photoUrls: string[];
    notes?: string;
    howDiscovered?: string;
    locationAccuracyMeters?: number;
    reviewedBy?: string;
    reviewerNotes?: string;
    rejectionReason?: string;
    createdVenueId?: string;
    mergedIntoVenueId?: string;
    detectedDuplicateVenueId?: string;
    duplicateDistanceMeters?: number;
    creditsAwarded: number;
    submittedAt: Date;
    reviewedAt?: Date;
}
export interface VenueContribution {
    id: string;
    venueId: string;
    userId: string;
    contributionType: string;
    details: Record<string, unknown>;
    notes?: string;
    photoUrl?: string;
    verificationLatitude?: number;
    verificationLongitude?: number;
    distanceFromVenueMeters?: number;
    locationVerified: boolean;
    equipmentItemId?: string;
    oldCondition?: string;
    newCondition?: string;
    creditsAwarded: number;
    isFlagged: boolean;
    reviewStatus: 'pending' | 'approved' | 'rejected';
    contributedAt: Date;
}
export interface VenuePhoto {
    id: string;
    venueId: string;
    userId?: string;
    url: string;
    thumbnailUrl?: string;
    caption?: string;
    photoType: 'general' | 'equipment' | 'entrance' | 'surroundings' | 'hours_sign' | 'accessibility' | 'condition_report';
    equipmentShown: EquipmentType[];
    isApproved: boolean;
    isPrimary: boolean;
    isFlagged: boolean;
    uploadedAt: Date;
}
export interface VenueReport {
    id: string;
    venueId: string;
    userId: string;
    reportType: string;
    description: string;
    severity: 'low' | 'medium' | 'high' | 'critical';
    photoUrls: string[];
    status: 'pending' | 'investigating' | 'resolved_fixed' | 'resolved_closed' | 'dismissed';
    resolutionNotes?: string;
    actionTaken?: string;
    creditsAwarded: number;
    reportedAt: Date;
    resolvedAt?: Date;
}
export interface ContributorStats {
    userId: string;
    venuesSubmitted: number;
    venuesApproved: number;
    verificationsCount: number;
    photosUploaded: number;
    reportsSubmitted: number;
    reportsResolved: number;
    equipmentUpdates: number;
    approvalRate: number;
    currentStreak: number;
    longestStreak: number;
    totalCreditsEarned: number;
    contributorLevel: number;
    contributorTitle: string;
    lastContributionAt?: Date;
}
export declare const crowdsourcingService: {
    /**
     * Submit a new venue location
     */
    submitVenue(userId: string, data: {
        name: string;
        venueType: VenueType;
        latitude: number;
        longitude: number;
        address?: string;
        borough?: string;
        postalCode?: string;
        equipment: EquipmentType[];
        hours?: Record<string, string>;
        isFree?: boolean;
        is24Hour?: boolean;
        photos?: string[];
        notes?: string;
        howDiscovered?: string;
        locationAccuracyMeters?: number;
    }): Promise<VenueSubmission>;
    /**
     * Get submission by ID
     */
    getSubmission(submissionId: string): Promise<VenueSubmission | null>;
    /**
     * Get user's submissions
     */
    getUserSubmissions(userId: string, options?: {
        status?: string;
        limit?: number;
    }): Promise<VenueSubmission[]>;
    /**
     * Get pending submissions for admin review
     */
    getPendingSubmissions(limit?: number): Promise<VenueSubmission[]>;
    /**
     * Approve a venue submission (admin only)
     */
    approveSubmission(submissionId: string, reviewerId: string, options?: {
        notes?: string;
    }): Promise<{
        submission: VenueSubmission;
        venue: Record<string, unknown>;
    }>;
    /**
     * Reject a venue submission
     */
    rejectSubmission(submissionId: string, reviewerId: string, reason: string): Promise<VenueSubmission>;
    /**
     * Verify a venue exists (user confirms they visited)
     */
    verifyVenueExists(venueId: string, userId: string, data: {
        latitude: number;
        longitude: number;
        notes?: string;
    }): Promise<VenueContribution>;
    /**
     * Verify equipment at a venue
     */
    verifyEquipment(venueId: string, userId: string, data: {
        equipment: EquipmentType[];
        accurate: boolean;
        notes?: string;
        latitude?: number;
        longitude?: number;
    }): Promise<VenueContribution>;
    /**
     * Add a photo to a venue
     */
    addPhoto(venueId: string, userId: string, data: {
        url: string;
        thumbnailUrl?: string;
        caption?: string;
        photoType?: VenuePhoto["photoType"];
        equipmentShown?: EquipmentType[];
        latitude?: number;
        longitude?: number;
    }): Promise<VenuePhoto>;
    /**
     * Get photos for a venue
     */
    getVenuePhotos(venueId: string, limit?: number): Promise<VenuePhoto[]>;
    /**
     * Report an issue with a venue
     */
    reportIssue(venueId: string, userId: string, data: {
        reportType: string;
        description: string;
        severity?: "low" | "medium" | "high" | "critical";
        photoUrls?: string[];
        duplicateVenueId?: string;
        latitude?: number;
        longitude?: number;
    }): Promise<VenueReport>;
    /**
     * Resolve an issue report (admin)
     */
    resolveReport(reportId: string, resolverId: string, data: {
        status: "resolved_fixed" | "resolved_closed" | "dismissed";
        resolutionNotes: string;
        actionTaken?: string;
    }): Promise<VenueReport>;
    /**
     * Get contributor stats for a user
     */
    getContributorStats(userId: string): Promise<ContributorStats | null>;
    /**
     * Update contributor stats
     */
    updateContributorStats(userId: string, updates: Partial<{
        venuesSubmitted: number;
        venuesApproved: number;
        verificationsCount: number;
        photosUploaded: number;
        reportsSubmitted: number;
        reportsResolved: number;
        equipmentUpdates: number;
    }>): Promise<void>;
    /**
     * Check and update contributor level
     */
    checkContributorLevelUp(userId: string): Promise<void>;
    /**
     * Award credits to user (integrates with economy system)
     */
    awardCredits(userId: string, amount: number, reason: string, metadata: Record<string, unknown>): Promise<void>;
    rowToSubmission(row: Record<string, unknown>): VenueSubmission;
    rowToContribution(row: Record<string, unknown>): VenueContribution;
    rowToPhoto(row: Record<string, unknown>): VenuePhoto;
    rowToReport(row: Record<string, unknown>): VenueReport;
};
export default crowdsourcingService;
