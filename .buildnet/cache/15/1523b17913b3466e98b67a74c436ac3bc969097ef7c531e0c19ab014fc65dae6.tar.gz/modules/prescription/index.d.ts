/**
 * AI-Powered Exercise Prescription Engine v2
 *
 * Multi-factor scoring algorithm that considers:
 * - User fitness level and experience
 * - Equipment availability
 * - Time constraints
 * - Injury history and contraindications
 * - Muscle imbalance correction
 * - Recovery status from previous workouts
 * - Periodization phase
 * - Skill level requirements
 *
 * Based on research from NSCA, ACSM, and sports science literature.
 */
export interface UserContext {
    userId: string;
    fitnessLevel: number;
    experienceLevel: 'beginner' | 'intermediate' | 'advanced' | 'elite';
    equipment: string[];
    location: 'home' | 'gym' | 'outdoor' | 'travel';
    timeAvailable: number;
    goals: string[];
    archetypeId?: string;
}
export interface PrescriptionRequest {
    userContext: UserContext;
    targetMuscles?: string[];
    excludeMuscles?: string[];
    exerciseTypes?: string[];
    maxExercises?: number;
    includeWarmup?: boolean;
    includeCooldown?: boolean;
}
export interface ScoredExercise {
    exerciseId: string;
    name: string;
    type: string;
    score: number;
    scoreBreakdown: {
        equipmentMatch: number;
        goalAlignment: number;
        muscleNeed: number;
        recoveryAdjustment: number;
        skillAppropriate: number;
        periodizationFit: number;
        varietyBonus: number;
        injuryPenalty: number;
    };
    sets: number;
    reps: number;
    restSeconds: number;
    notes?: string;
    primaryMuscles: string[];
}
export interface PrescriptionResult {
    id: string;
    exercises: ScoredExercise[];
    warmup: ScoredExercise[];
    cooldown: ScoredExercise[];
    totalDuration: number;
    muscleCoverage: Record<string, number>;
    periodizationPhase?: string;
    difficulty: string;
    metadata: {
        algorithVersion: string;
        generatedAt: string;
        factorsConsidered: string[];
    };
}
interface Exercise {
    id: string;
    name: string;
    type: string;
    difficulty: number;
    primary_muscles: string[];
    equipment_required?: string[];
    equipment_optional?: string[];
    locations?: string[];
    movement_pattern?: string;
    skill_level?: string;
    source_methodology?: string;
    contraindicated_injuries?: string[];
    is_rehab_exercise?: boolean;
}
interface UserInjury {
    injury_profile_id: string;
    severity: string;
    status: string;
    contraindicated_movements: string[];
}
interface WorkoutHistory {
    exercise_id: string;
    last_performed: Date;
    times_performed: number;
    avg_rpe: number;
}
interface TrainingPhase {
    phase_type: string;
    volume_modifier: number;
    intensity_modifier: number;
    exercise_types: string[];
}
export declare class PrescriptionEngine {
    private readonly algorithmVersion;
    /**
     * Generate a personalized exercise prescription
     */
    prescribe(request: PrescriptionRequest): Promise<PrescriptionResult>;
    /**
     * Parse comma-separated string to array, handling null/undefined
     */
    private parseCommaSeparated;
    /**
     * Get exercises available based on equipment and location
     */
    private getAvailableExercises;
    /**
     * Get user's active injuries
     */
    private getUserInjuries;
    /**
     * Get user's recent workout history
     */
    private getWorkoutHistory;
    /**
     * Get user's current periodization phase
     * Returns null if user has no active training cycle (most users won't)
     */
    private getCurrentTrainingPhase;
    /**
     * Get muscle training stats for balance detection
     */
    private getMuscleStats;
    /**
     * Get user exercise preferences
     * Maps preference_type to a numeric score:
     * - favorite: +20
     * - avoid/injured/no_equipment/too_difficult: -100 (effectively exclude)
     * - too_easy: -20 (mild penalty)
     */
    private getUserPreferences;
    /**
     * Score all available exercises (including recovery factor)
     */
    private scoreExercises;
    /**
     * Calculate goal alignment score
     */
    private calculateGoalAlignment;
    /**
     * Calculate muscle need score (prioritize undertrained muscles)
     */
    private calculateMuscleNeed;
    /**
     * Calculate recovery score based on recent training
     */
    private calculateRecoveryScore;
    /**
     * Calculate skill appropriateness score
     */
    private calculateSkillScore;
    /**
     * Calculate periodization fit score
     */
    private calculatePeriodizationFit;
    /**
     * Calculate variety bonus
     */
    private calculateVarietyBonus;
    /**
     * Calculate injury penalty
     */
    private calculateInjuryPenalty;
    /**
     * Apply recovery penalty based on exercise intensity and current recovery state
     * Penalizes high-intensity exercises when recovery is poor,
     * and favors low-intensity/mobility exercises
     */
    private applyRecoveryPenalty;
    /**
     * Recommend sets based on phase and context
     */
    private recommendSets;
    /**
     * Recommend reps based on phase and exercise type
     */
    private recommendReps;
    /**
     * Recommend rest period
     */
    private recommendRest;
    /**
     * Select optimal set of exercises (adjusted for recovery)
     */
    private selectExercises;
    /**
     * Calculate max exercises based on time
     */
    private calculateMaxExercises;
    /**
     * Generate warmup exercises
     */
    private generateWarmup;
    /**
     * Generate cooldown exercises
     */
    private generateCooldown;
    /**
     * Calculate muscle coverage map
     */
    private calculateMuscleCoverage;
    /**
     * Estimate total workout duration
     */
    private estimateDuration;
    /**
     * Determine workout difficulty rating (adjusted for recovery)
     */
    private determineDifficulty;
    /**
     * Get intensity multiplier based on recovery score
     * Maps recovery classification to volume/intensity adjustments
     */
    private getIntensityMultiplier;
    /**
     * Adjust exercises based on recovery state
     * Modifies sets, reps, and adds recovery-appropriate notes
     */
    private adjustForRecovery;
    /**
     * Store prescription for ML feedback
     */
    private storePrescriptionHistory;
}
export declare const prescriptionEngine: PrescriptionEngine;
export type { Exercise, UserInjury, WorkoutHistory, TrainingPhase };
