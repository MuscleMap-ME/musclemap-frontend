/**
 * Anti-Cheat Module
 *
 * Prevents gaming of leaderboards through:
 * - Rate limiting (max submissions per day)
 * - Outlier detection (extreme jumps from previous values)
 * - Impossible value detection
 * - Suspicious pattern detection
 * - Geo-verification mismatches
 */
export declare const FLAG_TYPES: {
    readonly RAPID_SUBMISSIONS: "rapid_submissions";
    readonly EXTREME_JUMP: "extreme_jump";
    readonly IMPOSSIBLE_VALUE: "impossible_value";
    readonly SUSPICIOUS_PATTERN: "suspicious_pattern";
    readonly GEO_MISMATCH: "geo_mismatch";
    readonly TIME_ANOMALY: "time_anomaly";
};
export type FlagType = (typeof FLAG_TYPES)[keyof typeof FLAG_TYPES];
export declare const SEVERITY_LEVELS: {
    readonly LOW: "low";
    readonly MEDIUM: "medium";
    readonly HIGH: "high";
    readonly CRITICAL: "critical";
};
export type Severity = (typeof SEVERITY_LEVELS)[keyof typeof SEVERITY_LEVELS];
export declare const FLAG_STATUS: {
    readonly PENDING: "pending";
    readonly REVIEWED: "reviewed";
    readonly DISMISSED: "dismissed";
    readonly CONFIRMED: "confirmed";
};
export type FlagStatus = (typeof FLAG_STATUS)[keyof typeof FLAG_STATUS];
export interface SuspiciousFlag {
    id: string;
    userId: string;
    leaderboardEntryId?: string;
    workoutId?: string;
    flagType: FlagType;
    severity: Severity;
    details: Record<string, unknown>;
    status: FlagStatus;
    reviewedBy?: string;
    reviewedAt?: Date;
    createdAt: Date;
}
export interface RateLimitStatus {
    submissionsToday: number;
    maxSubmissions: number;
    isLimited: boolean;
    resetsAt: Date;
}
export declare const antiCheatService: {
    /**
     * Check if user is rate limited
     */
    checkRateLimit(userId: string): Promise<RateLimitStatus>;
    /**
     * Increment submission count
     */
    incrementSubmissionCount(userId: string): Promise<void>;
    /**
     * Detect if a value is an outlier compared to user's history
     */
    detectOutlier(userId: string, exerciseId: string, metricKey: string, value: number, direction?: "higher" | "lower"): Promise<{
        isOutlier: boolean;
        previousBest?: number;
        jumpRatio?: number;
    }>;
    /**
     * Check if a value is physically impossible
     */
    isImpossibleValue(exerciseId: string, metricKey: string, value: number): {
        isImpossible: boolean;
        limit?: number;
    };
    /**
     * Flag a submission as suspicious
     */
    flagSuspicious(params: {
        userId: string;
        flagType: FlagType;
        severity?: Severity;
        leaderboardEntryId?: string;
        workoutId?: string;
        details?: Record<string, unknown>;
    }): Promise<SuspiciousFlag>;
    /**
     * Validate a workout submission
     * Returns null if valid, or a SuspiciousFlag if suspicious
     */
    validateWorkoutSubmission(params: {
        userId: string;
        workoutId: string;
        exerciseId: string;
        metricKey: string;
        value: number;
        direction?: "higher" | "lower";
    }): Promise<SuspiciousFlag | null>;
    /**
     * Get pending flags for review
     */
    getPendingFlags(options?: {
        limit?: number;
        offset?: number;
        severity?: Severity;
    }): Promise<{
        flags: SuspiciousFlag[];
        total: number;
    }>;
    /**
     * Review a flag
     */
    reviewFlag(flagId: string, reviewerId: string, decision: "dismissed" | "confirmed"): Promise<void>;
    /**
     * Get user's flag history
     */
    getUserFlags(userId: string): Promise<SuspiciousFlag[]>;
    /**
     * Check if user has too many confirmed flags (potential ban candidate)
     */
    getUserFlagSummary(userId: string): Promise<{
        totalFlags: number;
        confirmedFlags: number;
        recentFlags: number;
        isHighRisk: boolean;
    }>;
};
export default antiCheatService;
