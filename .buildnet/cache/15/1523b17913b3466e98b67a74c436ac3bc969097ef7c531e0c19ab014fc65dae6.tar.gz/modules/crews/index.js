"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports, p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.registerCrewsRoutes = registerCrewsRoutes;
const auth_1 = require("../../http/routes/auth");
const crewsService = __importStar(require("./service"));
function registerCrewsRoutes(fastify) {
    // Get user's crew
    fastify.get('/crews/my', {
        preHandler: [auth_1.authenticate],
    }, async (request, _reply) => {
        const userId = request.user.userId;
        const result = await crewsService.getUserCrew(userId);
        if (!result) {
            return { data: null };
        }
        const [members, wars, stats] = await Promise.all([
            crewsService.getCrewMembers(result.crew.id),
            crewsService.getCrewWars(result.crew.id),
            crewsService.getCrewStats(result.crew.id),
        ]);
        return {
            data: {
                crew: result.crew,
                membership: result.membership,
                members,
                wars,
                stats,
            },
        };
    });
    // Get leaderboard (public route, before :id)
    fastify.get('/crews/leaderboard', async (request, _reply) => {
        const limit = parseInt(request.query.limit || '50', 10);
        const leaderboard = await crewsService.getCrewLeaderboard(limit);
        return { data: leaderboard };
    });
    // Search crews
    fastify.get('/crews/search', {
        preHandler: [auth_1.authenticate],
    }, async (request, _reply) => {
        const query = request.query.q || '';
        const limit = parseInt(request.query.limit || '20', 10);
        const crews = await crewsService.searchCrews(query, limit);
        return { data: crews };
    });
    // Leave crew
    fastify.post('/crews/leave', {
        preHandler: [auth_1.authenticate],
    }, async (request, _reply) => {
        const userId = request.user.userId;
        await crewsService.leaveCrew(userId);
        return { success: true };
    });
    // Create a new crew
    fastify.post('/crews', {
        preHandler: [auth_1.authenticate],
    }, async (request, reply) => {
        const userId = request.user.userId;
        const { name, tag, description, color } = request.body;
        if (!name || !tag) {
            return reply.status(400).send({ error: 'Name and tag are required' });
        }
        const crew = await crewsService.createCrew(userId, name, tag, description, color);
        reply.status(201);
        return { data: crew };
    });
    // Get crew by ID
    fastify.get('/crews/:id', {
        preHandler: [auth_1.authenticate],
    }, async (request, reply) => {
        const crew = await crewsService.getCrew(request.params.id);
        if (!crew) {
            return reply.status(404).send({ error: 'Crew not found' });
        }
        const [members, stats] = await Promise.all([
            crewsService.getCrewMembers(crew.id),
            crewsService.getCrewStats(crew.id),
        ]);
        return { data: { crew, members, stats } };
    });
    // Invite user to crew
    fastify.post('/crews/:id/invite', {
        preHandler: [auth_1.authenticate],
    }, async (request, reply) => {
        const userId = request.user.userId;
        const { inviteeId } = request.body;
        if (!inviteeId) {
            return reply.status(400).send({ error: 'inviteeId is required' });
        }
        const invite = await crewsService.inviteToCrew(request.params.id, userId, inviteeId);
        reply.status(201);
        return { data: invite };
    });
    // Accept invite
    fastify.post('/crews/invites/:id/accept', {
        preHandler: [auth_1.authenticate],
    }, async (request, _reply) => {
        const userId = request.user.userId;
        const member = await crewsService.acceptInvite(request.params.id, userId);
        return { data: member };
    });
    // Start crew war
    fastify.post('/crews/:id/war', {
        preHandler: [auth_1.authenticate],
    }, async (request, reply) => {
        const userId = request.user.userId;
        const { defendingCrewId, durationDays } = request.body;
        // Verify user is owner/captain of the crew
        const userCrew = await crewsService.getUserCrew(userId);
        if (!userCrew || userCrew.crew.id !== request.params.id) {
            return reply.status(403).send({ error: 'You are not in this crew' });
        }
        if (userCrew.membership.role === 'member') {
            return reply.status(403).send({ error: 'Only owners and captains can start wars' });
        }
        if (!defendingCrewId) {
            return reply.status(400).send({ error: 'defendingCrewId is required' });
        }
        const war = await crewsService.startCrewWar(request.params.id, defendingCrewId, durationDays || 7);
        reply.status(201);
        return { data: war };
    });
    // Get crew wars
    fastify.get('/crews/:id/wars', {
        preHandler: [auth_1.authenticate],
    }, async (request, _reply) => {
        const wars = await crewsService.getCrewWars(request.params.id);
        return { data: wars };
    });
}
__exportStar(require("./types"), exports);
__exportStar(require("./service"), exports);
//# sourceMappingURL=index.js.map