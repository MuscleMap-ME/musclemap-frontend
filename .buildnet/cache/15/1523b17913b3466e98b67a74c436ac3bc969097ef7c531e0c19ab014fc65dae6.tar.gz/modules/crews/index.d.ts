/**
 * Crews Router
 *
 * REST API endpoints for crews and Crew Wars.
 */
import type { FastifyInstance } from 'fastify';
export declare function registerCrewsRoutes(fastify: FastifyInstance): void;
export * from './types';
export * from './service';
