import type { Crew, CrewMember, CrewInvite, CrewWar, CrewWarWithDetails, CrewLeaderboard, CrewStats } from './types';
/**
 * Create a new crew
 */
export declare function createCrew(ownerId: string, name: string, tag: string, description?: string, color?: string): Promise<Crew>;
/**
 * Get a crew by ID
 */
export declare function getCrew(crewId: string): Promise<Crew | null>;
/**
 * Get user's crew
 */
export declare function getUserCrew(userId: string): Promise<{
    crew: Crew;
    membership: CrewMember;
} | null>;
/**
 * Get crew members
 */
export declare function getCrewMembers(crewId: string): Promise<CrewMember[]>;
/**
 * Invite user to crew
 */
export declare function inviteToCrew(crewId: string, inviterId: string, inviteeId: string): Promise<CrewInvite>;
/**
 * Accept crew invite
 */
export declare function acceptInvite(inviteId: string, userId: string): Promise<CrewMember>;
/**
 * Leave crew
 */
export declare function leaveCrew(userId: string): Promise<void>;
/**
 * Challenge another crew to war
 */
export declare function startCrewWar(challengerCrewId: string, defendingCrewId: string, durationDays?: number): Promise<CrewWar>;
/**
 * Record workout contribution to crew war
 */
export declare function recordCrewWorkout(userId: string, tu: number): Promise<void>;
/**
 * Get active crew wars for a crew
 */
export declare function getCrewWars(crewId: string): Promise<CrewWarWithDetails[]>;
/**
 * Get crew leaderboard
 */
export declare function getCrewLeaderboard(limit?: number): Promise<CrewLeaderboard[]>;
/**
 * Get crew stats
 */
export declare function getCrewStats(crewId: string): Promise<CrewStats>;
/**
 * Search crews
 */
export declare function searchCrews(query: string, limit?: number): Promise<Crew[]>;
