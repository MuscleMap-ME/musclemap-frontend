/**
 * Food Search Service
 *
 * Multi-source food search with caching:
 * 1. Local cache (PostgreSQL)
 * 2. Open Food Facts (barcode + search)
 * 3. USDA FoodData Central
 * 4. FatSecret (if configured)
 */
import type { Food, CustomFood, FoodSearchResult, FoodSearchOptions, CreateCustomFoodInput } from './types';
export declare class FoodSearchService {
    search(options: FoodSearchOptions, userId?: string): Promise<FoodSearchResult>;
    searchByBarcode(barcode: string): Promise<FoodSearchResult>;
    private searchLocalCache;
    private searchUSDA;
    private parseUSDAFood;
    private extractUSDAMicronutrients;
    private searchOpenFoodFacts;
    private parseOpenFoodFactsProduct;
    private searchFatSecret;
    searchUserCustomFoods(userId: string, query: string, limit: number): Promise<CustomFood[]>;
    createCustomFood(userId: string, input: CreateCustomFoodInput): Promise<CustomFood>;
    getCustomFood(id: string, userId: string): Promise<CustomFood | null>;
    getUserCustomFoods(userId: string, limit?: number): Promise<CustomFood[]>;
    deleteCustomFood(id: string, userId: string): Promise<boolean>;
    getFoodById(id: string): Promise<Food | null>;
    getFrequentFoods(userId: string, limit?: number): Promise<Food[]>;
    updateFoodUsage(userId: string, foodId: string): Promise<void>;
    private cacheFood;
    private mergeResults;
    private deduplicateFoods;
    private customFoodToFood;
    private mapFoodRow;
    private mapCustomFoodRow;
}
export declare const foodSearchService: FoodSearchService;
