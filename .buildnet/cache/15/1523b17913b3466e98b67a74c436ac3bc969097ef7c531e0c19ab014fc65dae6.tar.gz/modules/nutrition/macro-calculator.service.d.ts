/**
 * Macro Calculator Service
 *
 * Calculates TDEE, BMR, and macro targets based on user metrics
 */
import type { NutritionGoals, CalculateGoalsInput, ArchetypeNutritionProfile } from './types';
export declare class MacroCalculatorService {
    private readonly activityMultipliers;
    private readonly goalAdjustments;
    private readonly defaultMacroSplit;
    private readonly proteinTargets;
    /**
     * Calculate BMR using Mifflin-St Jeor equation (most accurate)
     */
    calculateBMR(weightKg: number, heightCm: number, age: number, sex: 'male' | 'female' | 'other'): number;
    /**
     * Calculate TDEE (Total Daily Energy Expenditure)
     */
    calculateTDEE(bmr: number, activityLevel: keyof typeof this.activityMultipliers): number;
    /**
     * Calculate target calories based on goal
     */
    calculateTargetCalories(tdee: number, goalType: 'lose' | 'maintain' | 'gain', intensity?: 'slow' | 'moderate' | 'aggressive'): number;
    /**
     * Calculate macro targets from calories
     */
    calculateMacros(calories: number, weightKg: number, activityLevel: keyof typeof this.activityMultipliers, archetypeProfile?: ArchetypeNutritionProfile | null): {
        proteinG: number;
        carbsG: number;
        fatG: number;
    };
    /**
     * Calculate workout day bonuses
     */
    calculateWorkoutDayBonus(baseCalories: number, baseProtein: number, baseCarbs: number, activityLevel: keyof typeof this.activityMultipliers): {
        calories: number;
        proteinG: number;
        carbsG: number;
    };
    /**
     * Calculate and save nutrition goals for a user
     */
    calculateAndSaveGoals(userId: string, input: CalculateGoalsInput): Promise<NutritionGoals>;
    /**
     * Get current goals for a user
     */
    getGoals(userId: string): Promise<NutritionGoals | null>;
    /**
     * Adjust goals based on workout completion
     */
    adjustForWorkout(userId: string, tuBurned: number, musclesTrained: string[]): Promise<{
        calorieAdjustment: number;
        proteinAdjustment: number;
    }>;
    /**
     * Generate macro recommendations for a specific meal
     */
    generateMealMacros(totalGoals: NutritionGoals, remainingCalories: number, remainingProtein: number, mealType: string, isPostWorkout: boolean): {
        calories: number;
        proteinG: number;
        carbsG: number;
        fatG: number;
    };
    private mapGoalsRow;
}
export declare const macroCalculatorService: MacroCalculatorService;
