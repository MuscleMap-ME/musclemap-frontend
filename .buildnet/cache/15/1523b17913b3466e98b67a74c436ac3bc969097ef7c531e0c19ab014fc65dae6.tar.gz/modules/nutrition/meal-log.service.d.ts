/**
 * Meal Log Service
 *
 * Handles meal logging, daily summaries, and hydration tracking
 */
import type { MealLog, CreateMealLogInput, UpdateMealLogInput, DailyNutritionSummary, HydrationLog, CreateHydrationLogInput, MealType } from './types';
export declare class MealLogService {
    createMealLog(userId: string, input: CreateMealLogInput): Promise<MealLog>;
    updateMealLog(id: string, userId: string, input: UpdateMealLogInput): Promise<MealLog | null>;
    deleteMealLog(id: string, userId: string): Promise<boolean>;
    getMealLog(id: string, userId: string): Promise<MealLog | null>;
    getMealsByDate(userId: string, date: string): Promise<MealLog[]>;
    getMealsByDateRange(userId: string, startDate: string, endDate: string): Promise<MealLog[]>;
    getRecentMeals(userId: string, limit?: number): Promise<MealLog[]>;
    getDailySummary(userId: string, date: string): Promise<DailyNutritionSummary | null>;
    getDailySummaries(userId: string, startDate: string, endDate: string): Promise<DailyNutritionSummary[]>;
    updateDailySummaryGoals(userId: string, date: string): Promise<void>;
    logHydration(userId: string, input: CreateHydrationLogInput): Promise<HydrationLog>;
    getHydrationByDate(userId: string, date: string): Promise<HydrationLog[]>;
    getDailyWaterTotal(userId: string, date: string): Promise<number>;
    private updateDailyWater;
    copyMealsFromDate(userId: string, sourceDate: string, targetDate: string, mealTypes?: MealType[]): Promise<MealLog[]>;
    private getRecipeNutrition;
    private mapMealLogRow;
    private mapSummaryRow;
    private mapHydrationRow;
}
export declare const mealLogService: MealLogService;
