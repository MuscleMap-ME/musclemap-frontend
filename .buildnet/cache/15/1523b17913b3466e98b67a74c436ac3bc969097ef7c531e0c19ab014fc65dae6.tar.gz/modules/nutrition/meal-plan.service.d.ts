/**
 * Meal Plan Service
 *
 * Handles meal plan creation, management, and AI-assisted generation
 */
import type { MealPlan, MealPlanItem, CreateMealPlanInput, GenerateMealPlanInput, ShoppingListItem, MealType } from './types';
export declare class MealPlanService {
    createMealPlan(userId: string, input: CreateMealPlanInput): Promise<MealPlan>;
    getMealPlan(id: string, userId: string): Promise<MealPlan | null>;
    getUserMealPlans(userId: string, status?: string): Promise<MealPlan[]>;
    getActiveMealPlan(userId: string): Promise<MealPlan | null>;
    updateMealPlan(id: string, userId: string, updates: Partial<CreateMealPlanInput & {
        status: string;
    }>): Promise<MealPlan | null>;
    deleteMealPlan(id: string, userId: string): Promise<boolean>;
    activateMealPlan(id: string, userId: string): Promise<MealPlan | null>;
    addMealPlanItem(planId: string, userId: string, item: {
        planDate: string;
        mealType: MealType;
        recipeId?: string;
        foodId?: string;
        customDescription?: string;
        servings?: number;
    }): Promise<MealPlanItem>;
    getMealPlanItems(planId: string): Promise<MealPlanItem[]>;
    getMealPlanItemsForDate(planId: string, date: string): Promise<MealPlanItem[]>;
    updateMealPlanItem(itemId: string, userId: string, updates: {
        servings?: number;
        completed?: boolean;
        completedMealLogId?: string;
    }): Promise<MealPlanItem | null>;
    deleteMealPlanItem(itemId: string, userId: string): Promise<boolean>;
    generateShoppingList(planId: string, userId: string): Promise<ShoppingListItem[]>;
    private categorizeIngredient;
    generateMealPlan(userId: string, input: GenerateMealPlanInput): Promise<MealPlan>;
    private mapMealPlanRow;
    private mapMealPlanItemRow;
}
export declare const mealPlanService: MealPlanService;
