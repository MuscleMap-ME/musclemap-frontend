/**
 * Nutrition Goals Service
 *
 * Wrapper service for goal-related operations
 * Re-exports from macro-calculator for consistency
 */
import type { NutritionGoals, CalculateGoalsInput } from './types';
export declare class NutritionGoalsService {
    getGoals(userId: string): Promise<NutritionGoals | null>;
    calculateGoals(userId: string, input: CalculateGoalsInput): Promise<NutritionGoals>;
    adjustForWorkout(userId: string, tuBurned: number, musclesTrained: string[]): Promise<{
        calorieAdjustment: number;
        proteinAdjustment: number;
    }>;
}
export declare const nutritionGoalsService: NutritionGoalsService;
