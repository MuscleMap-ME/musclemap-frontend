"use strict";
/**
 * Nutrition Goals Service
 *
 * Wrapper service for goal-related operations
 * Re-exports from macro-calculator for consistency
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.nutritionGoalsService = exports.NutritionGoalsService = void 0;
const macro_calculator_service_1 = require("./macro-calculator.service");
class NutritionGoalsService {
    async getGoals(userId) {
        return macro_calculator_service_1.macroCalculatorService.getGoals(userId);
    }
    async calculateGoals(userId, input) {
        return macro_calculator_service_1.macroCalculatorService.calculateAndSaveGoals(userId, input);
    }
    async adjustForWorkout(userId, tuBurned, musclesTrained) {
        return macro_calculator_service_1.macroCalculatorService.adjustForWorkout(userId, tuBurned, musclesTrained);
    }
}
exports.NutritionGoalsService = NutritionGoalsService;
exports.nutritionGoalsService = new NutritionGoalsService();
//# sourceMappingURL=nutrition-goals.service.js.map