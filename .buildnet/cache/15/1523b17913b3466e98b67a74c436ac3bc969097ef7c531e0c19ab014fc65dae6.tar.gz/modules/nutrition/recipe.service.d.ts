/**
 * Recipe Service
 *
 * Handles recipe CRUD, community features, ratings, and saves
 */
import type { Recipe, CreateRecipeInput, UpdateRecipeInput, RecipeFilter, RecipeSort, PaginatedResponse } from './types';
export declare class RecipeService {
    createRecipe(userId: string, input: CreateRecipeInput): Promise<Recipe>;
    updateRecipe(id: string, userId: string, input: UpdateRecipeInput): Promise<Recipe | null>;
    deleteRecipe(id: string, userId: string): Promise<boolean>;
    getRecipe(id: string, userId?: string): Promise<Recipe | null>;
    searchRecipes(filter: RecipeFilter, sort?: RecipeSort, limit?: number, cursor?: string, userId?: string): Promise<PaginatedResponse<Recipe>>;
    getUserRecipes(userId: string, limit?: number): Promise<Recipe[]>;
    getSavedRecipes(userId: string, limit?: number): Promise<Recipe[]>;
    saveRecipe(recipeId: string, userId: string): Promise<boolean>;
    unsaveRecipe(recipeId: string, userId: string): Promise<boolean>;
    rateRecipe(recipeId: string, userId: string, rating: number, review?: string): Promise<boolean>;
    getRecipeRatings(recipeId: string, limit?: number): Promise<{
        userId: string;
        rating: number;
        review?: string;
        createdAt: Date;
    }[]>;
    getPopularRecipes(limit?: number): Promise<Recipe[]>;
    getTrendingRecipes(limit?: number): Promise<Recipe[]>;
    getRecipesByArchetype(archetype: string, limit?: number): Promise<Recipe[]>;
    private calculateRecipeNutrition;
    private generateSlug;
    private getSortColumn;
    private getCursorValue;
    private mapRecipeRow;
}
export declare const recipeService: RecipeService;
