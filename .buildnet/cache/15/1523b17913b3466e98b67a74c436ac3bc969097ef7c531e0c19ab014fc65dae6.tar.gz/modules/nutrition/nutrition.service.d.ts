/**
 * Nutrition Service
 *
 * Core service for nutrition preferences and dashboard data
 */
import type { NutritionPreferences, UpdateNutritionPreferencesInput, NutritionDashboard, NutritionStreaks, ArchetypeNutritionProfile } from './types';
export declare class NutritionService {
    getPreferences(userId: string): Promise<NutritionPreferences | null>;
    getOrCreatePreferences(userId: string): Promise<NutritionPreferences>;
    updatePreferences(userId: string, input: UpdateNutritionPreferencesInput): Promise<NutritionPreferences>;
    enableNutrition(userId: string): Promise<NutritionPreferences>;
    disableNutrition(userId: string, deleteData?: boolean): Promise<boolean>;
    getDashboard(userId: string): Promise<NutritionDashboard>;
    private getGoals;
    private getTodaySummary;
    private getRecentMeals;
    getStreaks(userId: string): Promise<NutritionStreaks | null>;
    updateStreaks(userId: string, mealDate: string): Promise<void>;
    getArchetypeProfile(archetype: string): Promise<ArchetypeNutritionProfile | null>;
    getAllArchetypeProfiles(): Promise<ArchetypeNutritionProfile[]>;
    private getUserArchetype;
    private mapPreferencesRow;
    private mapGoalsRow;
    private mapSummaryRow;
    private mapMealLogRow;
}
export declare const nutritionService: NutritionService;
