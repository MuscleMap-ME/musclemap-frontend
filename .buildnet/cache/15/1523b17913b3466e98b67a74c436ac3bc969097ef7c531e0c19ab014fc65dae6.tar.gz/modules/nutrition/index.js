"use strict";
/**
 * Nutrition Module
 *
 * Comprehensive nutrition tracking system including:
 * - Food search with multi-source API integration
 * - Meal logging and daily summaries
 * - Macro/micronutrient tracking
 * - Recipe management
 * - Meal planning
 * - Workout-nutrition integration
 * - Community features
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports, p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.nutritionGoalsService = exports.NutritionGoalsService = exports.mealPlanService = exports.MealPlanService = exports.recipeService = exports.RecipeService = exports.macroCalculatorService = exports.MacroCalculatorService = exports.mealLogService = exports.MealLogService = exports.foodSearchService = exports.FoodSearchService = exports.nutritionService = exports.NutritionService = void 0;
var nutrition_service_1 = require("./nutrition.service");
Object.defineProperty(exports, "NutritionService", { enumerable: true, get: function () { return nutrition_service_1.NutritionService; } });
Object.defineProperty(exports, "nutritionService", { enumerable: true, get: function () { return nutrition_service_1.nutritionService; } });
var food_search_service_1 = require("./food-search.service");
Object.defineProperty(exports, "FoodSearchService", { enumerable: true, get: function () { return food_search_service_1.FoodSearchService; } });
Object.defineProperty(exports, "foodSearchService", { enumerable: true, get: function () { return food_search_service_1.foodSearchService; } });
var meal_log_service_1 = require("./meal-log.service");
Object.defineProperty(exports, "MealLogService", { enumerable: true, get: function () { return meal_log_service_1.MealLogService; } });
Object.defineProperty(exports, "mealLogService", { enumerable: true, get: function () { return meal_log_service_1.mealLogService; } });
var macro_calculator_service_1 = require("./macro-calculator.service");
Object.defineProperty(exports, "MacroCalculatorService", { enumerable: true, get: function () { return macro_calculator_service_1.MacroCalculatorService; } });
Object.defineProperty(exports, "macroCalculatorService", { enumerable: true, get: function () { return macro_calculator_service_1.macroCalculatorService; } });
var recipe_service_1 = require("./recipe.service");
Object.defineProperty(exports, "RecipeService", { enumerable: true, get: function () { return recipe_service_1.RecipeService; } });
Object.defineProperty(exports, "recipeService", { enumerable: true, get: function () { return recipe_service_1.recipeService; } });
var meal_plan_service_1 = require("./meal-plan.service");
Object.defineProperty(exports, "MealPlanService", { enumerable: true, get: function () { return meal_plan_service_1.MealPlanService; } });
Object.defineProperty(exports, "mealPlanService", { enumerable: true, get: function () { return meal_plan_service_1.mealPlanService; } });
var nutrition_goals_service_1 = require("./nutrition-goals.service");
Object.defineProperty(exports, "NutritionGoalsService", { enumerable: true, get: function () { return nutrition_goals_service_1.NutritionGoalsService; } });
Object.defineProperty(exports, "nutritionGoalsService", { enumerable: true, get: function () { return nutrition_goals_service_1.nutritionGoalsService; } });
__exportStar(require("./types"), exports);
//# sourceMappingURL=index.js.map