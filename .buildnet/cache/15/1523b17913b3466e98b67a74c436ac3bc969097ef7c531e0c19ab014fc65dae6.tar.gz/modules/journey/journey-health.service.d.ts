/**
 * Journey Health Service
 *
 * Provides health scoring and proactive monitoring for user journeys.
 * Detects stalled journeys and provides actionable recommendations.
 *
 * Health Score Components (0-100):
 * - Engagement (35%): Based on recency of activity
 * - Consistency (25%): Based on check-in frequency
 * - Momentum (40%): Based on progress vs expected rate
 *
 * Risk Levels:
 * - healthy: On track, regular activity
 * - at_risk: Slowing down, needs attention
 * - critical: Significantly behind, urgent action needed
 * - stalled: No activity for extended period
 */
export type JourneyRiskLevel = 'healthy' | 'at_risk' | 'critical' | 'stalled';
export type JourneyAlertType = 'stalled' | 'declining' | 'missed_milestone' | 'off_track' | 'no_activity' | 'consistency_drop' | 'risk_upgrade' | 'approaching_deadline';
export type RecommendationType = 'increase_frequency' | 'set_reminder' | 'adjust_goal' | 'take_break' | 'celebrate_progress' | 'connect_buddy' | 'join_challenge' | 'simplify_goal' | 'change_approach' | 'seek_support' | 'restart_journey' | 'archive_journey';
export interface JourneyHealthScore {
    id: string;
    userJourneyId: string;
    userId: string;
    healthScore: number;
    engagementScore: number;
    consistencyScore: number;
    momentumScore: number;
    progressRate: number;
    expectedDailyProgress: number;
    actualDailyProgress: number;
    deviationPercentage: number;
    riskLevel: JourneyRiskLevel;
    riskFactors: RiskFactor[];
    daysSinceLastProgress: number;
    totalActiveDays: number;
    streakCurrent: number;
    streakLongest: number;
    lastActivityAt: Date | null;
    milestonesTotal: number;
    milestonesCompleted: number;
    milestonesOnTrack: number;
    milestonesBehind: number;
    expectedCheckins: number;
    actualCheckins: number;
    checkinConsistency: number;
    scoreTrend: 'improving' | 'stable' | 'declining' | 'critical_decline';
    score7dChange: number;
    score30dChange: number;
    calculatedAt: Date;
}
export interface RiskFactor {
    factor: string;
    weight: number;
    days?: number;
    ratio?: number;
    progressGap?: number;
    completed?: number;
    total?: number;
}
export interface JourneyHealthAlert {
    id: string;
    userJourneyId: string;
    userId: string;
    alertType: JourneyAlertType;
    severity: 'info' | 'warning' | 'critical';
    title: string;
    message: string;
    triggerData: Record<string, unknown>;
    status: 'active' | 'acknowledged' | 'dismissed' | 'resolved';
    acknowledgedAt: Date | null;
    dismissedAt: Date | null;
    resolvedAt: Date | null;
    notificationSent: boolean;
    expiresAt: Date | null;
    createdAt: Date;
}
export interface JourneyRecommendation {
    id: string;
    userJourneyId: string;
    userId: string;
    recommendationType: RecommendationType;
    priority: number;
    title: string;
    description: string;
    actionText: string | null;
    actionUrl: string | null;
    reasoning: {
        factors: string[];
        confidence: number;
    };
    status: 'active' | 'viewed' | 'actioned' | 'dismissed' | 'expired';
    wasHelpful: boolean | null;
    feedbackText: string | null;
    expiresAt: Date | null;
    createdAt: Date;
}
export interface StalledJourney {
    userJourneyId: string;
    journeyName: string;
    daysSinceActivity: number;
    currentProgress: number;
    riskLevel: JourneyRiskLevel;
    healthScore: number;
}
export declare const journeyHealthService: {
    /**
     * Calculate health score for a specific journey
     */
    calculateHealthScore(journeyId: string): Promise<JourneyHealthScore | null>;
    /**
     * Get the current health score for a journey
     */
    getJourneyHealth(journeyId: string): Promise<JourneyHealthScore | null>;
    /**
     * Detect stalled journeys for a user
     */
    detectStalledJourneys(userId: string, thresholdDays?: number): Promise<StalledJourney[]>;
    /**
     * Get health alerts for a user
     */
    getHealthAlerts(userId: string, options?: {
        status?: "active" | "acknowledged" | "dismissed" | "resolved";
        limit?: number;
        journeyId?: string;
    }): Promise<JourneyHealthAlert[]>;
    /**
     * Generate recommendations for a journey
     */
    generateRecommendations(journeyId: string): Promise<JourneyRecommendation[]>;
    /**
     * Get recommendations for a journey
     */
    getRecommendations(journeyId: string, options?: {
        status?: string;
        limit?: number;
    }): Promise<JourneyRecommendation[]>;
    /**
     * Acknowledge an alert
     */
    acknowledgeAlert(alertId: string, userId: string): Promise<JourneyHealthAlert | null>;
    /**
     * Dismiss an alert
     */
    dismissAlert(alertId: string, userId: string): Promise<boolean>;
    /**
     * Get risk level for a journey
     */
    getJourneyRiskLevel(journeyId: string): Promise<JourneyRiskLevel>;
    /**
     * Mark recommendation as viewed
     */
    markRecommendationViewed(recommendationId: string, userId: string): Promise<void>;
    /**
     * Mark recommendation as actioned
     */
    markRecommendationActioned(recommendationId: string, userId: string): Promise<void>;
    /**
     * Provide feedback on a recommendation
     */
    provideFeedback(recommendationId: string, userId: string, wasHelpful: boolean, feedbackText?: string): Promise<void>;
    /**
     * Recalculate health scores for all active journeys (batch operation)
     */
    recalculateAllHealthScores(): Promise<{
        journeysProcessed: number;
        alertsCreated: number;
        durationMs: number;
    }>;
    /**
     * Get health score history for trend analysis
     */
    getHealthHistory(journeyId: string, days?: number): Promise<Array<{
        date: string;
        healthScore: number;
        engagementScore: number;
        consistencyScore: number;
        momentumScore: number;
        riskLevel: JourneyRiskLevel;
    }>>;
    /**
     * Create a custom alert
     */
    createAlert(journeyId: string, userId: string, alertType: JourneyAlertType, severity: "info" | "warning" | "critical", title: string, message: string, triggerData?: Record<string, unknown>, expiresInDays?: number): Promise<JourneyHealthAlert>;
};
export default journeyHealthService;
