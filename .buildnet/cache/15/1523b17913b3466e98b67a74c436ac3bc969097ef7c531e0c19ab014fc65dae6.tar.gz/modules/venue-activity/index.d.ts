/**
 * Venue Activity Service
 *
 * Manages community activity aggregations for visualizations:
 * - Daily activity aggregates (for charts)
 * - Real-time activity logging
 * - Privacy-aware data aggregation
 * - Regional/multi-venue summaries
 */
export interface VenueActivityDaily {
    venueId: string;
    activityDate: Date;
    totalUsers: number;
    publicUsers: number;
    totalWorkouts: number;
    totalSets: number;
    totalReps: number;
    totalVolumeKg: number;
    totalTu: number;
    exercisesBreakdown: ExerciseBreakdownItem[];
    muscleActivations: MuscleActivationItem[];
    hourlyActivity: number[];
    recordsSet: number;
    peakConcurrentUsers: number;
    busiestHour?: number;
}
export interface ExerciseBreakdownItem {
    exerciseId: string;
    exerciseName: string;
    count: number;
    percentage: number;
}
export interface MuscleActivationItem {
    muscleId: string;
    muscleName: string;
    totalTu: number;
    percentage: number;
}
export interface DailyDataPoint {
    date: Date;
    value: number;
}
export interface HourlyDataPoint {
    hour: number;
    averageUsers: number;
    averageWorkouts: number;
}
export interface WeekdayDataPoint {
    dayOfWeek: number;
    dayName: string;
    averageUsers: number;
    averageWorkouts: number;
}
export interface VenueContributor {
    userId: string;
    username: string;
    avatarUrl?: string;
    totalWorkouts: number;
    totalVolumeKg: number;
    recordsHeld: number;
}
export interface VenueActivitySummary {
    venueId: string;
    startDate: Date;
    endDate: Date;
    totalWorkouts: number;
    uniqueUsers: number;
    totalRecordsSet: number;
    totalVolumeKg: number;
    totalTu: number;
    dailyWorkouts: DailyDataPoint[];
    dailyUsers: DailyDataPoint[];
    dailyRecords: DailyDataPoint[];
    dailyVolume: DailyDataPoint[];
    exerciseDistribution: ExerciseBreakdownItem[];
    muscleDistribution: MuscleActivationItem[];
    hourlyPattern: HourlyDataPoint[];
    weekdayPattern: WeekdayDataPoint[];
    topContributors: VenueContributor[];
    recentRecords: any[];
}
export interface VenueComparisonItem {
    venueId: string;
    venueName: string;
    workouts: number;
    users: number;
    records: number;
}
export interface VenueHeatmapPoint {
    venueId: string;
    latitude: number;
    longitude: number;
    intensity: number;
    workouts: number;
}
export interface RegionalActivitySummary {
    venues: any[];
    venueCount: number;
    totalWorkouts: number;
    uniqueUsers: number;
    totalRecordsSet: number;
    venueComparison: VenueComparisonItem[];
    heatmapData: VenueHeatmapPoint[];
}
export type ActivityType = 'checkin' | 'checkout' | 'workout_start' | 'workout_end' | 'set_logged' | 'record_claimed';
export interface LogActivityInput {
    venueId: string;
    userId: string;
    workoutSessionId?: string;
    activityType: ActivityType;
    setsCount?: number;
    repsCount?: number;
    volumeKg?: number;
    tuEarned?: number;
    exerciseId?: string;
    muscleActivations?: Record<string, number>;
}
/**
 * Log an activity event at a venue
 */
export declare function logActivity(input: LogActivityInput): Promise<void>;
/**
 * Get or compute daily activity for a venue
 */
export declare function getVenueActivityDaily(venueId: string, date: Date): Promise<VenueActivityDaily | null>;
/**
 * Get activity summary for a venue over a date range
 */
export declare function getVenueActivitySummary(venueId: string, startDate: Date, endDate: Date): Promise<VenueActivitySummary>;
/**
 * Get regional activity summary across multiple venues
 */
export declare function getRegionalActivitySummary(options: {
    venueIds?: string[];
    borough?: string;
    latitude?: number;
    longitude?: number;
    radiusMeters?: number;
    startDate: Date;
    endDate: Date;
}): Promise<RegionalActivitySummary>;
/**
 * Refresh daily aggregates for a venue
 * Called by background job
 */
export declare function refreshDailyAggregate(venueId: string, date: Date): Promise<void>;
/**
 * Refresh all daily aggregates for yesterday
 * Called at midnight by cron job
 */
export declare function refreshYesterdayAggregates(): Promise<number>;
export declare const venueActivityService: {
    logActivity: typeof logActivity;
    getVenueActivityDaily: typeof getVenueActivityDaily;
    getVenueActivitySummary: typeof getVenueActivitySummary;
    getRegionalActivitySummary: typeof getRegionalActivitySummary;
    refreshDailyAggregate: typeof refreshDailyAggregate;
    refreshYesterdayAggregates: typeof refreshYesterdayAggregates;
};
