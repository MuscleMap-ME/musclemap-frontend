/**
 * Rivals WebSocket
 *
 * Real-time updates for active rivalries with Redis pub/sub
 * for cross-node messaging in PM2 cluster mode.
 */
import type { FastifyInstance } from 'fastify';
import type { RivalEvent } from './types';
export declare function registerRivalsWebSocket(fastify: FastifyInstance): void;
/**
 * Send event to a specific user (cross-node aware)
 */
export declare function sendToUser(userId: string, event: RivalEvent): void;
/**
 * Broadcast workout update to all rivalry opponents
 */
export declare function broadcastRivalWorkout(userId: string, username: string, workoutId: string, tuEarned: number, topMuscles: string[]): Promise<void>;
/**
 * Broadcast rivalry status change
 */
export declare function broadcastRivalryStatusChange(rivalryId: string, type: 'rival.request' | 'rival.accepted' | 'rival.declined' | 'rival.ended', challengerId: string, challengedId: string, data?: Record<string, unknown>): void;
/**
 * Get connection stats (local instance only)
 */
export declare function getConnectionStats(): {
    users: number;
    connections: number;
    instanceId: string;
};
/**
 * Check if a user has active connections on this node
 */
export declare function hasLocalConnection(userId: string): boolean;
/**
 * Force disconnect a user from this node
 */
export declare function disconnectUser(userId: string, reason?: string): void;
