import type { Rival, RivalWithUser, RivalStats, RivalStatus } from './types';
export declare const rivalsService: {
    /**
     * Create a new rivalry request
     *
     * RC-004 FIX: Uses database-level bidirectional unique index to prevent
     * duplicate rivalries regardless of who challenged whom.
     */
    createRivalry(challengerId: string, challengedId: string): Promise<RivalWithUser>;
    /**
     * Get a rivalry by ID
     */
    getRivalry(id: string): Promise<Rival | null>;
    /**
     * Get rivalry with user info
     */
    getRivalryWithUser(id: string, userId: string): Promise<RivalWithUser | null>;
    /**
     * Accept a rivalry request
     */
    acceptRivalry(id: string, userId: string): Promise<RivalWithUser>;
    /**
     * Decline a rivalry request
     */
    declineRivalry(id: string, userId: string): Promise<void>;
    /**
     * End an active rivalry
     */
    endRivalry(id: string, userId: string): Promise<void>;
    /**
     * Get all rivalries for a user
     */
    getUserRivalries(userId: string, status?: RivalStatus): Promise<RivalWithUser[]>;
    /**
     * Get pending rivalry requests for a user
     */
    getPendingRequests(userId: string): Promise<RivalWithUser[]>;
    /**
     * Get rivalry stats for a user
     */
    getUserStats(userId: string): Promise<RivalStats>;
    /**
     * Record a workout for rivalry tracking
     */
    recordWorkout(userId: string, workoutId: string, tuEarned: number, _topMuscles: string[]): Promise<RivalWithUser[]>;
    /**
     * Search for potential rivals
     */
    searchPotentialRivals(userId: string, query: string, limit?: number): Promise<Array<{
        id: string;
        username: string;
        avatar?: string;
        archetype?: string;
    }>>;
};
