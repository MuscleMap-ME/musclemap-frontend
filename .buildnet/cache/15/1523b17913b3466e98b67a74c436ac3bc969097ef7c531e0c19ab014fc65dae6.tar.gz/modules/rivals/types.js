"use strict";
/**
 * Rivals Module Types
 *
 * Type definitions for the rivalry system.
 */
Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=types.js.map