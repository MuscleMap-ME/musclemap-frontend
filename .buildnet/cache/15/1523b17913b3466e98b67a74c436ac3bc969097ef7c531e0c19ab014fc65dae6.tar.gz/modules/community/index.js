"use strict";
/**
 * Community Module
 *
 * Themed virtual community system with:
 * - Virtual Hangouts: Themed spaces tied to archetypes (Warrior's Cave, Hunter's Den)
 * - Communities: Self-organized groups with hierarchy and moderation
 * - Bulletin Boards: Voting-enabled discussion boards
 * - Events: Community meetups and challenges
 * - Privacy: Ghost mode, profile visibility controls
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports, p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", { value: true });
__exportStar(require("./virtual-hangouts.service"), exports);
__exportStar(require("./communities.service"), exports);
__exportStar(require("./bulletin.service"), exports);
__exportStar(require("./privacy.service"), exports);
//# sourceMappingURL=index.js.map