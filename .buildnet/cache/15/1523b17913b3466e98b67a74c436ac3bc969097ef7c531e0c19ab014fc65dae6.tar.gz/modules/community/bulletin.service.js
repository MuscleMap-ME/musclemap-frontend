"use strict";
/**
 * Bulletin Board Service
 *
 * Manages community discussion boards with:
 * - Posts with upvote/downvote voting
 * - Comments and replies
 * - Pin and highlight by moderators
 * - Content moderation
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.bulletinService = void 0;
const crypto_1 = __importDefault(require("crypto"));
const client_1 = require("../../db/client");
const errors_1 = require("../../lib/errors");
const logger_1 = require("../../lib/logger");
const communities_service_1 = require("./communities.service");
const log = logger_1.loggers.core;
// Service implementation
exports.bulletinService = {
    /**
     * Create a new post
     */
    async createPost(request) {
        const { boardId, authorId, title, content, postType = 'discussion', contentLang = 'en', mediaUrls = [], linkedWorkoutId, linkedMilestoneId, } = request;
        // Validate
        if (!title || title.length < 3 || title.length > 300) {
            throw new errors_1.ValidationError('Title must be between 3 and 300 characters');
        }
        if (!content || content.length < 1 || content.length > 50000) {
            throw new errors_1.ValidationError('Content must be between 1 and 50,000 characters');
        }
        // Verify board exists and get context
        const board = await (0, client_1.queryOne)('SELECT id, community_id, virtual_hangout_id FROM bulletin_boards WHERE id = $1 AND is_active = TRUE', [boardId]);
        if (!board) {
            throw new errors_1.NotFoundError('Bulletin board not found');
        }
        // Verify author is a member of the community/hangout
        if (board.community_id) {
            const membership = await (0, client_1.queryOne)('SELECT status FROM community_memberships WHERE community_id = $1 AND user_id = $2', [board.community_id, authorId]);
            if (!membership || membership.status !== 'active') {
                throw new errors_1.ForbiddenError('Must be an active community member to post');
            }
        }
        else if (board.virtual_hangout_id) {
            const membership = await (0, client_1.queryOne)('SELECT user_id FROM virtual_hangout_memberships WHERE hangout_id = $1 AND user_id = $2', [board.virtual_hangout_id, authorId]);
            if (!membership) {
                throw new errors_1.ForbiddenError('Must be a hangout member to post');
            }
        }
        const postId = `bp_${crypto_1.default.randomBytes(12).toString('hex')}`;
        const row = await (0, client_1.queryOne)(`INSERT INTO bulletin_posts (
        id, board_id, author_id, title, content, content_lang, post_type,
        media_urls, linked_workout_id, linked_milestone_id
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
      RETURNING created_at, updated_at`, [
            postId, boardId, authorId, title, content, contentLang, postType,
            JSON.stringify(mediaUrls), linkedWorkoutId, linkedMilestoneId
        ]);
        // Get author info
        const author = await (0, client_1.queryOne)('SELECT username, display_name, avatar_url FROM users WHERE id = $1', [authorId]);
        log.info({ postId, boardId, authorId }, 'Bulletin post created');
        return {
            id: postId,
            boardId,
            authorId,
            authorUsername: author?.username,
            authorDisplayName: author?.display_name ?? undefined,
            authorAvatarUrl: author?.avatar_url ?? undefined,
            title,
            content,
            contentLang,
            postType,
            mediaUrls,
            linkedWorkoutId,
            linkedMilestoneId,
            upvotes: 0,
            downvotes: 0,
            score: 0,
            commentCount: 0,
            viewCount: 0,
            isPinned: false,
            isHighlighted: false,
            isHidden: false,
            createdAt: row.created_at,
            updatedAt: row.updated_at,
        };
    },
    /**
     * Get posts from a bulletin board
     */
    async getPosts(boardId, userId, options = {}) {
        const { limit = 20, offset = 0, sortBy = 'hot', postType } = options;
        const conditions = ['bp.board_id = $1', 'bp.is_hidden = FALSE'];
        const params = [boardId];
        let paramIndex = 2;
        if (postType) {
            conditions.push(`bp.post_type = $${paramIndex++}`);
            params.push(postType);
        }
        const whereClause = conditions.join(' AND ');
        // User vote join - use parameterized query to prevent SQL injection
        const userJoin = userId
            ? `LEFT JOIN bulletin_votes bv ON bv.post_id = bp.id AND bv.user_id = $${paramIndex++}`
            : '';
        const userSelect = userId ? ', bv.vote_type as user_vote' : ', NULL as user_vote';
        if (userId) {
            params.push(userId);
        }
        // Sort order
        let orderBy;
        switch (sortBy) {
            case 'new':
                orderBy = 'bp.created_at DESC';
                break;
            case 'top':
                orderBy = 'bp.score DESC, bp.created_at DESC';
                break;
            case 'hot':
            default:
                // Hot = score weighted by recency
                orderBy = `(bp.score + 1) / POWER(EXTRACT(EPOCH FROM (NOW() - bp.created_at)) / 3600 + 2, 1.8) DESC`;
                break;
        }
        const rows = await (0, client_1.queryAll)(`SELECT
        bp.id, bp.board_id, bp.author_id, u.username, u.display_name, u.avatar_url,
        bp.title, bp.content, bp.content_lang, bp.post_type, bp.media_urls,
        bp.linked_workout_id, bp.linked_milestone_id,
        bp.upvotes, bp.downvotes, bp.score, bp.comment_count, bp.view_count,
        bp.is_pinned, bp.is_highlighted, bp.is_hidden, bp.created_at, bp.updated_at
        ${userSelect}
       FROM bulletin_posts bp
       LEFT JOIN users u ON u.id = bp.author_id
       ${userJoin}
       WHERE ${whereClause}
       ORDER BY bp.is_pinned DESC, ${orderBy}
       LIMIT $${paramIndex++} OFFSET $${paramIndex++}`, [...params, limit, offset]);
        const countResult = await (0, client_1.queryOne)(`SELECT COUNT(*) as count FROM bulletin_posts bp WHERE ${whereClause}`, params);
        return {
            posts: rows.map(r => ({
                id: r.id,
                boardId: r.board_id,
                authorId: r.author_id ?? undefined,
                authorUsername: r.username ?? undefined,
                authorDisplayName: r.display_name ?? undefined,
                authorAvatarUrl: r.avatar_url ?? undefined,
                title: r.title,
                content: r.content,
                contentLang: r.content_lang,
                postType: r.post_type,
                mediaUrls: r.media_urls || [],
                linkedWorkoutId: r.linked_workout_id ?? undefined,
                linkedMilestoneId: r.linked_milestone_id ?? undefined,
                upvotes: r.upvotes,
                downvotes: r.downvotes,
                score: r.score,
                commentCount: r.comment_count,
                viewCount: r.view_count,
                isPinned: r.is_pinned,
                isHighlighted: r.is_highlighted,
                isHidden: r.is_hidden,
                createdAt: r.created_at,
                updatedAt: r.updated_at,
                userVote: r.user_vote,
            })),
            total: parseInt(countResult?.count || '0', 10),
        };
    },
    /**
     * Get a single post by ID
     */
    async getPostById(postId, userId) {
        // Use parameterized query to prevent SQL injection
        const params = [postId];
        const userJoin = userId
            ? `LEFT JOIN bulletin_votes bv ON bv.post_id = bp.id AND bv.user_id = $2`
            : '';
        const userSelect = userId ? ', bv.vote_type as user_vote' : ', NULL as user_vote';
        if (userId) {
            params.push(userId);
        }
        const row = await (0, client_1.queryOne)(`SELECT
        bp.id, bp.board_id, bp.author_id, u.username, u.display_name, u.avatar_url,
        bp.title, bp.content, bp.content_lang, bp.post_type, bp.media_urls,
        bp.linked_workout_id, bp.linked_milestone_id,
        bp.upvotes, bp.downvotes, bp.score, bp.comment_count, bp.view_count,
        bp.is_pinned, bp.is_highlighted, bp.is_hidden, bp.created_at, bp.updated_at
        ${userSelect}
       FROM bulletin_posts bp
       LEFT JOIN users u ON u.id = bp.author_id
       ${userJoin}
       WHERE bp.id = $1`, params);
        if (!row)
            return null;
        // Increment view count
        await (0, client_1.query)('UPDATE bulletin_posts SET view_count = view_count + 1 WHERE id = $1', [postId]);
        return {
            id: row.id,
            boardId: row.board_id,
            authorId: row.author_id ?? undefined,
            authorUsername: row.username ?? undefined,
            authorDisplayName: row.display_name ?? undefined,
            authorAvatarUrl: row.avatar_url ?? undefined,
            title: row.title,
            content: row.content,
            contentLang: row.content_lang,
            postType: row.post_type,
            mediaUrls: row.media_urls || [],
            linkedWorkoutId: row.linked_workout_id ?? undefined,
            linkedMilestoneId: row.linked_milestone_id ?? undefined,
            upvotes: row.upvotes,
            downvotes: row.downvotes,
            score: row.score,
            commentCount: row.comment_count,
            viewCount: row.view_count + 1,
            isPinned: row.is_pinned,
            isHighlighted: row.is_highlighted,
            isHidden: row.is_hidden,
            createdAt: row.created_at,
            updatedAt: row.updated_at,
            userVote: row.user_vote,
        };
    },
    /**
     * Vote on a post
     */
    async votePost(postId, userId, voteType) {
        // Verify post exists
        const post = await (0, client_1.queryOne)('SELECT id, board_id FROM bulletin_posts WHERE id = $1 AND is_hidden = FALSE', [postId]);
        if (!post) {
            throw new errors_1.NotFoundError('Post not found');
        }
        // Check existing vote
        const existingVote = await (0, client_1.queryOne)('SELECT vote_type FROM bulletin_votes WHERE post_id = $1 AND user_id = $2', [postId, userId]);
        if (existingVote) {
            if (existingVote.vote_type === voteType) {
                // Remove vote (toggle off)
                await (0, client_1.query)('DELETE FROM bulletin_votes WHERE post_id = $1 AND user_id = $2', [postId, userId]);
            }
            else {
                // Change vote
                await (0, client_1.query)('UPDATE bulletin_votes SET vote_type = $1, updated_at = NOW() WHERE post_id = $2 AND user_id = $3', [voteType, postId, userId]);
            }
        }
        else {
            // New vote
            await (0, client_1.query)('INSERT INTO bulletin_votes (post_id, user_id, vote_type) VALUES ($1, $2, $3)', [postId, userId, voteType]);
        }
        // Get updated counts
        const counts = await (0, client_1.queryOne)('SELECT upvotes, downvotes, score FROM bulletin_posts WHERE id = $1', [postId]);
        return {
            upvotes: counts?.upvotes || 0,
            downvotes: counts?.downvotes || 0,
            score: counts?.score || 0,
        };
    },
    /**
     * Add a comment to a post
     */
    async addComment(postId, authorId, content, parentId) {
        if (!content || content.length < 1 || content.length > 10000) {
            throw new errors_1.ValidationError('Comment must be between 1 and 10,000 characters');
        }
        // Verify post exists
        const post = await (0, client_1.queryOne)('SELECT id, board_id FROM bulletin_posts WHERE id = $1 AND is_hidden = FALSE', [postId]);
        if (!post) {
            throw new errors_1.NotFoundError('Post not found');
        }
        // Verify parent comment if provided
        if (parentId) {
            const parent = await (0, client_1.queryOne)('SELECT id FROM bulletin_comments WHERE id = $1 AND post_id = $2 AND is_hidden = FALSE', [parentId, postId]);
            if (!parent) {
                throw new errors_1.NotFoundError('Parent comment not found');
            }
        }
        const commentId = `bc_${crypto_1.default.randomBytes(12).toString('hex')}`;
        const row = await (0, client_1.queryOne)(`INSERT INTO bulletin_comments (id, post_id, parent_id, author_id, content)
       VALUES ($1, $2, $3, $4, $5)
       RETURNING created_at, updated_at`, [commentId, postId, parentId, authorId, content]);
        // Get author info
        const author = await (0, client_1.queryOne)('SELECT username, display_name, avatar_url FROM users WHERE id = $1', [authorId]);
        log.info({ commentId, postId, authorId, parentId }, 'Comment added');
        return {
            id: commentId,
            postId,
            parentId,
            authorId,
            authorUsername: author?.username,
            authorDisplayName: author?.display_name ?? undefined,
            authorAvatarUrl: author?.avatar_url ?? undefined,
            content,
            upvotes: 0,
            downvotes: 0,
            score: 0,
            replyCount: 0,
            isHidden: false,
            createdAt: row.created_at,
            updatedAt: row.updated_at,
        };
    },
    /**
     * Get comments for a post
     */
    async getComments(postId, userId, options = {}) {
        const { limit = 50, offset = 0 } = options;
        // Use parameterized query to prevent SQL injection
        const params = [postId];
        let paramIndex = 2;
        const userJoin = userId
            ? `LEFT JOIN bulletin_votes bcv ON bcv.comment_id = bc.id AND bcv.user_id = $${paramIndex++}`
            : '';
        const userSelect = userId ? ', bcv.vote_type as user_vote' : ', NULL as user_vote';
        if (userId) {
            params.push(userId);
        }
        // Get top-level comments
        const rows = await (0, client_1.queryAll)(`SELECT
        bc.id, bc.post_id, bc.parent_id, bc.author_id,
        u.username, u.display_name, u.avatar_url,
        bc.content, bc.upvotes, bc.downvotes, bc.score, bc.reply_count,
        bc.is_hidden, bc.created_at, bc.updated_at
        ${userSelect}
       FROM bulletin_comments bc
       LEFT JOIN users u ON u.id = bc.author_id
       ${userJoin}
       WHERE bc.post_id = $1 AND bc.parent_id IS NULL AND bc.is_hidden = FALSE
       ORDER BY bc.score DESC, bc.created_at
       LIMIT $${paramIndex++} OFFSET $${paramIndex++}`, [...params, limit, offset]);
        const countResult = await (0, client_1.queryOne)('SELECT COUNT(*) as count FROM bulletin_comments WHERE post_id = $1 AND parent_id IS NULL AND is_hidden = FALSE', [postId]);
        // Get replies for each comment (limited to 3)
        const comments = await Promise.all(rows.map(async (r) => {
            const replies = await (0, client_1.queryAll)(`SELECT
            bc.id, bc.post_id, bc.parent_id, bc.author_id,
            u.username, u.display_name, u.avatar_url,
            bc.content, bc.upvotes, bc.downvotes, bc.score, bc.reply_count,
            bc.is_hidden, bc.created_at, bc.updated_at
           FROM bulletin_comments bc
           LEFT JOIN users u ON u.id = bc.author_id
           WHERE bc.parent_id = $1 AND bc.is_hidden = FALSE
           ORDER BY bc.created_at
           LIMIT 3`, [r.id]);
            return {
                id: r.id,
                postId: r.post_id,
                parentId: r.parent_id ?? undefined,
                authorId: r.author_id ?? undefined,
                authorUsername: r.username ?? undefined,
                authorDisplayName: r.display_name ?? undefined,
                authorAvatarUrl: r.avatar_url ?? undefined,
                content: r.content,
                upvotes: r.upvotes,
                downvotes: r.downvotes,
                score: r.score,
                replyCount: r.reply_count,
                isHidden: r.is_hidden,
                createdAt: r.created_at,
                updatedAt: r.updated_at,
                userVote: r.user_vote,
                replies: replies.map(reply => ({
                    id: reply.id,
                    postId: reply.post_id,
                    parentId: reply.parent_id ?? undefined,
                    authorId: reply.author_id ?? undefined,
                    authorUsername: reply.username ?? undefined,
                    authorDisplayName: reply.display_name ?? undefined,
                    authorAvatarUrl: reply.avatar_url ?? undefined,
                    content: reply.content,
                    upvotes: reply.upvotes,
                    downvotes: reply.downvotes,
                    score: reply.score,
                    replyCount: reply.reply_count,
                    isHidden: reply.is_hidden,
                    createdAt: reply.created_at,
                    updatedAt: reply.updated_at,
                })),
            };
        }));
        return {
            comments,
            total: parseInt(countResult?.count || '0', 10),
        };
    },
    /**
     * Vote on a comment
     */
    async voteComment(commentId, userId, voteType) {
        // Verify comment exists
        const comment = await (0, client_1.queryOne)('SELECT id FROM bulletin_comments WHERE id = $1 AND is_hidden = FALSE', [commentId]);
        if (!comment) {
            throw new errors_1.NotFoundError('Comment not found');
        }
        // Check existing vote
        const existingVote = await (0, client_1.queryOne)('SELECT vote_type FROM bulletin_votes WHERE comment_id = $1 AND user_id = $2', [commentId, userId]);
        if (existingVote) {
            if (existingVote.vote_type === voteType) {
                await (0, client_1.query)('DELETE FROM bulletin_votes WHERE comment_id = $1 AND user_id = $2', [commentId, userId]);
            }
            else {
                await (0, client_1.query)('UPDATE bulletin_votes SET vote_type = $1, updated_at = NOW() WHERE comment_id = $2 AND user_id = $3', [voteType, commentId, userId]);
            }
        }
        else {
            await (0, client_1.query)('INSERT INTO bulletin_votes (comment_id, user_id, vote_type) VALUES ($1, $2, $3)', [commentId, userId, voteType]);
        }
        // Get updated counts
        const counts = await (0, client_1.queryOne)('SELECT upvotes, downvotes, score FROM bulletin_comments WHERE id = $1', [commentId]);
        return {
            upvotes: counts?.upvotes || 0,
            downvotes: counts?.downvotes || 0,
            score: counts?.score || 0,
        };
    },
    /**
     * Moderator: Pin/unpin a post
     */
    async togglePinPost(postId, actorUserId, pin) {
        const post = await (0, client_1.queryOne)('SELECT id, board_id FROM bulletin_posts WHERE id = $1', [postId]);
        if (!post) {
            throw new errors_1.NotFoundError('Post not found');
        }
        // Get board context and verify moderator permissions
        const board = await (0, client_1.queryOne)('SELECT community_id, virtual_hangout_id FROM bulletin_boards WHERE id = $1', [post.board_id]);
        if (board?.community_id) {
            const membership = await (0, client_1.queryOne)('SELECT role_level FROM community_memberships WHERE community_id = $1 AND user_id = $2', [board.community_id, actorUserId]);
            if (!membership || membership.role_level < communities_service_1.CommunityRole.MODERATOR) {
                throw new errors_1.ForbiddenError('Insufficient permissions');
            }
        }
        else if (board?.virtual_hangout_id) {
            const membership = await (0, client_1.queryOne)('SELECT role FROM virtual_hangout_memberships WHERE hangout_id = $1 AND user_id = $2', [board.virtual_hangout_id, actorUserId]);
            if (!membership || membership.role < 1) { // HangoutMemberRole.MODERATOR
                throw new errors_1.ForbiddenError('Insufficient permissions');
            }
        }
        await (0, client_1.query)('UPDATE bulletin_posts SET is_pinned = $1 WHERE id = $2', [pin, postId]);
        log.info({ postId, pin, actorUserId }, 'Post pin status updated');
    },
    /**
     * Moderator: Hide/unhide a post
     */
    async toggleHidePost(postId, actorUserId, hide) {
        const post = await (0, client_1.queryOne)('SELECT id, board_id FROM bulletin_posts WHERE id = $1', [postId]);
        if (!post) {
            throw new errors_1.NotFoundError('Post not found');
        }
        // Get board context and verify moderator permissions
        const board = await (0, client_1.queryOne)('SELECT community_id, virtual_hangout_id FROM bulletin_boards WHERE id = $1', [post.board_id]);
        if (board?.community_id) {
            const membership = await (0, client_1.queryOne)('SELECT role_level FROM community_memberships WHERE community_id = $1 AND user_id = $2', [board.community_id, actorUserId]);
            if (!membership || membership.role_level < communities_service_1.CommunityRole.MODERATOR) {
                throw new errors_1.ForbiddenError('Insufficient permissions');
            }
        }
        else if (board?.virtual_hangout_id) {
            const membership = await (0, client_1.queryOne)('SELECT role FROM virtual_hangout_memberships WHERE hangout_id = $1 AND user_id = $2', [board.virtual_hangout_id, actorUserId]);
            if (!membership || membership.role < 1) {
                throw new errors_1.ForbiddenError('Insufficient permissions');
            }
        }
        await (0, client_1.query)('UPDATE bulletin_posts SET is_hidden = $1 WHERE id = $2', [hide, postId]);
        log.info({ postId, hide, actorUserId }, 'Post hidden status updated');
    },
    /**
     * Get or create a bulletin board for a community/hangout
     */
    async getOrCreateBoard(type, entityId) {
        const column = type === 'community' ? 'community_id' : 'virtual_hangout_id';
        // Check if board exists
        let board = await (0, client_1.queryOne)(`SELECT id, name FROM bulletin_boards WHERE ${column} = $1 AND is_active = TRUE`, [entityId]);
        if (board) {
            return board;
        }
        // Get entity name
        let entityName = 'Discussion';
        if (type === 'community') {
            const community = await (0, client_1.queryOne)('SELECT name FROM communities WHERE id = $1', [entityId]);
            entityName = community?.name || 'Community';
        }
        else {
            const hangout = await (0, client_1.queryOne)('SELECT name FROM virtual_hangouts WHERE id = $1', [entityId]);
            entityName = hangout?.name || 'Hangout';
        }
        // Create board
        const row = await (0, client_1.queryOne)(`INSERT INTO bulletin_boards (${column}, name, description, board_type)
       VALUES ($1, $2, $3, 'general')
       RETURNING id`, [entityId, `${entityName} Bulletin Board`, `Discussion board for ${entityName}`]);
        return {
            id: row.id,
            name: `${entityName} Bulletin Board`,
        };
    },
};
//# sourceMappingURL=bulletin.service.js.map