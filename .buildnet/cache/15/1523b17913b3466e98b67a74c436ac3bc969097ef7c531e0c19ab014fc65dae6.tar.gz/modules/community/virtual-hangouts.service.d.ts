/**
 * Virtual Hangouts Service
 *
 * Manages themed virtual spaces tied to archetypes (not geo-located):
 * - Warrior's Cave: For powerlifters and strength athletes
 * - Hunter's Den: For tracking and outdoor fitness
 * - Runner's Camp: For runners and cardio enthusiasts
 * - Police Academy: For law enforcement fitness
 * - Fire Station: For firefighters
 * - Military Barracks: For military/veterans
 * - Yoga Garden: For flexibility and mindfulness
 * - CrossFit Box: For functional fitness
 */
export declare enum HangoutMemberRole {
    MEMBER = 0,
    MODERATOR = 1,
    ADMIN = 2
}
export declare const HANGOUT_THEMES: {
    readonly WARRIORS_CAVE: "warriors-cave";
    readonly HUNTERS_DEN: "hunters-den";
    readonly RUNNERS_CAMP: "runners-camp";
    readonly POLICE_ACADEMY: "police-academy";
    readonly FIRE_STATION: "fire-station";
    readonly MILITARY_BARRACKS: "military-barracks";
    readonly YOGA_GARDEN: "yoga-garden";
    readonly CROSSFIT_BOX: "crossfit-box";
    readonly SWIMMERS_COVE: "swimmers-cove";
    readonly CLIMBERS_PEAK: "climbers-peak";
};
export type HangoutThemeSlug = (typeof HANGOUT_THEMES)[keyof typeof HANGOUT_THEMES];
export interface VirtualHangoutTheme {
    id: string;
    name: string;
    tagline?: string;
    description?: string;
    primaryColor: string;
    secondaryColor: string;
    accentColor: string;
    backgroundImageUrl?: string;
    iconUrl?: string;
    bannerUrl?: string;
    archetypeCategoryId?: string;
    goalTypes: string[];
    targetAudiences: string[];
    isActive: boolean;
}
export interface VirtualHangout {
    id: number;
    themeId: string;
    themeName: string;
    customName?: string;
    customDescription?: string;
    customBannerUrl?: string;
    primaryColor: string;
    accentColor: string;
    memberCount: number;
    activeMemberCount: number;
    postCount: number;
    isActive: boolean;
    createdAt: Date;
    updatedAt: Date;
    isMember?: boolean;
    userRole?: HangoutMemberRole;
    lastVisitedAt?: Date;
}
export interface HangoutMembership {
    userId: string;
    username: string;
    displayName?: string;
    avatarUrl?: string;
    role: HangoutMemberRole;
    joinedAt: Date;
    lastActiveAt?: Date;
    showInMemberList: boolean;
    receiveNotifications: boolean;
}
export interface HangoutActivity {
    id: string;
    hangoutId: number;
    userId?: string;
    username?: string;
    activityType: 'join' | 'leave' | 'post' | 'workout_shared' | 'achievement' | 'milestone';
    activityData: Record<string, any>;
    createdAt: Date;
}
export declare const virtualHangoutsService: {
    /**
     * Get all hangout themes
     */
    getThemes(): Promise<VirtualHangoutTheme[]>;
    /**
     * Get all virtual hangouts (optionally filtered by theme)
     */
    getHangouts(userId?: string, options?: {
        themeId?: number;
        limit?: number;
        offset?: number;
    }): Promise<{
        hangouts: VirtualHangout[];
        total: number;
    }>;
    /**
     * Get a single hangout by ID
     */
    getHangoutById(hangoutId: number, userId?: string): Promise<VirtualHangout | null>;
    /**
     * Get hangouts for user's archetype/goals (recommended hangouts)
     */
    getRecommendedHangouts(userId: string, options?: {
        limit?: number;
    }): Promise<VirtualHangout[]>;
    /**
     * Join a virtual hangout
     */
    joinHangout(hangoutId: number, userId: string, options?: {
        showInMemberList?: boolean;
        receiveNotifications?: boolean;
    }): Promise<void>;
    /**
     * Leave a virtual hangout
     */
    leaveHangout(hangoutId: number, userId: string): Promise<void>;
    /**
     * Update membership settings
     */
    updateMembershipSettings(hangoutId: number, userId: string, settings: {
        showInMemberList?: boolean;
        receiveNotifications?: boolean;
    }): Promise<void>;
    /**
     * Get hangout members
     */
    getMembers(hangoutId: number, options?: {
        limit?: number;
        offset?: number;
        visibleOnly?: boolean;
    }): Promise<{
        members: HangoutMembership[];
        total: number;
    }>;
    /**
     * Get user's hangout memberships
     */
    getUserHangouts(userId: string, options?: {
        limit?: number;
        offset?: number;
    }): Promise<{
        hangouts: VirtualHangout[];
        total: number;
    }>;
    /**
     * Update user's last active time in a hangout
     */
    updateLastActive(hangoutId: number, userId: string): Promise<void>;
    /**
     * Get recent activity in a hangout
     */
    getActivity(hangoutId: number, options?: {
        limit?: number;
        offset?: number;
    }): Promise<HangoutActivity[]>;
    /**
     * Log activity in a hangout
     */
    logActivity(hangoutId: number, userId: string | null, activityType: HangoutActivity["activityType"], activityData: Record<string, any>): Promise<void>;
    /**
     * Share a workout to a hangout
     */
    shareWorkout(hangoutId: number, userId: string, workoutId: string, message?: string): Promise<void>;
};
