/**
 * Communities Service
 *
 * Manages self-organized communities with:
 * - Goal-based communities (weight loss, muscle gain)
 * - Interest-based communities (martial arts, running)
 * - Institution-based communities (military, police, fire)
 * - Leader hierarchy and moderation
 * - Events and meetups
 */
export declare enum CommunityRole {
    MEMBER = 0,
    MODERATOR = 1,
    ADMIN = 2,
    LEADER = 3
}
export type CommunityType = 'goal' | 'interest' | 'institution' | 'local' | 'challenge';
export type CommunityPrivacy = 'public' | 'private' | 'secret';
export type MembershipStatus = 'pending' | 'active' | 'suspended' | 'banned';
export type GoalType = 'weight_loss' | 'muscle_gain' | 'endurance' | 'flexibility' | 'strength' | 'general_fitness';
export type InstitutionType = 'military' | 'police' | 'fire' | 'medical' | 'education' | 'corporate';
export interface Community {
    id: number;
    slug: string;
    name: string;
    tagline?: string;
    description?: string;
    communityType: CommunityType;
    goalType?: GoalType;
    institutionType?: InstitutionType;
    archetypeId?: number;
    privacy: CommunityPrivacy;
    iconEmoji: string;
    accentColor: string;
    bannerImageUrl?: string;
    logoImageUrl?: string;
    rules?: string;
    memberCount: number;
    postCount: number;
    isVerified: boolean;
    isActive: boolean;
    requiresApproval: boolean;
    allowMemberPosts: boolean;
    createdBy: string;
    createdAt: Date;
    updatedAt: Date;
    isMember?: boolean;
    userRole?: CommunityRole;
    membershipStatus?: MembershipStatus;
}
export interface CommunityMember {
    userId: string;
    username: string;
    displayName?: string;
    avatarUrl?: string;
    role: CommunityRole;
    title?: string;
    status: MembershipStatus;
    joinedAt: Date;
    lastActiveAt?: Date;
    showInMemberList: boolean;
}
export interface CommunityInvite {
    id: string;
    communityId: number;
    inviterId: string;
    inviteeEmail?: string;
    inviteeUserId?: string;
    code: string;
    expiresAt: Date;
    usedAt?: Date;
    maxUses: number;
    useCount: number;
    createdAt: Date;
}
export interface CommunityEvent {
    id: string;
    communityId: number;
    virtualHangoutId?: number;
    creatorId: string;
    title: string;
    description?: string;
    eventType: 'meetup' | 'challenge' | 'workshop' | 'competition' | 'social';
    startsAt: Date;
    endsAt?: Date;
    timezone: string;
    locationName?: string;
    locationAddress?: string;
    isVirtual: boolean;
    virtualUrl?: string;
    maxParticipants?: number;
    participantCount: number;
    status: 'draft' | 'scheduled' | 'ongoing' | 'completed' | 'cancelled';
    createdAt: Date;
}
export interface CreateCommunityRequest {
    name: string;
    tagline?: string;
    description?: string;
    communityType: CommunityType;
    goalType?: GoalType;
    institutionType?: InstitutionType;
    archetypeId?: number;
    privacy?: CommunityPrivacy;
    iconEmoji?: string;
    accentColor?: string;
    rules?: string;
    requiresApproval?: boolean;
    allowMemberPosts?: boolean;
    createdBy: string;
}
export declare const communitiesService: {
    /**
     * Create a new community
     */
    create(request: CreateCommunityRequest): Promise<Community>;
    /**
     * Get community by ID or slug
     */
    getById(idOrSlug: number | string, userId?: string): Promise<Community | null>;
    /**
     * Search/list communities
     */
    search(userId?: string, options?: {
        query?: string;
        communityType?: CommunityType;
        goalType?: GoalType;
        institutionType?: InstitutionType;
        limit?: number;
        offset?: number;
    }): Promise<{
        communities: Community[];
        total: number;
    }>;
    /**
     * Join a community
     */
    join(communityId: number, userId: string): Promise<{
        status: MembershipStatus;
    }>;
    /**
     * Leave a community
     */
    leave(communityId: number, userId: string): Promise<void>;
    /**
     * Get community members
     */
    getMembers(communityId: number, options?: {
        limit?: number;
        offset?: number;
        status?: MembershipStatus;
        visibleOnly?: boolean;
    }): Promise<{
        members: CommunityMember[];
        total: number;
    }>;
    /**
     * Get user's communities
     */
    getUserCommunities(userId: string, options?: {
        limit?: number;
        offset?: number;
    }): Promise<{
        communities: Community[];
        total: number;
    }>;
    /**
     * Update member role (moderator actions)
     */
    updateMemberRole(communityId: number, targetUserId: string, newRole: CommunityRole, actorUserId: string): Promise<void>;
    /**
     * Approve/reject pending membership
     */
    handleMembershipRequest(communityId: number, targetUserId: string, approve: boolean, actorUserId: string): Promise<void>;
    /**
     * Create a community event
     */
    createEvent(communityId: number, creatorId: string, eventData: {
        title: string;
        description?: string;
        eventType: CommunityEvent["eventType"];
        startsAt: Date;
        endsAt?: Date;
        timezone?: string;
        locationName?: string;
        locationAddress?: string;
        isVirtual?: boolean;
        virtualUrl?: string;
        maxParticipants?: number;
    }): Promise<CommunityEvent>;
    /**
     * Get community events
     */
    getEvents(communityId: number, options?: {
        upcoming?: boolean;
        limit?: number;
        offset?: number;
    }): Promise<CommunityEvent[]>;
};
