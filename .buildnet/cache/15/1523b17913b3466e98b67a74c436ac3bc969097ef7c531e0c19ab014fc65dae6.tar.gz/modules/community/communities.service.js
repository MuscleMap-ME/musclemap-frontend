"use strict";
/**
 * Communities Service
 *
 * Manages self-organized communities with:
 * - Goal-based communities (weight loss, muscle gain)
 * - Interest-based communities (martial arts, running)
 * - Institution-based communities (military, police, fire)
 * - Leader hierarchy and moderation
 * - Events and meetups
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.communitiesService = exports.CommunityRole = void 0;
const crypto_1 = __importDefault(require("crypto"));
const client_1 = require("../../db/client");
const errors_1 = require("../../lib/errors");
const logger_1 = require("../../lib/logger");
const log = logger_1.loggers.core;
// Membership role levels
var CommunityRole;
(function (CommunityRole) {
    CommunityRole[CommunityRole["MEMBER"] = 0] = "MEMBER";
    CommunityRole[CommunityRole["MODERATOR"] = 1] = "MODERATOR";
    CommunityRole[CommunityRole["ADMIN"] = 2] = "ADMIN";
    CommunityRole[CommunityRole["LEADER"] = 3] = "LEADER";
})(CommunityRole || (exports.CommunityRole = CommunityRole = {}));
// Generate URL-safe slug
function generateSlug(name) {
    return name
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, '-')
        .replace(/^-+|-+$/g, '')
        .substring(0, 50);
}
// Service implementation
exports.communitiesService = {
    /**
     * Create a new community
     */
    async create(request) {
        const { name, tagline, description, communityType, goalType, institutionType, archetypeId, privacy = 'public', iconEmoji = '👥', accentColor = '#3B82F6', rules, requiresApproval = false, allowMemberPosts = true, createdBy, } = request;
        // Validate name
        if (!name || name.length < 3 || name.length > 100) {
            throw new errors_1.ValidationError('Community name must be between 3 and 100 characters');
        }
        // Generate unique slug
        let slug = generateSlug(name);
        let slugSuffix = 0;
        while (true) {
            const existing = await (0, client_1.queryOne)('SELECT id FROM communities WHERE slug = $1', [slugSuffix > 0 ? `${slug}-${slugSuffix}` : slug]);
            if (!existing) {
                if (slugSuffix > 0)
                    slug = `${slug}-${slugSuffix}`;
                break;
            }
            slugSuffix++;
            if (slugSuffix > 100) {
                throw new errors_1.ValidationError('Unable to generate unique slug');
            }
        }
        // Create community
        // Note: institution_type column doesn't exist in schema - using community_type = 'institution' instead
        const row = await (0, client_1.queryOne)(`INSERT INTO communities (
        slug, name, tagline, description, community_type, goal_type,
        archetype_id, privacy, created_by
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
      RETURNING id, created_at, updated_at`, [
            slug, name, tagline, description, communityType, goalType,
            archetypeId, privacy, createdBy
        ]);
        // Auto-add creator as leader
        await (0, client_1.query)(`INSERT INTO community_memberships (community_id, user_id, role_level, status, title)
       VALUES ($1, $2, $3, 'active', 'Founder')`, [row.id, createdBy, CommunityRole.LEADER]);
        log.info({ communityId: row.id, name, createdBy }, 'Community created');
        return {
            id: row.id,
            slug,
            name,
            tagline,
            description,
            communityType,
            goalType,
            institutionType,
            archetypeId,
            privacy,
            iconEmoji,
            accentColor,
            rules,
            memberCount: 1,
            postCount: 0,
            isVerified: false,
            isActive: true,
            requiresApproval,
            allowMemberPosts,
            createdBy,
            createdAt: row.created_at,
            updatedAt: row.updated_at,
            isMember: true,
            userRole: CommunityRole.LEADER,
            membershipStatus: 'active',
        };
    },
    /**
     * Get community by ID or slug
     */
    async getById(idOrSlug, userId) {
        const isNumeric = typeof idOrSlug === 'number' || /^\d+$/.test(String(idOrSlug));
        const whereClause = isNumeric ? 'c.id = $1' : 'c.slug = $1';
        const userJoin = userId
            ? `LEFT JOIN community_memberships cm ON cm.community_id = c.id AND cm.user_id = $2`
            : '';
        const userSelect = userId
            ? ', cm.role_level as user_role, (cm.user_id IS NOT NULL) as is_member, cm.status as membership_status'
            : ', NULL as user_role, NULL as is_member, NULL as membership_status';
        const queryParams = userId ? [idOrSlug, userId] : [idOrSlug];
        const row = await (0, client_1.queryOne)(`SELECT
        c.id, c.slug, c.name, c.tagline, c.description, c.community_type,
        c.goal_type, c.archetype_id, c.privacy,
        c.primary_color, c.avatar_url, c.banner_url,
        c.member_count, c.post_count, c.is_verified, c.is_active,
        c.created_by, c.created_at, c.updated_at
        ${userSelect}
       FROM communities c
       ${userJoin}
       WHERE ${whereClause}`, queryParams);
        if (!row)
            return null;
        // Check visibility
        if (row.privacy === 'secret' && !row.is_member) {
            return null;
        }
        return {
            id: row.id,
            slug: row.slug,
            name: row.name,
            tagline: row.tagline ?? undefined,
            description: row.description ?? undefined,
            communityType: row.community_type,
            goalType: row.goal_type,
            institutionType: undefined, // Column doesn't exist in schema
            archetypeId: row.archetype_id ?? undefined,
            privacy: row.privacy,
            iconEmoji: '',
            accentColor: row.primary_color ?? '',
            bannerImageUrl: row.banner_url ?? undefined,
            logoImageUrl: row.avatar_url ?? undefined,
            rules: undefined,
            memberCount: row.member_count,
            postCount: row.post_count,
            isVerified: row.is_verified,
            isActive: row.is_active,
            requiresApproval: false,
            allowMemberPosts: true,
            createdBy: row.created_by,
            createdAt: row.created_at,
            updatedAt: row.updated_at,
            isMember: row.is_member ?? undefined,
            userRole: row.user_role,
            membershipStatus: row.membership_status,
        };
    },
    /**
     * Search/list communities
     */
    async search(userId, options = {}) {
        const { query: searchQuery, communityType, goalType, institutionType, limit = 20, offset = 0 } = options;
        const conditions = ['c.is_active = TRUE', "c.privacy != 'secret'"];
        const params = [];
        let paramIndex = 1;
        if (searchQuery) {
            conditions.push(`(c.name ILIKE $${paramIndex} OR c.tagline ILIKE $${paramIndex} OR c.description ILIKE $${paramIndex})`);
            params.push(`%${searchQuery}%`);
            paramIndex++;
        }
        if (communityType) {
            conditions.push(`c.community_type = $${paramIndex++}`);
            params.push(communityType);
        }
        if (goalType) {
            conditions.push(`c.goal_type = $${paramIndex++}`);
            params.push(goalType);
        }
        // Note: institutionType filter is ignored - column doesn't exist in schema
        // If institutionType is set, filter by community_type = 'institution' instead
        if (institutionType) {
            conditions.push(`c.community_type = 'institution'`);
        }
        const whereClause = conditions.join(' AND ');
        // Handle userId parameter for SQL injection prevention
        let userJoin = '';
        let userSelect = ', NULL as user_role, NULL as is_member, NULL as membership_status';
        if (userId) {
            userJoin = `LEFT JOIN community_memberships cm ON cm.community_id = c.id AND cm.user_id = $${paramIndex++}`;
            params.push(userId);
            userSelect = ', cm.role_level as user_role, (cm.user_id IS NOT NULL) as is_member, cm.status as membership_status';
        }
        const rows = await (0, client_1.queryAll)(`SELECT
        c.id, c.slug, c.name, c.tagline, c.description, c.community_type,
        c.goal_type, c.archetype_id, c.privacy,
        c.primary_color, c.avatar_url, c.banner_url,
        c.member_count, c.post_count, c.is_verified, c.is_active,
        c.created_by, c.created_at, c.updated_at
        ${userSelect}
       FROM communities c
       ${userJoin}
       WHERE ${whereClause}
       ORDER BY c.member_count DESC, c.name
       LIMIT $${paramIndex++} OFFSET $${paramIndex++}`, [...params, limit, offset]);
        const countResult = await (0, client_1.queryOne)(`SELECT COUNT(*) as count FROM communities c WHERE ${whereClause}`, params);
        return {
            communities: rows.map(r => ({
                id: r.id,
                slug: r.slug,
                name: r.name,
                tagline: r.tagline ?? undefined,
                description: r.description ?? undefined,
                communityType: r.community_type,
                goalType: r.goal_type,
                institutionType: undefined, // Column doesn't exist in schema
                archetypeId: r.archetype_id ?? undefined,
                privacy: r.privacy,
                iconEmoji: '',
                accentColor: r.primary_color ?? '',
                bannerImageUrl: r.banner_url ?? undefined,
                logoImageUrl: r.avatar_url ?? undefined,
                memberCount: r.member_count,
                postCount: r.post_count,
                isVerified: r.is_verified,
                isActive: r.is_active,
                requiresApproval: false,
                allowMemberPosts: true,
                createdBy: r.created_by,
                createdAt: r.created_at,
                updatedAt: r.updated_at,
                isMember: r.is_member ?? undefined,
                userRole: r.user_role,
                membershipStatus: r.membership_status,
            })),
            total: parseInt(countResult?.count || '0', 10),
        };
    },
    /**
     * Join a community
     */
    async join(communityId, userId) {
        const community = await (0, client_1.queryOne)('SELECT id, privacy, requires_approval, is_active FROM communities WHERE id = $1', [communityId]);
        if (!community) {
            throw new errors_1.NotFoundError('Community not found');
        }
        if (!community.is_active) {
            throw new errors_1.ValidationError('Community is not active');
        }
        if (community.privacy === 'secret') {
            throw new errors_1.ForbiddenError('Cannot join a secret community without invitation');
        }
        // Check existing membership
        const existing = await (0, client_1.queryOne)('SELECT status FROM community_memberships WHERE community_id = $1 AND user_id = $2', [communityId, userId]);
        if (existing) {
            if (existing.status === 'active') {
                throw new errors_1.ValidationError('Already a member of this community');
            }
            if (existing.status === 'banned') {
                throw new errors_1.ForbiddenError('You are banned from this community');
            }
            if (existing.status === 'pending') {
                throw new errors_1.ValidationError('Your membership is pending approval');
            }
        }
        const status = community.requires_approval || community.privacy === 'private'
            ? 'pending'
            : 'active';
        await (0, client_1.query)(`INSERT INTO community_memberships (community_id, user_id, role_level, status)
       VALUES ($1, $2, $3, $4)
       ON CONFLICT (community_id, user_id) DO UPDATE SET status = $4`, [communityId, userId, CommunityRole.MEMBER, status]);
        log.info({ communityId, userId, status }, 'User joined community');
        return { status };
    },
    /**
     * Leave a community
     */
    async leave(communityId, userId) {
        const membership = await (0, client_1.queryOne)('SELECT role_level FROM community_memberships WHERE community_id = $1 AND user_id = $2', [communityId, userId]);
        if (!membership) {
            throw new errors_1.NotFoundError('Not a member of this community');
        }
        if (membership.role_level === CommunityRole.LEADER) {
            // Check if there are other leaders
            const otherLeaders = await (0, client_1.queryOne)(`SELECT COUNT(*) as count FROM community_memberships
         WHERE community_id = $1 AND role_level = $2 AND user_id != $3`, [communityId, CommunityRole.LEADER, userId]);
            if (parseInt(otherLeaders?.count || '0', 10) === 0) {
                throw new errors_1.ValidationError('Cannot leave as the only leader. Transfer leadership first.');
            }
        }
        await (0, client_1.query)('DELETE FROM community_memberships WHERE community_id = $1 AND user_id = $2', [communityId, userId]);
        log.info({ communityId, userId }, 'User left community');
    },
    /**
     * Get community members
     */
    async getMembers(communityId, options = {}) {
        const { limit = 50, offset = 0, status = 'active', visibleOnly = true } = options;
        const conditions = ['cm.community_id = $1'];
        const params = [communityId];
        let paramIndex = 2;
        if (status) {
            conditions.push(`cm.status = $${paramIndex++}`);
            params.push(status);
        }
        if (visibleOnly) {
            conditions.push('cm.show_in_member_list = TRUE');
        }
        const whereClause = conditions.join(' AND ');
        const rows = await (0, client_1.queryAll)(`SELECT
        cm.user_id, u.username, u.display_name, u.avatar_url,
        cm.role_level, cm.title, cm.status, cm.joined_at,
        cm.last_active_at, cm.show_in_member_list
       FROM community_memberships cm
       JOIN users u ON u.id = cm.user_id
       WHERE ${whereClause}
       ORDER BY cm.role_level DESC, cm.joined_at
       LIMIT $${paramIndex++} OFFSET $${paramIndex++}`, [...params, limit, offset]);
        const countResult = await (0, client_1.queryOne)(`SELECT COUNT(*) as count FROM community_memberships cm WHERE ${whereClause}`, params);
        return {
            members: rows.map(r => ({
                userId: r.user_id,
                username: r.username,
                displayName: r.display_name ?? undefined,
                avatarUrl: r.avatar_url ?? undefined,
                role: r.role_level,
                title: r.title ?? undefined,
                status: r.status,
                joinedAt: r.joined_at,
                lastActiveAt: r.last_active_at ?? undefined,
                showInMemberList: r.show_in_member_list,
            })),
            total: parseInt(countResult?.count || '0', 10),
        };
    },
    /**
     * Get user's communities
     */
    async getUserCommunities(userId, options = {}) {
        const { limit = 50, offset = 0 } = options;
        const rows = await (0, client_1.queryAll)(`SELECT
        c.id, c.slug, c.name, c.tagline, c.community_type,
        c.icon_emoji, c.accent_color, c.member_count, c.is_verified,
        cm.role_level as user_role, cm.status as membership_status, c.created_at
       FROM community_memberships cm
       JOIN communities c ON c.id = cm.community_id
       WHERE cm.user_id = $1 AND c.is_active = TRUE
       ORDER BY cm.last_active_at DESC NULLS LAST
       LIMIT $2 OFFSET $3`, [userId, limit, offset]);
        const countResult = await (0, client_1.queryOne)(`SELECT COUNT(*) as count FROM community_memberships cm
       JOIN communities c ON c.id = cm.community_id
       WHERE cm.user_id = $1 AND c.is_active = TRUE`, [userId]);
        return {
            communities: rows.map(r => ({
                id: r.id,
                slug: r.slug,
                name: r.name,
                tagline: r.tagline ?? undefined,
                communityType: r.community_type,
                iconEmoji: r.icon_emoji,
                accentColor: r.accent_color,
                memberCount: r.member_count,
                isVerified: r.is_verified,
                isMember: true,
                userRole: r.user_role,
                membershipStatus: r.membership_status,
                createdAt: r.created_at,
                // Minimal fields for list view
                privacy: 'public',
                postCount: 0,
                isActive: true,
                requiresApproval: false,
                allowMemberPosts: true,
                createdBy: '',
                updatedAt: r.created_at,
            })),
            total: parseInt(countResult?.count || '0', 10),
        };
    },
    /**
     * Update member role (moderator actions)
     */
    async updateMemberRole(communityId, targetUserId, newRole, actorUserId) {
        // Check actor's role
        const actorMembership = await (0, client_1.queryOne)('SELECT role_level FROM community_memberships WHERE community_id = $1 AND user_id = $2', [communityId, actorUserId]);
        if (!actorMembership || actorMembership.role_level < CommunityRole.ADMIN) {
            throw new errors_1.ForbiddenError('Insufficient permissions');
        }
        // Cannot promote to leader or demote leader unless you're a leader
        if (newRole === CommunityRole.LEADER && actorMembership.role_level !== CommunityRole.LEADER) {
            throw new errors_1.ForbiddenError('Only leaders can promote to leader');
        }
        const targetMembership = await (0, client_1.queryOne)('SELECT role_level FROM community_memberships WHERE community_id = $1 AND user_id = $2', [communityId, targetUserId]);
        if (!targetMembership) {
            throw new errors_1.NotFoundError('User is not a member');
        }
        if (targetMembership.role_level === CommunityRole.LEADER && actorMembership.role_level !== CommunityRole.LEADER) {
            throw new errors_1.ForbiddenError('Cannot modify leader role');
        }
        await (0, client_1.query)('UPDATE community_memberships SET role_level = $1 WHERE community_id = $2 AND user_id = $3', [newRole, communityId, targetUserId]);
        log.info({ communityId, targetUserId, newRole, actorUserId }, 'Member role updated');
    },
    /**
     * Approve/reject pending membership
     */
    async handleMembershipRequest(communityId, targetUserId, approve, actorUserId) {
        // Check actor's role
        const actorMembership = await (0, client_1.queryOne)('SELECT role_level FROM community_memberships WHERE community_id = $1 AND user_id = $2', [communityId, actorUserId]);
        if (!actorMembership || actorMembership.role_level < CommunityRole.MODERATOR) {
            throw new errors_1.ForbiddenError('Insufficient permissions');
        }
        const targetMembership = await (0, client_1.queryOne)('SELECT status FROM community_memberships WHERE community_id = $1 AND user_id = $2', [communityId, targetUserId]);
        if (!targetMembership || targetMembership.status !== 'pending') {
            throw new errors_1.NotFoundError('No pending membership request found');
        }
        if (approve) {
            await (0, client_1.query)('UPDATE community_memberships SET status = $1 WHERE community_id = $2 AND user_id = $3', ['active', communityId, targetUserId]);
        }
        else {
            await (0, client_1.query)('DELETE FROM community_memberships WHERE community_id = $1 AND user_id = $2', [communityId, targetUserId]);
        }
        log.info({ communityId, targetUserId, approved: approve, actorUserId }, 'Membership request handled');
    },
    /**
     * Create a community event
     */
    async createEvent(communityId, creatorId, eventData) {
        // Verify creator is a member with sufficient role
        const membership = await (0, client_1.queryOne)('SELECT role_level FROM community_memberships WHERE community_id = $1 AND user_id = $2', [communityId, creatorId]);
        if (!membership || membership.role_level < CommunityRole.MODERATOR) {
            throw new errors_1.ForbiddenError('Insufficient permissions to create events');
        }
        const eventId = `ce_${crypto_1.default.randomBytes(12).toString('hex')}`;
        const row = await (0, client_1.queryOne)(`INSERT INTO community_events (
        id, community_id, creator_id, title, description, event_type,
        starts_at, ends_at, timezone, location_name, location_address,
        is_virtual, virtual_url, max_participants, status
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, 'scheduled')
      RETURNING created_at`, [
            eventId, communityId, creatorId, eventData.title, eventData.description,
            eventData.eventType, eventData.startsAt, eventData.endsAt,
            eventData.timezone || 'UTC', eventData.locationName, eventData.locationAddress,
            eventData.isVirtual ?? false, eventData.virtualUrl, eventData.maxParticipants
        ]);
        log.info({ eventId, communityId, creatorId }, 'Community event created');
        return {
            id: eventId,
            communityId,
            creatorId,
            title: eventData.title,
            description: eventData.description,
            eventType: eventData.eventType,
            startsAt: eventData.startsAt,
            endsAt: eventData.endsAt,
            timezone: eventData.timezone || 'UTC',
            locationName: eventData.locationName,
            locationAddress: eventData.locationAddress,
            isVirtual: eventData.isVirtual ?? false,
            virtualUrl: eventData.virtualUrl,
            maxParticipants: eventData.maxParticipants,
            participantCount: 0,
            status: 'scheduled',
            createdAt: row.created_at,
        };
    },
    /**
     * Get community events
     */
    async getEvents(communityId, options = {}) {
        const { upcoming = true, limit = 20, offset = 0 } = options;
        let whereClause = 'e.community_id = $1';
        if (upcoming) {
            whereClause += " AND e.starts_at > NOW() AND e.status = 'scheduled'";
        }
        const rows = await (0, client_1.queryAll)(`SELECT
        e.id, e.community_id, e.virtual_hangout_id, e.creator_id, e.title, e.description,
        e.event_type, e.starts_at, e.ends_at, e.timezone, e.location_name, e.location_address,
        e.is_virtual, e.virtual_url, e.max_participants,
        (SELECT COUNT(*) FROM event_participants WHERE event_id = e.id AND status != 'cancelled') as participant_count,
        e.status, e.created_at
       FROM community_events e
       WHERE ${whereClause}
       ORDER BY e.starts_at ${upcoming ? 'ASC' : 'DESC'}
       LIMIT $2 OFFSET $3`, [communityId, limit, offset]);
        return rows.map(r => ({
            id: r.id,
            communityId: r.community_id,
            virtualHangoutId: r.virtual_hangout_id ?? undefined,
            creatorId: r.creator_id,
            title: r.title,
            description: r.description ?? undefined,
            eventType: r.event_type,
            startsAt: r.starts_at,
            endsAt: r.ends_at ?? undefined,
            timezone: r.timezone,
            locationName: r.location_name ?? undefined,
            locationAddress: r.location_address ?? undefined,
            isVirtual: r.is_virtual,
            virtualUrl: r.virtual_url ?? undefined,
            maxParticipants: r.max_participants ?? undefined,
            participantCount: parseInt(r.participant_count, 10) || 0,
            status: r.status,
            createdAt: r.created_at,
        }));
    },
};
//# sourceMappingURL=communities.service.js.map