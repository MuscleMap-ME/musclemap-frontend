/**
 * Privacy Service
 *
 * Manages user privacy controls:
 * - Ghost mode (appear offline)
 * - Profile visibility
 * - Activity visibility
 * - Blocking and muting
 */
export type ProfileVisibility = 'public' | 'members_only' | 'connections_only' | 'private';
export type ActivityVisibility = 'public' | 'members_only' | 'connections_only' | 'private';
export interface UserPrivacySettings {
    userId: string;
    ghostModeEnabled: boolean;
    ghostModeUntil?: Date;
    profileVisibility: ProfileVisibility;
    activityVisibility: ActivityVisibility;
    showInLeaderboards: boolean;
    showInMemberLists: boolean;
    allowDirectMessages: boolean;
    allowEventInvites: boolean;
    showWorkoutHistory: boolean;
    showAchievements: boolean;
    showStats: boolean;
    updatedAt: Date;
}
export interface BlockedUser {
    userId: string;
    blockedUserId: string;
    blockedUsername: string;
    blockedAt: Date;
}
export interface MutedEntity {
    userId: string;
    entityType: 'user' | 'community' | 'hangout';
    entityId: string | number;
    entityName: string;
    mutedAt: Date;
    muteUntil?: Date;
}
export declare const privacyService: {
    /**
     * Get user's privacy settings
     */
    getSettings(userId: string): Promise<UserPrivacySettings>;
    /**
     * Update privacy settings
     */
    updateSettings(userId: string, settings: Partial<Omit<UserPrivacySettings, "userId" | "updatedAt">>): Promise<UserPrivacySettings>;
    /**
     * Enable ghost mode (appear offline)
     */
    enableGhostMode(userId: string, durationHours?: number): Promise<void>;
    /**
     * Disable ghost mode
     */
    disableGhostMode(userId: string): Promise<void>;
    /**
     * Check if user is in ghost mode
     */
    isGhostMode(userId: string): Promise<boolean>;
    /**
     * Block a user
     */
    blockUser(userId: string, blockedUserId: string): Promise<void>;
    /**
     * Unblock a user
     */
    unblockUser(userId: string, blockedUserId: string): Promise<void>;
    /**
     * Get blocked users
     */
    getBlockedUsers(userId: string): Promise<BlockedUser[]>;
    /**
     * Check if user is blocked
     */
    isBlocked(userId: string, otherUserId: string): Promise<boolean>;
    /**
     * Mute a user, community, or hangout
     */
    mute(userId: string, entityType: MutedEntity["entityType"], entityId: string | number, durationHours?: number): Promise<void>;
    /**
     * Unmute an entity
     */
    unmute(userId: string, entityType: MutedEntity["entityType"], entityId: string | number): Promise<void>;
    /**
     * Get muted entities
     */
    getMutedEntities(userId: string): Promise<MutedEntity[]>;
    /**
     * Check if entity is muted
     */
    isMuted(userId: string, entityType: MutedEntity["entityType"], entityId: string | number): Promise<boolean>;
    /**
     * Check if user can view another user's profile
     */
    canViewProfile(viewerId: string | undefined, targetUserId: string): Promise<boolean>;
    /**
     * Check if user can view another user's activity
     */
    canViewActivity(viewerId: string | undefined, targetUserId: string): Promise<boolean>;
};
