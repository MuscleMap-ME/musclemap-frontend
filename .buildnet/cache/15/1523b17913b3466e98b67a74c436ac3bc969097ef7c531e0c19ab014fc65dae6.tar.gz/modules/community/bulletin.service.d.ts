/**
 * Bulletin Board Service
 *
 * Manages community discussion boards with:
 * - Posts with upvote/downvote voting
 * - Comments and replies
 * - Pin and highlight by moderators
 * - Content moderation
 */
export type PostType = 'discussion' | 'question' | 'announcement' | 'poll' | 'workout_share' | 'milestone';
export type VoteType = 'up' | 'down';
export interface BulletinPost {
    id: string;
    boardId: number;
    authorId?: string;
    authorUsername?: string;
    authorDisplayName?: string;
    authorAvatarUrl?: string;
    title: string;
    content: string;
    contentLang: string;
    postType: PostType;
    mediaUrls: string[];
    linkedWorkoutId?: string;
    linkedMilestoneId?: string;
    upvotes: number;
    downvotes: number;
    score: number;
    commentCount: number;
    viewCount: number;
    isPinned: boolean;
    isHighlighted: boolean;
    isHidden: boolean;
    createdAt: Date;
    updatedAt: Date;
    userVote?: VoteType;
}
export interface BulletinComment {
    id: string;
    postId: string;
    parentId?: string;
    authorId?: string;
    authorUsername?: string;
    authorDisplayName?: string;
    authorAvatarUrl?: string;
    content: string;
    upvotes: number;
    downvotes: number;
    score: number;
    replyCount: number;
    isHidden: boolean;
    createdAt: Date;
    updatedAt: Date;
    userVote?: VoteType;
    replies?: BulletinComment[];
}
export interface CreatePostRequest {
    boardId: number;
    authorId: string;
    title: string;
    content: string;
    postType?: PostType;
    contentLang?: string;
    mediaUrls?: string[];
    linkedWorkoutId?: string;
    linkedMilestoneId?: string;
}
export declare const bulletinService: {
    /**
     * Create a new post
     */
    createPost(request: CreatePostRequest): Promise<BulletinPost>;
    /**
     * Get posts from a bulletin board
     */
    getPosts(boardId: number, userId?: string, options?: {
        limit?: number;
        offset?: number;
        sortBy?: "hot" | "new" | "top";
        postType?: PostType;
    }): Promise<{
        posts: BulletinPost[];
        total: number;
    }>;
    /**
     * Get a single post by ID
     */
    getPostById(postId: string, userId?: string): Promise<BulletinPost | null>;
    /**
     * Vote on a post
     */
    votePost(postId: string, userId: string, voteType: VoteType): Promise<{
        upvotes: number;
        downvotes: number;
        score: number;
    }>;
    /**
     * Add a comment to a post
     */
    addComment(postId: string, authorId: string, content: string, parentId?: string): Promise<BulletinComment>;
    /**
     * Get comments for a post
     */
    getComments(postId: string, userId?: string, options?: {
        limit?: number;
        offset?: number;
    }): Promise<{
        comments: BulletinComment[];
        total: number;
    }>;
    /**
     * Vote on a comment
     */
    voteComment(commentId: string, userId: string, voteType: VoteType): Promise<{
        upvotes: number;
        downvotes: number;
        score: number;
    }>;
    /**
     * Moderator: Pin/unpin a post
     */
    togglePinPost(postId: string, actorUserId: string, pin: boolean): Promise<void>;
    /**
     * Moderator: Hide/unhide a post
     */
    toggleHidePost(postId: string, actorUserId: string, hide: boolean): Promise<void>;
    /**
     * Get or create a bulletin board for a community/hangout
     */
    getOrCreateBoard(type: "community" | "hangout", entityId: number): Promise<{
        id: number;
        name: string;
    }>;
};
