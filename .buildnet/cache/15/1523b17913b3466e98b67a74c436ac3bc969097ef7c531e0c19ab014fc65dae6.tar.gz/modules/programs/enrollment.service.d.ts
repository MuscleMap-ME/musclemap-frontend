/**
 * Program Enrollment Service
 *
 * Handles user enrollment and progress tracking for training programs.
 */
import type { ProgramEnrollment, EnrollmentStatus, TrainingProgram, EnrollmentProgress, ProgramDay } from './types';
export declare const EnrollmentService: {
    /**
     * Enroll user in a program
     */
    enroll(userId: string, programId: string): Promise<ProgramEnrollment>;
    /**
     * Get user's active enrollment
     */
    getActiveEnrollment(userId: string, programId?: string): Promise<ProgramEnrollment | null>;
    /**
     * Get all user enrollments
     */
    getUserEnrollments(userId: string, options?: {
        status?: EnrollmentStatus;
        limit?: number;
        offset?: number;
    }): Promise<{
        enrollments: ProgramEnrollment[];
        total: number;
    }>;
    /**
     * Get enrollment by ID
     */
    getById(enrollmentId: string, userId: string): Promise<ProgramEnrollment>;
    /**
     * Get enrollment with program details
     */
    getEnrollmentWithProgram(enrollmentId: string, userId: string): Promise<{
        enrollment: ProgramEnrollment;
        program: TrainingProgram;
        progress: EnrollmentProgress;
    }>;
    /**
     * Record workout completion
     */
    recordWorkout(userId: string, programId: string): Promise<ProgramEnrollment>;
    /**
     * Pause enrollment
     */
    pause(enrollmentId: string, userId: string): Promise<ProgramEnrollment>;
    /**
     * Resume enrollment
     */
    resume(enrollmentId: string, userId: string): Promise<ProgramEnrollment>;
    /**
     * Drop/quit enrollment
     */
    drop(enrollmentId: string, userId: string): Promise<ProgramEnrollment>;
    /**
     * Get today's workout for active enrollment
     */
    getTodaysWorkout(userId: string, programId?: string): Promise<{
        enrollment: ProgramEnrollment;
        program: TrainingProgram;
        todaysWorkout: ProgramDay | null;
    } | null>;
    /**
     * Calculate enrollment progress
     */
    calculateProgress(enrollment: ProgramEnrollment, program: TrainingProgram): EnrollmentProgress;
    /**
     * Reset streak (called when user misses a workout)
     */
    resetStreak(userId: string, programId: string): Promise<void>;
    /**
     * Update progress data (for tracking weights, etc.)
     */
    updateProgressData(enrollmentId: string, userId: string, exerciseId: string, data: {
        weight?: number;
        reps?: number;
        notes?: string;
    }): Promise<ProgramEnrollment>;
};
export default EnrollmentService;
