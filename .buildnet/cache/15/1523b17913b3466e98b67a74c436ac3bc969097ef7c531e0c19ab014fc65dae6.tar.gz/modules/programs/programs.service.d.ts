/**
 * Training Programs Service
 *
 * Handles CRUD operations for multi-week training programs.
 */
import type { TrainingProgram, CreateProgramInput, UpdateProgramInput, ProgramSearchOptions } from './types';
export declare const ProgramsService: {
    /**
     * Create a new training program
     */
    create(userId: string, input: CreateProgramInput): Promise<TrainingProgram>;
    /**
     * Get a program by ID
     */
    getById(programId: string, userId?: string): Promise<TrainingProgram>;
    /**
     * Update a program
     */
    update(programId: string, userId: string, input: UpdateProgramInput): Promise<TrainingProgram>;
    /**
     * Delete a program
     */
    delete(programId: string, userId: string): Promise<void>;
    /**
     * Get user's programs
     */
    getUserPrograms(userId: string, options?: {
        limit?: number;
        offset?: number;
    }): Promise<{
        programs: TrainingProgram[];
        total: number;
    }>;
    /**
     * Search public programs
     */
    search(options?: ProgramSearchOptions, userId?: string): Promise<{
        programs: TrainingProgram[];
        total: number;
    }>;
    /**
     * Get official programs
     */
    getOfficialPrograms(userId?: string): Promise<TrainingProgram[]>;
    /**
     * Get featured programs
     */
    getFeaturedPrograms(limit?: number, userId?: string): Promise<TrainingProgram[]>;
    /**
     * Rate a program
     */
    rate(programId: string, userId: string, rating: number, review?: string): Promise<void>;
    /**
     * Duplicate a program
     */
    duplicate(programId: string, userId: string, newName?: string): Promise<TrainingProgram>;
};
export default ProgramsService;
