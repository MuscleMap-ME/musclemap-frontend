"use strict";
/**
 * Program Enrollment Service
 *
 * Handles user enrollment and progress tracking for training programs.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.EnrollmentService = void 0;
const client_1 = require("../../db/client");
const logger_1 = require("../../lib/logger");
const errors_1 = require("../../lib/errors");
const programs_service_1 = require("./programs.service");
const log = logger_1.loggers.core.child({ service: 'enrollment' });
function mapEnrollment(row) {
    return {
        id: row.id,
        userId: row.user_id,
        programId: row.program_id,
        currentWeek: row.current_week,
        currentDay: row.current_day,
        status: row.status,
        startedAt: row.started_at,
        pausedAt: row.paused_at ?? undefined,
        completedAt: row.completed_at ?? undefined,
        expectedEndDate: row.expected_end_date ?? undefined,
        workoutsCompleted: row.workouts_completed,
        totalWorkouts: row.total_workouts,
        streakCurrent: row.streak_current,
        streakLongest: row.streak_longest,
        progressData: row.progress_data,
        userRating: row.user_rating ?? undefined,
        userReview: row.user_review ?? undefined,
        ratedAt: row.rated_at ?? undefined,
        createdAt: row.created_at,
        updatedAt: row.updated_at,
    };
}
exports.EnrollmentService = {
    /**
     * Enroll user in a program
     */
    async enroll(userId, programId) {
        // Check program exists and is accessible
        const program = await programs_service_1.ProgramsService.getById(programId, userId);
        // Check if user already has an active enrollment in this program
        const existing = await (0, client_1.queryOne)('SELECT id, status FROM program_enrollments WHERE user_id = $1 AND program_id = $2', [userId, programId]);
        if (existing) {
            if (existing.status === 'active') {
                throw new errors_1.ValidationError('You are already enrolled in this program');
            }
            if (existing.status === 'paused') {
                // Resume instead of creating new enrollment
                return this.resume(existing.id, userId);
            }
        }
        // Calculate total workouts
        const totalWorkouts = program.durationWeeks * program.daysPerWeek;
        // Calculate expected end date
        const expectedEndDate = new Date();
        expectedEndDate.setDate(expectedEndDate.getDate() + program.durationWeeks * 7);
        return await (0, client_1.transaction)(async (client) => {
            // Create enrollment
            const result = await client.query(`INSERT INTO program_enrollments (
          user_id, program_id, current_week, current_day, status,
          total_workouts, expected_end_date
        )
         VALUES ($1, $2, 1, 1, 'active', $3, $4)
         ON CONFLICT (user_id, program_id) DO UPDATE SET
           status = 'active',
           current_week = 1,
           current_day = 1,
           started_at = NOW(),
           paused_at = NULL,
           completed_at = NULL,
           workouts_completed = 0,
           streak_current = 0,
           expected_end_date = $4,
           updated_at = NOW()
         RETURNING *`, [userId, programId, totalWorkouts, expectedEndDate]);
            // Update program stats
            await client.query(`UPDATE training_programs SET
           total_enrollments = total_enrollments + 1,
           active_enrollments = active_enrollments + 1
         WHERE id = $1`, [programId]);
            log.info(`User ${userId} enrolled in program ${programId}`);
            return mapEnrollment(result.rows[0]);
        });
    },
    /**
     * Get user's active enrollment
     */
    async getActiveEnrollment(userId, programId) {
        let sql = `SELECT * FROM program_enrollments WHERE user_id = $1 AND status = 'active'`;
        const params = [userId];
        if (programId) {
            sql += ' AND program_id = $2';
            params.push(programId);
        }
        sql += ' LIMIT 1';
        const row = await (0, client_1.queryOne)(sql, params);
        return row ? mapEnrollment(row) : null;
    },
    /**
     * Get all user enrollments
     */
    async getUserEnrollments(userId, options = {}) {
        const { status, limit = 20, offset = 0 } = options;
        let whereClause = 'WHERE e.user_id = $1';
        const params = [userId];
        let paramIndex = 2;
        if (status) {
            whereClause += ` AND e.status = $${paramIndex++}`;
            params.push(status);
        }
        params.push(limit, offset);
        const result = await (0, client_1.queryAll)(`SELECT e.*, p.name as program_name, p.duration_weeks as program_duration_weeks, p.days_per_week as program_days_per_week
       FROM program_enrollments e
       JOIN training_programs p ON p.id = e.program_id
       ${whereClause}
       ORDER BY e.status = 'active' DESC, e.updated_at DESC
       LIMIT $${paramIndex++} OFFSET $${paramIndex++}`, params);
        const countParams = status ? [userId, status] : [userId];
        const countResult = await (0, client_1.queryOne)(`SELECT COUNT(*) as count FROM program_enrollments e
       ${whereClause}`, countParams);
        return {
            enrollments: result.map(mapEnrollment),
            total: parseInt(countResult?.count || '0'),
        };
    },
    /**
     * Get enrollment by ID
     */
    async getById(enrollmentId, userId) {
        const row = await (0, client_1.queryOne)('SELECT * FROM program_enrollments WHERE id = $1 AND user_id = $2', [enrollmentId, userId]);
        if (!row) {
            throw new errors_1.NotFoundError('Enrollment not found');
        }
        return mapEnrollment(row);
    },
    /**
     * Get enrollment with program details
     */
    async getEnrollmentWithProgram(enrollmentId, userId) {
        const enrollment = await this.getById(enrollmentId, userId);
        const program = await programs_service_1.ProgramsService.getById(enrollment.programId, userId);
        const progress = this.calculateProgress(enrollment, program);
        return { enrollment, program, progress };
    },
    /**
     * Record workout completion
     */
    async recordWorkout(userId, programId) {
        const enrollment = await (0, client_1.queryOne)('SELECT * FROM program_enrollments WHERE user_id = $1 AND program_id = $2 AND status = $3', [userId, programId, 'active']);
        if (!enrollment) {
            throw new errors_1.NotFoundError('No active enrollment found for this program');
        }
        const program = await programs_service_1.ProgramsService.getById(programId, userId);
        // Calculate next day/week
        let nextDay = enrollment.current_day + 1;
        let nextWeek = enrollment.current_week;
        let completed = false;
        if (nextDay > program.daysPerWeek) {
            nextDay = 1;
            nextWeek = enrollment.current_week + 1;
        }
        if (nextWeek > program.durationWeeks) {
            completed = true;
        }
        // Update streak
        const newStreak = enrollment.streak_current + 1;
        const longestStreak = Math.max(enrollment.streak_longest, newStreak);
        if (completed) {
            return await (0, client_1.transaction)(async (client) => {
                const result = await client.query(`UPDATE program_enrollments SET
             workouts_completed = workouts_completed + 1,
             streak_current = $3,
             streak_longest = $4,
             status = 'completed',
             completed_at = NOW(),
             updated_at = NOW()
           WHERE id = $1 AND user_id = $2
           RETURNING *`, [enrollment.id, userId, newStreak, longestStreak]);
                // Update program stats
                await client.query(`UPDATE training_programs SET
             active_enrollments = active_enrollments - 1,
             completion_rate = (
               SELECT (COUNT(*) FILTER (WHERE status = 'completed')::float /
                       NULLIF(COUNT(*), 0) * 100)
               FROM program_enrollments WHERE program_id = $1
             )
           WHERE id = $1`, [programId]);
                log.info(`User ${userId} completed program ${programId}`);
                return mapEnrollment(result.rows[0]);
            });
        }
        const result = await (0, client_1.queryOne)(`UPDATE program_enrollments SET
         current_week = $3,
         current_day = $4,
         workouts_completed = workouts_completed + 1,
         streak_current = $5,
         streak_longest = $6,
         updated_at = NOW()
       WHERE id = $1 AND user_id = $2
       RETURNING *`, [enrollment.id, userId, nextWeek, nextDay, newStreak, longestStreak]);
        log.info(`User ${userId} completed workout in program ${programId} (week ${nextWeek}, day ${nextDay})`);
        return mapEnrollment(result);
    },
    /**
     * Pause enrollment
     */
    async pause(enrollmentId, userId) {
        const enrollment = await this.getById(enrollmentId, userId);
        if (enrollment.status !== 'active') {
            throw new errors_1.ValidationError('Only active enrollments can be paused');
        }
        return await (0, client_1.transaction)(async (client) => {
            const result = await client.query(`UPDATE program_enrollments SET
           status = 'paused',
           paused_at = NOW(),
           streak_current = 0,
           updated_at = NOW()
         WHERE id = $1 AND user_id = $2
         RETURNING *`, [enrollmentId, userId]);
            // Update program stats
            await client.query('UPDATE training_programs SET active_enrollments = active_enrollments - 1 WHERE id = $1', [enrollment.programId]);
            log.info(`User ${userId} paused enrollment ${enrollmentId}`);
            return mapEnrollment(result.rows[0]);
        });
    },
    /**
     * Resume enrollment
     */
    async resume(enrollmentId, userId) {
        const enrollment = await this.getById(enrollmentId, userId);
        if (enrollment.status !== 'paused') {
            throw new errors_1.ValidationError('Only paused enrollments can be resumed');
        }
        return await (0, client_1.transaction)(async (client) => {
            // Recalculate expected end date
            const program = await programs_service_1.ProgramsService.getById(enrollment.programId, userId);
            const remainingWeeks = program.durationWeeks - enrollment.currentWeek + 1;
            const expectedEndDate = new Date();
            expectedEndDate.setDate(expectedEndDate.getDate() + remainingWeeks * 7);
            const result = await client.query(`UPDATE program_enrollments SET
           status = 'active',
           paused_at = NULL,
           expected_end_date = $3,
           updated_at = NOW()
         WHERE id = $1 AND user_id = $2
         RETURNING *`, [enrollmentId, userId, expectedEndDate]);
            // Update program stats
            await client.query('UPDATE training_programs SET active_enrollments = active_enrollments + 1 WHERE id = $1', [enrollment.programId]);
            log.info(`User ${userId} resumed enrollment ${enrollmentId}`);
            return mapEnrollment(result.rows[0]);
        });
    },
    /**
     * Drop/quit enrollment
     */
    async drop(enrollmentId, userId) {
        const enrollment = await this.getById(enrollmentId, userId);
        if (enrollment.status === 'completed') {
            throw new errors_1.ValidationError('Cannot drop a completed program');
        }
        if (enrollment.status === 'dropped') {
            throw new errors_1.ValidationError('Already dropped from this program');
        }
        return await (0, client_1.transaction)(async (client) => {
            const result = await client.query(`UPDATE program_enrollments SET
           status = 'dropped',
           streak_current = 0,
           updated_at = NOW()
         WHERE id = $1 AND user_id = $2
         RETURNING *`, [enrollmentId, userId]);
            // Update program stats if was active
            if (enrollment.status === 'active') {
                await client.query('UPDATE training_programs SET active_enrollments = active_enrollments - 1 WHERE id = $1', [enrollment.programId]);
            }
            log.info(`User ${userId} dropped enrollment ${enrollmentId}`);
            return mapEnrollment(result.rows[0]);
        });
    },
    /**
     * Get today's workout for active enrollment
     */
    async getTodaysWorkout(userId, programId) {
        let enrollment;
        if (programId) {
            enrollment = await this.getActiveEnrollment(userId, programId);
        }
        else {
            enrollment = await this.getActiveEnrollment(userId);
        }
        if (!enrollment) {
            return null;
        }
        const program = await programs_service_1.ProgramsService.getById(enrollment.programId, userId);
        // Find today's workout from schedule
        const todaysWorkout = program.schedule.find((day) => day.day === enrollment.currentDay) ?? null;
        return { enrollment, program, todaysWorkout };
    },
    /**
     * Calculate enrollment progress
     */
    calculateProgress(enrollment, program) {
        const totalWorkouts = program.durationWeeks * program.daysPerWeek;
        const weekProgress = (enrollment.currentDay / program.daysPerWeek) * 100;
        const totalProgress = (enrollment.workoutsCompleted / totalWorkouts) * 100;
        // Calculate days remaining
        const expectedEnd = enrollment.expectedEndDate ?? new Date();
        const now = new Date();
        const daysRemaining = Math.max(0, Math.ceil((expectedEnd.getTime() - now.getTime()) / (1000 * 60 * 60 * 24)));
        // Check if on track (should have completed X workouts by now)
        const daysSinceStart = Math.ceil((now.getTime() - enrollment.startedAt.getTime()) / (1000 * 60 * 60 * 24));
        const expectedWorkouts = Math.floor((daysSinceStart / 7) * program.daysPerWeek);
        const onTrack = enrollment.workoutsCompleted >= expectedWorkouts * 0.8; // 80% threshold
        // Find next workout
        const nextWorkout = program.schedule.find((day) => day.day === enrollment.currentDay);
        return {
            weekProgress,
            totalProgress,
            daysRemaining,
            onTrack,
            nextWorkout: nextWorkout ? {
                day: nextWorkout.day,
                name: nextWorkout.name,
                exercises: nextWorkout.exercises,
            } : undefined,
        };
    },
    /**
     * Reset streak (called when user misses a workout)
     */
    async resetStreak(userId, programId) {
        await (0, client_1.query)(`UPDATE program_enrollments SET streak_current = 0, updated_at = NOW()
       WHERE user_id = $1 AND program_id = $2 AND status = 'active'`, [userId, programId]);
    },
    /**
     * Update progress data (for tracking weights, etc.)
     */
    async updateProgressData(enrollmentId, userId, exerciseId, data) {
        const enrollment = await this.getById(enrollmentId, userId);
        const newProgressData = {
            ...enrollment.progressData,
            [exerciseId]: {
                ...(enrollment.progressData[exerciseId] || {}),
                ...data,
                lastUpdated: new Date().toISOString(),
            },
        };
        const result = await (0, client_1.queryOne)(`UPDATE program_enrollments SET
         progress_data = $3,
         updated_at = NOW()
       WHERE id = $1 AND user_id = $2
       RETURNING *`, [enrollmentId, userId, JSON.stringify(newProgressData)]);
        return mapEnrollment(result);
    },
};
exports.default = exports.EnrollmentService;
//# sourceMappingURL=enrollment.service.js.map