/**
 * Sleep Hygiene Service
 *
 * Handles sleep hygiene preferences, tips, assessments, streaks,
 * and credit rewards for good sleep habits.
 */
import type { SleepHygienePreferences, UpdateSleepHygienePreferencesInput, SleepHygieneTip, SleepHygieneTipWithInteraction, SleepHygieneAssessment, CreateSleepHygieneAssessmentInput, UpdateSleepHygieneAssessmentInput, SleepHygieneStreak, SleepStreakType, SleepCreditAward, SleepCreditAwardType, SleepHygieneDashboard, SleepHygieneTipCategory } from './types';
/**
 * Get or create sleep hygiene preferences for a user
 */
export declare function getOrCreatePreferences(userId: string): Promise<SleepHygienePreferences>;
/**
 * Update sleep hygiene preferences
 */
export declare function updatePreferences(userId: string, input: UpdateSleepHygienePreferencesInput): Promise<SleepHygienePreferences>;
/**
 * Enable sleep hygiene for a user
 */
export declare function enableSleepHygiene(userId: string): Promise<SleepHygienePreferences>;
/**
 * Disable sleep hygiene for a user
 */
export declare function disableSleepHygiene(userId: string): Promise<SleepHygienePreferences>;
/**
 * Get all active sleep hygiene tips
 */
export declare function getAllTips(): Promise<SleepHygieneTip[]>;
/**
 * Get tips by category
 */
export declare function getTipsByCategory(category: SleepHygieneTipCategory): Promise<SleepHygieneTip[]>;
/**
 * Get tips with user interaction state
 */
export declare function getTipsForUser(userId: string, options?: {
    category?: SleepHygieneTipCategory;
    limit?: number;
}): Promise<SleepHygieneTipWithInteraction[]>;
/**
 * Get bookmarked tips for user
 */
export declare function getBookmarkedTips(userId: string): Promise<SleepHygieneTipWithInteraction[]>;
/**
 * Bookmark a tip
 */
export declare function bookmarkTip(userId: string, tipId: string): Promise<void>;
/**
 * Unbookmark a tip
 */
export declare function unbookmarkTip(userId: string, tipId: string): Promise<void>;
/**
 * Mark tip as following (user is actively trying this tip)
 */
export declare function followTip(userId: string, tipId: string): Promise<void>;
/**
 * Stop following a tip
 */
export declare function unfollowTip(userId: string, tipId: string): Promise<void>;
/**
 * Mark tip as helpful
 */
export declare function markTipHelpful(userId: string, tipId: string, helpful: boolean): Promise<void>;
/**
 * Dismiss a tip
 */
export declare function dismissTip(userId: string, tipId: string): Promise<void>;
/**
 * Get today's assessment for user
 */
export declare function getTodayAssessment(userId: string): Promise<SleepHygieneAssessment | null>;
/**
 * Get assessment by date
 */
export declare function getAssessmentByDate(userId: string, date: string): Promise<SleepHygieneAssessment | null>;
/**
 * Get assessment history
 */
export declare function getAssessmentHistory(userId: string, limit?: number): Promise<SleepHygieneAssessment[]>;
/**
 * Create or update sleep hygiene assessment
 */
export declare function upsertAssessment(userId: string, input: CreateSleepHygieneAssessmentInput): Promise<{
    assessment: SleepHygieneAssessment;
    creditsAwarded: number;
}>;
/**
 * Update an existing assessment
 */
export declare function updateAssessment(userId: string, date: string, input: UpdateSleepHygieneAssessmentInput): Promise<SleepHygieneAssessment | null>;
/**
 * Get all streaks for user
 */
export declare function getStreaks(userId: string): Promise<SleepHygieneStreak[]>;
/**
 * Get a specific streak
 */
export declare function getStreak(userId: string, streakType: SleepStreakType): Promise<SleepHygieneStreak | null>;
/**
 * Update streaks based on sleep activity
 * Called after logging sleep or completing assessment
 */
export declare function updateSleepStreaks(userId: string, activityDate: string, context: {
    hasChecklist?: boolean;
    isPerfect?: boolean;
    avoidedScreens?: boolean;
    sleepQuality?: number;
    metDurationTarget?: boolean;
    wasConsistentBedtime?: boolean;
}): Promise<void>;
/**
 * Award credits for sleep-related activities
 */
export declare function awardSleepCredits(userId: string, awardType: SleepCreditAwardType, context?: {
    awardDate?: string;
    sleepLogId?: string;
    assessmentId?: string;
    streakId?: string;
    metadata?: Record<string, unknown>;
}): Promise<number>;
/**
 * Award credits when sleep is logged (called from sleep.service)
 */
export declare function awardSleepLogCredits(userId: string, sleepLogId: string, context: {
    quality: number;
    durationMinutes: number;
    targetMinutes: number;
    wasConsistentBedtime: boolean;
}): Promise<number>;
/**
 * Get credit awards for user
 */
export declare function getCreditAwards(userId: string, options?: {
    limit?: number;
    startDate?: string;
    endDate?: string;
}): Promise<SleepCreditAward[]>;
/**
 * Get total credits earned from sleep hygiene
 */
export declare function getTotalCreditsEarned(userId: string): Promise<number>;
/**
 * Get credits earned today
 */
export declare function getTodayCreditsEarned(userId: string): Promise<number>;
/**
 * Get comprehensive sleep hygiene dashboard
 */
export declare function getDashboard(userId: string): Promise<SleepHygieneDashboard>;
