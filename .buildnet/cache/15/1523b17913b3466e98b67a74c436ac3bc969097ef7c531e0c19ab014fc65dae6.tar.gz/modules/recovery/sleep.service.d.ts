/**
 * Sleep Service
 *
 * Handles sleep log CRUD operations and sleep statistics.
 */
import type { SleepLog, CreateSleepLogInput, UpdateSleepLogInput, SleepGoal, CreateSleepGoalInput, UpdateSleepGoalInput, SleepStats, WeeklySleepStats } from './types';
/**
 * Log a sleep session
 */
export declare function logSleep(userId: string, input: CreateSleepLogInput): Promise<SleepLog>;
/**
 * Get a single sleep log
 */
export declare function getSleepLog(userId: string, sleepId: string): Promise<SleepLog | null>;
/**
 * Get user's sleep history with keyset pagination
 */
export declare function getSleepHistory(userId: string, options?: {
    limit?: number;
    cursor?: {
        bedTime: string;
        id: string;
    };
    startDate?: string;
    endDate?: string;
}): Promise<{
    logs: SleepLog[];
    nextCursor: {
        bedTime: string;
        id: string;
    } | null;
}>;
/**
 * Update a sleep log
 */
export declare function updateSleepLog(userId: string, sleepId: string, input: UpdateSleepLogInput): Promise<SleepLog | null>;
/**
 * Delete a sleep log
 */
export declare function deleteSleepLog(userId: string, sleepId: string): Promise<boolean>;
/**
 * Get last night's sleep (most recent)
 */
export declare function getLastSleep(userId: string): Promise<SleepLog | null>;
/**
 * Get sleep statistics for a user
 */
export declare function getSleepStats(userId: string, period?: 'week' | 'month' | 'all'): Promise<SleepStats>;
/**
 * Get weekly sleep stats for trend analysis
 */
export declare function getWeeklySleepStats(userId: string, weeks?: number): Promise<WeeklySleepStats[]>;
/**
 * Get active sleep goal
 */
export declare function getActiveSleepGoal(userId: string): Promise<SleepGoal | null>;
/**
 * Create or update sleep goal
 */
export declare function upsertSleepGoal(userId: string, input: CreateSleepGoalInput): Promise<SleepGoal>;
/**
 * Update sleep goal
 */
export declare function updateSleepGoal(userId: string, goalId: string, input: UpdateSleepGoalInput): Promise<SleepGoal | null>;
/**
 * Delete sleep goal
 */
export declare function deleteSleepGoal(userId: string, goalId: string): Promise<boolean>;
