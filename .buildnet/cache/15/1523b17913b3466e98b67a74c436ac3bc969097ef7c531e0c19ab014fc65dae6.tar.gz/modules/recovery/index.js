"use strict";
/**
 * Recovery Module
 *
 * Sleep tracking and recovery scoring system.
 * Integrates with the workout prescription system to recommend
 * workout intensity based on user's recovery state.
 *
 * Also includes Sleep Hygiene features:
 * - Sleep hygiene preferences
 * - Sleep hygiene tips library
 * - Sleep hygiene assessments
 * - Sleep streaks with credit rewards
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports, p)) __createBinding(exports, m, p);
};
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.getSleepHygieneDashboard = exports.getSleepHygieneTodayCreditsEarned = exports.getSleepHygieneTotalCreditsEarned = exports.getSleepHygieneCreditAwards = exports.awardSleepLogCredits = exports.awardSleepCredits = exports.getSleepHygieneStreaks = exports.updateSleepHygieneAssessment = exports.upsertSleepHygieneAssessment = exports.getSleepHygieneAssessmentHistory = exports.getSleepHygieneTodayAssessment = exports.unfollowSleepHygieneTip = exports.followSleepHygieneTip = exports.unbookmarkSleepHygieneTip = exports.bookmarkSleepHygieneTip = exports.getSleepHygieneBookmarkedTips = exports.getSleepHygieneTipsForUser = exports.getAllSleepHygieneTips = exports.disableSleepHygiene = exports.enableSleepHygiene = exports.updateSleepHygienePreferences = exports.getSleepHygienePreferences = exports.getRecoveryHistory = exports.getRecoveryStatus = exports.acknowledgeRecommendation = exports.getActiveRecommendations = exports.generateRecommendations = exports.calculateRecoveryScore = exports.getRecoveryScore = exports.deleteSleepGoal = exports.updateSleepGoal = exports.upsertSleepGoal = exports.getActiveSleepGoal = exports.getWeeklySleepStats = exports.getSleepStats = exports.getLastSleep = exports.deleteSleepLog = exports.updateSleepLog = exports.getSleepHistory = exports.getSleepLog = exports.logSleep = exports.sleepHygieneService = exports.recoveryService = exports.sleepService = void 0;
__exportStar(require("./types"), exports);
exports.sleepService = __importStar(require("./sleep.service"));
exports.recoveryService = __importStar(require("./recovery.service"));
exports.sleepHygieneService = __importStar(require("./sleep-hygiene.service"));
// Re-export commonly used functions for convenience
var sleep_service_1 = require("./sleep.service");
Object.defineProperty(exports, "logSleep", { enumerable: true, get: function () { return sleep_service_1.logSleep; } });
Object.defineProperty(exports, "getSleepLog", { enumerable: true, get: function () { return sleep_service_1.getSleepLog; } });
Object.defineProperty(exports, "getSleepHistory", { enumerable: true, get: function () { return sleep_service_1.getSleepHistory; } });
Object.defineProperty(exports, "updateSleepLog", { enumerable: true, get: function () { return sleep_service_1.updateSleepLog; } });
Object.defineProperty(exports, "deleteSleepLog", { enumerable: true, get: function () { return sleep_service_1.deleteSleepLog; } });
Object.defineProperty(exports, "getLastSleep", { enumerable: true, get: function () { return sleep_service_1.getLastSleep; } });
Object.defineProperty(exports, "getSleepStats", { enumerable: true, get: function () { return sleep_service_1.getSleepStats; } });
Object.defineProperty(exports, "getWeeklySleepStats", { enumerable: true, get: function () { return sleep_service_1.getWeeklySleepStats; } });
Object.defineProperty(exports, "getActiveSleepGoal", { enumerable: true, get: function () { return sleep_service_1.getActiveSleepGoal; } });
Object.defineProperty(exports, "upsertSleepGoal", { enumerable: true, get: function () { return sleep_service_1.upsertSleepGoal; } });
Object.defineProperty(exports, "updateSleepGoal", { enumerable: true, get: function () { return sleep_service_1.updateSleepGoal; } });
Object.defineProperty(exports, "deleteSleepGoal", { enumerable: true, get: function () { return sleep_service_1.deleteSleepGoal; } });
var recovery_service_1 = require("./recovery.service");
Object.defineProperty(exports, "getRecoveryScore", { enumerable: true, get: function () { return recovery_service_1.getRecoveryScore; } });
Object.defineProperty(exports, "calculateRecoveryScore", { enumerable: true, get: function () { return recovery_service_1.calculateRecoveryScore; } });
Object.defineProperty(exports, "generateRecommendations", { enumerable: true, get: function () { return recovery_service_1.generateRecommendations; } });
Object.defineProperty(exports, "getActiveRecommendations", { enumerable: true, get: function () { return recovery_service_1.getActiveRecommendations; } });
Object.defineProperty(exports, "acknowledgeRecommendation", { enumerable: true, get: function () { return recovery_service_1.acknowledgeRecommendation; } });
Object.defineProperty(exports, "getRecoveryStatus", { enumerable: true, get: function () { return recovery_service_1.getRecoveryStatus; } });
Object.defineProperty(exports, "getRecoveryHistory", { enumerable: true, get: function () { return recovery_service_1.getRecoveryHistory; } });
// Sleep Hygiene exports
var sleep_hygiene_service_1 = require("./sleep-hygiene.service");
Object.defineProperty(exports, "getSleepHygienePreferences", { enumerable: true, get: function () { return sleep_hygiene_service_1.getOrCreatePreferences; } });
Object.defineProperty(exports, "updateSleepHygienePreferences", { enumerable: true, get: function () { return sleep_hygiene_service_1.updatePreferences; } });
Object.defineProperty(exports, "enableSleepHygiene", { enumerable: true, get: function () { return sleep_hygiene_service_1.enableSleepHygiene; } });
Object.defineProperty(exports, "disableSleepHygiene", { enumerable: true, get: function () { return sleep_hygiene_service_1.disableSleepHygiene; } });
Object.defineProperty(exports, "getAllSleepHygieneTips", { enumerable: true, get: function () { return sleep_hygiene_service_1.getAllTips; } });
Object.defineProperty(exports, "getSleepHygieneTipsForUser", { enumerable: true, get: function () { return sleep_hygiene_service_1.getTipsForUser; } });
Object.defineProperty(exports, "getSleepHygieneBookmarkedTips", { enumerable: true, get: function () { return sleep_hygiene_service_1.getBookmarkedTips; } });
Object.defineProperty(exports, "bookmarkSleepHygieneTip", { enumerable: true, get: function () { return sleep_hygiene_service_1.bookmarkTip; } });
Object.defineProperty(exports, "unbookmarkSleepHygieneTip", { enumerable: true, get: function () { return sleep_hygiene_service_1.unbookmarkTip; } });
Object.defineProperty(exports, "followSleepHygieneTip", { enumerable: true, get: function () { return sleep_hygiene_service_1.followTip; } });
Object.defineProperty(exports, "unfollowSleepHygieneTip", { enumerable: true, get: function () { return sleep_hygiene_service_1.unfollowTip; } });
Object.defineProperty(exports, "getSleepHygieneTodayAssessment", { enumerable: true, get: function () { return sleep_hygiene_service_1.getTodayAssessment; } });
Object.defineProperty(exports, "getSleepHygieneAssessmentHistory", { enumerable: true, get: function () { return sleep_hygiene_service_1.getAssessmentHistory; } });
Object.defineProperty(exports, "upsertSleepHygieneAssessment", { enumerable: true, get: function () { return sleep_hygiene_service_1.upsertAssessment; } });
Object.defineProperty(exports, "updateSleepHygieneAssessment", { enumerable: true, get: function () { return sleep_hygiene_service_1.updateAssessment; } });
Object.defineProperty(exports, "getSleepHygieneStreaks", { enumerable: true, get: function () { return sleep_hygiene_service_1.getStreaks; } });
Object.defineProperty(exports, "awardSleepCredits", { enumerable: true, get: function () { return sleep_hygiene_service_1.awardSleepCredits; } });
Object.defineProperty(exports, "awardSleepLogCredits", { enumerable: true, get: function () { return sleep_hygiene_service_1.awardSleepLogCredits; } });
Object.defineProperty(exports, "getSleepHygieneCreditAwards", { enumerable: true, get: function () { return sleep_hygiene_service_1.getCreditAwards; } });
Object.defineProperty(exports, "getSleepHygieneTotalCreditsEarned", { enumerable: true, get: function () { return sleep_hygiene_service_1.getTotalCreditsEarned; } });
Object.defineProperty(exports, "getSleepHygieneTodayCreditsEarned", { enumerable: true, get: function () { return sleep_hygiene_service_1.getTodayCreditsEarned; } });
Object.defineProperty(exports, "getSleepHygieneDashboard", { enumerable: true, get: function () { return sleep_hygiene_service_1.getDashboard; } });
//# sourceMappingURL=index.js.map