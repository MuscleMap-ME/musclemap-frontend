"use strict";
/**
 * Sleep Service
 *
 * Handles sleep log CRUD operations and sleep statistics.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.logSleep = logSleep;
exports.getSleepLog = getSleepLog;
exports.getSleepHistory = getSleepHistory;
exports.updateSleepLog = updateSleepLog;
exports.deleteSleepLog = deleteSleepLog;
exports.getLastSleep = getLastSleep;
exports.getSleepStats = getSleepStats;
exports.getWeeklySleepStats = getWeeklySleepStats;
exports.getActiveSleepGoal = getActiveSleepGoal;
exports.upsertSleepGoal = upsertSleepGoal;
exports.updateSleepGoal = updateSleepGoal;
exports.deleteSleepGoal = deleteSleepGoal;
const client_1 = require("../../db/client");
const logger_1 = require("../../lib/logger");
const log = logger_1.loggers.api;
// ============================================
// SLEEP LOG OPERATIONS
// ============================================
/**
 * Log a sleep session
 */
async function logSleep(userId, input) {
    const id = `sl_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
    const now = new Date().toISOString();
    // Validate sleep times
    const bedTime = new Date(input.bedTime);
    const wakeTime = new Date(input.wakeTime);
    if (wakeTime <= bedTime) {
        throw new Error('Wake time must be after bed time');
    }
    const durationMinutes = Math.round((wakeTime.getTime() - bedTime.getTime()) / (1000 * 60));
    // Validate duration (4-16 hours)
    if (durationMinutes < 240 || durationMinutes > 960) {
        throw new Error('Sleep duration must be between 4 and 16 hours');
    }
    await (0, client_1.execute)(`INSERT INTO sleep_logs (
      id, user_id, bed_time, wake_time, quality, sleep_environment,
      time_to_fall_asleep_minutes, wake_count, notes, source, external_id, logged_at
    ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12)
    ON CONFLICT (user_id, bed_time) DO UPDATE SET
      wake_time = EXCLUDED.wake_time,
      quality = EXCLUDED.quality,
      sleep_environment = EXCLUDED.sleep_environment,
      time_to_fall_asleep_minutes = EXCLUDED.time_to_fall_asleep_minutes,
      wake_count = EXCLUDED.wake_count,
      notes = EXCLUDED.notes,
      updated_at = NOW()`, [
        id,
        userId,
        input.bedTime,
        input.wakeTime,
        input.quality,
        JSON.stringify(input.sleepEnvironment || {}),
        input.timeToFallAsleepMinutes || null,
        input.wakeCount || 0,
        input.notes || null,
        input.source || 'manual',
        input.externalId || null,
        input.loggedAt || now,
    ]);
    log.info({ userId, sleepId: id, durationMinutes, quality: input.quality }, 'Sleep logged');
    const sleepLog = await getSleepLog(userId, id);
    if (!sleepLog) {
        throw new Error('Failed to create sleep log');
    }
    return sleepLog;
}
/**
 * Get a single sleep log
 */
async function getSleepLog(userId, sleepId) {
    const row = await (0, client_1.queryOne)(`SELECT * FROM sleep_logs WHERE id = $1 AND user_id = $2`, [sleepId, userId]);
    if (!row)
        return null;
    return mapRowToSleepLog(row);
}
/**
 * Get user's sleep history with keyset pagination
 */
async function getSleepHistory(userId, options = {}) {
    const limit = Math.min(options.limit || 30, 100);
    let sql;
    let params;
    if (options.cursor) {
        sql = `
      SELECT * FROM sleep_logs
      WHERE user_id = $1
        AND (bed_time, id) < ($2, $3)
        ${options.startDate ? 'AND bed_time >= $4' : ''}
        ${options.endDate ? `AND bed_time <= $${options.startDate ? 5 : 4}` : ''}
      ORDER BY bed_time DESC, id DESC
      LIMIT $${options.startDate && options.endDate ? 6 : options.startDate || options.endDate ? 5 : 4}
    `;
        params = [userId, options.cursor.bedTime, options.cursor.id];
        if (options.startDate)
            params.push(options.startDate);
        if (options.endDate)
            params.push(options.endDate);
        params.push(limit);
    }
    else {
        sql = `
      SELECT * FROM sleep_logs
      WHERE user_id = $1
        ${options.startDate ? 'AND bed_time >= $2' : ''}
        ${options.endDate ? `AND bed_time <= $${options.startDate ? 3 : 2}` : ''}
      ORDER BY bed_time DESC, id DESC
      LIMIT $${options.startDate && options.endDate ? 4 : options.startDate || options.endDate ? 3 : 2}
    `;
        params = [userId];
        if (options.startDate)
            params.push(options.startDate);
        if (options.endDate)
            params.push(options.endDate);
        params.push(limit);
    }
    const rows = await (0, client_1.queryAll)(sql, params);
    const logs = rows.map(mapRowToSleepLog);
    const lastLog = logs[logs.length - 1];
    const nextCursor = logs.length === limit && lastLog
        ? { bedTime: lastLog.bedTime, id: lastLog.id }
        : null;
    return { logs, nextCursor };
}
/**
 * Update a sleep log
 */
async function updateSleepLog(userId, sleepId, input) {
    const updates = [];
    const values = [];
    let paramIndex = 1;
    if (input.quality !== undefined) {
        updates.push(`quality = $${paramIndex++}`);
        values.push(input.quality);
    }
    if (input.sleepEnvironment !== undefined) {
        updates.push(`sleep_environment = $${paramIndex++}`);
        values.push(JSON.stringify(input.sleepEnvironment));
    }
    if (input.timeToFallAsleepMinutes !== undefined) {
        updates.push(`time_to_fall_asleep_minutes = $${paramIndex++}`);
        values.push(input.timeToFallAsleepMinutes);
    }
    if (input.wakeCount !== undefined) {
        updates.push(`wake_count = $${paramIndex++}`);
        values.push(input.wakeCount);
    }
    if (input.notes !== undefined) {
        updates.push(`notes = $${paramIndex++}`);
        values.push(input.notes);
    }
    if (updates.length === 0) {
        return getSleepLog(userId, sleepId);
    }
    updates.push(`updated_at = NOW()`);
    values.push(sleepId, userId);
    await (0, client_1.execute)(`UPDATE sleep_logs SET ${updates.join(', ')} WHERE id = $${paramIndex} AND user_id = $${paramIndex + 1}`, values);
    return getSleepLog(userId, sleepId);
}
/**
 * Delete a sleep log
 */
async function deleteSleepLog(userId, sleepId) {
    const rowCount = await (0, client_1.execute)(`DELETE FROM sleep_logs WHERE id = $1 AND user_id = $2`, [sleepId, userId]);
    return rowCount > 0;
}
/**
 * Get last night's sleep (most recent)
 */
async function getLastSleep(userId) {
    const row = await (0, client_1.queryOne)(`SELECT * FROM sleep_logs WHERE user_id = $1 ORDER BY bed_time DESC LIMIT 1`, [userId]);
    if (!row)
        return null;
    return mapRowToSleepLog(row);
}
// ============================================
// SLEEP STATISTICS
// ============================================
/**
 * Get sleep statistics for a user
 */
async function getSleepStats(userId, period = 'week') {
    // Map period to days - using parameterized queries for safety
    const daysMap = {
        week: 7,
        month: 30,
        all: 365, // Cap at 1 year for performance
    };
    const days = daysMap[period] || 7;
    // Get aggregate stats
    const stats = await (0, client_1.queryOne)(`SELECT
      COUNT(*) as nights_logged,
      ROUND(AVG(sleep_duration_minutes)::numeric, 1) as avg_duration,
      ROUND(AVG(quality)::numeric, 2) as avg_quality,
      MIN(sleep_duration_minutes) as min_duration,
      MAX(sleep_duration_minutes) as max_duration,
      ROUND(STDDEV(sleep_duration_minutes)::numeric, 1) as stddev_duration
    FROM sleep_logs
    WHERE user_id = $1 AND bed_time >= NOW() - INTERVAL '1 day' * $2`, [userId, days]);
    // Get quality distribution
    const qualityDist = await (0, client_1.queryAll)(`SELECT quality, COUNT(*) as count
     FROM sleep_logs
     WHERE user_id = $1 AND bed_time >= NOW() - INTERVAL '1 day' * $2
     GROUP BY quality`, [userId, days]);
    const qualityMap = {};
    for (const row of qualityDist) {
        qualityMap[row.quality] = parseInt(row.count);
    }
    // Get user's sleep goal for target comparison
    const goal = await getActiveSleepGoal(userId);
    const targetMinutes = (goal?.targetHours || 8) * 60;
    // Count nights meeting target
    const targetMet = await (0, client_1.queryOne)(`SELECT COUNT(*) as count
     FROM sleep_logs
     WHERE user_id = $1
       AND bed_time >= NOW() - INTERVAL '1 day' * $2
       AND sleep_duration_minutes >= $3`, [userId, days, targetMinutes * 0.9] // Within 90% of target
    );
    const nightsLogged = parseInt(stats?.nights_logged || '0');
    const avgDuration = parseFloat(stats?.avg_duration || '0');
    const stddev = parseFloat(stats?.stddev_duration || '0');
    // Calculate consistency (inverse of coefficient of variation)
    const consistency = avgDuration > 0 && nightsLogged >= 3
        ? Math.max(0, Math.min(100, 100 - (stddev / avgDuration * 100)))
        : 0;
    return {
        period,
        nightsLogged,
        avgDurationMinutes: avgDuration,
        avgDurationHours: Math.round((avgDuration / 60) * 10) / 10,
        avgQuality: parseFloat(stats?.avg_quality || '0'),
        minDurationMinutes: parseInt(stats?.min_duration || '0'),
        maxDurationMinutes: parseInt(stats?.max_duration || '0'),
        consistency: Math.round(consistency),
        targetMet: parseInt(targetMet?.count || '0'),
        qualityDistribution: {
            terrible: qualityMap[1] || 0,
            poor: qualityMap[2] || 0,
            fair: qualityMap[3] || 0,
            good: qualityMap[4] || 0,
            excellent: qualityMap[5] || 0,
        },
    };
}
/**
 * Get weekly sleep stats for trend analysis
 */
async function getWeeklySleepStats(userId, weeks = 8) {
    const rows = await (0, client_1.queryAll)(`SELECT * FROM mv_sleep_stats
     WHERE user_id = $1
     ORDER BY week_start DESC
     LIMIT $2`, [userId, weeks]);
    return rows.map(row => ({
        weekStart: row.week_start,
        nightsLogged: parseInt(row.nights_logged),
        avgDurationMinutes: parseFloat(row.avg_duration_minutes),
        avgQuality: parseFloat(row.avg_quality),
        minDurationMinutes: parseInt(row.min_duration_minutes),
        maxDurationMinutes: parseInt(row.max_duration_minutes),
        stddevDuration: parseFloat(row.stddev_duration || '0'),
    }));
}
// ============================================
// SLEEP GOAL OPERATIONS
// ============================================
/**
 * Get active sleep goal
 */
async function getActiveSleepGoal(userId) {
    const row = await (0, client_1.queryOne)(`SELECT * FROM sleep_goals WHERE user_id = $1 AND is_active = TRUE`, [userId]);
    if (!row)
        return null;
    return {
        id: row.id,
        userId: row.user_id,
        targetHours: parseFloat(row.target_hours),
        targetBedTime: row.target_bed_time || undefined,
        targetWakeTime: row.target_wake_time || undefined,
        targetQuality: row.target_quality || undefined,
        consistencyTarget: row.consistency_target,
        isActive: row.is_active,
        createdAt: row.created_at,
        updatedAt: row.updated_at,
    };
}
/**
 * Create or update sleep goal
 */
async function upsertSleepGoal(userId, input) {
    const id = `sg_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
    // Deactivate existing goals first
    await (0, client_1.execute)(`UPDATE sleep_goals SET is_active = FALSE, updated_at = NOW() WHERE user_id = $1 AND is_active = TRUE`, [userId]);
    // Create new goal
    await (0, client_1.execute)(`INSERT INTO sleep_goals (
      id, user_id, target_hours, target_bed_time, target_wake_time,
      target_quality, consistency_target, is_active
    ) VALUES ($1, $2, $3, $4, $5, $6, $7, TRUE)`, [
        id,
        userId,
        input.targetHours,
        input.targetBedTime || null,
        input.targetWakeTime || null,
        input.targetQuality || null,
        input.consistencyTarget || 5,
    ]);
    log.info({ userId, goalId: id, targetHours: input.targetHours }, 'Sleep goal created');
    const goal = await getActiveSleepGoal(userId);
    if (!goal) {
        throw new Error('Failed to create sleep goal');
    }
    return goal;
}
/**
 * Update sleep goal
 */
async function updateSleepGoal(userId, goalId, input) {
    const updates = [];
    const values = [];
    let paramIndex = 1;
    if (input.targetHours !== undefined) {
        updates.push(`target_hours = $${paramIndex++}`);
        values.push(input.targetHours);
    }
    if (input.targetBedTime !== undefined) {
        updates.push(`target_bed_time = $${paramIndex++}`);
        values.push(input.targetBedTime);
    }
    if (input.targetWakeTime !== undefined) {
        updates.push(`target_wake_time = $${paramIndex++}`);
        values.push(input.targetWakeTime);
    }
    if (input.targetQuality !== undefined) {
        updates.push(`target_quality = $${paramIndex++}`);
        values.push(input.targetQuality);
    }
    if (input.consistencyTarget !== undefined) {
        updates.push(`consistency_target = $${paramIndex++}`);
        values.push(input.consistencyTarget);
    }
    if (updates.length === 0) {
        return getActiveSleepGoal(userId);
    }
    updates.push(`updated_at = NOW()`);
    values.push(goalId, userId);
    await (0, client_1.execute)(`UPDATE sleep_goals SET ${updates.join(', ')} WHERE id = $${paramIndex} AND user_id = $${paramIndex + 1}`, values);
    return getActiveSleepGoal(userId);
}
/**
 * Delete sleep goal
 */
async function deleteSleepGoal(userId, goalId) {
    const rowCount = await (0, client_1.execute)(`DELETE FROM sleep_goals WHERE id = $1 AND user_id = $2`, [goalId, userId]);
    return rowCount > 0;
}
// ============================================
// HELPER FUNCTIONS
// ============================================
function mapRowToSleepLog(row) {
    let sleepEnvironment = {};
    if (row.sleep_environment) {
        try {
            sleepEnvironment = typeof row.sleep_environment === 'string'
                ? JSON.parse(row.sleep_environment)
                : row.sleep_environment;
        }
        catch {
            sleepEnvironment = {};
        }
    }
    return {
        id: row.id,
        userId: row.user_id,
        bedTime: row.bed_time,
        wakeTime: row.wake_time,
        sleepDurationMinutes: row.sleep_duration_minutes,
        quality: row.quality,
        sleepEnvironment: Object.keys(sleepEnvironment).length > 0 ? sleepEnvironment : undefined,
        timeToFallAsleepMinutes: row.time_to_fall_asleep_minutes || undefined,
        wakeCount: row.wake_count || undefined,
        notes: row.notes || undefined,
        source: row.source,
        externalId: row.external_id || undefined,
        loggedAt: row.logged_at,
        createdAt: row.created_at,
        updatedAt: row.updated_at,
    };
}
//# sourceMappingURL=sleep.service.js.map