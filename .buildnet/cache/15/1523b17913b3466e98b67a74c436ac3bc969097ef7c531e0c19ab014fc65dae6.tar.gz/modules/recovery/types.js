"use strict";
/**
 * Recovery Module Types
 *
 * Type definitions for sleep tracking and recovery scoring.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.SLEEP_CREDIT_AMOUNTS = void 0;
// Credit amounts for sleep hygiene rewards
exports.SLEEP_CREDIT_AMOUNTS = {
    daily_log: 5,
    target_met: 10,
    good_quality: 5,
    excellent_quality: 10,
    hygiene_checklist: 5,
    perfect_hygiene: 15,
    streak_milestone_7: 25,
    streak_milestone_14: 50,
    streak_milestone_30: 100,
    streak_milestone_60: 200,
    streak_milestone_90: 350,
    weekly_consistency: 20,
};
//# sourceMappingURL=types.js.map