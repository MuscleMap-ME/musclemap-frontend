/**
 * Recovery Service
 *
 * Calculates recovery scores based on:
 * - Sleep duration: 0-40 points (8 hours = max)
 * - Sleep quality: 0-30 points
 * - Rest days since last workout: 0-20 points
 * - Optional HRV bonus: 0-10 points
 *
 * The recovery score influences workout prescription intensity.
 */
import type { RecoveryScore, RecoveryRecommendation, RecoveryStatus, RecoveryHistory } from './types';
/**
 * Calculate or retrieve the user's recovery score
 */
export declare function getRecoveryScore(userId: string, options?: {
    forceRecalculate?: boolean;
}): Promise<RecoveryScore | null>;
/**
 * Calculate a new recovery score for the user
 */
export declare function calculateRecoveryScore(userId: string): Promise<RecoveryScore>;
/**
 * Generate recovery recommendations based on score
 */
export declare function generateRecommendations(userId: string): Promise<RecoveryRecommendation[]>;
/**
 * Get active recommendations for user
 */
export declare function getActiveRecommendations(userId: string): Promise<RecoveryRecommendation[]>;
/**
 * Acknowledge a recommendation
 */
export declare function acknowledgeRecommendation(userId: string, recommendationId: string, followed?: boolean, feedback?: string): Promise<void>;
/**
 * Get comprehensive recovery status
 */
export declare function getRecoveryStatus(userId: string): Promise<RecoveryStatus>;
/**
 * Get recovery history for trend analysis
 */
export declare function getRecoveryHistory(userId: string, days?: number): Promise<RecoveryHistory>;
