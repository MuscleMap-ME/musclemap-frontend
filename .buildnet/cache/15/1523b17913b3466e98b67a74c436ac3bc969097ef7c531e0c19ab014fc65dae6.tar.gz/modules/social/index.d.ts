/**
 * Social Graph Service
 *
 * Handles social connections between users:
 * - Follows (one-way)
 * - Friendships (mutual)
 * - Buddy matching (workout partners)
 */
export interface Follow {
    id: string;
    followerId: string;
    followingId: string;
    createdAt: Date;
}
export interface FollowWithUser extends Follow {
    username: string;
    displayName?: string;
    avatarUrl?: string;
}
export interface Friendship {
    id: string;
    userAId: string;
    userBId: string;
    status: 'pending' | 'accepted' | 'declined' | 'blocked';
    initiatedBy: string;
    metAtHangoutId?: number;
    metAtCommunityId?: number;
    createdAt: Date;
    acceptedAt?: Date;
}
export interface FriendWithUser extends Friendship {
    friendId: string;
    username: string;
    displayName?: string;
    avatarUrl?: string;
}
export interface BuddyPreferences {
    userId: string;
    seekingBuddy: boolean;
    preferredGoals: string[];
    preferredArchetypes: string[];
    preferredExperienceLevels: string[];
    preferredSchedule: string[];
    preferredWorkoutTypes: string[];
    maxDistanceKm: number;
    preferSameHangout: boolean;
    preferSameCommunity: boolean;
    matchGender: boolean;
    matchAgeRange: boolean;
    minAge?: number;
    maxAge?: number;
    buddyBio?: string;
    visibleInBuddySearch: boolean;
}
export interface BuddyRequest {
    id: string;
    senderId: string;
    receiverId: string;
    status: 'pending' | 'accepted' | 'declined' | 'expired';
    message?: string;
    matchScore?: number;
    createdAt: Date;
    respondedAt?: Date;
    expiresAt: Date;
}
export interface BuddyMatch {
    userId: string;
    username: string;
    displayName?: string;
    avatarUrl?: string;
    matchScore: number;
    sharedGoals: string[];
    sharedArchetypes: string[];
    distance?: number;
}
export interface BuddyPair {
    id: string;
    userAId: string;
    userBId: string;
    workoutsTogether: number;
    lastWorkoutTogether?: Date;
    streakDays: number;
    status: 'active' | 'paused' | 'ended';
    createdAt: Date;
}
export declare const socialService: {
    /**
     * Follow a user
     */
    follow(followerId: string, followingId: string): Promise<Follow>;
    /**
     * Unfollow a user
     */
    unfollow(followerId: string, followingId: string): Promise<void>;
    /**
     * Check if user follows another
     */
    isFollowing(followerId: string, followingId: string): Promise<boolean>;
    /**
     * Get followers of a user
     */
    getFollowers(userId: string, options?: {
        limit?: number;
        offset?: number;
    }): Promise<{
        followers: FollowWithUser[];
        total: number;
    }>;
    /**
     * Get users that a user follows
     */
    getFollowing(userId: string, options?: {
        limit?: number;
        offset?: number;
    }): Promise<{
        following: FollowWithUser[];
        total: number;
    }>;
    /**
     * Send friend request
     */
    sendFriendRequest(fromUserId: string, toUserId: string, context?: {
        hangoutId?: number;
        communityId?: number;
    }): Promise<Friendship>;
    /**
     * Accept friend request
     */
    acceptFriendRequest(userId: string, friendshipId: string): Promise<void>;
    /**
     * Decline friend request
     */
    declineFriendRequest(userId: string, friendshipId: string): Promise<void>;
    /**
     * Remove friend
     */
    removeFriend(userId: string, friendId: string): Promise<void>;
    /**
     * Block user
     */
    blockUser(userId: string, blockedUserId: string): Promise<void>;
    /**
     * Get pending friend requests
     */
    getPendingFriendRequests(userId: string): Promise<FriendWithUser[]>;
    /**
     * Get friends list
     */
    getFriends(userId: string, options?: {
        limit?: number;
        offset?: number;
    }): Promise<{
        friends: FriendWithUser[];
        total: number;
    }>;
    /**
     * Update buddy preferences
     */
    updateBuddyPreferences(userId: string, prefs: Partial<BuddyPreferences>): Promise<BuddyPreferences>;
    /**
     * Get buddy preferences
     */
    getBuddyPreferences(userId: string): Promise<BuddyPreferences | null>;
    /**
     * Find potential buddy matches
     */
    findBuddyMatches(userId: string, options?: {
        limit?: number;
    }): Promise<BuddyMatch[]>;
    /**
     * Send buddy request
     */
    sendBuddyRequest(senderId: string, receiverId: string, message?: string): Promise<BuddyRequest>;
    /**
     * Accept buddy request
     */
    acceptBuddyRequest(userId: string, requestId: string): Promise<BuddyPair>;
    /**
     * Decline buddy request
     */
    declineBuddyRequest(userId: string, requestId: string): Promise<void>;
    /**
     * Get pending buddy requests
     */
    getPendingBuddyRequests(userId: string): Promise<(BuddyRequest & {
        senderUsername: string;
    })[]>;
    /**
     * Get active buddy pairs
     */
    getBuddyPairs(userId: string): Promise<(BuddyPair & {
        buddyUsername: string;
        buddyAvatarUrl?: string;
    })[]>;
};
export default socialService;
