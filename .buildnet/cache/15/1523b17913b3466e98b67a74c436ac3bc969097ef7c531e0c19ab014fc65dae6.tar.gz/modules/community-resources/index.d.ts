/**
 * Community Resources Service
 *
 * Handles community knowledge base and shared artifacts:
 * - Pinned resources (guides, FAQs, tutorials)
 * - File uploads and links
 * - Helpful vote tracking
 * - Resource categories
 */
export interface CommunityResource {
    id: string;
    communityId: number;
    authorId: string;
    title: string;
    description?: string;
    resourceType: 'guide' | 'faq' | 'link' | 'file' | 'video' | 'program' | 'template';
    content?: string;
    url?: string;
    fileUrl?: string;
    fileType?: string;
    fileSizeBytes?: number;
    category?: string;
    tags: string[];
    isPinned: boolean;
    pinnedAt?: Date;
    pinnedBy?: string;
    helpfulCount: number;
    viewCount: number;
    status: 'draft' | 'published' | 'archived';
    publishedAt?: Date;
    createdAt: Date;
    updatedAt: Date;
}
export interface ResourceWithAuthor extends CommunityResource {
    authorUsername: string;
    authorDisplayName?: string;
    authorAvatarUrl?: string;
    userVoted?: boolean;
}
export interface ResourceCategory {
    category: string;
    resourceCount: number;
}
export interface ResourceSearchOptions {
    communityId: number;
    resourceType?: CommunityResource['resourceType'];
    category?: string;
    tags?: string[];
    isPinned?: boolean;
    searchQuery?: string;
    status?: CommunityResource['status'];
    limit?: number;
    offset?: number;
    sortBy?: 'newest' | 'most_helpful' | 'most_viewed';
}
export declare const communityResourcesService: {
    /**
     * Create a new resource
     */
    createResource(communityId: number, authorId: string, resource: {
        title: string;
        description?: string;
        resourceType: CommunityResource["resourceType"];
        content?: string;
        url?: string;
        fileUrl?: string;
        fileType?: string;
        fileSizeBytes?: number;
        category?: string;
        tags?: string[];
        status?: CommunityResource["status"];
    }): Promise<CommunityResource>;
    /**
     * Get a resource by ID
     */
    getResource(resourceId: string, viewerId?: string): Promise<ResourceWithAuthor | null>;
    /**
     * Update a resource
     */
    updateResource(resourceId: string, authorId: string, updates: Partial<{
        title: string;
        description: string;
        content: string;
        url: string;
        category: string;
        tags: string[];
        status: CommunityResource["status"];
    }>): Promise<void>;
    /**
     * Delete a resource
     */
    deleteResource(resourceId: string, userId: string, isAdmin?: boolean): Promise<void>;
    /**
     * Search/list resources
     */
    searchResources(options: ResourceSearchOptions, viewerId?: string): Promise<{
        resources: ResourceWithAuthor[];
        total: number;
    }>;
    /**
     * Get pinned resources for a community
     */
    getPinnedResources(communityId: number, viewerId?: string): Promise<ResourceWithAuthor[]>;
    /**
     * Get resource categories for a community
     */
    getCategories(communityId: number): Promise<ResourceCategory[]>;
    /**
     * Pin a resource (admin/mod action)
     */
    pinResource(resourceId: string, pinnedBy: string): Promise<void>;
    /**
     * Unpin a resource
     */
    unpinResource(resourceId: string): Promise<void>;
    /**
     * Mark a resource as helpful
     */
    markHelpful(resourceId: string, userId: string): Promise<void>;
    /**
     * Remove helpful vote
     */
    removeHelpful(resourceId: string, userId: string): Promise<void>;
    /**
     * Increment view count
     */
    recordView(resourceId: string): Promise<void>;
    /**
     * Get most helpful resources across communities
     */
    getMostHelpful(options?: {
        limit?: number;
        communityIds?: number[];
    }): Promise<ResourceWithAuthor[]>;
};
export default communityResourcesService;
