/**
 * Character Stats Module
 *
 * D&D-style character stats system with 6 core attributes:
 * - Strength (STR): Heavy compound lifts, high weight
 * - Constitution (CON): Consistency, workout frequency
 * - Dexterity (DEX): Bodyweight exercises, agility
 * - Power (PWR): Explosive exercises (cleans, snatches)
 * - Endurance (END): High-rep sets, cardio, duration
 * - Vitality (VIT): Aggregate of all stats
 */
export declare const STAT_TYPES: {
    readonly STRENGTH: "strength";
    readonly CONSTITUTION: "constitution";
    readonly DEXTERITY: "dexterity";
    readonly POWER: "power";
    readonly ENDURANCE: "endurance";
    readonly VITALITY: "vitality";
};
export type StatType = (typeof STAT_TYPES)[keyof typeof STAT_TYPES];
export interface CharacterStats {
    userId: string;
    strength: number;
    constitution: number;
    dexterity: number;
    power: number;
    endurance: number;
    vitality: number;
    lastCalculatedAt: Date;
    version: number;
}
export interface StatContributions {
    strength: number;
    constitution: number;
    dexterity: number;
    power: number;
    endurance: number;
}
export interface WorkoutExercise {
    exerciseId: string;
    sets: number;
    reps?: number;
    weight?: number;
    duration?: number;
}
export interface UserRanking {
    rank: number;
    total: number;
    percentile: number;
}
export interface RankingsByScope {
    global: UserRanking;
    country?: UserRanking;
    state?: UserRanking;
    city?: UserRanking;
}
export interface ExtendedProfile {
    userId: string;
    gender: string | null;
    city: string | null;
    county: string | null;
    state: string | null;
    country: string | null;
    countryCode: string | null;
    leaderboardOptIn: boolean;
    profileVisibility: string;
}
/**
 * Update character stats after a workout
 */
export declare function updateStatsFromWorkout(userId: string, exercises: WorkoutExercise[]): Promise<CharacterStats>;
/**
 * Get user's current stats (cached)
 */
export declare function getUserStats(userId: string): Promise<CharacterStats>;
/**
 * Get stats history for progress charts
 *
 * PERF-004: Optimized from ~1s to <200ms using:
 * - BRIN index on snapshot_date (efficient for time-series data)
 * - Covering index with INCLUDE clause (avoids heap lookups)
 * - Parameterized date filter (uses index properly)
 * - Caching for repeated queries within short timeframe
 */
export declare function getStatsHistory(userId: string, days?: number): Promise<Array<{
    snapshotDate: string;
    strength: number;
    constitution: number;
    dexterity: number;
    power: number;
    endurance: number;
    vitality: number;
}>>;
/**
 * Create daily snapshot of user's stats
 */
export declare function createDailySnapshot(userId: string): Promise<void>;
/**
 * Get extended profile (gender, location)
 */
export declare function getExtendedProfile(userId: string): Promise<ExtendedProfile>;
/**
 * Update extended profile
 */
export declare function updateExtendedProfile(userId: string, updates: Partial<{
    gender: string;
    city: string;
    county: string;
    state: string;
    country: string;
    countryCode: string;
    leaderboardOptIn: boolean;
    profileVisibility: string;
}>): Promise<ExtendedProfile>;
/**
 * Get leaderboard rankings (cached)
 *
 * PERF-001: Optimized using:
 * - Covering index on character_stats
 * - Keyset pagination support via cursor
 * - Short TTL caching for frequently accessed data
 */
export declare function getLeaderboard(options: {
    statType?: StatType;
    scope?: 'global' | 'country' | 'state' | 'city';
    scopeValue?: string;
    gender?: string;
    limit?: number;
    offset?: number;
    cursor?: string;
}): Promise<Array<{
    userId: string;
    username: string;
    avatarUrl: string | null;
    statValue: number;
    rank: number;
    gender?: string;
    country?: string;
    state?: string;
    city?: string;
}>>;
/**
 * Get user's rankings across different scopes
 */
export declare function getUserRankings(userId: string): Promise<Record<StatType, RankingsByScope>>;
/**
 * Recalculate all stats from workout history
 */
export declare function recalculateAllStats(userId: string): Promise<CharacterStats>;
export declare const statsService: {
    STAT_TYPES: {
        readonly STRENGTH: "strength";
        readonly CONSTITUTION: "constitution";
        readonly DEXTERITY: "dexterity";
        readonly POWER: "power";
        readonly ENDURANCE: "endurance";
        readonly VITALITY: "vitality";
    };
    updateStatsFromWorkout: typeof updateStatsFromWorkout;
    getUserStats: typeof getUserStats;
    getStatsHistory: typeof getStatsHistory;
    createDailySnapshot: typeof createDailySnapshot;
    getExtendedProfile: typeof getExtendedProfile;
    updateExtendedProfile: typeof updateExtendedProfile;
    getLeaderboard: typeof getLeaderboard;
    getUserRankings: typeof getUserRankings;
    recalculateAllStats: typeof recalculateAllStats;
};
export default statsService;
