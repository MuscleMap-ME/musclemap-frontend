/**
 * Spirit Animal Wardrobe Service
 *
 * Handles all cosmetic/wardrobe functionality for Spirit Animals:
 * - Browsing and purchasing cosmetics
 * - Equipping/unequipping items
 * - Managing loadout presets
 * - Shop rotation
 * - Gifting cosmetics
 */
export interface SpiritCosmetic {
    id: string;
    itemKey: string;
    name: string;
    description: string | null;
    category: string;
    slot: string | null;
    rarity: string;
    basePrice: number;
    speciesLocked: string[] | null;
    stageRequired: number;
    isPurchasable: boolean;
    isTradeable: boolean;
    isGiftable: boolean;
    achievementRequired: string | null;
    season: string | null;
    releaseDate: string;
    retirementDate: string | null;
    previewUrl: string | null;
    assetUrl: string | null;
}
export interface UserCosmetic {
    id: string;
    cosmeticId: string;
    acquiredAt: string;
    acquisitionMethod: string;
    creditsSpent: number;
    giftedBy: string | null;
    isFavorite: boolean;
    isNew: boolean;
    cosmetic: SpiritCosmetic;
}
export interface SpiritLoadout {
    skinId: string | null;
    eyesId: string | null;
    outfitId: string | null;
    headwearId: string | null;
    footwearId: string | null;
    accessory1Id: string | null;
    accessory2Id: string | null;
    accessory3Id: string | null;
    auraId: string | null;
    emoteVictoryId: string | null;
    emoteIdleId: string | null;
    backgroundId: string | null;
}
export interface ShopItem {
    slotNumber: number;
    cosmeticId: string;
    itemKey: string;
    name: string;
    description: string | null;
    category: string;
    rarity: string;
    basePrice: number;
    discountPercent: number;
    finalPrice: number;
    isFeatured: boolean;
    owned: boolean;
}
export interface PurchaseResult {
    success: boolean;
    error?: string;
    cosmetic?: SpiritCosmetic;
    creditsSpent?: number;
    newBalance?: number;
}
export interface GiftResult {
    success: boolean;
    error?: string;
    giftId?: string;
    creditsSpent?: number;
}
export declare const spiritWardrobeService: {
    /**
     * Get all available cosmetics with filters
     */
    getCatalog(filters?: {
        category?: string;
        rarity?: string;
        maxPrice?: number;
        purchasableOnly?: boolean;
        season?: string;
    }): Promise<SpiritCosmetic[]>;
    /**
     * Get a specific cosmetic by ID or item_key
     */
    getCosmetic(idOrKey: string): Promise<SpiritCosmetic | null>;
    /**
     * Get user's owned cosmetics
     */
    getUserCollection(userId: string, category?: string): Promise<UserCosmetic[]>;
    /**
     * Check if user owns a specific cosmetic
     */
    userOwnsCosmetic(userId: string, cosmeticId: string): Promise<boolean>;
    /**
     * Purchase a cosmetic
     */
    purchaseCosmetic(userId: string, cosmeticId: string, discountPercent?: number): Promise<PurchaseResult>;
    /**
     * Gift a cosmetic to another user
     */
    giftCosmetic(fromUserId: string, toUserId: string, cosmeticId: string, message?: string): Promise<GiftResult>;
    /**
     * Get user's current loadout
     */
    getLoadout(userId: string): Promise<SpiritLoadout>;
    /**
     * Update user's loadout
     */
    updateLoadout(userId: string, updates: Partial<SpiritLoadout>): Promise<{
        success: boolean;
        error?: string;
    }>;
    /**
     * Get today's shop rotation
     */
    getTodaysShop(userId: string): Promise<ShopItem[]>;
    /**
     * Rotate the daily shop (called by scheduler)
     */
    rotateShop(): Promise<void>;
    /**
     * Award a cosmetic to user (for achievements, events, etc.)
     */
    awardCosmetic(userId: string, cosmeticId: string, method: "achievement" | "event" | "reward" | "competition" | "starter"): Promise<boolean>;
    /**
     * Toggle favorite status
     */
    toggleFavorite(userId: string, cosmeticId: string): Promise<boolean>;
    /**
     * Mark cosmetic as seen (not new)
     */
    markAsSeen(userId: string, cosmeticIds: string[]): Promise<void>;
    /**
     * Get all presets for a user
     */
    getPresets(userId: string): Promise<{
        id: string;
        name: string;
        icon: string;
        loadout: SpiritLoadout;
        createdAt: string;
    }[]>;
    /**
     * Save current loadout as a preset
     */
    savePreset(userId: string, name: string, icon?: string): Promise<{
        success: boolean;
        presetId?: string;
        error?: string;
    }>;
    /**
     * Load a preset into current loadout
     */
    loadPreset(userId: string, presetId: string): Promise<{
        success: boolean;
        error?: string;
    }>;
    /**
     * Delete a preset
     */
    deletePreset(userId: string, presetId: string): Promise<{
        success: boolean;
        error?: string;
    }>;
    /**
     * Rename a preset
     */
    renamePreset(userId: string, presetId: string, newName: string): Promise<{
        success: boolean;
        error?: string;
    }>;
    getUserStage(userId: string): Promise<number>;
    mapCosmetic(row: {
        id: string;
        item_key: string;
        name: string;
        description: string | null;
        category: string;
        slot: string | null;
        rarity: string;
        base_price: number;
        species_locked: string[] | null;
        stage_required: number;
        is_purchasable: boolean;
        is_tradeable: boolean;
        is_giftable: boolean;
        achievement_required: string | null;
        season: string | null;
        release_date: string;
        retirement_date: string | null;
        preview_url: string | null;
        asset_url: string | null;
    }): SpiritCosmetic;
};
