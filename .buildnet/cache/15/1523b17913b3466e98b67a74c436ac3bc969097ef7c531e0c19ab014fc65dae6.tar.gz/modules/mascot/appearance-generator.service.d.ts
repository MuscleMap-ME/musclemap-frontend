/**
 * Mascot Appearance Generator Service
 *
 * Generates deterministic visual traits for mascots based on user ID and archetype.
 * Uses seeded random generation to ensure consistency while allowing uniqueness.
 *
 * Key features:
 * - Deterministic: Same user ID always produces the same base appearance
 * - Archetype-influenced: User's archetype affects base traits
 * - Stage-dependent: More features unlock at higher stages
 * - Cosmetic-override: Equipped cosmetics replace generated traits
 */
export interface MascotBaseTraits {
    species: string;
    bodyShape: string;
    baseColor: string;
    secondaryColor: string;
    accentColor: string;
    eyeStyle: string;
    eyeColor: string;
    mouthStyle: string;
    expressionDefault: string;
    earStyle: string;
    tailStyle: string;
    patternType: string;
    patternIntensity: number;
    energyLevel: 'calm' | 'moderate' | 'energetic' | 'hyperactive';
    demeanor: 'shy' | 'friendly' | 'confident' | 'bold';
}
export interface MascotAppearance {
    base: MascotBaseTraits;
    stageFeatures: {
        stage: number;
        auraUnlocked: boolean;
        wingsUnlocked: boolean;
        specialEffectsUnlocked: boolean;
        evolutionGlow: boolean;
    };
    equipped: {
        skin: string | null;
        eyes: string | null;
        outfit: string | null;
        headwear: string | null;
        footwear: string | null;
        accessory1: string | null;
        accessory2: string | null;
        accessory3: string | null;
        aura: string | null;
        background: string | null;
        emoteVictory: string | null;
        emoteIdle: string | null;
    };
    final: {
        renderSeed: string;
        colorPalette: string[];
        activeEffects: string[];
    };
}
export interface SeededRandom {
    next(): number;
    nextInt(max: number): number;
    pick<T>(array: T[]): T;
    pickWeighted<T>(items: {
        item: T;
        weight: number;
    }[]): T;
}
export declare const appearanceGeneratorService: {
    /**
     * Generate base traits for a mascot based on user ID and archetype
     * These traits are deterministic and never change once generated
     */
    generateBaseTraits(userId: string, archetype?: string | null): MascotBaseTraits;
    /**
     * Get stage-dependent features
     */
    getStageFeatures(stage: number): MascotAppearance["stageFeatures"];
    /**
     * Generate a unique render seed for 3D rendering
     * Combines user ID with current cosmetic state
     */
    generateRenderSeed(userId: string, equipped: MascotAppearance["equipped"]): string;
    /**
     * Compute final color palette based on base traits and equipped cosmetics
     */
    computeColorPalette(base: MascotBaseTraits, equipped: MascotAppearance["equipped"]): string[];
    /**
     * Determine active visual effects based on stage and equipped items
     */
    computeActiveEffects(stageFeatures: MascotAppearance["stageFeatures"], equipped: MascotAppearance["equipped"]): string[];
    /**
     * Get full mascot appearance for a user
     */
    getFullAppearance(userId: string): Promise<MascotAppearance>;
    /**
     * Get simplified appearance for preview (without database lookup)
     * Used for quick rendering with known parameters
     */
    getPreviewAppearance(userId: string, archetype: string | null, stage: number, equipped?: Partial<MascotAppearance["equipped"]>): MascotAppearance;
    /**
     * Get animation config based on mascot personality
     */
    getAnimationConfig(base: MascotBaseTraits): {
        idleSpeed: number;
        movementAmplitude: number;
        blinkRate: number;
        bounciness: number;
        breathingDepth: number;
    };
    /**
     * Get reaction animation based on event type
     */
    getReactionAnimation(eventType: string, base: MascotBaseTraits): {
        animationName: string;
        duration: number;
        intensity: number;
        soundEffect: string | null;
    };
};
export default appearanceGeneratorService;
