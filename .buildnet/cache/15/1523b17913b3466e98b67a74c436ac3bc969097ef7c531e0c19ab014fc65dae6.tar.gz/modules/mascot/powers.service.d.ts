/**
 * Mascot Powers Service
 *
 * Unified service for all mascot powers across all phases:
 * - Phase 2: Credit Guardian, Streak Saver, Bonus Multiplier
 * - Phase 3: Smart Scheduler, Form Finder, Progress Tracker
 * - Phase 4: Crew Helper, Rivalry Manager, High-Five Helper
 * - Phase 5: Settings Optimizer, Data Guardian, Subscription Assistant
 * - Phase 6: Workout Generator, Injury Prevention, Nutrition Hints
 */
export interface MascotEnergy {
    current: number;
    max: number;
    regenPerHour: number;
}
export interface BonusMultiplier {
    totalMultiplier: number;
    firstWorkoutBonus: number;
    consecutiveBonus: number;
    consecutiveDays: number;
    companionStage: number;
}
export interface StreakSaveConfig {
    weeklySaves: number;
    savesUsed: number;
    savesRemaining: number;
    creditCost: number;
    energyCost: number;
    canSaveAnyStreak: boolean;
}
export interface CreditAlert {
    id: string;
    alertType: string;
    message: string;
    currentBalance: number;
    workoutCost?: number;
    dismissed: boolean;
    createdAt: Date;
}
export interface WorkoutSuggestion {
    id: string;
    suggestedFor: Date;
    suggestionType: string;
    focusMuscles: string[];
    recommendedExercises: string[];
    durationMinutes: number;
    reason: string;
}
export interface MilestoneProgress {
    id: string;
    milestoneType: string;
    milestoneName: string;
    currentValue: number;
    targetValue: number;
    estimatedCompletion: Date | null;
    confidencePercent: number;
}
export interface SocialAction {
    actionType: string;
    targetUserId: string;
    targetUsername: string;
    actionData: Record<string, unknown>;
    priority: number;
}
export interface MascotPowersSummary {
    companionStage: number;
    energy: MascotEnergy;
    phase2: {
        bonusMultiplier: BonusMultiplier;
        streakSaver: StreakSaveConfig;
        creditGuardianFeatures: string[];
    };
    phase3: {
        schedulerLevel: string;
        canSuggestRecovery: boolean;
        canPredictMilestones: boolean;
    };
    phase4: {
        canAutoHighfive: boolean;
        canTrashTalk: boolean;
        canCoordinateCrews: boolean;
    };
    phase5: {
        canDetectAnomalies: boolean;
        canSuggestSettings: boolean;
    };
    phase6: {
        canGeneratePrograms: boolean;
        hasInjuryPrevention: boolean;
        hasNutritionHints: boolean;
    };
    masterAbilities: string[];
}
export interface CreditLoanOffer {
    available: boolean;
    maxAmount: number;
    interestRate: number;
    currentLoan: number;
    canBorrow: boolean;
    reason?: string;
}
export interface ExerciseAlternative {
    exerciseId: string;
    exerciseName: string;
    reason: string;
    similarityScore: number;
    equipment: string[];
    difficulty: string;
}
export interface CrewSuggestion {
    crewId: string;
    crewName: string;
    matchScore: number;
    matchReasons: string[];
    memberCount: number;
}
export interface GeneratedProgram {
    id: string;
    name: string;
    type: string;
    goal: string;
    durationWeeks: number;
    daysPerWeek: number;
    schedule: Record<string, unknown>;
    workouts: ProgramWorkout[];
    creditCost: number;
}
export interface ProgramWorkout {
    weekNumber: number;
    dayNumber: number;
    name: string;
    focusAreas: string[];
    exercises: ProgramExercise[];
    durationMinutes: number;
    isDeload: boolean;
}
export interface ProgramExercise {
    exerciseId: string;
    exerciseName: string;
    sets: number;
    reps: string;
    restSeconds: number;
    notes?: string;
}
export interface VolumeStats {
    muscleGroup: string;
    weeklyVolume: number;
    averageIntensity: number;
    frequency: number;
    trend: 'increasing' | 'stable' | 'decreasing';
    recommendation?: string;
}
export declare const mascotPowersService: {
    /**
     * Get current mascot energy (with regeneration applied)
     */
    getEnergy(userId: string): Promise<MascotEnergy>;
    /**
     * Spend mascot energy
     */
    spendEnergy(userId: string, amount: number): Promise<{
        success: boolean;
        remaining: number;
    }>;
    /**
     * Get current bonus multiplier for user
     */
    getBonusMultiplier(userId: string): Promise<BonusMultiplier>;
    /**
     * Apply bonus to workout TU
     */
    applyBonus(userId: string, workoutId: string, baseTU: number): Promise<{
        bonusTU: number;
        totalTU: number;
    }>;
    /**
     * Get streak saver configuration and usage
     */
    getStreakSaverStatus(userId: string): Promise<StreakSaveConfig>;
    /**
     * Save a streak using mascot power
     */
    saveStreak(userId: string, streakType: "workout_streak" | "login_streak" | "goal_streak" | "challenge_streak", streakValue: number): Promise<{
        success: boolean;
        error?: string;
        saveId?: string;
    }>;
    /**
     * Get active credit alerts for user
     */
    getCreditAlerts(userId: string): Promise<CreditAlert[]>;
    /**
     * Create a credit alert
     */
    createCreditAlert(userId: string, alertType: string, currentBalance: number, workoutCost?: number, message?: string): Promise<void>;
    /**
     * Dismiss a credit alert
     */
    dismissCreditAlert(userId: string, alertId: string): Promise<void>;
    /**
     * Get credit loan offer for user (Stage 5+)
     */
    getCreditLoanOffer(userId: string): Promise<CreditLoanOffer>;
    /**
     * Take a credit loan from mascot (Stage 5+)
     */
    takeCreditLoan(userId: string, amount: number): Promise<{
        success: boolean;
        error?: string;
        newBalance?: number;
    }>;
    /**
     * Repay credit loan
     */
    repayCreditLoan(userId: string, amount?: number): Promise<{
        success: boolean;
        error?: string;
        amountRepaid?: number;
        remainingDebt?: number;
    }>;
    /**
     * Get negotiated workout rate (Stage 4+)
     * Returns a discount percentage for the next workout
     */
    getNegotiatedRate(userId: string): Promise<{
        discountPercent: number;
        available: boolean;
    }>;
    /**
     * Get today's workout suggestion
     */
    getWorkoutSuggestion(userId: string): Promise<WorkoutSuggestion | null>;
    /**
     * Get recovered muscle groups
     */
    getRecoveredMuscles(userId: string): Promise<{
        muscleGroup: string;
        hoursSinceRecovery: number;
    }[]>;
    /**
     * Update muscle recovery after workout
     */
    updateMuscleRecovery(userId: string, muscleGroup: string, volume: number, intensity: number): Promise<void>;
    /**
     * Get active milestone predictions
     */
    getMilestones(userId: string): Promise<MilestoneProgress[]>;
    /**
     * Record a celebration
     */
    recordCelebration(userId: string, celebrationType: string, title: string, valueAchieved?: number, previousValue?: number): Promise<string>;
    /**
     * Get exercise alternatives based on muscle activation similarity
     */
    getExerciseAlternatives(userId: string, exerciseId: string, reason?: "equipment" | "preference" | "easier" | "harder"): Promise<ExerciseAlternative[]>;
    /**
     * Record user's exercise avoidance/preference
     */
    setExerciseAvoidance(userId: string, exerciseId: string, avoidanceType: "favorite" | "avoid" | "injured" | "no_equipment" | "too_difficult" | "too_easy", reason?: string): Promise<void>;
    /**
     * Get user's avoided exercises
     */
    getExerciseAvoidances(userId: string): Promise<{
        exerciseId: string;
        avoidanceType: string;
        reason: string | null;
    }[]>;
    /**
     * Get pending social actions
     */
    getSocialActions(userId: string): Promise<SocialAction[]>;
    /**
     * Get auto-highfive preferences
     */
    getHighfivePrefs(userId: string): Promise<{
        enabled: boolean;
        closeFriends: boolean;
        crew: boolean;
        allFollowing: boolean;
        dailyLimit: number;
        usedToday: number;
    }>;
    /**
     * Update auto-highfive preferences
     */
    updateHighfivePrefs(userId: string, prefs: {
        enabled?: boolean;
        closeFriends?: boolean;
        crew?: boolean;
        allFollowing?: boolean;
        dailyLimit?: number;
    }): Promise<void>;
    /**
     * Get trash talk message for rivalry
     */
    getTrashTalk(context: string, variables: Record<string, string | number>): Promise<string | null>;
    /**
     * Get crew suggestions for user based on archetype and activity
     */
    getCrewSuggestions(userId: string): Promise<CrewSuggestion[]>;
    /**
     * Create crew coordination event (for workout scheduling)
     */
    createCrewCoordination(userId: string, crewId: string, coordinationType: "workout_reminder" | "time_suggestion" | "group_workout" | "challenge_invite", proposedTime?: Date, workoutType?: string): Promise<{
        success: boolean;
        coordinationId?: string;
    }>;
    /**
     * Get rivalry alerts (notifications about rival activity)
     */
    getRivalryAlerts(userId: string): Promise<{
        id: string;
        rivalUserId: string;
        rivalUsername: string;
        alertType: string;
        rivalAction: string | null;
        yourStanding: string | null;
        suggestion: string | null;
        createdAt: Date;
    }[]>;
    /**
     * Mark rivalry alert as seen
     */
    markRivalryAlertSeen(userId: string, alertId: string): Promise<void>;
    /**
     * Create rivalry alert (used by workout completion hook)
     */
    createRivalryAlert(userId: string, rivalryId: string, rivalUserId: string, alertType: string, rivalAction?: string, yourStanding?: string): Promise<void>;
    /**
     * Get tutorial status
     */
    getTutorialStatus(userId: string): Promise<{
        complete: boolean;
        currentStep: string;
        completedCount: number;
        nextHint: string | null;
    }>;
    /**
     * Check if backup reminder should be shown
     */
    shouldRemindBackup(userId: string): Promise<boolean>;
    /**
     * Get data alerts
     */
    getDataAlerts(userId: string): Promise<{
        id: string;
        alertType: string;
        severity: string;
        title: string;
        description: string | null;
        suggestedAction: string | null;
    }[]>;
    /**
     * Get generated programs
     */
    getPrograms(userId: string): Promise<{
        id: string;
        name: string;
        type: string;
        durationWeeks: number;
        status: string;
        startedAt: Date | null;
    }[]>;
    /**
     * Get overtraining alerts
     */
    getOvertrainingAlerts(userId: string): Promise<{
        id: string;
        alertType: string;
        affectedArea: string;
        riskLevel: string;
        recommendation: string | null;
    }[]>;
    /**
     * Get nutrition hint
     */
    getNutritionHint(userId: string, timing: string): Promise<string | null>;
    /**
     * Get volume stats for all muscle groups over past weeks
     */
    getVolumeStats(userId: string, weeks?: number): Promise<VolumeStats[]>;
    /**
     * Record volume after workout completion
     */
    recordWorkoutVolume(userId: string, muscleVolumes: {
        muscleGroup: string;
        sets: number;
        reps: number;
        weight: number;
        intensity: number;
    }[]): Promise<void>;
    /**
     * Check for overtraining and create alerts if needed
     */
    checkOvertraining(userId: string): Promise<{
        alerts: {
            muscleGroup: string;
            riskLevel: string;
            recommendation: string;
        }[];
    }>;
    /**
     * Generate a workout program (Stage 5+)
     */
    generateProgram(userId: string, params: {
        programType: "strength" | "hypertrophy" | "powerbuilding" | "athletic" | "custom";
        goal: "build_muscle" | "increase_strength" | "lose_fat" | "improve_endurance" | "general_fitness";
        durationWeeks: number;
        daysPerWeek: number;
        equipment?: string[];
    }): Promise<{
        success: boolean;
        program?: GeneratedProgram;
        error?: string;
        creditCost?: number;
    }>;
    /**
     * Build program logic (internal helper)
     */
    buildProgram(userId: string, params: {
        programType: string;
        goal: string;
        durationWeeks: number;
        daysPerWeek: number;
        equipment?: string[];
    }, _stage: number): Promise<Omit<GeneratedProgram, "id" | "creditCost">>;
    /**
     * Get workout split based on days per week
     */
    getSplitForDays(daysPerWeek: number, _programType: string): {
        name: string;
        muscles: string[];
        primaryMuscle: string;
    }[];
    /**
     * Get a user's active program
     */
    getActiveProgram(userId: string): Promise<GeneratedProgram | null>;
    /**
     * Get master abilities for user
     */
    getMasterAbilities(userId: string): Promise<{
        abilityKey: string;
        abilityName: string;
        description: string;
        category: string;
        unlocked: boolean;
        creditCost: number;
    }[]>;
    /**
     * Unlock a master ability
     */
    unlockMasterAbility(userId: string, abilityKey: string): Promise<{
        success: boolean;
        error?: string;
    }>;
    /**
     * Get all mascot powers for a user (using DB function)
     */
    getAllPowers(userId: string): Promise<Record<string, unknown>>;
    /**
     * Get comprehensive mascot powers summary
     */
    getPowersSummary(userId: string): Promise<MascotPowersSummary>;
    /**
     * Get user's companion stage
     */
    getCompanionStage(userId: string): Promise<number>;
    /**
     * Get mascot assist state
     */
    getAssistState(userId: string): Promise<{
        chargesRemaining: number;
        chargesMax: number;
        lastChargeReset: Date | null;
        lastAssistUsed: Date | null;
        totalAssistsUsed: number;
        exercisesAssistedToday: number;
        canUseAssist: boolean;
        cooldownEndsAt: Date | null;
        companionStage: number;
        userRankTier: number;
        ability: {
            id: string;
            name: string;
            maxExercises: number;
            dailyCharges: number;
            cooldownHours: number;
        } | null;
    }>;
    /**
     * Use mascot assist
     */
    useMascotAssist(userId: string, workoutId: string, exerciseId: string, reason?: string): Promise<{
        success: boolean;
        error?: string;
        assistLogId?: string;
        tuAwarded?: number;
        chargesRemaining?: number;
        message?: string;
    }>;
    /**
     * Request a credit loan
     */
    requestCreditLoan(userId: string, amount: number): Promise<{
        success: boolean;
        error?: string;
        newBalance?: number;
        amountRepaid?: number;
        remainingDebt?: number;
    }>;
    /**
     * Acknowledge overtraining alert
     */
    acknowledgeOvertrainingAlert(userId: string, alertId: string): Promise<void>;
    /**
     * Accept workout suggestion
     */
    acceptWorkoutSuggestion(userId: string, suggestionId: string): Promise<void>;
    /**
     * Activate generated program
     */
    activateGeneratedProgram(userId: string, programId: string): Promise<void>;
    /**
     * Execute social action
     */
    executeSocialAction(userId: string, actionId: string): Promise<void>;
    /**
     * Remove exercise avoidance
     */
    removeExerciseAvoidance(userId: string, exerciseId: string): Promise<void>;
    /**
     * Get multiple workout suggestions
     */
    getWorkoutSuggestions(userId: string, limit?: number): Promise<WorkoutSuggestion[]>;
    /**
     * Get milestone progress
     */
    getMilestoneProgress(userId: string): Promise<MilestoneProgress[]>;
    /**
     * Get generated programs
     */
    getGeneratedPrograms(userId: string, status?: string): Promise<{
        id: string;
        name: string;
        type: string;
        goal: string;
        durationWeeks: number;
        daysPerWeek: number;
        schedule: Record<string, unknown>;
        workouts: Array<{
            weekNumber: number;
            dayNumber: number;
            name: string;
            focusAreas: string[];
            exercises: Array<{
                exerciseId: string;
                exerciseName: string;
                sets: number;
                reps: string;
                restSeconds: number;
                notes: string | null;
            }>;
            durationMinutes: number;
            isDeload: boolean;
        }>;
        creditCost: number;
    }[]>;
    /**
     * Get pending social actions
     */
    getPendingSocialActions(userId: string): Promise<SocialAction[]>;
};
export default mascotPowersService;
