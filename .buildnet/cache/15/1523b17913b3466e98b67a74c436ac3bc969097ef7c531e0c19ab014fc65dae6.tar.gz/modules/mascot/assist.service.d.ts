/**
 * Mascot Assist Service
 *
 * Handles the mascot's ability to complete exercises on behalf of the user.
 * This is a powerful early-game feature that helps new users maintain streaks
 * and earn full credit even when they can't complete all exercises.
 *
 * Key features:
 * - Check if user can use mascot assist
 * - Use assist to complete an exercise
 * - Track daily charge usage
 * - Calculate TU credit for assisted exercises
 */
export interface MascotAssistAbility {
    abilityId: string;
    abilityName: string;
    maxExercises: number;
    dailyCharges: number;
    cooldownHours: number;
}
export interface MascotAssistState {
    chargesRemaining: number;
    chargesMax: number;
    lastChargeReset: Date;
    lastAssistUsed: Date | null;
    totalAssistsUsed: number;
    exercisesAssistedToday: number;
    currentAbility: MascotAssistAbility | null;
    canUseAssist: boolean;
    cooldownEndsAt: Date | null;
    companionStage: number;
    userRankTier: number;
}
export interface UseAssistResult {
    success: boolean;
    error?: string;
    assistLogId?: string;
    tuAwarded?: number;
    chargesRemaining?: number;
    message?: string;
}
export interface AssistLogEntry {
    id: string;
    workoutId: string | null;
    exerciseId: string;
    exerciseName: string | null;
    abilityId: string;
    companionStage: number;
    userRankTier: number;
    setsCompleted: number;
    repsCompleted: number;
    weightUsed: number;
    tuAwarded: number;
    reason: string | null;
    createdAt: Date;
}
export declare const mascotAssistService: {
    /**
     * Get the current mascot assist ability for a user based on their companion stage and rank
     */
    getAbilityForUser(userId: string): Promise<MascotAssistAbility | null>;
    /**
     * Get or create the mascot assist state for a user
     */
    getOrCreateState(userId: string): Promise<MascotAssistState>;
    /**
     * Use mascot assist to complete an exercise
     */
    useAssist(userId: string, exerciseId: string, options?: {
        workoutId?: string;
        sets?: number;
        reps?: number;
        weight?: number;
        reason?: string;
    }): Promise<UseAssistResult>;
    /**
     * Get assist history for a user
     */
    getAssistHistory(userId: string, options?: {
        limit?: number;
        cursor?: string;
    }): Promise<{
        entries: AssistLogEntry[];
        nextCursor: string | null;
    }>;
    /**
     * Check if a specific exercise in a workout was assisted
     */
    wasExerciseAssisted(userId: string, workoutId: string, exerciseId: string): Promise<boolean>;
    /**
     * Get all assisted exercises for a workout
     */
    getAssistedExercises(workoutId: string): Promise<string[]>;
    /**
     * Reset daily charges for all users (called by cron job)
     */
    resetDailyCharges(): Promise<{
        updated: number;
    }>;
};
export default mascotAssistService;
