/**
 * Companion Events Service
 *
 * Handles companion XP/stage progression and event emission.
 * Integrates with the economy service for training unit rewards.
 */
export declare const STAGE_THRESHOLDS: number[];
export declare const XP_REWARDS: Record<string, number>;
export declare const UNIT_REWARDS: Record<string, number>;
export declare const companionEventsService: {
    /**
     * Emit a companion event and handle XP/unit rewards
     */
    emit(userId: string, eventType: string, eventData?: Record<string, unknown>): Promise<{
        xp: number;
        units: number;
        newStage?: number;
        evolved?: boolean;
    }>;
    /**
     * Get or initialize companion state for a user
     */
    getOrCreateState(userId: string): Promise<{
        id: string;
        user_id: string;
        template_id: string;
        nickname: string | null;
        stage: number;
        xp: number;
        unlocked_upgrades: string[];
        equipped_cosmetics: Record<string, string>;
        abilities: string[];
        is_visible: boolean;
        is_minimized: boolean;
        sounds_enabled: boolean;
        tips_enabled: boolean;
        created_at: Date;
        updated_at: Date;
    }>;
    /**
     * Calculate progression info for a companion
     */
    calculateProgression(xp: number, stage: number): {
        currentXp: number;
        prevStageXp: number;
        nextStageXp: number;
        progressPercent: number;
        isMaxStage: boolean;
    };
    /**
     * Award a badge upgrade to a user (for achievements)
     */
    awardBadge(userId: string, badgeId: string): Promise<boolean>;
};
