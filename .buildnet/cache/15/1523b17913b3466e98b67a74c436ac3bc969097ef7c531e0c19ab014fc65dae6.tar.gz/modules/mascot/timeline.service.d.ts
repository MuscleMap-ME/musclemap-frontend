/**
 * Mascot Timeline Service
 *
 * Integrates mascot reactions with the user's journey timeline.
 * Generates contextual reactions based on workout events, achievements, etc.
 *
 * Key features:
 * - Automatic reaction generation for timeline events
 * - Context-aware messaging based on mascot personality
 * - Stage-dependent reaction complexity
 * - Cooldown management to prevent reaction spam
 */
import type { MascotBaseTraits } from './appearance-generator.service';
export interface MascotTimelineEvent {
    id: string;
    userId: string;
    eventType: string;
    eventData: Record<string, unknown>;
    timestamp: Date;
    importance: 'low' | 'medium' | 'high' | 'epic';
}
export interface MascotReaction {
    id: string;
    eventId: string;
    reactionType: string;
    message: string;
    emote: string;
    animation: string;
    duration: number;
    intensity: number;
    soundEffect: string | null;
    createdAt: Date;
    shown: boolean;
}
export interface TimelineEventWithReaction {
    event: MascotTimelineEvent;
    reaction: MascotReaction | null;
}
export declare const mascotTimelineService: {
    /**
     * Record a timeline event and generate a mascot reaction
     */
    recordEvent(userId: string, eventType: string, eventData?: Record<string, unknown>, forceReaction?: boolean): Promise<TimelineEventWithReaction>;
    /**
     * Create a timeline event record
     */
    createEvent(userId: string, eventType: string, eventData: Record<string, unknown>): Promise<MascotTimelineEvent>;
    /**
     * Generate a mascot reaction for an event
     */
    generateReaction(userId: string, event: MascotTimelineEvent): Promise<MascotReaction | null>;
    /**
     * Personalize a message template based on mascot personality and event data
     */
    personalizeMessage(template: string, traits: MascotBaseTraits, eventData: Record<string, unknown>): string;
    /**
     * Get pending (unshown) reactions for a user
     */
    getPendingReactions(userId: string, limit?: number): Promise<MascotReaction[]>;
    /**
     * Mark reactions as shown
     */
    markReactionsShown(userId: string, reactionIds: string[]): Promise<void>;
    /**
     * Get timeline with reactions for a user
     */
    getTimelineWithReactions(userId: string, options?: {
        limit?: number;
        offset?: number;
        importance?: string[];
    }): Promise<TimelineEventWithReaction[]>;
    /**
     * Get recent timeline stats for a user
     */
    getTimelineStats(userId: string, days?: number): Promise<{
        totalEvents: number;
        eventsByType: Record<string, number>;
        eventsByImportance: Record<string, number>;
        reactionsShown: number;
        reactionsPending: number;
    }>;
    /**
     * Helper: Pick random element from array
     */
    pickRandom<T>(array: T[]): T;
};
export default mascotTimelineService;
