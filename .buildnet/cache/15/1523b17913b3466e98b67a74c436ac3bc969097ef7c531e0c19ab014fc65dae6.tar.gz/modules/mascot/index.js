"use strict";
/**
 * Mascot Module (Spirit Animal System)
 *
 * Provides services for both the Global Mascot and User Companions (Spirit Animals).
 * Includes all mascot powers across 6 phases:
 * - Phase 1: Workout Assist
 * - Phase 2: Credit & Economy (Streak Saver, Bonus Multiplier)
 * - Phase 3: Journey & Progress (Smart Scheduler, Form Finder)
 * - Phase 4: Social & Community (Crew Helper, Rivalry Manager)
 * - Phase 5: Account & Meta (Settings, Data Guardian)
 * - Phase 6: Advanced AI (Workout Generator, Injury Prevention)
 *
 * Also includes:
 * - Spirit Animal Wardrobe system for cosmetic customization
 * - Appearance Generator for deterministic visual trait generation
 * - Timeline integration for mascot reactions to user events
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.mascotTimelineService = exports.appearanceGeneratorService = exports.spiritWardrobeService = exports.mascotPowersService = exports.mascotAssistService = exports.UNIT_REWARDS = exports.XP_REWARDS = exports.STAGE_THRESHOLDS = exports.companionEventsService = void 0;
var companion_events_1 = require("./companion-events");
Object.defineProperty(exports, "companionEventsService", { enumerable: true, get: function () { return companion_events_1.companionEventsService; } });
Object.defineProperty(exports, "STAGE_THRESHOLDS", { enumerable: true, get: function () { return companion_events_1.STAGE_THRESHOLDS; } });
Object.defineProperty(exports, "XP_REWARDS", { enumerable: true, get: function () { return companion_events_1.XP_REWARDS; } });
Object.defineProperty(exports, "UNIT_REWARDS", { enumerable: true, get: function () { return companion_events_1.UNIT_REWARDS; } });
var assist_service_1 = require("./assist.service");
Object.defineProperty(exports, "mascotAssistService", { enumerable: true, get: function () { return assist_service_1.mascotAssistService; } });
var powers_service_1 = require("./powers.service");
Object.defineProperty(exports, "mascotPowersService", { enumerable: true, get: function () { return powers_service_1.mascotPowersService; } });
var spirit_wardrobe_service_1 = require("./spirit-wardrobe.service");
Object.defineProperty(exports, "spiritWardrobeService", { enumerable: true, get: function () { return spirit_wardrobe_service_1.spiritWardrobeService; } });
var appearance_generator_service_1 = require("./appearance-generator.service");
Object.defineProperty(exports, "appearanceGeneratorService", { enumerable: true, get: function () { return appearance_generator_service_1.appearanceGeneratorService; } });
var timeline_service_1 = require("./timeline.service");
Object.defineProperty(exports, "mascotTimelineService", { enumerable: true, get: function () { return timeline_service_1.mascotTimelineService; } });
//# sourceMappingURL=index.js.map