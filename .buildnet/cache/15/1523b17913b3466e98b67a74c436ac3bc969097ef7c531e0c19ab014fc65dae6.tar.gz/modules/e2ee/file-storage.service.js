"use strict";
/**
 * E2EE File Storage Service
 *
 * Handles zero-storage file attachments:
 * - Files are encrypted client-side BEFORE upload
 * - Files are stored on external storage (Cloudflare R2)
 * - Server only stores encrypted metadata (cannot read content)
 * - Presigned URLs for direct client upload/download
 *
 * IMPORTANT: Server NEVER sees plaintext file content.
 * All encryption happens client-side.
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.fileStorageService = void 0;
const crypto_1 = __importDefault(require("crypto"));
const client_s3_1 = require("@aws-sdk/client-s3");
const s3_request_presigner_1 = require("@aws-sdk/s3-request-presigner");
const client_1 = require("../../db/client");
const logger_1 = require("../../lib/logger");
const crypto_2 = require("./crypto");
const log = logger_1.loggers.api.child({ module: 'e2ee-file-storage' });
// ============================================
// CONFIGURATION
// ============================================
const R2_CONFIG = {
    accountId: process.env.CLOUDFLARE_ACCOUNT_ID || '',
    accessKeyId: process.env.R2_ACCESS_KEY_ID || '',
    secretAccessKey: process.env.R2_SECRET_ACCESS_KEY || '',
    bucketName: process.env.R2_BUCKET_NAME || 'musclemap-encrypted-files',
    publicUrl: process.env.R2_PUBLIC_URL || '',
};
const FILE_CONFIG = {
    UPLOAD_URL_EXPIRATION_SECONDS: 3600, // 1 hour
    DOWNLOAD_URL_EXPIRATION_SECONDS: 3600, // 1 hour
    DEFAULT_EXPIRATION_DAYS: 30,
    MAX_EXPIRATION_DAYS: 90,
    MAX_UPLOADS_PER_DAY: 50,
    MAX_TOTAL_SIZE_PER_DAY_MB: 500,
};
// Initialize S3 client for R2
let s3Client = null;
function getS3Client() {
    if (!s3Client) {
        if (!R2_CONFIG.accountId || !R2_CONFIG.accessKeyId || !R2_CONFIG.secretAccessKey) {
            // Return a mock client for development - will throw on actual use
            log.warn('R2 configuration missing - file uploads will fail');
            s3Client = new client_s3_1.S3Client({
                region: 'auto',
                endpoint: 'https://mock.r2.cloudflarestorage.com',
                credentials: {
                    accessKeyId: 'mock',
                    secretAccessKey: 'mock',
                },
            });
        }
        else {
            s3Client = new client_s3_1.S3Client({
                region: 'auto',
                endpoint: `https://${R2_CONFIG.accountId}.r2.cloudflarestorage.com`,
                credentials: {
                    accessKeyId: R2_CONFIG.accessKeyId,
                    secretAccessKey: R2_CONFIG.secretAccessKey,
                },
            });
        }
    }
    return s3Client;
}
// ============================================
// SERVICE
// ============================================
exports.fileStorageService = {
    /**
     * Request a presigned upload URL
     * Returns a token and URL for direct client-to-R2 upload
     */
    async requestUploadUrl(userId, request) {
        const { fileName, fileSize, mimeType, encryptedMetadata, nsfwClassification } = request;
        // Validate file size
        if (fileSize > crypto_2.FILE_LIMITS.MAX_FILE_SIZE_BYTES) {
            throw new Error(`File too large. Maximum size is ${crypto_2.FILE_LIMITS.MAX_FILE_SIZE_BYTES / 1024 / 1024}MB`);
        }
        // Check rate limits
        const today = new Date().toISOString().split('T')[0];
        const stats = await (0, client_1.queryOne)(`SELECT COUNT(*) as upload_count, COALESCE(SUM(file_size), 0) as total_size
       FROM encrypted_file_metadata
       WHERE uploader_id = $1 AND created_at::date = $2::date`, [userId, today]);
        const uploadCount = parseInt(stats?.upload_count || '0');
        const totalSize = parseInt(stats?.total_size || '0');
        if (uploadCount >= FILE_CONFIG.MAX_UPLOADS_PER_DAY) {
            throw new Error(`Rate limit exceeded: maximum ${FILE_CONFIG.MAX_UPLOADS_PER_DAY} uploads per day`);
        }
        if (totalSize + fileSize > FILE_CONFIG.MAX_TOTAL_SIZE_PER_DAY_MB * 1024 * 1024) {
            throw new Error(`Rate limit exceeded: maximum ${FILE_CONFIG.MAX_TOTAL_SIZE_PER_DAY_MB}MB per day`);
        }
        // Generate unique content ID
        const contentId = crypto_1.default.randomUUID();
        const token = crypto_1.default.randomBytes(32).toString('hex');
        const expiresAt = new Date(Date.now() + FILE_CONFIG.UPLOAD_URL_EXPIRATION_SECONDS * 1000);
        // Store upload token
        await (0, client_1.query)(`INSERT INTO file_upload_tokens (
        id, user_id, token_hash, content_id, file_size,
        mime_type, encrypted_metadata, nsfw_classification,
        storage_provider, expires_at, status
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, 'pending')`, [
            crypto_1.default.randomUUID(),
            userId,
            crypto_1.default.createHash('sha256').update(token).digest('hex'),
            contentId,
            fileSize,
            mimeType,
            encryptedMetadata,
            nsfwClassification || 'safe',
            'r2',
            expiresAt,
        ]);
        // Generate presigned upload URL
        const s3 = getS3Client();
        const key = `encrypted/${contentId}`;
        const command = new client_s3_1.PutObjectCommand({
            Bucket: R2_CONFIG.bucketName,
            Key: key,
            ContentType: 'application/octet-stream', // Always binary (encrypted)
            ContentLength: fileSize,
        });
        const uploadUrl = await (0, s3_request_presigner_1.getSignedUrl)(s3, command, {
            expiresIn: FILE_CONFIG.UPLOAD_URL_EXPIRATION_SECONDS,
        });
        log.info({ userId, contentId, fileSize, mimeType }, 'Generated upload URL');
        return {
            token,
            uploadUrl,
            expiresAt,
            maxSize: fileSize,
        };
    },
    /**
     * Confirm upload after client has uploaded to R2
     * Creates the file metadata record
     */
    async confirmUpload(userId, token, encryptedKey, contentHash) {
        const tokenHash = crypto_1.default.createHash('sha256').update(token).digest('hex');
        // Find and validate token
        const uploadToken = await (0, client_1.queryOne)(`SELECT * FROM file_upload_tokens
       WHERE token_hash = $1 AND user_id = $2 AND status = 'pending'`, [tokenHash, userId]);
        if (!uploadToken) {
            throw new Error('Upload token not found or already used');
        }
        if (new Date() > uploadToken.expires_at) {
            throw new Error('Upload token expired');
        }
        // Mark token as used
        await (0, client_1.query)(`UPDATE file_upload_tokens SET status = 'completed' WHERE id = $1`, [uploadToken.id]);
        // Create file metadata record
        const fileId = crypto_1.default.randomUUID();
        const storageUrl = `r2://${R2_CONFIG.bucketName}/encrypted/${uploadToken.content_id}`;
        const expiresAt = new Date(Date.now() + FILE_CONFIG.DEFAULT_EXPIRATION_DAYS * 24 * 60 * 60 * 1000);
        await (0, client_1.query)(`INSERT INTO encrypted_file_metadata (
        id, uploader_id, encrypted_metadata, encrypted_key,
        mime_type, file_size, content_hash, storage_url,
        nsfw_classification, expires_at
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)`, [
            fileId,
            userId,
            uploadToken.encrypted_metadata,
            encryptedKey,
            uploadToken.mime_type,
            uploadToken.file_size,
            contentHash,
            storageUrl,
            uploadToken.nsfw_classification,
            expiresAt,
        ]);
        log.info({ fileId, userId, contentId: uploadToken.content_id }, 'Confirmed file upload');
        return {
            id: fileId,
            uploaderId: userId,
            encryptedMetadata: uploadToken.encrypted_metadata,
            encryptedKey,
            mimeType: uploadToken.mime_type,
            fileSize: uploadToken.file_size,
            contentHash,
            storageUrl,
            nsfwClassification: uploadToken.nsfw_classification,
            expiresAt,
            createdAt: new Date(),
        };
    },
    /**
     * Get presigned download URL for a file
     */
    async getDownloadUrl(fileId, userId) {
        // Get file metadata
        const file = await (0, client_1.queryOne)(`SELECT * FROM encrypted_file_metadata WHERE id = $1`, [fileId]);
        if (!file) {
            throw new Error('File not found');
        }
        // Check if expired
        if (file.expires_at && new Date() > file.expires_at) {
            throw new Error('File has expired');
        }
        // For NSFW content, check user preferences
        if (file.nsfw_classification !== 'safe') {
            const prefs = await (0, client_1.queryOne)(`SELECT adult_content_enabled, is_minor FROM user_content_preferences WHERE user_id = $1`, [userId]);
            if (prefs?.is_minor) {
                throw new Error('This content is not available to minors');
            }
            if (!prefs?.adult_content_enabled && file.nsfw_classification !== 'suggestive') {
                throw new Error('Enable adult content in settings to view this file');
            }
        }
        // Extract content ID from storage URL
        // Format: r2://bucket/encrypted/{contentId}
        const contentId = file.storage_url.split('/').pop();
        if (!contentId) {
            throw new Error('Invalid storage URL');
        }
        // Generate presigned download URL
        const s3 = getS3Client();
        const key = `encrypted/${contentId}`;
        const command = new client_s3_1.GetObjectCommand({
            Bucket: R2_CONFIG.bucketName,
            Key: key,
        });
        const downloadUrl = await (0, s3_request_presigner_1.getSignedUrl)(s3, command, {
            expiresIn: FILE_CONFIG.DOWNLOAD_URL_EXPIRATION_SECONDS,
        });
        // Update access tracking
        await (0, client_1.query)(`UPDATE encrypted_file_metadata
       SET download_count = COALESCE(download_count, 0) + 1,
           last_downloaded_at = NOW()
       WHERE id = $1`, [fileId]);
        log.info({ fileId, userId }, 'Generated download URL');
        return downloadUrl;
    },
    /**
     * Delete a file (only uploader can delete)
     */
    async deleteFile(fileId, userId) {
        // Get file and verify ownership
        const file = await (0, client_1.queryOne)(`SELECT id, uploader_id, storage_url FROM encrypted_file_metadata WHERE id = $1`, [fileId]);
        if (!file) {
            throw new Error('File not found');
        }
        if (file.uploader_id !== userId) {
            throw new Error('Only the uploader can delete this file');
        }
        // Extract content ID from storage URL
        const contentId = file.storage_url.split('/').pop();
        if (contentId) {
            // Delete from R2
            const s3 = getS3Client();
            const key = `encrypted/${contentId}`;
            const command = new client_s3_1.DeleteObjectCommand({
                Bucket: R2_CONFIG.bucketName,
                Key: key,
            });
            try {
                await s3.send(command);
            }
            catch (error) {
                log.error({ fileId, error }, 'Failed to delete file from R2');
                // Continue to delete metadata even if R2 delete fails
            }
        }
        // Delete metadata
        await (0, client_1.query)(`DELETE FROM encrypted_file_metadata WHERE id = $1`, [fileId]);
        log.info({ fileId, userId }, 'Deleted encrypted file');
    },
    /**
     * Get file metadata by ID
     */
    async getFileMetadata(fileId) {
        const file = await (0, client_1.queryOne)(`SELECT * FROM encrypted_file_metadata WHERE id = $1`, [fileId]);
        if (!file)
            return null;
        return {
            id: file.id,
            uploaderId: file.uploader_id,
            encryptedMetadata: file.encrypted_metadata,
            encryptedKey: file.encrypted_key,
            mimeType: file.mime_type,
            fileSize: file.file_size,
            contentHash: file.content_hash,
            storageUrl: file.storage_url,
            nsfwClassification: file.nsfw_classification,
            expiresAt: file.expires_at,
            createdAt: file.created_at,
        };
    },
    /**
     * Cleanup expired files from R2
     */
    async cleanupExpiredFiles() {
        const expiredFiles = await (0, client_1.queryAll)(`SELECT id, storage_url FROM encrypted_file_metadata
       WHERE expires_at IS NOT NULL AND expires_at < NOW()
       LIMIT 100`);
        if (expiredFiles.length === 0)
            return 0;
        const s3 = getS3Client();
        let deletedCount = 0;
        for (const file of expiredFiles) {
            try {
                const contentId = file.storage_url.split('/').pop();
                if (contentId) {
                    const key = `encrypted/${contentId}`;
                    const command = new client_s3_1.DeleteObjectCommand({
                        Bucket: R2_CONFIG.bucketName,
                        Key: key,
                    });
                    await s3.send(command);
                }
                await (0, client_1.query)(`DELETE FROM encrypted_file_metadata WHERE id = $1`, [file.id]);
                deletedCount++;
            }
            catch (error) {
                log.error({ fileId: file.id, error }, 'Failed to delete expired file');
            }
        }
        if (deletedCount > 0) {
            log.info({ count: deletedCount }, 'Cleaned up expired files');
        }
        return deletedCount;
    },
    /**
     * Cleanup expired upload tokens
     */
    async cleanupExpiredTokens() {
        const result = await (0, client_1.query)(`DELETE FROM file_upload_tokens
       WHERE expires_at < NOW() AND status = 'pending'`);
        return result.rowCount || 0;
    },
};
exports.default = exports.fileStorageService;
//# sourceMappingURL=file-storage.service.js.map