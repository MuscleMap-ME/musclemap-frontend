/**
 * E2EE Cryptography Utilities
 *
 * Server-side crypto operations for key validation and verification.
 * IMPORTANT: Private keys are NEVER on the server - all encryption/decryption
 * happens client-side. This module only handles:
 * - Key format validation
 * - Signature verification
 * - Fingerprint generation
 * - Content hashing
 */
export declare const CRYPTO_CONSTANTS: {
    ED25519_PUBLIC_KEY_SIZE: number;
    ED25519_SIGNATURE_SIZE: number;
    X25519_PUBLIC_KEY_SIZE: number;
    XCHACHA20_NONCE_SIZE: number;
    XCHACHA20_KEY_SIZE: number;
    POLY1305_TAG_SIZE: number;
    ENCODING: "base64";
    CURRENT_PROTOCOL_VERSION: number;
    MIN_ONETIME_PREKEYS: number;
    MAX_ONETIME_PREKEYS: number;
    DEFAULT_ONETIME_PREKEYS: number;
    SIGNED_PREKEY_ROTATION_MS: number;
};
export interface KeyBundle {
    userId: string;
    deviceId: string;
    identityKeyPublic: string;
    identityKeyFingerprint: string;
    signedPreKeyPublic: string;
    signedPreKeySignature: string;
    signedPreKeyId: number;
}
export interface OneTimePreKey {
    id: number;
    publicKey: string;
}
export interface EncryptedPayload {
    version: number;
    senderFingerprint: string;
    keyExchange?: {
        ephemeralKey: string;
        usedOneTimePreKeyId?: number;
    };
    header: {
        ratchetPublicKey: string;
        messageNumber: number;
        previousChainLength: number;
    };
    nonce: string;
    ciphertext: string;
}
/**
 * Validate a base64-encoded public key
 */
export declare function validatePublicKey(key: string, expectedSize: number, keyType: string): {
    valid: boolean;
    error?: string;
};
/**
 * Validate an Ed25519 identity public key
 */
export declare function validateIdentityKey(key: string): {
    valid: boolean;
    error?: string;
};
/**
 * Validate an X25519 prekey
 */
export declare function validatePreKey(key: string): {
    valid: boolean;
    error?: string;
};
/**
 * Validate an Ed25519 signature
 */
export declare function validateSignature(signature: string): {
    valid: boolean;
    error?: string;
};
/**
 * Validate a nonce
 */
export declare function validateNonce(nonce: string): {
    valid: boolean;
    error?: string;
};
/**
 * Validate an entire key bundle
 */
export declare function validateKeyBundle(bundle: Partial<KeyBundle>): {
    valid: boolean;
    errors: string[];
};
/**
 * Generate a fingerprint for a public key
 * Used for key verification and display
 */
export declare function generateFingerprint(publicKey: string): string;
/**
 * Generate a short fingerprint (first 8 chars)
 * Used for display in UI
 */
export declare function generateShortFingerprint(publicKey: string): string;
/**
 * Generate fingerprint for identity key verification
 */
export declare function generateIdentityFingerprint(identityKey: string): string;
/**
 * Hash content for verification (without revealing content)
 * Used in content reports to verify claims
 */
export declare function hashContent(content: Buffer | string): string;
/**
 * Hash file content for CID-like identification
 */
export declare function hashFile(fileBuffer: Buffer): string;
/**
 * Verify content matches a hash
 */
export declare function verifyContentHash(content: Buffer | string, expectedHash: string): boolean;
/**
 * Generate a secure random token
 */
export declare function generateSecureToken(bytes?: number): Promise<string>;
/**
 * Generate a random ID with prefix
 */
export declare function generateRandomId(prefix: string): Promise<string>;
/**
 * Generate a prekey ID (sequential within device)
 */
export declare function generatePreKeyId(lastId?: number): number;
/**
 * Verify Ed25519 signature using Node.js crypto
 * Note: Ed25519 is supported in Node.js 12+
 */
export declare function verifyEd25519Signature(message: Buffer, signature: string, publicKey: string): boolean;
/**
 * Verify signed prekey signature
 * The signature is over the signed prekey public key bytes
 */
export declare function verifySignedPreKey(signedPreKeyPublic: string, signature: string, identityKeyPublic: string): boolean;
/**
 * Validate encrypted message payload structure
 */
export declare function validateEncryptedPayload(payload: Partial<EncryptedPayload>): {
    valid: boolean;
    errors: string[];
};
export declare const ALLOWED_MIME_TYPES: {
    images: string[];
    videos: string[];
    audio: string[];
    documents: string[];
};
export declare const FILE_LIMITS: {
    MAX_FILE_SIZE_BYTES: number;
    MAX_IMAGE_SIZE_BYTES: number;
    MAX_VIDEO_SIZE_BYTES: number;
    MAX_DOCUMENT_SIZE_BYTES: number;
    MAX_THUMBNAIL_SIZE_BYTES: number;
};
/**
 * Get file category from MIME type
 */
export declare function getFileCategory(mimeType: string): 'images' | 'videos' | 'audio' | 'documents' | null;
/**
 * Validate file metadata
 */
export declare function validateFileMetadata(mimeType: string, sizeBytes: number, allowedTypes: {
    images: boolean;
    videos: boolean;
    audio: boolean;
    documents: boolean;
}): {
    valid: boolean;
    error?: string;
};
declare const _default: {
    CRYPTO_CONSTANTS: {
        ED25519_PUBLIC_KEY_SIZE: number;
        ED25519_SIGNATURE_SIZE: number;
        X25519_PUBLIC_KEY_SIZE: number;
        XCHACHA20_NONCE_SIZE: number;
        XCHACHA20_KEY_SIZE: number;
        POLY1305_TAG_SIZE: number;
        ENCODING: "base64";
        CURRENT_PROTOCOL_VERSION: number;
        MIN_ONETIME_PREKEYS: number;
        MAX_ONETIME_PREKEYS: number;
        DEFAULT_ONETIME_PREKEYS: number;
        SIGNED_PREKEY_ROTATION_MS: number;
    };
    validateIdentityKey: typeof validateIdentityKey;
    validatePreKey: typeof validatePreKey;
    validateSignature: typeof validateSignature;
    validateNonce: typeof validateNonce;
    validateKeyBundle: typeof validateKeyBundle;
    generateFingerprint: typeof generateFingerprint;
    generateShortFingerprint: typeof generateShortFingerprint;
    generateIdentityFingerprint: typeof generateIdentityFingerprint;
    hashContent: typeof hashContent;
    hashFile: typeof hashFile;
    verifyContentHash: typeof verifyContentHash;
    generateSecureToken: typeof generateSecureToken;
    generateRandomId: typeof generateRandomId;
    generatePreKeyId: typeof generatePreKeyId;
    verifyEd25519Signature: typeof verifyEd25519Signature;
    verifySignedPreKey: typeof verifySignedPreKey;
    validateEncryptedPayload: typeof validateEncryptedPayload;
    getFileCategory: typeof getFileCategory;
    validateFileMetadata: typeof validateFileMetadata;
    ALLOWED_MIME_TYPES: {
        images: string[];
        videos: string[];
        audio: string[];
        documents: string[];
    };
    FILE_LIMITS: {
        MAX_FILE_SIZE_BYTES: number;
        MAX_IMAGE_SIZE_BYTES: number;
        MAX_VIDEO_SIZE_BYTES: number;
        MAX_DOCUMENT_SIZE_BYTES: number;
        MAX_THUMBNAIL_SIZE_BYTES: number;
    };
};
export default _default;
