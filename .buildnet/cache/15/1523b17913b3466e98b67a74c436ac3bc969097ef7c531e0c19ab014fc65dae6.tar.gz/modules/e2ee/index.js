"use strict";
/**
 * E2EE Module Index
 *
 * End-to-End Encrypted Messaging System
 *
 * Features:
 * - Signal Protocol compatible encryption (X3DH + Double Ratchet)
 * - Zero-storage file attachments (R2/IPFS)
 * - NSFW content moderation with user consent
 * - Age verification and minor protection
 * - Granular privacy controls
 * - Trust scoring and anti-abuse
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports, p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.contentPreferencesService = exports.fileStorageService = exports.encryptedMessagingService = exports.keyManagementService = void 0;
// Crypto utilities
__exportStar(require("./crypto"), exports);
// Services
var key_management_service_1 = require("./key-management.service");
Object.defineProperty(exports, "keyManagementService", { enumerable: true, get: function () { return key_management_service_1.keyManagementService; } });
var encrypted_messaging_service_1 = require("./encrypted-messaging.service");
Object.defineProperty(exports, "encryptedMessagingService", { enumerable: true, get: function () { return encrypted_messaging_service_1.encryptedMessagingService; } });
var file_storage_service_1 = require("./file-storage.service");
Object.defineProperty(exports, "fileStorageService", { enumerable: true, get: function () { return file_storage_service_1.fileStorageService; } });
var content_preferences_service_1 = require("./content-preferences.service");
Object.defineProperty(exports, "contentPreferencesService", { enumerable: true, get: function () { return content_preferences_service_1.contentPreferencesService; } });
//# sourceMappingURL=index.js.map