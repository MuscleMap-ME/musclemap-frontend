/**
 * Encrypted Messaging Service
 *
 * Handles server-side operations for E2EE messages:
 * - Storing encrypted messages (server cannot read content)
 * - Message delivery and receipts
 * - Session tracking
 * - Conversation E2EE upgrades
 *
 * IMPORTANT: The server NEVER sees plaintext message content.
 * All encryption/decryption happens client-side.
 */
export interface SendEncryptedMessageInput {
    conversationId: string;
    senderId: string;
    senderDeviceId: string;
    senderFingerprint: string;
    keyExchangeEphemeral?: string;
    keyExchangeOnetimeId?: number;
    ratchetPublicKey: string;
    messageNumber: number;
    previousChainLength: number;
    nonce: string;
    ciphertext: string;
    hasFileAttachment?: boolean;
    contentType?: string;
    nsfwScore?: number;
    nsfwCategory?: string;
    userMarkedAdult?: boolean;
    disappearingTtl?: number;
}
/**
 * Simplified input for GraphQL resolver
 * The encrypted payload is a JSON string containing the full Signal Protocol message
 */
export interface SendEncryptedMessageSimpleInput {
    conversationId: string;
    senderId: string;
    encryptedPayload: string;
    messageType?: string;
    replyToId?: string;
    fileIds?: string[];
}
export interface EncryptedMessage {
    id: string;
    conversationId: string;
    senderId: string;
    senderFingerprint: string;
    senderDeviceId: string;
    protocolVersion: number;
    keyExchangeEphemeral?: string;
    keyExchangeOnetimeId?: number;
    ratchetPublicKey: string;
    messageNumber: number;
    previousChainLength: number;
    nonce: string;
    ciphertext: string;
    hasFileAttachment: boolean;
    contentType: string;
    nsfwScore: number;
    userMarkedAdult: boolean;
    createdAt: Date;
    editedAt?: Date;
    expiresAt?: Date;
    deliveredCount: number;
    readCount: number;
}
export interface EncryptedMessageWithReceipts extends EncryptedMessage {
    deliveredAt?: Date;
    readAt?: Date;
}
export declare const encryptedMessagingService: {
    /**
     * Store an encrypted message
     */
    sendEncryptedMessage(input: SendEncryptedMessageInput): Promise<EncryptedMessage>;
    /**
     * Simplified send function for GraphQL resolver
     * Parses the encrypted payload JSON and calls the full function
     */
    sendEncryptedMessageSimple(input: SendEncryptedMessageSimpleInput): Promise<EncryptedMessage>;
    /**
     * Update session tracking when message is sent
     */
    updateSessionOnMessageSent(client: any, conversationId: string, userId: string, deviceId: string): Promise<void>;
    /**
     * Get encrypted messages in a conversation
     */
    getMessages(conversationId: string, userId: string, options?: {
        cursor?: {
            createdAt: Date;
            id: string;
        };
        limit?: number;
        includeDeleted?: boolean;
    }): Promise<EncryptedMessageWithReceipts[]>;
    /**
     * Get a single encrypted message by ID
     */
    getMessage(messageId: string, userId: string): Promise<EncryptedMessage | null>;
    /**
     * Mark message as delivered
     */
    markDelivered(messageId: string, userId: string, deviceId?: string): Promise<void>;
    /**
     * Mark message as read
     */
    markRead(messageId: string, userId: string): Promise<void>;
    /**
     * Mark all messages in conversation as read
     */
    markConversationRead(conversationId: string, userId: string): Promise<number>;
    /**
     * Delete an encrypted message (soft delete)
     */
    deleteMessage(messageId: string, userId: string): Promise<void>;
    /**
     * Get unread message count for a user
     */
    getUnreadCount(userId: string): Promise<number>;
    /**
     * Get unread count per conversation
     */
    getUnreadCountsByConversation(userId: string): Promise<Map<string, number>>;
    /**
     * Check if a conversation is E2EE enabled
     */
    isConversationE2EE(conversationId: string): Promise<boolean>;
    /**
     * Check if all participants have E2EE enabled
     */
    canUpgradeToE2EE(conversationId: string): Promise<{
        canUpgrade: boolean;
        participantsWithoutE2EE: string[];
    }>;
    /**
     * Upgrade conversation to E2EE
     */
    upgradeConversationToE2EE(conversationId: string): Promise<void>;
    /**
     * Delete expired messages
     */
    cleanupExpiredMessages(): Promise<number>;
    /**
     * Clean up old deleted messages (hard delete after 30 days)
     */
    cleanupDeletedMessages(): Promise<number>;
};
export default encryptedMessagingService;
