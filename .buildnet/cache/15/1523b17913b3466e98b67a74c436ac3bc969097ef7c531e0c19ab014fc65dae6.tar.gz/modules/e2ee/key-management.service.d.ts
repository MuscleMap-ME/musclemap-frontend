/**
 * E2EE Key Management Service
 *
 * Handles server-side key operations:
 * - Storing and retrieving public key bundles
 * - Managing one-time prekeys
 * - Key rotation and cleanup
 * - Multi-device support
 *
 * IMPORTANT: Private keys NEVER touch the server.
 * All private key operations happen client-side.
 */
import { type KeyBundle, type OneTimePreKey } from './crypto';
export interface RegisterKeysInput {
    userId: string;
    deviceId: string;
    deviceName?: string;
    deviceType?: string;
    identityKeyPublic: string;
    signedPreKeyPublic: string;
    signedPreKeySignature: string;
    signedPreKeyId: number;
    oneTimePreKeys?: Array<{
        id: number;
        publicKey: string;
    }>;
}
export interface KeyBundleWithPreKeys extends KeyBundle {
    oneTimePreKeys: OneTimePreKey[];
}
export interface DeviceInfo {
    deviceId: string;
    deviceName?: string;
    deviceType?: string;
    lastActiveAt: Date;
    createdAt: Date;
}
export declare const keyManagementService: {
    /**
     * Register or update encryption keys for a device
     */
    registerKeys(input: RegisterKeysInput): Promise<KeyBundle>;
    /**
     * Upload additional one-time prekeys
     */
    uploadOneTimePreKeys(userId: string, deviceId: string, keys: Array<{
        id: number;
        publicKey: string;
    }>): Promise<number>;
    /**
     * Internal: Upload prekeys within a transaction
     */
    uploadOneTimePreKeysInternal(client: any, userId: string, deviceId: string, keys: Array<{
        id: number;
        publicKey: string;
    }>): Promise<number>;
    /**
     * Get a user's key bundle for initiating encrypted communication
     */
    getKeyBundle(targetUserId: string, requestingUserId?: string): Promise<KeyBundleWithPreKeys | null>;
    /**
     * Get key bundles for all devices of a user
     */
    getAllDeviceKeyBundles(targetUserId: string): Promise<KeyBundle[]>;
    /**
     * Get and consume a one-time prekey (atomic operation)
     */
    getAndConsumeOneTimePreKey(userId: string, deviceId: string, consumingUserId?: string): Promise<OneTimePreKey | null>;
    /**
     * Get available prekey count for a device
     */
    getAvailablePreKeyCount(userId: string, deviceId: string): Promise<number>;
    /**
     * Get all devices for a user
     */
    getUserDevices(userId: string): Promise<DeviceInfo[]>;
    /**
     * Remove a device (and all its keys)
     */
    removeDevice(userId: string, deviceId: string): Promise<void>;
    /**
     * Update device activity timestamp
     */
    updateDeviceActivity(userId: string, deviceId: string): Promise<void>;
    /**
     * Verify a key fingerprint matches what we have stored
     */
    verifyKeyFingerprint(userId: string, deviceId: string, fingerprint: string): Promise<boolean>;
    /**
     * Check if user has E2EE enabled
     */
    isE2EEEnabled(userId: string): Promise<boolean>;
    /**
     * Clean up old used one-time prekeys (keep for 30 days for debugging)
     */
    cleanupUsedPreKeys(): Promise<number>;
    /**
     * Clean up inactive devices (no activity in 90 days)
     */
    cleanupInactiveDevices(): Promise<number>;
    /**
     * Check if signed prekey needs rotation
     */
    checkSignedPreKeyRotation(userId: string, deviceId: string): Promise<boolean>;
    /**
     * Get users who need to replenish one-time prekeys
     */
    getUsersWithLowPreKeys(): Promise<Array<{
        userId: string;
        deviceId: string;
        count: number;
    }>>;
};
export default keyManagementService;
