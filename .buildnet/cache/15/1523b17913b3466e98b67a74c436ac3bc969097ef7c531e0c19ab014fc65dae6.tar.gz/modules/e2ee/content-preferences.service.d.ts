/**
 * Content Preferences & Age Verification Service
 *
 * Handles:
 * - Age verification (self-declaration, payment, ID)
 * - Minor protection enforcement
 * - Adult content preferences
 * - NSFW thresholds and auto-moderation
 * - Messaging privacy settings
 */
export interface ContentPreferences {
    userId: string;
    isMinor: boolean;
    ageVerified: boolean;
    ageVerificationMethod?: 'self' | 'payment' | 'id';
    ageVerifiedAt?: Date;
    allowAdultContent: boolean;
    showAdultContentWarning: boolean;
    canSendAdultContent: boolean;
    displayAge: boolean;
    displayAgeValue?: number;
    nsfwBlockThreshold: number;
    nsfwBlurThreshold: number;
    autoBlockNsfw: boolean;
    autoReportIllegal: boolean;
}
export interface MessagingPrivacy {
    userId: string;
    whoCanMessage: 'everyone' | 'mutuals' | 'friends' | 'nobody';
    whoCanSendFiles: 'everyone' | 'mutuals' | 'friends' | 'nobody';
    whoCanSeeOnline: 'everyone' | 'mutuals' | 'friends' | 'nobody';
    whoCanSeeReadReceipts: 'everyone' | 'mutuals' | 'friends' | 'nobody';
    whoCanSeeTyping: 'everyone' | 'mutuals' | 'friends' | 'nobody';
    requireMessageRequest: boolean;
    autoDeleteMessages: boolean;
    autoDeleteHours: number;
    allowedFileTypes: {
        images: boolean;
        videos: boolean;
        audio: boolean;
        documents: boolean;
    };
    maxFileSizeMb: number;
    e2eeRequired: boolean;
    allowNonE2eeFallback: boolean;
}
export interface TrustScore {
    userId: string;
    trustScore: number;
    accountAgeScore: number;
    verificationScore: number;
    activityScore: number;
    reportScore: number;
    isTrustedSender: boolean;
    isRestricted: boolean;
    isShadowbanned: boolean;
    maxNewConversationsPerDay: number;
    maxMessagesPerMinute: number;
    maxFilesPerDay: number;
    totalReportsReceived: number;
    totalReportsUpheld: number;
    totalReportsDismissed: number;
}
export interface AgeVerificationResult {
    verified: boolean;
    isMinor: boolean;
    method: 'self' | 'payment' | 'id';
    error?: string;
}
export declare const contentPreferencesService: {
    /**
     * Get or create content preferences for a user
     */
    getContentPreferences(userId: string): Promise<ContentPreferences>;
    /**
     * Update content preferences
     */
    updateContentPreferences(userId: string, updates: Partial<Omit<ContentPreferences, "userId" | "isMinor" | "ageVerified" | "ageVerificationMethod" | "ageVerifiedAt">>): Promise<ContentPreferences>;
    /**
     * Verify user's age via self-declaration
     */
    verifyAgeSelfDeclaration(userId: string, dateOfBirth: Date): Promise<AgeVerificationResult>;
    /**
     * Enforce minor restrictions
     */
    enforceMinorRestrictions(userId: string): Promise<void>;
    /**
     * Internal: Enforce minor restrictions within transaction
     */
    enforceMinorRestrictionsInternal(client: any, userId: string): Promise<void>;
    /**
     * Get or create messaging privacy settings
     */
    getMessagingPrivacy(userId: string): Promise<MessagingPrivacy>;
    /**
     * Update messaging privacy settings
     */
    updateMessagingPrivacy(userId: string, updates: Partial<Omit<MessagingPrivacy, "userId">>): Promise<MessagingPrivacy>;
    /**
     * Get or create trust score for a user
     */
    getTrustScore(userId: string): Promise<TrustScore>;
    /**
     * Recalculate trust score for a user
     */
    recalculateTrustScore(userId: string): Promise<TrustScore>;
    /**
     * Check if sender can message recipient
     */
    canMessageUser(senderId: string, recipientId: string): Promise<{
        canMessage: boolean;
        reason?: string;
        requiresRequest: boolean;
    }>;
    /**
     * Check if users are friends
     */
    areFriends(userId1: string, userId2: string): Promise<boolean>;
    /**
     * Check if users are mutual followers
     */
    areMutualFollowers(userId1: string, userId2: string): Promise<boolean>;
    /**
     * Check if sender can send files to recipient
     */
    canSendFiles(senderId: string, recipientId: string): Promise<{
        canSend: boolean;
        reason?: string;
        allowedTypes?: string[];
    }>;
};
export default contentPreferencesService;
