/**
 * E2EE File Storage Service
 *
 * Handles zero-storage file attachments:
 * - Files are encrypted client-side BEFORE upload
 * - Files are stored on external storage (Cloudflare R2)
 * - Server only stores encrypted metadata (cannot read content)
 * - Presigned URLs for direct client upload/download
 *
 * IMPORTANT: Server NEVER sees plaintext file content.
 * All encryption happens client-side.
 */
export interface FileUploadRequest {
    fileName: string;
    fileSize: number;
    mimeType: string;
    encryptedMetadata: string;
    nsfwClassification?: string;
}
export interface FileUploadToken {
    token: string;
    uploadUrl: string;
    expiresAt: Date;
    maxSize: number;
}
export interface FileMetadata {
    id: string;
    uploaderId: string;
    encryptedMetadata: string;
    encryptedKey: string;
    mimeType: string;
    fileSize: number;
    contentHash: string;
    storageUrl: string;
    nsfwClassification: string;
    expiresAt: Date | null;
    createdAt: Date;
}
export declare const fileStorageService: {
    /**
     * Request a presigned upload URL
     * Returns a token and URL for direct client-to-R2 upload
     */
    requestUploadUrl(userId: string, request: FileUploadRequest): Promise<FileUploadToken>;
    /**
     * Confirm upload after client has uploaded to R2
     * Creates the file metadata record
     */
    confirmUpload(userId: string, token: string, encryptedKey: string, contentHash: string): Promise<FileMetadata>;
    /**
     * Get presigned download URL for a file
     */
    getDownloadUrl(fileId: string, userId: string): Promise<string>;
    /**
     * Delete a file (only uploader can delete)
     */
    deleteFile(fileId: string, userId: string): Promise<void>;
    /**
     * Get file metadata by ID
     */
    getFileMetadata(fileId: string): Promise<FileMetadata | null>;
    /**
     * Cleanup expired files from R2
     */
    cleanupExpiredFiles(): Promise<number>;
    /**
     * Cleanup expired upload tokens
     */
    cleanupExpiredTokens(): Promise<number>;
};
export default fileStorageService;
