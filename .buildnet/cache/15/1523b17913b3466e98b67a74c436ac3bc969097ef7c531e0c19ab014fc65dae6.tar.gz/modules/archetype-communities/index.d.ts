/**
 * Archetype Communities Service
 *
 * Handles automatic community joining based on user archetypes:
 * - Link archetypes to default communities
 * - Auto-join users when they select an archetype
 * - Suggest archetype-related communities
 */
export interface ArchetypeCommunityLink {
    id: string;
    archetypeId: string;
    communityId: number;
    isDefault: boolean;
    priority: number;
    createdAt: Date;
}
export interface LinkedCommunity {
    communityId: number;
    communityName: string;
    communityDescription?: string;
    communitySlug: string;
    memberCount: number;
    isDefault: boolean;
    priority: number;
}
export interface ArchetypeSuggestion {
    archetypeId: string;
    archetypeName: string;
    communities: LinkedCommunity[];
}
export declare const archetypeCommunitiesService: {
    /**
     * Link a community to an archetype
     */
    linkCommunity(archetypeId: string, communityId: number, options?: {
        isDefault?: boolean;
        priority?: number;
    }): Promise<ArchetypeCommunityLink>;
    /**
     * Unlink a community from an archetype
     */
    unlinkCommunity(archetypeId: string, communityId: number): Promise<void>;
    /**
     * Get linked communities for an archetype
     */
    getLinkedCommunities(archetypeId: string): Promise<LinkedCommunity[]>;
    /**
     * Get default communities for an archetype (ones to auto-join)
     */
    getDefaultCommunities(archetypeId: string): Promise<LinkedCommunity[]>;
    /**
     * Auto-join user to archetype's default communities
     * Called when user selects an archetype
     */
    autoJoinDefaultCommunities(userId: string, archetypeId: string): Promise<number[]>;
    /**
     * Get suggested communities for a user based on their archetype
     * Excludes communities they're already a member of
     */
    getSuggestedCommunities(userId: string): Promise<LinkedCommunity[]>;
    /**
     * Get all archetypes with their linked communities
     */
    getAllArchetypesWithCommunities(): Promise<ArchetypeSuggestion[]>;
    /**
     * Handle archetype change for a user
     * - Leave old archetype's auto-join communities (optional)
     * - Join new archetype's default communities
     */
    handleArchetypeChange(userId: string, oldArchetypeId: string | null, newArchetypeId: string, options?: {
        leaveOldCommunities?: boolean;
    }): Promise<{
        joined: number[];
        left: number[];
    }>;
    /**
     * Bulk link communities to an archetype (admin function)
     */
    bulkLinkCommunities(archetypeId: string, communityLinks: Array<{
        communityId: number;
        isDefault?: boolean;
        priority?: number;
    }>): Promise<number>;
};
export default archetypeCommunitiesService;
