/**
 * RPE/RIR Analysis Module
 *
 * Provides intelligent workout intensity tracking and recommendations:
 * - RPE (Rate of Perceived Exertion) trend analysis
 * - RIR (Reps in Reserve) tracking
 * - Fatigue detection
 * - Auto-regulation recommendations
 * - Load adjustment suggestions
 */
export declare const RPE_SCALE: {
    readonly 10: {
        readonly description: "Maximum effort - could not do more reps";
        readonly intensity: "maximal";
    };
    readonly 9.5: {
        readonly description: "Could maybe do 1 more rep";
        readonly intensity: "near-maximal";
    };
    readonly 9: {
        readonly description: "Could definitely do 1 more rep";
        readonly intensity: "very hard";
    };
    readonly 8.5: {
        readonly description: "Could do 1-2 more reps";
        readonly intensity: "very hard";
    };
    readonly 8: {
        readonly description: "Could do 2 more reps";
        readonly intensity: "hard";
    };
    readonly 7.5: {
        readonly description: "Could do 2-3 more reps";
        readonly intensity: "hard";
    };
    readonly 7: {
        readonly description: "Could do 3 more reps";
        readonly intensity: "moderate-hard";
    };
    readonly 6.5: {
        readonly description: "Could do 3-4 more reps";
        readonly intensity: "moderate";
    };
    readonly 6: {
        readonly description: "Could do 4+ more reps";
        readonly intensity: "moderate";
    };
    readonly 5: {
        readonly description: "Warm-up / light work";
        readonly intensity: "light";
    };
};
export declare const RIR_TO_RPE: Record<number, number>;
export declare const RPE_TO_RIR: Record<number, number>;
export interface RPETrend {
    exerciseId: string;
    exerciseName?: string;
    date: Date;
    avgRpe: number;
    avgRir: number | null;
    setCount: number;
    avgWeight: number;
    maxWeight: number;
    avgReps: number;
}
export interface WeeklyRPETrend {
    exerciseId: string;
    weekStart: Date;
    avgRpe: number;
    avgRir: number | null;
    totalSets: number;
    rpeVariance: number;
    minRpe: number;
    maxRpe: number;
    avgWeight: number;
    totalVolume: number;
}
export interface FatigueAnalysis {
    userId: string;
    fatigueScore: number;
    classification: 'recovered' | 'fresh' | 'moderate' | 'elevated' | 'high';
    indicators: string[];
    recommendation: string;
    suggestedIntensity: 'light' | 'moderate' | 'hard' | 'maximal';
    recentRpeTrend: 'increasing' | 'stable' | 'decreasing';
}
export interface AutoRegulationSuggestion {
    exerciseId: string;
    exerciseName?: string;
    currentWeight?: number;
    suggestedWeight: number;
    suggestedReps: number;
    targetRpe: number;
    reasoning: string;
    adjustmentPercent: number;
    confidence: 'high' | 'medium' | 'low';
}
export interface RPESnapshot {
    userId: string;
    snapshotDate: Date;
    avgRpe: number;
    avgRir: number | null;
    totalSets: number;
    fatigueScore: number;
    recoveryRecommendation: string;
}
/**
 * Get RPE trends for a specific exercise over time
 */
export declare function getRPETrends(userId: string, exerciseId: string, days?: number): Promise<RPETrend[]>;
/**
 * Get weekly RPE trends for an exercise (for long-term analysis)
 */
export declare function getWeeklyRPETrends(userId: string, exerciseId: string, weeks?: number): Promise<WeeklyRPETrend[]>;
/**
 * Analyze user's current fatigue level based on recent RPE data
 */
export declare function analyzeFatigue(userId: string): Promise<FatigueAnalysis>;
/**
 * Get auto-regulation recommendations for a workout
 * Adjusts weights based on current fatigue and recent performance
 */
export declare function getAutoRegulationSuggestions(userId: string, exerciseIds: string[], targetRpe?: number): Promise<AutoRegulationSuggestion[]>;
/**
 * Get user's default RPE/RIR targets for an exercise
 */
export declare function getExerciseRPETarget(userId: string, exerciseId: string): Promise<{
    rpe: number | null;
    rir: number | null;
}>;
/**
 * Set user's default RPE/RIR targets for an exercise
 */
export declare function setExerciseRPETarget(userId: string, exerciseId: string, rpe: number | null, rir: number | null): Promise<void>;
/**
 * Get RPE info/scale reference
 */
export declare function getRPEScaleInfo(): typeof RPE_SCALE;
/**
 * Create daily RPE snapshot for a user
 */
export declare function createRPESnapshot(userId: string): Promise<RPESnapshot | null>;
/**
 * Get historical RPE snapshots
 */
export declare function getRPESnapshots(userId: string, days?: number): Promise<RPESnapshot[]>;
export declare const rpeService: {
    RPE_SCALE: {
        readonly 10: {
            readonly description: "Maximum effort - could not do more reps";
            readonly intensity: "maximal";
        };
        readonly 9.5: {
            readonly description: "Could maybe do 1 more rep";
            readonly intensity: "near-maximal";
        };
        readonly 9: {
            readonly description: "Could definitely do 1 more rep";
            readonly intensity: "very hard";
        };
        readonly 8.5: {
            readonly description: "Could do 1-2 more reps";
            readonly intensity: "very hard";
        };
        readonly 8: {
            readonly description: "Could do 2 more reps";
            readonly intensity: "hard";
        };
        readonly 7.5: {
            readonly description: "Could do 2-3 more reps";
            readonly intensity: "hard";
        };
        readonly 7: {
            readonly description: "Could do 3 more reps";
            readonly intensity: "moderate-hard";
        };
        readonly 6.5: {
            readonly description: "Could do 3-4 more reps";
            readonly intensity: "moderate";
        };
        readonly 6: {
            readonly description: "Could do 4+ more reps";
            readonly intensity: "moderate";
        };
        readonly 5: {
            readonly description: "Warm-up / light work";
            readonly intensity: "light";
        };
    };
    RIR_TO_RPE: Record<number, number>;
    RPE_TO_RIR: Record<number, number>;
    getRPETrends: typeof getRPETrends;
    getWeeklyRPETrends: typeof getWeeklyRPETrends;
    analyzeFatigue: typeof analyzeFatigue;
    getAutoRegulationSuggestions: typeof getAutoRegulationSuggestions;
    getExerciseRPETarget: typeof getExerciseRPETarget;
    setExerciseRPETarget: typeof setExerciseRPETarget;
    getRPEScaleInfo: typeof getRPEScaleInfo;
    createRPESnapshot: typeof createRPESnapshot;
    getRPESnapshots: typeof getRPESnapshots;
};
export default rpeService;
