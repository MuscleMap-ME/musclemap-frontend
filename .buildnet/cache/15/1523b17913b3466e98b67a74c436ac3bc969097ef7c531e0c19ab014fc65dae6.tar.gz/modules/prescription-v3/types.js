"use strict";
/**
 * Prescription Engine v3.0 - Type Definitions
 *
 * Comprehensive type system for the 16-factor scoring algorithm
 * with support for user biomechanics, adaptive learning, and research-backed effectiveness.
 */
Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=types.js.map