/**
 * Prescription Engine v3.0 - Load Calculator
 *
 * Calculates optimal sets, reps, RPE, and rest periods based on:
 * - User goals and training phase
 * - Exercise type and CNS load
 * - User's performance history
 * - Current recovery state
 * - Research-backed loading protocols
 */
import type { ExerciseMetadataV3, UserExercisePerformance, UserContextV3, Goal } from './types';
export interface LoadRecommendation {
    sets: number;
    reps: number | string;
    rpe: number;
    percentOf1RM?: number;
    restSeconds: number;
    tempo?: string;
    notes: string[];
}
export declare class LoadCalculator {
    /**
     * Calculate optimal load parameters for an exercise
     */
    calculateLoad(exercise: ExerciseMetadataV3, userContext: UserContextV3, userPerformance: UserExercisePerformance | null): LoadRecommendation;
    /**
     * Adjust load for recovery state
     */
    private adjustForRecovery;
    /**
     * Adjust load for exercise characteristics
     */
    private adjustForExercise;
    /**
     * Adjust load for experience level
     */
    private adjustForExperience;
    /**
     * Calculate percentage of 1RM from reps and RPE
     */
    private calculatePercent1RM;
    /**
     * Calculate tempo prescription
     */
    private calculateTempo;
    /**
     * Build contextual notes for the exercise
     */
    private buildNotes;
    /**
     * Calculate rest period between superset exercises
     */
    calculateSupersetRest(exercise1: ExerciseMetadataV3, exercise2: ExerciseMetadataV3): {
        restBetween: number;
        restAfter: number;
    };
    /**
     * Calculate progressive overload suggestion
     */
    getProgressionSuggestion(exercise: ExerciseMetadataV3, performance: UserExercisePerformance | null, goal: Goal): string | null;
}
export declare const loadCalculator: LoadCalculator;
