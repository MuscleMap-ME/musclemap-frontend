/**
 * Prescription Engine v3.0
 *
 * Comprehensive exercise prescription engine with:
 * - 16-factor scoring algorithm
 * - Biomechanical compatibility
 * - Exercise-specific recovery modeling
 * - Adaptive learning from feedback
 * - Multi-layer caching
 * - Research-backed effectiveness ratings
 */
import { ScoringEngineV3, scoringEngine } from './scoring-engine';
import { LoadCalculator, loadCalculator } from './load-calculator';
import { PrescriptionBuilder, prescriptionBuilder } from './prescription-builder';
import { PrescriptionCache, prescriptionCache } from './cache';
import { feedbackCollector, learningSystem, preferenceModeler } from './learning-system';
import type { PrescriptionRequestV3, PrescriptionResultV3 } from './types';
export * from './types';
export declare class PrescriptionEngineV3 {
    private readonly algorithmVersion;
    private scoringEngine;
    private loadCalculator;
    private prescriptionBuilder;
    private cache;
    constructor();
    /**
     * Generate a personalized exercise prescription
     */
    prescribe(request: PrescriptionRequestV3): Promise<PrescriptionResultV3>;
    /**
     * Get exercise metadata (cached)
     */
    private getExerciseMetadata;
    /**
     * Get user exercise performance (cached)
     */
    private getUserPerformance;
    /**
     * Get muscle training stats (cached)
     */
    private getMuscleStats;
    /**
     * Get recent exercise history
     */
    private getRecentExerciseHistory;
    /**
     * Get recovery score from recovery service
     */
    private getRecoveryScore;
    /**
     * Map recovery service score to v3 format
     */
    private mapRecoveryScore;
    /**
     * Generate human-readable reasoning for exercise selection
     */
    private generateReasoning;
    /**
     * Store prescription for feedback collection
     */
    private storePrescriptionHistory;
    /**
     * Get cache metrics for monitoring
     */
    getCacheMetrics(): {
        hits: number;
        misses: number;
        hitRate: number;
        sizes: Record<string, number>;
    };
    /**
     * Invalidate caches on event
     */
    invalidateOnEvent(event: string, userId?: string): Promise<void>;
}
export declare const prescriptionEngineV3: PrescriptionEngineV3;
export { scoringEngine, loadCalculator, prescriptionBuilder, prescriptionCache, feedbackCollector, learningSystem, preferenceModeler, };
export { ScoringEngineV3, LoadCalculator, PrescriptionBuilder, PrescriptionCache, };
