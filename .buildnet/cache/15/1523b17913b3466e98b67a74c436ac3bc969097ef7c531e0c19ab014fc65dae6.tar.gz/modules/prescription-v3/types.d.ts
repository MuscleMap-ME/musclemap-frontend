/**
 * Prescription Engine v3.0 - Type Definitions
 *
 * Comprehensive type system for the 16-factor scoring algorithm
 * with support for user biomechanics, adaptive learning, and research-backed effectiveness.
 */
export type MovementPattern = 'horizontal_push' | 'horizontal_pull' | 'vertical_push' | 'vertical_pull' | 'squat' | 'hip_hinge' | 'lunge' | 'carry' | 'rotation' | 'anti_rotation' | 'flexion' | 'extension' | 'isolation_upper' | 'isolation_lower' | 'plyometric' | 'olympic' | 'mobility' | 'stability';
export type ExperienceLevel = 'beginner' | 'intermediate' | 'advanced' | 'elite';
export type Goal = 'strength' | 'hypertrophy' | 'endurance' | 'power' | 'fat_loss' | 'rehabilitation' | 'flexibility' | 'athletic';
export type TrainingPhase = 'accumulation' | 'intensification' | 'realization' | 'deload' | 'maintenance';
export type RecoveryClassification = 'poor' | 'fair' | 'good' | 'excellent';
export interface UserBiomechanics {
    userId: string;
    heightCm?: number;
    weightKg?: number;
    armSpanCm?: number;
    femurLengthRelative?: 'short' | 'average' | 'long';
    torsoLengthRelative?: 'short' | 'average' | 'long';
    frameSize?: 'small' | 'medium' | 'large';
    somatotype?: 'ectomorph' | 'mesomorph' | 'endomorph' | 'mixed';
    mobilityProfile: {
        shoulderFlexion?: number;
        shoulderInternalRotation?: number;
        hipFlexion?: number;
        ankleFlexion?: number;
        thoracicExtension?: number;
        hamstringLength?: number;
    };
    strengthCurveAnomalies: {
        benchPress?: 'weak_bottom' | 'weak_lockout' | 'balanced';
        squat?: 'weak_hole' | 'weak_lockout' | 'balanced';
        deadlift?: 'weak_floor' | 'weak_lockout' | 'balanced';
    };
}
export interface UserTrainingProfile {
    userId: string;
    trainingAgeYears: number;
    experienceLevel: ExperienceLevel;
    technicalProficiency: Partial<Record<MovementPattern, 1 | 2 | 3 | 4 | 5>>;
    strengthLevels: {
        squat?: number;
        deadlift?: number;
        benchPress?: number;
        overheadPress?: number;
        pullUp?: number;
        row?: number;
    };
    lifetimeWorkouts: number;
    averageSessionsPerWeek: number;
    longestConsistentStreak: number;
    currentStreak: number;
    preferredExerciseStyles: string[];
    dislikedExercises: string[];
    preferredRepRanges: {
        min: number;
        max: number;
    };
    preferredSessionDuration: number;
}
export interface UserHealthProfile {
    userId: string;
    age: number;
    biologicalSex: 'male' | 'female';
    activeInjuries: UserInjury[];
    historicalInjuries: UserInjury[];
    limitations: Limitation[];
    contraindications: string[];
    averageSleepHours: number;
    sleepQualityAvg: number;
    stressLevel: 'low' | 'moderate' | 'high';
    occupationType: 'sedentary' | 'light' | 'moderate' | 'heavy';
    cycleTracking?: {
        enabled: boolean;
        currentPhase?: 'follicular' | 'ovulatory' | 'luteal' | 'menstrual';
        daysIntoCycle?: number;
    };
}
export interface UserInjury {
    injuryProfileId: string;
    name: string;
    severity: 'mild' | 'moderate' | 'severe';
    status: 'active' | 'recovering' | 'resolved';
    affectedJoints: string[];
    contraindicatedMovements: string[];
    startDate: Date;
    expectedRecoveryDate?: Date;
}
export interface Limitation {
    type: 'equipment' | 'mobility' | 'strength' | 'medical' | 'preference';
    description: string;
    affectedExercises: string[];
    severity: 'minor' | 'moderate' | 'major';
}
export interface ExerciseMetadataV3 {
    id: string;
    name: string;
    aliases: string[];
    category: string;
    movementPattern: MovementPattern;
    plane: 'sagittal' | 'frontal' | 'transverse' | 'multi';
    jointActions: JointAction[];
    muscleActivation: {
        primary: MuscleActivation[];
        secondary: MuscleActivation[];
        stabilizers: MuscleActivation[];
    };
    biomechanics: {
        loadingPattern: 'axial' | 'horizontal' | 'rotational' | 'unloaded';
        resistanceCurve: 'ascending' | 'descending' | 'bell' | 'flat';
        stickingPointRom?: number;
        jointStressProfile: Record<string, 'low' | 'moderate' | 'high'>;
    };
    performanceMetrics: {
        cnsLoadFactor: number;
        metabolicDemand: number;
        technicalComplexity: number;
        skillLearningCurve: number;
        balanceRequirement: number;
    };
    recoveryProfile: {
        typicalSorenessHours: number;
        minimumRecoveryHours: number;
        muscleGroupRecoveryFactor: Record<string, number>;
    };
    effectiveness: {
        forStrength: number;
        forHypertrophy: number;
        forPower: number;
        forEndurance: number;
        forRehabilitation: number;
        evidenceLevel: 'low' | 'moderate' | 'high';
        researchCitations: string[];
    };
    requirements: {
        equipment: string[];
        optionalEquipment: string[];
        spaceNeeded: 'minimal' | 'moderate' | 'large';
        noiseLevel: 'silent' | 'quiet' | 'moderate' | 'loud';
        safeForHome: boolean;
    };
    progressionTree: {
        regressions: string[];
        progressions: string[];
        lateralVariations: string[];
    };
    contraindications: {
        injuryTypes: string[];
        conditionTypes: string[];
        ageRestrictions?: {
            minAge?: number;
            maxAge?: number;
        };
        pregnancySafe: boolean;
    };
}
export interface MuscleActivation {
    muscleId: string;
    activation: number;
}
export interface JointAction {
    joint: string;
    action: 'flexion' | 'extension' | 'abduction' | 'adduction' | 'rotation' | 'circumduction';
}
export interface UserExercisePerformance {
    userId: string;
    exerciseId: string;
    estimated1RM?: number;
    recentMaxWeight?: number;
    maxWeightEver?: number;
    bestRepMax: Record<string, number>;
    lifetimeTotalReps: number;
    lifetimeTotalTonnage: number;
    monthlyVolumeTrend: {
        month: string;
        volume: number;
    }[];
    formRating?: number;
    skillProgression: 'learning' | 'competent' | 'proficient' | 'mastered';
    sessionsToCompetency?: number;
    enjoymentRating?: number;
    perceivedDifficulty?: number;
    jointStressExperienced?: number;
    firstPerformedAt?: Date;
    lastPerformedAt?: Date;
    totalSessions: number;
    consecutiveSuccessSessions: number;
}
export interface ScoringWeightsV3 {
    equipmentMatch: number;
    goalEffectiveness: number;
    muscleTargetMatch: number;
    biomechanicalFit: number;
    skillAppropriate: number;
    userPreference: number;
    performanceHistory: number;
    recoveryAppropriate: number;
    injurySafe: number;
    jointStressAcceptable: number;
    periodizationAlignment: number;
    varietyOptimization: number;
    movementPatternBalance: number;
}
export interface ScoringBonus {
    progressionOpportunity: number;
    timeEfficiency: number;
    equipmentOptimization: number;
}
export interface ScoreBreakdownV3 extends ScoringWeightsV3, ScoringBonus {
    totalScore: number;
}
export interface UserContextV3 {
    userId: string;
    biomechanics?: UserBiomechanics;
    trainingProfile?: UserTrainingProfile;
    healthProfile?: UserHealthProfile;
    equipment: string[];
    location: 'home' | 'gym' | 'outdoor' | 'travel';
    timeAvailable: number;
    goals: Goal[];
    currentPhase?: TrainingPhase;
    recoveryScore?: RecoveryScoreV3;
}
export interface RecoveryScoreV3 {
    score: number;
    classification: RecoveryClassification;
    recommendedIntensity: 'rest' | 'light' | 'moderate' | 'normal' | 'high';
    factors: {
        sleepQuality: number;
        muscleReadiness: number;
        stressLevel: number;
        previousWorkoutIntensity: number;
    };
}
export interface PrescriptionRequestV3 {
    userContext: UserContextV3;
    targetMuscles?: string[];
    excludeMuscles?: string[];
    exerciseTypes?: string[];
    maxExercises?: number;
    includeWarmup?: boolean;
    includeCooldown?: boolean;
    includeSupersets?: boolean;
    preferredIntensity?: 'light' | 'moderate' | 'intense';
}
export interface ScoredExerciseV3 {
    exerciseId: string;
    name: string;
    type: string;
    movementPattern: MovementPattern;
    score: number;
    scoreBreakdown: ScoreBreakdownV3;
    sets: number;
    reps: number | string;
    rpe: number;
    percentOf1RM?: number;
    restSeconds: number;
    tempo?: string;
    primaryMuscles: string[];
    secondaryMuscles: string[];
    notes: string[];
    substitutes: SubstituteInfo[];
    reasoning: string;
}
export interface SubstituteInfo {
    exerciseId: string;
    name: string;
    similarityScore: number;
    differenceNotes: string;
    whenToPrefer: string[];
}
export interface SupersetPair {
    exercise1: ScoredExerciseV3;
    exercise2: ScoredExerciseV3;
    restBetween: number;
    restAfter: number;
    rationale: string;
}
export interface PrescriptionResultV3 {
    id: string;
    userId: string;
    exercises: ScoredExerciseV3[];
    warmup: ScoredExerciseV3[];
    cooldown: ScoredExerciseV3[];
    supersets: SupersetPair[];
    targetDuration: number;
    actualDuration: number;
    muscleCoverage: Record<string, number>;
    movementPatternBalance: Record<MovementPattern, number>;
    difficulty: 'easy' | 'moderate' | 'intense' | 'brutal';
    periodizationPhase?: TrainingPhase;
    recoveryAdjusted: boolean;
    metadata: {
        algorithmVersion: string;
        generatedAt: string;
        factorsConsidered: string[];
        recoveryScore?: number;
        cacheHit: boolean;
        generationTimeMs: number;
    };
}
export interface PrescriptionFeedback {
    prescriptionId: string;
    userId: string;
    exercisesPrescribed: number;
    exercisesCompleted: number;
    exercisesSkipped: number;
    exercisesSubstituted: number;
    substitutions: {
        original: string;
        substituted: string;
        reason: string;
    }[];
    overallDifficultyRating: number;
    estimatedTimeMinutes: number;
    actualTimeMinutes: number;
    fatigueAtEnd: number;
    sorenessNextDay?: number;
    overallSatisfaction: number;
    wouldRepeat: boolean;
    freeTextFeedback?: string;
    exerciseFeedback: {
        exerciseId: string;
        tooEasy: boolean;
        tooHard: boolean;
        causedPain: boolean;
        wouldDoAgain: boolean;
    }[];
    createdAt: Date;
}
export interface AdaptiveUserWeights {
    userId: string;
    weightModifiers: Partial<ScoringWeightsV3>;
    preferredPatterns: MovementPattern[];
    avoidedPatterns: MovementPattern[];
    preferredIntensityRange: {
        min: number;
        max: number;
    };
    samplesUsed: number;
    lastUpdated: Date;
    confidence: number;
}
export interface CachedUserContext {
    context: UserContextV3;
    cachedAt: Date;
    ttlSeconds: number;
    invalidateOn: string[];
}
export interface CachedExerciseMetadata {
    exercises: ExerciseMetadataV3[];
    cachedAt: Date;
    ttlSeconds: number;
}
