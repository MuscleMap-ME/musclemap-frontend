/**
 * Prescription Engine v3.0 - Learning System
 *
 * Adaptive learning from user feedback:
 * - Post-workout feedback collection
 * - Preference modeling from behavior
 * - Weight adaptation using reinforcement learning
 * - A/B testing infrastructure
 */
import type { PrescriptionFeedback, AdaptiveUserWeights } from './types';
export declare class FeedbackCollector {
    /**
     * Store prescription feedback
     */
    storeFeedback(feedback: PrescriptionFeedback): Promise<void>;
    /**
     * Update user exercise performance from completed workout
     */
    updateExercisePerformance(userId: string, exerciseId: string, performance: {
        weight?: number;
        reps?: number;
        sets?: number;
        rpe?: number;
        enjoymentRating?: number;
        perceivedDifficulty?: number;
        jointStressExperienced?: number;
        success: boolean;
    }): Promise<void>;
    /**
     * Trigger async learning update
     */
    private triggerLearningUpdate;
}
export declare class AdaptiveLearningSystem {
    private readonly MINIMUM_SAMPLES;
    private readonly LEARNING_RATE;
    /**
     * Update user-specific scoring weights based on feedback patterns
     */
    updateUserWeights(userId: string): Promise<void>;
    /**
     * Get prescription history with feedback
     */
    private getPrescriptionHistory;
    /**
     * Analyze feedback patterns
     */
    private analyzePatterns;
    /**
     * Calculate weight adjustments based on patterns
     */
    private calculateWeightAdjustments;
    /**
     * Store updated user weights
     */
    private storeUserWeights;
    /**
     * Get learned weights for a user
     */
    getUserWeights(userId: string): Promise<AdaptiveUserWeights | null>;
}
export declare class PreferenceModeler {
    /**
     * Infer user preferences from behavior
     */
    buildPreferenceModel(userId: string): Promise<UserPreferences>;
    private getExplicitPreferences;
    private getImplicitPreferences;
    private getPerformanceData;
    private computeExerciseScores;
}
interface ExplicitPreferences {
    favoriteExercises: string[];
    dislikedExercises: string[];
    preferredEquipment: string[];
    avoidedEquipment: string[];
    preferredSessionDuration: number;
}
interface ImplicitPreferences {
    actuallyEnjoyedExercises: string[];
    actuallyDislikedExercises: string[];
    optimalRepRange: {
        min: number;
        max: number;
    };
}
interface UserPreferences {
    explicit: ExplicitPreferences;
    implicit: ImplicitPreferences;
    exerciseScores: Map<string, number>;
}
export declare const feedbackCollector: FeedbackCollector;
export declare const learningSystem: AdaptiveLearningSystem;
export declare const preferenceModeler: PreferenceModeler;
export {};
