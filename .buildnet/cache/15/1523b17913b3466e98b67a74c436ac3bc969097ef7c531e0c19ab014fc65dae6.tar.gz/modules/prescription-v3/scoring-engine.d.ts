/**
 * Prescription Engine v3.0 - Scoring Engine
 *
 * 16-factor scoring algorithm with:
 * - Biomechanical compatibility
 * - Exercise-specific recovery modeling
 * - Research-backed effectiveness ratings
 * - Adaptive user weights from learning system
 */
import type { ExerciseMetadataV3, UserContextV3, UserExercisePerformance, ScoreBreakdownV3, MovementPattern, AdaptiveUserWeights } from './types';
export declare class ScoringEngineV3 {
    private userWeightsCache;
    /**
     * Score a single exercise for a user context
     */
    scoreExercise(exercise: ExerciseMetadataV3, userContext: UserContextV3, userPerformance: UserExercisePerformance | null, recentHistory: Map<string, Date>, muscleStats: Record<string, number>, targetMuscles?: string[], excludeMuscles?: string[], selectedPatterns?: Set<MovementPattern>): ScoreBreakdownV3 | null;
    /**
     * Get scoring weights for a user (defaults + goal adjustments + learned)
     */
    private getWeightsForUser;
    /**
     * Check if user has required equipment
     */
    private checkEquipmentMatch;
    /**
     * Calculate goal effectiveness score based on research-backed ratings
     */
    private calculateGoalEffectiveness;
    /**
     * Calculate muscle target match score
     */
    private calculateMuscleTargetMatch;
    /**
     * Calculate biomechanical fit score based on user proportions and mobility
     */
    private calculateBiomechanicalFit;
    /**
     * Calculate skill appropriateness score
     */
    private calculateSkillAppropriate;
    /**
     * Calculate user preference score based on past feedback
     */
    private calculateUserPreference;
    /**
     * Calculate performance history score
     */
    private calculatePerformanceHistory;
    /**
     * Calculate recovery appropriateness score
     */
    private calculateRecoveryAppropriate;
    /**
     * Calculate injury safety score
     */
    private calculateInjurySafe;
    /**
     * Calculate joint stress acceptability
     */
    private calculateJointStressAcceptable;
    /**
     * Calculate periodization alignment score
     */
    private calculatePeriodizationAlignment;
    /**
     * Calculate variety optimization score
     */
    private calculateVarietyOptimization;
    /**
     * Calculate movement pattern balance score
     */
    private calculateMovementPatternBalance;
    /**
     * Calculate progression opportunity score
     */
    private calculateProgressionOpportunity;
    /**
     * Calculate time efficiency score (superset potential, setup time)
     */
    private calculateTimeEfficiency;
    /**
     * Calculate equipment optimization score
     */
    private calculateEquipmentOptimization;
    /**
     * Load user adaptive weights from cache or database
     */
    loadUserWeights(userId: string, weights: AdaptiveUserWeights | null): Promise<void>;
    /**
     * Clear user weights from cache
     */
    clearUserWeights(userId: string): void;
}
export declare const scoringEngine: ScoringEngineV3;
