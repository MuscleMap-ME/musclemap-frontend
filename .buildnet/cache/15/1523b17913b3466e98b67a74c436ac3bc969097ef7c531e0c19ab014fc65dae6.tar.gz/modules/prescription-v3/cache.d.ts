/**
 * Prescription Engine v3.0 - Caching Layer
 *
 * Multi-layer caching for prescription data:
 * - Memory cache (LRU) for hot paths
 * - Redis cache for persistence
 * - Cache invalidation on relevant events
 */
import type { UserContextV3, ExerciseMetadataV3, UserExercisePerformance, AdaptiveUserWeights } from './types';
export declare class PrescriptionCache {
    private memoryCache;
    private cacheHits;
    private cacheMisses;
    constructor();
    getUserContext(userId: string): Promise<UserContextV3 | null>;
    setUserContext(userId: string, context: UserContextV3): Promise<void>;
    getExerciseMetadata(): Promise<ExerciseMetadataV3[] | null>;
    setExerciseMetadata(exercises: ExerciseMetadataV3[]): Promise<void>;
    getUserPerformance(userId: string): Promise<Map<string, UserExercisePerformance> | null>;
    setUserPerformance(userId: string, performance: Map<string, UserExercisePerformance>): Promise<void>;
    getMuscleStats(userId: string): Promise<Record<string, number> | null>;
    setMuscleStats(userId: string, stats: Record<string, number>): Promise<void>;
    getUserWeights(userId: string): Promise<AdaptiveUserWeights | null>;
    setUserWeights(userId: string, weights: AdaptiveUserWeights): Promise<void>;
    /**
     * Invalidate cache on specific events
     */
    invalidateOn(event: string, userId?: string): Promise<void>;
    /**
     * Invalidate specific cache type
     */
    invalidateCache(cacheType: string, userId?: string): Promise<void>;
    /**
     * Invalidate all caches for a user
     */
    invalidateUserCaches(userId: string): Promise<void>;
    getMetrics(): {
        hits: number;
        misses: number;
        hitRate: number;
        sizes: Record<string, number>;
    };
    resetMetrics(): void;
}
export declare const prescriptionCache: PrescriptionCache;
