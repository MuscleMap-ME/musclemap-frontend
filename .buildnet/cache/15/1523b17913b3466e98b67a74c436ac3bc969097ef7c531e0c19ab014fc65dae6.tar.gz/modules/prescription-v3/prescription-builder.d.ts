/**
 * Prescription Engine v3.0 - Prescription Builder
 *
 * Builds optimized workout prescriptions with:
 * - Intelligent exercise ordering (compounds first, skill-based sequencing)
 * - Superset and circuit optimization
 * - Warmup and cooldown generation
 * - Progressive overload integration
 */
import type { ExerciseMetadataV3, ScoredExerciseV3, UserContextV3, PrescriptionResultV3 } from './types';
import type { UserExercisePerformance } from './types';
export declare class PrescriptionBuilder {
    private loadCalculator;
    constructor();
    /**
     * Build a complete prescription from scored exercises
     */
    buildPrescription(scoredExercises: ScoredExerciseV3[], userContext: UserContextV3, request: {
        maxExercises?: number;
        includeWarmup?: boolean;
        includeCooldown?: boolean;
        includeSupersets?: boolean;
        preferredIntensity?: 'light' | 'moderate' | 'intense';
    }, performanceMap: Map<string, UserExercisePerformance>, allExercises: ExerciseMetadataV3[]): Promise<Omit<PrescriptionResultV3, 'metadata'>>;
    /**
     * Calculate max exercises based on time and goals
     */
    private calculateMaxExercises;
    /**
     * Select exercises ensuring variety and balance
     */
    private selectExercises;
    /**
     * Order exercises for optimal performance
     */
    private orderExercises;
    /**
     * Order by movement priority and CNS load (for strength)
     */
    private orderByPriorityAndCNS;
    /**
     * Order for hypertrophy (pair-friendly)
     */
    private orderForHypertrophy;
    /**
     * Order for circuit training
     */
    private orderForCircuit;
    /**
     * Find optimal superset pairs
     */
    private findSupersets;
    /**
     * Generate warmup exercises
     */
    private generateWarmup;
    /**
     * Generate cooldown exercises
     */
    private generateCooldown;
    /**
     * Add substitute recommendations to exercises
     */
    private addSubstitutes;
    /**
     * Calculate muscle coverage map
     */
    private calculateMuscleCoverage;
    /**
     * Calculate movement pattern balance
     */
    private calculatePatternBalance;
    /**
     * Estimate workout duration
     */
    private estimateDuration;
    /**
     * Determine workout difficulty rating
     */
    private determineDifficulty;
}
export declare const prescriptionBuilder: PrescriptionBuilder;
