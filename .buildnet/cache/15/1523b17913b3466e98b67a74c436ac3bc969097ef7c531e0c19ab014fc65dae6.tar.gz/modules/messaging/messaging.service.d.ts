/**
 * Messaging Service
 *
 * Comprehensive messaging service handling all messaging features:
 * - Core messaging (send, edit, delete)
 * - Typing indicators
 * - Presence (online/offline/away)
 * - Delivery and read receipts
 * - Message reactions
 * - Message search
 * - Voice messages
 * - Link previews
 * - Scheduled messages
 * - Message forwarding and pinning
 * - Rate limiting
 * - Push notifications
 */
export interface Message {
    id: string;
    conversationId: string;
    senderId: string;
    content: string;
    contentType: string;
    replyToId?: string;
    threadRootId?: string;
    forwardedFromId?: string;
    editedAt?: Date;
    pinnedAt?: Date;
    pinnedBy?: string;
    expiresAt?: Date;
    createdAt: Date;
    metadata?: Record<string, unknown>;
}
export interface Conversation {
    id: string;
    type: 'direct' | 'group';
    name?: string;
    createdBy: string;
    disappearingTtl?: number;
    createdAt: Date;
    updatedAt: Date;
    lastMessageAt?: Date;
}
export interface MessageReceipt {
    messageId: string;
    userId: string;
    deliveredAt?: Date;
    readAt?: Date;
}
export interface Reaction {
    id: string;
    messageId: string;
    userId: string;
    emoji: string;
    createdAt: Date;
}
export interface TypingIndicator {
    conversationId: string;
    userId: string;
    username: string;
    avatarUrl?: string;
    isTyping: boolean;
}
export interface UserPresence {
    userId: string;
    status: 'online' | 'away' | 'offline';
    lastSeen?: Date;
    device?: string;
}
export interface LinkPreview {
    url: string;
    title?: string;
    description?: string;
    imageUrl?: string;
    siteName?: string;
    faviconUrl?: string;
}
export interface ScheduledMessage {
    id: string;
    conversationId: string;
    senderId: string;
    content: string;
    contentType: string;
    scheduledFor: Date;
    timezone: string;
    status: 'pending' | 'sent' | 'cancelled';
}
export interface MessageTemplate {
    id: string;
    userId: string;
    name: string;
    content: string;
    shortcut?: string;
    category?: string;
    useCount: number;
}
export interface RateLimitInfo {
    messagesRemaining: number;
    conversationsRemaining: number;
    resetAt: Date;
}
export declare function extractUrls(text: string): string[];
export declare function sendMessage(conversationId: string, senderId: string, content: string, options?: {
    contentType?: string;
    replyToId?: string;
    forwardedFromId?: string;
    metadata?: Record<string, unknown>;
}): Promise<Message>;
export declare function editMessage(messageId: string, userId: string, newContent: string): Promise<Message>;
export declare function deleteMessage(messageId: string, userId: string): Promise<boolean>;
export declare function setTypingStatus(conversationId: string, userId: string, isTyping: boolean): Promise<void>;
export declare function getTypingUsers(conversationId: string): Promise<TypingIndicator[]>;
export declare function updatePresence(userId: string, status: 'online' | 'away' | 'offline', device?: string): Promise<void>;
export declare function getPresence(userId: string): Promise<UserPresence>;
export declare function getBulkPresence(userIds: string[]): Promise<Map<string, UserPresence>>;
export declare function markDelivered(messageId: string, userId: string): Promise<void>;
export declare function markRead(conversationId: string, userId: string): Promise<void>;
export declare function getMessageReceipts(messageId: string): Promise<MessageReceipt[]>;
export declare function addReaction(messageId: string, userId: string, emoji: string): Promise<Reaction>;
export declare function removeReaction(messageId: string, userId: string, emoji: string): Promise<boolean>;
export declare function getReactions(messageId: string): Promise<{
    emoji: string;
    count: number;
    users: string[];
    hasReacted?: boolean;
}[]>;
export declare function searchMessages(userId: string, query: string, options?: {
    conversationId?: string;
    fromUserId?: string;
    startDate?: Date;
    endDate?: Date;
    limit?: number;
    offset?: number;
}): Promise<{
    messages: Message[];
    total: number;
}>;
export declare function getLinkPreview(url: string): Promise<LinkPreview | null>;
export declare function saveLinkPreview(preview: LinkPreview): Promise<void>;
export declare function forwardMessage(messageId: string, userId: string, toConversationIds: string[], addComment?: string): Promise<Message[]>;
export declare function pinMessage(messageId: string, userId: string): Promise<Message>;
export declare function unpinMessage(messageId: string, userId: string): Promise<boolean>;
export declare function getPinnedMessages(conversationId: string): Promise<Message[]>;
export declare function scheduleMessage(conversationId: string, senderId: string, content: string, scheduledFor: Date, timezone?: string): Promise<ScheduledMessage>;
export declare function cancelScheduledMessage(scheduledId: string, userId: string): Promise<boolean>;
export declare function getScheduledMessages(userId: string): Promise<ScheduledMessage[]>;
export declare function processScheduledMessages(): Promise<number>;
export declare function createTemplate(userId: string, name: string, content: string, options?: {
    shortcut?: string;
    category?: string;
}): Promise<MessageTemplate>;
export declare function getTemplates(userId: string): Promise<MessageTemplate[]>;
export declare function useTemplate(templateId: string): Promise<string>;
export declare function checkRateLimit(userId: string): Promise<RateLimitInfo>;
export declare function incrementRateLimit(userId: string, type: 'message' | 'conversation'): Promise<void>;
export declare function deductCredits(userId: string, amount: number): Promise<boolean>;
export declare function registerPushSubscription(userId: string, endpoint: string, keys: {
    p256dh: string;
    auth: string;
}, deviceType?: string, deviceName?: string): Promise<void>;
export declare function unregisterPushSubscription(userId: string, endpoint: string): Promise<void>;
export declare function getMessageAnalytics(userId: string, startDate: Date, endDate: Date): Promise<{
    totalSent: number;
    totalReceived: number;
    avgResponseTime?: number;
    dailyStats: Array<{
        date: string;
        sent: number;
        received: number;
    }>;
}>;
export declare function setDisappearingMessages(conversationId: string, userId: string, ttlSeconds: number | null): Promise<void>;
export declare function cleanupExpiredMessages(): Promise<number>;
export declare function archiveConversation(conversationId: string, userId: string): Promise<void>;
export declare function unarchiveConversation(conversationId: string, userId: string): Promise<void>;
export declare function starConversation(conversationId: string, userId: string): Promise<void>;
export declare function unstarConversation(conversationId: string, userId: string): Promise<void>;
export declare function shareContent(conversationId: string, senderId: string, contentType: 'workout' | 'achievement' | 'challenge' | 'profile', contentId: string, previewData?: Record<string, unknown>): Promise<Message>;
export declare function reportMessage(messageId: string, reporterId: string, reason: string, details?: string): Promise<void>;
