"use strict";
/**
 * Messaging Service
 *
 * Comprehensive messaging service handling all messaging features:
 * - Core messaging (send, edit, delete)
 * - Typing indicators
 * - Presence (online/offline/away)
 * - Delivery and read receipts
 * - Message reactions
 * - Message search
 * - Voice messages
 * - Link previews
 * - Scheduled messages
 * - Message forwarding and pinning
 * - Rate limiting
 * - Push notifications
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.extractUrls = extractUrls;
exports.sendMessage = sendMessage;
exports.editMessage = editMessage;
exports.deleteMessage = deleteMessage;
exports.setTypingStatus = setTypingStatus;
exports.getTypingUsers = getTypingUsers;
exports.updatePresence = updatePresence;
exports.getPresence = getPresence;
exports.getBulkPresence = getBulkPresence;
exports.markDelivered = markDelivered;
exports.markRead = markRead;
exports.getMessageReceipts = getMessageReceipts;
exports.addReaction = addReaction;
exports.removeReaction = removeReaction;
exports.getReactions = getReactions;
exports.searchMessages = searchMessages;
exports.getLinkPreview = getLinkPreview;
exports.saveLinkPreview = saveLinkPreview;
exports.forwardMessage = forwardMessage;
exports.pinMessage = pinMessage;
exports.unpinMessage = unpinMessage;
exports.getPinnedMessages = getPinnedMessages;
exports.scheduleMessage = scheduleMessage;
exports.cancelScheduledMessage = cancelScheduledMessage;
exports.getScheduledMessages = getScheduledMessages;
exports.processScheduledMessages = processScheduledMessages;
exports.createTemplate = createTemplate;
exports.getTemplates = getTemplates;
exports.useTemplate = useTemplate;
exports.checkRateLimit = checkRateLimit;
exports.incrementRateLimit = incrementRateLimit;
exports.deductCredits = deductCredits;
exports.registerPushSubscription = registerPushSubscription;
exports.unregisterPushSubscription = unregisterPushSubscription;
exports.getMessageAnalytics = getMessageAnalytics;
exports.setDisappearingMessages = setDisappearingMessages;
exports.cleanupExpiredMessages = cleanupExpiredMessages;
exports.archiveConversation = archiveConversation;
exports.unarchiveConversation = unarchiveConversation;
exports.starConversation = starConversation;
exports.unstarConversation = unstarConversation;
exports.shareContent = shareContent;
exports.reportMessage = reportMessage;
const crypto_1 = __importDefault(require("crypto"));
const client_1 = require("../../db/client");
const redis_1 = require("../../lib/redis");
const pubsub_1 = require("../../lib/pubsub");
const logger_1 = require("../../lib/logger");
const log = logger_1.loggers.core;
// ============================================
// CONSTANTS
// ============================================
const RATE_LIMITS = {
    MESSAGES_PER_MINUTE: 60,
    CONVERSATIONS_PER_DAY: 20,
    MAX_GROUP_PARTICIPANTS: 50,
    MESSAGE_EDIT_WINDOW_MS: 15 * 60 * 1000, // 15 minutes
    MAX_EDITS_PER_MESSAGE: 5,
    TYPING_TTL_SECONDS: 5,
    PRESENCE_TTL_SECONDS: 60,
    PRESENCE_AWAY_THRESHOLD_MS: 5 * 60 * 1000, // 5 minutes
    MAX_PINNED_MESSAGES: 10,
    MESSAGE_COST_CREDITS: 0.1,
};
const REDIS_KEYS_MESSAGING = {
    TYPING: (convId, userId) => `typing:${convId}:${userId}`,
    TYPING_CONV: (convId) => `typing:${convId}:*`,
    PRESENCE: (userId) => `presence:${userId}`,
    RATE_LIMIT: (userId) => `ratelimit:msg:${userId}`,
    LINK_PREVIEW: (url) => `linkpreview:${Buffer.from(url).toString('base64').slice(0, 50)}`,
};
// ============================================
// UTILITY FUNCTIONS
// ============================================
function generateId(prefix) {
    return `${prefix}_${crypto_1.default.randomBytes(12).toString('hex')}`;
}
function sanitizeContent(content) {
    // Basic XSS prevention
    return content
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#x27;');
}
// Exported for use by link preview feature
function extractUrls(text) {
    const urlRegex = /https?:\/\/[^\s<>"\[\]{}|\\^`]+/gi;
    return text.match(urlRegex) || [];
}
// ============================================
// CORE MESSAGING
// ============================================
async function sendMessage(conversationId, senderId, content, options = {}) {
    const now = new Date();
    const messageId = generateId('msg');
    // Get conversation to check for disappearing messages
    const conversation = await (0, client_1.queryOne)(`SELECT disappearing_ttl FROM conversations WHERE id = $1`, [conversationId]);
    let expiresAt = null;
    if (conversation?.disappearing_ttl) {
        expiresAt = new Date(now.getTime() + conversation.disappearing_ttl * 1000);
    }
    // Insert message
    await (0, client_1.query)(`INSERT INTO messages (
      id, conversation_id, sender_id, content, content_type,
      reply_to_id, forwarded_from_id, expires_at, created_at, metadata
    ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)`, [
        messageId,
        conversationId,
        senderId,
        sanitizeContent(content),
        options.contentType || 'text',
        options.replyToId || null,
        options.forwardedFromId || null,
        expiresAt,
        now.toISOString(),
        options.metadata ? JSON.stringify(options.metadata) : null,
    ]);
    // Update conversation last_message_at
    await (0, client_1.query)(`UPDATE conversations SET last_message_at = $1, updated_at = $1 WHERE id = $2`, [now.toISOString(), conversationId]);
    // Update reply count if this is a thread reply
    if (options.replyToId) {
        await (0, client_1.query)(`UPDATE messages SET reply_count = reply_count + 1 WHERE id = $1`, [options.replyToId]);
    }
    // Get participants for receipts and notifications
    const participants = await (0, client_1.queryAll)(`SELECT user_id FROM conversation_participants WHERE conversation_id = $1 AND user_id != $2`, [conversationId, senderId]);
    // Create delivery receipts for all participants
    for (const participant of participants) {
        await (0, client_1.query)(`INSERT INTO message_receipts (message_id, user_id)
       VALUES ($1, $2)
       ON CONFLICT (message_id, user_id) DO NOTHING`, [messageId, participant.user_id]);
    }
    // Update analytics
    await updateMessageAnalytics(senderId, 'sent');
    // Publish message event
    await (0, pubsub_1.publish)(pubsub_1.PUBSUB_CHANNELS.MESSAGE_RECEIVED, {
        id: messageId,
        conversationId,
        senderId,
        content: sanitizeContent(content),
        contentType: options.contentType || 'text',
        replyToId: options.replyToId,
        createdAt: now.toISOString(),
    });
    // Publish conversation update
    await (0, pubsub_1.publish)(pubsub_1.PUBSUB_CHANNELS.CONVERSATION_UPDATED, {
        id: conversationId,
        participantIds: [senderId, ...participants.map((p) => p.user_id)],
        lastMessageId: messageId,
        updatedAt: now.toISOString(),
    });
    // Queue push notifications for offline users
    await queuePushNotifications(conversationId, senderId, content, participants.map((p) => p.user_id));
    return {
        id: messageId,
        conversationId,
        senderId,
        content: sanitizeContent(content),
        contentType: options.contentType || 'text',
        replyToId: options.replyToId,
        forwardedFromId: options.forwardedFromId,
        expiresAt: expiresAt || undefined,
        createdAt: now,
    };
}
async function editMessage(messageId, userId, newContent) {
    // Get existing message
    const message = await (0, client_1.queryOne)(`SELECT * FROM messages WHERE id = $1 AND deleted_at IS NULL`, [messageId]);
    if (!message) {
        throw new Error('Message not found');
    }
    if (message.sender_id !== userId) {
        throw new Error('Can only edit your own messages');
    }
    // Check edit window
    const messageAge = Date.now() - new Date(message.created_at).getTime();
    if (messageAge > RATE_LIMITS.MESSAGE_EDIT_WINDOW_MS) {
        throw new Error('Edit window has expired (15 minutes)');
    }
    // Check edit count
    if (message.edit_count >= RATE_LIMITS.MAX_EDITS_PER_MESSAGE) {
        throw new Error(`Maximum edits (${RATE_LIMITS.MAX_EDITS_PER_MESSAGE}) reached`);
    }
    const now = new Date();
    const originalContent = message.original_content || message.content;
    await (0, client_1.query)(`UPDATE messages
     SET content = $1, original_content = $2, edit_count = edit_count + 1, edited_at = $3
     WHERE id = $4`, [sanitizeContent(newContent), originalContent, now.toISOString(), messageId]);
    // Publish edit event
    await (0, pubsub_1.publish)(pubsub_1.PUBSUB_CHANNELS.MESSAGE_RECEIVED, {
        id: messageId,
        conversationId: message.conversation_id,
        senderId: userId,
        content: sanitizeContent(newContent),
        edited: true,
        editedAt: now.toISOString(),
    });
    return {
        id: messageId,
        conversationId: message.conversation_id,
        senderId: userId,
        content: sanitizeContent(newContent),
        contentType: 'text',
        editedAt: now,
        createdAt: message.created_at,
    };
}
async function deleteMessage(messageId, userId) {
    const message = await (0, client_1.queryOne)(`SELECT sender_id, conversation_id FROM messages WHERE id = $1`, [messageId]);
    if (!message) {
        throw new Error('Message not found');
    }
    if (message.sender_id !== userId) {
        throw new Error('Can only delete your own messages');
    }
    await (0, client_1.query)(`UPDATE messages SET deleted_at = NOW() WHERE id = $1`, [messageId]);
    // Publish deletion event
    await (0, pubsub_1.publish)(pubsub_1.PUBSUB_CHANNELS.MESSAGE_RECEIVED, {
        id: messageId,
        conversationId: message.conversation_id,
        deleted: true,
    });
    return true;
}
// ============================================
// TYPING INDICATORS
// ============================================
async function setTypingStatus(conversationId, userId, isTyping) {
    const redis = (0, redis_1.getRedis)();
    if (redis && (0, redis_1.isRedisAvailable)()) {
        const key = REDIS_KEYS_MESSAGING.TYPING(conversationId, userId);
        if (isTyping) {
            // Get user info for the indicator
            const user = await (0, client_1.queryOne)(`SELECT username, avatar_url FROM users WHERE id = $1`, [userId]);
            await redis.setex(key, RATE_LIMITS.TYPING_TTL_SECONDS, JSON.stringify({
                username: user?.username,
                avatarUrl: user?.avatar_url,
                startedAt: Date.now(),
            }));
        }
        else {
            await redis.del(key);
        }
        // Publish typing event
        await (0, pubsub_1.publish)('pubsub:typing', {
            conversationId,
            userId,
            isTyping,
        });
    }
    else {
        // Fallback: store in database (less efficient but functional)
        if (isTyping) {
            await (0, client_1.query)(`INSERT INTO typing_indicators (conversation_id, user_id, started_at)
         VALUES ($1, $2, NOW())
         ON CONFLICT (conversation_id, user_id) DO UPDATE SET started_at = NOW()`, [conversationId, userId]);
        }
        else {
            await (0, client_1.query)(`DELETE FROM typing_indicators WHERE conversation_id = $1 AND user_id = $2`, [conversationId, userId]);
        }
    }
}
async function getTypingUsers(conversationId) {
    const redis = (0, redis_1.getRedis)();
    if (redis && (0, redis_1.isRedisAvailable)()) {
        // Use SCAN instead of KEYS to avoid blocking Redis in production
        // KEYS is O(n) and blocks the single-threaded Redis server
        const indicators = [];
        const pattern = `typing:${conversationId}:*`;
        let cursor = '0';
        do {
            const [nextCursor, keys] = await redis.scan(cursor, 'MATCH', pattern, 'COUNT', 100);
            cursor = nextCursor;
            if (keys.length > 0) {
                // Batch fetch all keys at once using MGET
                const values = await redis.mget(...keys);
                for (let i = 0; i < keys.length; i++) {
                    const data = values[i];
                    if (data) {
                        try {
                            const parsed = JSON.parse(data);
                            const userId = keys[i].split(':')[2];
                            indicators.push({
                                conversationId,
                                userId,
                                username: parsed.username,
                                avatarUrl: parsed.avatarUrl,
                                isTyping: true,
                            });
                        }
                        catch {
                            // Skip malformed data
                        }
                    }
                }
            }
        } while (cursor !== '0');
        return indicators;
    }
    else {
        // Fallback: query database
        const results = await (0, client_1.queryAll)(`SELECT ti.user_id, u.username, u.avatar_url
       FROM typing_indicators ti
       JOIN users u ON ti.user_id = u.id
       WHERE ti.conversation_id = $1
         AND ti.started_at > NOW() - INTERVAL '5 seconds'`, [conversationId]);
        return results.map((r) => ({
            conversationId,
            userId: r.user_id,
            username: r.username,
            avatarUrl: r.avatar_url,
            isTyping: true,
        }));
    }
}
// ============================================
// PRESENCE SYSTEM
// ============================================
async function updatePresence(userId, status, device) {
    const redis = (0, redis_1.getRedis)();
    const now = new Date();
    // Update database
    await (0, client_1.query)(`UPDATE users SET last_active_at = $1 WHERE id = $2`, [now.toISOString(), userId]);
    if (redis && (0, redis_1.isRedisAvailable)()) {
        const key = REDIS_KEYS_MESSAGING.PRESENCE(userId);
        if (status === 'offline') {
            await redis.del(key);
        }
        else {
            await redis.setex(key, RATE_LIMITS.PRESENCE_TTL_SECONDS, JSON.stringify({
                status,
                lastSeen: now.toISOString(),
                device: device || 'web',
            }));
        }
        // Publish presence event
        await (0, pubsub_1.publish)('pubsub:presence', {
            userId,
            status,
            lastSeen: now.toISOString(),
        });
    }
}
async function getPresence(userId) {
    const redis = (0, redis_1.getRedis)();
    if (redis && (0, redis_1.isRedisAvailable)()) {
        const key = REDIS_KEYS_MESSAGING.PRESENCE(userId);
        const data = await redis.get(key);
        if (data) {
            const parsed = JSON.parse(data);
            return {
                userId,
                status: parsed.status,
                lastSeen: new Date(parsed.lastSeen),
                device: parsed.device,
            };
        }
    }
    // Fallback: check database
    const user = await (0, client_1.queryOne)(`SELECT last_active_at, presence_visible FROM users WHERE id = $1`, [userId]);
    if (!user || !user.presence_visible) {
        return { userId, status: 'offline' };
    }
    if (!user.last_active_at) {
        return { userId, status: 'offline' };
    }
    const timeSinceActive = Date.now() - new Date(user.last_active_at).getTime();
    if (timeSinceActive < RATE_LIMITS.PRESENCE_AWAY_THRESHOLD_MS) {
        return { userId, status: 'online', lastSeen: user.last_active_at };
    }
    else if (timeSinceActive < RATE_LIMITS.PRESENCE_TTL_SECONDS * 1000) {
        return { userId, status: 'away', lastSeen: user.last_active_at };
    }
    return { userId, status: 'offline', lastSeen: user.last_active_at };
}
async function getBulkPresence(userIds) {
    const presenceMap = new Map();
    if (userIds.length === 0) {
        return presenceMap;
    }
    const redis = (0, redis_1.getRedis)();
    if (redis && (0, redis_1.isRedisAvailable)()) {
        // Batch fetch from Redis using MGET
        const keys = userIds.map((id) => REDIS_KEYS_MESSAGING.PRESENCE(id));
        const values = await redis.mget(...keys);
        for (let i = 0; i < userIds.length; i++) {
            const userId = userIds[i];
            const data = values[i];
            if (data) {
                try {
                    const parsed = JSON.parse(data);
                    presenceMap.set(userId, {
                        userId,
                        status: parsed.status,
                        lastSeen: new Date(parsed.lastSeen),
                        device: parsed.device,
                    });
                }
                catch {
                    presenceMap.set(userId, { userId, status: 'offline' });
                }
            }
            else {
                presenceMap.set(userId, { userId, status: 'offline' });
            }
        }
    }
    else {
        // Batch fetch from database
        const users = await (0, client_1.queryAll)(`SELECT id, last_active_at, COALESCE(presence_visible, true) as presence_visible
       FROM users WHERE id = ANY($1)`, [userIds]);
        const userMap = new Map(users.map((u) => [u.id, u]));
        for (const userId of userIds) {
            const user = userMap.get(userId);
            if (!user || !user.presence_visible || !user.last_active_at) {
                presenceMap.set(userId, { userId, status: 'offline' });
            }
            else {
                const timeSinceActive = Date.now() - new Date(user.last_active_at).getTime();
                if (timeSinceActive < RATE_LIMITS.PRESENCE_AWAY_THRESHOLD_MS) {
                    presenceMap.set(userId, { userId, status: 'online', lastSeen: user.last_active_at });
                }
                else if (timeSinceActive < RATE_LIMITS.PRESENCE_TTL_SECONDS * 1000) {
                    presenceMap.set(userId, { userId, status: 'away', lastSeen: user.last_active_at });
                }
                else {
                    presenceMap.set(userId, { userId, status: 'offline', lastSeen: user.last_active_at });
                }
            }
        }
    }
    return presenceMap;
}
// ============================================
// DELIVERY & READ RECEIPTS
// ============================================
async function markDelivered(messageId, userId) {
    await (0, client_1.query)(`UPDATE message_receipts SET delivered_at = NOW()
     WHERE message_id = $1 AND user_id = $2 AND delivered_at IS NULL`, [messageId, userId]);
    // Publish delivery event
    const message = await (0, client_1.queryOne)(`SELECT conversation_id, sender_id FROM messages WHERE id = $1`, [messageId]);
    if (message) {
        await (0, pubsub_1.publish)('pubsub:delivery', {
            messageId,
            conversationId: message.conversation_id,
            senderId: message.sender_id,
            userId,
            deliveredAt: new Date().toISOString(),
        });
    }
}
async function markRead(conversationId, userId) {
    const now = new Date();
    // Update conversation participant's last_read_at
    await (0, client_1.query)(`UPDATE conversation_participants SET last_read_at = $1
     WHERE conversation_id = $2 AND user_id = $3`, [now.toISOString(), conversationId, userId]);
    // Update all unread message receipts
    await (0, client_1.query)(`UPDATE message_receipts mr
     SET read_at = $1
     FROM messages m
     WHERE mr.message_id = m.id
       AND m.conversation_id = $2
       AND mr.user_id = $3
       AND mr.read_at IS NULL`, [now.toISOString(), conversationId, userId]);
    // Update analytics
    await updateMessageAnalytics(userId, 'received');
    // Publish read event
    await (0, pubsub_1.publish)('pubsub:read', {
        conversationId,
        userId,
        readAt: now.toISOString(),
    });
}
async function getMessageReceipts(messageId) {
    const receipts = await (0, client_1.queryAll)(`SELECT * FROM message_receipts WHERE message_id = $1`, [messageId]);
    return receipts.map((r) => ({
        messageId: r.message_id,
        userId: r.user_id,
        deliveredAt: r.delivered_at || undefined,
        readAt: r.read_at || undefined,
    }));
}
// ============================================
// MESSAGE REACTIONS
// ============================================
async function addReaction(messageId, userId, emoji) {
    const id = generateId('rxn');
    await (0, client_1.query)(`INSERT INTO message_reactions (id, message_id, user_id, emoji)
     VALUES ($1, $2, $3, $4)
     ON CONFLICT (message_id, user_id, emoji) DO NOTHING`, [id, messageId, userId, emoji]);
    const message = await (0, client_1.queryOne)(`SELECT conversation_id FROM messages WHERE id = $1`, [messageId]);
    // Publish reaction event
    await (0, pubsub_1.publish)('pubsub:reaction', {
        messageId,
        conversationId: message?.conversation_id,
        userId,
        emoji,
        action: 'add',
    });
    return {
        id,
        messageId,
        userId,
        emoji,
        createdAt: new Date(),
    };
}
async function removeReaction(messageId, userId, emoji) {
    await (0, client_1.query)(`DELETE FROM message_reactions WHERE message_id = $1 AND user_id = $2 AND emoji = $3`, [messageId, userId, emoji]);
    const message = await (0, client_1.queryOne)(`SELECT conversation_id FROM messages WHERE id = $1`, [messageId]);
    // Publish reaction event
    await (0, pubsub_1.publish)('pubsub:reaction', {
        messageId,
        conversationId: message?.conversation_id,
        userId,
        emoji,
        action: 'remove',
    });
    return true;
}
async function getReactions(messageId) {
    const reactions = await (0, client_1.queryAll)(`SELECT emoji, array_agg(user_id) as user_ids
     FROM message_reactions
     WHERE message_id = $1
     GROUP BY emoji
     ORDER BY MIN(created_at)`, [messageId]);
    return reactions.map((r) => ({
        emoji: r.emoji,
        count: r.user_ids.length,
        users: r.user_ids,
    }));
}
// ============================================
// MESSAGE SEARCH
// ============================================
async function searchMessages(userId, query, options = {}) {
    const limit = Math.min(options.limit || 20, 100);
    const offset = options.offset || 0;
    let sql = `
    SELECT m.*, u.username as sender_username,
           ts_headline('english', m.content, plainto_tsquery('english', $1), 'MaxWords=50, MinWords=20') as highlight,
           ts_rank(m.search_vector, plainto_tsquery('english', $1)) as rank
    FROM messages m
    JOIN conversation_participants cp ON m.conversation_id = cp.conversation_id AND cp.user_id = $2
    JOIN users u ON m.sender_id = u.id
    WHERE m.search_vector @@ plainto_tsquery('english', $1)
      AND m.deleted_at IS NULL
  `;
    const params = [query, userId];
    if (options.conversationId) {
        params.push(options.conversationId);
        sql += ` AND m.conversation_id = $${params.length}`;
    }
    if (options.fromUserId) {
        params.push(options.fromUserId);
        sql += ` AND m.sender_id = $${params.length}`;
    }
    if (options.startDate) {
        params.push(options.startDate);
        sql += ` AND m.created_at >= $${params.length}`;
    }
    if (options.endDate) {
        params.push(options.endDate);
        sql += ` AND m.created_at <= $${params.length}`;
    }
    sql += ` ORDER BY rank DESC, m.created_at DESC`;
    // Get total count
    const countSql = sql.replace(/SELECT m\.\*, u\.username.*rank/, 'SELECT COUNT(*) as total');
    const countResult = await (0, client_1.queryOne)(countSql, params);
    const total = parseInt(countResult?.total || '0', 10);
    // Get paginated results
    params.push(limit, offset);
    sql += ` LIMIT $${params.length - 1} OFFSET $${params.length}`;
    const results = await (0, client_1.queryAll)(sql, params);
    return {
        messages: results.map((r) => ({
            id: r.id,
            conversationId: r.conversation_id,
            senderId: r.sender_id,
            content: r.content,
            contentType: r.content_type,
            createdAt: r.created_at,
            metadata: { highlight: r.highlight, senderUsername: r.sender_username },
        })),
        total,
    };
}
// ============================================
// LINK PREVIEWS
// ============================================
async function getLinkPreview(url) {
    // Check cache first
    const redis = (0, redis_1.getRedis)();
    if (redis && (0, redis_1.isRedisAvailable)()) {
        const cached = await redis.get(REDIS_KEYS_MESSAGING.LINK_PREVIEW(url));
        if (cached) {
            return JSON.parse(cached);
        }
    }
    // Check database cache
    const dbCached = await (0, client_1.queryOne)(`SELECT * FROM link_previews WHERE url = $1 AND expires_at > NOW()`, [url]);
    if (dbCached) {
        const preview = {
            url,
            title: dbCached.title,
            description: dbCached.description,
            imageUrl: dbCached.image_url,
            siteName: dbCached.site_name,
            faviconUrl: dbCached.favicon_url,
        };
        // Cache in Redis
        if (redis && (0, redis_1.isRedisAvailable)()) {
            await redis.setex(REDIS_KEYS_MESSAGING.LINK_PREVIEW(url), 3600, JSON.stringify(preview));
        }
        return preview;
    }
    return null;
}
async function saveLinkPreview(preview) {
    await (0, client_1.query)(`INSERT INTO link_previews (url, title, description, image_url, site_name, favicon_url, fetched_at, expires_at)
     VALUES ($1, $2, $3, $4, $5, $6, NOW(), NOW() + INTERVAL '7 days')
     ON CONFLICT (url) DO UPDATE SET
       title = $2, description = $3, image_url = $4, site_name = $5, favicon_url = $6,
       fetched_at = NOW(), expires_at = NOW() + INTERVAL '7 days'`, [
        preview.url,
        preview.title,
        preview.description,
        preview.imageUrl,
        preview.siteName,
        preview.faviconUrl,
    ]);
    // Cache in Redis
    const redis = (0, redis_1.getRedis)();
    if (redis && (0, redis_1.isRedisAvailable)()) {
        await redis.setex(REDIS_KEYS_MESSAGING.LINK_PREVIEW(preview.url), 3600, JSON.stringify(preview));
    }
}
// ============================================
// MESSAGE FORWARDING
// ============================================
async function forwardMessage(messageId, userId, toConversationIds, addComment) {
    const originalMessage = await (0, client_1.queryOne)(`SELECT * FROM messages WHERE id = $1 AND deleted_at IS NULL`, [messageId]);
    if (!originalMessage) {
        throw new Error('Message not found');
    }
    // Verify user has access to original message
    const hasAccess = await (0, client_1.queryOne)(`SELECT 1 FROM conversation_participants WHERE conversation_id = $1 AND user_id = $2`, [originalMessage.conversation_id, userId]);
    if (!hasAccess) {
        throw new Error('No access to original message');
    }
    const forwardedMessages = [];
    for (const convId of toConversationIds) {
        // Verify user is participant in destination
        const isParticipant = await (0, client_1.queryOne)(`SELECT 1 FROM conversation_participants WHERE conversation_id = $1 AND user_id = $2`, [convId, userId]);
        if (!isParticipant) {
            continue;
        }
        // Send optional comment first
        if (addComment) {
            await sendMessage(convId, userId, addComment);
        }
        // Send forwarded message
        const forwarded = await sendMessage(convId, userId, originalMessage.content, {
            contentType: originalMessage.content_type,
            forwardedFromId: messageId,
        });
        forwardedMessages.push(forwarded);
    }
    return forwardedMessages;
}
// ============================================
// MESSAGE PINNING
// ============================================
async function pinMessage(messageId, userId) {
    const message = await (0, client_1.queryOne)(`SELECT conversation_id, pinned_at FROM messages WHERE id = $1`, [messageId]);
    if (!message) {
        throw new Error('Message not found');
    }
    if (message.pinned_at) {
        throw new Error('Message is already pinned');
    }
    // Check user has permission (owner or moderator)
    const participant = await (0, client_1.queryOne)(`SELECT role FROM conversation_participants WHERE conversation_id = $1 AND user_id = $2`, [message.conversation_id, userId]);
    if (!participant || !['owner', 'moderator'].includes(participant.role)) {
        throw new Error('Only owners and moderators can pin messages');
    }
    // Check pin limit
    const pinnedCount = await (0, client_1.queryOne)(`SELECT COUNT(*) as count FROM messages WHERE conversation_id = $1 AND pinned_at IS NOT NULL`, [message.conversation_id]);
    if (parseInt(pinnedCount?.count || '0', 10) >= RATE_LIMITS.MAX_PINNED_MESSAGES) {
        throw new Error(`Maximum ${RATE_LIMITS.MAX_PINNED_MESSAGES} pinned messages reached`);
    }
    await (0, client_1.query)(`UPDATE messages SET pinned_at = NOW(), pinned_by = $1 WHERE id = $2`, [userId, messageId]);
    const updated = await (0, client_1.queryOne)(`SELECT * FROM messages WHERE id = $1`, [messageId]);
    return updated;
}
async function unpinMessage(messageId, userId) {
    const message = await (0, client_1.queryOne)(`SELECT conversation_id FROM messages WHERE id = $1`, [messageId]);
    if (!message) {
        throw new Error('Message not found');
    }
    // Check permission
    const participant = await (0, client_1.queryOne)(`SELECT role FROM conversation_participants WHERE conversation_id = $1 AND user_id = $2`, [message.conversation_id, userId]);
    if (!participant || !['owner', 'moderator'].includes(participant.role)) {
        throw new Error('Only owners and moderators can unpin messages');
    }
    await (0, client_1.query)(`UPDATE messages SET pinned_at = NULL, pinned_by = NULL WHERE id = $1`, [messageId]);
    return true;
}
async function getPinnedMessages(conversationId) {
    const messages = await (0, client_1.queryAll)(`SELECT * FROM messages
     WHERE conversation_id = $1 AND pinned_at IS NOT NULL AND deleted_at IS NULL
     ORDER BY pinned_at DESC`, [conversationId]);
    return messages.map((m) => ({
        id: m.id,
        conversationId: m.conversation_id,
        senderId: m.sender_id,
        content: m.content,
        contentType: m.content_type,
        pinnedAt: m.pinned_at,
        pinnedBy: m.pinned_by,
        createdAt: m.created_at,
    }));
}
// ============================================
// SCHEDULED MESSAGES
// ============================================
async function scheduleMessage(conversationId, senderId, content, scheduledFor, timezone = 'UTC') {
    const id = generateId('sched');
    await (0, client_1.query)(`INSERT INTO scheduled_messages (id, conversation_id, sender_id, content, scheduled_for, timezone)
     VALUES ($1, $2, $3, $4, $5, $6)`, [id, conversationId, senderId, sanitizeContent(content), scheduledFor.toISOString(), timezone]);
    return {
        id,
        conversationId,
        senderId,
        content: sanitizeContent(content),
        contentType: 'text',
        scheduledFor,
        timezone,
        status: 'pending',
    };
}
async function cancelScheduledMessage(scheduledId, userId) {
    const result = await (0, client_1.query)(`UPDATE scheduled_messages SET status = 'cancelled', updated_at = NOW()
     WHERE id = $1 AND sender_id = $2 AND status = 'pending'`, [scheduledId, userId]);
    return result.rowCount > 0;
}
async function getScheduledMessages(userId) {
    const messages = await (0, client_1.queryAll)(`SELECT * FROM scheduled_messages
     WHERE sender_id = $1 AND status = 'pending'
     ORDER BY scheduled_for ASC`, [userId]);
    return messages.map((m) => ({
        id: m.id,
        conversationId: m.conversation_id,
        senderId: m.sender_id,
        content: m.content,
        contentType: m.content_type,
        scheduledFor: m.scheduled_for,
        timezone: m.timezone,
        status: m.status,
    }));
}
async function processScheduledMessages() {
    const now = new Date();
    const pending = await (0, client_1.queryAll)(`SELECT * FROM scheduled_messages
     WHERE scheduled_for <= $1 AND status = 'pending'
     ORDER BY scheduled_for ASC
     LIMIT 100`, [now.toISOString()]);
    let processed = 0;
    for (const scheduled of pending) {
        try {
            const message = await sendMessage(scheduled.conversation_id, scheduled.sender_id, scheduled.content, {
                contentType: scheduled.content_type,
            });
            await (0, client_1.query)(`UPDATE scheduled_messages SET status = 'sent', sent_message_id = $1, updated_at = NOW()
         WHERE id = $2`, [message.id, scheduled.id]);
            processed++;
        }
        catch (error) {
            log.error({ scheduledId: scheduled.id, error }, 'Failed to send scheduled message');
        }
    }
    return processed;
}
// ============================================
// MESSAGE TEMPLATES
// ============================================
async function createTemplate(userId, name, content, options = {}) {
    const id = generateId('tmpl');
    await (0, client_1.query)(`INSERT INTO message_templates (id, user_id, name, content, shortcut, category)
     VALUES ($1, $2, $3, $4, $5, $6)`, [id, userId, name, content, options.shortcut, options.category]);
    return {
        id,
        userId,
        name,
        content,
        shortcut: options.shortcut,
        category: options.category,
        useCount: 0,
    };
}
async function getTemplates(userId) {
    const templates = await (0, client_1.queryAll)(`SELECT * FROM message_templates WHERE user_id = $1 ORDER BY use_count DESC, name ASC`, [
        userId,
    ]);
    return templates.map((t) => ({
        id: t.id,
        userId: t.user_id,
        name: t.name,
        content: t.content,
        shortcut: t.shortcut || undefined,
        category: t.category || undefined,
        useCount: t.use_count,
    }));
}
async function useTemplate(templateId) {
    const template = await (0, client_1.queryOne)(`UPDATE message_templates SET use_count = use_count + 1, updated_at = NOW()
     WHERE id = $1 RETURNING content`, [templateId]);
    if (!template) {
        throw new Error('Template not found');
    }
    return template.content;
}
// ============================================
// RATE LIMITING
// ============================================
async function checkRateLimit(userId) {
    const redis = (0, redis_1.getRedis)();
    const now = new Date();
    const minuteStart = new Date(now.getFullYear(), now.getMonth(), now.getDate(), now.getHours(), now.getMinutes());
    if (redis && (0, redis_1.isRedisAvailable)()) {
        const key = `${REDIS_KEYS_MESSAGING.RATE_LIMIT(userId)}:${minuteStart.getTime()}`;
        const count = await redis.get(key);
        const messagesSent = parseInt(count || '0', 10);
        return {
            messagesRemaining: Math.max(0, RATE_LIMITS.MESSAGES_PER_MINUTE - messagesSent),
            conversationsRemaining: RATE_LIMITS.CONVERSATIONS_PER_DAY, // Simplified
            resetAt: new Date(minuteStart.getTime() + 60000),
        };
    }
    // Fallback: use database
    const limits = await (0, client_1.queryOne)(`SELECT * FROM message_rate_limits WHERE user_id = $1`, [userId]);
    const today = new Date().toISOString().split('T')[0];
    if (!limits || limits.last_reset_at.toISOString().split('T')[0] !== today) {
        // Reset daily limits
        await (0, client_1.query)(`INSERT INTO message_rate_limits (user_id, messages_sent_today, conversations_created_today, last_reset_at)
       VALUES ($1, 0, 0, CURRENT_DATE)
       ON CONFLICT (user_id) DO UPDATE SET
         messages_sent_today = 0, conversations_created_today = 0, last_reset_at = CURRENT_DATE`, [userId]);
        return {
            messagesRemaining: RATE_LIMITS.MESSAGES_PER_MINUTE,
            conversationsRemaining: RATE_LIMITS.CONVERSATIONS_PER_DAY,
            resetAt: new Date(now.getTime() + 60000),
        };
    }
    return {
        messagesRemaining: RATE_LIMITS.MESSAGES_PER_MINUTE, // Per minute, simplified
        conversationsRemaining: RATE_LIMITS.CONVERSATIONS_PER_DAY - limits.conversations_created_today,
        resetAt: new Date(now.getTime() + 60000),
    };
}
async function incrementRateLimit(userId, type) {
    const redis = (0, redis_1.getRedis)();
    if (redis && (0, redis_1.isRedisAvailable)()) {
        const now = new Date();
        const minuteStart = new Date(now.getFullYear(), now.getMonth(), now.getDate(), now.getHours(), now.getMinutes());
        const key = `${REDIS_KEYS_MESSAGING.RATE_LIMIT(userId)}:${minuteStart.getTime()}`;
        await redis.incr(key);
        await redis.expire(key, 60);
    }
    else {
        // Fallback: use database
        if (type === 'message') {
            await (0, client_1.query)(`UPDATE message_rate_limits SET messages_sent_today = messages_sent_today + 1, last_message_at = NOW()
         WHERE user_id = $1`, [userId]);
        }
        else {
            await (0, client_1.query)(`UPDATE message_rate_limits SET conversations_created_today = conversations_created_today + 1
         WHERE user_id = $1`, [userId]);
        }
    }
}
async function deductCredits(userId, amount) {
    const result = await (0, client_1.query)(`UPDATE users SET credit_balance = credit_balance - $1
     WHERE id = $2 AND credit_balance >= $1
     RETURNING credit_balance`, [amount, userId]);
    if (result.rowCount === 0) {
        return false;
    }
    // Log transaction
    await (0, client_1.query)(`INSERT INTO credit_transactions (id, user_id, amount, type, description, created_at)
     VALUES ($1, $2, $3, 'message_send', 'Message sending cost', NOW())`, [generateId('txn'), userId, -amount]);
    return true;
}
// ============================================
// PUSH NOTIFICATIONS
// ============================================
async function registerPushSubscription(userId, endpoint, keys, deviceType = 'web', deviceName) {
    await (0, client_1.query)(`INSERT INTO push_subscriptions (user_id, endpoint, keys_p256dh, keys_auth, device_type, device_name)
     VALUES ($1, $2, $3, $4, $5, $6)
     ON CONFLICT (user_id, endpoint) DO UPDATE SET
       keys_p256dh = $3, keys_auth = $4, device_type = $5, device_name = $6, last_used_at = NOW()`, [userId, endpoint, keys.p256dh, keys.auth, deviceType, deviceName]);
}
async function unregisterPushSubscription(userId, endpoint) {
    await (0, client_1.query)(`DELETE FROM push_subscriptions WHERE user_id = $1 AND endpoint = $2`, [
        userId,
        endpoint,
    ]);
}
async function queuePushNotifications(conversationId, senderId, content, recipientIds) {
    // Get sender info
    const sender = await (0, client_1.queryOne)(`SELECT username, display_name FROM users WHERE id = $1`, [senderId]);
    // Get notification preferences and push subscriptions
    for (const recipientId of recipientIds) {
        const prefs = await (0, client_1.queryOne)(`SELECT messaging_enabled, messaging_preview FROM notification_preferences WHERE user_id = $1`, [recipientId]);
        // Default to enabled if no preferences set
        if (prefs && !prefs.messaging_enabled) {
            continue;
        }
        // Check if user is online (skip push if online)
        const presence = await getPresence(recipientId);
        if (presence.status === 'online') {
            continue;
        }
        // Get push subscriptions
        const subscriptions = await (0, client_1.queryAll)(`SELECT endpoint, keys_p256dh, keys_auth FROM push_subscriptions WHERE user_id = $1`, [
            recipientId,
        ]);
        // In production, you would send to a push notification service here
        // For now, just log that we would send
        for (const sub of subscriptions) {
            log.debug({
                recipientId,
                endpoint: sub.endpoint.slice(0, 50),
                sender: sender?.display_name || sender?.username,
            }, 'Would send push notification');
        }
    }
}
// ============================================
// ANALYTICS
// ============================================
async function updateMessageAnalytics(userId, type) {
    const today = new Date().toISOString().split('T')[0];
    if (type === 'sent') {
        await (0, client_1.query)(`INSERT INTO message_analytics (user_id, date, messages_sent)
       VALUES ($1, $2, 1)
       ON CONFLICT (user_id, date) DO UPDATE SET messages_sent = message_analytics.messages_sent + 1`, [userId, today]);
    }
    else {
        await (0, client_1.query)(`INSERT INTO message_analytics (user_id, date, messages_received)
       VALUES ($1, $2, 1)
       ON CONFLICT (user_id, date) DO UPDATE SET messages_received = message_analytics.messages_received + 1`, [userId, today]);
    }
}
async function getMessageAnalytics(userId, startDate, endDate) {
    const stats = await (0, client_1.queryAll)(`SELECT * FROM message_analytics
     WHERE user_id = $1 AND date >= $2 AND date <= $3
     ORDER BY date ASC`, [userId, startDate.toISOString().split('T')[0], endDate.toISOString().split('T')[0]]);
    let totalSent = 0;
    let totalReceived = 0;
    let totalResponseTime = 0;
    let responseTimeCount = 0;
    const dailyStats = stats.map((s) => {
        totalSent += s.messages_sent;
        totalReceived += s.messages_received;
        if (s.avg_response_time_seconds) {
            totalResponseTime += s.avg_response_time_seconds;
            responseTimeCount++;
        }
        return {
            date: s.date.toISOString().split('T')[0],
            sent: s.messages_sent,
            received: s.messages_received,
        };
    });
    return {
        totalSent,
        totalReceived,
        avgResponseTime: responseTimeCount > 0 ? totalResponseTime / responseTimeCount : undefined,
        dailyStats,
    };
}
// ============================================
// DISAPPEARING MESSAGES
// ============================================
async function setDisappearingMessages(conversationId, userId, ttlSeconds) {
    // Verify user is owner or moderator
    const participant = await (0, client_1.queryOne)(`SELECT role FROM conversation_participants WHERE conversation_id = $1 AND user_id = $2`, [conversationId, userId]);
    if (!participant || !['owner', 'moderator'].includes(participant.role)) {
        throw new Error('Only owners and moderators can set disappearing messages');
    }
    await (0, client_1.query)(`UPDATE conversations SET disappearing_ttl = $1, updated_at = NOW() WHERE id = $2`, [
        ttlSeconds,
        conversationId,
    ]);
}
async function cleanupExpiredMessages() {
    const result = await (0, client_1.query)(`DELETE FROM messages WHERE expires_at IS NOT NULL AND expires_at < NOW()`);
    return result.rowCount || 0;
}
// ============================================
// CONVERSATION MANAGEMENT
// ============================================
async function archiveConversation(conversationId, userId) {
    await (0, client_1.query)(`UPDATE conversations SET archived_at = NOW() WHERE id = $1
     AND EXISTS (SELECT 1 FROM conversation_participants WHERE conversation_id = $1 AND user_id = $2)`, [conversationId, userId]);
}
async function unarchiveConversation(conversationId, userId) {
    await (0, client_1.query)(`UPDATE conversations SET archived_at = NULL WHERE id = $1
     AND EXISTS (SELECT 1 FROM conversation_participants WHERE conversation_id = $1 AND user_id = $2)`, [conversationId, userId]);
}
async function starConversation(conversationId, userId) {
    await (0, client_1.query)(`UPDATE conversation_participants SET starred = true
     WHERE conversation_id = $1 AND user_id = $2`, [conversationId, userId]);
}
async function unstarConversation(conversationId, userId) {
    await (0, client_1.query)(`UPDATE conversation_participants SET starred = false
     WHERE conversation_id = $1 AND user_id = $2`, [conversationId, userId]);
}
// ============================================
// CONTENT SHARING
// ============================================
async function shareContent(conversationId, senderId, contentType, contentId, previewData) {
    const messageId = generateId('msg');
    const sharedContentId = generateId('shared');
    const now = new Date();
    // Create the message
    await (0, client_1.query)(`INSERT INTO messages (id, conversation_id, sender_id, content, content_type, created_at)
     VALUES ($1, $2, $3, $4, 'shared', $5)`, [messageId, conversationId, senderId, `Shared ${contentType}`, now.toISOString()]);
    // Create shared content reference
    await (0, client_1.query)(`INSERT INTO message_shared_content (id, message_id, content_type, content_id, preview_data)
     VALUES ($1, $2, $3, $4, $5)`, [sharedContentId, messageId, contentType, contentId, previewData ? JSON.stringify(previewData) : null]);
    // Update conversation
    await (0, client_1.query)(`UPDATE conversations SET last_message_at = $1, updated_at = $1 WHERE id = $2`, [now.toISOString(), conversationId]);
    return {
        id: messageId,
        conversationId,
        senderId,
        content: `Shared ${contentType}`,
        contentType: 'shared',
        createdAt: now,
        metadata: { sharedContentType: contentType, sharedContentId: contentId, preview: previewData },
    };
}
// ============================================
// REPORT MESSAGE
// ============================================
async function reportMessage(messageId, reporterId, reason, details) {
    const id = generateId('rpt');
    await (0, client_1.query)(`INSERT INTO message_reports (id, message_id, reporter_id, reason, details)
     VALUES ($1, $2, $3, $4, $5)`, [id, messageId, reporterId, reason, details]);
    log.info({ reportId: id, messageId, reporterId, reason }, 'Message reported');
}
//# sourceMappingURL=messaging.service.js.map