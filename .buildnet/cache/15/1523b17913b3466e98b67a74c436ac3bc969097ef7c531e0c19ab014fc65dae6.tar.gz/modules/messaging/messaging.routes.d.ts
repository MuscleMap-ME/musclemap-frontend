/**
 * Enhanced Messaging Routes (Fastify)
 *
 * Comprehensive messaging API with all advanced features:
 * - Core messaging (send, edit, delete)
 * - Typing indicators
 * - Presence system
 * - Delivery/read receipts
 * - Message reactions
 * - Message search
 * - Voice messages
 * - Link previews
 * - Scheduled messages
 * - Message forwarding and pinning
 * - Rate limiting
 * - Push notifications
 * - Content sharing
 * - Conversation management
 */
import { FastifyInstance } from 'fastify';
export declare function registerEnhancedMessagingRoutes(app: FastifyInstance): Promise<void>;
