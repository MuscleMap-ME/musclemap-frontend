/**
 * Leaderboards Module
 *
 * Handles exercise-based leaderboards for hangouts:
 * - Process workout data into leaderboard entries
 * - Query leaderboards with cohort filtering (gender, age, adaptive)
 * - Calculate user rankings
 * - Support daily, weekly, monthly, and all-time periods
 */
export declare const PERIOD_TYPES: {
    readonly DAILY: "daily";
    readonly WEEKLY: "weekly";
    readonly MONTHLY: "monthly";
    readonly ALL_TIME: "all_time";
};
export type PeriodType = (typeof PERIOD_TYPES)[keyof typeof PERIOD_TYPES];
export declare const VERIFICATION_STATUS: {
    readonly SELF_REPORTED: "self_reported";
    readonly PENDING_REVIEW: "pending_review";
    readonly VERIFIED: "verified";
    readonly REJECTED: "rejected";
};
export type VerificationStatus = (typeof VERIFICATION_STATUS)[keyof typeof VERIFICATION_STATUS];
export interface ExerciseMetricDefinition {
    id: string;
    exerciseId: string;
    metricKey: string;
    displayName: string;
    unit: string;
    direction: 'higher' | 'lower';
    calculationType: string;
    enabled: boolean;
}
export interface LeaderboardEntry {
    rank: number;
    userId: string;
    username: string;
    displayName?: string;
    avatarUrl?: string;
    value: number;
    verificationStatus: VerificationStatus;
    achievedAt: Date;
    genderCategory?: string;
    ageBand?: string;
    adaptiveCategory?: string;
}
export interface LeaderboardQuery {
    exerciseId: string;
    metricKey: string;
    periodType: PeriodType;
    periodStart?: Date;
    hangoutId?: number;
    virtualHangoutId?: number;
    genderCategory?: string;
    ageBand?: string;
    adaptiveCategory?: string;
    verificationStatus?: VerificationStatus | 'all';
    limit?: number;
    offset?: number;
    cursor?: string;
}
export interface UserRankResult {
    rank: number;
    value: number;
    total: number;
    percentile: number;
}
export interface WorkoutSet {
    reps?: number;
    weight?: number;
    duration?: number;
    distance?: number;
}
export interface WorkoutExerciseData {
    exerciseId: string;
    sets: WorkoutSet[];
}
export declare const leaderboardService: {
    /**
     * Get metric definitions for an exercise
     */
    getMetricDefinitions(exerciseId: string): Promise<ExerciseMetricDefinition[]>;
    /**
     * Calculate metric value from workout sets
     */
    calculateMetricValue(sets: WorkoutSet[], calculationType: string, metricKey: string): number | null;
    /**
     * Get period start date for a given period type
     */
    getPeriodStart(periodType: PeriodType, date?: Date): Date;
    /**
     * Process a workout and update leaderboard entries
     */
    processWorkout(userId: string, workoutId: string, exercises: WorkoutExerciseData[], hangoutId?: number, virtualHangoutId?: number): Promise<void>;
    /**
     * Upsert a leaderboard entry
     */
    upsertEntry(params: {
        userId: string;
        exerciseId: string;
        metricKey: string;
        hangoutId?: number;
        virtualHangoutId?: number;
        periodType: PeriodType;
        periodStart: Date;
        value: number;
        direction: "higher" | "lower";
        sourceWorkoutId?: string;
    }): Promise<{
        isNewRecord: boolean;
        isPersonalBest: boolean;
        previousValue?: number;
    }>;
    /**
     * Check if a value is a hangout or global record
     */
    checkForRecords(userId: string, exerciseId: string, metricKey: string, value: number, direction: "higher" | "lower", hangoutId?: number, virtualHangoutId?: number): Promise<{
        isHangoutRecord: boolean;
        isGlobalRecord: boolean;
    }>;
    /**
     * Get leaderboard entries with keyset pagination for optimal performance
     *
     * PERF-001: Optimized from ~500ms to <100ms using:
     * - Keyset pagination instead of OFFSET (O(1) vs O(n))
     * - Covering indexes to avoid heap lookups
     * - Materialized view for global top 100
     */
    getLeaderboard(queryParams: LeaderboardQuery): Promise<{
        entries: LeaderboardEntry[];
        total: number;
        nextCursor?: string;
    }>;
    /**
     * Get user's rank on a leaderboard
     */
    getUserRank(userId: string, queryParams: Omit<LeaderboardQuery, "limit" | "offset">): Promise<UserRankResult | null>;
    /**
     * Get cache key for a leaderboard query
     */
    getCacheKey(query: LeaderboardQuery): string;
    /**
     * Invalidate caches for specific hangouts and exercises
     */
    invalidateCaches(hangoutId?: number, virtualHangoutId?: number, _exerciseIds?: string[]): Promise<void>;
    /**
     * Get available exercises with metrics for a hangout
     */
    getAvailableMetrics(hangoutId?: number, virtualHangoutId?: number): Promise<Array<{
        exerciseId: string;
        exerciseName: string;
        metrics: ExerciseMetricDefinition[];
    }>>;
};
export default leaderboardService;
