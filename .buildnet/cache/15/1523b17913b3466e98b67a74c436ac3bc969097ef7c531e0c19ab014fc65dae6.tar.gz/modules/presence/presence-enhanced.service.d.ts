/**
 * Enhanced Community Presence Service
 *
 * Adds advanced features:
 * - Training partner streaks and bonuses
 * - Quick status options
 * - Venue activity heatmaps
 * - Partner compatibility scoring
 * - Recurring training schedules
 */
export type QuickStatusType = 'none' | 'looking_for_spotter' | 'need_workout_buddy' | 'open_to_teach' | 'want_to_learn' | 'warming_up' | 'cooling_down' | 'taking_a_break' | 'last_set';
export interface TrainingPartnership {
    id: string;
    userId1: string;
    userId2: string;
    totalSessions: number;
    currentStreak: number;
    longestStreak: number;
    lastSessionDate: Date | null;
    totalCreditsEarned: number;
    favoriteVenues: string[];
    favoriteWorkoutTypes: string[];
    firstSessionAt: Date | null;
    createdAt: Date;
}
export interface PartnershipSession {
    id: string;
    partnershipId: string;
    sessionId: string | null;
    venueId: string | null;
    workoutType: string | null;
    durationMinutes: number | null;
    creditsAwarded: number;
    streakBonus: number;
    sessionDate: Date;
    createdAt: Date;
}
export interface VenueHourlyActivity {
    venueId: string;
    activityDate: Date;
    hourOfDay: number;
    dayOfWeek: number;
    checkInCount: number;
    uniqueUserCount: number;
    peakConcurrentUsers: number;
    avgSessionDurationMinutes: number;
    openToTrainCount: number;
    trainingSessionsCount: number;
}
export interface VenueWeeklyPattern {
    venueId: string;
    dayOfWeek: number;
    hourOfDay: number;
    avgCheckInCount: number;
    avgUniqueUsers: number;
    avgOpenToTrain: number;
    activityLevel: 'low' | 'medium' | 'high' | 'very_high';
    sampleSize: number;
}
export interface UserTrainingPreferences {
    userId: string;
    preferredExercises: string[];
    preferredMuscleGroups: string[];
    preferredWorkoutTypes: string[];
    typicalWorkoutDurationMinutes: number;
    experienceLevel: string | null;
    goals: string[];
    preferredDays: number[];
    preferredHours: number[];
    timezone: string;
    preferredGroupSize: number;
    openToBeginners: boolean;
    willingToTeach: boolean;
    lookingForMentor: boolean;
    communicationStyle: string | null;
    intensityPreference: string | null;
    favoriteVenueIds: string[];
    maxTravelDistanceKm: number;
}
export interface PartnerCompatibility {
    userId1: string;
    userId2: string;
    overallScore: number;
    scheduleCompatibility: number;
    workoutCompatibility: number;
    experienceCompatibility: number;
    socialCompatibility: number;
    commonExercises: string[];
    commonTimes: string[];
    compatibilityFactors: Record<string, unknown>;
}
export interface RecurringTrainingSchedule {
    id: string;
    creatorId: string;
    venueId: string | null;
    title: string;
    description: string | null;
    workoutType: string | null;
    targetMuscles: string[];
    durationMinutes: number;
    recurrenceType: 'daily' | 'weekly' | 'biweekly' | 'monthly';
    daysOfWeek: number[];
    startTime: string;
    timezone: string;
    maxParticipants: number;
    requireApproval: boolean;
    allowGuests: boolean;
    isActive: boolean;
    startDate: Date;
    endDate: Date | null;
    createdAt: Date;
}
export interface RecurringScheduleMember {
    id: string;
    scheduleId: string;
    userId: string;
    role: 'creator' | 'admin' | 'member';
    status: 'active' | 'paused' | 'left';
    notifyBeforeSession: boolean;
    notifyMinutesBefore: number;
    joinedAt: Date;
}
export declare const QUICK_STATUS_OPTIONS: Record<QuickStatusType, {
    label: string;
    icon: string;
    defaultDuration: number;
}>;
/**
 * Set quick status for a user
 */
export declare function setQuickStatus(userId: string, status: QuickStatusType, message?: string, durationMinutes?: number): Promise<void>;
/**
 * Clear expired quick statuses (call periodically)
 */
export declare function clearExpiredQuickStatuses(): Promise<number>;
/**
 * Get users with a specific quick status nearby
 */
export declare function getUsersWithQuickStatus(status: QuickStatusType, venueId?: string): Promise<Array<{
    userId: string;
    username: string;
    displayName: string | null;
    avatarUrl: string | null;
    quickStatusMessage: string | null;
    checkedInAt: Date | null;
}>>;
/**
 * Get or create a training partnership between two users
 */
export declare function getOrCreatePartnership(userId1: string, userId2: string): Promise<TrainingPartnership>;
/**
 * Record a training session between partners
 */
export declare function recordPartnershipSession(userId1: string, userId2: string, options: {
    sessionId?: string;
    venueId?: string;
    workoutType?: string;
    durationMinutes?: number;
}): Promise<{
    partnership: TrainingPartnership;
    session: PartnershipSession;
    streakMilestoneReached?: number;
    bonusCredits: number;
}>;
/**
 * Get all training partnerships for a user
 */
export declare function getUserPartnerships(userId: string): Promise<Array<TrainingPartnership & {
    partnerUserId: string;
    partnerUsername: string;
}>>;
/**
 * Get hourly activity data for a venue
 */
export declare function getVenueHourlyActivity(venueId: string, startDate: Date, endDate: Date): Promise<VenueHourlyActivity[]>;
/**
 * Get weekly patterns for a venue (predicted activity)
 */
export declare function getVenueWeeklyPatterns(venueId: string): Promise<VenueWeeklyPattern[]>;
/**
 * Get best times to visit a venue (based on user preference)
 */
export declare function getVenueBestTimes(venueId: string, preference: 'busy' | 'quiet' | 'social'): Promise<Array<{
    dayOfWeek: number;
    hourOfDay: number;
    score: number;
}>>;
/**
 * Trigger hourly activity aggregation
 */
export declare function aggregateHourlyActivity(): Promise<void>;
/**
 * Update weekly patterns from historical data
 */
export declare function updateWeeklyPatterns(): Promise<void>;
/**
 * Get or update training preferences for a user
 */
export declare function upsertTrainingPreferences(userId: string, prefs: Partial<UserTrainingPreferences>): Promise<UserTrainingPreferences>;
/**
 * Get training preferences for a user
 */
export declare function getTrainingPreferences(userId: string): Promise<UserTrainingPreferences | null>;
/**
 * Calculate compatibility between two users
 */
export declare function calculateCompatibility(userId1: string, userId2: string): Promise<PartnerCompatibility>;
/**
 * Get suggested training partners for a user
 */
export declare function getSuggestedPartners(userId: string, venueId?: string, limit?: number): Promise<Array<PartnerCompatibility & {
    username: string;
    avatarUrl: string | null;
}>>;
/**
 * Create a recurring training schedule
 */
export declare function createRecurringSchedule(creatorId: string, schedule: Omit<RecurringTrainingSchedule, 'id' | 'createdAt'>): Promise<RecurringTrainingSchedule>;
/**
 * Get a recurring schedule by ID
 */
export declare function getRecurringSchedule(scheduleId: string): Promise<RecurringTrainingSchedule | null>;
/**
 * Get recurring schedules for a user
 */
export declare function getUserRecurringSchedules(userId: string): Promise<RecurringTrainingSchedule[]>;
/**
 * Join a recurring schedule
 */
export declare function joinRecurringSchedule(scheduleId: string, userId: string): Promise<RecurringScheduleMember>;
/**
 * Leave a recurring schedule
 */
export declare function leaveRecurringSchedule(scheduleId: string, userId: string): Promise<void>;
