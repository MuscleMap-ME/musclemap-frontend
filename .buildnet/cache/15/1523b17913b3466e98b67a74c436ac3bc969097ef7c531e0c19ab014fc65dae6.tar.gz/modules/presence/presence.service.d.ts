/**
 * Community Presence Service
 *
 * Handles real-time user presence at fitness venues:
 * - Location sharing with privacy controls
 * - Check-in/out with GPS verification
 * - Training sessions and invites
 * - Nearby user discovery
 * - Presence history for heat maps
 *
 * Privacy-first design ensures users have full control over their visibility.
 */
export type PresenceState = 'invisible' | 'location_only' | 'visible' | 'training_now' | 'open_to_train';
export type PrivacyPreset = 'social' | 'selective' | 'private';
export type LocationPrecision = 'exact' | 'approximate' | 'area_only';
export interface UserPresence {
    userId: string;
    state: PresenceState;
    latitude?: number;
    longitude?: number;
    locationPrecision: LocationPrecision;
    venueId?: string;
    sessionStartedAt?: Date;
    sessionPlannedDuration?: number;
    sessionWorkoutType?: string;
    sessionTargetMuscles?: string[];
    sessionOpenToJoin: boolean;
    sessionMaxParticipants: number;
    sessionNotes?: string;
    locationUpdatedAt?: Date;
    lastActiveAt: Date;
}
export interface PresenceSettings {
    userId: string;
    sharePresence: boolean;
    privacyPreset: PrivacyPreset;
    locationEnabled: boolean;
    locationPrecision: LocationPrecision;
    locationOnlyWhenCheckedIn: boolean;
    locationAutoExpireMinutes: number;
    visibleToEveryone: boolean;
    visibleToFollowers: boolean;
    visibleToMutualFollowers: boolean;
    showRealName: boolean;
    showProfilePhoto: boolean;
    showTrainingStats: boolean;
    showCurrentWorkout: boolean;
    showTrainingHistory: boolean;
    allowDirectMessages: boolean;
    allowMessagesFromEveryone: boolean;
    allowMessagesFromFollowers: boolean;
    allowMessagesFromMutualOnly: boolean;
    allowTrainingInvites: boolean;
    showInNearbyList: boolean;
    receiveNearbyNotifications: boolean;
    notifyWhenFriendsNearby: boolean;
    nearbyNotificationRadiusMeters: number;
    preferredTrainingTimes?: string[];
    preferredWorkoutTypes?: string[];
    lookingForTrainingPartners: boolean;
    maxTrainingGroupSize: number;
}
export interface VenueCheckIn {
    id: string;
    venueId: string;
    userId: string;
    latitude: number;
    longitude: number;
    distanceFromVenueMeters?: number;
    locationAccuracyMeters?: number;
    isActive: boolean;
    checkedInAt: Date;
    checkedOutAt?: Date;
    autoCheckout: boolean;
    workoutType?: string;
    openToJoin: boolean;
    visibleToOthers: boolean;
    plannedDuration?: number;
    sessionId?: string;
    verificationMethod: 'gps' | 'manual' | 'qr_code' | 'nfc';
    gpsVerified: boolean;
    workoutId?: string;
}
export interface TrainingInvite {
    id: string;
    fromUserId: string;
    toUserId: string;
    venueId: string;
    proposedTime: Date;
    workoutType?: string;
    message?: string;
    isNow: boolean;
    status: 'pending' | 'accepted' | 'declined' | 'expired' | 'cancelled';
    statusMessage?: string;
    respondedAt?: Date;
    expiresAt: Date;
    sessionId?: string;
    messageId?: string;
    conversationId?: string;
    createdAt: Date;
}
export interface TrainingSession {
    id: string;
    venueId: string;
    hostUserId: string;
    workoutType?: string;
    scheduledTime: Date;
    startedAt?: Date;
    endedAt?: Date;
    durationMinutes?: number;
    status: 'scheduled' | 'active' | 'completed' | 'cancelled';
    maxParticipants: number;
    participantCount: number;
    notes?: string;
    creditsAwardedPerParticipant: number;
    createdAt: Date;
}
export interface UserAtVenue {
    userId: string;
    displayName: string;
    username: string;
    avatarUrl?: string;
    checkedInAt: Date;
    workoutType?: string;
    openToJoin: boolean;
    canMessage: boolean;
    isFollowing: boolean;
    isFollower: boolean;
    isMutual: boolean;
    durationMinutes: number;
}
export interface NearbyVenue {
    venueId: string;
    name: string;
    latitude: number;
    longitude: number;
    distanceMeters: number;
    currentUserCount: number;
    openToTrainCount: number;
    hasFriendsHere: boolean;
    friendsHereCount: number;
}
export declare const PRIVACY_PRESETS: Record<PrivacyPreset, Partial<PresenceSettings>>;
/**
 * Get user's presence settings
 */
export declare function getPresenceSettings(userId: string): Promise<PresenceSettings | null>;
/**
 * Create or update user's presence settings
 */
export declare function upsertPresenceSettings(userId: string, settings: Partial<PresenceSettings>): Promise<PresenceSettings>;
/**
 * Apply a privacy preset to user's settings
 */
export declare function applyPrivacyPreset(userId: string, preset: PrivacyPreset): Promise<PresenceSettings>;
/**
 * Get user's current presence
 */
export declare function getUserPresence(userId: string): Promise<UserPresence | null>;
/**
 * Update user's presence state and optionally location
 */
export declare function updatePresence(userId: string, update: {
    state?: PresenceState;
    latitude?: number;
    longitude?: number;
    venueId?: string | null;
    sessionWorkoutType?: string;
    sessionTargetMuscles?: string[];
    sessionOpenToJoin?: boolean;
    sessionMaxParticipants?: number;
    sessionNotes?: string;
}): Promise<UserPresence>;
/**
 * Set user as invisible (clear presence)
 */
export declare function setInvisible(userId: string): Promise<void>;
/**
 * Check in to a venue
 */
export declare function checkIn(userId: string, venueId: string, options: {
    latitude: number;
    longitude: number;
    locationAccuracy?: number;
    workoutType?: string;
    plannedDuration?: number;
    openToJoin?: boolean;
    visible?: boolean;
}): Promise<{
    checkIn: VenueCheckIn;
    gpsVerified: boolean;
    distanceMeters: number;
    othersAtVenue: UserAtVenue[];
    creditsAwarded: number;
}>;
/**
 * Check out from current venue
 */
export declare function checkOut(userId: string): Promise<VenueCheckIn | null>;
/**
 * Get user's active check-in
 */
export declare function getActiveCheckIn(userId: string): Promise<VenueCheckIn | null>;
/**
 * Get users currently at a venue (respecting privacy settings)
 */
export declare function getUsersAtVenue(venueId: string, requestingUserId: string): Promise<UserAtVenue[]>;
/**
 * Get active venues nearby with user counts
 */
export declare function getActiveVenuesNearby(latitude: number, longitude: number, radiusMeters: number, requestingUserId: string): Promise<NearbyVenue[]>;
/**
 * Send a training invite
 */
export declare function sendTrainingInvite(fromUserId: string, toUserId: string, venueId: string, options?: {
    proposedTime?: Date;
    workoutType?: string;
    message?: string;
}): Promise<TrainingInvite>;
/**
 * Get a training invite by ID
 */
export declare function getTrainingInvite(inviteId: string): Promise<TrainingInvite | null>;
/**
 * Accept a training invite
 */
export declare function acceptTrainingInvite(inviteId: string, userId: string): Promise<{
    invite: TrainingInvite;
    session: TrainingSession;
}>;
/**
 * Decline a training invite
 */
export declare function declineTrainingInvite(inviteId: string, userId: string, message?: string): Promise<TrainingInvite>;
/**
 * Get pending invites for a user
 */
export declare function getPendingInvites(userId: string): Promise<TrainingInvite[]>;
/**
 * Get a training session by ID
 */
export declare function getTrainingSession(sessionId: string): Promise<TrainingSession | null>;
/**
 * Expire stale presence and check-ins (call periodically)
 */
export declare function expireStalePresence(): Promise<void>;
