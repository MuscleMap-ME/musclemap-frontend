/**
 * Dispute Service
 *
 * Handles disputes for classes, transfers, and other economy transactions.
 * Provides a workflow for reporting, investigating, and resolving disputes.
 */
export type DisputeType = 'class_noshow' | 'class_quality' | 'transfer_fraud' | 'refund_request' | 'other';
export type DisputeStatus = 'open' | 'investigating' | 'pending_response' | 'resolved_reporter' | 'resolved_respondent' | 'resolved_split' | 'dismissed' | 'escalated';
export interface Dispute {
    id: string;
    reporterId: string;
    respondentId: string;
    disputeType: DisputeType;
    referenceType: string;
    referenceId: string;
    amountDisputed?: number;
    escrowId?: string;
    description: string;
    evidence: Array<{
        type: string;
        url?: string;
        text?: string;
        uploadedAt: string;
    }>;
    status: DisputeStatus;
    resolution?: string;
    resolutionAmount?: number;
    resolvedBy?: string;
    resolvedAt?: Date;
    deadline?: Date;
    createdAt: Date;
    updatedAt: Date;
}
export interface DisputeMessage {
    id: string;
    disputeId: string;
    senderId: string;
    isAdmin: boolean;
    message: string;
    attachments: string[];
    createdAt: Date;
}
export interface CreateDisputeInput {
    reporterId: string;
    respondentId: string;
    disputeType: DisputeType;
    referenceType: string;
    referenceId: string;
    amountDisputed?: number;
    escrowId?: string;
    description: string;
    evidence?: Array<{
        type: string;
        url?: string;
        text?: string;
    }>;
}
export declare const disputeService: {
    /**
     * Get economy setting value
     */
    getSetting(key: string, defaultValue: number): Promise<number>;
    /**
     * Create a new dispute
     */
    createDispute(input: CreateDisputeInput): Promise<Dispute>;
    /**
     * Get dispute by ID
     */
    getDispute(disputeId: string): Promise<Dispute | null>;
    /**
     * Get disputes for a user (as reporter or respondent)
     */
    getUserDisputes(userId: string, options?: {
        role?: "reporter" | "respondent" | "all";
        status?: DisputeStatus;
        limit?: number;
        offset?: number;
    }): Promise<{
        disputes: Dispute[];
        total: number;
    }>;
    /**
     * Add message to dispute
     */
    addMessage(disputeId: string, senderId: string, message: string, isAdmin?: boolean, attachments?: string[]): Promise<DisputeMessage>;
    /**
     * Get messages for a dispute
     */
    getMessages(disputeId: string): Promise<DisputeMessage[]>;
    /**
     * Update dispute status (admin)
     */
    updateStatus(disputeId: string, status: DisputeStatus, adminId: string): Promise<void>;
    /**
     * Resolve dispute (admin)
     */
    resolve(disputeId: string, adminId: string, resolution: {
        status: "resolved_reporter" | "resolved_respondent" | "resolved_split" | "dismissed";
        resolution: string;
        resolutionAmount?: number;
        splitRatio?: number;
    }): Promise<void>;
    /**
     * Get pending disputes (admin)
     */
    getPendingDisputes(options?: {
        status?: DisputeStatus[];
        disputeType?: DisputeType;
        limit?: number;
        offset?: number;
    }): Promise<{
        disputes: Dispute[];
        total: number;
    }>;
};
export default disputeService;
