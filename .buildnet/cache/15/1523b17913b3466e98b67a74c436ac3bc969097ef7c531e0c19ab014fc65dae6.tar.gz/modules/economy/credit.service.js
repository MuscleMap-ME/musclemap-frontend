"use strict";
/**
 * Enhanced Credit Service
 *
 * Handles the credit economy with:
 * - Atomic transactions with idempotency
 * - P2P credit transfers
 * - Rep-based credit awards (1 credit per rep)
 * - Redis caching for balance lookups
 * - Transaction history with audit trails
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.creditService = exports.RefType = exports.CreditReason = void 0;
const crypto_1 = __importDefault(require("crypto"));
const client_1 = require("../../db/client");
const redis_1 = require("../../lib/redis");
const errors_1 = require("../../lib/errors");
const logger_1 = require("../../lib/logger");
const entitlements_1 = require("../entitlements");
const log = logger_1.loggers.economy;
// Credit reason codes (matches database migration)
var CreditReason;
(function (CreditReason) {
    CreditReason[CreditReason["REP_COMPLETED"] = 1] = "REP_COMPLETED";
    CreditReason[CreditReason["DM_SENT"] = 2] = "DM_SENT";
    CreditReason[CreditReason["AI_QUERY"] = 3] = "AI_QUERY";
    CreditReason[CreditReason["POST_CREATED"] = 4] = "POST_CREATED";
    CreditReason[CreditReason["AD_POSTED"] = 5] = "AD_POSTED";
    CreditReason[CreditReason["TRANSFER_SENT"] = 6] = "TRANSFER_SENT";
    CreditReason[CreditReason["TRANSFER_RECEIVED"] = 7] = "TRANSFER_RECEIVED";
    CreditReason[CreditReason["ADMIN_ADJUSTMENT"] = 8] = "ADMIN_ADJUSTMENT";
    CreditReason[CreditReason["WORKOUT_COMPLETED"] = 9] = "WORKOUT_COMPLETED";
    CreditReason[CreditReason["PURCHASE"] = 10] = "PURCHASE";
    CreditReason[CreditReason["SUBSCRIPTION_BONUS"] = 11] = "SUBSCRIPTION_BONUS";
    CreditReason[CreditReason["REFERRAL_BONUS"] = 12] = "REFERRAL_BONUS";
    CreditReason[CreditReason["MILESTONE_REWARD"] = 13] = "MILESTONE_REWARD";
})(CreditReason || (exports.CreditReason = CreditReason = {}));
// Reference type codes
var RefType;
(function (RefType) {
    RefType[RefType["REP_EVENT"] = 1] = "REP_EVENT";
    RefType[RefType["MESSAGE"] = 2] = "MESSAGE";
    RefType[RefType["AI_REQUEST"] = 3] = "AI_REQUEST";
    RefType[RefType["POST"] = 4] = "POST";
    RefType[RefType["AD"] = 5] = "AD";
    RefType[RefType["TRANSFER"] = 6] = "TRANSFER";
    RefType[RefType["WORKOUT"] = 7] = "WORKOUT";
    RefType[RefType["PURCHASE"] = 8] = "PURCHASE";
    RefType[RefType["MILESTONE"] = 9] = "MILESTONE";
})(RefType || (exports.RefType = RefType = {}));
// Cache settings
const BALANCE_CACHE_TTL = 60; // 60 seconds
const BALANCE_CACHE_PREFIX = 'balance:';
/**
 * Invalidate cached balance
 */
async function invalidateBalanceCache(userId) {
    if (!(0, redis_1.isRedisAvailable)())
        return;
    try {
        const redis = (0, redis_1.getRedis)();
        if (redis) {
            await redis.del(`${BALANCE_CACHE_PREFIX}${userId}`);
        }
    }
    catch (error) {
        log.warn({ userId, error }, 'Failed to invalidate balance cache');
    }
}
/**
 * Get cached balance or null
 */
async function getCachedBalance(userId) {
    if (!(0, redis_1.isRedisAvailable)())
        return null;
    try {
        const redis = (0, redis_1.getRedis)();
        if (!redis)
            return null;
        const cached = await redis.get(`${BALANCE_CACHE_PREFIX}${userId}`);
        return cached !== null ? parseInt(cached, 10) : null;
    }
    catch {
        return null;
    }
}
/**
 * Cache a balance value
 */
async function cacheBalance(userId, balance) {
    if (!(0, redis_1.isRedisAvailable)())
        return;
    try {
        const redis = (0, redis_1.getRedis)();
        if (redis) {
            await redis.set(`${BALANCE_CACHE_PREFIX}${userId}`, balance.toString(), 'EX', BALANCE_CACHE_TTL, 'NX');
        }
    }
    catch (error) {
        log.warn({ userId, error }, 'Failed to cache balance');
    }
}
exports.creditService = {
    /**
     * Get user's current credit balance
     * Uses Redis cache with 60s TTL for performance
     */
    async getBalance(userId) {
        // Try cache first
        const cached = await getCachedBalance(userId);
        if (cached !== null) {
            return cached;
        }
        // Query database
        const row = await (0, client_1.queryOne)('SELECT balance FROM credit_balances WHERE user_id = $1', [userId]);
        const balance = row?.balance ?? 0;
        // Cache the result
        await cacheBalance(userId, balance);
        return balance;
    },
    /**
     * Get detailed balance info
     */
    async getBalanceDetails(userId) {
        const row = await (0, client_1.queryOne)(`SELECT balance, COALESCE(total_earned, lifetime_earned) as total_earned,
              COALESCE(total_spent, lifetime_spent) as total_spent, version
       FROM credit_balances WHERE user_id = $1`, [userId]);
        return {
            balance: row?.balance ?? 0,
            totalEarned: row?.total_earned ?? 0,
            totalSpent: row?.total_spent ?? 0,
            version: row?.version ?? 0,
        };
    },
    /**
     * Execute an atomic credit transaction using the database function
     */
    async transact(request) {
        const { userId, delta, reason, refType, refId, idempotencyKey, metadata } = request;
        // Hash user agent if provided
        let userAgentHash = null;
        if (metadata?.userAgent) {
            userAgentHash = crypto_1.default.createHash('sha256').update(metadata.userAgent).digest().slice(0, 16);
        }
        // RC-005 FIX: Invalidate cache BEFORE the transaction
        // This ensures any reads during or after the transaction will fetch fresh data
        // The database function handles its own transaction, so we can't invalidate inside it
        await invalidateBalanceCache(userId);
        try {
            const result = await client_1.db.queryOne(`SELECT * FROM credit_transaction($1, $2, $3, $4, $5, $6, $7, $8)`, [
                userId,
                delta,
                reason,
                refType ?? null,
                refId ?? null,
                idempotencyKey,
                metadata?.ip ?? null,
                userAgentHash,
            ]);
            if (!result) {
                throw new Error('Transaction returned no result');
            }
            // Log on success (unless duplicate)
            if (!result.was_duplicate) {
                log.info({
                    userId,
                    delta,
                    reason,
                    newBalance: result.new_balance,
                }, 'Credit transaction completed');
            }
            return {
                entryId: result.entry_id,
                newBalance: parseInt(result.new_balance, 10),
                wasDuplicate: result.was_duplicate,
                version: result.version,
            };
        }
        catch (error) {
            // Handle specific errors
            if (error.message?.includes('INSUFFICIENT_CREDITS')) {
                throw new errors_1.ValidationError('Insufficient credits');
            }
            log.error({ userId, delta, reason, error }, 'Credit transaction failed');
            throw error;
        }
    },
    /**
     * Transfer credits between users
     */
    async transfer(request) {
        const { senderId, recipientId, amount, note } = request;
        if (senderId === recipientId) {
            throw new errors_1.ValidationError('Cannot transfer credits to yourself');
        }
        if (amount <= 0 || amount > 1000000) {
            throw new errors_1.ValidationError('Transfer amount must be between 1 and 1,000,000');
        }
        // Verify recipient exists
        const recipient = await (0, client_1.queryOne)('SELECT id FROM users WHERE id = $1', [recipientId]);
        if (!recipient) {
            throw new errors_1.NotFoundError('Recipient not found');
        }
        // Generate transfer ID
        const transferId = `xfer_${crypto_1.default.randomBytes(12).toString('hex')}`;
        // RC-005 FIX: Invalidate caches BEFORE the transaction
        // This ensures any reads during or after the transaction will fetch fresh data
        await Promise.all([invalidateBalanceCache(senderId), invalidateBalanceCache(recipientId)]);
        try {
            const result = await client_1.db.queryOne(`SELECT * FROM credit_transfer($1, $2, $3, $4)`, [senderId, recipientId, amount, transferId]);
            if (!result) {
                throw new Error('Transfer returned no result');
            }
            log.info({
                transferId: result.transfer_id,
                senderId,
                recipientId,
                amount,
                note: note?.slice(0, 100),
            }, 'Credit transfer completed');
            return {
                transferId: result.transfer_id,
                senderNewBalance: parseInt(result.sender_new_balance, 10),
                recipientNewBalance: parseInt(result.recipient_new_balance, 10),
            };
        }
        catch (error) {
            if (error.message?.includes('INSUFFICIENT_CREDITS')) {
                throw new errors_1.ValidationError('Insufficient credits for transfer');
            }
            if (error.message?.includes('SELF_TRANSFER')) {
                throw new errors_1.ValidationError('Cannot transfer credits to yourself');
            }
            if (error.message?.includes('INVALID_AMOUNT')) {
                throw new errors_1.ValidationError('Invalid transfer amount');
            }
            log.error({ senderId, recipientId, amount, error }, 'Credit transfer failed');
            throw error;
        }
    },
    /**
     * Award credits for completed reps
     * Awards 1 credit per rep completed
     */
    async awardForReps(userId, repEventId, repCount) {
        if (repCount <= 0 || repCount > 500) {
            throw new errors_1.ValidationError('Rep count must be between 1 and 500');
        }
        return this.transact({
            userId,
            delta: repCount, // 1 credit per rep
            reason: CreditReason.REP_COMPLETED,
            refType: RefType.REP_EVENT,
            refId: repEventId,
            idempotencyKey: `reps:${repEventId}`,
        });
    },
    /**
     * Spend credits for an action
     */
    async spend(userId, amount, reason, refType, refId, idempotencyKey) {
        if (amount <= 0) {
            throw new errors_1.ValidationError('Amount must be positive');
        }
        return this.transact({
            userId,
            delta: -amount,
            reason,
            refType,
            refId,
            idempotencyKey,
        });
    },
    /**
     * Charge credits using the action-based system
     * Compatible with the original economy service interface
     */
    async charge(request) {
        const { userId, action, amount, metadata, idempotencyKey } = request;
        // Check if user has unlimited access (trial or subscription)
        const entitlements = await entitlements_1.entitlementsService.getEntitlements(userId);
        if (entitlements.unlimited) {
            log.info({
                userId,
                action,
                reason: entitlements.reason,
            }, 'Action performed with unlimited access');
            return {
                success: true,
                ledgerEntryId: undefined,
                newBalance: entitlements.creditBalance ?? undefined,
            };
        }
        try {
            const result = await (0, client_1.serializableTransaction)(async (client) => {
                // Check for existing idempotent transaction
                const existing = await client.query('SELECT id, balance_after FROM credit_ledger WHERE idempotency_key = $1', [idempotencyKey]);
                if (existing.rows.length > 0) {
                    return {
                        success: true,
                        ledgerEntryId: existing.rows[0].id,
                        newBalance: existing.rows[0].balance_after,
                        _wasIdempotent: true, // Don't invalidate cache for idempotent returns
                    };
                }
                // Get action cost
                let cost = amount;
                if (cost === undefined) {
                    const actionRow = await client.query('SELECT default_cost FROM credit_actions WHERE id = $1 AND enabled = TRUE', [action]);
                    if (actionRow.rows.length === 0) {
                        return { success: false, error: `Unknown action: ${action}` };
                    }
                    cost = actionRow.rows[0].default_cost;
                }
                // Get current balance with row-level lock
                const balance = await client.query('SELECT balance, version FROM credit_balances WHERE user_id = $1 FOR UPDATE', [userId]);
                if (balance.rows.length === 0) {
                    return { success: false, error: 'User has no credit account' };
                }
                const currentBalance = balance.rows[0].balance;
                const currentVersion = balance.rows[0].version;
                if (currentBalance < cost) {
                    return { success: false, error: 'Insufficient credits' };
                }
                const newBalance = currentBalance - cost;
                const entryId = `txn_${crypto_1.default.randomBytes(12).toString('hex')}`;
                // Atomic update with version check
                const updateResult = await client.query(`UPDATE credit_balances
           SET balance = $1, lifetime_spent = lifetime_spent + $2, version = version + 1, updated_at = NOW()
           WHERE user_id = $3 AND version = $4`, [newBalance, cost, userId, currentVersion]);
                if (updateResult.rowCount === 0) {
                    throw new errors_1.ConflictError('Concurrent modification detected');
                }
                // Insert ledger entry
                await client.query(`INSERT INTO credit_ledger (id, user_id, action, amount, balance_after, metadata, idempotency_key)
           VALUES ($1, $2, $3, $4, $5, $6, $7)`, [entryId, userId, action, -cost, newBalance, metadata ? JSON.stringify(metadata) : null, idempotencyKey]);
                log.info({
                    userId,
                    action,
                    amount: cost,
                    newBalance,
                }, 'Credits charged');
                return { success: true, ledgerEntryId: entryId, newBalance };
            });
            // Phase 6 Fix: Invalidate cache AFTER transaction commits successfully
            // This prevents stale reads during the transaction window
            if (result.success && !('_wasIdempotent' in result)) {
                await invalidateBalanceCache(userId);
            }
            return result;
        }
        catch (error) {
            // Handle unique constraint violation
            if (error.code === '23505' && error.constraint?.includes('idempotency')) {
                const existing = await (0, client_1.queryOne)('SELECT id, balance_after FROM credit_ledger WHERE idempotency_key = $1', [idempotencyKey]);
                if (existing) {
                    return {
                        success: true,
                        ledgerEntryId: existing.id,
                        newBalance: existing.balance_after,
                    };
                }
            }
            log.error({ error, request }, 'Credit charge failed');
            throw error;
        }
    },
    /**
     * Add credits to a user's balance
     */
    async addCredits(userId, amount, action, metadata, idempotencyKey) {
        const key = idempotencyKey || `add-${userId}-${Date.now()}-${crypto_1.default.randomBytes(4).toString('hex')}`;
        let wasIdempotent = false;
        const result = await (0, client_1.serializableTransaction)(async (client) => {
            // Check for existing idempotent transaction
            if (idempotencyKey) {
                const existing = await client.query('SELECT id, balance_after FROM credit_ledger WHERE idempotency_key = $1', [key]);
                if (existing.rows.length > 0) {
                    wasIdempotent = true;
                    return {
                        success: true,
                        ledgerEntryId: existing.rows[0].id,
                        newBalance: existing.rows[0].balance_after,
                    };
                }
            }
            // Upsert credit balance
            const balanceResult = await client.query(`INSERT INTO credit_balances (user_id, balance, lifetime_earned, version)
         VALUES ($1, $2, $2, 1)
         ON CONFLICT (user_id) DO UPDATE SET
           balance = credit_balances.balance + $2,
           lifetime_earned = credit_balances.lifetime_earned + $2,
           version = credit_balances.version + 1,
           updated_at = NOW()
         RETURNING balance`, [userId, amount]);
            const newBalance = balanceResult.rows[0].balance;
            const entryId = `txn_${crypto_1.default.randomBytes(12).toString('hex')}`;
            // Insert ledger entry
            await client.query(`INSERT INTO credit_ledger (id, user_id, action, amount, balance_after, metadata, idempotency_key)
         VALUES ($1, $2, $3, $4, $5, $6, $7)`, [entryId, userId, action, amount, newBalance, metadata ? JSON.stringify(metadata) : null, key]);
            log.info({ userId, action, amount, newBalance }, 'Credits added');
            return { success: true, ledgerEntryId: entryId, newBalance };
        });
        // Phase 6 Fix: Invalidate cache AFTER transaction commits successfully
        // This prevents stale reads during the transaction window
        if (result.success && !wasIdempotent) {
            await invalidateBalanceCache(userId);
        }
        return result;
    },
    /**
     * Get transaction history with pagination
     */
    async getHistory(userId, options = {}) {
        const { limit = 50, offset = 0, reason } = options;
        // Query with optional reason filter - using separate queries to avoid string interpolation
        // which triggers SQL injection warnings (even though this pattern is safe)
        const rows = reason
            ? await (0, client_1.queryAll)(`SELECT id, action, amount, balance_after, reason, ref_type, ref_id, metadata, created_at
           FROM credit_ledger
           WHERE user_id = $1 AND reason = $4
           ORDER BY created_at DESC
           LIMIT $2 OFFSET $3`, [userId, limit, offset, reason])
            : await (0, client_1.queryAll)(`SELECT id, action, amount, balance_after, reason, ref_type, ref_id, metadata, created_at
           FROM credit_ledger
           WHERE user_id = $1
           ORDER BY created_at DESC
           LIMIT $2 OFFSET $3`, [userId, limit, offset]);
        const countResult = reason
            ? await (0, client_1.queryOne)(`SELECT COUNT(*) as count FROM credit_ledger WHERE user_id = $1 AND reason = $2`, [userId, reason])
            : await (0, client_1.queryOne)(`SELECT COUNT(*) as count FROM credit_ledger WHERE user_id = $1`, [userId]);
        return {
            transactions: rows.map((row) => ({
                id: row.id,
                action: row.action,
                amount: row.amount,
                balanceAfter: row.balance_after,
                reason: row.reason,
                refType: row.ref_type,
                refId: row.ref_id ?? undefined,
                metadata: row.metadata || null,
                createdAt: row.created_at,
            })),
            total: parseInt(countResult?.count || '0', 10),
        };
    },
    /**
     * Initialize credit balance for new user
     */
    async initializeBalance(userId, initialBalance = 100) {
        await (0, client_1.query)(`INSERT INTO credit_balances (user_id, balance, lifetime_earned)
       VALUES ($1, $2, $2)
       ON CONFLICT (user_id) DO NOTHING`, [userId, initialBalance]);
    },
    /**
     * Check if user can afford a charge
     */
    async canAfford(userId, amount) {
        // Check for unlimited access first
        const entitlements = await entitlements_1.entitlementsService.getEntitlements(userId);
        if (entitlements.unlimited) {
            return true;
        }
        const balance = await this.getBalance(userId);
        return balance >= amount;
    },
};
//# sourceMappingURL=credit.service.js.map