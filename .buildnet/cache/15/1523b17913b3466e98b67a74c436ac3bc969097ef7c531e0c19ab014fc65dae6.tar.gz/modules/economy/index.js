"use strict";
/**
 * Economy Module
 *
 * Handles credit balance management with proper transaction isolation
 * and race condition prevention using PostgreSQL's serializable transactions.
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.socialSpendingService = exports.paymentsService = exports.geoHangoutsService = exports.bonusEventsService = exports.earnEventsService = exports.disputeService = exports.escrowService = exports.trustService = exports.RefType = exports.CreditReason = exports.creditService = exports.trainerService = exports.antiabuseService = exports.BUDDY_SPECIES = exports.buddyService = exports.storeService = exports.earningService = exports.walletService = exports.economyService = void 0;
const client_1 = require("../../db/client");
const errors_1 = require("../../lib/errors");
const logger_1 = require("../../lib/logger");
const crypto_1 = __importDefault(require("crypto"));
const entitlements_1 = require("../entitlements");
const log = logger_1.loggers.economy;
exports.economyService = {
    /**
     * Get user's current credit balance
     */
    async getBalance(userId) {
        const row = await (0, client_1.queryOne)('SELECT balance FROM credit_balances WHERE user_id = $1', [userId]);
        return row?.balance ?? 0;
    },
    /**
     * Check if user can afford a charge
     */
    async canCharge(userId, amount) {
        const balance = await this.getBalance(userId);
        return balance >= amount;
    },
    /**
     * Charge credits with proper transaction isolation
     *
     * Uses PostgreSQL's serializable isolation level for:
     * - Idempotency via unique constraint on idempotency_key
     * - Atomic balance update with version checking
     * - Automatic retry on serialization failure
     */
    async charge(request) {
        // Check if user has unlimited access (trial or subscription)
        const entitlements = await entitlements_1.entitlementsService.getEntitlements(request.userId);
        if (entitlements.unlimited) {
            log.info('Action performed with unlimited access', {
                userId: request.userId,
                action: request.action,
                reason: entitlements.reason,
            });
            return {
                success: true,
                ledgerEntryId: undefined,
                newBalance: entitlements.creditBalance ?? undefined,
            };
        }
        try {
            // Use serializable transaction for strongest isolation
            return await (0, client_1.serializableTransaction)(async (client) => {
                // Check for existing idempotent transaction
                const existing = await client.query('SELECT id, balance_after FROM credit_ledger WHERE idempotency_key = $1', [request.idempotencyKey]);
                if (existing.rows.length > 0) {
                    return {
                        success: true,
                        ledgerEntryId: existing.rows[0].id,
                        newBalance: existing.rows[0].balance_after,
                    };
                }
                // Get action cost
                let cost = request.amount;
                if (cost === undefined) {
                    const action = await client.query('SELECT default_cost FROM credit_actions WHERE id = $1 AND enabled = TRUE', [request.action]);
                    if (action.rows.length === 0) {
                        return { success: false, error: `Unknown action: ${request.action}` };
                    }
                    cost = action.rows[0].default_cost;
                }
                // Get current balance with row-level lock (FOR UPDATE)
                const balance = await client.query('SELECT balance, version FROM credit_balances WHERE user_id = $1 FOR UPDATE', [request.userId]);
                if (balance.rows.length === 0) {
                    return { success: false, error: 'User has no credit account' };
                }
                const currentBalance = balance.rows[0].balance;
                const currentVersion = balance.rows[0].version;
                if (currentBalance < cost) {
                    return { success: false, error: 'Insufficient credits' };
                }
                const newBalance = currentBalance - cost;
                const entryId = `txn_${crypto_1.default.randomBytes(12).toString('hex')}`;
                // Atomic update with version check
                const updateResult = await client.query(`UPDATE credit_balances
           SET balance = $1, lifetime_spent = lifetime_spent + $2, version = version + 1, updated_at = NOW()
           WHERE user_id = $3 AND version = $4`, [newBalance, cost, request.userId, currentVersion]);
                if (updateResult.rowCount === 0) {
                    throw new errors_1.ConflictError('Concurrent modification detected');
                }
                // Insert ledger entry (idempotency_key has UNIQUE constraint)
                await client.query(`INSERT INTO credit_ledger (id, user_id, action, amount, balance_after, metadata, idempotency_key)
           VALUES ($1, $2, $3, $4, $5, $6, $7)`, [
                    entryId,
                    request.userId,
                    request.action,
                    -cost,
                    newBalance,
                    request.metadata ? JSON.stringify(request.metadata) : null,
                    request.idempotencyKey,
                ]);
                log.info('Credits charged', {
                    userId: request.userId,
                    action: request.action,
                    amount: cost,
                    newBalance,
                });
                return { success: true, ledgerEntryId: entryId, newBalance };
            });
        }
        catch (error) {
            // Handle unique constraint violation (duplicate idempotency key from race)
            if (error.code === '23505' && error.constraint?.includes('idempotency')) {
                const existing = await (0, client_1.queryOne)('SELECT id, balance_after FROM credit_ledger WHERE idempotency_key = $1', [request.idempotencyKey]);
                if (existing) {
                    return {
                        success: true,
                        ledgerEntryId: existing.id,
                        newBalance: existing.balance_after,
                    };
                }
            }
            log.error({ error, request }, 'Credit charge failed');
            throw error;
        }
    },
    /**
     * Add credits to a user's balance (for purchases, rewards, etc.)
     */
    async addCredits(userId, amount, action, metadata, idempotencyKey) {
        const key = idempotencyKey || `add-${userId}-${Date.now()}-${crypto_1.default.randomBytes(4).toString('hex')}`;
        return await (0, client_1.serializableTransaction)(async (client) => {
            // Check for existing idempotent transaction
            if (idempotencyKey) {
                const existing = await client.query('SELECT id, balance_after FROM credit_ledger WHERE idempotency_key = $1', [key]);
                if (existing.rows.length > 0) {
                    return {
                        success: true,
                        ledgerEntryId: existing.rows[0].id,
                        newBalance: existing.rows[0].balance_after,
                    };
                }
            }
            // Upsert credit balance
            const result = await client.query(`INSERT INTO credit_balances (user_id, balance, lifetime_earned, version)
         VALUES ($1, $2, $2, 1)
         ON CONFLICT (user_id) DO UPDATE SET
           balance = credit_balances.balance + $2,
           lifetime_earned = credit_balances.lifetime_earned + $2,
           version = credit_balances.version + 1,
           updated_at = NOW()
         RETURNING balance`, [userId, amount]);
            const newBalance = result.rows[0].balance;
            const entryId = `txn_${crypto_1.default.randomBytes(12).toString('hex')}`;
            // Insert ledger entry
            await client.query(`INSERT INTO credit_ledger (id, user_id, action, amount, balance_after, metadata, idempotency_key)
         VALUES ($1, $2, $3, $4, $5, $6, $7)`, [entryId, userId, action, amount, newBalance, metadata ? JSON.stringify(metadata) : null, key]);
            log.info('Credits added', { userId, action, amount, newBalance });
            return { success: true, ledgerEntryId: entryId, newBalance };
        });
    },
    /**
     * Get transaction history with pagination
     */
    async getHistory(userId, limit = 50, offset = 0) {
        const rows = await (0, client_1.queryAll)(`SELECT id, action, amount, balance_after, metadata, created_at
       FROM credit_ledger
       WHERE user_id = $1
       ORDER BY created_at DESC
       LIMIT $2 OFFSET $3`, [userId, limit, offset]);
        return rows;
    },
    /**
     * Get total transaction count for pagination
     */
    async getHistoryCount(userId) {
        const result = await (0, client_1.queryOne)('SELECT COUNT(*) as count FROM credit_ledger WHERE user_id = $1', [userId]);
        return parseInt(result?.count || '0', 10);
    },
    /**
     * Initialize credit balance for new user
     */
    async initializeBalance(userId, initialBalance = 100) {
        await (0, client_1.query)(`INSERT INTO credit_balances (user_id, balance, lifetime_earned)
       VALUES ($1, $2, $2)
       ON CONFLICT (user_id) DO NOTHING`, [userId, initialBalance]);
    },
    /**
     * Refund credits to a user (wrapper around addCredits with refund action)
     */
    async refund(request) {
        // Get the action cost to refund if amount not specified
        let refundAmount = request.amount;
        if (refundAmount === undefined) {
            const action = await (0, client_1.queryOne)('SELECT default_cost FROM credit_actions WHERE id = $1', [request.action]);
            refundAmount = action?.default_cost ?? 25; // Default to 25 if action not found
        }
        return this.addCredits(request.userId, refundAmount, `refund.${request.action}`, { ...request.metadata, originalAction: request.action }, request.idempotencyKey);
    },
};
// Re-export all economy services
var wallet_service_1 = require("./wallet.service");
Object.defineProperty(exports, "walletService", { enumerable: true, get: function () { return wallet_service_1.walletService; } });
var earning_service_1 = require("./earning.service");
Object.defineProperty(exports, "earningService", { enumerable: true, get: function () { return earning_service_1.earningService; } });
var store_service_1 = require("./store.service");
Object.defineProperty(exports, "storeService", { enumerable: true, get: function () { return store_service_1.storeService; } });
var buddy_service_1 = require("./buddy.service");
Object.defineProperty(exports, "buddyService", { enumerable: true, get: function () { return buddy_service_1.buddyService; } });
Object.defineProperty(exports, "BUDDY_SPECIES", { enumerable: true, get: function () { return buddy_service_1.BUDDY_SPECIES; } });
var antiabuse_service_1 = require("./antiabuse.service");
Object.defineProperty(exports, "antiabuseService", { enumerable: true, get: function () { return antiabuse_service_1.antiabuseService; } });
var trainer_service_1 = require("./trainer.service");
Object.defineProperty(exports, "trainerService", { enumerable: true, get: function () { return trainer_service_1.trainerService; } });
var credit_service_1 = require("./credit.service");
Object.defineProperty(exports, "creditService", { enumerable: true, get: function () { return credit_service_1.creditService; } });
Object.defineProperty(exports, "CreditReason", { enumerable: true, get: function () { return credit_service_1.CreditReason; } });
Object.defineProperty(exports, "RefType", { enumerable: true, get: function () { return credit_service_1.RefType; } });
var trust_service_1 = require("./trust.service");
Object.defineProperty(exports, "trustService", { enumerable: true, get: function () { return trust_service_1.trustService; } });
var escrow_service_1 = require("./escrow.service");
Object.defineProperty(exports, "escrowService", { enumerable: true, get: function () { return escrow_service_1.escrowService; } });
var dispute_service_1 = require("./dispute.service");
Object.defineProperty(exports, "disputeService", { enumerable: true, get: function () { return dispute_service_1.disputeService; } });
// New economy enhancement services
var earnEvents_service_1 = require("./earnEvents.service");
Object.defineProperty(exports, "earnEventsService", { enumerable: true, get: function () { return earnEvents_service_1.earnEventsService; } });
var bonusEvents_service_1 = require("./bonusEvents.service");
Object.defineProperty(exports, "bonusEventsService", { enumerable: true, get: function () { return bonusEvents_service_1.bonusEventsService; } });
var geoHangouts_service_1 = require("./geoHangouts.service");
Object.defineProperty(exports, "geoHangoutsService", { enumerable: true, get: function () { return geoHangouts_service_1.geoHangoutsService; } });
var payments_service_1 = require("./payments.service");
Object.defineProperty(exports, "paymentsService", { enumerable: true, get: function () { return payments_service_1.paymentsService; } });
var socialSpending_service_1 = require("./socialSpending.service");
Object.defineProperty(exports, "socialSpendingService", { enumerable: true, get: function () { return socialSpending_service_1.socialSpendingService; } });
//# sourceMappingURL=index.js.map