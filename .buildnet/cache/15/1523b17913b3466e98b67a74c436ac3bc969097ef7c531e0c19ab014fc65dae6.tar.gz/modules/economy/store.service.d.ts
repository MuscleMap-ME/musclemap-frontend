/**
 * Store Service
 *
 * Handles the in-app store for purchasing:
 * - Training Buddy species and cosmetics
 * - App cosmetics (frames, themes, trails)
 * - Community actions (tips, boosts, challenges)
 * - Utility unlocks (analytics, export, support)
 * - Trainer features (promotion, verification)
 * - Status/prestige items
 */
export interface StoreItem {
    sku: string;
    name: string;
    description?: string;
    category: string;
    subcategory?: string;
    priceCredits: number;
    rarity: 'common' | 'uncommon' | 'rare' | 'epic' | 'legendary';
    limitedQuantity?: number;
    soldCount: number;
    requiresLevel: number;
    requiresItems: string[];
    metadata: Record<string, unknown>;
    enabled: boolean;
    featured: boolean;
    sortOrder: number;
}
export interface InventoryItem {
    id: string;
    userId: string;
    sku: string;
    item: StoreItem;
    quantity: number;
    purchasedAt: Date;
    expiresAt?: Date;
}
export interface PurchaseResult {
    success: boolean;
    inventoryId?: string;
    newBalance?: number;
    error?: string;
}
export declare const storeService: {
    /**
     * Get all store items with optional filtering
     */
    getItems(options?: {
        category?: string;
        rarity?: string;
        featured?: boolean;
        enabledOnly?: boolean;
        limit?: number;
        offset?: number;
    }): Promise<{
        items: StoreItem[];
        total: number;
    }>;
    /**
     * Get a specific store item by SKU
     */
    getItem(sku: string): Promise<StoreItem | null>;
    /**
     * Get store categories
     */
    getCategories(): Promise<Array<{
        category: string;
        count: number;
    }>>;
    /**
     * Purchase a store item
     */
    purchase(userId: string, sku: string, metadata?: Record<string, unknown>): Promise<PurchaseResult>;
    /**
     * Get user's inventory
     */
    getInventory(userId: string, options?: {
        category?: string;
        limit?: number;
        offset?: number;
    }): Promise<{
        items: InventoryItem[];
        total: number;
    }>;
    /**
     * Check if user owns an item
     */
    ownsItem(userId: string, sku: string): Promise<boolean>;
    /**
     * Get all items owned by user as a set of SKUs
     */
    getOwnedSkus(userId: string): Promise<Set<string>>;
    /**
     * Check if a category is consumable (can be purchased multiple times)
     */
    isConsumable(category: string): boolean;
    /**
     * Get featured items
     */
    getFeaturedItems(limit?: number): Promise<StoreItem[]>;
    /**
     * Get items by rarity
     */
    getItemsByRarity(rarity: string, limit?: number): Promise<StoreItem[]>;
    /**
     * Admin: Grant an item to a user
     */
    grantItem(userId: string, sku: string, adminUserId: string, reason: string): Promise<string>;
    /**
     * Admin: Revoke an item from a user
     */
    revokeItem(userId: string, sku: string, adminUserId: string, reason: string): Promise<void>;
};
export default storeService;
