/**
 * Escrow Service
 *
 * Manages escrow holds for class bookings, challenges, and marketplace transactions.
 * Credits are held until conditions are met, then released to recipients.
 */
export type HoldType = 'class_booking' | 'challenge_stake' | 'marketplace' | 'other';
export type EscrowStatus = 'held' | 'released' | 'refunded' | 'disputed' | 'forfeited';
export interface EscrowHold {
    id: string;
    userId: string;
    amount: number;
    holdType: HoldType;
    referenceType: string;
    referenceId: string;
    status: EscrowStatus;
    releaseTo?: string;
    releaseAmount?: number;
    feeAmount: number;
    holdUntil?: Date;
    autoRelease: boolean;
    createdAt: Date;
    releasedAt?: Date;
}
export interface CreateEscrowInput {
    userId: string;
    amount: number;
    holdType: HoldType;
    referenceType: string;
    referenceId: string;
    releaseTo?: string;
    holdUntil?: Date;
    autoRelease?: boolean;
}
export interface ReleaseEscrowInput {
    escrowId: string;
    releaseTo?: string;
    releaseAmount?: number;
    feeAmount?: number;
    releasedBy: string;
    reason: string;
}
export declare const escrowService: {
    /**
     * Create an escrow hold by charging the user
     */
    createHold(input: CreateEscrowInput): Promise<EscrowHold>;
    /**
     * Get escrow hold by ID
     */
    getHold(escrowId: string): Promise<EscrowHold | null>;
    /**
     * Get escrow hold by reference
     */
    getHoldByReference(referenceType: string, referenceId: string): Promise<EscrowHold | null>;
    /**
     * Release escrow to recipient
     */
    release(input: ReleaseEscrowInput): Promise<{
        released: boolean;
        recipientNewBalance?: number;
    }>;
    /**
     * Refund escrow to original holder
     */
    refund(escrowId: string, refundedBy: string, reason: string): Promise<{
        refunded: boolean;
        newBalance: number;
    }>;
    /**
     * Mark escrow as disputed
     */
    dispute(escrowId: string): Promise<void>;
    /**
     * Get user's active escrow holds
     */
    getUserHolds(userId: string, status?: EscrowStatus): Promise<EscrowHold[]>;
    /**
     * Process auto-release for expired holds
     */
    processAutoReleases(): Promise<{
        processed: number;
    }>;
};
export default escrowService;
