"use strict";
/**
 * Geo Hangouts Service
 *
 * Handles location-based community features:
 * - User location tracking (with privacy controls)
 * - Automatic hangout creation based on location clusters
 * - Distance-based member sorting
 * - Local leaderboards
 * - Hangout challenges and events
 *
 * Users feel at home in their local community!
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.geoHangoutsService = void 0;
const crypto_1 = __importDefault(require("crypto"));
const client_1 = require("../../db/client");
const logger_1 = require("../../lib/logger");
const log = logger_1.loggers.social;
// Distance calculation constants
const EARTH_RADIUS_MILES = 3958.8;
// Hangout radius tiers in miles
const HANGOUT_RADIUS = 25;
const DISTANCE_TIERS = {
    neighbor: 5,
    local: 15,
    regional: 50,
    extended: 100,
};
exports.geoHangoutsService = {
    /**
     * Calculate distance between two coordinates using Haversine formula
     */
    calculateDistance(lat1, lng1, lat2, lng2) {
        const toRad = (deg) => deg * (Math.PI / 180);
        const dLat = toRad(lat2 - lat1);
        const dLng = toRad(lng2 - lng1);
        const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
            Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) *
                Math.sin(dLng / 2) * Math.sin(dLng / 2);
        const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        return EARTH_RADIUS_MILES * c;
    },
    /**
     * Get distance tier based on miles
     */
    getDistanceTier(miles) {
        if (miles < DISTANCE_TIERS.neighbor)
            return 'neighbor';
        if (miles < DISTANCE_TIERS.local)
            return 'local';
        if (miles < DISTANCE_TIERS.regional)
            return 'regional';
        return 'extended';
    },
    /**
     * Update user's location
     */
    async updateUserLocation(userId, latitude, longitude, options = {}) {
        const result = await (0, client_1.queryOne)(`INSERT INTO user_locations (user_id, latitude, longitude, accuracy_meters, city, state_province, country, postal_code, timezone, share_exact, share_city, visible_in_hangout, updated_at)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, NOW())
       ON CONFLICT (user_id) DO UPDATE SET
         latitude = EXCLUDED.latitude,
         longitude = EXCLUDED.longitude,
         accuracy_meters = COALESCE(EXCLUDED.accuracy_meters, user_locations.accuracy_meters),
         city = COALESCE(EXCLUDED.city, user_locations.city),
         state_province = COALESCE(EXCLUDED.state_province, user_locations.state_province),
         country = COALESCE(EXCLUDED.country, user_locations.country),
         postal_code = COALESCE(EXCLUDED.postal_code, user_locations.postal_code),
         timezone = COALESCE(EXCLUDED.timezone, user_locations.timezone),
         share_exact = COALESCE(EXCLUDED.share_exact, user_locations.share_exact),
         share_city = COALESCE(EXCLUDED.share_city, user_locations.share_city),
         visible_in_hangout = COALESCE(EXCLUDED.visible_in_hangout, user_locations.visible_in_hangout),
         updated_at = NOW()
       RETURNING *`, [
            userId,
            latitude,
            longitude,
            options.accuracyMeters || null,
            options.city || null,
            options.stateProvince || null,
            options.country || null,
            options.postalCode || null,
            options.timezone || null,
            options.shareExact ?? false,
            options.shareCity ?? true,
            options.visibleInHangout ?? true,
        ]);
        if (!result)
            throw new Error('Failed to update location');
        // Auto-assign to nearest hangout
        await this.assignUserToNearestHangout(userId, latitude, longitude);
        return {
            userId: result.user_id,
            latitude: parseFloat(result.latitude),
            longitude: parseFloat(result.longitude),
            accuracyMeters: result.accuracy_meters || undefined,
            city: result.city || undefined,
            stateProvince: result.state_province || undefined,
            country: result.country || undefined,
            postalCode: result.postal_code || undefined,
            timezone: result.timezone || undefined,
            shareExact: result.share_exact,
            shareCity: result.share_city,
            visibleInHangout: result.visible_in_hangout,
            updatedAt: result.updated_at,
        };
    },
    /**
     * Get user's location
     */
    async getUserLocation(userId) {
        const row = await (0, client_1.queryOne)('SELECT * FROM user_locations WHERE user_id = $1', [userId]);
        if (!row || !row.latitude || !row.longitude)
            return null;
        return {
            userId: row.user_id,
            latitude: parseFloat(row.latitude),
            longitude: parseFloat(row.longitude),
            accuracyMeters: row.accuracy_meters || undefined,
            city: row.city || undefined,
            stateProvince: row.state_province || undefined,
            country: row.country || undefined,
            postalCode: row.postal_code || undefined,
            timezone: row.timezone || undefined,
            shareExact: row.share_exact,
            shareCity: row.share_city,
            visibleInHangout: row.visible_in_hangout,
            updatedAt: row.updated_at,
        };
    },
    /**
     * Find or create a hangout for a location
     */
    async findOrCreateHangout(latitude, longitude, city, stateProvince, country) {
        // First try to find an existing hangout within radius
        const existing = await (0, client_1.queryOne)(`SELECT * FROM geo_hangouts
       WHERE enabled = true
       ORDER BY (
         (center_latitude - $1) * (center_latitude - $1) +
         (center_longitude - $2) * (center_longitude - $2)
       )
       LIMIT 1`, [latitude, longitude]);
        if (existing) {
            const distance = this.calculateDistance(latitude, longitude, parseFloat(existing.center_latitude), parseFloat(existing.center_longitude));
            if (distance <= existing.radius_miles) {
                return {
                    id: existing.id,
                    name: existing.name,
                    centerLatitude: parseFloat(existing.center_latitude),
                    centerLongitude: parseFloat(existing.center_longitude),
                    radiusMiles: existing.radius_miles,
                    city: existing.city || undefined,
                    stateProvince: existing.state_province || undefined,
                    country: existing.country || undefined,
                    memberCount: existing.member_count,
                    activeToday: existing.active_today,
                    activeThisWeek: existing.active_this_week,
                    autoGenerated: existing.auto_generated,
                    enabled: existing.enabled,
                    createdAt: existing.created_at,
                };
            }
        }
        // Create a new hangout
        const name = city
            ? `${city} Fitness Crew`
            : stateProvince
                ? `${stateProvince} Fitness Crew`
                : `Local Fitness Crew`;
        const id = `geo_${crypto_1.default.randomBytes(12).toString('hex')}`;
        await (0, client_1.query)(`INSERT INTO geo_hangouts (id, name, center_latitude, center_longitude, radius_miles, city, state_province, country, auto_generated)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, true)`, [id, name, latitude, longitude, HANGOUT_RADIUS, city || null, stateProvince || null, country || null]);
        log.info({ id, name, latitude, longitude }, 'Created new geo hangout');
        return {
            id,
            name,
            centerLatitude: latitude,
            centerLongitude: longitude,
            radiusMiles: HANGOUT_RADIUS,
            city,
            stateProvince,
            country,
            memberCount: 0,
            activeToday: 0,
            activeThisWeek: 0,
            autoGenerated: true,
            enabled: true,
            createdAt: new Date(),
        };
    },
    /**
     * Assign user to their nearest hangout
     */
    async assignUserToNearestHangout(userId, latitude, longitude) {
        // Get or create the nearest hangout
        const location = await this.getUserLocation(userId);
        const hangout = await this.findOrCreateHangout(latitude, longitude, location?.city, location?.stateProvince, location?.country);
        const distance = this.calculateDistance(latitude, longitude, hangout.centerLatitude, hangout.centerLongitude);
        // Remove existing primary membership if different
        await (0, client_1.query)(`UPDATE user_hangout_memberships SET is_primary = false
       WHERE user_id = $1 AND is_primary = true AND hangout_id != $2`, [userId, hangout.id]);
        // Add/update membership
        await (0, client_1.query)(`INSERT INTO user_hangout_memberships (user_id, hangout_id, is_primary, distance_miles, last_active_at)
       VALUES ($1, $2, true, $3, NOW())
       ON CONFLICT (user_id, hangout_id) DO UPDATE SET
         is_primary = true,
         distance_miles = EXCLUDED.distance_miles,
         last_active_at = NOW()`, [userId, hangout.id, distance]);
        // Update hangout member count
        await (0, client_1.query)(`UPDATE geo_hangouts SET member_count = (
         SELECT COUNT(DISTINCT user_id) FROM user_hangout_memberships WHERE hangout_id = $1
       ) WHERE id = $1`, [hangout.id]);
    },
    /**
     * Get user's primary hangout
     */
    async getUserPrimaryHangout(userId) {
        const row = await (0, client_1.queryOne)(`SELECT h.* FROM geo_hangouts h
       JOIN user_hangout_memberships m ON m.hangout_id = h.id
       WHERE m.user_id = $1 AND m.is_primary = true`, [userId]);
        if (!row)
            return null;
        return {
            id: row.id,
            name: row.name,
            centerLatitude: parseFloat(row.center_latitude),
            centerLongitude: parseFloat(row.center_longitude),
            radiusMiles: row.radius_miles,
            city: row.city || undefined,
            stateProvince: row.state_province || undefined,
            country: row.country || undefined,
            memberCount: row.member_count,
            activeToday: row.active_today,
            activeThisWeek: row.active_this_week,
            autoGenerated: row.auto_generated,
            enabled: row.enabled,
            createdAt: row.created_at,
        };
    },
    /**
     * Get hangout members sorted by distance from a user
     */
    async getHangoutMembers(hangoutId, viewerUserId, options = {}) {
        const { limit = 50, offset = 0, onlineOnly = false } = options;
        // Get viewer's location
        const viewerLocation = await this.getUserLocation(viewerUserId);
        let whereClause = 'WHERE m.hangout_id = $1';
        const params = [hangoutId];
        if (onlineOnly) {
            whereClause += ' AND m.last_active_at > NOW() - INTERVAL \'15 minutes\'';
        }
        // Get members with distance calculation
        const rows = await (0, client_1.queryAll)(`SELECT
         m.user_id,
         u.username,
         u.display_name,
         COALESCE(u.wealth_tier, 0) as wealth_tier,
         m.is_primary,
         m.last_active_at,
         l.city,
         l.latitude,
         l.longitude,
         COALESCE(l.share_exact, false) as share_exact,
         COALESCE(l.visible_in_hangout, true) as visible_in_hangout,
         m.distance_miles
       FROM user_hangout_memberships m
       JOIN users u ON u.id = m.user_id
       LEFT JOIN user_locations l ON l.user_id = m.user_id
       ${whereClause}
       ORDER BY m.distance_miles ASC NULLS LAST
       LIMIT $${params.length + 1} OFFSET $${params.length + 2}`, [...params, limit, offset]);
        // Get total count
        const countResult = await (0, client_1.queryOne)(`SELECT COUNT(*) as count FROM user_hangout_memberships m ${whereClause}`, params);
        const members = [];
        for (const row of rows) {
            if (!row.visible_in_hangout)
                continue;
            let distanceMiles = parseFloat(row.distance_miles || '0');
            // Calculate distance from viewer if we have coordinates
            if (viewerLocation && row.latitude && row.longitude) {
                distanceMiles = this.calculateDistance(viewerLocation.latitude, viewerLocation.longitude, parseFloat(row.latitude), parseFloat(row.longitude));
            }
            members.push({
                userId: row.user_id,
                username: row.username,
                displayName: row.display_name || undefined,
                wealthTier: row.wealth_tier,
                distanceMiles: row.share_exact ? distanceMiles : Math.round(distanceMiles),
                distanceTier: this.getDistanceTier(distanceMiles),
                isPrimary: row.is_primary,
                lastActiveAt: row.last_active_at || undefined,
                city: row.city || undefined,
            });
        }
        // Sort by distance from viewer
        members.sort((a, b) => a.distanceMiles - b.distanceMiles);
        return {
            members,
            total: parseInt(countResult?.count || '0'),
        };
    },
    /**
     * Get hangout by ID
     */
    async getHangout(hangoutId) {
        const row = await (0, client_1.queryOne)('SELECT * FROM geo_hangouts WHERE id = $1', [hangoutId]);
        if (!row)
            return null;
        return {
            id: row.id,
            name: row.name,
            centerLatitude: parseFloat(row.center_latitude),
            centerLongitude: parseFloat(row.center_longitude),
            radiusMiles: row.radius_miles,
            city: row.city || undefined,
            stateProvince: row.state_province || undefined,
            country: row.country || undefined,
            memberCount: row.member_count,
            activeToday: row.active_today,
            activeThisWeek: row.active_this_week,
            autoGenerated: row.auto_generated,
            enabled: row.enabled,
            createdAt: row.created_at,
        };
    },
    /**
     * Create a hangout challenge
     */
    async createChallenge(hangoutId, createdBy, params) {
        const id = `hc_${crypto_1.default.randomBytes(12).toString('hex')}`;
        await (0, client_1.query)(`INSERT INTO hangout_challenges (id, hangout_id, name, description, challenge_type, metric_key, starts_at, ends_at, base_prize, entry_fee, max_participants, created_by, status)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, 'upcoming')`, [
            id,
            hangoutId,
            params.name,
            params.description || null,
            params.challengeType,
            params.metricKey || null,
            params.startsAt,
            params.endsAt,
            params.basePrize || 0,
            params.entryFee || 0,
            params.maxParticipants || null,
            createdBy,
        ]);
        log.info({ id, hangoutId, name: params.name }, 'Created hangout challenge');
        return {
            id,
            hangoutId: hangoutId || undefined,
            name: params.name,
            description: params.description,
            challengeType: params.challengeType,
            metricKey: params.metricKey,
            startsAt: params.startsAt,
            endsAt: params.endsAt,
            basePrize: params.basePrize || 0,
            contributedPrize: 0,
            totalPrize: params.basePrize || 0,
            entryFee: params.entryFee || 0,
            maxParticipants: params.maxParticipants,
            participantCount: 0,
            status: 'upcoming',
            createdBy,
        };
    },
    /**
     * Get hangout challenges
     */
    async getHangoutChallenges(hangoutId, options = {}) {
        const { status, limit = 20, offset = 0 } = options;
        let whereClause = 'WHERE hangout_id = $1';
        const params = [hangoutId];
        if (status) {
            whereClause += ` AND status = $${params.length + 1}`;
            params.push(status);
        }
        const rows = await (0, client_1.queryAll)(`SELECT c.*,
         (SELECT COUNT(*) FROM hangout_challenge_participants WHERE challenge_id = c.id) as participant_count
       FROM hangout_challenges c
       ${whereClause}
       ORDER BY starts_at DESC
       LIMIT $${params.length + 1} OFFSET $${params.length + 2}`, [...params, limit, offset]);
        return rows.map(r => ({
            id: r.id,
            hangoutId: r.hangout_id || undefined,
            name: r.name,
            description: r.description || undefined,
            challengeType: r.challenge_type,
            metricKey: r.metric_key || undefined,
            startsAt: r.starts_at,
            endsAt: r.ends_at,
            basePrize: r.base_prize,
            contributedPrize: r.contributed_prize,
            totalPrize: r.base_prize + r.contributed_prize,
            entryFee: r.entry_fee,
            maxParticipants: r.max_participants || undefined,
            participantCount: parseInt(r.participant_count, 10) || 0,
            status: r.status,
            createdBy: r.created_by || undefined,
        }));
    },
    /**
     * Create a hangout event
     */
    async createEvent(hangoutId, createdBy, params) {
        const id = `he_${crypto_1.default.randomBytes(12).toString('hex')}`;
        await (0, client_1.query)(`INSERT INTO hangout_events (id, hangout_id, created_by, title, description, starts_at, ends_at, location_type, location_name, location_address, max_attendees, status)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, 'scheduled')`, [
            id,
            hangoutId,
            createdBy,
            params.title,
            params.description || null,
            params.startsAt,
            params.endsAt || null,
            params.locationType,
            params.locationName || null,
            params.locationAddress || null,
            params.maxAttendees || null,
        ]);
        log.info({ id, hangoutId, title: params.title }, 'Created hangout event');
        return {
            id,
            hangoutId,
            createdBy,
            title: params.title,
            description: params.description,
            startsAt: params.startsAt,
            endsAt: params.endsAt,
            locationType: params.locationType,
            locationName: params.locationName,
            locationAddress: params.locationAddress,
            maxAttendees: params.maxAttendees,
            attendeesCount: 0,
            isFeatured: false,
            status: 'scheduled',
        };
    },
    /**
     * Get hangout events
     */
    async getHangoutEvents(hangoutId, options = {}) {
        const { upcoming = true, limit = 20, offset = 0 } = options;
        let whereClause = 'WHERE e.hangout_id = $1';
        if (upcoming) {
            whereClause += " AND e.starts_at > NOW() AND e.status = 'scheduled'";
        }
        const rows = await (0, client_1.queryAll)(`SELECT e.id, e.hangout_id, e.created_by, e.title, e.description, e.starts_at, e.ends_at,
        e.location_type, e.location_name, e.location_address, e.max_attendees, e.is_featured, e.status,
        (SELECT COUNT(*) FROM hangout_event_attendees WHERE event_id = e.id AND status = 'going') as attendees_count
       FROM hangout_events e
       ${whereClause}
       ORDER BY e.starts_at ASC
       LIMIT $2 OFFSET $3`, [hangoutId, limit, offset]);
        return rows.map(r => ({
            id: r.id,
            hangoutId: r.hangout_id,
            createdBy: r.created_by,
            title: r.title,
            description: r.description || undefined,
            startsAt: r.starts_at,
            endsAt: r.ends_at || undefined,
            locationType: r.location_type,
            locationName: r.location_name || undefined,
            locationAddress: r.location_address || undefined,
            maxAttendees: r.max_attendees || undefined,
            attendeesCount: parseInt(r.attendees_count, 10) || 0,
            isFeatured: r.is_featured,
            status: r.status,
        }));
    },
    /**
     * Update activity stats for a hangout (call periodically)
     */
    async updateActivityStats(hangoutId) {
        await (0, client_1.query)(`UPDATE geo_hangouts SET
         active_today = (
           SELECT COUNT(DISTINCT user_id) FROM user_hangout_memberships
           WHERE hangout_id = $1 AND last_active_at >= CURRENT_DATE
         ),
         active_this_week = (
           SELECT COUNT(DISTINCT user_id) FROM user_hangout_memberships
           WHERE hangout_id = $1 AND last_active_at >= DATE_TRUNC('week', CURRENT_DATE)
         ),
         updated_at = NOW()
       WHERE id = $1`, [hangoutId]);
    },
    /**
     * Record user activity in hangout
     */
    async recordActivity(userId, hangoutId) {
        await (0, client_1.query)(`UPDATE user_hangout_memberships SET last_active_at = NOW()
       WHERE user_id = $1 AND hangout_id = $2`, [userId, hangoutId]);
    },
};
exports.default = exports.geoHangoutsService;
//# sourceMappingURL=geoHangouts.service.js.map