"use strict";
/**
 * Dispute Service
 *
 * Handles disputes for classes, transfers, and other economy transactions.
 * Provides a workflow for reporting, investigating, and resolving disputes.
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.disputeService = void 0;
const crypto_1 = __importDefault(require("crypto"));
const client_1 = require("../../db/client");
const logger_1 = require("../../lib/logger");
const errors_1 = require("../../lib/errors");
const escrow_service_1 = require("./escrow.service");
const log = logger_1.loggers.economy;
exports.disputeService = {
    /**
     * Get economy setting value
     */
    async getSetting(key, defaultValue) {
        const row = await (0, client_1.queryOne)(`SELECT value FROM economy_settings WHERE key = $1`, [key]);
        return row ? JSON.parse(row.value) : defaultValue;
    },
    /**
     * Create a new dispute
     */
    async createDispute(input) {
        const { reporterId, respondentId, disputeType, referenceType, referenceId, amountDisputed, escrowId, description, evidence = [], } = input;
        // Validate reporter and respondent are different
        if (reporterId === respondentId) {
            throw new errors_1.ValidationError('Cannot create a dispute against yourself');
        }
        // Check for existing open dispute on same reference
        const existing = await (0, client_1.queryOne)(`SELECT id FROM economy_disputes
       WHERE reference_type = $1 AND reference_id = $2 AND status NOT IN ('dismissed', 'resolved_reporter', 'resolved_respondent', 'resolved_split')`, [referenceType, referenceId]);
        if (existing) {
            throw new errors_1.ValidationError('A dispute is already open for this reference');
        }
        // Check dispute window for class disputes
        if (disputeType === 'class_noshow' || disputeType === 'class_quality') {
            const disputeWindowHours = await this.getSetting('dispute_window_hours', 48);
            const classRow = await (0, client_1.queryOne)(`SELECT start_at, status FROM trainer_classes WHERE id = $1`, [referenceId]);
            if (classRow) {
                const classTime = new Date(classRow.start_at);
                const windowEnd = new Date(classTime.getTime() + disputeWindowHours * 60 * 60 * 1000);
                if (new Date() > windowEnd) {
                    throw new errors_1.ValidationError(`Dispute window has expired. Disputes must be filed within ${disputeWindowHours} hours of class completion.`);
                }
            }
        }
        // Mark escrow as disputed if provided
        if (escrowId) {
            await escrow_service_1.escrowService.dispute(escrowId);
        }
        const disputeId = `dispute_${crypto_1.default.randomBytes(12).toString('hex')}`;
        const disputeWindowHours = await this.getSetting('dispute_window_hours', 48);
        const deadline = new Date(Date.now() + disputeWindowHours * 60 * 60 * 1000);
        await (0, client_1.query)(`INSERT INTO economy_disputes (id, reporter_id, respondent_id, dispute_type, reference_type, reference_id, amount_disputed, escrow_id, description, evidence, deadline)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)`, [disputeId, reporterId, respondentId, disputeType, referenceType, referenceId, amountDisputed || null, escrowId || null, description, JSON.stringify(evidence.map(e => ({ ...e, uploadedAt: new Date().toISOString() }))), deadline]);
        log.info({ disputeId, reporterId, respondentId, disputeType, referenceId }, 'Dispute created');
        return (await this.getDispute(disputeId));
    },
    /**
     * Get dispute by ID
     */
    async getDispute(disputeId) {
        const row = await (0, client_1.queryOne)(`SELECT * FROM economy_disputes WHERE id = $1`, [disputeId]);
        if (!row)
            return null;
        return {
            id: row.id,
            reporterId: row.reporter_id,
            respondentId: row.respondent_id,
            disputeType: row.dispute_type,
            referenceType: row.reference_type,
            referenceId: row.reference_id,
            amountDisputed: row.amount_disputed ?? undefined,
            escrowId: row.escrow_id ?? undefined,
            description: row.description,
            evidence: row.evidence || [],
            status: row.status,
            resolution: row.resolution ?? undefined,
            resolutionAmount: row.resolution_amount ?? undefined,
            resolvedBy: row.resolved_by ?? undefined,
            resolvedAt: row.resolved_at ?? undefined,
            deadline: row.deadline ?? undefined,
            createdAt: row.created_at,
            updatedAt: row.updated_at,
        };
    },
    /**
     * Get disputes for a user (as reporter or respondent)
     */
    async getUserDisputes(userId, options = {}) {
        const { role = 'all', status, limit = 50, offset = 0 } = options;
        let whereClause = role === 'reporter'
            ? 'reporter_id = $1'
            : role === 'respondent'
                ? 'respondent_id = $1'
                : '(reporter_id = $1 OR respondent_id = $1)';
        const params = [userId];
        let paramIndex = 2;
        if (status) {
            whereClause += ` AND status = $${paramIndex++}`;
            params.push(status);
        }
        params.push(limit, offset);
        const rows = await (0, client_1.queryAll)(`SELECT * FROM economy_disputes WHERE ${whereClause} ORDER BY created_at DESC LIMIT $${paramIndex++} OFFSET $${paramIndex++}`, params);
        const countResult = await (0, client_1.queryOne)(`SELECT COUNT(*) as count FROM economy_disputes WHERE ${whereClause}`, params.slice(0, -2));
        return {
            disputes: rows.map((row) => ({
                id: row.id,
                reporterId: row.reporter_id,
                respondentId: row.respondent_id,
                disputeType: row.dispute_type,
                referenceType: row.reference_type,
                referenceId: row.reference_id,
                amountDisputed: row.amount_disputed ?? undefined,
                escrowId: row.escrow_id ?? undefined,
                description: row.description,
                evidence: row.evidence || [],
                status: row.status,
                resolution: row.resolution ?? undefined,
                resolutionAmount: row.resolution_amount ?? undefined,
                resolvedBy: row.resolved_by ?? undefined,
                resolvedAt: row.resolved_at ?? undefined,
                deadline: row.deadline ?? undefined,
                createdAt: row.created_at,
                updatedAt: row.updated_at,
            })),
            total: parseInt(countResult?.count || '0'),
        };
    },
    /**
     * Add message to dispute
     */
    async addMessage(disputeId, senderId, message, isAdmin = false, attachments = []) {
        const dispute = await this.getDispute(disputeId);
        if (!dispute) {
            throw new errors_1.NotFoundError('Dispute not found');
        }
        // Verify sender is involved or is admin
        if (!isAdmin && senderId !== dispute.reporterId && senderId !== dispute.respondentId) {
            throw new errors_1.ForbiddenError('You are not authorized to message in this dispute');
        }
        // Check dispute is still open
        if (['dismissed', 'resolved_reporter', 'resolved_respondent', 'resolved_split'].includes(dispute.status)) {
            throw new errors_1.ValidationError('Dispute is already closed');
        }
        const messageId = `dmsg_${crypto_1.default.randomBytes(12).toString('hex')}`;
        await (0, client_1.query)(`INSERT INTO dispute_messages (id, dispute_id, sender_id, is_admin, message, attachments)
       VALUES ($1, $2, $3, $4, $5, $6)`, [messageId, disputeId, senderId, isAdmin, message, JSON.stringify(attachments)]);
        // Update dispute status if respondent is replying
        if (senderId === dispute.respondentId && dispute.status === 'open') {
            await (0, client_1.query)(`UPDATE economy_disputes SET status = 'pending_response', updated_at = NOW() WHERE id = $1`, [disputeId]);
        }
        return {
            id: messageId,
            disputeId,
            senderId,
            isAdmin,
            message,
            attachments,
            createdAt: new Date(),
        };
    },
    /**
     * Get messages for a dispute
     */
    async getMessages(disputeId) {
        const rows = await (0, client_1.queryAll)(`SELECT * FROM dispute_messages WHERE dispute_id = $1 ORDER BY created_at ASC`, [disputeId]);
        return rows.map((row) => ({
            id: row.id,
            disputeId: row.dispute_id,
            senderId: row.sender_id,
            isAdmin: row.is_admin,
            message: row.message,
            attachments: row.attachments || [],
            createdAt: row.created_at,
        }));
    },
    /**
     * Update dispute status (admin)
     */
    async updateStatus(disputeId, status, adminId) {
        const dispute = await this.getDispute(disputeId);
        if (!dispute) {
            throw new errors_1.NotFoundError('Dispute not found');
        }
        await (0, client_1.query)(`UPDATE economy_disputes SET status = $1, updated_at = NOW() WHERE id = $2`, [status, disputeId]);
        log.info({ disputeId, status, adminId }, 'Dispute status updated');
    },
    /**
     * Resolve dispute (admin)
     */
    async resolve(disputeId, adminId, resolution) {
        const dispute = await this.getDispute(disputeId);
        if (!dispute) {
            throw new errors_1.NotFoundError('Dispute not found');
        }
        if (['dismissed', 'resolved_reporter', 'resolved_respondent', 'resolved_split'].includes(dispute.status)) {
            throw new errors_1.ValidationError('Dispute is already resolved');
        }
        // Handle escrow if exists
        if (dispute.escrowId) {
            const hold = await escrow_service_1.escrowService.getHold(dispute.escrowId);
            if (hold && hold.status === 'disputed') {
                switch (resolution.status) {
                    case 'resolved_reporter':
                        // Refund to reporter
                        await escrow_service_1.escrowService.refund(dispute.escrowId, adminId, `Dispute resolved in favor of reporter: ${resolution.resolution}`);
                        break;
                    case 'resolved_respondent':
                        // Release to respondent
                        await escrow_service_1.escrowService.release({
                            escrowId: dispute.escrowId,
                            releaseTo: dispute.respondentId,
                            releasedBy: adminId,
                            reason: `Dispute resolved in favor of respondent: ${resolution.resolution}`,
                        });
                        break;
                    case 'resolved_split':
                        // Split the escrow
                        const splitRatio = resolution.splitRatio ?? 0.5;
                        const reporterAmount = Math.floor(hold.amount * splitRatio);
                        const _respondentAmount = hold.amount - reporterAmount;
                        // First refund reporter's portion
                        // Note: This is simplified - in production you'd want atomic handling
                        await escrow_service_1.escrowService.release({
                            escrowId: dispute.escrowId,
                            releaseTo: dispute.reporterId,
                            releaseAmount: reporterAmount,
                            releasedBy: adminId,
                            reason: `Dispute split resolution - reporter portion`,
                        });
                        break;
                    case 'dismissed':
                        // Release to original intended recipient
                        if (hold.releaseTo) {
                            await escrow_service_1.escrowService.release({
                                escrowId: dispute.escrowId,
                                releasedBy: adminId,
                                reason: `Dispute dismissed: ${resolution.resolution}`,
                            });
                        }
                        break;
                }
            }
        }
        // Update dispute
        await (0, client_1.query)(`UPDATE economy_disputes SET
         status = $1,
         resolution = $2,
         resolution_amount = $3,
         resolved_by = $4,
         resolved_at = NOW(),
         updated_at = NOW()
       WHERE id = $5`, [resolution.status, resolution.resolution, resolution.resolutionAmount || null, adminId, disputeId]);
        log.info({ disputeId, status: resolution.status, adminId }, 'Dispute resolved');
    },
    /**
     * Get pending disputes (admin)
     */
    async getPendingDisputes(options = {}) {
        const { status = ['open', 'investigating', 'pending_response'], disputeType, limit = 50, offset = 0 } = options;
        let whereClause = `status = ANY($1)`;
        const params = [status];
        let paramIndex = 2;
        if (disputeType) {
            whereClause += ` AND dispute_type = $${paramIndex++}`;
            params.push(disputeType);
        }
        params.push(limit, offset);
        const rows = await (0, client_1.queryAll)(`SELECT * FROM economy_disputes WHERE ${whereClause} ORDER BY deadline ASC NULLS LAST, created_at ASC LIMIT $${paramIndex++} OFFSET $${paramIndex++}`, params);
        const countResult = await (0, client_1.queryOne)(`SELECT COUNT(*) as count FROM economy_disputes WHERE ${whereClause}`, params.slice(0, -2));
        return {
            disputes: rows.map((row) => ({
                id: row.id,
                reporterId: row.reporter_id,
                respondentId: row.respondent_id,
                disputeType: row.dispute_type,
                referenceType: row.reference_type,
                referenceId: row.reference_id,
                amountDisputed: row.amount_disputed ?? undefined,
                escrowId: row.escrow_id ?? undefined,
                description: row.description,
                evidence: row.evidence || [],
                status: row.status,
                resolution: row.resolution ?? undefined,
                resolutionAmount: row.resolution_amount ?? undefined,
                resolvedBy: row.resolved_by ?? undefined,
                resolvedAt: row.resolved_at ?? undefined,
                deadline: row.deadline ?? undefined,
                createdAt: row.created_at,
                updatedAt: row.updated_at,
            })),
            total: parseInt(countResult?.count || '0'),
        };
    },
};
exports.default = exports.disputeService;
//# sourceMappingURL=dispute.service.js.map