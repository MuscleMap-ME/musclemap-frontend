/**
 * Payments Service
 *
 * Handles real money to credits conversion:
 * - Credit package management
 * - Stripe checkout integration
 * - PayPal integration (planned)
 * - Purchase tracking and webhooks
 *
 * Core Equation: 1 penny = 1 credit = 1 Training Unit (TU)
 * Minimum Purchase: $1.00 = 100 credits
 */
import Stripe from 'stripe';
export interface CreditPackage {
    id: string;
    name: string;
    description?: string;
    priceCents: number;
    credits: number;
    bonusCredits: number;
    bonusPercent: number;
    totalCredits: number;
    popular: boolean;
    bestValue: boolean;
    displayOrder: number;
    icon?: string;
    color?: string;
    enabled: boolean;
    stripePriceId?: string;
}
export interface Purchase {
    id: string;
    userId: string;
    packageId?: string;
    amountCents: number;
    credits: number;
    bonusCredits: number;
    paymentMethod: string;
    paymentProvider: string;
    stripePaymentId?: string;
    stripeSessionId?: string;
    status: 'pending' | 'completed' | 'failed' | 'refunded';
    createdAt: Date;
    completedAt?: Date;
}
export interface CheckoutSession {
    sessionId: string;
    sessionUrl: string;
    packageId: string;
    credits: number;
    bonusCredits: number;
    amountCents: number;
}
export declare const paymentsService: {
    /**
     * Get all credit packages
     */
    getPackages(enabledOnly?: boolean): Promise<CreditPackage[]>;
    /**
     * Get a specific package by ID
     */
    getPackage(packageId: string): Promise<CreditPackage | null>;
    /**
     * Create a Stripe checkout session for a credit package
     */
    createStripeCheckout(userId: string, packageId: string, options: {
        successUrl: string;
        cancelUrl: string;
        quantity?: number;
    }): Promise<CheckoutSession>;
    /**
     * Handle Stripe webhook for completed checkout
     */
    handleStripeWebhook(event: Stripe.Event): Promise<void>;
    /**
     * Get user's purchase history
     */
    getUserPurchases(userId: string, options?: {
        limit?: number;
        offset?: number;
    }): Promise<Purchase[]>;
    /**
     * Get total revenue stats (admin)
     */
    getRevenueStats(): Promise<{
        totalRevenueCents: number;
        totalCreditsIssued: number;
        purchaseCount: number;
        uniqueBuyers: number;
        todayRevenueCents: number;
        weekRevenueCents: number;
        monthRevenueCents: number;
    }>;
    /**
     * Calculate price for custom amount (for custom purchases)
     * 1 penny = 1 credit, minimum $1.00
     */
    calculateCustomPrice(credits: number): {
        credits: number;
        priceCents: number;
        bonusCredits: number;
    };
    /**
     * Verify Stripe webhook signature
     */
    verifyStripeWebhook(payload: string, signature: string): Stripe.Event | null;
    /**
     * Get the Stripe client instance (for subscription management)
     */
    getStripeClient(): Stripe | null;
};
export default paymentsService;
