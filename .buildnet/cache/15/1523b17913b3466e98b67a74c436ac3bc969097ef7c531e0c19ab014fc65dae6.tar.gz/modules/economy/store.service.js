"use strict";
/**
 * Store Service
 *
 * Handles the in-app store for purchasing:
 * - Training Buddy species and cosmetics
 * - App cosmetics (frames, themes, trails)
 * - Community actions (tips, boosts, challenges)
 * - Utility unlocks (analytics, export, support)
 * - Trainer features (promotion, verification)
 * - Status/prestige items
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.storeService = void 0;
const crypto_1 = __importDefault(require("crypto"));
const client_1 = require("../../db/client");
const errors_1 = require("../../lib/errors");
const logger_1 = require("../../lib/logger");
const wallet_service_1 = require("./wallet.service");
const log = logger_1.loggers.economy;
// Safe JSON parse helper - handles both strings and already-parsed JSONB values
function safeJsonParse(value, defaultValue) {
    if (value === null || value === undefined)
        return defaultValue;
    // If it's already an object/array (from JSONB), return it directly
    if (typeof value === 'object')
        return value;
    // If it's a string, try to parse it
    if (typeof value === 'string') {
        if (value.trim() === '')
            return defaultValue;
        try {
            return JSON.parse(value);
        }
        catch {
            return defaultValue;
        }
    }
    return defaultValue;
}
exports.storeService = {
    /**
     * Get all store items with optional filtering
     */
    async getItems(options = {}) {
        const { category, rarity, featured, enabledOnly = true, limit = 100, offset = 0 } = options;
        let whereClause = enabledOnly ? 'enabled = TRUE' : '1=1';
        const params = [];
        let paramIndex = 1;
        if (category) {
            whereClause += ` AND category = $${paramIndex++}`;
            params.push(category);
        }
        if (rarity) {
            whereClause += ` AND rarity = $${paramIndex++}`;
            params.push(rarity);
        }
        if (featured !== undefined) {
            whereClause += ` AND featured = $${paramIndex++}`;
            params.push(featured);
        }
        params.push(limit, offset);
        const rows = await (0, client_1.queryAll)(`SELECT * FROM store_items
       WHERE ${whereClause}
       ORDER BY sort_order, category, rarity DESC, price_credits
       LIMIT $${paramIndex++} OFFSET $${paramIndex++}`, params);
        const countResult = await (0, client_1.queryOne)(`SELECT COUNT(*) as count FROM store_items WHERE ${whereClause}`, params.slice(0, -2));
        return {
            items: rows.map((r) => ({
                sku: r.sku,
                name: r.name,
                description: r.description ?? undefined,
                category: r.category,
                subcategory: r.subcategory ?? undefined,
                priceCredits: r.price_credits,
                rarity: r.rarity,
                limitedQuantity: r.limited_quantity ?? undefined,
                soldCount: r.sold_count,
                requiresLevel: r.requires_level,
                requiresItems: safeJsonParse(r.requires_items, []),
                metadata: safeJsonParse(r.metadata, {}),
                enabled: r.enabled,
                featured: r.featured,
                sortOrder: r.sort_order,
            })),
            total: parseInt(countResult?.count || '0', 10),
        };
    },
    /**
     * Get a specific store item by SKU
     */
    async getItem(sku) {
        const row = await (0, client_1.queryOne)('SELECT * FROM store_items WHERE sku = $1', [sku]);
        if (!row)
            return null;
        return {
            sku: row.sku,
            name: row.name,
            description: row.description ?? undefined,
            category: row.category,
            subcategory: row.subcategory ?? undefined,
            priceCredits: row.price_credits,
            rarity: row.rarity,
            limitedQuantity: row.limited_quantity ?? undefined,
            soldCount: row.sold_count,
            requiresLevel: row.requires_level,
            requiresItems: safeJsonParse(row.requires_items, []),
            metadata: safeJsonParse(row.metadata, {}),
            enabled: row.enabled,
            featured: row.featured,
            sortOrder: row.sort_order,
        };
    },
    /**
     * Get store categories
     */
    async getCategories() {
        const rows = await (0, client_1.queryAll)(`SELECT category, COUNT(*) as count
       FROM store_items
       WHERE enabled = TRUE
       GROUP BY category
       ORDER BY category`);
        return rows.map((r) => ({ category: r.category, count: parseInt(r.count, 10) }));
    },
    /**
     * Purchase a store item
     */
    async purchase(userId, sku, metadata) {
        // Get item
        const item = await this.getItem(sku);
        if (!item) {
            throw new errors_1.NotFoundError('Item not found');
        }
        if (!item.enabled) {
            throw new errors_1.ValidationError('Item is not available for purchase');
        }
        // Check limited quantity
        if (item.limitedQuantity !== undefined && item.soldCount >= item.limitedQuantity) {
            throw new errors_1.ValidationError('Item is sold out');
        }
        // Check if user already owns non-consumable item
        if (!this.isConsumable(item.category)) {
            const existing = await (0, client_1.queryOne)('SELECT id FROM user_inventory WHERE user_id = $1 AND sku = $2', [userId, sku]);
            if (existing) {
                throw new errors_1.ValidationError('You already own this item');
            }
        }
        // Check wallet status
        const canTransact = await wallet_service_1.walletService.canTransact(userId);
        if (!canTransact.allowed) {
            throw new errors_1.ForbiddenError(canTransact.reason);
        }
        // Check level requirements
        if (item.requiresLevel > 1) {
            const buddy = await (0, client_1.queryOne)('SELECT level FROM training_buddies WHERE user_id = $1', [userId]);
            if (!buddy || buddy.level < item.requiresLevel) {
                throw new errors_1.ValidationError(`Requires buddy level ${item.requiresLevel}`);
            }
        }
        // Check required items
        if (item.requiresItems.length > 0) {
            const ownedItems = await (0, client_1.queryAll)('SELECT sku FROM user_inventory WHERE user_id = $1', [userId]);
            const ownedSkus = new Set(ownedItems.map((i) => i.sku));
            for (const required of item.requiresItems) {
                if (!ownedSkus.has(required)) {
                    throw new errors_1.ValidationError(`Requires item: ${required}`);
                }
            }
        }
        // Process purchase
        const inventoryId = `inv_${crypto_1.default.randomBytes(12).toString('hex')}`;
        const idempotencyKey = `purchase-${userId}-${sku}-${Date.now()}-${crypto_1.default.randomBytes(4).toString('hex')}`;
        try {
            const result = await (0, client_1.serializableTransaction)(async (client) => {
                // Check balance
                const balance = await client.query('SELECT balance FROM credit_balances WHERE user_id = $1 FOR UPDATE', [userId]);
                if (balance.rows.length === 0 || balance.rows[0].balance < item.priceCredits) {
                    throw new errors_1.ValidationError('Insufficient credits');
                }
                const newBalance = balance.rows[0].balance - item.priceCredits;
                const txId = `txn_${crypto_1.default.randomBytes(12).toString('hex')}`;
                // Debit credits
                await client.query(`UPDATE credit_balances
           SET balance = $1, lifetime_spent = lifetime_spent + $2, version = version + 1, updated_at = NOW()
           WHERE user_id = $3`, [newBalance, item.priceCredits, userId]);
                // Create ledger entry
                await client.query(`INSERT INTO credit_ledger (id, user_id, action, amount, balance_after, metadata, idempotency_key)
           VALUES ($1, $2, 'purchase', $3, $4, $5, $6)`, [txId, userId, -item.priceCredits, newBalance, JSON.stringify({ sku, itemName: item.name, ...metadata }), idempotencyKey]);
                // Add to inventory
                await client.query(`INSERT INTO user_inventory (id, user_id, sku, purchase_tx_id, metadata)
           VALUES ($1, $2, $3, $4, $5)
           ON CONFLICT (user_id, sku) DO UPDATE SET
             quantity = user_inventory.quantity + 1,
             purchased_at = NOW()`, [inventoryId, userId, sku, txId, metadata ? JSON.stringify(metadata) : '{}']);
                // Update sold count
                await client.query('UPDATE store_items SET sold_count = sold_count + 1, updated_at = NOW() WHERE sku = $1', [sku]);
                return { newBalance };
            });
            log.info({
                inventoryId,
                userId,
                sku,
                itemName: item.name,
                priceCredits: item.priceCredits,
            }, 'Store purchase completed');
            return {
                success: true,
                inventoryId,
                newBalance: result.newBalance,
            };
        }
        catch (error) {
            if (error.message?.includes('Insufficient')) {
                return { success: false, error: 'Insufficient credits' };
            }
            if (error.message?.includes('already own')) {
                return { success: false, error: 'You already own this item' };
            }
            log.error({ userId, sku, error }, 'Store purchase failed');
            throw error;
        }
    },
    /**
     * Get user's inventory
     */
    async getInventory(userId, options = {}) {
        const { category, limit = 100, offset = 0 } = options;
        let whereClause = 'ui.user_id = $1';
        const params = [userId];
        let paramIndex = 2;
        if (category) {
            whereClause += ` AND si.category = $${paramIndex++}`;
            params.push(category);
        }
        params.push(limit, offset);
        const rows = await (0, client_1.queryAll)(`SELECT ui.id, ui.user_id, ui.sku, ui.quantity, ui.purchased_at, ui.expires_at,
              si.name as item_name, si.description as item_description, si.category as item_category,
              si.subcategory as item_subcategory, si.price_credits as item_price, si.rarity as item_rarity,
              si.metadata as item_metadata
       FROM user_inventory ui
       JOIN store_items si ON si.sku = ui.sku
       WHERE ${whereClause}
       ORDER BY ui.purchased_at DESC
       LIMIT $${paramIndex++} OFFSET $${paramIndex++}`, params);
        const countResult = await (0, client_1.queryOne)(`SELECT COUNT(*) as count FROM user_inventory ui
       JOIN store_items si ON si.sku = ui.sku
       WHERE ${whereClause}`, params.slice(0, -2));
        return {
            items: rows.map((r) => ({
                id: r.id,
                userId: r.user_id,
                sku: r.sku,
                item: {
                    sku: r.sku,
                    name: r.item_name,
                    description: r.item_description ?? undefined,
                    category: r.item_category,
                    subcategory: r.item_subcategory ?? undefined,
                    priceCredits: r.item_price,
                    rarity: r.item_rarity,
                    soldCount: 0,
                    requiresLevel: 1,
                    requiresItems: [],
                    metadata: safeJsonParse(r.item_metadata, {}),
                    enabled: true,
                    featured: false,
                    sortOrder: 0,
                },
                quantity: r.quantity,
                purchasedAt: r.purchased_at,
                expiresAt: r.expires_at ?? undefined,
            })),
            total: parseInt(countResult?.count || '0', 10),
        };
    },
    /**
     * Check if user owns an item
     */
    async ownsItem(userId, sku) {
        const result = await (0, client_1.queryOne)('SELECT COUNT(*) as count FROM user_inventory WHERE user_id = $1 AND sku = $2', [userId, sku]);
        return parseInt(result?.count || '0', 10) > 0;
    },
    /**
     * Get all items owned by user as a set of SKUs
     */
    async getOwnedSkus(userId) {
        const rows = await (0, client_1.queryAll)('SELECT sku FROM user_inventory WHERE user_id = $1', [userId]);
        return new Set(rows.map((r) => r.sku));
    },
    /**
     * Check if a category is consumable (can be purchased multiple times)
     */
    isConsumable(category) {
        const consumableCategories = [
            'community_tip',
            'community_bounty',
            'community_challenge',
            'community_boost',
            'community_shoutout',
            'community_gift',
        ];
        return consumableCategories.includes(category);
    },
    /**
     * Get featured items
     */
    async getFeaturedItems(limit = 10) {
        const { items } = await this.getItems({ featured: true, limit });
        return items;
    },
    /**
     * Get items by rarity
     */
    async getItemsByRarity(rarity, limit = 20) {
        const { items } = await this.getItems({ rarity, limit });
        return items;
    },
    /**
     * Admin: Grant an item to a user
     */
    async grantItem(userId, sku, adminUserId, reason) {
        const item = await this.getItem(sku);
        if (!item) {
            throw new errors_1.NotFoundError('Item not found');
        }
        const inventoryId = `inv_${crypto_1.default.randomBytes(12).toString('hex')}`;
        await (0, client_1.query)(`INSERT INTO user_inventory (id, user_id, sku, metadata)
       VALUES ($1, $2, $3, $4)
       ON CONFLICT (user_id, sku) DO UPDATE SET
         quantity = user_inventory.quantity + 1,
         purchased_at = NOW()`, [inventoryId, userId, sku, JSON.stringify({ grantedBy: adminUserId, reason })]);
        // Audit log
        await wallet_service_1.walletService.logAdminAction({
            adminUserId,
            action: 'grant_item',
            targetUserId: userId,
            reason,
            details: { sku, itemName: item.name },
        });
        log.info({ inventoryId, userId, sku, adminUserId, reason }, 'Item granted by admin');
        return inventoryId;
    },
    /**
     * Admin: Revoke an item from a user
     */
    async revokeItem(userId, sku, adminUserId, reason) {
        const item = await this.getItem(sku);
        if (!item) {
            throw new errors_1.NotFoundError('Item not found');
        }
        await (0, client_1.query)('DELETE FROM user_inventory WHERE user_id = $1 AND sku = $2', [userId, sku]);
        // Audit log
        await wallet_service_1.walletService.logAdminAction({
            adminUserId,
            action: 'revoke_item',
            targetUserId: userId,
            reason,
            details: { sku, itemName: item.name },
        });
        log.info({ userId, sku, adminUserId, reason }, 'Item revoked by admin');
    },
};
exports.default = exports.storeService;
//# sourceMappingURL=store.service.js.map