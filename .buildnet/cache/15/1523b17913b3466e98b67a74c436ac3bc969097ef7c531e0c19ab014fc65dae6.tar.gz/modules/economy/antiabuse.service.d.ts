/**
 * Anti-Abuse Service
 *
 * Detects and prevents economic abuse:
 * - Velocity checks (too many transfers/actions)
 * - Unusual pattern detection
 * - Self-farming detection
 * - Bot detection
 * - Admin audit logging
 */
export declare const FRAUD_FLAG_TYPES: {
    readonly VELOCITY: "velocity";
    readonly SELF_FARMING: "self_farming";
    readonly SUSPICIOUS_PATTERN: "suspicious_pattern";
    readonly BOT_BEHAVIOR: "bot_behavior";
    readonly COLLUSION: "collusion";
    readonly MANUAL: "manual";
};
export type FraudFlagType = (typeof FRAUD_FLAG_TYPES)[keyof typeof FRAUD_FLAG_TYPES];
export declare const FLAG_SEVERITIES: {
    readonly LOW: "low";
    readonly MEDIUM: "medium";
    readonly HIGH: "high";
    readonly CRITICAL: "critical";
};
export type FlagSeverity = (typeof FLAG_SEVERITIES)[keyof typeof FLAG_SEVERITIES];
export declare const FLAG_STATUSES: {
    readonly OPEN: "open";
    readonly INVESTIGATING: "investigating";
    readonly RESOLVED_VALID: "resolved_valid";
    readonly RESOLVED_INVALID: "resolved_invalid";
    readonly ESCALATED: "escalated";
};
export type FlagStatus = (typeof FLAG_STATUSES)[keyof typeof FLAG_STATUSES];
export interface FraudFlag {
    id: string;
    userId: string;
    flagType: FraudFlagType;
    severity: FlagSeverity;
    description: string;
    metadata: Record<string, unknown>;
    status: FlagStatus;
    reviewedBy?: string;
    reviewedAt?: Date;
    reviewNotes?: string;
    createdAt: Date;
}
export interface RateLimit {
    action: string;
    maxPerHour: number;
    maxPerDay: number;
    cooldownSeconds: number;
}
export interface VelocityCheck {
    action: string;
    count: number;
    limit: number;
    period: 'hour' | 'day';
    blocked: boolean;
}
export declare const antiabuseService: {
    /**
     * Check if an action exceeds rate limits
     */
    checkRateLimit(userId: string, action: string): Promise<{
        allowed: boolean;
        hourlyCount: number;
        hourlyLimit: number;
        dailyCount: number;
        dailyLimit: number;
        cooldownRemaining: number;
    }>;
    /**
     * Get all rate limit configurations
     */
    getRateLimits(): Promise<RateLimit[]>;
    /**
     * Update rate limit configuration
     */
    updateRateLimit(action: string, limits: Partial<RateLimit>): Promise<void>;
    /**
     * Check for suspicious transfer patterns
     */
    checkTransferPatterns(userId: string, toUserId: string, amount: number): Promise<{
        suspicious: boolean;
        reasons: string[];
        severity: FlagSeverity;
    }>;
    /**
     * Check for bot-like behavior patterns
     */
    checkBotPatterns(userId: string): Promise<{
        suspicious: boolean;
        score: number;
        indicators: string[];
    }>;
    /**
     * Create a fraud flag
     */
    createFlag(params: {
        userId: string;
        flagType: FraudFlagType;
        severity: FlagSeverity;
        description: string;
        metadata?: Record<string, unknown>;
    }): Promise<FraudFlag>;
    /**
     * Get fraud flags with filters
     */
    getFlags(options?: {
        userId?: string;
        status?: FlagStatus;
        severity?: FlagSeverity;
        limit?: number;
        offset?: number;
    }): Promise<{
        flags: FraudFlag[];
        total: number;
    }>;
    /**
     * Update flag status (review)
     */
    reviewFlag(flagId: string, reviewerId: string, status: FlagStatus, notes?: string): Promise<void>;
    /**
     * Log an admin action on the economy
     */
    logAdminAction(params: {
        adminId: string;
        action: string;
        targetUserId?: string;
        targetType: string;
        targetId: string;
        details: Record<string, unknown>;
        reason?: string;
    }): Promise<void>;
    /**
     * Get admin audit log
     */
    getAuditLog(options?: {
        adminId?: string;
        targetUserId?: string;
        action?: string;
        limit?: number;
        offset?: number;
    }): Promise<{
        entries: Array<{
            id: string;
            adminId: string;
            adminUsername?: string;
            action: string;
            targetUserId?: string;
            targetUsername?: string;
            targetType: string;
            targetId: string;
            details: Record<string, unknown>;
            reason?: string;
            createdAt: Date;
        }>;
        total: number;
    }>;
    /**
     * Run all automated abuse checks for a user
     */
    runChecks(userId: string): Promise<{
        passed: boolean;
        flags: FraudFlag[];
    }>;
    /**
     * Run pre-transfer checks
     */
    preTransferCheck(fromUserId: string, toUserId: string, amount: number): Promise<{
        allowed: boolean;
        reason?: string;
        flagCreated?: FraudFlag;
    }>;
};
export default antiabuseService;
