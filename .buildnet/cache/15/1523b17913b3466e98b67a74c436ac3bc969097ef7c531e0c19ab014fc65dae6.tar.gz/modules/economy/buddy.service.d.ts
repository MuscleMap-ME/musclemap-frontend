/**
 * Buddy Service
 *
 * Handles the Training Buddy/Companion system:
 * - Buddy creation with species selection
 * - XP and level progression
 * - Stage evolution (6 stages per species)
 * - Cosmetic equipping (aura, armor, wings, tools, skins)
 * - Ability unlocking
 * - Display settings
 */
export declare const BUDDY_SPECIES: readonly ["wolf", "bear", "eagle", "phoenix", "dragon", "tiger", "ox", "shark"];
export type BuddySpecies = typeof BUDDY_SPECIES[number];
export interface Buddy {
    userId: string;
    species: BuddySpecies;
    nickname?: string;
    level: number;
    xp: number;
    xpToNextLevel: number;
    stage: number;
    stageName: string;
    stageDescription?: string;
    equippedAura?: string;
    equippedArmor?: string;
    equippedWings?: string;
    equippedTool?: string;
    equippedSkin?: string;
    equippedEmotePack?: string;
    equippedVoicePack?: string;
    unlockedAbilities: string[];
    visible: boolean;
    showOnProfile: boolean;
    showInWorkouts: boolean;
    totalXpEarned: number;
    workoutsTogether: number;
    streaksWitnessed: number;
    prsCelebrated: number;
    createdAt: Date;
    updatedAt: Date;
}
export interface EvolutionStage {
    species: BuddySpecies;
    stage: number;
    minLevel: number;
    stageName: string;
    description?: string;
    unlockedFeatures: string[];
}
export declare const buddyService: {
    /**
     * Get user's buddy
     */
    getBuddy(userId: string): Promise<Buddy | null>;
    /**
     * Create a new buddy for user
     */
    createBuddy(userId: string, species: BuddySpecies, nickname?: string): Promise<Buddy>;
    /**
     * Change buddy species (if user owns the new species)
     */
    changeSpecies(userId: string, newSpecies: BuddySpecies): Promise<Buddy>;
    /**
     * Set buddy nickname
     */
    setNickname(userId: string, nickname: string | null): Promise<void>;
    /**
     * Add XP to buddy
     */
    addXp(userId: string, xp: number): Promise<{
        newXp: number;
        newLevel: number;
        leveledUp: boolean;
        newStage: number;
        evolved: boolean;
    }>;
    /**
     * Check and apply evolution based on level
     */
    checkEvolution(userId: string): Promise<{
        evolved: boolean;
        newStage: number;
        stageName?: string;
    }>;
    /**
     * Get stage info for a species
     */
    getStageInfo(species: BuddySpecies, stage: number): Promise<EvolutionStage | null>;
    /**
     * Get all evolution stages for a species
     */
    getEvolutionPath(species: BuddySpecies): Promise<EvolutionStage[]>;
    /**
     * Equip a cosmetic item
     */
    equipCosmetic(userId: string, sku: string, slot: string): Promise<void>;
    /**
     * Unequip a cosmetic from a slot
     */
    unequipCosmetic(userId: string, slot: string): Promise<void>;
    /**
     * Unlock an ability for the buddy
     */
    unlockAbility(userId: string, abilitySku: string): Promise<void>;
    /**
     * Update display settings
     */
    updateDisplaySettings(userId: string, settings: {
        visible?: boolean;
        showOnProfile?: boolean;
        showInWorkouts?: boolean;
    }): Promise<void>;
    /**
     * Increment buddy stats
     */
    incrementStats(userId: string, stats: {
        workoutsTogether?: number;
        streaksWitnessed?: number;
        prsCelebrated?: number;
    }): Promise<void>;
    /**
     * Get buddy leaderboard (by level)
     */
    getLeaderboard(options?: {
        species?: BuddySpecies;
        limit?: number;
        offset?: number;
    }): Promise<{
        entries: Array<{
            rank: number;
            userId: string;
            username: string;
            species: BuddySpecies;
            nickname?: string;
            level: number;
            stage: number;
            stageName: string;
        }>;
        total: number;
    }>;
};
export default buddyService;
