/**
 * Credit Earn Events Service
 *
 * Handles real-time credit earning visibility:
 * - Creates earn events for UI display/animation
 * - Supports different animation types based on amount
 * - Provides streaming endpoint for real-time updates
 * - Manages event cleanup for old events
 *
 * Every credit earn should feel like a reward!
 */
export interface EarnEvent {
    id: string;
    userId: string;
    amount: number;
    source: string;
    sourceId?: string;
    description?: string;
    animationType: string;
    icon: string;
    color: string;
    shown: boolean;
    createdAt: Date;
}
export interface CreateEarnEventParams {
    userId: string;
    amount: number;
    source: string;
    sourceId?: string;
    description?: string;
    forceAnimationType?: string;
    forceIcon?: string;
    forceColor?: string;
}
export declare const earnEventsService: {
    /**
     * Create a credit earn event for real-time display
     */
    createEvent(params: CreateEarnEventParams): Promise<EarnEvent>;
    /**
     * Get unseen earn events for a user
     */
    getUnseenEvents(userId: string, limit?: number): Promise<EarnEvent[]>;
    /**
     * Get recent earn events (including seen)
     */
    getRecentEvents(userId: string, limit?: number): Promise<EarnEvent[]>;
    /**
     * Mark events as seen
     */
    markEventsSeen(userId: string, eventIds?: string[]): Promise<number>;
    /**
     * Get today's earning summary for a user
     */
    getTodaySummary(userId: string): Promise<{
        totalEarned: number;
        eventCount: number;
        bySource: Record<string, {
            amount: number;
            count: number;
        }>;
    }>;
    /**
     * Get this week's earning summary
     */
    getWeekSummary(userId: string): Promise<{
        totalEarned: number;
        eventCount: number;
        dailyTotals: {
            date: string;
            amount: number;
        }[];
    }>;
    /**
     * Cleanup old events (for scheduled job)
     * Events older than 7 days are deleted
     */
    cleanupOldEvents(): Promise<number>;
    /**
     * Get source display info
     */
    getSourceDisplay(source: string): {
        name: string;
        icon: string;
        color: string;
    };
};
export default earnEventsService;
