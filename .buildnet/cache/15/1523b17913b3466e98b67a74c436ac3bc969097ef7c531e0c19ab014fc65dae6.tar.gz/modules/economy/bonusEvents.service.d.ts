/**
 * Bonus Events Service
 *
 * Handles random/conditional credit bonuses:
 * - Lucky Rep (1% chance per rep)
 * - Golden Set (2% chance per set)
 * - Jackpot Workout (1% chance per workout)
 * - Mystery Box (daily random reward)
 * - Time-based bonuses (early bird, night owl, weekend)
 * - Comeback bonus (returning after absence)
 *
 * These create excitement and keep users engaged!
 */
export interface BonusEventType {
    id: string;
    code: string;
    name: string;
    description?: string;
    probability: number;
    minCredits: number;
    maxCredits: number;
    triggerOn: string;
    maxPerDay: number;
    maxPerWeek: number;
    icon?: string;
    color?: string;
    animation?: string;
    enabled: boolean;
}
export interface BonusEventResult {
    triggered: boolean;
    eventType?: string;
    creditsAwarded?: number;
    eventId?: string;
    message?: string;
}
export declare const bonusEventsService: {
    /**
     * Get all bonus event types
     */
    getEventTypes(enabledOnly?: boolean): Promise<BonusEventType[]>;
    /**
     * Get a specific bonus event type
     */
    getEventType(code: string): Promise<BonusEventType | null>;
    /**
     * Check and potentially trigger a bonus event
     */
    checkAndTrigger(userId: string, trigger: string, sourceId?: string): Promise<BonusEventResult>;
    /**
     * Check for rep bonus (called per rep)
     */
    checkRepBonus(userId: string, workoutId: string, repNumber: number): Promise<BonusEventResult>;
    /**
     * Check for set bonus (called per set)
     */
    checkSetBonus(userId: string, workoutId: string, setNumber: number): Promise<BonusEventResult>;
    /**
     * Check for workout bonus (called on workout complete)
     */
    checkWorkoutBonus(userId: string, workoutId: string): Promise<BonusEventResult>;
    /**
     * Check for daily login bonus
     */
    checkDailyLoginBonus(userId: string): Promise<BonusEventResult>;
    /**
     * Check for early bird workout bonus (before 6 AM)
     */
    checkEarlyBirdBonus(userId: string, workoutId: string): Promise<BonusEventResult>;
    /**
     * Check for night owl workout bonus (after 10 PM)
     */
    checkNightOwlBonus(userId: string, workoutId: string): Promise<BonusEventResult>;
    /**
     * Check for weekend workout bonus
     */
    checkWeekendBonus(userId: string, workoutId: string): Promise<BonusEventResult>;
    /**
     * Check for comeback bonus (returning after 3+ days)
     */
    checkComebackBonus(userId: string): Promise<BonusEventResult>;
    /**
     * Get today's bonus event count for a user
     */
    getTodayCount(userId: string, eventTypeCode: string): Promise<number>;
    /**
     * Get user's bonus event history
     */
    getUserBonusHistory(userId: string, limit?: number, offset?: number): Promise<{
        id: string;
        eventType: string;
        creditsAwarded: number;
        createdAt: Date;
    }[]>;
    /**
     * Calculate random reward between min and max
     * Uses weighted distribution favoring lower values
     */
    calculateReward(min: number, max: number): number;
    /**
     * Process all workout-related bonuses
     */
    processWorkoutBonuses(userId: string, workoutId: string, _totalReps: number, _totalSets: number): Promise<BonusEventResult[]>;
};
export default bonusEventsService;
