/**
 * Earning Service
 *
 * Handles credit and XP awards based on configurable rules:
 * - Workout completion (duration/volume bonuses)
 * - Streak milestones
 * - Personal records
 * - Goal completion
 * - Leaderboard placements
 * - Trainer wages
 * - Social actions
 */
export interface EarningRule {
    code: string;
    name: string;
    description?: string;
    category: string;
    creditsBase: number;
    creditsFormula?: string;
    xpBase: number;
    xpFormula?: string;
    maxPerDay?: number;
    maxPerWeek?: number;
    cooldownMinutes?: number;
    enabled: boolean;
}
export interface EarningContext {
    userId: string;
    ruleCode: string;
    sourceType: string;
    sourceId: string;
    metadata?: Record<string, unknown>;
    durationMinutes?: number;
    totalVolume?: number;
    currentStreak?: number;
    goalDifficulty?: 'easy' | 'medium' | 'hard';
    leaderboardRank?: number;
    attendeeCount?: number;
    wagePerStudent?: number;
}
export interface EarningResult {
    success: boolean;
    alreadyAwarded?: boolean;
    creditsAwarded?: number;
    xpAwarded?: number;
    awardId?: string;
    error?: string;
}
export declare const earningService: {
    /**
     * Get all earning rules
     */
    getRules(options?: {
        category?: string;
        enabledOnly?: boolean;
    }): Promise<EarningRule[]>;
    /**
     * Get a specific earning rule
     */
    getRule(code: string): Promise<EarningRule | null>;
    /**
     * Process an earning event and award credits/XP
     */
    processEarning(context: EarningContext): Promise<EarningResult>;
    /**
     * Calculate credits based on rule and context
     */
    calculateCredits(rule: EarningRule, context: EarningContext): number;
    /**
     * Calculate XP based on rule and context
     */
    calculateXp(rule: EarningRule, context: EarningContext): number;
    /**
     * Award XP to user's buddy and user's ranking XP
     */
    awardXp(userId: string, xp: number, sourceType?: string, sourceId?: string, reason?: string): Promise<void>;
    /**
     * Get count of awards today for a rule
     */
    getTodayCount(userId: string, ruleCode: string): Promise<number>;
    /**
     * Get count of awards this week for a rule
     */
    getWeekCount(userId: string, ruleCode: string): Promise<number>;
    /**
     * Get earning history for a user
     */
    getHistory(userId: string, options?: {
        limit?: number;
        offset?: number;
        category?: string;
    }): Promise<{
        awards: Array<{
            id: string;
            ruleCode: string;
            ruleName: string;
            category: string;
            sourceType: string;
            sourceId: string;
            creditsAwarded: number;
            xpAwarded: number;
            createdAt: Date;
        }>;
        total: number;
    }>;
    /**
     * Award credits for completing a workout
     */
    onWorkoutComplete(params: {
        userId: string;
        workoutId: string;
        durationMinutes: number;
        totalVolume?: number;
        exerciseCount: number;
        muscleGroupsHit?: string[];
        newExercisesTried?: number;
        prsSet?: number;
    }): Promise<EarningResult[]>;
    /**
     * Check and award streak milestones
     */
    checkStreakAwards(userId: string): Promise<EarningResult[]>;
    /**
     * Award credits for setting a personal record
     */
    onPersonalRecord(params: {
        userId: string;
        exerciseId: string;
        metricKey: string;
        value: number;
        previousValue?: number;
    }): Promise<EarningResult>;
    /**
     * Award credits for completing a goal
     */
    onGoalComplete(params: {
        userId: string;
        goalId: string;
        difficulty: "easy" | "medium" | "hard";
    }): Promise<EarningResult>;
    /**
     * Award credits for leaderboard placement
     */
    onLeaderboardPlacement(params: {
        userId: string;
        leaderboardId: string;
        rank: number;
        periodType: string;
    }): Promise<EarningResult>;
    /**
     * Award trainer wage for class attendance
     */
    onClassAttendance(params: {
        trainerId: string;
        classId: string;
        attendeeCount: number;
        wagePerStudent: number;
    }): Promise<EarningResult>;
};
export default earningService;
