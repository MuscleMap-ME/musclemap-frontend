/**
 * Trainer Service
 *
 * Manages trainer profiles, classes, enrollments, and attendance.
 * Handles wage distribution for trainers based on class attendance.
 */
export interface TrainerProfile {
    userId: string;
    displayName: string;
    bio?: string;
    specialties: string[];
    certifications: string[];
    hourlyRateCredits: number;
    perClassRateCredits: number;
    verified: boolean;
    verifiedAt?: Date;
    ratingAvg: number;
    ratingCount: number;
    totalClassesTaught: number;
    totalStudentsTrained: number;
    totalCreditsEarned: number;
    status: 'active' | 'paused' | 'suspended';
    createdAt: Date;
}
export interface TrainerClass {
    id: string;
    trainerUserId: string;
    title: string;
    description?: string;
    category: string;
    difficulty: 'beginner' | 'intermediate' | 'advanced' | 'all';
    startAt: Date;
    durationMinutes: number;
    locationType: 'in_person' | 'virtual' | 'hybrid';
    locationDetails?: string;
    hangoutId?: number;
    virtualHangoutId?: number;
    capacity: number;
    enrolledCount: number;
    creditsPerStudent: number;
    trainerWagePerStudent: number;
    status: 'draft' | 'scheduled' | 'in_progress' | 'completed' | 'cancelled';
    metadata: Record<string, unknown>;
    createdAt: Date;
}
export interface ClassEnrollment {
    id: string;
    classId: string;
    userId: string;
    status: 'pending' | 'enrolled' | 'cancelled' | 'refunded' | 'completed';
    paymentTxId?: string;
    creditsPaid: number;
    enrolledAt: Date;
    cancelledAt?: Date;
    refundTxId?: string;
}
export interface ClassAttendance {
    id: string;
    classId: string;
    userId: string;
    attended: boolean;
    markedBy: string;
    wageTxId?: string;
    rating?: number;
    feedback?: string;
    markedAt: Date;
}
export interface CreateTrainerProfileInput {
    displayName: string;
    bio?: string;
    specialties?: string[];
    certifications?: string[];
    hourlyRateCredits?: number;
    perClassRateCredits?: number;
}
export interface CreateClassInput {
    title: string;
    description?: string;
    category: string;
    difficulty: 'beginner' | 'intermediate' | 'advanced' | 'all';
    startAt: Date;
    durationMinutes: number;
    locationType: 'in_person' | 'virtual' | 'hybrid';
    locationDetails?: string;
    hangoutId?: number;
    virtualHangoutId?: number;
    capacity: number;
    creditsPerStudent: number;
    trainerWagePerStudent: number;
}
export declare const trainerService: {
    /**
     * Get trainer profile by user ID
     */
    getProfile(userId: string): Promise<TrainerProfile | null>;
    /**
     * Create or update trainer profile
     */
    upsertProfile(userId: string, input: CreateTrainerProfileInput): Promise<TrainerProfile>;
    /**
     * List trainer profiles with optional filters
     */
    listProfiles(options?: {
        verified?: boolean;
        specialty?: string;
        status?: string;
        limit?: number;
        offset?: number;
    }): Promise<{
        trainers: TrainerProfile[];
        total: number;
    }>;
    /**
     * Update trainer status
     */
    updateStatus(userId: string, status: "active" | "paused" | "suspended"): Promise<void>;
    /**
     * Create a new class
     */
    createClass(trainerUserId: string, input: CreateClassInput): Promise<TrainerClass>;
    /**
     * Get class by ID
     */
    getClass(classId: string): Promise<TrainerClass | null>;
    /**
     * List classes with filters
     */
    listClasses(options?: {
        trainerUserId?: string;
        status?: string;
        category?: string;
        upcoming?: boolean;
        limit?: number;
        offset?: number;
    }): Promise<{
        classes: TrainerClass[];
        total: number;
    }>;
    /**
     * Update class
     */
    updateClass(classId: string, updates: Partial<CreateClassInput>): Promise<TrainerClass>;
    /**
     * Cancel a class
     */
    cancelClass(classId: string, reason?: string): Promise<void>;
    /**
     * Enroll in a class
     */
    enroll(userId: string, classId: string): Promise<ClassEnrollment>;
    /**
     * Get enrollment by ID
     */
    getEnrollment(enrollmentId: string): Promise<ClassEnrollment | null>;
    /**
     * Get enrollments for a class
     */
    getClassEnrollments(classId: string): Promise<ClassEnrollment[]>;
    /**
     * Get user's enrollments
     */
    getUserEnrollments(userId: string, options?: {
        status?: string;
        limit?: number;
        offset?: number;
    }): Promise<{
        enrollments: (ClassEnrollment & {
            class: TrainerClass;
        })[];
        total: number;
    }>;
    /**
     * Cancel enrollment
     */
    cancelEnrollment(userId: string, classId: string): Promise<void>;
    /**
     * Mark attendance for a class
     */
    markAttendance(trainerId: string, classId: string, attendees: Array<{
        userId: string;
        attended: boolean;
        rating?: number;
        feedback?: string;
    }>): Promise<{
        attendeeCount: number;
        wageEarned: number;
    }>;
    /**
     * Get attendance for a class
     */
    getClassAttendance(classId: string): Promise<ClassAttendance[]>;
};
export default trainerService;
