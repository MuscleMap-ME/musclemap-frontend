"use strict";
/**
 * Bonus Events Service
 *
 * Handles random/conditional credit bonuses:
 * - Lucky Rep (1% chance per rep)
 * - Golden Set (2% chance per set)
 * - Jackpot Workout (1% chance per workout)
 * - Mystery Box (daily random reward)
 * - Time-based bonuses (early bird, night owl, weekend)
 * - Comeback bonus (returning after absence)
 *
 * These create excitement and keep users engaged!
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.bonusEventsService = void 0;
const crypto_1 = __importDefault(require("crypto"));
const client_1 = require("../../db/client");
const logger_1 = require("../../lib/logger");
const credit_service_1 = require("./credit.service");
const earnEvents_service_1 = require("./earnEvents.service");
const log = logger_1.loggers.economy;
exports.bonusEventsService = {
    /**
     * Get all bonus event types
     */
    async getEventTypes(enabledOnly = true) {
        const rows = await (0, client_1.queryAll)(enabledOnly
            ? 'SELECT * FROM bonus_event_types WHERE enabled = true ORDER BY code'
            : 'SELECT * FROM bonus_event_types ORDER BY code', []);
        return rows.map(r => ({
            id: r.id,
            code: r.code,
            name: r.name,
            description: r.description || undefined,
            probability: parseFloat(r.probability),
            minCredits: r.min_credits,
            maxCredits: r.max_credits,
            triggerOn: r.trigger_on,
            maxPerDay: r.max_per_day || 1,
            maxPerWeek: r.max_per_week || 7,
            icon: r.icon || undefined,
            color: r.color || undefined,
            animation: r.animation || undefined,
            enabled: r.enabled,
        }));
    },
    /**
     * Get a specific bonus event type
     */
    async getEventType(code) {
        const row = await (0, client_1.queryOne)('SELECT * FROM bonus_event_types WHERE code = $1', [code]);
        if (!row)
            return null;
        return {
            id: row.id,
            code: row.code,
            name: row.name,
            description: row.description || undefined,
            probability: parseFloat(row.probability),
            minCredits: row.min_credits,
            maxCredits: row.max_credits,
            triggerOn: row.trigger_on,
            maxPerDay: row.max_per_day || 1,
            maxPerWeek: row.max_per_week || 7,
            icon: row.icon || undefined,
            color: row.color || undefined,
            animation: row.animation || undefined,
            enabled: row.enabled,
        };
    },
    /**
     * Check and potentially trigger a bonus event
     */
    async checkAndTrigger(userId, trigger, sourceId) {
        // Get all enabled event types for this trigger
        const eventTypes = await this.getEventTypes(true);
        const matchingTypes = eventTypes.filter(et => et.triggerOn === trigger);
        if (matchingTypes.length === 0) {
            return { triggered: false };
        }
        // Check each event type
        for (const eventType of matchingTypes) {
            // Check daily limit
            const todayCount = await this.getTodayCount(userId, eventType.code);
            if (todayCount >= eventType.maxPerDay) {
                continue;
            }
            // Check probability (skip for probability = 1.0 events like daily login)
            if (eventType.probability < 1.0) {
                const roll = Math.random();
                if (roll > eventType.probability) {
                    continue;
                }
            }
            // Triggered! Calculate reward
            const credits = this.calculateReward(eventType.minCredits, eventType.maxCredits);
            // Award credits
            const idempotencyKey = `bonus-${eventType.code}-${userId}-${Date.now()}-${crypto_1.default.randomBytes(4).toString('hex')}`;
            const creditResult = await credit_service_1.creditService.addCredits(userId, credits, `bonus.${eventType.code}`, { sourceId, eventType: eventType.code }, idempotencyKey);
            if (!creditResult.success) {
                log.error({ userId, eventType: eventType.code, error: creditResult.error }, 'Failed to award bonus credits');
                continue;
            }
            // Record the bonus event
            const eventId = `ube_${crypto_1.default.randomBytes(12).toString('hex')}`;
            await (0, client_1.query)(`INSERT INTO user_bonus_events (id, user_id, event_type_code, credits_awarded, trigger_source_id)
         VALUES ($1, $2, $3, $4, $5)`, [eventId, userId, eventType.code, credits, sourceId || null]);
            // Create earn event for UI display
            await earnEvents_service_1.earnEventsService.createEvent({
                userId,
                amount: credits,
                source: eventType.code,
                sourceId,
                description: eventType.name,
                forceAnimationType: eventType.animation || 'celebration',
                forceIcon: eventType.icon,
                forceColor: eventType.color,
            });
            log.info({
                userId,
                eventType: eventType.code,
                credits,
                trigger,
                sourceId,
            }, 'Bonus event triggered');
            return {
                triggered: true,
                eventType: eventType.code,
                creditsAwarded: credits,
                eventId,
                message: `${eventType.name}! +${credits} credits`,
            };
        }
        return { triggered: false };
    },
    /**
     * Check for rep bonus (called per rep)
     */
    async checkRepBonus(userId, workoutId, repNumber) {
        return this.checkAndTrigger(userId, 'rep', `${workoutId}:rep:${repNumber}`);
    },
    /**
     * Check for set bonus (called per set)
     */
    async checkSetBonus(userId, workoutId, setNumber) {
        return this.checkAndTrigger(userId, 'set', `${workoutId}:set:${setNumber}`);
    },
    /**
     * Check for workout bonus (called on workout complete)
     */
    async checkWorkoutBonus(userId, workoutId) {
        return this.checkAndTrigger(userId, 'workout', workoutId);
    },
    /**
     * Check for daily login bonus
     */
    async checkDailyLoginBonus(userId) {
        return this.checkAndTrigger(userId, 'daily_login', `login-${new Date().toISOString().split('T')[0]}`);
    },
    /**
     * Check for early bird workout bonus (before 6 AM)
     */
    async checkEarlyBirdBonus(userId, workoutId) {
        const hour = new Date().getHours();
        if (hour >= 6)
            return { triggered: false };
        return this.checkAndTrigger(userId, 'early_workout', workoutId);
    },
    /**
     * Check for night owl workout bonus (after 10 PM)
     */
    async checkNightOwlBonus(userId, workoutId) {
        const hour = new Date().getHours();
        if (hour < 22)
            return { triggered: false };
        return this.checkAndTrigger(userId, 'late_workout', workoutId);
    },
    /**
     * Check for weekend workout bonus
     */
    async checkWeekendBonus(userId, workoutId) {
        const day = new Date().getDay();
        if (day !== 0 && day !== 6)
            return { triggered: false };
        return this.checkAndTrigger(userId, 'weekend_workout', workoutId);
    },
    /**
     * Check for comeback bonus (returning after 3+ days)
     */
    async checkComebackBonus(userId) {
        // Check last activity
        const lastActivity = await (0, client_1.queryOne)(`SELECT GREATEST(
         (SELECT MAX(created_at) FROM workouts WHERE user_id = $1),
         (SELECT MAX(created_at) FROM credit_ledger WHERE user_id = $1)
       ) as last_active_at`, [userId]);
        if (!lastActivity?.last_active_at) {
            return { triggered: false };
        }
        const daysSinceActive = (Date.now() - lastActivity.last_active_at.getTime()) / (1000 * 60 * 60 * 24);
        if (daysSinceActive < 3) {
            return { triggered: false };
        }
        return this.checkAndTrigger(userId, 'comeback', `comeback-${new Date().toISOString().split('T')[0]}`);
    },
    /**
     * Get today's bonus event count for a user
     */
    async getTodayCount(userId, eventTypeCode) {
        const result = await (0, client_1.queryOne)(`SELECT COUNT(*) as count FROM user_bonus_events
       WHERE user_id = $1 AND event_type_code = $2 AND created_at >= CURRENT_DATE`, [userId, eventTypeCode]);
        return parseInt(result?.count || '0');
    },
    /**
     * Get user's bonus event history
     */
    async getUserBonusHistory(userId, limit = 50, offset = 0) {
        const rows = await (0, client_1.queryAll)(`SELECT id, event_type_code, credits_awarded, created_at
       FROM user_bonus_events
       WHERE user_id = $1
       ORDER BY created_at DESC
       LIMIT $2 OFFSET $3`, [userId, limit, offset]);
        return rows.map(r => ({
            id: r.id,
            eventType: r.event_type_code,
            creditsAwarded: r.credits_awarded,
            createdAt: r.created_at,
        }));
    },
    /**
     * Calculate random reward between min and max
     * Uses weighted distribution favoring lower values
     */
    calculateReward(min, max) {
        if (min === max)
            return min;
        // Use exponential distribution for more low rewards, fewer high rewards
        const range = max - min;
        const random = Math.random();
        // 70% chance of lower half, 25% middle, 5% top
        let reward;
        if (random < 0.7) {
            reward = min + Math.floor(range * 0.5 * Math.random());
        }
        else if (random < 0.95) {
            reward = min + Math.floor(range * 0.5) + Math.floor(range * 0.3 * Math.random());
        }
        else {
            reward = min + Math.floor(range * 0.8) + Math.floor(range * 0.2 * Math.random());
        }
        return Math.max(min, Math.min(max, reward));
    },
    /**
     * Process all workout-related bonuses
     */
    async processWorkoutBonuses(userId, workoutId, _totalReps, _totalSets) {
        const results = [];
        // Check workout jackpot (once per workout)
        const workoutBonus = await this.checkWorkoutBonus(userId, workoutId);
        if (workoutBonus.triggered) {
            results.push(workoutBonus);
        }
        // Check time-based bonuses
        const earlyBird = await this.checkEarlyBirdBonus(userId, workoutId);
        if (earlyBird.triggered) {
            results.push(earlyBird);
        }
        const nightOwl = await this.checkNightOwlBonus(userId, workoutId);
        if (nightOwl.triggered) {
            results.push(nightOwl);
        }
        const weekend = await this.checkWeekendBonus(userId, workoutId);
        if (weekend.triggered) {
            results.push(weekend);
        }
        return results;
    },
};
exports.default = exports.bonusEventsService;
//# sourceMappingURL=bonusEvents.service.js.map