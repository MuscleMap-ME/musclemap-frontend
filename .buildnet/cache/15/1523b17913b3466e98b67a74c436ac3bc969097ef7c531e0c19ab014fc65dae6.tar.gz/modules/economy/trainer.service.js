"use strict";
/**
 * Trainer Service
 *
 * Manages trainer profiles, classes, enrollments, and attendance.
 * Handles wage distribution for trainers based on class attendance.
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.trainerService = void 0;
const crypto_1 = __importDefault(require("crypto"));
const client_1 = require("../../db/client");
const logger_1 = require("../../lib/logger");
const errors_1 = require("../../lib/errors");
const wallet_service_1 = require("./wallet.service");
const earning_service_1 = require("./earning.service");
const log = logger_1.loggers.economy;
/**
 * Safely parse JSON array or comma-separated string
 */
function parseJsonOrCsv(value) {
    if (!value)
        return [];
    if (Array.isArray(value))
        return value;
    try {
        const parsed = JSON.parse(value);
        return Array.isArray(parsed) ? parsed : [String(parsed)];
    }
    catch {
        // Not JSON, treat as comma-separated string
        return value.split(',').map(s => s.trim()).filter(Boolean);
    }
}
/**
 * Safely parse JSON object or return object as-is (for JSONB columns)
 */
function parseJsonOrObject(value) {
    if (!value)
        return {};
    if (typeof value === 'object')
        return value;
    try {
        return JSON.parse(value);
    }
    catch {
        return {};
    }
}
exports.trainerService = {
    // ==========================================
    // TRAINER PROFILE MANAGEMENT
    // ==========================================
    /**
     * Get trainer profile by user ID
     */
    async getProfile(userId) {
        const row = await (0, client_1.queryOne)(`SELECT * FROM trainer_profiles WHERE user_id = $1`, [userId]);
        if (!row)
            return null;
        return {
            userId: row.user_id,
            displayName: row.display_name,
            bio: row.bio ?? undefined,
            specialties: parseJsonOrCsv(row.specialties),
            certifications: parseJsonOrCsv(row.certifications),
            hourlyRateCredits: row.hourly_rate_credits,
            perClassRateCredits: row.per_class_rate_credits,
            verified: row.verified,
            verifiedAt: row.verified_at ?? undefined,
            ratingAvg: parseFloat(String(row.rating_avg)) || 0,
            ratingCount: row.rating_count,
            totalClassesTaught: row.total_classes_taught,
            totalStudentsTrained: row.total_students_trained,
            totalCreditsEarned: row.total_credits_earned,
            status: row.status,
            createdAt: row.created_at,
        };
    },
    /**
     * Create or update trainer profile
     */
    async upsertProfile(userId, input) {
        const existing = await this.getProfile(userId);
        if (existing) {
            // Update
            await (0, client_1.query)(`UPDATE trainer_profiles SET
          display_name = $2,
          bio = $3,
          specialties = $4,
          certifications = $5,
          hourly_rate_credits = COALESCE($6, hourly_rate_credits),
          per_class_rate_credits = COALESCE($7, per_class_rate_credits),
          updated_at = NOW()
         WHERE user_id = $1`, [
                userId,
                input.displayName,
                input.bio || null,
                JSON.stringify(input.specialties || []),
                JSON.stringify(input.certifications || []),
                input.hourlyRateCredits ?? null,
                input.perClassRateCredits ?? null,
            ]);
        }
        else {
            // Create
            await (0, client_1.query)(`INSERT INTO trainer_profiles (user_id, display_name, bio, specialties, certifications, hourly_rate_credits, per_class_rate_credits)
         VALUES ($1, $2, $3, $4, $5, $6, $7)`, [
                userId,
                input.displayName,
                input.bio || null,
                JSON.stringify(input.specialties || []),
                JSON.stringify(input.certifications || []),
                input.hourlyRateCredits ?? 100,
                input.perClassRateCredits ?? 50,
            ]);
        }
        log.info({ userId }, 'Trainer profile upserted');
        return (await this.getProfile(userId));
    },
    /**
     * List trainer profiles with optional filters
     */
    async listProfiles(options = {}) {
        const { verified, specialty, status = 'active', limit = 50, offset = 0 } = options;
        let whereClause = 'status = $1';
        const params = [status];
        let paramIndex = 2;
        if (verified !== undefined) {
            whereClause += ` AND verified = $${paramIndex++}`;
            params.push(verified);
        }
        if (specialty) {
            whereClause += ` AND specialties::text ILIKE $${paramIndex++}`;
            params.push(`%${specialty}%`);
        }
        params.push(limit, offset);
        const rows = await (0, client_1.queryAll)(`SELECT * FROM trainer_profiles
       WHERE ${whereClause}
       ORDER BY rating_avg DESC, total_classes_taught DESC
       LIMIT $${paramIndex++} OFFSET $${paramIndex++}`, params);
        const countResult = await (0, client_1.queryOne)(`SELECT COUNT(*) as count FROM trainer_profiles WHERE ${whereClause}`, params.slice(0, -2));
        return {
            trainers: rows.map((row) => ({
                userId: row.user_id,
                displayName: row.display_name,
                bio: row.bio ?? undefined,
                specialties: parseJsonOrCsv(row.specialties),
                certifications: parseJsonOrCsv(row.certifications),
                hourlyRateCredits: row.hourly_rate_credits,
                perClassRateCredits: row.per_class_rate_credits,
                verified: row.verified,
                verifiedAt: row.verified_at ?? undefined,
                ratingAvg: parseFloat(String(row.rating_avg)) || 0,
                ratingCount: row.rating_count,
                totalClassesTaught: row.total_classes_taught,
                totalStudentsTrained: row.total_students_trained,
                totalCreditsEarned: row.total_credits_earned,
                status: row.status,
                createdAt: row.created_at,
            })),
            total: parseInt(countResult?.count || '0', 10),
        };
    },
    /**
     * Update trainer status
     */
    async updateStatus(userId, status) {
        await (0, client_1.query)(`UPDATE trainer_profiles SET status = $2, updated_at = NOW() WHERE user_id = $1`, [userId, status]);
        log.info({ userId, status }, 'Trainer status updated');
    },
    // ==========================================
    // CLASS MANAGEMENT
    // ==========================================
    /**
     * Create a new class
     */
    async createClass(trainerUserId, input) {
        // Verify trainer exists and is active
        const profile = await this.getProfile(trainerUserId);
        if (!profile) {
            throw new errors_1.NotFoundError('Trainer profile not found. Please create a profile first.');
        }
        if (profile.status !== 'active') {
            throw new errors_1.ForbiddenError('Trainer profile is not active');
        }
        // Validate start time is in the future
        if (new Date(input.startAt) <= new Date()) {
            throw new errors_1.ValidationError('Class start time must be in the future');
        }
        const classId = `class_${crypto_1.default.randomBytes(12).toString('hex')}`;
        await (0, client_1.query)(`INSERT INTO trainer_classes (
        id, trainer_user_id, title, description, category, difficulty,
        start_at, duration_minutes, location_type, location_details,
        hangout_id, virtual_hangout_id, capacity, credits_per_student, trainer_wage_per_student
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15)`, [
            classId,
            trainerUserId,
            input.title,
            input.description || null,
            input.category,
            input.difficulty,
            input.startAt,
            input.durationMinutes,
            input.locationType,
            input.locationDetails || null,
            input.hangoutId || null,
            input.virtualHangoutId || null,
            input.capacity,
            input.creditsPerStudent,
            input.trainerWagePerStudent,
        ]);
        log.info({ classId, trainerUserId }, 'Class created');
        return (await this.getClass(classId));
    },
    /**
     * Get class by ID
     */
    async getClass(classId) {
        const row = await (0, client_1.queryOne)(`SELECT * FROM trainer_classes WHERE id = $1`, [classId]);
        if (!row)
            return null;
        return {
            id: row.id,
            trainerUserId: row.trainer_user_id,
            title: row.title,
            description: row.description ?? undefined,
            category: row.category,
            difficulty: row.difficulty,
            startAt: row.start_at,
            durationMinutes: row.duration_minutes,
            locationType: row.location_type,
            locationDetails: row.location_details ?? undefined,
            hangoutId: row.hangout_id ?? undefined,
            virtualHangoutId: row.virtual_hangout_id ?? undefined,
            capacity: row.capacity,
            enrolledCount: row.enrolled_count,
            creditsPerStudent: row.credits_per_student,
            trainerWagePerStudent: row.trainer_wage_per_student,
            status: row.status,
            metadata: parseJsonOrObject(row.metadata),
            createdAt: row.created_at,
        };
    },
    /**
     * List classes with filters
     */
    async listClasses(options = {}) {
        const { trainerUserId, status, category, upcoming, limit = 50, offset = 0 } = options;
        let whereClause = '1=1';
        const params = [];
        let paramIndex = 1;
        if (trainerUserId) {
            whereClause += ` AND trainer_user_id = $${paramIndex++}`;
            params.push(trainerUserId);
        }
        if (status) {
            whereClause += ` AND status = $${paramIndex++}`;
            params.push(status);
        }
        if (category) {
            whereClause += ` AND category = $${paramIndex++}`;
            params.push(category);
        }
        if (upcoming) {
            whereClause += ` AND start_at > NOW() AND status = 'scheduled'`;
        }
        params.push(limit, offset);
        const rows = await (0, client_1.queryAll)(`SELECT * FROM trainer_classes
       WHERE ${whereClause}
       ORDER BY start_at ASC
       LIMIT $${paramIndex++} OFFSET $${paramIndex++}`, params);
        const countResult = await (0, client_1.queryOne)(`SELECT COUNT(*) as count FROM trainer_classes WHERE ${whereClause}`, params.slice(0, -2));
        return {
            classes: rows.map((row) => ({
                id: row.id,
                trainerUserId: row.trainer_user_id,
                title: row.title,
                description: row.description ?? undefined,
                category: row.category,
                difficulty: row.difficulty,
                startAt: row.start_at,
                durationMinutes: row.duration_minutes,
                locationType: row.location_type,
                locationDetails: row.location_details ?? undefined,
                hangoutId: row.hangout_id ?? undefined,
                virtualHangoutId: row.virtual_hangout_id ?? undefined,
                capacity: row.capacity,
                enrolledCount: row.enrolled_count,
                creditsPerStudent: row.credits_per_student,
                trainerWagePerStudent: row.trainer_wage_per_student,
                status: row.status,
                metadata: parseJsonOrObject(row.metadata),
                createdAt: row.created_at,
            })),
            total: parseInt(countResult?.count || '0', 10),
        };
    },
    /**
     * Update class
     */
    async updateClass(classId, updates) {
        const classData = await this.getClass(classId);
        if (!classData) {
            throw new errors_1.NotFoundError('Class not found');
        }
        if (classData.status !== 'draft' && classData.status !== 'scheduled') {
            throw new errors_1.ValidationError('Cannot update a class that has started or completed');
        }
        const setClauses = [];
        const params = [];
        let paramIndex = 1;
        if (updates.title !== undefined) {
            setClauses.push(`title = $${paramIndex++}`);
            params.push(updates.title);
        }
        if (updates.description !== undefined) {
            setClauses.push(`description = $${paramIndex++}`);
            params.push(updates.description);
        }
        if (updates.category !== undefined) {
            setClauses.push(`category = $${paramIndex++}`);
            params.push(updates.category);
        }
        if (updates.difficulty !== undefined) {
            setClauses.push(`difficulty = $${paramIndex++}`);
            params.push(updates.difficulty);
        }
        if (updates.startAt !== undefined) {
            setClauses.push(`start_at = $${paramIndex++}`);
            params.push(updates.startAt);
        }
        if (updates.durationMinutes !== undefined) {
            setClauses.push(`duration_minutes = $${paramIndex++}`);
            params.push(updates.durationMinutes);
        }
        if (updates.locationType !== undefined) {
            setClauses.push(`location_type = $${paramIndex++}`);
            params.push(updates.locationType);
        }
        if (updates.locationDetails !== undefined) {
            setClauses.push(`location_details = $${paramIndex++}`);
            params.push(updates.locationDetails);
        }
        if (updates.capacity !== undefined) {
            setClauses.push(`capacity = $${paramIndex++}`);
            params.push(updates.capacity);
        }
        if (updates.creditsPerStudent !== undefined) {
            setClauses.push(`credits_per_student = $${paramIndex++}`);
            params.push(updates.creditsPerStudent);
        }
        if (updates.trainerWagePerStudent !== undefined) {
            setClauses.push(`trainer_wage_per_student = $${paramIndex++}`);
            params.push(updates.trainerWagePerStudent);
        }
        if (setClauses.length > 0) {
            setClauses.push('updated_at = NOW()');
            params.push(classId);
            await (0, client_1.query)(`UPDATE trainer_classes SET ${setClauses.join(', ')} WHERE id = $${paramIndex}`, params);
        }
        return (await this.getClass(classId));
    },
    /**
     * Cancel a class
     */
    async cancelClass(classId, reason) {
        const classData = await this.getClass(classId);
        if (!classData) {
            throw new errors_1.NotFoundError('Class not found');
        }
        if (classData.status === 'completed' || classData.status === 'cancelled') {
            throw new errors_1.ValidationError('Class is already completed or cancelled');
        }
        // Refund all enrolled students
        const enrollments = await (0, client_1.queryAll)(`SELECT id, user_id, credits_paid, status FROM class_enrollments WHERE class_id = $1 AND status = 'enrolled'`, [classId]);
        for (const enrollment of enrollments) {
            if (enrollment.credits_paid > 0) {
                const refundResult = await wallet_service_1.walletService.adminAdjust({
                    userId: enrollment.user_id,
                    amount: enrollment.credits_paid,
                    adminUserId: 'system',
                    reason: `Refund for cancelled class: ${classData.title}`,
                });
                await (0, client_1.query)(`UPDATE class_enrollments SET status = 'refunded', cancelled_at = NOW(), refund_tx_id = $1 WHERE id = $2`, [refundResult.entryId, enrollment.id]);
            }
        }
        await (0, client_1.query)(`UPDATE trainer_classes SET status = 'cancelled', metadata = jsonb_set(COALESCE(metadata, '{}'), '{cancelReason}', $1::jsonb), updated_at = NOW() WHERE id = $2`, [JSON.stringify(reason || 'Cancelled by trainer'), classId]);
        log.info({ classId, reason }, 'Class cancelled');
    },
    // ==========================================
    // ENROLLMENT MANAGEMENT
    // ==========================================
    /**
     * Enroll in a class
     */
    async enroll(userId, classId) {
        const classData = await this.getClass(classId);
        if (!classData) {
            throw new errors_1.NotFoundError('Class not found');
        }
        if (classData.status !== 'scheduled') {
            throw new errors_1.ValidationError('Class is not available for enrollment');
        }
        if (classData.enrolledCount >= classData.capacity) {
            throw new errors_1.ValidationError('Class is full');
        }
        // Check if user is the trainer
        if (userId === classData.trainerUserId) {
            throw new errors_1.ValidationError('Trainers cannot enroll in their own classes');
        }
        // Check if already enrolled
        const existing = await (0, client_1.queryOne)(`SELECT id FROM class_enrollments WHERE class_id = $1 AND user_id = $2 AND status = 'enrolled'`, [classId, userId]);
        if (existing) {
            throw new errors_1.ValidationError('Already enrolled in this class');
        }
        const enrollmentId = `enroll_${crypto_1.default.randomBytes(12).toString('hex')}`;
        let paymentTxId;
        // Charge credits if needed
        if (classData.creditsPerStudent > 0) {
            const balance = await wallet_service_1.walletService.getBalance(userId);
            if (balance < classData.creditsPerStudent) {
                throw new errors_1.ValidationError('Insufficient credits to enroll');
            }
            const chargeResult = await wallet_service_1.walletService.charge({
                userId,
                amount: classData.creditsPerStudent,
                action: 'class_enrollment',
                metadata: { classId, classTitle: classData.title },
                idempotencyKey: `class_enrollment:${userId}:${classId}:${Date.now()}-${crypto_1.default.randomBytes(4).toString('hex')}`,
            });
            paymentTxId = chargeResult.ledgerEntryId;
        }
        await (0, client_1.serializableTransaction)(async (client) => {
            await client.query(`INSERT INTO class_enrollments (id, class_id, user_id, status, payment_tx_id, credits_paid)
         VALUES ($1, $2, $3, 'enrolled', $4, $5)`, [enrollmentId, classId, userId, paymentTxId, classData.creditsPerStudent]);
            await client.query(`UPDATE trainer_classes SET enrolled_count = enrolled_count + 1, updated_at = NOW() WHERE id = $1`, [classId]);
        });
        log.info({ enrollmentId, classId, userId }, 'User enrolled in class');
        return (await this.getEnrollment(enrollmentId));
    },
    /**
     * Get enrollment by ID
     */
    async getEnrollment(enrollmentId) {
        const row = await (0, client_1.queryOne)(`SELECT * FROM class_enrollments WHERE id = $1`, [enrollmentId]);
        if (!row)
            return null;
        return {
            id: row.id,
            classId: row.class_id,
            userId: row.user_id,
            status: row.status,
            paymentTxId: row.payment_tx_id ?? undefined,
            creditsPaid: row.credits_paid,
            enrolledAt: row.enrolled_at,
            cancelledAt: row.cancelled_at ?? undefined,
            refundTxId: row.refund_tx_id ?? undefined,
        };
    },
    /**
     * Get enrollments for a class
     */
    async getClassEnrollments(classId) {
        const rows = await (0, client_1.queryAll)(`SELECT * FROM class_enrollments WHERE class_id = $1 ORDER BY enrolled_at ASC`, [classId]);
        return rows.map((row) => ({
            id: row.id,
            classId: row.class_id,
            userId: row.user_id,
            status: row.status,
            paymentTxId: row.payment_tx_id ?? undefined,
            creditsPaid: row.credits_paid,
            enrolledAt: row.enrolled_at,
            cancelledAt: row.cancelled_at ?? undefined,
            refundTxId: row.refund_tx_id ?? undefined,
        }));
    },
    /**
     * Get user's enrollments
     */
    async getUserEnrollments(userId, options = {}) {
        const { status, limit = 50, offset = 0 } = options;
        let whereClause = 'e.user_id = $1';
        const params = [userId];
        let paramIndex = 2;
        if (status) {
            whereClause += ` AND e.status = $${paramIndex++}`;
            params.push(status);
        }
        params.push(limit, offset);
        const rows = await (0, client_1.queryAll)(`SELECT e.*, c.id as c_id, c.trainer_user_id as c_trainer_user_id, c.title as c_title,
              c.description as c_description, c.category as c_category, c.difficulty as c_difficulty,
              c.start_at as c_start_at, c.duration_minutes as c_duration_minutes,
              c.location_type as c_location_type, c.location_details as c_location_details,
              c.capacity as c_capacity, c.enrolled_count as c_enrolled_count,
              c.credits_per_student as c_credits_per_student, c.trainer_wage_per_student as c_trainer_wage_per_student,
              c.status as c_status, c.metadata as c_metadata, c.created_at as c_created_at
       FROM class_enrollments e
       JOIN trainer_classes c ON e.class_id = c.id
       WHERE ${whereClause}
       ORDER BY c.start_at DESC
       LIMIT $${paramIndex++} OFFSET $${paramIndex++}`, params);
        const countResult = await (0, client_1.queryOne)(`SELECT COUNT(*) as count FROM class_enrollments e WHERE ${whereClause}`, params.slice(0, -2));
        return {
            enrollments: rows.map((row) => ({
                id: row.id,
                classId: row.class_id,
                userId: row.user_id,
                status: row.status,
                paymentTxId: row.payment_tx_id ?? undefined,
                creditsPaid: row.credits_paid,
                enrolledAt: row.enrolled_at,
                cancelledAt: row.cancelled_at ?? undefined,
                refundTxId: row.refund_tx_id ?? undefined,
                class: {
                    id: row.c_id,
                    trainerUserId: row.c_trainer_user_id,
                    title: row.c_title,
                    description: row.c_description ?? undefined,
                    category: row.c_category,
                    difficulty: row.c_difficulty,
                    startAt: row.c_start_at,
                    durationMinutes: row.c_duration_minutes,
                    locationType: row.c_location_type,
                    locationDetails: row.c_location_details ?? undefined,
                    capacity: row.c_capacity,
                    enrolledCount: row.c_enrolled_count,
                    creditsPerStudent: row.c_credits_per_student,
                    trainerWagePerStudent: row.c_trainer_wage_per_student,
                    status: row.c_status,
                    metadata: parseJsonOrObject(row.c_metadata),
                    createdAt: row.c_created_at,
                },
            })),
            total: parseInt(countResult?.count || '0', 10),
        };
    },
    /**
     * Cancel enrollment
     */
    async cancelEnrollment(userId, classId) {
        const enrollment = await (0, client_1.queryOne)(`SELECT id, credits_paid, status FROM class_enrollments WHERE class_id = $1 AND user_id = $2`, [classId, userId]);
        if (!enrollment) {
            throw new errors_1.NotFoundError('Enrollment not found');
        }
        if (enrollment.status !== 'enrolled') {
            throw new errors_1.ValidationError('Enrollment is not active');
        }
        const classData = await this.getClass(classId);
        if (!classData) {
            throw new errors_1.NotFoundError('Class not found');
        }
        // Check if class hasn't started yet
        if (new Date(classData.startAt) <= new Date()) {
            throw new errors_1.ValidationError('Cannot cancel enrollment after class has started');
        }
        // Refund credits
        let refundTxId;
        if (enrollment.credits_paid > 0) {
            const refundResult = await wallet_service_1.walletService.adminAdjust({
                userId,
                amount: enrollment.credits_paid,
                adminUserId: 'system',
                reason: `Enrollment cancellation refund: ${classData.title}`,
            });
            refundTxId = refundResult.entryId;
        }
        await (0, client_1.serializableTransaction)(async (client) => {
            await client.query(`UPDATE class_enrollments SET status = 'cancelled', cancelled_at = NOW(), refund_tx_id = $1 WHERE id = $2`, [refundTxId, enrollment.id]);
            await client.query(`UPDATE trainer_classes SET enrolled_count = enrolled_count - 1, updated_at = NOW() WHERE id = $1`, [classId]);
        });
        log.info({ classId, userId }, 'Enrollment cancelled');
    },
    // ==========================================
    // ATTENDANCE MANAGEMENT
    // ==========================================
    /**
     * Mark attendance for a class
     */
    async markAttendance(trainerId, classId, attendees) {
        const classData = await this.getClass(classId);
        if (!classData) {
            throw new errors_1.NotFoundError('Class not found');
        }
        // Verify trainer owns this class
        if (classData.trainerUserId !== trainerId) {
            throw new errors_1.ForbiddenError('Only the class trainer can mark attendance');
        }
        // Verify class status
        if (classData.status !== 'scheduled' && classData.status !== 'in_progress') {
            throw new errors_1.ValidationError('Cannot mark attendance for this class');
        }
        let attendeeCount = 0;
        let totalWage = 0;
        for (const attendee of attendees) {
            // Verify user was enrolled
            const enrollment = await (0, client_1.queryOne)(`SELECT id FROM class_enrollments WHERE class_id = $1 AND user_id = $2 AND status = 'enrolled'`, [classId, attendee.userId]);
            if (!enrollment) {
                log.warn({ classId, userId: attendee.userId }, 'Attempted to mark attendance for unenrolled user');
                continue;
            }
            const attendanceId = `attend_${crypto_1.default.randomBytes(12).toString('hex')}`;
            let wageTxId;
            if (attendee.attended) {
                attendeeCount++;
                // Pay trainer wage for this attendee
                if (classData.trainerWagePerStudent > 0) {
                    const wageResult = await wallet_service_1.walletService.adminAdjust({
                        userId: trainerId,
                        amount: classData.trainerWagePerStudent,
                        adminUserId: 'system',
                        reason: `Class wage: ${classData.title} (attendee: ${attendee.userId})`,
                    });
                    wageTxId = wageResult.entryId;
                    totalWage += classData.trainerWagePerStudent;
                }
                // Update enrollment status
                await (0, client_1.query)(`UPDATE class_enrollments SET status = 'completed' WHERE class_id = $1 AND user_id = $2`, [classId, attendee.userId]);
                // Award XP to student
                await earning_service_1.earningService.processEarning({
                    userId: attendee.userId,
                    ruleCode: 'first_hangout_join', // Reusing this for class attendance
                    sourceType: 'class_attendance',
                    sourceId: classId,
                }).catch(() => { }); // Ignore if already awarded
            }
            // Record attendance
            await (0, client_1.query)(`INSERT INTO class_attendance (id, class_id, user_id, attended, marked_by, wage_tx_id, rating, feedback)
         VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
         ON CONFLICT (class_id, user_id) DO UPDATE SET
           attended = $4, marked_by = $5, wage_tx_id = COALESCE($6, class_attendance.wage_tx_id),
           rating = COALESCE($7, class_attendance.rating), feedback = COALESCE($8, class_attendance.feedback),
           marked_at = NOW()`, [attendanceId, classId, attendee.userId, attendee.attended, trainerId, wageTxId, attendee.rating || null, attendee.feedback || null]);
        }
        // Update class status to completed
        await (0, client_1.query)(`UPDATE trainer_classes SET status = 'completed', updated_at = NOW() WHERE id = $1`, [classId]);
        // Update trainer stats
        await (0, client_1.query)(`UPDATE trainer_profiles SET
        total_classes_taught = total_classes_taught + 1,
        total_students_trained = total_students_trained + $1,
        total_credits_earned = total_credits_earned + $2,
        updated_at = NOW()
       WHERE user_id = $3`, [attendeeCount, totalWage, trainerId]);
        // Update rating if provided
        const ratings = attendees.filter(a => a.rating).map(a => a.rating);
        if (ratings.length > 0) {
            const _avgRating = ratings.reduce((a, b) => a + b, 0) / ratings.length;
            await (0, client_1.query)(`UPDATE trainer_profiles SET
          rating_avg = ((rating_avg * rating_count) + $1) / (rating_count + $2),
          rating_count = rating_count + $2,
          updated_at = NOW()
         WHERE user_id = $3`, [ratings.reduce((a, b) => a + b, 0), ratings.length, trainerId]);
        }
        log.info({ classId, trainerId, attendeeCount, wageEarned: totalWage }, 'Attendance marked');
        return { attendeeCount, wageEarned: totalWage };
    },
    /**
     * Get attendance for a class
     */
    async getClassAttendance(classId) {
        const rows = await (0, client_1.queryAll)(`SELECT * FROM class_attendance WHERE class_id = $1`, [classId]);
        return rows.map((row) => ({
            id: row.id,
            classId: row.class_id,
            userId: row.user_id,
            attended: row.attended,
            markedBy: row.marked_by,
            wageTxId: row.wage_tx_id ?? undefined,
            rating: row.rating ?? undefined,
            feedback: row.feedback ?? undefined,
            markedAt: row.marked_at,
        }));
    },
};
exports.default = exports.trainerService;
//# sourceMappingURL=trainer.service.js.map