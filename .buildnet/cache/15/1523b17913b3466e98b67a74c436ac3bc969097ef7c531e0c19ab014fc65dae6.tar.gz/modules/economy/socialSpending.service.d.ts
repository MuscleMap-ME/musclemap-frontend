/**
 * Social Spending Service
 *
 * Handles credit-based social interactions:
 * - Tips (send credits to other users)
 * - Gifts (purchase store items for others)
 * - Super High Fives (enhanced reactions with cost)
 * - Post Boosts (promote content in feeds)
 *
 * Social spending creates engagement and community!
 */
export interface Tip {
    id: string;
    senderId: string;
    recipientId: string;
    amount: number;
    message?: string;
    sourceType?: string;
    sourceId?: string;
    createdAt: Date;
}
export interface Gift {
    id: string;
    senderId: string;
    recipientId: string;
    itemSku: string;
    itemName?: string;
    message?: string;
    totalCost: number;
    status: 'pending' | 'accepted' | 'declined' | 'expired';
    createdAt: Date;
    expiresAt: Date;
}
export interface SuperHighFive {
    id: string;
    senderId: string;
    recipientId: string;
    type: 'super' | 'mega' | 'standing_ovation';
    cost: number;
    sourceType?: string;
    sourceId?: string;
    message?: string;
    createdAt: Date;
}
export interface PostBoost {
    id: string;
    userId: string;
    targetType: string;
    targetId: string;
    cost: number;
    boostMultiplier: number;
    startsAt: Date;
    endsAt: Date;
    impressionsGained: number;
}
export declare const socialSpendingService: {
    /**
     * Send a tip to another user
     */
    sendTip(senderId: string, recipientId: string, amount: number, options?: {
        message?: string;
        sourceType?: string;
        sourceId?: string;
    }): Promise<Tip>;
    /**
     * Send a gift (store item) to another user
     */
    sendGift(senderId: string, recipientId: string, itemSku: string, options?: {
        message?: string;
    }): Promise<Gift>;
    /**
     * Accept a gift
     */
    acceptGift(giftId: string, recipientId: string): Promise<void>;
    /**
     * Decline a gift (refund sender)
     */
    declineGift(giftId: string, recipientId: string): Promise<void>;
    /**
     * Send a super high five
     */
    sendSuperHighFive(senderId: string, recipientId: string, type: "super" | "mega" | "standing_ovation", options?: {
        sourceType?: string;
        sourceId?: string;
        message?: string;
    }): Promise<SuperHighFive>;
    /**
     * Boost a post
     */
    boostPost(userId: string, targetType: string, targetId: string, boostOption: "24h" | "7d"): Promise<PostBoost>;
    /**
     * Get user's sent tips
     */
    getSentTips(userId: string, limit?: number): Promise<Tip[]>;
    /**
     * Get user's received tips
     */
    getReceivedTips(userId: string, limit?: number): Promise<Tip[]>;
    /**
     * Get pending gifts for a user
     */
    getPendingGifts(userId: string): Promise<Gift[]>;
    /**
     * Get super high fives received
     */
    getReceivedSuperHighFives(userId: string, limit?: number): Promise<SuperHighFive[]>;
    /**
     * Get active boosts for a post
     */
    getActiveBoost(targetType: string, targetId: string): Promise<PostBoost | null>;
    /**
     * Get super high five costs
     */
    getSuperHighFiveCosts(): {
        super: number;
        mega: number;
        standing_ovation: number;
    };
    /**
     * Get post boost options
     */
    getPostBoostOptions(): {
        '24h': {
            cost: number;
            durationHours: number;
            multiplier: number;
        };
        '7d': {
            cost: number;
            durationHours: number;
            multiplier: number;
        };
    };
};
export default socialSpendingService;
