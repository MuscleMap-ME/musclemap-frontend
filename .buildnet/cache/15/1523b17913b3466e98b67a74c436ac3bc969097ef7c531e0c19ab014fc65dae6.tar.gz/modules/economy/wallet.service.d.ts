/**
 * Enhanced Wallet Service
 *
 * Extends the credit service with:
 * - P2P credit transfers with atomic transactions
 * - Wallet freeze/unfreeze for anti-abuse
 * - Transaction reversals for admin
 * - Rate limiting integration
 * - Audit logging
 */
export interface WalletDetails {
    userId: string;
    balance: number;
    totalEarned: number;
    totalSpent: number;
    totalTransferredOut: number;
    totalTransferredIn: number;
    status: 'active' | 'frozen' | 'suspended';
    frozenAt?: Date;
    frozenReason?: string;
}
export interface TransferRequest {
    senderId: string;
    recipientId: string;
    amount: number;
    note?: string;
    tipType?: 'trainer' | 'user' | 'group';
}
export interface TransferResult {
    transferId: string;
    senderNewBalance: number;
    recipientNewBalance: number;
}
export interface ReverseRequest {
    transactionId: string;
    adminUserId: string;
    reason: string;
}
export interface ReverseResult {
    reversalId: string;
    reversedAmount: number;
    newBalance: number;
}
export declare const walletService: {
    /**
     * Get detailed wallet information
     */
    getWalletDetails(userId: string): Promise<WalletDetails>;
    /**
     * Ensure wallet exists for user
     */
    ensureWallet(userId: string): Promise<void>;
    /**
     * Check if wallet can transact
     */
    canTransact(userId: string): Promise<{
        allowed: boolean;
        reason?: string;
    }>;
    /**
     * Transfer credits between users with atomic transaction
     */
    transfer(request: TransferRequest): Promise<TransferResult>;
    /**
     * Freeze a wallet (admin action)
     */
    freezeWallet(userId: string, adminUserId: string, reason: string): Promise<void>;
    /**
     * Unfreeze a wallet (admin action)
     */
    unfreezeWallet(userId: string, adminUserId: string, reason: string): Promise<void>;
    /**
     * Reverse a transaction (admin action)
     */
    reverseTransaction(request: ReverseRequest): Promise<ReverseResult>;
    /**
     * Manual credit adjustment (admin action)
     */
    adminAdjust(params: {
        userId: string;
        amount: number;
        adminUserId: string;
        reason: string;
    }): Promise<{
        entryId: string;
        newBalance: number;
    }>;
    /**
     * Get transaction history with enhanced filtering
     */
    getTransactionHistory(userId: string, options?: {
        limit?: number;
        offset?: number;
        action?: string;
        fromDate?: Date;
        toDate?: Date;
    }): Promise<{
        transactions: Array<{
            id: string;
            action: string;
            amount: number;
            balanceAfter: number;
            metadata: Record<string, unknown> | null;
            createdAt: Date;
        }>;
        total: number;
    }>;
    /**
     * Get transfer history
     */
    getTransferHistory(userId: string, options?: {
        direction?: "sent" | "received" | "all";
        limit?: number;
        offset?: number;
    }): Promise<{
        transfers: Array<{
            id: string;
            senderId: string;
            recipientId: string;
            amount: number;
            note?: string;
            status: string;
            createdAt: Date;
            direction: "sent" | "received";
        }>;
        total: number;
    }>;
    /**
     * Check transfer rate limits
     * Uses 60-second time buffers to prevent clock sensitivity issues at boundaries.
     * This prevents edge cases where rapid requests could exploit the exact moment
     * of a rate limit reset due to clock skew across distributed systems.
     */
    checkTransferRateLimit(userId: string): Promise<{
        allowed: boolean;
        reason?: string;
    }>;
    /**
     * Record a transfer for rate limiting
     */
    recordTransfer(userId: string): Promise<void>;
    /**
     * Log admin action for audit
     */
    logAdminAction(params: {
        adminUserId: string;
        action: string;
        targetUserId?: string;
        targetTxId?: string;
        amount?: number;
        reason: string;
        details?: Record<string, unknown>;
        ipAddress?: string;
        userAgent?: string;
    }): Promise<void>;
    getBalance: (userId: string) => Promise<number>;
    charge: (request: import("./credit.service").ChargeRequest) => Promise<import("./credit.service").ChargeResult>;
    addCredits: (userId: string, amount: number, action: string, metadata?: Record<string, unknown>, idempotencyKey?: string) => Promise<import("./credit.service").ChargeResult>;
    canAfford: (userId: string, amount: number) => Promise<boolean>;
    initializeBalance: (userId: string, initialBalance?: number) => Promise<void>;
};
export default walletService;
