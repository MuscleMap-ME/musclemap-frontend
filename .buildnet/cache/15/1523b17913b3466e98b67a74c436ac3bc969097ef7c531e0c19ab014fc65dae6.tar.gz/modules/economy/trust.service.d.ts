/**
 * Trust Tier Service
 *
 * Manages user trust levels based on account age, activity, and verification.
 * Trust tiers gate transfer limits and other economy features.
 */
export interface TrustTier {
    tier: number;
    name: string;
    description: string;
    minAccountAgeDays: number;
    minWorkouts: number;
    minCreditsEarned: number;
    requiresEmailVerified: boolean;
    requiresPhoneVerified: boolean;
    dailyTransferLimit: number;
    singleTransferLimit: number;
    canReceiveTransfers: boolean;
    canSendTransfers: boolean;
    canCreateClasses: boolean;
    canHostHangouts: boolean;
}
export interface UserTrustInfo {
    userId: string;
    currentTier: number;
    tierName: string;
    accountAgeDays: number;
    workoutCount: number;
    creditsEarned: number;
    emailVerified: boolean;
    phoneVerified: boolean;
    manualOverride: boolean;
    limits: {
        dailyTransferLimit: number;
        singleTransferLimit: number;
        canSendTransfers: boolean;
        canReceiveTransfers: boolean;
        canCreateClasses: boolean;
        canHostHangouts: boolean;
    };
    nextTierProgress: {
        nextTier: number;
        nextTierName: string;
        requirements: {
            accountAgeDays: {
                current: number;
                required: number;
                met: boolean;
            };
            workouts: {
                current: number;
                required: number;
                met: boolean;
            };
            creditsEarned: {
                current: number;
                required: number;
                met: boolean;
            };
            emailVerified: {
                current: boolean;
                required: boolean;
                met: boolean;
            };
        };
        overallProgress: number;
    } | null;
}
export declare const trustService: {
    /**
     * Get all trust tier definitions
     */
    getTiers(): Promise<TrustTier[]>;
    /**
     * Calculate user's trust tier based on their activity
     */
    calculateTier(userId: string): Promise<UserTrustInfo>;
    /**
     * Get user's current trust info (from cache or calculate)
     */
    getUserTrust(userId: string): Promise<UserTrustInfo>;
    /**
     * Check if user can perform a transfer
     */
    canTransfer(senderId: string, recipientId: string, amount: number): Promise<{
        allowed: boolean;
        reason?: string;
        senderTier: number;
        recipientTier: number;
    }>;
    /**
     * Admin: Set manual override tier
     */
    setOverrideTier(userId: string, tier: number, adminId: string, reason: string): Promise<void>;
    /**
     * Admin: Clear manual override
     */
    clearOverride(userId: string, adminId: string): Promise<void>;
};
export default trustService;
