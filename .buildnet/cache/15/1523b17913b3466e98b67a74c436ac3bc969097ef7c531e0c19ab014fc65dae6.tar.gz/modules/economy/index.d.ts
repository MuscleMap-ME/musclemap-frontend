/**
 * Economy Module
 *
 * Handles credit balance management with proper transaction isolation
 * and race condition prevention using PostgreSQL's serializable transactions.
 */
interface CreditChargeRequest {
    userId: string;
    action: string;
    amount?: number;
    metadata?: Record<string, unknown>;
    idempotencyKey: string;
}
interface CreditChargeResult {
    success: boolean;
    ledgerEntryId?: string;
    newBalance?: number;
    error?: string;
}
export declare const economyService: {
    /**
     * Get user's current credit balance
     */
    getBalance(userId: string): Promise<number>;
    /**
     * Check if user can afford a charge
     */
    canCharge(userId: string, amount: number): Promise<boolean>;
    /**
     * Charge credits with proper transaction isolation
     *
     * Uses PostgreSQL's serializable isolation level for:
     * - Idempotency via unique constraint on idempotency_key
     * - Atomic balance update with version checking
     * - Automatic retry on serialization failure
     */
    charge(request: CreditChargeRequest): Promise<CreditChargeResult>;
    /**
     * Add credits to a user's balance (for purchases, rewards, etc.)
     */
    addCredits(userId: string, amount: number, action: string, metadata?: Record<string, unknown>, idempotencyKey?: string): Promise<CreditChargeResult>;
    /**
     * Get transaction history with pagination
     */
    getHistory(userId: string, limit?: number, offset?: number): Promise<{
        id: string;
        action: string;
        amount: number;
        balance_after: number;
        metadata: string | null;
        created_at: Date;
    }[]>;
    /**
     * Get total transaction count for pagination
     */
    getHistoryCount(userId: string): Promise<number>;
    /**
     * Initialize credit balance for new user
     */
    initializeBalance(userId: string, initialBalance?: number): Promise<void>;
    /**
     * Refund credits to a user (wrapper around addCredits with refund action)
     */
    refund(request: {
        userId: string;
        action: string;
        amount?: number;
        idempotencyKey: string;
        metadata?: Record<string, unknown>;
    }): Promise<CreditChargeResult>;
};
export { walletService } from './wallet.service';
export { earningService } from './earning.service';
export { storeService } from './store.service';
export { buddyService, BUDDY_SPECIES } from './buddy.service';
export { antiabuseService } from './antiabuse.service';
export { trainerService } from './trainer.service';
export { creditService, CreditReason, RefType } from './credit.service';
export { trustService } from './trust.service';
export { escrowService } from './escrow.service';
export { disputeService } from './dispute.service';
export { earnEventsService } from './earnEvents.service';
export { bonusEventsService } from './bonusEvents.service';
export { geoHangoutsService } from './geoHangouts.service';
export { paymentsService } from './payments.service';
export { socialSpendingService } from './socialSpending.service';
