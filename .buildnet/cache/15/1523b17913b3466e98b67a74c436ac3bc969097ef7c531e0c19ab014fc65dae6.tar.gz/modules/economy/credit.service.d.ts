/**
 * Enhanced Credit Service
 *
 * Handles the credit economy with:
 * - Atomic transactions with idempotency
 * - P2P credit transfers
 * - Rep-based credit awards (1 credit per rep)
 * - Redis caching for balance lookups
 * - Transaction history with audit trails
 */
export declare enum CreditReason {
    REP_COMPLETED = 1,
    DM_SENT = 2,
    AI_QUERY = 3,
    POST_CREATED = 4,
    AD_POSTED = 5,
    TRANSFER_SENT = 6,
    TRANSFER_RECEIVED = 7,
    ADMIN_ADJUSTMENT = 8,
    WORKOUT_COMPLETED = 9,
    PURCHASE = 10,
    SUBSCRIPTION_BONUS = 11,
    REFERRAL_BONUS = 12,
    MILESTONE_REWARD = 13
}
export declare enum RefType {
    REP_EVENT = 1,
    MESSAGE = 2,
    AI_REQUEST = 3,
    POST = 4,
    AD = 5,
    TRANSFER = 6,
    WORKOUT = 7,
    PURCHASE = 8,
    MILESTONE = 9
}
interface TransactionRequest {
    userId: string;
    delta: number;
    reason: CreditReason;
    refType?: RefType;
    refId?: string;
    idempotencyKey: string;
    metadata?: {
        ip?: string;
        userAgent?: string;
    };
}
interface TransactionResult {
    entryId: string;
    newBalance: number;
    wasDuplicate: boolean;
    version: number;
}
interface TransferRequest {
    senderId: string;
    recipientId: string;
    amount: number;
    note?: string;
}
interface TransferResult {
    transferId: string;
    senderNewBalance: number;
    recipientNewBalance: number;
}
export interface ChargeRequest {
    userId: string;
    action: string;
    amount?: number;
    metadata?: Record<string, unknown>;
    idempotencyKey: string;
}
export interface ChargeResult {
    success: boolean;
    ledgerEntryId?: string;
    newBalance?: number;
    error?: string;
}
export declare const creditService: {
    /**
     * Get user's current credit balance
     * Uses Redis cache with 60s TTL for performance
     */
    getBalance(userId: string): Promise<number>;
    /**
     * Get detailed balance info
     */
    getBalanceDetails(userId: string): Promise<{
        balance: number;
        totalEarned: number;
        totalSpent: number;
        version: number;
    }>;
    /**
     * Execute an atomic credit transaction using the database function
     */
    transact(request: TransactionRequest): Promise<TransactionResult>;
    /**
     * Transfer credits between users
     */
    transfer(request: TransferRequest): Promise<TransferResult>;
    /**
     * Award credits for completed reps
     * Awards 1 credit per rep completed
     */
    awardForReps(userId: string, repEventId: string, repCount: number): Promise<TransactionResult>;
    /**
     * Spend credits for an action
     */
    spend(userId: string, amount: number, reason: CreditReason, refType: RefType, refId: string, idempotencyKey: string): Promise<TransactionResult>;
    /**
     * Charge credits using the action-based system
     * Compatible with the original economy service interface
     */
    charge(request: ChargeRequest): Promise<ChargeResult>;
    /**
     * Add credits to a user's balance
     */
    addCredits(userId: string, amount: number, action: string, metadata?: Record<string, unknown>, idempotencyKey?: string): Promise<ChargeResult>;
    /**
     * Get transaction history with pagination
     */
    getHistory(userId: string, options?: {
        limit?: number;
        offset?: number;
        reason?: CreditReason;
    }): Promise<{
        transactions: Array<{
            id: string;
            action: string;
            amount: number;
            balanceAfter: number;
            reason?: CreditReason;
            refType?: RefType;
            refId?: string;
            metadata: Record<string, unknown> | null;
            createdAt: Date;
        }>;
        total: number;
    }>;
    /**
     * Initialize credit balance for new user
     */
    initializeBalance(userId: string, initialBalance?: number): Promise<void>;
    /**
     * Check if user can afford a charge
     */
    canAfford(userId: string, amount: number): Promise<boolean>;
};
export {};
