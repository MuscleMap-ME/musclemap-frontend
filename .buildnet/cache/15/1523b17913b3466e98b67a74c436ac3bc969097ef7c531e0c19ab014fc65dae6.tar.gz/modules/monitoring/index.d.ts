/**
 * Monitoring & Testing Module
 *
 * Comprehensive system health monitoring, API testing, user journey tracing,
 * and error tracking for the MuscleMap platform.
 */
export interface TestResult {
    id: string;
    name: string;
    category: string;
    status: 'pass' | 'fail' | 'skip' | 'error';
    duration: number;
    message?: string;
    details?: Record<string, unknown>;
    timestamp: Date;
}
export interface TestSuite {
    id: string;
    name: string;
    startedAt: Date;
    completedAt?: Date;
    totalTests: number;
    passed: number;
    failed: number;
    skipped: number;
    errors: number;
    results: TestResult[];
    environment: string;
}
export interface UserJourney {
    id: string;
    sessionId: string;
    userId?: string;
    startedAt: Date;
    endedAt?: Date;
    steps: JourneyStep[];
    errors: JourneyError[];
    metadata: Record<string, unknown>;
}
export interface JourneyStep {
    id: string;
    timestamp: Date;
    type: 'navigation' | 'action' | 'api_call' | 'render' | 'interaction';
    name: string;
    path?: string;
    duration?: number;
    details?: Record<string, unknown>;
    screenshot?: string;
}
export interface JourneyError {
    id: string;
    timestamp: Date;
    type: 'js_error' | 'api_error' | 'render_error' | 'network_error';
    message: string;
    stack?: string;
    componentStack?: string;
    context?: Record<string, unknown>;
}
export interface HealthCheck {
    name: string;
    status: 'healthy' | 'degraded' | 'unhealthy';
    latency?: number;
    message?: string;
    lastChecked: Date;
}
export interface SystemHealth {
    overall: 'healthy' | 'degraded' | 'unhealthy';
    timestamp: Date;
    uptime: number;
    checks: HealthCheck[];
    metrics: {
        requestsPerMinute: number;
        averageResponseTime: number;
        errorRate: number;
        activeUsers: number;
    };
}
interface APITest {
    name: string;
    category: string;
    query: string;
    variables?: Record<string, unknown>;
    requiresAuth?: boolean;
    expectedFields?: string[];
    validator?: (data: unknown) => boolean;
}
export declare function runAPITests(options: {
    baseUrl: string;
    authToken?: string;
    categories?: string[];
    verbose?: boolean;
}): Promise<TestSuite>;
export declare function startJourney(sessionId: string, userId?: string, metadata?: Record<string, unknown>): UserJourney;
export declare function addJourneyStep(sessionId: string, step: Omit<JourneyStep, 'id' | 'timestamp'>): JourneyStep | null;
export declare function addJourneyError(sessionId: string, error: Omit<JourneyError, 'id' | 'timestamp'>): JourneyError | null;
export declare function endJourney(sessionId: string): Promise<UserJourney | null>;
export declare function getActiveJourney(sessionId: string): UserJourney | null;
interface TrackedError {
    id: string;
    type: string;
    message: string;
    stack?: string;
    userId?: string;
    sessionId?: string;
    path?: string;
    userAgent?: string;
    timestamp: Date;
    context?: Record<string, unknown>;
    resolved: boolean;
    occurrences: number;
}
export declare function trackError(error: Omit<TrackedError, 'id' | 'timestamp' | 'resolved' | 'occurrences'>): Promise<TrackedError>;
export declare function getRecentErrors(limit?: number): Promise<TrackedError[]>;
export declare function resolveError(errorId: string): Promise<boolean>;
export declare function getSystemHealth(): Promise<SystemHealth>;
export declare function getTestHistory(limit?: number): Promise<TestSuite[]>;
export declare function getJourneyHistory(options: {
    userId?: string;
    limit?: number;
    hasErrors?: boolean;
}): Promise<UserJourney[]>;
export declare function getDashboardStats(): Promise<{
    testsRun24h: number;
    testPassRate: number;
    journeysTracked24h: number;
    journeysWithErrors: number;
    unresolvedErrors: number;
    topErrors: Array<{
        message: string;
        occurrences: number;
    }>;
    recentFailedTests: TestResult[];
}>;
export declare const monitoringService: {
    runAPITests: typeof runAPITests;
    getTestHistory: typeof getTestHistory;
    API_TESTS: APITest[];
    startJourney: typeof startJourney;
    addJourneyStep: typeof addJourneyStep;
    addJourneyError: typeof addJourneyError;
    endJourney: typeof endJourney;
    getActiveJourney: typeof getActiveJourney;
    getJourneyHistory: typeof getJourneyHistory;
    trackError: typeof trackError;
    getRecentErrors: typeof getRecentErrors;
    resolveError: typeof resolveError;
    getSystemHealth: typeof getSystemHealth;
    getDashboardStats: typeof getDashboardStats;
};
export default monitoringService;
