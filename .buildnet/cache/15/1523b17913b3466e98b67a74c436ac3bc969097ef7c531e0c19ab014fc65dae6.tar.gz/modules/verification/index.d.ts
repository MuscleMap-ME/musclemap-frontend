/**
 * Achievement Verification Module
 *
 * Handles video verification for elite achievements:
 * - Video proof submissions
 * - Witness attestations
 * - Verification status tracking
 * - Achievement granting upon verification
 */
export type VerificationStatus = 'pending_witness' | 'verified' | 'rejected' | 'expired';
export type WitnessStatus = 'pending' | 'confirmed' | 'declined';
export interface AchievementVerification {
    id: string;
    userId: string;
    achievementId: string;
    achievementKey?: string;
    achievementName?: string;
    achievementTier?: string;
    videoAssetId?: string;
    videoUrl?: string;
    thumbnailUrl?: string;
    videoDurationSeconds?: number;
    status: VerificationStatus;
    notes?: string;
    rejectionReason?: string;
    submittedAt: Date;
    verifiedAt?: Date;
    expiresAt: Date;
    createdAt: Date;
    updatedAt: Date;
    username?: string;
    displayName?: string;
    avatarUrl?: string;
    witness?: WitnessInfo;
}
export interface WitnessInfo {
    id: string;
    witnessUserId: string;
    witnessUsername?: string;
    witnessDisplayName?: string;
    witnessAvatarUrl?: string;
    attestationText?: string;
    relationship?: string;
    locationDescription?: string;
    status: WitnessStatus;
    isPublic: boolean;
    requestedAt: Date;
    respondedAt?: Date;
}
export interface SubmitVerificationParams {
    userId: string;
    achievementId: string;
    witnessUserId: string;
    notes?: string;
    videoBuffer?: Buffer;
    videoStream?: NodeJS.ReadableStream;
    originalFilename?: string;
    fileSizeBytes?: number;
}
export interface WitnessAttestationParams {
    verificationId: string;
    witnessUserId: string;
    confirm: boolean;
    attestationText?: string;
    relationship?: string;
    locationDescription?: string;
    isPublic?: boolean;
}
export declare const verificationService: {
    /**
     * Check if an achievement requires verification
     */
    requiresVerification(achievementId: string): Promise<boolean>;
    /**
     * Check if an achievement requires verification by key
     */
    requiresVerificationByKey(achievementKey: string): Promise<boolean>;
    /**
     * Get achievement definition with tier info
     */
    getAchievementWithTier(achievementId: string): Promise<{
        id: string;
        key: string;
        name: string;
        tier: string;
        requires_verification: boolean;
        rarity: string;
        points: number;
    } | undefined>;
    /**
     * Submit a verification request with video proof
     */
    submitVerification(params: SubmitVerificationParams): Promise<AchievementVerification>;
    /**
     * Get a verification by ID
     */
    getVerification(verificationId: string): Promise<AchievementVerification>;
    /**
     * Get witness info for a verification
     */
    getWitnessInfo(verificationId: string): Promise<WitnessInfo | undefined>;
    /**
     * Get user's verifications
     */
    getUserVerifications(userId: string, options?: {
        status?: VerificationStatus;
        limit?: number;
        offset?: number;
    }): Promise<{
        verifications: AchievementVerification[];
        total: number;
    }>;
    /**
     * Get pending witness requests for a user
     */
    getWitnessRequests(witnessUserId: string, options?: {
        status?: WitnessStatus;
        limit?: number;
        offset?: number;
    }): Promise<{
        requests: AchievementVerification[];
        total: number;
    }>;
    /**
     * Submit witness attestation
     */
    submitWitnessAttestation(params: WitnessAttestationParams): Promise<AchievementVerification>;
    /**
     * Cancel a pending verification
     */
    cancelVerification(verificationId: string, userId: string): Promise<void>;
    /**
     * Expire old pending verifications (run as cron job)
     */
    expireOldVerifications(): Promise<number>;
    /**
     * Get achievements that require verification
     */
    getVerificationRequiredAchievements(): Promise<Array<{
        id: string;
        key: string;
        name: string;
        description?: string;
        tier: string;
        rarity: string;
        points: number;
    }>>;
    /**
     * Check if user can submit verification for an achievement
     */
    canSubmitVerification(userId: string, achievementId: string): Promise<{
        canSubmit: boolean;
        reason?: string;
    }>;
};
export default verificationService;
