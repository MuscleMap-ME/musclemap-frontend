"use strict";
/**
 * Achievement Verification Module
 *
 * Handles video verification for elite achievements:
 * - Video proof submissions
 * - Witness attestations
 * - Verification status tracking
 * - Achievement granting upon verification
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.verificationService = void 0;
const crypto_1 = __importDefault(require("crypto"));
const promises_1 = __importDefault(require("fs/promises"));
const path_1 = __importDefault(require("path"));
const promises_2 = require("stream/promises");
const fs_1 = require("fs");
const client_1 = require("../../db/client");
const errors_1 = require("../../lib/errors");
const logger_1 = require("../../lib/logger");
const cache_service_1 = __importStar(require("../../lib/cache.service"));
const video_processing_service_1 = require("../../services/video-processing.service");
const notification_service_1 = require("../../services/notification.service");
const log = logger_1.loggers.core;
// Constants
const UPLOAD_BASE_DIR = process.env.UPLOAD_DIR || '/var/www/musclemap.me/uploads';
const VERIFICATION_DIR = 'verifications';
const MAX_VIDEO_SIZE_BYTES = 50 * 1024 * 1024; // 50MB
const _MAX_VIDEO_DURATION_SECONDS = 60;
const MAX_PENDING_VERIFICATIONS = 3;
const VERIFICATION_EXPIRY_DAYS = 30;
const MIN_WITNESS_ACCOUNT_AGE_DAYS = 30;
// Service
exports.verificationService = {
    /**
     * Check if an achievement requires verification
     */
    async requiresVerification(achievementId) {
        const result = await (0, client_1.queryOne)('SELECT requires_verification FROM achievement_definitions WHERE id = $1', [achievementId]);
        return result?.requires_verification ?? false;
    },
    /**
     * Check if an achievement requires verification by key
     */
    async requiresVerificationByKey(achievementKey) {
        const result = await (0, client_1.queryOne)('SELECT requires_verification FROM achievement_definitions WHERE key = $1', [achievementKey]);
        return result?.requires_verification ?? false;
    },
    /**
     * Get achievement definition with tier info
     */
    async getAchievementWithTier(achievementId) {
        return (0, client_1.queryOne)('SELECT id, key, name, tier, requires_verification, rarity, points FROM achievement_definitions WHERE id = $1', [achievementId]);
    },
    /**
     * Submit a verification request with video proof
     */
    async submitVerification(params) {
        const { userId, achievementId, witnessUserId, notes, videoBuffer, videoStream, originalFilename: _originalFilename, fileSizeBytes } = params;
        // Validate achievement exists and requires verification
        const achievement = await this.getAchievementWithTier(achievementId);
        if (!achievement) {
            throw new errors_1.NotFoundError('Achievement not found');
        }
        // Check if user already has this achievement
        const existingAchievement = await (0, client_1.queryOne)('SELECT id FROM achievement_events WHERE user_id = $1 AND achievement_id = $2', [userId, achievementId]);
        if (existingAchievement) {
            throw new errors_1.ValidationError('You already have this achievement');
        }
        // Check pending verification limit
        const pendingCount = await (0, client_1.queryOne)(`SELECT COUNT(*) as count FROM achievement_verifications
       WHERE user_id = $1 AND status = 'pending_witness'`, [userId]);
        if (parseInt(pendingCount?.count || '0') >= MAX_PENDING_VERIFICATIONS) {
            throw new errors_1.ValidationError(`You can only have ${MAX_PENDING_VERIFICATIONS} pending verifications at a time`);
        }
        // Check for existing pending verification for this achievement
        const existingVerification = await (0, client_1.queryOne)(`SELECT id FROM achievement_verifications
       WHERE user_id = $1 AND achievement_id = $2 AND status = 'pending_witness'`, [userId, achievementId]);
        if (existingVerification) {
            throw new errors_1.ValidationError('You already have a pending verification for this achievement');
        }
        // Validate witness
        if (witnessUserId === userId) {
            throw new errors_1.ValidationError('You cannot be your own witness');
        }
        const witness = await (0, client_1.queryOne)('SELECT id, created_at, email_verified FROM users WHERE id = $1', [witnessUserId]);
        if (!witness) {
            throw new errors_1.NotFoundError('Witness user not found');
        }
        // Check witness account age
        const accountAgeDays = Math.floor((Date.now() - new Date(witness.created_at).getTime()) / (1000 * 60 * 60 * 24));
        if (accountAgeDays < MIN_WITNESS_ACCOUNT_AGE_DAYS) {
            throw new errors_1.ValidationError(`Witness must have an account at least ${MIN_WITNESS_ACCOUNT_AGE_DAYS} days old`);
        }
        // Generate verification ID
        const verificationId = 'av_' + crypto_1.default.randomBytes(16).toString('hex');
        // Handle video upload
        let videoUrl;
        let thumbnailUrl;
        if (videoBuffer || videoStream) {
            // Validate file size
            if (fileSizeBytes && fileSizeBytes > MAX_VIDEO_SIZE_BYTES) {
                throw new errors_1.ValidationError(`Video must be less than ${MAX_VIDEO_SIZE_BYTES / (1024 * 1024)}MB`);
            }
            // Create upload directory
            const uploadDir = path_1.default.join(UPLOAD_BASE_DIR, VERIFICATION_DIR, userId, verificationId);
            await promises_1.default.mkdir(uploadDir, { recursive: true });
            const videoPath = path_1.default.join(uploadDir, 'video.mp4');
            if (videoBuffer) {
                await promises_1.default.writeFile(videoPath, videoBuffer);
            }
            else if (videoStream) {
                await (0, promises_2.pipeline)(videoStream, (0, fs_1.createWriteStream)(videoPath));
            }
            // Set URLs (relative to uploads directory)
            videoUrl = `/uploads/${VERIFICATION_DIR}/${userId}/${verificationId}/video.mp4`;
            thumbnailUrl = `/uploads/${VERIFICATION_DIR}/${userId}/${verificationId}/thumbnail.jpg`;
            // Generate thumbnail with ffmpeg
            const thumbnailPath = path_1.default.join(uploadDir, 'thumbnail.jpg');
            const thumbnailResult = await video_processing_service_1.VideoProcessingService.generateThumbnail(videoPath, thumbnailPath, { quality: 5, timestamp: 1, scale: { width: 640 } });
            if (!thumbnailResult.success) {
                log.warn(`Failed to generate thumbnail for verification ${verificationId}: ${thumbnailResult.error}`);
                // Continue without thumbnail - it's not critical
                thumbnailUrl = undefined;
            }
            else {
                log.info(`Thumbnail generated for verification ${verificationId}`);
            }
        }
        // Create verification record
        const expiresAt = new Date();
        expiresAt.setDate(expiresAt.getDate() + VERIFICATION_EXPIRY_DAYS);
        await (0, client_1.transaction)(async (client) => {
            // Insert verification
            await client.query(`INSERT INTO achievement_verifications
         (id, user_id, achievement_id, video_url, thumbnail_url, status, notes, expires_at)
         VALUES ($1, $2, $3, $4, $5, 'pending_witness', $6, $7)`, [verificationId, userId, achievementId, videoUrl, thumbnailUrl, notes, expiresAt]);
            // Create witness request
            await client.query(`INSERT INTO achievement_witnesses
         (verification_id, witness_user_id, status)
         VALUES ($1, $2, 'pending')`, [verificationId, witnessUserId]);
        });
        log.info(`Verification ${verificationId} created for user ${userId}, achievement ${achievementId}`);
        // Send notification to witness
        try {
            await notification_service_1.NotificationService.sendVerificationWitnessRequest(witnessUserId, userId, verificationId, achievement.name);
            log.info(`Witness notification sent for verification ${verificationId}`);
        }
        catch (err) {
            log.warn(`Failed to send witness notification for ${verificationId}: ${err}`);
            // Don't fail the verification submission if notification fails
        }
        return this.getVerification(verificationId);
    },
    /**
     * Get a verification by ID
     */
    async getVerification(verificationId) {
        const row = await (0, client_1.queryOne)(`SELECT v.*,
              u.username, u.display_name, u.avatar_url,
              a.key as achievement_key, a.name as achievement_name, a.tier as achievement_tier
       FROM achievement_verifications v
       JOIN users u ON u.id = v.user_id
       JOIN achievement_definitions a ON a.id = v.achievement_id
       WHERE v.id = $1`, [verificationId]);
        if (!row) {
            throw new errors_1.NotFoundError('Verification not found');
        }
        // Get witness info
        const witness = await this.getWitnessInfo(verificationId);
        return {
            id: row.id,
            userId: row.user_id,
            achievementId: row.achievement_id,
            achievementKey: row.achievement_key,
            achievementName: row.achievement_name,
            achievementTier: row.achievement_tier,
            videoAssetId: row.video_asset_id ?? undefined,
            videoUrl: row.video_url ?? undefined,
            thumbnailUrl: row.thumbnail_url ?? undefined,
            videoDurationSeconds: row.video_duration_seconds ?? undefined,
            status: row.status,
            notes: row.notes ?? undefined,
            rejectionReason: row.rejection_reason ?? undefined,
            submittedAt: row.submitted_at,
            verifiedAt: row.verified_at ?? undefined,
            expiresAt: row.expires_at,
            createdAt: row.created_at,
            updatedAt: row.updated_at,
            username: row.username,
            displayName: row.display_name ?? undefined,
            avatarUrl: row.avatar_url ?? undefined,
            witness,
        };
    },
    /**
     * Get witness info for a verification
     */
    async getWitnessInfo(verificationId) {
        const row = await (0, client_1.queryOne)(`SELECT w.*,
              u.username as witness_username,
              u.display_name as witness_display_name,
              u.avatar_url as witness_avatar_url
       FROM achievement_witnesses w
       JOIN users u ON u.id = w.witness_user_id
       WHERE w.verification_id = $1`, [verificationId]);
        if (!row)
            return undefined;
        return {
            id: row.id,
            witnessUserId: row.witness_user_id,
            witnessUsername: row.witness_username,
            witnessDisplayName: row.witness_display_name ?? undefined,
            witnessAvatarUrl: row.witness_avatar_url ?? undefined,
            attestationText: row.attestation_text ?? undefined,
            relationship: row.relationship ?? undefined,
            locationDescription: row.location_description ?? undefined,
            status: row.status,
            isPublic: row.is_public,
            requestedAt: row.requested_at,
            respondedAt: row.responded_at ?? undefined,
        };
    },
    /**
     * Get user's verifications
     */
    async getUserVerifications(userId, options = {}) {
        const { status, limit = 20, offset = 0 } = options;
        let whereClause = 'v.user_id = $1';
        const params = [userId];
        if (status) {
            whereClause += ` AND v.status = $${params.length + 1}`;
            params.push(status);
        }
        const countResult = await (0, client_1.queryOne)(`SELECT COUNT(*) as count FROM achievement_verifications v WHERE ${whereClause}`, params);
        const total = parseInt(countResult?.count || '0');
        const rows = await (0, client_1.queryAll)(`SELECT v.id, v.user_id, v.achievement_id, v.video_url, v.thumbnail_url,
              v.status, v.notes, v.submitted_at, v.verified_at, v.expires_at,
              v.created_at, v.updated_at,
              a.key as achievement_key, a.name as achievement_name, a.tier as achievement_tier
       FROM achievement_verifications v
       JOIN achievement_definitions a ON a.id = v.achievement_id
       WHERE ${whereClause}
       ORDER BY v.submitted_at DESC
       LIMIT $${params.length + 1} OFFSET $${params.length + 2}`, [...params, limit, offset]);
        const verifications = await Promise.all(rows.map(async (row) => {
            const witness = await this.getWitnessInfo(row.id);
            return {
                id: row.id,
                userId: row.user_id,
                achievementId: row.achievement_id,
                achievementKey: row.achievement_key,
                achievementName: row.achievement_name,
                achievementTier: row.achievement_tier,
                videoUrl: row.video_url ?? undefined,
                thumbnailUrl: row.thumbnail_url ?? undefined,
                status: row.status,
                notes: row.notes ?? undefined,
                submittedAt: row.submitted_at,
                verifiedAt: row.verified_at ?? undefined,
                expiresAt: row.expires_at,
                createdAt: row.created_at,
                updatedAt: row.updated_at,
                witness,
            };
        }));
        return { verifications, total };
    },
    /**
     * Get pending witness requests for a user
     */
    async getWitnessRequests(witnessUserId, options = {}) {
        const { status = 'pending', limit = 20, offset = 0 } = options;
        let whereClause = 'w.witness_user_id = $1';
        const params = [witnessUserId];
        if (status) {
            whereClause += ` AND w.status = $${params.length + 1}`;
            params.push(status);
        }
        const countResult = await (0, client_1.queryOne)(`SELECT COUNT(*) as count
       FROM achievement_witnesses w
       JOIN achievement_verifications v ON v.id = w.verification_id
       WHERE ${whereClause}`, params);
        const total = parseInt(countResult?.count || '0');
        const rows = await (0, client_1.queryAll)(`SELECT w.verification_id
       FROM achievement_witnesses w
       JOIN achievement_verifications v ON v.id = w.verification_id
       WHERE ${whereClause}
       ORDER BY w.requested_at DESC
       LIMIT $${params.length + 1} OFFSET $${params.length + 2}`, [...params, limit, offset]);
        const requests = await Promise.all(rows.map((row) => this.getVerification(row.verification_id)));
        return { requests, total };
    },
    /**
     * Submit witness attestation
     */
    async submitWitnessAttestation(params) {
        const { verificationId, witnessUserId, confirm, attestationText, relationship, locationDescription, isPublic = true, } = params;
        // Get the witness record
        const witnessRecord = await (0, client_1.queryOne)(`SELECT * FROM achievement_witnesses WHERE verification_id = $1`, [verificationId]);
        if (!witnessRecord) {
            throw new errors_1.NotFoundError('Witness request not found');
        }
        if (witnessRecord.witness_user_id !== witnessUserId) {
            throw new errors_1.ForbiddenError('You are not the requested witness for this verification');
        }
        if (witnessRecord.status !== 'pending') {
            throw new errors_1.ValidationError('This witness request has already been responded to');
        }
        // Get verification to check status
        const verification = await (0, client_1.queryOne)(`SELECT v.status, v.user_id, v.achievement_id, a.name as achievement_name
       FROM achievement_verifications v
       JOIN achievement_definitions a ON a.id = v.achievement_id
       WHERE v.id = $1`, [verificationId]);
        if (!verification) {
            throw new errors_1.NotFoundError('Verification not found');
        }
        if (verification.status !== 'pending_witness') {
            throw new errors_1.ValidationError('This verification is no longer pending');
        }
        if (confirm && !attestationText) {
            throw new errors_1.ValidationError('Attestation text is required when confirming');
        }
        // Get witness username for the achievement event
        const witnessUser = await (0, client_1.queryOne)('SELECT username FROM users WHERE id = $1', [witnessUserId]);
        await (0, client_1.transaction)(async (client) => {
            // Update witness record
            await client.query(`UPDATE achievement_witnesses
         SET status = $1,
             attestation_text = $2,
             relationship = $3,
             location_description = $4,
             is_public = $5,
             responded_at = NOW()
         WHERE verification_id = $6`, [
                confirm ? 'confirmed' : 'declined',
                attestationText,
                relationship,
                locationDescription,
                isPublic,
                verificationId,
            ]);
            if (confirm) {
                // Update verification status
                await client.query(`UPDATE achievement_verifications
           SET status = 'verified', verified_at = NOW()
           WHERE id = $1`, [verificationId]);
                // Grant the achievement
                const achievementId = 'ae_' + crypto_1.default.randomBytes(16).toString('hex');
                await client.query(`INSERT INTO achievement_events
           (id, user_id, achievement_id, verification_id, is_verified, witness_username, earned_at)
           VALUES ($1, $2, $3, $4, TRUE, $5, NOW())`, [achievementId, verification.user_id, verification.achievement_id, verificationId, witnessUser?.username]);
                // Update user achievement points
                await client.query(`UPDATE users
           SET achievement_points = achievement_points + (
             SELECT points FROM achievement_definitions WHERE id = $1
           )
           WHERE id = $2`, [verification.achievement_id, verification.user_id]);
                log.info(`Achievement ${verification.achievement_id} verified and granted to user ${verification.user_id}`);
            }
            else {
                // Mark as rejected
                await client.query(`UPDATE achievement_verifications
           SET status = 'rejected', rejection_reason = 'Witness declined'
           WHERE id = $1`, [verificationId]);
                log.info(`Verification ${verificationId} rejected by witness`);
            }
        });
        // Send notification to user about result
        try {
            if (confirm) {
                await notification_service_1.NotificationService.sendVerificationConfirmed(verification.user_id, witnessUserId, verificationId, verification.achievement_name);
            }
            else {
                await notification_service_1.NotificationService.sendVerificationRejected(verification.user_id, witnessUserId, verificationId, verification.achievement_name);
            }
            log.info(`Result notification sent for verification ${verificationId}`);
        }
        catch (err) {
            log.warn(`Failed to send result notification for ${verificationId}: ${err}`);
            // Don't fail the attestation if notification fails
        }
        return this.getVerification(verificationId);
    },
    /**
     * Cancel a pending verification
     */
    async cancelVerification(verificationId, userId) {
        const verification = await (0, client_1.queryOne)('SELECT user_id, status FROM achievement_verifications WHERE id = $1', [verificationId]);
        if (!verification) {
            throw new errors_1.NotFoundError('Verification not found');
        }
        if (verification.user_id !== userId) {
            throw new errors_1.ForbiddenError('You can only cancel your own verifications');
        }
        if (verification.status !== 'pending_witness') {
            throw new errors_1.ValidationError('Only pending verifications can be cancelled');
        }
        await (0, client_1.query)('DELETE FROM achievement_verifications WHERE id = $1', [verificationId]);
        // Clean up video files
        const uploadDir = path_1.default.join(UPLOAD_BASE_DIR, VERIFICATION_DIR, userId, verificationId);
        try {
            await promises_1.default.rm(uploadDir, { recursive: true, force: true });
        }
        catch {
            // Ignore cleanup errors
        }
        log.info(`Verification ${verificationId} cancelled by user ${userId}`);
    },
    /**
     * Expire old pending verifications (run as cron job)
     */
    async expireOldVerifications() {
        const result = await (0, client_1.query)(`UPDATE achievement_verifications
       SET status = 'expired'
       WHERE status = 'pending_witness' AND expires_at < NOW()
       RETURNING id`);
        const expiredCount = result.rowCount || 0;
        if (expiredCount > 0) {
            log.info(`Expired ${expiredCount} old verifications`);
        }
        return expiredCount;
    },
    /**
     * Get achievements that require verification
     */
    async getVerificationRequiredAchievements() {
        const cacheKey = `${cache_service_1.CACHE_PREFIX.ACHIEVEMENT_DEFS}:verification_required`;
        return cache_service_1.default.getOrSet(cacheKey, cache_service_1.CACHE_TTL.ACHIEVEMENT_DEFINITIONS, async () => {
            const rows = await (0, client_1.queryAll)(`SELECT id, key, name, description, tier, rarity, points
         FROM achievement_definitions
         WHERE requires_verification = TRUE AND enabled = TRUE
         ORDER BY tier DESC, points DESC`);
            return rows.map((r) => ({
                id: r.id,
                key: r.key,
                name: r.name,
                description: r.description ?? undefined,
                tier: r.tier,
                rarity: r.rarity,
                points: r.points,
            }));
        });
    },
    /**
     * Check if user can submit verification for an achievement
     */
    async canSubmitVerification(userId, achievementId) {
        // Check if achievement exists
        const achievement = await this.getAchievementWithTier(achievementId);
        if (!achievement) {
            return { canSubmit: false, reason: 'Achievement not found' };
        }
        // Check if user already has this achievement
        const existingAchievement = await (0, client_1.queryOne)('SELECT id FROM achievement_events WHERE user_id = $1 AND achievement_id = $2', [userId, achievementId]);
        if (existingAchievement) {
            return { canSubmit: false, reason: 'You already have this achievement' };
        }
        // Check pending verification limit
        const pendingCount = await (0, client_1.queryOne)(`SELECT COUNT(*) as count FROM achievement_verifications
       WHERE user_id = $1 AND status = 'pending_witness'`, [userId]);
        if (parseInt(pendingCount?.count || '0') >= MAX_PENDING_VERIFICATIONS) {
            return {
                canSubmit: false,
                reason: `You can only have ${MAX_PENDING_VERIFICATIONS} pending verifications at a time`,
            };
        }
        // Check for existing pending verification
        const existingVerification = await (0, client_1.queryOne)(`SELECT id FROM achievement_verifications
       WHERE user_id = $1 AND achievement_id = $2 AND status = 'pending_witness'`, [userId, achievementId]);
        if (existingVerification) {
            return { canSubmit: false, reason: 'You already have a pending verification for this achievement' };
        }
        return { canSubmit: true };
    },
};
exports.default = exports.verificationService;
//# sourceMappingURL=index.js.map