/**
 * Career Readiness Module
 *
 * Provides career physical standards tracking, readiness scoring,
 * and team readiness dashboards for first responders, military, and law enforcement.
 */
export interface CareerGoal {
    id: string;
    userId: string;
    ptTestId: string;
    targetDate: string | null;
    priority: 'primary' | 'secondary';
    status: 'active' | 'achieved' | 'abandoned';
    agencyName: string | null;
    notes: string | null;
    createdAt: string;
    updatedAt: string;
    achievedAt: string | null;
}
export interface CareerGoalWithTest extends CareerGoal {
    testName: string;
    testDescription: string | null;
    institution: string | null;
    category: string | null;
    icon: string | null;
}
export interface ReadinessScore {
    goalId: string;
    readinessScore: number | null;
    status: 'ready' | 'at_risk' | 'not_ready' | 'no_data';
    eventsPassed: number;
    eventsTotal: number;
    weakEvents: string[];
    lastAssessmentAt: string | null;
}
export interface PTTestWithCareer {
    id: string;
    name: string;
    description: string | null;
    institution: string | null;
    category: string | null;
    components: unknown[];
    scoringMethod: string;
    maxScore: number | null;
    passingScore: number | null;
    recertificationMonths: number | null;
    exerciseMappings: Record<string, string[]>;
    tips: Array<{
        event: string;
        tip: string;
    }>;
    icon: string | null;
    active: boolean;
}
export interface TeamReadinessConfig {
    id: string;
    hangoutId: string;
    enabled: boolean;
    ptTestId: string | null;
    requireOptIn: boolean;
    visibleTo: string[];
    showIndividualScores: boolean;
    showAggregateOnly: boolean;
}
export interface TeamMemberReadiness {
    userId: string;
    username: string;
    displayName: string | null;
    readinessScore: number | null;
    status: 'ready' | 'at_risk' | 'not_ready' | 'no_data';
    lastAssessmentAt: string | null;
    weakEvents: string[];
}
export interface TeamReadinessSummary {
    hangoutId: string;
    ptTestId: string | null;
    membersTotal: number;
    membersOptedIn: number;
    membersReady: number;
    membersAtRisk: number;
    membersNotReady: number;
    averageReadiness: number | null;
    members: TeamMemberReadiness[];
    weakAreas: Array<{
        eventId: string;
        membersFailing: number;
    }>;
}
export interface RecertificationSchedule {
    id: string;
    userId: string;
    goalId: string;
    lastCertifiedAt: string | null;
    nextDueAt: string;
    reminderDays: number[];
    status: 'active' | 'completed' | 'overdue';
}
/**
 * Get all PT tests with career-specific fields
 */
export declare function getCareerStandards(options?: {
    category?: string;
    activeOnly?: boolean;
}): Promise<PTTestWithCareer[]>;
/**
 * Get a single PT test by ID
 */
export declare function getCareerStandard(testId: string): Promise<PTTestWithCareer | null>;
/**
 * Get categories with test counts
 */
export declare function getCareerCategories(): Promise<Array<{
    category: string;
    count: number;
    icon: string;
}>>;
/**
 * Get user's career goals
 */
export declare function getUserCareerGoals(userId: string): Promise<CareerGoalWithTest[]>;
/**
 * Create a career goal
 */
export declare function createCareerGoal(userId: string, data: {
    ptTestId: string;
    targetDate?: string;
    priority?: 'primary' | 'secondary';
    agencyName?: string;
    notes?: string;
}): Promise<CareerGoal>;
/**
 * Update a career goal
 */
export declare function updateCareerGoal(userId: string, goalId: string, data: {
    targetDate?: string | null;
    priority?: 'primary' | 'secondary';
    status?: 'active' | 'achieved' | 'abandoned';
    agencyName?: string | null;
    notes?: string | null;
}): Promise<CareerGoal | null>;
/**
 * Delete a career goal
 */
export declare function deleteCareerGoal(userId: string, goalId: string): Promise<boolean>;
/**
 * Calculate readiness score for a goal based on latest PT test results
 */
export declare function calculateReadiness(userId: string, goalId: string): Promise<ReadinessScore>;
/**
 * Get cached readiness or calculate fresh
 */
export declare function getReadiness(userId: string, goalId: string): Promise<ReadinessScore>;
/**
 * Get readiness for all user goals
 */
export declare function getAllReadiness(userId: string): Promise<Array<ReadinessScore & {
    goal: CareerGoalWithTest;
}>>;
/**
 * Get or create team readiness config for a hangout
 */
export declare function getTeamReadinessConfig(hangoutId: string): Promise<TeamReadinessConfig | null>;
/**
 * Enable team readiness for a hangout
 */
export declare function enableTeamReadiness(hangoutId: string, ptTestId: string, options?: {
    requireOptIn?: boolean;
    visibleTo?: string[];
    showIndividualScores?: boolean;
}): Promise<TeamReadinessConfig>;
/**
 * Opt in/out of team readiness sharing
 */
export declare function setTeamReadinessOptIn(hangoutId: string, userId: string, optIn: boolean, options?: {
    shareScore?: boolean;
    shareAssessmentDates?: boolean;
    shareWeakEvents?: boolean;
}): Promise<void>;
/**
 * Get team readiness summary
 */
export declare function getTeamReadiness(hangoutId: string): Promise<TeamReadinessSummary | null>;
/**
 * Set recertification schedule for a goal
 */
export declare function setRecertificationSchedule(userId: string, goalId: string, data: {
    lastCertifiedAt?: string;
    nextDueAt: string;
    reminderDays?: number[];
}): Promise<RecertificationSchedule>;
/**
 * Get user's recertification schedules
 */
export declare function getRecertificationSchedules(userId: string): Promise<RecertificationSchedule[]>;
/**
 * Get exercises that target weak events for a goal
 */
export declare function getExercisesForWeakEvents(goalId: string, userId: string): Promise<Array<{
    exerciseId: string;
    exerciseName: string;
    targetEvents: string[];
}>>;
export declare const careerService: {
    getCareerStandards: typeof getCareerStandards;
    getCareerStandard: typeof getCareerStandard;
    getCareerCategories: typeof getCareerCategories;
    getUserCareerGoals: typeof getUserCareerGoals;
    createCareerGoal: typeof createCareerGoal;
    updateCareerGoal: typeof updateCareerGoal;
    deleteCareerGoal: typeof deleteCareerGoal;
    calculateReadiness: typeof calculateReadiness;
    getReadiness: typeof getReadiness;
    getAllReadiness: typeof getAllReadiness;
    getTeamReadinessConfig: typeof getTeamReadinessConfig;
    enableTeamReadiness: typeof enableTeamReadiness;
    setTeamReadinessOptIn: typeof setTeamReadinessOptIn;
    getTeamReadiness: typeof getTeamReadiness;
    setRecertificationSchedule: typeof setRecertificationSchedule;
    getRecertificationSchedules: typeof getRecertificationSchedules;
    getExercisesForWeakEvents: typeof getExercisesForWeakEvents;
};
export default careerService;
