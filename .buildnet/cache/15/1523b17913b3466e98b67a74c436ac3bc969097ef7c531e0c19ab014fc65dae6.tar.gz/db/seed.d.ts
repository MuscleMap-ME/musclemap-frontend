/**
 * Database Seed Script
 *
 * Run with: npx tsx src/db/seed.ts
 */
/**
 * Seed the database with initial data
 */
export declare function seedDatabase(): Promise<void>;
