/**
 * Database Schema (PostgreSQL)
 */
export declare function initializeSchema(): Promise<void>;
export declare function seedCreditActions(): Promise<void>;
