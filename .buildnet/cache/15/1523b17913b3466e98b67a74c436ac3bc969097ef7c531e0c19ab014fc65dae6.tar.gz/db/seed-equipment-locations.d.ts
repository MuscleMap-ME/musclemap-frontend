/**
 * Equipment and Location Mappings for Exercises
 *
 * This file contains equipment requirements and location appropriateness
 * for each exercise in the database, used by the prescription constraint solver.
 */
export declare const EQUIPMENT: {
    readonly barbell: "Barbell";
    readonly ez_bar: "EZ Curl Bar";
    readonly pullup_bar: "Pull-up Bar";
    readonly dip_bars: "Dip Bars/Station";
    readonly dumbbells: "Dumbbells";
    readonly kettlebell: "Kettlebell";
    readonly plates: "Weight Plates";
    readonly cable_machine: "Cable Machine";
    readonly lat_pulldown: "Lat Pulldown Machine";
    readonly leg_press: "Leg Press";
    readonly smith_machine: "Smith Machine";
    readonly leg_curl_machine: "Leg Curl Machine";
    readonly leg_extension_machine: "Leg Extension Machine";
    readonly preacher_bench: "Preacher Bench";
    readonly flat_bench: "Flat Bench";
    readonly adjustable_bench: "Adjustable Bench";
    readonly squat_rack: "Squat Rack/Power Cage";
    readonly bands: "Resistance Bands";
    readonly trx: "TRX/Suspension Trainer";
    readonly ab_wheel: "Ab Wheel";
    readonly jump_rope: "Jump Rope";
    readonly yoga_mat: "Yoga Mat";
    readonly treadmill: "Treadmill";
    readonly bike: "Stationary Bike";
    readonly rower: "Rowing Machine";
};
export type EquipmentId = keyof typeof EQUIPMENT;
export type LocationId = 'gym' | 'home' | 'park' | 'hotel' | 'office' | 'travel';
export type MovementPattern = 'push' | 'pull' | 'squat' | 'hinge' | 'carry' | 'core' | 'isolation';
export declare const LOCATION_EQUIPMENT: Record<LocationId, EquipmentId[]>;
interface ExerciseEquipmentMapping {
    equipment_required: EquipmentId[];
    equipment_optional: EquipmentId[];
    locations: LocationId[];
    is_compound: boolean;
    estimated_seconds: number;
    rest_seconds: number;
    movement_pattern: MovementPattern;
}
/**
 * Exercise mappings - keyed by exercise ID
 *
 * Format:
 * - equipment_required: Must have ALL of these
 * - equipment_optional: Nice to have, not required
 * - locations: Where this exercise is appropriate
 * - is_compound: Whether this is a compound movement
 * - estimated_seconds: Time per set (not including rest)
 * - rest_seconds: Rest between sets
 * - movement_pattern: For push/pull balancing
 */
export declare const EXERCISE_MAPPINGS: Record<string, ExerciseEquipmentMapping>;
/**
 * Apply exercise equipment/location mappings to the database
 */
export declare function seedEquipmentLocations(): Promise<void>;
export {};
