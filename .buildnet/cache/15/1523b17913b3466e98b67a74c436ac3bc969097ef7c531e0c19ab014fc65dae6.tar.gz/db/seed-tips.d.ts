/**
 * Seed Tips and Milestones
 *
 * High-quality tips across categories for contextual display during workouts.
 */
export declare function seedTips(): Promise<void>;
export declare function seedMilestones(): Promise<void>;
