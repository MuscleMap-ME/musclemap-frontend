/**
 * Migration 157: Enhanced Teams and Crews System
 *
 * Phase 3 of the Community Engagement Master Plan
 * Extends existing crew infrastructure with:
 * - crew_challenges: Team-based challenges
 * - challenge_contributions: Individual contributions to challenges
 * - crew_achievements: Shared accomplishments
 * - crew_chat_messages: Team communication
 * - crew_chat_read_status: Track last read message per user
 *
 * DESTRUCTIVE: down() drops all Phase 3 crew enhancement tables - acknowledged for rollback capability
 */
export declare function up(): Promise<void>;
export declare function down(): Promise<void>;
