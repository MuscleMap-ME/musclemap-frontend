/**
 * Migration 075: Transportation Career Standards
 *
 * Adds DOT and Transportation career standards to MuscleMap:
 * 1. DOT Physical Exam (FMCSA) - Commercial driver certification
 * 2. TSA Transportation Security Officer - Airport security
 * 3. Federal Air Marshal (TSA/DHS) - Law enforcement fitness
 * 4. Transit Operator (Generic) - Public transit
 * 5. USPS Mail Carrier - Postal service physical requirements
 *
 * Note: Many transportation jobs focus on medical fitness rather than
 * athletic performance, so components may be medical evaluations
 * rather than timed fitness tests.
 */
export declare function migrate(): Promise<void>;
export declare function down(): Promise<void>;
export declare const up: typeof migrate;
