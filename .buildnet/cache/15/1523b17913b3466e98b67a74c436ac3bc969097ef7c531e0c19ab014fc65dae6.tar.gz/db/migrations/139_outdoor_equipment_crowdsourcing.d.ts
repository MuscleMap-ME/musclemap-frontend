/**
 * Migration 139: Outdoor Equipment Crowdsourcing System
 *
 * Extends the existing fitness_venues system with:
 * - NYC Open Data integration fields
 * - OpenStreetMap integration fields
 * - Crowdsourced location submissions with approval workflow
 * - Equipment condition tracking
 * - Location verification/contributions tracking
 * - Photo contributions
 * - User contribution credits/rewards
 *
 * Builds on migration 132_venue_records_system which already has:
 * - fitness_venues table with equipment JSONB
 * - venue_checkins for user presence tracking
 * - venue_memberships for user-venue relationships
 *
 * DESTRUCTIVE: The down() function removes crowdsourcing tables and columns.
 * This is intentional for clean rollback of the feature.
 */
export declare function up(): Promise<void>;
export declare function down(): Promise<void>;
