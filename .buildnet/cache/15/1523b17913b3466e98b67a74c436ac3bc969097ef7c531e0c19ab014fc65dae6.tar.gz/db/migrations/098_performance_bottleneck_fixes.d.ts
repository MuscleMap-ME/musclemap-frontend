/**
 * Migration: Performance Bottleneck Fixes
 *
 * Addresses 5 critical performance issues:
 *
 * PERF-001: GET /api/leaderboard (~500ms → <100ms)
 * - Covering index for leaderboard entries with INCLUDE clause
 * - Index for keyset pagination on leaderboard_entries
 * - Materialized view for frequently accessed leaderboards
 *
 * PERF-002: GET /api/community/feed (~800ms → <200ms)
 * - Optimized composite index for activity_events feed queries
 * - Index for privacy mode filtering (NOT EXISTS optimization)
 *
 * PERF-003: POST /api/workout (~300ms → <150ms)
 * - Index for exercise_activations lookup (batch optimization)
 * - Index for muscles bias_weight lookup
 *
 * PERF-004: GET /api/stats/history (~1s → <200ms)
 * - BRIN index on character_stats_history.snapshot_date
 * - Covering index for stats history queries
 *
 * PERF-005: tu_calculate (JavaScript ~20ms → <2ms)
 * - TU calculation cache table for repeated calculations
 *
 * See docs/DATABASE-OPTIMIZATION-PLAN.md for full details.
 */
export declare function up(): Promise<void>;
export declare function down(): Promise<void>;
export declare const migrate: typeof up;
