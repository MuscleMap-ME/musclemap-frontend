/**
 * Migration 117: Error Tracking System
 *
 * Creates tables for tracking frontend errors, auto-healing workflows,
 * and error pattern analysis. This powers the Cockatrice error reporting
 * system and enables proactive issue resolution.
 *
 * Tables:
 * - frontend_errors: Individual error reports from the UI
 * - error_patterns: Detected patterns and recurring issues
 * - auto_healing_actions: Actions taken to fix issues automatically
 * - error_resolutions: How errors were resolved (for learning)
 * - auto_healing_executions: Execution log for auto-healing actions
 */
export declare function up(): Promise<void>;
export declare function down(): Promise<void>;
