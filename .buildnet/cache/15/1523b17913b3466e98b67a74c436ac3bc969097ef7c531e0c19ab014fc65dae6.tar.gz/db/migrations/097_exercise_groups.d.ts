/**
 * Migration 097: Exercise Groups (Supersets, Circuits, Giant Sets)
 *
 * Adds support for grouping exercises together:
 * - exercise_groups table for storing group definitions
 * - Supports supersets (2 exercises), giant sets (3+ exercises), circuits, and drop sets
 * - Each group has configurable rest times (between exercises, after completing group)
 * - Groups maintain exercise order and can be reordered within workouts
 */
export declare function up(): Promise<void>;
export declare function down(): Promise<void>;
