"use strict";
// DESTRUCTIVE: Schema modification for user mutes - contains DROP/TRUNCATE operations
/**
 * Migration: User Mutes System
 *
 * Adds table for muting users, communities, and other entities.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.up = up;
exports.down = down;
const client_1 = require("../client");
const logger_1 = require("../../lib/logger");
const log = logger_1.loggers.db;
async function tableExists(tableName) {
    const result = await client_1.db.queryOne(`SELECT COUNT(*) as count FROM information_schema.tables
     WHERE table_schema = 'public' AND table_name = $1`, [tableName]);
    return parseInt(result?.count || '0') > 0;
}
async function up() {
    log.info('Running migration: 058_user_mutes');
    // ============================================
    // USER MUTES TABLE
    // ============================================
    if (!(await tableExists('user_mutes'))) {
        log.info('Creating user_mutes table...');
        await client_1.db.query(`
      CREATE TABLE user_mutes (
        id TEXT PRIMARY KEY DEFAULT 'mute_' || replace(gen_random_uuid()::text, '-', ''),
        user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
        entity_type TEXT NOT NULL CHECK (entity_type IN ('user', 'community', 'thread', 'channel')),
        entity_id TEXT NOT NULL,
        mute_until TIMESTAMPTZ, -- NULL = permanent
        reason TEXT,
        created_at TIMESTAMPTZ DEFAULT NOW(),
        CONSTRAINT unique_user_mute UNIQUE (user_id, entity_type, entity_id)
      )
    `);
        await client_1.db.query('CREATE INDEX idx_user_mutes_user ON user_mutes(user_id)');
        await client_1.db.query('CREATE INDEX idx_user_mutes_entity ON user_mutes(entity_type, entity_id)');
        await client_1.db.query('CREATE INDEX idx_user_mutes_expiry ON user_mutes(mute_until) WHERE mute_until IS NOT NULL');
        log.info('user_mutes table created');
    }
    log.info('Migration 058_user_mutes completed');
}
async function down() {
    log.info('Rolling back migration: 058_user_mutes');
    await client_1.db.query('DROP TABLE IF EXISTS user_mutes CASCADE');
    log.info('Rollback 058_user_mutes completed');
}
//# sourceMappingURL=058_user_mutes.js.map