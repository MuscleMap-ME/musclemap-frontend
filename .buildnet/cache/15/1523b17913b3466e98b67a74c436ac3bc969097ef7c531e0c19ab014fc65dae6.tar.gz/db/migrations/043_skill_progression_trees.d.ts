/**
 * Migration: Skill Progression Trees
 *
 * Adds support for gymnastics/calisthenics skill progression tracking.
 * Users can track their progress toward advanced bodyweight skills like:
 * - Handstands, HSPU, One-arm handstand
 * - Planche, Front/Back Lever
 * - Muscle-ups, One-arm pull-ups
 * - Iron Cross, Human Flag
 */
export declare function migrate(): Promise<void>;
export declare function rollback(): Promise<void>;
