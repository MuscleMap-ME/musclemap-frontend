/**
 * Migration: Add D&D-Style Character Stats System
 *
 * This migration creates tables for:
 * 1. character_stats - Current stat values per user (STR, CON, DEX, PWR, END, VIT)
 * 2. character_stats_history - Historical snapshots for progress charts
 * 3. exercise_stat_mappings - Maps exercises to stat contributions
 * 4. user_profile_extended - Gender and location data for leaderboards
 * 5. leaderboard_cache - Pre-computed rankings for performance
 */
export declare function up(): Promise<void>;
