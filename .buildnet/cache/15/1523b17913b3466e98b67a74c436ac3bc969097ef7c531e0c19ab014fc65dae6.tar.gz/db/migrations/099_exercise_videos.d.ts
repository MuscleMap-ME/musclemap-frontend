/**
 * Migration: Exercise Videos System
 *
 * Creates infrastructure for exercise video demonstrations:
 * - exercise_videos table for multiple video angles (front, side, back, detail)
 * - Video types: demonstration, common_mistakes, cues, slow_motion
 * - Support for adaptive streaming (HLS) preparation
 * - Thumbnail and duration tracking
 */
export declare function up(): Promise<void>;
export declare function down(): Promise<void>;
