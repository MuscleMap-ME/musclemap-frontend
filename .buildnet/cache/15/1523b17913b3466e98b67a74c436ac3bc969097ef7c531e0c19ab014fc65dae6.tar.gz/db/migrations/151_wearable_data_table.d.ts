/**
 * Migration 151: Create wearable_data table
 *
 * This table stores aggregated wearable data for the wellness page.
 * It unifies data from various wearable sources into a single queryable table.
 */
export declare function migrate(): Promise<void>;
