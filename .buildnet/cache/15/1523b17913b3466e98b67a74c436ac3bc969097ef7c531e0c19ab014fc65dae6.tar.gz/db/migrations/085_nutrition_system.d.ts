/**
 * Migration: Nutrition System
 *
 * Comprehensive nutrition tracking system for MuscleMap including:
 * - User nutrition preferences (binary enable/disable)
 * - Nutrition goals with adaptive calculations
 * - Food database with multi-source caching
 * - Meal logging with workout integration
 * - Recipes and meal planning
 * - Community nutrition features
 * - Nutrition streaks and achievements
 */
export declare function up(): Promise<void>;
export declare function down(): Promise<void>;
export declare const migrate: typeof up;
