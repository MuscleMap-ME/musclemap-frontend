/**
 * Migration 096: One Rep Max (1RM) Tracking System
 *
 * Adds comprehensive 1RM tracking features:
 * - Exercise 1RM history table for tracking progression over time
 * - Best 1RM fields in exercise_personal_records
 * - 1RM-based achievements (1000lb Club, etc.)
 * - Compound lift total tracking (Squat + Bench + Deadlift)
 * - Views for 1RM progression charts
 */
export declare function up(): Promise<void>;
export declare function down(): Promise<void>;
export declare const migrate: typeof up;
