/**
 * Migration: Performance Optimization Phase 1
 *
 * Quick wins for immediate performance improvement:
 * 1. Automated materialized view refresh scheduling
 * 2. Activity events composite index for user + event_type queries
 * 3. Conversation participant lookup index
 * 4. Exercise activation reverse lookup index (muscle -> exercises)
 *
 * See docs/DATABASE-OPTIMIZATION-PLAN.md for full optimization roadmap.
 */
export declare function up(): Promise<void>;
export declare function down(): Promise<void>;
export declare const migrate: typeof up;
