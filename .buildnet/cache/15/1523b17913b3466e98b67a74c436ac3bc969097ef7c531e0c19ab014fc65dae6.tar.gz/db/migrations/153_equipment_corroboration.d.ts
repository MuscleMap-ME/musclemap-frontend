/**
 * Migration: Equipment Corroboration System
 *
 * Adds tables and functionality for:
 * - Equipment suggestions (users can propose new equipment at venues)
 * - Equipment voting (corroboration system for suggestions)
 * - Condition voting (community consensus on equipment condition)
 * - Auto-approval when 3+ votes with <2 rejections
 */
export declare function up(): Promise<void>;
export declare function down(): Promise<void>;
