/**
 * Migration 103: Mascot Powers Phase 4 - Social & Community Assistance
 *
 * Implements:
 * - Crew Helper: Coordinate team workouts and find crews
 * - Rivalry Manager: Competitive assistance
 * - High-Five Helper: Automate positive social engagement
 */
export declare function up(): Promise<void>;
export declare function down(): Promise<void>;
