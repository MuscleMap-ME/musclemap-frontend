/**
 * Migration 119: Venue Records System
 *
 * Creates the infrastructure for location-based achievement records:
 * - fitness_venues: Physical locations (parks, gyms, rec centers)
 * - venue_record_types: Record categories (pull-ups, bench press, etc.)
 * - venue_records: Record claims with verification
 * - venue_record_history: Audit trail of past records
 * - venue_memberships: Users following venues
 * - venue_checkins: Active presence tracking
 * - venue_record_disputes: Dispute resolution
 *
 * Also seeds NYC calisthenics parks and common record types.
 */
export declare function up(): Promise<void>;
export declare function down(): Promise<void>;
