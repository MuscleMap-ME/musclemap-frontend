/**
 * Migration 105: Mascot Powers Phase 6 - Advanced AI Abilities
 *
 * Implements:
 * - Workout Generator: AI-powered workout plan creation
 * - Injury Prevention: Overtraining monitoring and warnings
 * - Nutrition Hints: Light nutrition guidance
 * - Master Mascot Powers: Top-tier abilities for stage 6 companions
 */
export declare function up(): Promise<void>;
export declare function down(): Promise<void>;
