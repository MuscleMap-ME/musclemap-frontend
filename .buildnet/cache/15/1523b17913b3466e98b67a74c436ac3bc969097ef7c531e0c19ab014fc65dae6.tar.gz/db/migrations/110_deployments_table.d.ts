/**
 * Migration 108: Deployments Table
 *
 * Creates infrastructure for tracking deployment history:
 * 1. Deployments table to store all deployment records
 * 2. Indexes for efficient querying of deployment history
 * 3. View for deployment statistics
 *
 * Used by the admin dashboard for deployment pipeline management.
 */
export declare function up(): Promise<void>;
export declare function down(): Promise<void>;
