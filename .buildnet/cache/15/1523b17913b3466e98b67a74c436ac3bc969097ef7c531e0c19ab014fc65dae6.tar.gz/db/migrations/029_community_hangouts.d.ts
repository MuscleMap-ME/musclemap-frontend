/**
 * Migration: Community Hangouts & Virtual Spaces
 *
 * This migration creates the themed virtual community system:
 *
 * 1. virtual_hangouts - Themed spaces tied to archetypes/goals (not geo-located)
 *    - Warrior's Cave, Hunter's Den, Runner's Camp, Police Academy, etc.
 *    - Each has themed graphics, content, and member lists
 *
 * 2. communities - Self-organized groups with leaders and hierarchy
 *    - Goal-based (weight loss, muscle gain)
 *    - Interest-based (martial arts, running)
 *    - Institution-based (military, police, fire)
 *
 * 3. bulletin_boards - Community bulletin boards with voting
 *    - Posts with upvote/downvote
 *    - Pinned content by moderators
 *
 * 4. community_artifacts - Documents, links, resources per community
 *
 * 5. user_community_profiles - Extended privacy and visibility controls
 *    - Ghost mode (invisible in lists)
 *    - Selective profile data sharing
 *
 * 6. community_roles - Social hierarchy within communities
 */
export declare function up(): Promise<void>;
export declare function down(): Promise<void>;
export declare const migrate: typeof up;
