/**
 * Migration: Economy V2 - Trust Tiers, Transfer Controls, and Escrow
 *
 * Adds:
 * 1. Transfer opt-in settings and limits per user
 * 2. Trust tier system based on account age and activity
 * 3. Escrow holds for class bookings
 * 4. Dispute mechanism for classes
 * 5. Configurable economy settings table
 */
export declare function up(): Promise<void>;
export declare function down(): Promise<void>;
export declare const migrate: typeof up;
