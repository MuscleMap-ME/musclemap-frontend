/**
 * Migration: Denormalize Profile Fields to Users Table
 *
 * Optimizes the materialized view refresh and leaderboard queries by:
 * 1. Adding country, ghost_mode, leaderboard_opt_in to users table
 * 2. Migrating existing data from user_profile_extended
 * 3. Creating sync trigger for backwards compatibility
 * 4. Updating mv_xp_rankings to use denormalized fields (faster refresh)
 *
 * This eliminates the LEFT JOIN in mv_xp_rankings, reducing refresh time by ~50%.
 *
 * See docs/DATABASE-OPTIMIZATION-PLAN.md for full optimization roadmap.
 */
export declare function up(): Promise<void>;
export declare function down(): Promise<void>;
export declare const migrate: typeof up;
