/**
 * Migration: Skill Progressions System
 *
 * Creates tables for calisthenics skill progression trees
 * including planche, front lever, muscle-up, handstand, etc.
 * Based on gymnastics and calisthenics training methodology.
 */
export declare function up(): Promise<void>;
export declare function down(): Promise<void>;
