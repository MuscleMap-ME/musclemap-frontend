/**
 * Migration: Auto-Discovered Bugs System
 *
 * Enhances feedback system to support:
 * - System-discovered bugs (no user_id required)
 * - Bug hunter integration
 * - Full bug lifecycle tracking
 * - Resolution history
 */
export declare function up(): Promise<void>;
export declare function down(): Promise<void>;
