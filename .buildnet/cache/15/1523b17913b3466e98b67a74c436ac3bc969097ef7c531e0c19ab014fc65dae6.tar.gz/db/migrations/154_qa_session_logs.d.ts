/**
 * Migration: QA Session Logs
 *
 * Creates table for storing frontend QA session events for passive testing.
 * This allows comprehensive bug detection during user testing sessions.
 */
export declare function migrate(): Promise<void>;
