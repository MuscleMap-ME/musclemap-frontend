/**
 * Migration: Sleep Hygiene System
 *
 * Extends the existing sleep/recovery system with:
 * - Sleep hygiene preferences (enable/disable)
 * - Sleep hygiene tips library
 * - Sleep hygiene assessments (daily/weekly checklists)
 * - Sleep streaks with credit rewards
 * - Personalized sleep hygiene recommendations
 *
 * Users can earn credits for:
 * - Logging sleep consistently (streak bonuses)
 * - Meeting sleep duration targets
 * - Maintaining good sleep quality
 * - Following sleep hygiene recommendations
 */
export declare function up(): Promise<void>;
export declare function down(): Promise<void>;
