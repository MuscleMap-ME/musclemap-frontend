/**
 * Migration: Workout Templates System
 *
 * Adds workout templates for saving and sharing workout routines:
 * - Template definitions with exercise structures
 * - Template sharing and discovery
 * - Template ratings and usage tracking
 * - Template cloning/forking
 */
export declare function up(): Promise<void>;
export declare function down(): Promise<void>;
