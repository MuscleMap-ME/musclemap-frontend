/**
 * Migration: User Languages
 *
 * Adds:
 * 1. user_languages table - Multi-select languages per user with proficiency
 * 2. language_options table - Available languages with flag emojis
 *
 * Features:
 * - Users can select multiple languages they speak
 * - Each language has a proficiency level (native, fluent, conversational, basic)
 * - One language can be marked as primary
 * - Used for leaderboard filtering by language
 */
export declare function up(): Promise<void>;
export declare function down(): Promise<void>;
export declare const migrate: typeof up;
