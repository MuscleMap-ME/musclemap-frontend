/**
 * Migration: Mascot Timeline System
 *
 * Creates tables for:
 * 1. Timeline Events - Records of significant user events
 * 2. Timeline Reactions - Mascot reactions to events
 *
 * This enables:
 * - Recording workout/achievement events
 * - Generating contextual mascot reactions
 * - Building a personalized timeline feed
 * - Tracking which reactions have been shown to the user
 */
export declare function up(): Promise<void>;
export declare function down(): Promise<void>;
export declare const migrate: typeof up;
