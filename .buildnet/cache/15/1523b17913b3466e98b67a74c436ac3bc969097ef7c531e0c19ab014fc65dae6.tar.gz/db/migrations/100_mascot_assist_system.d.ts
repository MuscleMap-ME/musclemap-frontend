/**
 * Migration: Mascot Assist System
 *
 * Enables the mascot/companion to assist users by completing exercises on their behalf.
 * This is an early-game feature that helps new users maintain workout completion streaks
 * and earn full credit even when they can't complete all exercises.
 *
 * Key features:
 * - Mascot can complete one exercise per workout for low-level users
 * - Daily charge system (mascot gets tired, regenerates daily)
 * - Power grows with user rank and companion stage
 * - Tracks usage history for analytics
 */
export declare function up(): Promise<void>;
export declare function down(): Promise<void>;
export declare const migrate: typeof up;
