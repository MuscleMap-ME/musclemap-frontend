/**
 * Migration 130: Mascot Credit Loans System
 *
 * Adds support for mascot credit loans feature (Stage 5+):
 * - Credit loan records
 * - Loan configuration
 * - Emergency grant tracking
 */
export declare function up(): Promise<void>;
export declare function down(): Promise<void>;
