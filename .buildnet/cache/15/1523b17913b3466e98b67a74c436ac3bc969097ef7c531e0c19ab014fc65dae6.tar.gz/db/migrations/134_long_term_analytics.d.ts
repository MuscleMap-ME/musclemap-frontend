/**
 * Migration 134: Long-Term Analytics System
 *
 * Creates comprehensive infrastructure for tracking yearly TU (Training Units),
 * trends, and progress over time:
 *
 * - user_yearly_stats: Yearly aggregates (total_tu, total_workouts, total_exercises, etc.)
 * - user_monthly_stats: Monthly aggregates for trend analysis
 * - user_progress_trends: Computed trends (acceleration, velocity, projected milestones)
 * - Materialized views for efficient querying of historical data
 * - Indexes for time-series queries and keyset pagination
 *
 * TU (Training Units) = A normalized measure of workout volume:
 * TU = (sets * reps * weight_factor * difficulty_factor) / 100
 *
 * This system enables:
 * - Year-in-review summaries
 * - Multi-year progress tracking
 * - Projected milestone calculations
 * - Progress velocity and acceleration analysis
 */
export declare function up(): Promise<void>;
export declare function down(): Promise<void>;
