/**
 * Migration: Privacy Mode & Minimalist Experience Settings
 *
 * This migration creates/updates tables for:
 * 1. user_privacy_mode - Master privacy/minimalist mode settings
 *
 * Privacy Philosophy:
 * - Users can opt out of ALL community features entirely
 * - Users can selectively disable specific community features
 * - Users data should be excluded from collection/comparison when opted out
 * - UI can be stripped down to bare essentials if that's what users want
 */
export declare function up(): Promise<void>;
export declare function down(): Promise<void>;
export declare const migrate: typeof up;
