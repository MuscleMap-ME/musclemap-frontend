/**
 * Migration 101: Mascot Powers Phase 2 - Credit & Economy Assistance
 *
 * Implements:
 * - Credit Guardian: Warns users about low balance
 * - Streak Saver: Protects valuable streaks
 * - Bonus Multiplier: Increases TU earnings
 * - Mascot Energy System: Resource for using abilities
 */
export declare function up(): Promise<void>;
export declare function down(): Promise<void>;
