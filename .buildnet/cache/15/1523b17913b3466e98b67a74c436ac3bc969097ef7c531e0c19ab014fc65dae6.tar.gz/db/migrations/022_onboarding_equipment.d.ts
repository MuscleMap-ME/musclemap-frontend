/**
 * Migration: User Onboarding & Location-Based Equipment Tracking
 *
 * This migration creates tables for:
 * 1. Physical profile extension (height, weight, DOB, units)
 * 2. Equipment types reference table
 * 3. Location equipment (crowd-sourced equipment at gyms/parks)
 * 4. Equipment reports (individual user reports)
 * 5. User home equipment (personal gym equipment)
 *
 * Trust Model:
 * - Equipment is verified when 3+ users report it as present
 * - Users can report equipment as present or absent
 * - Consensus drives verification status
 */
export declare function up(): Promise<void>;
export declare function down(): Promise<void>;
export declare const migrate: typeof up;
