/**
 * Migration: Community Dashboard Tables
 *
 * This migration creates tables for:
 * 1. user_privacy_settings - Privacy preferences for community features
 * 2. activity_events - Append-only log for activity feed
 * 3. journey_progress - Tracks user progress through journeys
 * 4. metrics_rollups_hourly - Cached hourly statistics
 * 5. user_locations - Coarse location data for map view
 */
export declare function migrate(): Promise<void>;
