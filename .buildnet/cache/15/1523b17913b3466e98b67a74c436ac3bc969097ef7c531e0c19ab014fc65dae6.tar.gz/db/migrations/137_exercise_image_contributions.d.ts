/**
 * Migration 137: Exercise Image Contributions
 *
 * Creates a system for users to submit exercise photos:
 * - Track submissions with AI validation scores
 * - Support approval workflow with credits
 * - Allow community images to replace wger.de images
 */
export declare function up(): Promise<void>;
export declare function down(): Promise<void>;
