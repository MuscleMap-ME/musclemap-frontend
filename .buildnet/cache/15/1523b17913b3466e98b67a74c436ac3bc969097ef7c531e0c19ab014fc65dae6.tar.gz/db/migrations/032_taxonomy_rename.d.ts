/**
 * Migration: Taxonomy Rename (Journey System Overhaul - Phase 1)
 *
 * This migration renames the core taxonomy tables:
 * - archetypes → identities
 * - archetype_categories → identity_categories
 * - archetype_levels → identity_levels
 * - archetype_community_links → identity_community_links
 * - user_goals → user_journeys
 * - goal_progress → journey_progress
 * - goal_milestones → journey_milestones
 *
 * Also updates:
 * - users.current_archetype_id → users.current_identity_id
 * - Foreign key references
 * - Creates backward-compatible views for old table names
 */
export declare function up(): Promise<void>;
export declare function down(): Promise<void>;
export declare const migrate: typeof up;
