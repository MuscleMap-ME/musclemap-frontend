/**
 * Migration 071: Corrections Officer Career Standards
 *
 * Adds physical fitness test standards for corrections officers:
 * 1. California CDCR PFT - California Department of Corrections and Rehabilitation
 * 2. Federal BOP PFT - Federal Bureau of Prisons
 * 3. NY DOCCS PAT - New York Department of Corrections and Community Supervision
 * 4. Hawaii COPAT - Hawaii Department of Corrections and Rehabilitation
 * 5. Generic COPAT - Various agencies standard corrections officer test
 */
export declare function migrate(): Promise<void>;
export declare function down(): Promise<void>;
export { migrate as up };
