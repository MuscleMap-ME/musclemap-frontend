/**
 * Migration: Social Features & Community Enhancements
 *
 * This migration adds:
 *
 * 1. Social Graph - Friends, follows, and connections
 * 2. Buddy Matching - Find workout partners with similar goals
 * 3. Mentorship System - Mentor/mentee pairing
 * 4. Community Analytics - Growth and engagement tracking
 * 5. Auto-join by Archetype - Link archetypes to default communities
 * 6. Community Resources - Knowledge base, artifacts, wiki pages
 * 7. Content Reporting/Flagging - Moderation workflow
 * 8. Inter-Community Challenges - Federated events
 */
export declare function up(): Promise<void>;
export declare function down(): Promise<void>;
