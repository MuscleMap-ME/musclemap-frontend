/**
 * Migration 131: User Preferences System
 *
 * Creates a comprehensive user customization system including:
 * - Central user preferences with JSONB flexibility
 * - Configuration profiles (Gym Mode, Home Mode, Competition Mode)
 * - Dashboard widget layouts
 * - Music streaming connections
 * - Custom sound packs
 * - Device-specific settings
 */
export declare function up(): Promise<void>;
export declare function down(): Promise<void>;
