/**
 * Migration: User Feedback System
 *
 * Adds tables for:
 * - Bug reports
 * - Feature suggestions
 * - Questions/support requests
 * - Feedback responses (admin replies)
 * - FAQ entries (for common questions)
 */
export declare function up(): Promise<void>;
export declare function down(): Promise<void>;
