/**
 * Migration: Ghost Mode and Profile Enhancements
 *
 * Adds:
 * 1. ghost_mode column to user_profile_extended
 * 2. about_me and about_me_visibility columns for rich text bio
 * 3. user_field_visibility table for per-field privacy controls
 *
 * Ghost Mode:
 * - When enabled, user is excluded from all leaderboards
 * - Profile returns minimal info to other users
 * - User can still use all app features normally
 *
 * Field Visibility:
 * - Each profile field can be independently shown/hidden
 * - Controls: location, gender, age, stats, achievements, rank, workouts, languages, veteran badge
 */
export declare function up(): Promise<void>;
export declare function down(): Promise<void>;
export declare const migrate: typeof up;
