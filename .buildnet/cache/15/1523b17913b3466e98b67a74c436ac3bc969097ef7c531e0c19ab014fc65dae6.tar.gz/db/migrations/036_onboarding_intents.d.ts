/**
 * Migration: Onboarding Intents System
 *
 * Phase 5 of Journey Overhaul - adds:
 * - User intent tracking for progressive disclosure onboarding
 * - 5 primary intents: general, goal, competition, milestone, recovery
 * - Onboarding state machine with step tracking
 * - Flow-specific customization storage
 */
export declare function up(): Promise<void>;
