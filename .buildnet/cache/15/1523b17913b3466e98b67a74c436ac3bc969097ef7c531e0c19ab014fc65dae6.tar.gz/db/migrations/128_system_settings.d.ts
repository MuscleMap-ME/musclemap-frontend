/**
 * Migration 128: System Settings Table
 *
 * Creates a system_settings table to store application-wide settings
 * like maintenance mode, read-only mode, and other configuration.
 *
 * This provides database durability for emergency mode settings
 * when Redis is unavailable.
 */
export declare function up(): Promise<void>;
export declare function down(): Promise<void>;
