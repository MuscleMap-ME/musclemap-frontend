/**
 * Migration 119: Active Workout Sessions
 *
 * Creates server-side storage for in-progress workout sessions.
 * This allows users to recover their workouts after:
 * - Browser refresh/crash
 * - Server restart
 * - Switching devices
 * - App crashes
 *
 * Sessions are automatically cleaned up after 24 hours of inactivity.
 */
export declare function migrate(): Promise<void>;
