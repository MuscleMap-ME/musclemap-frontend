/**
 * Migration: Issue Tracker System
 *
 * This migration adds a comprehensive bug and issue tracking system:
 * 1. Issues table - bugs, feature requests, suggestions
 * 2. Issue comments - threaded discussions
 * 3. Issue votes - upvotes for prioritization
 * 4. Issue subscribers - follow updates
 * 5. Issue status history - audit trail
 * 6. Issue labels/tags - categorization
 */
export declare function migrate(): Promise<void>;
export declare const up: typeof migrate;
