/**
 * Migration: Live Activity System
 *
 * Creates tables for real-time activity monitoring:
 * - live_activity_events: Anonymous, ephemeral activity events (24h retention)
 * - geo_regions: Geographic hierarchy for drill-down navigation
 *
 * Privacy-First Architecture:
 * - NO user_id column - events are anonymous by design
 * - Privacy settings are checked BEFORE logging (gate at collection, not display)
 * - Events auto-expire after 24 hours
 * - No exact coordinates stored - only geo_bucket hashes
 */
export declare function up(): Promise<void>;
export declare function down(): Promise<void>;
export declare const migrate: typeof up;
