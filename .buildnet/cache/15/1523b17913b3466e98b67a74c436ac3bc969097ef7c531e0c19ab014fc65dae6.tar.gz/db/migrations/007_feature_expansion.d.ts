/**
 * Migration: Feature Expansion
 *
 * This migration adds:
 * 1. Hangouts (Location-Based Community Hubs) with PostGIS
 * 2. Enhanced Credits Economy with P2P transfers
 * 3. Video Assets and Exercise Demos
 * 4. i18n Content Translations
 * 5. Imported Activities (Apple Watch, etc.)
 * 6. Moderation Queue
 * 7. User Location Settings
 * 8. Workout Sessions and Rep Events
 */
export declare function migrate(): Promise<void>;
export declare const up: typeof migrate;
