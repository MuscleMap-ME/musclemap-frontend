/**
 * Migration: Goal-Based Training System
 *
 * This migration creates tables for:
 * 1. user_goals - User's fitness goals with targets
 * 2. goal_progress - Daily progress tracking towards goals
 * 3. goal_milestones - Achievement milestones within goals
 */
export declare function up(): Promise<void>;
export declare function down(): Promise<void>;
export declare const migrate: typeof up;
