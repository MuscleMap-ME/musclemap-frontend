/**
 * Migration 078: Expanded Career Categories
 *
 * Updates the career standards category taxonomy to support all new profession types:
 * - Creates a reference table for category metadata (career_standard_categories)
 * - Expands the pt_tests.category CHECK constraint to include new categories
 * - Adds hierarchical support via parent_category
 *
 * New categories added:
 * - ems_paramedic - EMS and Paramedic roles
 * - corrections - Corrections officers
 * - park_ranger - Park rangers and wildlife officers
 * - lifeguard - Lifeguards and aquatic safety
 * - transportation - CDL drivers, TSA, transit operators
 * - trades_construction - Construction and trade workers
 * - public_service - Postal workers, sanitation, public works
 */
export declare function migrate(): Promise<void>;
export declare function down(): Promise<void>;
export declare const up: typeof migrate;
