"use strict";
/**
 * Migration 151: Create wearable_data table
 *
 * This table stores aggregated wearable data for the wellness page.
 * It unifies data from various wearable sources into a single queryable table.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.migrate = migrate;
const client_1 = require("../client");
const logger_1 = require("../../lib/logger");
const log = logger_1.loggers.db;
async function tableExists(tableName) {
    const result = await client_1.db.queryOne(`SELECT COUNT(*) as count FROM information_schema.tables
     WHERE table_name = $1`, [tableName]);
    return parseInt(result?.count || '0') > 0;
}
async function migrate() {
    log.info('Running migration: 151_wearable_data_table');
    // Create wearable_data table if it doesn't exist
    if (!(await tableExists('wearable_data'))) {
        log.info('Creating wearable_data table...');
        await client_1.db.query(`
      CREATE TABLE wearable_data (
        id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::TEXT,
        user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
        recorded_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),

        -- Activity metrics
        steps INTEGER DEFAULT 0,
        active_calories INTEGER DEFAULT 0,
        total_calories INTEGER DEFAULT 0,
        workout_minutes INTEGER DEFAULT 0,
        stand_hours INTEGER DEFAULT 0,
        distance_meters NUMERIC(10, 2) DEFAULT 0,

        -- Heart rate metrics
        heart_rate INTEGER,
        resting_heart_rate INTEGER,
        max_heart_rate INTEGER,
        min_heart_rate INTEGER,

        -- Source tracking
        source TEXT NOT NULL DEFAULT 'manual',
        raw_data JSONB,

        -- Timestamps
        created_at TIMESTAMPTZ DEFAULT NOW(),
        updated_at TIMESTAMPTZ DEFAULT NOW()
      )
    `);
        // Create indexes for common queries
        await client_1.db.query(`
      CREATE INDEX idx_wearable_data_user_recorded
      ON wearable_data(user_id, recorded_at DESC)
    `);
        await client_1.db.query(`
      CREATE INDEX idx_wearable_data_user_date
      ON wearable_data(user_id, DATE(recorded_at))
    `);
        // Unique constraint: one record per user per day per source
        // Use expression index with COALESCE to handle the DATE function properly
        await client_1.db.query(`
      CREATE UNIQUE INDEX idx_wearable_data_user_source_date
      ON wearable_data(user_id, source, (recorded_at::date))
    `);
        log.info('Created wearable_data table with indexes');
    }
    else {
        log.info('wearable_data table already exists');
    }
    log.info('Migration 151 completed');
}
//# sourceMappingURL=151_wearable_data_table.js.map