/**
 * Migration 150: Add is_rehab_exercise column to exercises table
 *
 * This column was missing from the exercises table but referenced in the
 * prescription engine v3 code. It indicates whether an exercise is specifically
 * designed for rehabilitation purposes.
 */
export declare function migrate(): Promise<void>;
