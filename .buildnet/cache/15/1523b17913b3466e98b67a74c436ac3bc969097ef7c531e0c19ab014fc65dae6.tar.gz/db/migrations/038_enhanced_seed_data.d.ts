/**
 * Migration: Enhanced Seed Data
 *
 * Adds additional content based on Claude Chad's comprehensive proposal:
 * - More specific rehabilitation journey templates with conditions
 * - Additional milestones for underrepresented categories
 * - More milestone progressions
 */
export declare function up(): Promise<void>;
