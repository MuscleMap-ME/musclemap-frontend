/**
 * Migration 071: Lifeguard and Aquatic Safety Career Standards
 *
 * Adds career standards for lifeguard and aquatic safety certifications:
 * 1. American Red Cross Lifeguard (arc-lifeguard) - r.24 update effective Sept 2024
 * 2. YMCA Lifeguard Certification (ymca-lifeguard)
 * 3. USLA Open Water Lifeguard (usla-ocean)
 * 4. Generic Pool Lifeguard (pool-lifeguard-generic)
 *
 * These are primarily swim-based tests with components for:
 * - Distance swimming (various strokes)
 * - Treading water (some with hands above water)
 * - Surface diving and object retrieval
 * - Sprint swimming
 * - CPR/First Aid skills
 */
export declare function migrate(): Promise<void>;
export declare function down(): Promise<void>;
export declare const up: typeof migrate;
