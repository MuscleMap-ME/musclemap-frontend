/**
 * Migration 135: Journey Health Scoring System
 *
 * Creates infrastructure for proactive journey health monitoring:
 * - journey_health_scores: Health metrics per journey (engagement_score, progress_rate, risk_level)
 * - journey_health_alerts: Alerts for at-risk journeys
 * - journey_recommendations: AI-generated recommendations
 * - Triggers to update health scores when progress is logged
 *
 * Health score factors:
 * - Days since last progress (higher = lower score)
 * - Progress rate vs expected rate
 * - Milestone completion rate
 * - Consistency of check-ins
 * - Deviation from target trajectory
 */
export declare function up(): Promise<void>;
export declare function down(): Promise<void>;
