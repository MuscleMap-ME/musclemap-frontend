/**
 * Migration 146: Presence System Enhancements
 *
 * Adds advanced features to the community presence system:
 * - Training partner streaks and bonus credits
 * - Quick status options (Looking for Spotter, etc.)
 * - Venue activity heatmap data endpoints
 * - Training partner compatibility scoring
 * - Scheduled recurring training sessions
 *
 * Builds on migration 143 (community_presence_system)
 *
 * DESTRUCTIVE: The down() function removes all enhancement tables.
 */
export declare function up(): Promise<void>;
export declare function down(): Promise<void>;
export declare const migrate: typeof up;
