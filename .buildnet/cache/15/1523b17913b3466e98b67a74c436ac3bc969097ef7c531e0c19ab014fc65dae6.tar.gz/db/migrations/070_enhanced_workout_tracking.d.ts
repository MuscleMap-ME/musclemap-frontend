/**
 * Migration 070: Enhanced Workout Tracking
 *
 * Adds support for:
 * - Individual workout sets table (instead of JSONB in workouts)
 * - Set tags (warmup, working, failure, drop, cluster, amrap)
 * - RPE (Rate of Perceived Exertion) and RIR (Reps in Reserve)
 * - Estimated 1RM per set
 * - Progress photos
 * - Body measurements
 * - Per-exercise rest timer defaults
 */
export declare function migrate(): Promise<void>;
