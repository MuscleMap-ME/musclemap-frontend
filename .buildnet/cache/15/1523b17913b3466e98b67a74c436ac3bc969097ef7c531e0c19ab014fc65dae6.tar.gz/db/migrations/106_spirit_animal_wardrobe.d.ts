/**
 * Migration 106: Spirit Animal Wardrobe System
 *
 * Implements the complete Spirit Animal cosmetic/wardrobe system:
 * - Cosmetic items catalog with rarity, seasons, and species locks
 * - User-owned cosmetics inventory
 * - Equipment loadout system
 * - Shop rotation for daily/featured items
 * - Purchase history for analytics
 * - Outfit presets for quick switching
 *
 * Spirit Animals (formerly "mascot companions") are a central part of
 * user identity and progression on MuscleMap.
 */
export declare function up(): Promise<void>;
export declare function down(): Promise<void>;
