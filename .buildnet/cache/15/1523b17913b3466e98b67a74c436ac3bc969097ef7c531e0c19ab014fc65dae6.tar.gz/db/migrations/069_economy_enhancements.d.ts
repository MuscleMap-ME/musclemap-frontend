/**
 * Migration: Economy Enhancements
 *
 * Comprehensive economy upgrade with:
 * 1. Geo-based hangouts with PostGIS support
 * 2. Credit packages for real money purchases
 * 3. Store categories and expanded items
 * 4. Credit earn events for real-time visibility
 * 5. Random bonus events (Lucky Rep, Golden Set, etc.)
 * 6. Hangout challenges with prize pools
 * 7. Enhanced profile customization
 * 8. Social spending features (tips, gifts, boosts)
 *
 * Core Equation: 1 penny = 1 credit = 1 Training Unit (TU)
 * Minimum Purchase: $1.00 = 100 credits
 */
export declare function up(): Promise<void>;
export declare function down(): Promise<void>;
export declare const migrate: typeof up;
