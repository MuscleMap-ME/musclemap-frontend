/**
 * Migration: User Ranks and XP System
 *
 * Adds:
 * 1. XP columns to users table (total_xp, current_rank, rank_updated_at)
 * 2. rank_definitions table with 8 tiers (Novice → Grandmaster)
 * 3. xp_history table for auditing XP awards
 * 4. veteran_tier column to users for tenure badges
 *
 * Rank Tiers:
 * - Novice (0 XP) - Empty outline
 * - Trainee (100 XP) - 1 chevron
 * - Apprentice (500 XP) - 2 chevrons
 * - Practitioner (1,500 XP) - 3 chevrons
 * - Journeyperson (4,000 XP) - Bronze star
 * - Expert (10,000 XP) - Silver star
 * - Master (25,000 XP) - Gold star
 * - Grandmaster (60,000 XP) - Diamond shield
 */
export declare function up(): Promise<void>;
export declare function down(): Promise<void>;
export declare const migrate: typeof up;
