/**
 * Migration: Add trial dates and subscriptions table
 *
 * This migration:
 * 1. Adds trial_started_at and trial_ends_at columns to users table
 * 2. Creates the subscriptions table
 * 3. Sets trial dates for existing users based on their created_at
 */
export declare function migrate(): Promise<void>;
