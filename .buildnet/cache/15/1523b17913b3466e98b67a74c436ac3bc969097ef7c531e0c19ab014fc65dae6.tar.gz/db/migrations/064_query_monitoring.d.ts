/**
 * Migration: Query Monitoring and Performance Views
 *
 * Creates monitoring infrastructure:
 * 1. Views for slow query identification
 * 2. Index usage monitoring
 * 3. Table bloat detection
 * 4. Database health dashboard view
 * 5. Helper functions for EXPLAIN ANALYZE
 *
 * Note: pg_stat_statements extension must be enabled by superuser.
 * If not available, some views will return empty results.
 *
 * See docs/DATABASE-OPTIMIZATION-PLAN.md for full optimization roadmap.
 */
export declare function up(): Promise<void>;
export declare function down(): Promise<void>;
export declare const migrate: typeof up;
