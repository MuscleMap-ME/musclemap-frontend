/**
 * Migration 149: Prescription Engine v3 Seed Data
 *
 * Seeds v3 metadata for existing exercises including:
 * - Movement patterns (v3 classification)
 * - Muscle activation data
 * - Effectiveness ratings
 * - Recovery profiles
 * - Equipment requirements
 *
 * // SQL-SAFE: All queries use parameterized placeholders ($1, $2, etc.) - no string interpolation
 */
export declare function migrate(): Promise<void>;
