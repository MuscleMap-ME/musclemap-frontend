/**
 * Migration: Trade and Construction Career Standards
 *
 * Adds physical ability tests for trade and construction careers:
 * 1. Laborers CPAT (LIUNA)
 * 2. Ironworkers PAT
 * 3. IBEW Electrician Apprentice
 * 4. UA Plumber/Pipefitter
 * 5. Carpenter Apprentice
 * 6. Utility Lineworker
 *
 * Note: OSHA 10/30 certification is often required alongside physical tests.
 */
export declare function up(): Promise<void>;
export declare function down(): Promise<void>;
export declare const migrate: typeof up;
