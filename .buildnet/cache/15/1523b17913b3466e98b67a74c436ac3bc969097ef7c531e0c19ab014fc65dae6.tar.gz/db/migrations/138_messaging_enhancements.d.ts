/**
 * Migration: Messaging System Enhancements
 *
 * Adds comprehensive messaging features:
 * - Message receipts (delivery + read)
 * - Message reactions
 * - Message editing history
 * - Full-text search
 * - Voice messages support
 * - Link previews
 * - Stickers/GIFs
 * - Scheduled messages
 * - Disappearing messages
 * - Push notifications
 * - Notification preferences
 * - Message reporting
 * - Channels for crews
 * - Message analytics
 */
export declare function migrate(): Promise<void>;
