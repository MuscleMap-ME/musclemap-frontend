/**
 * Migration 158: End-to-End Encrypted Secure Messaging System
 *
 * Implements:
 * - E2EE key management (Signal Protocol compatible)
 * - Encrypted message storage (server cannot read content)
 * - External file attachment metadata (files stored on R2/IPFS)
 * - NSFW content moderation infrastructure
 * - Age verification and minor protection
 * - Granular privacy controls
 * - Trust scoring for anti-abuse
 *
 * DESTRUCTIVE: Down migration drops E2EE tables and columns - intentional for rollback capability
 */
export declare function up(): Promise<void>;
export declare function down(): Promise<void>;
