/**
 * Migration 155: Social Foundation
 *
 * Phase 1 of the Community Engagement Master Plan
 * Creates core social infrastructure:
 * - activity_feed: Real-time social activity feed
 * - user_follows: Following system for users
 * - feed_preferences: User feed customization
 * - activity_comments: Comments on feed items
 *
 * DESTRUCTIVE: down() drops all Phase 1 social tables - acknowledged for rollback capability
 */
export declare function up(): Promise<void>;
export declare function down(): Promise<void>;
