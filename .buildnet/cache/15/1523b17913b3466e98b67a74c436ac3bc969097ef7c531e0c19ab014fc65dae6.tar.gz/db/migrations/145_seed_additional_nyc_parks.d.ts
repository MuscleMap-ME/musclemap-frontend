/**
 * Migration: Seed Additional NYC Calisthenics Parks
 *
 * Adds more well-known NYC outdoor fitness locations across all 5 boroughs.
 */
export declare function migrate(): Promise<void>;
export declare function rollback(): Promise<void>;
