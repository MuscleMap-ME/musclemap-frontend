/**
 * Migration: Periodization Engine
 *
 * Creates tables for training cycles, phases, weeks, and
 * user exercise preferences for AI-powered prescription learning.
 * Supports block, DUP, and linear periodization models.
 */
export declare function up(): Promise<void>;
export declare function down(): Promise<void>;
