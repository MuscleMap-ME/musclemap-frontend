"use strict";
// DESTRUCTIVE: Schema modification for system settings - contains DROP/TRUNCATE operations
/**
 * Migration 128: System Settings Table
 *
 * Creates a system_settings table to store application-wide settings
 * like maintenance mode, read-only mode, and other configuration.
 *
 * This provides database durability for emergency mode settings
 * when Redis is unavailable.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.up = up;
exports.down = down;
const client_1 = require("../client");
const logger_1 = require("../../lib/logger");
const log = logger_1.loggers.db;
async function up() {
    log.info('Running migration 128: System Settings Table');
    // Create system_settings table for emergency modes and other global settings
    await (0, client_1.query)(`
    CREATE TABLE IF NOT EXISTS system_settings (
      key VARCHAR(255) PRIMARY KEY,
      value TEXT NOT NULL,
      description TEXT,
      updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
      updated_by TEXT REFERENCES users(id) ON DELETE SET NULL,
      created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
    )
  `);
    // Add index for quick lookups
    await (0, client_1.query)(`
    CREATE INDEX IF NOT EXISTS idx_system_settings_updated_at
    ON system_settings(updated_at DESC)
  `);
    // Add comment for documentation
    await (0, client_1.query)(`
    COMMENT ON TABLE system_settings IS 'Global system settings including emergency modes (maintenance, read-only)'
  `);
    // Insert default values for emergency modes
    await (0, client_1.query)(`
    INSERT INTO system_settings (key, value, description)
    VALUES
      ('maintenance_mode', 'false', 'When true, returns 503 for all non-admin requests'),
      ('read_only_mode', 'false', 'When true, blocks all POST/PUT/DELETE/PATCH for non-admins')
    ON CONFLICT (key) DO NOTHING
  `);
    log.info('Migration 128 complete: System Settings Table created');
}
async function down() {
    log.info('Rolling back migration 128: System Settings Table');
    await (0, client_1.query)('DROP TABLE IF EXISTS system_settings CASCADE');
    log.info('Migration 128 rolled back');
}
//# sourceMappingURL=128_system_settings.js.map