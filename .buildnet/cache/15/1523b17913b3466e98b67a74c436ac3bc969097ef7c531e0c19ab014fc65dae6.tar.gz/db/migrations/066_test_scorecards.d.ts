/**
 * Migration: Test Scorecards System
 *
 * Adds table for storing API test scorecard results,
 * used by the Empire Dashboard to track test health over time.
 */
export declare function up(): Promise<void>;
export declare function down(): Promise<void>;
