/**
 * Migration 108: Security Audit System
 *
 * Creates infrastructure for security monitoring and management:
 * 1. IP blocklist table
 * 2. Security audit log table
 * 3. Failed login attempts table
 * 4. User sessions table
 * 5. Rate limit configuration table
 * 6. Proper indexes for all tables
 */
export declare function up(): Promise<void>;
export declare function down(): Promise<void>;
