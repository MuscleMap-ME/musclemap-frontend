/**
 * Migration: Exercise Images from wger.de
 *
 * Adds image_url and wger_id fields to exercises table to support
 * exercise illustrations from the wger.de open-source fitness database.
 *
 * wger.de provides CC-BY-SA licensed exercise images that we can use
 * to show animated GIF demonstrations for exercises.
 */
export declare function up(): Promise<void>;
export declare function down(): Promise<void>;
