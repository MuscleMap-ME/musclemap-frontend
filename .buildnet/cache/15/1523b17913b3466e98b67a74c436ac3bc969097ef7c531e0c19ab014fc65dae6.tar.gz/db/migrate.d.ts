/**
 * Database Migration Script
 *
 * Initializes PostgreSQL schema and runs migrations.
 * Usage: pnpm db:migrate
 */
/**
 * Ensure migrations table exists
 */
declare function ensureMigrationsTable(): Promise<void>;
/**
 * Get list of applied migrations
 */
declare function getAppliedMigrations(): Promise<string[]>;
/**
 * Main migration runner
 */
declare function migrate(): Promise<void>;
export { migrate, ensureMigrationsTable, getAppliedMigrations };
