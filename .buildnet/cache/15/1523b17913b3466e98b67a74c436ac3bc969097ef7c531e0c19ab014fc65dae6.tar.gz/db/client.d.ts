/**
 * PostgreSQL Database Client
 *
 * Optimized for high concurrency with:
 * - Connection pooling with tuned parameters
 * - Statement timeout protection
 * - Idle connection management
 * - Pool monitoring and metrics
 * - Transaction retry with exponential backoff
 * - Advisory locks for distributed locking
 */
import { Pool, PoolClient } from 'pg';
export interface PoolMetrics {
    totalConnections: number;
    idleConnections: number;
    waitingClients: number;
}
/**
 * Initialize the connection pool
 */
export declare function initializePool(): Promise<void>;
/**
 * Get pool metrics for monitoring
 */
export declare function getPoolMetrics(): PoolMetrics;
/**
 * Check if pool is healthy
 */
export declare function isPoolHealthy(): Promise<boolean>;
export interface DbQueryResult<T = Record<string, unknown>> {
    rows: T[];
    rowCount: number | null;
}
/**
 * Get a promise that resolves when pool is ready.
 * Useful for ensuring pool is initialized before use.
 */
export declare function ensurePoolReady(): Promise<void>;
/**
 * Database interface that provides query methods
 */
export declare const db: {
    /**
     * Execute a query with parameters
     */
    query<T = Record<string, unknown>>(sql: string, params?: unknown[]): Promise<DbQueryResult<T>>;
    /**
     * Get a single row from query result
     */
    queryOne<T = Record<string, unknown>>(sql: string, params?: unknown[]): Promise<T | undefined>;
    /**
     * Get all rows from query result
     */
    queryAll<T = Record<string, unknown>>(sql: string, params?: unknown[]): Promise<T[]>;
    /**
     * Execute a statement (INSERT, UPDATE, DELETE) and return affected row count
     */
    execute(sql: string, params?: unknown[]): Promise<number>;
    /**
     * Get a client from the pool for transactions
     */
    getClient(): Promise<PoolClient>;
    /**
     * Get the underlying pool for advanced usage
     */
    getPool(): Pool;
};
/**
 * Execute a function within a transaction with automatic retry on serialization failure
 *
 * PgBouncer Compatibility:
 * - Uses a single client for all retry attempts (required for transaction mode)
 * - Releases the client only after all retries complete or succeed
 * - Uses jittered exponential backoff to reduce contention
 */
export declare function transaction<T>(fn: (client: PoolClient) => Promise<T>, options?: {
    retries?: number;
    isolationLevel?: 'READ COMMITTED' | 'REPEATABLE READ' | 'SERIALIZABLE';
}): Promise<T>;
/**
 * Execute a function with advisory lock for distributed locking
 */
export declare function withAdvisoryLock<T>(lockId: number, fn: () => Promise<T>, timeout?: number): Promise<T>;
/**
 * Close the database pool
 */
export declare function closePool(): Promise<void>;
export declare const closeDatabase: typeof closePool;
export declare function query<T = Record<string, unknown>>(sql: string, params?: unknown[]): Promise<DbQueryResult<T>>;
export declare function queryOne<T = Record<string, unknown>>(sql: string, params?: unknown[]): Promise<T | undefined>;
export declare function queryAll<T = Record<string, unknown>>(sql: string, params?: unknown[]): Promise<T[]>;
export declare function execute(sql: string, params?: unknown[]): Promise<number>;
export declare const healthCheck: typeof isPoolHealthy;
export declare const getPoolStats: typeof getPoolMetrics;
/**
 * Execute a function within a SERIALIZABLE transaction with automatic retry
 */
export declare function serializableTransaction<T>(fn: (client: PoolClient) => Promise<T>, options?: {
    retries?: number;
}): Promise<T>;
