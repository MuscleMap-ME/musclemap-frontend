/**
 * Extended Exercises Seed Script
 *
 * Run with: npx tsx src/db/seed-extended.ts
 */
/**
 * Seed extended exercises and activations
 */
export declare function seedExtendedExercises(): Promise<void>;
