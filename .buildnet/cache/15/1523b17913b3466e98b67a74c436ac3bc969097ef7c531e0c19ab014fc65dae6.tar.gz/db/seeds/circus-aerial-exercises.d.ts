/**
 * Circus Arts & Aerial Exercise Seeds
 *
 * 60+ exercises based on training methodologies from:
 * - Cirque du Soleil conditioning programs
 * - Professional aerial arts training
 * - Circus arts academies
 * - Contortion and flexibility science
 */
import { ExerciseSeed, ActivationSeed } from './climbing-gymnastics-exercises';
export declare const aerialSilksExercises: ExerciseSeed[];
export declare const trapezeExercises: ExerciseSeed[];
export declare const aerialHoopExercises: ExerciseSeed[];
export declare const contortionExercises: ExerciseSeed[];
export declare const handBalancingExercises: ExerciseSeed[];
export declare const allCircusAerialExercises: ExerciseSeed[];
export declare const circusAerialActivations: ActivationSeed[];
