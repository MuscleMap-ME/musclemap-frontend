"use strict";
/**
 * Journey Progression Chains Seed File
 *
 * This file exports the seed data for journey progression chains.
 * The actual seeding is done in migration 133_journey_progression_chains.ts
 *
 * Chains included:
 * - Weight Loss Chain: Lose 10 lbs -> Lose 20 lbs -> Lose 50 lbs -> Maintain Weight
 * - Muscle Building Chain: Gain 5 lbs -> Gain 10 lbs -> Gain 15 lbs -> Gain 30 lbs -> Maintain
 * - Strength Chain: Beginner -> Intermediate -> Advanced -> Elite
 * - Running Chain: Couch to 5K -> 10K -> Half Marathon -> Marathon
 * - Pull-up Chain: First Pull-up -> 10 Pull-ups -> 20 Pull-ups -> Weighted Pull-ups
 * - Push-up Chain: First Push-up -> 25 Push-ups -> 50 Push-ups -> 100 Push-ups
 * - Flexibility Chain: Touch Toes -> Front Splits -> Middle Splits -> Full Mobility Mastery
 * - Plank Chain: 60 Second Plank -> 5 Minute Plank
 * - Rehab to Fitness: From Couch -> Beginner Strength -> Couch to 5K
 *
 * Total estimated completion time for longest chains: 2-3 years
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.chainMetadata = exports.allProgressionChains = exports.rehabToFitnessChain = exports.plankChain = exports.flexibilityChain = exports.pushUpChain = exports.pullUpChain = exports.runningChain = exports.strengthChain = exports.muscleBuildingChain = exports.weightLossChain = void 0;
exports.getChainMetadata = getChainMetadata;
exports.getChainsByName = getChainsByName;
exports.getNextJourneyInChain = getNextJourneyInChain;
exports.isChainStart = isChainStart;
exports.isChainEnd = isChainEnd;
// ============================================
// WEIGHT LOSS CHAIN
// Estimated duration: 18-24 months total
// ============================================
exports.weightLossChain = [
    {
        chain_name: 'weight_loss_progression',
        chain_description: 'Progressive weight loss journey from 10 lbs to sustainable maintenance',
        chain_order: 0,
        source_journey_template_id: 'lose_10_lbs',
        target_journey_template_id: 'lose_20_lbs',
        unlock_criteria: { completion_percentage: 100, min_milestones: 3 },
        bonus_xp: 200,
        bonus_credits: 50,
        icon: '🏋️',
        color: '#4CAF50',
        is_featured: true,
    },
    {
        chain_name: 'weight_loss_progression',
        chain_description: 'Progressive weight loss journey from 10 lbs to sustainable maintenance',
        chain_order: 1,
        source_journey_template_id: 'lose_20_lbs',
        target_journey_template_id: 'lose_50_lbs',
        unlock_criteria: { completion_percentage: 100, min_milestones: 3 },
        bonus_xp: 300,
        bonus_credits: 75,
        icon: '🏋️',
        color: '#4CAF50',
    },
    {
        chain_name: 'weight_loss_progression',
        chain_description: 'Progressive weight loss journey from 10 lbs to sustainable maintenance',
        chain_order: 2,
        source_journey_template_id: 'lose_50_lbs',
        target_journey_template_id: 'maintain_weight_journey',
        unlock_criteria: { completion_percentage: 100, min_days_active: 180 },
        bonus_xp: 500,
        bonus_credits: 150,
        unlock_achievement_key: 'chain_complete',
        icon: '🏋️',
        color: '#4CAF50',
    },
];
// ============================================
// MUSCLE BUILDING CHAIN
// Estimated duration: 24-36 months total
// ============================================
exports.muscleBuildingChain = [
    {
        chain_name: 'muscle_building_progression',
        chain_description: 'Progressive muscle gain from beginner to elite level',
        chain_order: 0,
        source_journey_template_id: 'gain_5_lbs_muscle',
        target_journey_template_id: 'gain_10_lbs_muscle',
        unlock_criteria: { completion_percentage: 100, min_days_active: 60 },
        bonus_xp: 200,
        bonus_credits: 50,
        icon: '💪',
        color: '#FF5722',
        is_featured: true,
    },
    {
        chain_name: 'muscle_building_progression',
        chain_description: 'Progressive muscle gain from beginner to elite level',
        chain_order: 1,
        source_journey_template_id: 'gain_10_lbs_muscle',
        target_journey_template_id: 'gain_15_lbs_muscle',
        unlock_criteria: { completion_percentage: 100, min_days_active: 120 },
        bonus_xp: 300,
        bonus_credits: 75,
        icon: '💪',
        color: '#FF5722',
    },
    {
        chain_name: 'muscle_building_progression',
        chain_description: 'Progressive muscle gain from beginner to elite level',
        chain_order: 2,
        source_journey_template_id: 'gain_15_lbs_muscle',
        target_journey_template_id: 'gain_30_lbs_muscle',
        unlock_criteria: { completion_percentage: 100, min_days_active: 180 },
        bonus_xp: 400,
        bonus_credits: 100,
        icon: '💪',
        color: '#FF5722',
    },
    {
        chain_name: 'muscle_building_progression',
        chain_description: 'Progressive muscle gain from beginner to elite level',
        chain_order: 3,
        source_journey_template_id: 'gain_30_lbs_muscle',
        target_journey_template_id: 'maintain_muscle',
        unlock_criteria: { completion_percentage: 100, min_days_active: 270 },
        bonus_xp: 600,
        bonus_credits: 175,
        unlock_achievement_key: 'chain_complete',
        icon: '💪',
        color: '#FF5722',
    },
];
// ============================================
// STRENGTH PROGRESSION CHAIN
// Estimated duration: 18-24 months total
// ============================================
exports.strengthChain = [
    {
        chain_name: 'strength_progression',
        chain_description: 'Build strength from beginner to elite level',
        chain_order: 0,
        source_journey_template_id: 'beginner_strength',
        target_journey_template_id: 'intermediate_strength',
        unlock_criteria: { completion_percentage: 100, min_milestones: 3 },
        bonus_xp: 200,
        bonus_credits: 50,
        icon: '🔱',
        color: '#9C27B0',
        is_featured: true,
    },
    {
        chain_name: 'strength_progression',
        chain_description: 'Build strength from beginner to elite level',
        chain_order: 1,
        source_journey_template_id: 'intermediate_strength',
        target_journey_template_id: 'advanced_strength',
        unlock_criteria: { completion_percentage: 100, min_days_active: 90 },
        bonus_xp: 350,
        bonus_credits: 85,
        icon: '🔱',
        color: '#9C27B0',
    },
    {
        chain_name: 'strength_progression',
        chain_description: 'Build strength from beginner to elite level',
        chain_order: 2,
        source_journey_template_id: 'advanced_strength',
        target_journey_template_id: 'elite_strength',
        unlock_criteria: { completion_percentage: 100, min_days_active: 180 },
        bonus_xp: 600,
        bonus_credits: 175,
        unlock_achievement_key: 'chain_complete',
        icon: '🔱',
        color: '#9C27B0',
    },
];
// ============================================
// RUNNING CHAIN (Couch to Marathon)
// Estimated duration: 12-18 months total
// ============================================
exports.runningChain = [
    {
        chain_name: 'running_progression',
        chain_description: 'From couch to marathon - the ultimate running journey',
        chain_order: 0,
        source_journey_template_id: 'couch_to_5k',
        target_journey_template_id: 'run_10k',
        unlock_criteria: { completion_percentage: 100, min_milestones: 4 },
        bonus_xp: 250,
        bonus_credits: 60,
        icon: '🏃',
        color: '#2196F3',
        is_featured: true,
    },
    {
        chain_name: 'running_progression',
        chain_description: 'From couch to marathon - the ultimate running journey',
        chain_order: 1,
        source_journey_template_id: 'run_10k',
        target_journey_template_id: 'run_half_marathon',
        unlock_criteria: { completion_percentage: 100, min_days_active: 60 },
        bonus_xp: 400,
        bonus_credits: 100,
        icon: '🏃',
        color: '#2196F3',
    },
    {
        chain_name: 'running_progression',
        chain_description: 'From couch to marathon - the ultimate running journey',
        chain_order: 2,
        source_journey_template_id: 'run_half_marathon',
        target_journey_template_id: 'run_marathon',
        unlock_criteria: { completion_percentage: 100, min_days_active: 90 },
        bonus_xp: 750,
        bonus_credits: 200,
        unlock_achievement_key: 'chain_complete',
        icon: '🏃',
        color: '#2196F3',
    },
];
// ============================================
// PULL-UP MASTERY CHAIN
// Estimated duration: 12-18 months total
// ============================================
exports.pullUpChain = [
    {
        chain_name: 'pullup_progression',
        chain_description: 'Master the pull-up from zero to weighted',
        chain_order: 0,
        source_journey_template_id: 'first_pullup',
        target_journey_template_id: 'pullups_10',
        unlock_criteria: { completion_percentage: 100, min_milestones: 3 },
        bonus_xp: 200,
        bonus_credits: 50,
        icon: '🎯',
        color: '#E91E63',
        is_featured: true,
    },
    {
        chain_name: 'pullup_progression',
        chain_description: 'Master the pull-up from zero to weighted',
        chain_order: 1,
        source_journey_template_id: 'pullups_10',
        target_journey_template_id: 'pullups_20',
        unlock_criteria: { completion_percentage: 100, min_days_active: 60 },
        bonus_xp: 350,
        bonus_credits: 85,
        icon: '🎯',
        color: '#E91E63',
    },
    {
        chain_name: 'pullup_progression',
        chain_description: 'Master the pull-up from zero to weighted',
        chain_order: 2,
        source_journey_template_id: 'pullups_20',
        target_journey_template_id: 'weighted_pullups',
        unlock_criteria: { completion_percentage: 100, min_days_active: 90 },
        bonus_xp: 500,
        bonus_credits: 150,
        unlock_achievement_key: 'chain_complete',
        icon: '🎯',
        color: '#E91E63',
    },
];
// ============================================
// PUSH-UP MASTERY CHAIN
// Estimated duration: 9-15 months total
// ============================================
exports.pushUpChain = [
    {
        chain_name: 'pushup_progression',
        chain_description: 'Master the push-up from first rep to 100',
        chain_order: 0,
        source_journey_template_id: 'first_pushup',
        target_journey_template_id: 'pushups_25',
        unlock_criteria: { completion_percentage: 100, min_milestones: 3 },
        bonus_xp: 150,
        bonus_credits: 40,
        icon: '✊',
        color: '#FF9800',
        is_featured: true,
    },
    {
        chain_name: 'pushup_progression',
        chain_description: 'Master the push-up from first rep to 100',
        chain_order: 1,
        source_journey_template_id: 'pushups_25',
        target_journey_template_id: 'pushups_50',
        unlock_criteria: { completion_percentage: 100, min_days_active: 45 },
        bonus_xp: 250,
        bonus_credits: 60,
        icon: '✊',
        color: '#FF9800',
    },
    {
        chain_name: 'pushup_progression',
        chain_description: 'Master the push-up from first rep to 100',
        chain_order: 2,
        source_journey_template_id: 'pushups_50',
        target_journey_template_id: 'pushups_100',
        unlock_criteria: { completion_percentage: 100, min_days_active: 60 },
        bonus_xp: 500,
        bonus_credits: 125,
        unlock_achievement_key: 'chain_complete',
        icon: '✊',
        color: '#FF9800',
    },
];
// ============================================
// FLEXIBILITY CHAIN
// Estimated duration: 12-18 months total
// ============================================
exports.flexibilityChain = [
    {
        chain_name: 'flexibility_progression',
        chain_description: 'Develop full-body flexibility from basics to advanced',
        chain_order: 0,
        source_journey_template_id: 'touch_toes',
        target_journey_template_id: 'front_splits',
        unlock_criteria: { completion_percentage: 100, min_days_active: 30 },
        bonus_xp: 200,
        bonus_credits: 50,
        icon: '🧘',
        color: '#00BCD4',
        is_featured: true,
    },
    {
        chain_name: 'flexibility_progression',
        chain_description: 'Develop full-body flexibility from basics to advanced',
        chain_order: 1,
        source_journey_template_id: 'front_splits',
        target_journey_template_id: 'middle_splits',
        unlock_criteria: { completion_percentage: 100, min_days_active: 120 },
        bonus_xp: 400,
        bonus_credits: 100,
        icon: '🧘',
        color: '#00BCD4',
    },
    {
        chain_name: 'flexibility_progression',
        chain_description: 'Develop full-body flexibility from basics to advanced',
        chain_order: 2,
        source_journey_template_id: 'middle_splits',
        target_journey_template_id: 'full_mobility_mastery',
        unlock_criteria: { completion_percentage: 100, min_days_active: 180 },
        bonus_xp: 600,
        bonus_credits: 175,
        unlock_achievement_key: 'chain_complete',
        icon: '🧘',
        color: '#00BCD4',
    },
];
// ============================================
// PLANK ENDURANCE CHAIN
// Estimated duration: 6-12 months total
// ============================================
exports.plankChain = [
    {
        chain_name: 'plank_progression',
        chain_description: 'Build core endurance from 60 seconds to 5 minutes',
        chain_order: 0,
        source_journey_template_id: 'plank_60s',
        target_journey_template_id: 'plank_5min',
        unlock_criteria: { completion_percentage: 100, min_days_active: 30 },
        bonus_xp: 350,
        bonus_credits: 85,
        unlock_achievement_key: 'chain_complete',
        icon: '🪑',
        color: '#795548',
    },
];
// ============================================
// REHABILITATION TO FITNESS CHAIN
// Estimated duration: 6-12 months total
// ============================================
exports.rehabToFitnessChain = [
    {
        chain_name: 'rehab_to_fitness',
        chain_description: 'Transition from sedentary to full fitness',
        chain_order: 0,
        source_journey_template_id: 'from_couch',
        target_journey_template_id: 'beginner_strength',
        unlock_criteria: { completion_percentage: 100, min_days_active: 45 },
        bonus_xp: 300,
        bonus_credits: 75,
        icon: '🌱',
        color: '#8BC34A',
    },
    {
        chain_name: 'rehab_to_fitness',
        chain_description: 'Transition from sedentary to full fitness',
        chain_order: 1,
        source_journey_template_id: 'beginner_strength',
        target_journey_template_id: 'couch_to_5k',
        unlock_criteria: { completion_percentage: 100, min_days_active: 60 },
        bonus_xp: 400,
        bonus_credits: 100,
        unlock_achievement_key: 'chain_complete',
        icon: '🌱',
        color: '#8BC34A',
    },
];
// ============================================
// COMBINE ALL CHAINS
// ============================================
exports.allProgressionChains = [
    ...exports.weightLossChain,
    ...exports.muscleBuildingChain,
    ...exports.strengthChain,
    ...exports.runningChain,
    ...exports.pullUpChain,
    ...exports.pushUpChain,
    ...exports.flexibilityChain,
    ...exports.plankChain,
    ...exports.rehabToFitnessChain,
];
// ============================================
// CHAIN METADATA FOR DISPLAY
// ============================================
exports.chainMetadata = [
    {
        name: 'weight_loss_progression',
        displayName: 'Weight Loss Journey',
        description: 'Progressive weight loss from 10 lbs to sustainable maintenance',
        stages: 4,
        estimatedDuration: '18-24 months',
        difficulty: 'intermediate',
        icon: '🏋️',
        color: '#4CAF50',
    },
    {
        name: 'muscle_building_progression',
        displayName: 'Muscle Building Path',
        description: 'Build muscle mass from beginner to elite level',
        stages: 5,
        estimatedDuration: '24-36 months',
        difficulty: 'advanced',
        icon: '💪',
        color: '#FF5722',
    },
    {
        name: 'strength_progression',
        displayName: 'Strength Mastery',
        description: 'Develop strength from novice to elite powerlifter',
        stages: 4,
        estimatedDuration: '18-24 months',
        difficulty: 'intermediate',
        icon: '🔱',
        color: '#9C27B0',
    },
    {
        name: 'running_progression',
        displayName: 'Couch to Marathon',
        description: 'The ultimate running journey from 0 to 42.2 km',
        stages: 4,
        estimatedDuration: '12-18 months',
        difficulty: 'intermediate',
        icon: '🏃',
        color: '#2196F3',
    },
    {
        name: 'pullup_progression',
        displayName: 'Pull-up Mastery',
        description: 'Master the pull-up from zero to weighted reps',
        stages: 4,
        estimatedDuration: '12-18 months',
        difficulty: 'intermediate',
        icon: '🎯',
        color: '#E91E63',
    },
    {
        name: 'pushup_progression',
        displayName: 'Push-up Champion',
        description: 'Progress from first push-up to 100 consecutive reps',
        stages: 4,
        estimatedDuration: '9-15 months',
        difficulty: 'beginner',
        icon: '✊',
        color: '#FF9800',
    },
    {
        name: 'flexibility_progression',
        displayName: 'Flexibility Evolution',
        description: 'Develop full-body flexibility and mobility',
        stages: 4,
        estimatedDuration: '12-18 months',
        difficulty: 'intermediate',
        icon: '🧘',
        color: '#00BCD4',
    },
    {
        name: 'plank_progression',
        displayName: 'Plank Endurance',
        description: 'Build core endurance from 60 seconds to 5 minutes',
        stages: 2,
        estimatedDuration: '6-12 months',
        difficulty: 'beginner',
        icon: '🪑',
        color: '#795548',
    },
    {
        name: 'rehab_to_fitness',
        displayName: 'Recovery to Fitness',
        description: 'Transition from sedentary to active lifestyle',
        stages: 3,
        estimatedDuration: '6-12 months',
        difficulty: 'beginner',
        icon: '🌱',
        color: '#8BC34A',
    },
];
// ============================================
// HELPER FUNCTIONS
// ============================================
/**
 * Get the chain metadata for a given chain name
 */
function getChainMetadata(chainName) {
    return exports.chainMetadata.find((m) => m.name === chainName);
}
/**
 * Get all chains in a specific progression
 */
function getChainsByName(chainName) {
    return exports.allProgressionChains
        .filter((c) => c.chain_name === chainName)
        .sort((a, b) => a.chain_order - b.chain_order);
}
/**
 * Get the next journey template ID in a chain after completing the source
 */
function getNextJourneyInChain(chainName, sourceJourneyTemplateId) {
    const chain = exports.allProgressionChains.find((c) => c.chain_name === chainName && c.source_journey_template_id === sourceJourneyTemplateId);
    return chain?.target_journey_template_id;
}
/**
 * Check if a journey is the start of any chain
 */
function isChainStart(journeyTemplateId) {
    return exports.allProgressionChains.some((c) => c.source_journey_template_id === journeyTemplateId && c.chain_order === 0);
}
/**
 * Check if a journey is the end of any chain
 */
function isChainEnd(journeyTemplateId) {
    const asTarget = exports.allProgressionChains.filter((c) => c.target_journey_template_id === journeyTemplateId);
    // It's the end if it's a target but not a source
    return asTarget.some((targetChain) => !exports.allProgressionChains.some((c) => c.chain_name === targetChain.chain_name &&
        c.source_journey_template_id === journeyTemplateId));
}
// ============================================
// EXPORT DEFAULT
// ============================================
exports.default = {
    progressionChains: exports.allProgressionChains,
    chainMetadata: exports.chainMetadata,
    chains: {
        weightLoss: exports.weightLossChain,
        muscleBuilding: exports.muscleBuildingChain,
        strength: exports.strengthChain,
        running: exports.runningChain,
        pullUp: exports.pullUpChain,
        pushUp: exports.pushUpChain,
        flexibility: exports.flexibilityChain,
        plank: exports.plankChain,
        rehabToFitness: exports.rehabToFitnessChain,
    },
    helpers: {
        getChainMetadata,
        getChainsByName,
        getNextJourneyInChain,
        isChainStart,
        isChainEnd,
    },
    // Statistics about the seed data
    stats: {
        totalChainSteps: exports.allProgressionChains.length,
        uniqueChains: exports.chainMetadata.length,
        byChain: {
            weight_loss_progression: exports.weightLossChain.length,
            muscle_building_progression: exports.muscleBuildingChain.length,
            strength_progression: exports.strengthChain.length,
            running_progression: exports.runningChain.length,
            pullup_progression: exports.pullUpChain.length,
            pushup_progression: exports.pushUpChain.length,
            flexibility_progression: exports.flexibilityChain.length,
            plank_progression: exports.plankChain.length,
            rehab_to_fitness: exports.rehabToFitnessChain.length,
        },
        totalBonusXp: exports.allProgressionChains.reduce((sum, c) => sum + c.bonus_xp, 0),
        totalBonusCredits: exports.allProgressionChains.reduce((sum, c) => sum + (c.bonus_credits || 0), 0),
        featuredChains: exports.allProgressionChains.filter((c) => c.is_featured).length,
    },
};
//# sourceMappingURL=journey-chains.js.map