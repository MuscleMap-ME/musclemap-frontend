/**
 * Achievement Definitions Seed File
 *
 * 50+ achievements across 8 categories covering all aspects of the MuscleMap experience.
 *
 * Categories:
 * - milestone: Workout counts and general progress markers
 * - streak: Consistency achievements for consecutive day activity
 * - record: Personal records and strength milestones
 * - first_time: First-time accomplishments
 * - social: Community engagement achievements
 * - top_rank: Leaderboard and competition achievements
 * - special: Holiday and rare achievements
 * - nutrition: Nutrition-related achievements (if enabled)
 *
 * Tiers: bronze (50 XP), silver (100 XP), gold (250 XP), platinum (500 XP), diamond (1000 XP)
 * Rarity: common (60%), uncommon (25%), rare (10%), epic (4%), legendary (1%)
 */
export interface AchievementSeed {
    key: string;
    name: string;
    description: string;
    category: 'milestone' | 'streak' | 'record' | 'first_time' | 'social' | 'top_rank' | 'special' | 'nutrition';
    tier: 'bronze' | 'silver' | 'gold' | 'platinum' | 'diamond';
    rarity: 'common' | 'uncommon' | 'rare' | 'epic' | 'legendary';
    points: number;
    icon: string;
    enabled?: boolean;
    requires_verification?: boolean;
}
export declare const TIER_XP_REWARDS: {
    readonly bronze: 50;
    readonly silver: 100;
    readonly gold: 250;
    readonly platinum: 500;
    readonly diamond: 1000;
};
export declare const workoutMilestoneAchievements: AchievementSeed[];
export declare const streakAchievements: AchievementSeed[];
export declare const strengthRecordAchievements: AchievementSeed[];
export declare const volumeAchievements: AchievementSeed[];
export declare const exerciseMasteryAchievements: AchievementSeed[];
export declare const socialAchievements: AchievementSeed[];
export declare const journeyAchievements: AchievementSeed[];
export declare const specialAchievements: AchievementSeed[];
export declare const topRankAchievements: AchievementSeed[];
export declare const firstTimeAchievements: AchievementSeed[];
export declare const allAchievements: AchievementSeed[];
declare const _default: {
    achievements: AchievementSeed[];
    tiers: {
        readonly bronze: 50;
        readonly silver: 100;
        readonly gold: 250;
        readonly platinum: 500;
        readonly diamond: 1000;
    };
    stats: {
        total: number;
        byCategory: {
            milestone: number;
            streak: number;
            record: number;
            first_time: number;
            social: number;
            top_rank: number;
            special: number;
        };
        byTier: {
            bronze: number;
            silver: number;
            gold: number;
            platinum: number;
            diamond: number;
        };
        byRarity: {
            common: number;
            uncommon: number;
            rare: number;
            epic: number;
            legendary: number;
        };
    };
};
export default _default;
