/**
 * Olympic Weightlifting, Wrestling & Combat Sports Exercise Seeds
 *
 * 100+ exercises based on training methodologies from:
 * - USA Weightlifting
 * - NSCA Olympic lifting progressions
 * - NCAA wrestling strength programs
 * - Combat sports conditioning research
 */
import { ExerciseSeed, ActivationSeed } from './climbing-gymnastics-exercises';
export declare const olympicWeightliftingExercises: ExerciseSeed[];
export declare const wrestlingExercises: ExerciseSeed[];
export declare const combatConditioningExercises: ExerciseSeed[];
export declare const allOlympicWrestlingExercises: ExerciseSeed[];
export declare const olympicWrestlingActivations: ActivationSeed[];
