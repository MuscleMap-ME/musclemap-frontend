/**
 * Climbing & Gymnastics Exercise Seeds
 *
 * 150+ exercises for climbing, gymnastics, and calisthenics skill training.
 * Based on research from Eric Horst, Eva Lopez, GMB, and gymnastics conditioning manuals.
 */
export interface ExerciseSeed {
    id: string;
    name: string;
    type: string;
    difficulty: number;
    primaryMuscles: string;
    description: string;
    cues: string;
    equipmentRequired?: string[];
    equipmentOptional?: string[];
    locations?: string[];
    movementPattern?: string;
    skillLevel?: string;
    sourceMethodology?: string;
    regressionExercise?: string;
    progressionExercise?: string;
}
export interface ActivationSeed {
    exerciseId: string;
    muscleId: string;
    activation: number;
}
export declare const climbingExercises: ExerciseSeed[];
export declare const gymnasticsExercises: ExerciseSeed[];
export declare const calisthenicsExercises: ExerciseSeed[];
export declare const allClimbingGymnasticsExercises: ExerciseSeed[];
export declare const climbingGymnasticsActivations: ActivationSeed[];
declare const _default: {
    exercises: ExerciseSeed[];
    activations: ActivationSeed[];
};
export default _default;
