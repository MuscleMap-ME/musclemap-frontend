/**
 * Journey Progression Chains Seed File
 *
 * This file exports the seed data for journey progression chains.
 * The actual seeding is done in migration 133_journey_progression_chains.ts
 *
 * Chains included:
 * - Weight Loss Chain: Lose 10 lbs -> Lose 20 lbs -> Lose 50 lbs -> Maintain Weight
 * - Muscle Building Chain: Gain 5 lbs -> Gain 10 lbs -> Gain 15 lbs -> Gain 30 lbs -> Maintain
 * - Strength Chain: Beginner -> Intermediate -> Advanced -> Elite
 * - Running Chain: Couch to 5K -> 10K -> Half Marathon -> Marathon
 * - Pull-up Chain: First Pull-up -> 10 Pull-ups -> 20 Pull-ups -> Weighted Pull-ups
 * - Push-up Chain: First Push-up -> 25 Push-ups -> 50 Push-ups -> 100 Push-ups
 * - Flexibility Chain: Touch Toes -> Front Splits -> Middle Splits -> Full Mobility Mastery
 * - Plank Chain: 60 Second Plank -> 5 Minute Plank
 * - Rehab to Fitness: From Couch -> Beginner Strength -> Couch to 5K
 *
 * Total estimated completion time for longest chains: 2-3 years
 */
export interface UnlockCriteria {
    completion_percentage?: number;
    min_milestones?: number;
    min_days_active?: number;
    custom_condition?: string;
}
export interface JourneyProgressionChainSeed {
    chain_name: string;
    chain_description: string;
    chain_order: number;
    source_journey_template_id: string;
    target_journey_template_id: string;
    unlock_criteria: UnlockCriteria;
    bonus_xp: number;
    bonus_credits?: number;
    unlock_achievement_key?: string;
    icon?: string;
    color?: string;
    is_featured?: boolean;
}
export interface ChainMetadata {
    name: string;
    displayName: string;
    description: string;
    stages: number;
    estimatedDuration: string;
    difficulty: 'beginner' | 'intermediate' | 'advanced' | 'elite';
    icon: string;
    color: string;
}
export declare const weightLossChain: JourneyProgressionChainSeed[];
export declare const muscleBuildingChain: JourneyProgressionChainSeed[];
export declare const strengthChain: JourneyProgressionChainSeed[];
export declare const runningChain: JourneyProgressionChainSeed[];
export declare const pullUpChain: JourneyProgressionChainSeed[];
export declare const pushUpChain: JourneyProgressionChainSeed[];
export declare const flexibilityChain: JourneyProgressionChainSeed[];
export declare const plankChain: JourneyProgressionChainSeed[];
export declare const rehabToFitnessChain: JourneyProgressionChainSeed[];
export declare const allProgressionChains: JourneyProgressionChainSeed[];
export declare const chainMetadata: ChainMetadata[];
/**
 * Get the chain metadata for a given chain name
 */
export declare function getChainMetadata(chainName: string): ChainMetadata | undefined;
/**
 * Get all chains in a specific progression
 */
export declare function getChainsByName(chainName: string): JourneyProgressionChainSeed[];
/**
 * Get the next journey template ID in a chain after completing the source
 */
export declare function getNextJourneyInChain(chainName: string, sourceJourneyTemplateId: string): string | undefined;
/**
 * Check if a journey is the start of any chain
 */
export declare function isChainStart(journeyTemplateId: string): boolean;
/**
 * Check if a journey is the end of any chain
 */
export declare function isChainEnd(journeyTemplateId: string): boolean;
declare const _default: {
    progressionChains: JourneyProgressionChainSeed[];
    chainMetadata: ChainMetadata[];
    chains: {
        weightLoss: JourneyProgressionChainSeed[];
        muscleBuilding: JourneyProgressionChainSeed[];
        strength: JourneyProgressionChainSeed[];
        running: JourneyProgressionChainSeed[];
        pullUp: JourneyProgressionChainSeed[];
        pushUp: JourneyProgressionChainSeed[];
        flexibility: JourneyProgressionChainSeed[];
        plank: JourneyProgressionChainSeed[];
        rehabToFitness: JourneyProgressionChainSeed[];
    };
    helpers: {
        getChainMetadata: typeof getChainMetadata;
        getChainsByName: typeof getChainsByName;
        getNextJourneyInChain: typeof getNextJourneyInChain;
        isChainStart: typeof isChainStart;
        isChainEnd: typeof isChainEnd;
    };
    stats: {
        totalChainSteps: number;
        uniqueChains: number;
        byChain: {
            weight_loss_progression: number;
            muscle_building_progression: number;
            strength_progression: number;
            running_progression: number;
            pullup_progression: number;
            pushup_progression: number;
            flexibility_progression: number;
            plank_progression: number;
            rehab_to_fitness: number;
        };
        totalBonusXp: number;
        totalBonusCredits: number;
        featuredChains: number;
    };
};
export default _default;
