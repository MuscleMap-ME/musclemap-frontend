/**
 * Skill Progressions Seed Data
 *
 * 30+ comprehensive skill progression paths for bodyweight and strength skills.
 * Each progression defines a clear path from beginner to mastery with specific
 * targets, prerequisites, tips, and common mistakes.
 *
 * Based on gymnastics strength training (GST), calisthenics progressions,
 * and proven methodologies from Overcoming Gravity, GMB, and FitnessFAQs.
 */
export interface SkillProgressionSeed {
    skill_name: string;
    level: number;
    level_name: string;
    description: string;
    exercise_id?: string;
    target_metric: 'reps' | 'duration_seconds' | 'distance_meters' | 'weight_percentage';
    target_value: number;
    prerequisites?: string[];
    estimated_weeks_min: number;
    estimated_weeks_max: number;
    tips: string[];
    common_mistakes: string[];
    video_url?: string;
}
export declare const pullupProgression: SkillProgressionSeed[];
export declare const pushupProgression: SkillProgressionSeed[];
export declare const dipProgression: SkillProgressionSeed[];
export declare const rowProgression: SkillProgressionSeed[];
export declare const squatProgression: SkillProgressionSeed[];
export declare const dragonFlagProgression: SkillProgressionSeed[];
export declare const hollowBodyProgression: SkillProgressionSeed[];
export declare const bridgeProgression: SkillProgressionSeed[];
export declare const hangingLegRaiseProgression: SkillProgressionSeed[];
export declare const plancheLeanProgression: SkillProgressionSeed[];
export declare const ringSupportProgression: SkillProgressionSeed[];
export declare const straightArmStrengthProgression: SkillProgressionSeed[];
export declare const compressionProgression: SkillProgressionSeed[];
export declare function seedSkillProgressions(): Promise<void>;
export declare const allSkillProgressions: {
    pullup: SkillProgressionSeed[];
    pushup: SkillProgressionSeed[];
    dip: SkillProgressionSeed[];
    row: SkillProgressionSeed[];
    pistolSquat: SkillProgressionSeed[];
    dragonFlag: SkillProgressionSeed[];
    hollowBody: SkillProgressionSeed[];
    bridge: SkillProgressionSeed[];
    hangingLegRaise: SkillProgressionSeed[];
    plancheLean: SkillProgressionSeed[];
    ringSupport: SkillProgressionSeed[];
    straightArmStrength: SkillProgressionSeed[];
    compression: SkillProgressionSeed[];
};
export declare const progressionSummary: {
    totalSkills: number;
    totalLevels: number;
    skills: {
        name: string;
        levels: number;
        description: string;
    }[];
};
export default seedSkillProgressions;
