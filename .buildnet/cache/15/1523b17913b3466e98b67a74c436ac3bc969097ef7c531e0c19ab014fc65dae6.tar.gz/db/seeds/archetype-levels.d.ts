/**
 * Archetype Levels Seed Data
 *
 * Comprehensive level progression data for all 10 core archetypes.
 * Each archetype has 10 levels with:
 * - Archetype-specific level names (not generic)
 * - Progressive TU thresholds (0 to ~100,000)
 * - Motivational descriptions
 * - Priority muscle targets for that level
 *
 * Run with: pnpm -C apps/api db:seed
 */
export interface ArchetypeLevelSeed {
    identityId: string;
    level: number;
    name: string;
    totalTU: number;
    description: string;
    muscleTargets: string[];
}
export declare const allArchetypeLevels: ArchetypeLevelSeed[];
/**
 * Seed archetype levels into the database
 * Uses ON CONFLICT to upsert (update existing or insert new)
 */
export declare function seedArchetypeLevels(): Promise<void>;
/**
 * Get all levels for a specific archetype
 */
export declare function getLevelsForArchetype(archetypeId: string): ArchetypeLevelSeed[];
/**
 * Get a specific level for an archetype
 */
export declare function getLevel(archetypeId: string, level: number): ArchetypeLevelSeed | undefined;
/**
 * Get the level for a given TU amount
 */
export declare function getLevelForTU(archetypeId: string, totalTU: number): ArchetypeLevelSeed | undefined;
