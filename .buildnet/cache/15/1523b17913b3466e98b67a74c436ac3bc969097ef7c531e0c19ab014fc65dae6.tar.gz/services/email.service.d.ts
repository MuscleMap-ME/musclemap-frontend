/**
 * Email Service
 *
 * Handles all email sending via Resend
 * - Transactional emails
 * - Feedback digest emails
 * - Resolution notifications
 */
interface EmailResult {
    success: boolean;
    id?: string;
    error?: string;
}
interface FeedbackDigestItem {
    id: string;
    type: 'feature_request' | 'question' | 'general';
    title: string;
    description: string;
    username: string;
    createdAt: Date;
}
interface ResolutionNotificationData {
    feedbackId: string;
    feedbackType: string;
    title: string;
    status: string;
    resolutionMessage?: string;
    userEmail: string;
    username: string;
}
/**
 * Check if email service is configured
 */
export declare function isEmailConfigured(): boolean;
/**
 * Send a generic email
 */
export declare function sendEmail(params: {
    to: string;
    subject: string;
    html: string;
    text?: string;
}): Promise<EmailResult>;
/**
 * Send hourly feedback digest to admin
 */
export declare function sendFeedbackDigest(items: FeedbackDigestItem[]): Promise<EmailResult>;
/**
 * Send resolution notification to user
 */
export declare function sendResolutionNotification(data: ResolutionNotificationData): Promise<EmailResult>;
/**
 * Send bug fix completion notification to admin
 */
export declare function sendBugFixNotification(params: {
    feedbackId: string;
    title: string;
    success: boolean;
    filesModified?: string[];
    deployCommit?: string;
    errorMessage?: string;
}): Promise<EmailResult>;
interface BugReportDigestItem {
    id: string;
    title: string;
    description: string;
    stepsToReproduce: string | null;
    username: string;
    email: string;
    isBetaTester: boolean;
    betaTesterTier: string | null;
    betaTesterPriority: number;
    createdAt: Date;
}
/**
 * Send hourly bug report digest to admin
 * Prioritizes beta tester reports
 */
export declare function sendBugReportDigest(bugs: BugReportDigestItem[]): Promise<EmailResult>;
export declare const EmailService: {
    isConfigured: typeof isEmailConfigured;
    send: typeof sendEmail;
    sendFeedbackDigest: typeof sendFeedbackDigest;
    sendResolutionNotification: typeof sendResolutionNotification;
    sendBugFixNotification: typeof sendBugFixNotification;
    sendBugReportDigest: typeof sendBugReportDigest;
};
export {};
