/**
 * Intelligent Exercise Prescription Service
 *
 * AI-powered workout prescription engine that considers:
 * - User preferences and exercise history
 * - Progression readiness and fatigue levels
 * - Injury/limitation awareness
 * - Periodization context
 * - Movement pattern variety
 * - Equipment availability
 * - Recovery status
 */
export interface PrescriptionConstraints {
    timeAvailable: number;
    location: string;
    equipmentAvailable: string[];
    goals: string[];
    fitnessLevel: 'beginner' | 'intermediate' | 'advanced' | 'elite';
    targetMuscles?: string[];
    excludeMuscles?: string[];
    excludeExercises?: string[];
    preferCompound: boolean;
    activeInjuryIds?: string[];
    avoidBodyParts?: string[];
    maxPainTolerance?: number;
    skillsInProgress?: string[];
    allocateSkillTime?: number;
    trainingPhase?: 'accumulation' | 'intensification' | 'realization' | 'deload';
    weekInCycle?: number;
    splitDay?: 'push' | 'pull' | 'legs' | 'upper' | 'lower' | 'full_body';
    varietyPreference?: 'consistent' | 'varied' | 'highly_varied';
    intensityPreference?: 'light' | 'moderate' | 'hard' | 'very_hard';
}
export interface ScoredExercise {
    exercise: ExerciseData;
    score: number;
    reasons: string[];
}
export interface ExerciseData {
    id: string;
    name: string;
    type: string;
    difficulty: number;
    is_compound: boolean;
    estimated_seconds: number;
    rest_seconds: number;
    locations: string[];
    equipment_required: string[];
    primary_muscles: string[];
    secondary_muscles: string[];
    movement_pattern?: string;
    force_vector?: string;
    contraction_type?: string;
    skill_level?: string;
    regression_exercise?: string;
    progression_exercise?: string;
    injury_risk_areas?: string[];
    contraindications?: string[];
    optimal_rep_range_low?: number;
    optimal_rep_range_high?: number;
    typical_intensity_percent?: number;
}
export interface PrescribedExercise {
    id: string;
    name: string;
    sets: number;
    reps: string;
    restSeconds: number;
    estimatedSeconds: number;
    notes?: string;
    substituteFor?: string;
    reasons?: string[];
}
export interface IntelligentPrescription {
    exercises: PrescribedExercise[];
    warmup: WarmupExercise[];
    cooldown: CooldownExercise[];
    skillWork?: SkillWorkBlock;
    muscleCoverage: Record<string, number>;
    estimatedDuration: number;
    periodizationContext?: PeriodizationContext;
    explanation: PrescriptionExplanation;
}
export interface WarmupExercise {
    name: string;
    type: string;
    duration: number;
    description: string;
    sets: number;
    reps: string;
    restSeconds: number;
    isActivity: boolean;
}
export interface CooldownExercise {
    name: string;
    type: string;
    duration: number;
    description: string;
    sets: number;
    reps: string;
    restSeconds: number;
    isActivity: boolean;
}
export interface SkillWorkBlock {
    skillName: string;
    exercises: PrescribedExercise[];
    allocatedMinutes: number;
    currentLevel: number;
    targetMetric: string;
    targetValue: number;
}
export interface PeriodizationContext {
    phaseName: string;
    weekInPhase: number;
    volumeModifier: number;
    intensityRange: {
        low: number;
        high: number;
    };
    repRange: {
        low: number;
        high: number;
    };
    focusAreas: string[];
}
export interface PrescriptionExplanation {
    volumeAnalysis: {
        push: number;
        pull: number;
        legs: number;
        core: number;
    };
    adjustmentsMade: string[];
    avoidedExercises: {
        exerciseId: string;
        reason: string;
    }[];
    periodizationNote?: string;
    recoveryNote?: string;
}
export interface DeloadRecommendation {
    recommend: boolean;
    reason?: string;
    suggestedDuration?: string;
    suggestedVolume?: string;
    suggestedIntensity?: string;
    fatigueScore?: number;
    readinessScore?: number;
}
export interface ExerciseAlternative {
    exerciseId: string;
    name: string;
    reason: string;
    similarityScore: number;
    notes?: string;
}
/**
 * Generate an intelligent workout prescription
 */
export declare function generateIntelligentPrescription(userId: string, constraints: PrescriptionConstraints): Promise<IntelligentPrescription>;
/**
 * Get exercise alternatives based on equipment/injuries/preferences
 */
export declare function getExerciseAlternatives(exerciseId: string, userId: string, reason?: 'equipment' | 'injury' | 'preference' | 'any'): Promise<ExerciseAlternative[]>;
/**
 * Get progressive overload suggestions for an exercise
 */
export declare function getProgressiveOverloadSuggestion(userId: string, exerciseId: string): Promise<{
    recommendation: 'increase_weight' | 'increase_reps' | 'increase_sets' | 'maintain' | 'deload';
    currentStats: {
        avgWeight: number;
        avgReps: number;
        lastSets: number;
    };
    suggestedParams: {
        weight?: number;
        reps?: string;
        sets?: number;
    };
    reasoning: string;
}>;
/**
 * Check if user should take a deload week
 */
export declare function checkDeloadRecommendation(userId: string): Promise<DeloadRecommendation>;
/**
 * Get skill training prescription for a specific skill
 */
export declare function getSkillTrainingPrescription(userId: string, skillName: string, allocatedMinutes: number): Promise<SkillWorkBlock | null>;
/**
 * Get rehabilitation workout prescription
 */
export declare function getRehabilitationPrescription(userId: string, userInjuryId: string): Promise<{
    phase: number;
    phaseName: string;
    exercises: PrescribedExercise[];
    frequency: string;
    precautions: string[];
    progressionCriteria: Record<string, unknown>;
} | null>;
/**
 * Get exercise progression chain (regressions and progressions)
 */
export declare function getExerciseProgressionChain(exerciseId: string): Promise<{
    regressions: Array<{
        id: string;
        name: string;
        difficulty: number;
    }>;
    current: {
        id: string;
        name: string;
        difficulty: number;
    };
    progressions: Array<{
        id: string;
        name: string;
        difficulty: number;
    }>;
}>;
