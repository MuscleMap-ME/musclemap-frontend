/**
 * Hangout Service
 *
 * Manages location-based community hubs:
 * - CRUD operations for hangouts
 * - Membership management
 * - Posts and discussions
 * - Activity feeds
 */
export declare enum HangoutRole {
    MEMBER = 0,
    MODERATOR = 1,
    ADMIN = 2,
    OWNER = 3
}
interface CreateHangoutRequest {
    name: string;
    description?: string;
    typeId: number;
    lat: number;
    lng: number;
    address?: string;
    city?: string;
    countryCode?: string;
    radiusMeters?: number;
    coverImageUrl?: string;
    createdBy: string;
}
interface HangoutDetails {
    id: number;
    name: string;
    description?: string;
    typeId: number;
    typeName: string;
    typeSlug: string;
    location: {
        lat: number;
        lng: number;
    };
    geohash: string;
    address?: string;
    city?: string;
    countryCode?: string;
    radiusMeters: number;
    coverImageUrl?: string;
    memberCount: number;
    postCount: number;
    isVerified: boolean;
    isActive: boolean;
    createdBy?: string;
    createdAt: Date;
    updatedAt: Date;
    userRole?: HangoutRole;
    isMember?: boolean;
}
interface CreatePostRequest {
    hangoutId: number;
    authorId: string;
    content: string;
    mediaUrls?: string[];
    contentLang?: string;
}
interface HangoutPost {
    id: string;
    hangoutId: number;
    authorId?: string;
    authorUsername?: string;
    authorDisplayName?: string;
    authorAvatarUrl?: string;
    content: string;
    contentLang: string;
    mediaUrls: string[];
    commentCount: number;
    likeCount: number;
    isPinned: boolean;
    isHidden: boolean;
    createdAt: Date;
    updatedAt: Date;
}
export declare const hangoutService: {
    /**
     * Create a new hangout
     */
    create(request: CreateHangoutRequest): Promise<HangoutDetails>;
    /**
     * Get hangout by ID
     */
    getById(hangoutId: number, userId?: string): Promise<HangoutDetails | null>;
    /**
     * Join a hangout
     */
    join(hangoutId: number, userId: string): Promise<void>;
    /**
     * Leave a hangout
     */
    leave(hangoutId: number, userId: string): Promise<void>;
    /**
     * Get hangout members
     */
    getMembers(hangoutId: number, options?: {
        limit?: number;
        offset?: number;
    }): Promise<{
        members: Array<{
            userId: string;
            username: string;
            displayName?: string;
            avatarUrl?: string;
            role: HangoutRole;
            joinedAt: Date;
        }>;
        total: number;
    }>;
    /**
     * Create a post in a hangout
     * Costs 1 credit
     */
    createPost(request: CreatePostRequest): Promise<HangoutPost>;
    /**
     * Get posts from a hangout
     */
    getPosts(hangoutId: number, options?: {
        limit?: number;
        cursor?: string;
    }): Promise<{
        posts: HangoutPost[];
        nextCursor?: string;
    }>;
    /**
     * Get user's hangout memberships
     */
    getUserMemberships(userId: string, options?: {
        limit?: number;
        offset?: number;
    }): Promise<{
        hangouts: Array<{
            id: number;
            name: string;
            typeSlug: string;
            typeName: string;
            memberCount: number;
            role: HangoutRole;
            joinedAt: Date;
            coverImageUrl?: string;
        }>;
        total: number;
    }>;
};
export {};
