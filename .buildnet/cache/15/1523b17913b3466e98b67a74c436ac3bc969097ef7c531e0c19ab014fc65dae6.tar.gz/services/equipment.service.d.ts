/**
 * Equipment Service
 *
 * Manages equipment types, location equipment (crowd-sourced), and user home equipment.
 * Implements consensus-based verification: equipment is verified when 3+ users report it present.
 */
export interface EquipmentType {
    id: string;
    name: string;
    category: string;
    description: string | null;
    iconUrl: string | null;
    displayOrder: number;
}
export interface LocationEquipment {
    equipmentTypeId: string;
    equipmentName: string;
    category: string;
    confirmedCount: number;
    deniedCount: number;
    isVerified: boolean;
    firstReportedAt: string;
    lastReportedAt: string;
}
export interface EquipmentReport {
    id: number;
    hangoutId: string;
    equipmentTypeId: string;
    userId: string;
    reportType: 'present' | 'absent';
    notes: string | null;
    createdAt: string;
}
export interface UserHomeEquipment {
    id: number;
    userId: string;
    equipmentTypeId: string;
    equipmentName: string;
    category: string;
    locationType: 'home' | 'work' | 'other';
    notes: string | null;
}
/**
 * Get all equipment types (cached)
 */
export declare function getEquipmentTypes(): Promise<EquipmentType[]>;
/**
 * Get equipment types by category (cached)
 */
export declare function getEquipmentTypesByCategory(category: string): Promise<EquipmentType[]>;
/**
 * Get equipment categories (cached)
 */
export declare function getEquipmentCategories(): Promise<string[]>;
/**
 * Get equipment at a specific location (hangout)
 */
export declare function getLocationEquipment(hangoutId: string): Promise<LocationEquipment[]>;
/**
 * Get verified equipment at a location (for workout recommendations)
 */
export declare function getVerifiedLocationEquipment(hangoutId: string): Promise<string[]>;
/**
 * Report equipment at a location
 * Implements consensus logic: updates aggregate counts and verification status
 */
export declare function reportEquipment(userId: string, hangoutId: string, equipmentTypeIds: string[], reportType: 'present' | 'absent'): Promise<void>;
/**
 * Get user's existing reports for a location
 */
export declare function getUserReportsForLocation(userId: string, hangoutId: string): Promise<{
    equipmentTypeId: string;
    reportType: 'present' | 'absent';
}[]>;
/**
 * Get user's home equipment
 */
export declare function getUserHomeEquipment(userId: string, locationType?: 'home' | 'work' | 'other'): Promise<UserHomeEquipment[]>;
/**
 * Set user's home equipment (replaces existing for the location type)
 */
export declare function setUserHomeEquipment(userId: string, equipmentTypeIds: string[], locationType?: 'home' | 'work' | 'other'): Promise<void>;
/**
 * Add single equipment to user's home
 */
export declare function addUserHomeEquipment(userId: string, equipmentTypeId: string, locationType?: 'home' | 'work' | 'other', notes?: string): Promise<void>;
/**
 * Remove equipment from user's home
 */
export declare function removeUserHomeEquipment(userId: string, equipmentTypeId: string, locationType?: 'home' | 'work' | 'other'): Promise<void>;
/**
 * Get equipment IDs for user's home (simple list)
 */
export declare function getUserHomeEquipmentIds(userId: string, locationType?: 'home' | 'work' | 'other'): Promise<string[]>;
