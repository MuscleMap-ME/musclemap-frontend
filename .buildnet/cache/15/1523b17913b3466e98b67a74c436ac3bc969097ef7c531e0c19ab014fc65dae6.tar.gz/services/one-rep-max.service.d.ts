/**
 * One Rep Max (1RM) Service
 *
 * Handles 1RM calculation, tracking, and achievement checking:
 * - Multiple 1RM calculation formulas (Epley, Brzycki, etc.)
 * - 1RM history tracking and PR detection
 * - Compound total tracking (Squat + Bench + Deadlift)
 * - 1RM-based achievement unlocking
 */
export type OneRMFormula = 'epley' | 'brzycki' | 'lombardi' | 'oconner' | 'actual';
export interface OneRMEntry {
    id: string;
    userId: string;
    exerciseId: string;
    exerciseName?: string;
    estimated1rm: number;
    actual1rm?: number;
    sourceWeight: number;
    sourceReps: number;
    sourceRpe?: number;
    formulaUsed: OneRMFormula;
    workoutId?: string;
    setId?: string;
    isPr: boolean;
    bodyweightKg?: number;
    relativeStrength?: number;
    recordedAt: Date;
}
export interface CompoundTotal {
    userId: string;
    bestSquat1rm?: number;
    bestBench1rm?: number;
    bestDeadlift1rm?: number;
    powerliftingTotal: number;
    squatPrDate?: Date;
    benchPrDate?: Date;
    deadliftPrDate?: Date;
    lastBodyweightKg?: number;
    wilksScore?: number;
    dotsScore?: number;
}
export interface OneRMProgression {
    exerciseId: string;
    exerciseName?: string;
    data: Array<{
        date: Date;
        best1rm: number;
        isPr: boolean;
    }>;
    currentPr?: number;
    firstRecorded?: number;
    improvement?: {
        absolute: number;
        percentage: number;
    };
}
/**
 * One Rep Max (1RM) Estimation Formulas
 *
 * All formulas estimate the maximum weight a person can lift for a single repetition
 * based on the weight lifted and number of reps performed.
 *
 * ACCURACY NOTES:
 * - Most accurate for 1-10 reps (r² > 0.95)
 * - Accuracy decreases significantly above 10 reps
 * - Individual variation can cause 5-10% error
 * - Use "average" formula for best general accuracy
 *
 * FORMULA RECOMMENDATIONS:
 * - Epley: Best for 6-10 rep ranges
 * - Brzycki: Best for 1-6 rep ranges (more conservative)
 * - Lombardi: Simple, good for quick mental math
 * - O'Conner: Good for general fitness (slightly conservative)
 */
export declare const OneRMFormulas: {
    /**
     * Epley Formula: 1RM = weight × (1 + reps/30)
     *
     * Developed by Boyd Epley, former strength coach at University of Nebraska.
     * One of the most widely used formulas in strength training.
     *
     * Characteristics:
     * - Linear relationship with reps
     * - Tends to overestimate at high rep ranges (>12)
     * - Best accuracy in 6-10 rep range
     *
     * @example 200 lbs × 5 reps = 200 × (1 + 5/30) = 200 × 1.167 = 233.3 lbs
     */
    epley(weight: number, reps: number): number;
    /**
     * Brzycki Formula: 1RM = weight × (36 / (37 - reps))
     *
     * Developed by Matt Brzycki, coordinator of fitness at Princeton University.
     * More conservative than Epley, especially for higher rep ranges.
     *
     * Characteristics:
     * - Non-linear (exponential increase as reps approach 37)
     * - More conservative estimates
     * - Best accuracy in 1-6 rep range
     * - Cannot calculate for reps >= 37 (mathematical constraint)
     *
     * @example 200 lbs × 5 reps = 200 × (36 / (37-5)) = 200 × 1.125 = 225 lbs
     */
    brzycki(weight: number, reps: number): number;
    /**
     * Lombardi Formula: 1RM = weight × reps^0.10
     *
     * Developed by Vincent Lombardi. Uses a power relationship.
     *
     * Characteristics:
     * - Simple power function
     * - Easy to calculate mentally (reps to the 0.1 power ≈ 1.0-1.3)
     * - Tends to underestimate compared to other formulas
     * - Consistent across all rep ranges
     *
     * @example 200 lbs × 5 reps = 200 × 5^0.10 = 200 × 1.175 = 235 lbs
     */
    lombardi(weight: number, reps: number): number;
    /**
     * O'Conner Formula: 1RM = weight × (1 + reps/40)
     *
     * A more conservative version of the Epley formula.
     * Divides reps by 40 instead of 30.
     *
     * Characteristics:
     * - Linear relationship like Epley
     * - More conservative (lower estimates)
     * - Good for general fitness populations
     * - Less likely to overestimate
     *
     * @example 200 lbs × 5 reps = 200 × (1 + 5/40) = 200 × 1.125 = 225 lbs
     */
    oconner(weight: number, reps: number): number;
    /**
     * Calculate 1RM using specified formula
     */
    calculate(weight: number, reps: number, formula?: OneRMFormula): number;
    /**
     * Calculate average of all formulas (more accurate for most people)
     * Research shows averaging multiple formulas provides the most reliable estimate.
     */
    average(weight: number, reps: number): number;
    /**
     * Calculate all formulas and return detailed breakdown
     */
    calculateAll(weight: number, reps: number): {
        epley: number;
        brzycki: number;
        lombardi: number;
        oconner: number;
        average: number;
        min: number;
        max: number;
        range: number;
    };
    /**
     * Reverse calculation: Get weight for target 1RM at given reps
     * Useful for programming: "What weight should I use for 5 reps to hit 80% of my 1RM?"
     *
     * @param target1rm - Target 1RM value
     * @param reps - Number of reps to perform
     * @param formula - Formula to use for calculation
     * @returns Weight to use
     */
    getWeightForReps(target1rm: number, reps: number, formula?: OneRMFormula): number;
    /**
     * Calculate percentage of 1RM for given weight and reps
     * Useful for tracking intensity relative to max
     *
     * @param weight - Weight lifted
     * @param reps - Reps performed
     * @param known1rm - User's known 1RM for the exercise
     * @returns Percentage of 1RM (e.g., 0.85 for 85%)
     */
    getPercentageOf1rm(weight: number, reps: number, known1rm: number): number;
    /**
     * Generate a rep-max table for training programming
     * Shows estimated weights for different rep ranges based on 1RM
     *
     * @param oneRepMax - The user's 1RM
     * @param formula - Formula to use
     * @returns Array of rep ranges with corresponding weights and percentages
     */
    generateRepMaxTable(oneRepMax: number, formula?: OneRMFormula): Array<{
        reps: number;
        weight: number;
        percentage: number;
    }>;
};
/**
 * Wilks and DOTS score calculators for comparing lifts across different bodyweights.
 * These are standard formulas used in competitive powerlifting.
 */
export declare const PowerliftingScores: {
    /**
     * Wilks Coefficient Formula
     * Used to compare powerlifting totals across different bodyweight classes.
     *
     * Wilks = Total × Coefficient
     * where Coefficient = 500 / (a + b×bw + c×bw² + d×bw³ + e×bw⁴ + f×bw⁵)
     *
     * @param totalKg - Total weight lifted (sum of squat, bench, deadlift) in kg
     * @param bodyweightKg - Bodyweight in kg
     * @param isMale - True for male coefficients, false for female
     * @returns Wilks score
     */
    calculateWilks(totalKg: number, bodyweightKg: number, isMale?: boolean): number;
    /**
     * DOTS (Dynamic Objective Team Scoring) Formula
     * A newer formula that replaces Wilks in some federations.
     * Better accuracy across a wider range of bodyweights.
     *
     * @param totalKg - Total weight lifted (sum of squat, bench, deadlift) in kg
     * @param bodyweightKg - Bodyweight in kg
     * @param isMale - True for male coefficients, false for female
     * @returns DOTS score
     */
    calculateDots(totalKg: number, bodyweightKg: number, isMale?: boolean): number;
    /**
     * Convert pounds to kilograms
     */
    lbsToKg(lbs: number): number;
    /**
     * Convert kilograms to pounds
     */
    kgToLbs(kg: number): number;
};
/**
 * Strength standards based on bodyweight ratios
 * These are approximate guidelines for classification
 */
export declare const StrengthStandards: {
    male: {
        squat: {
            beginner: number;
            novice: number;
            intermediate: number;
            advanced: number;
            elite: number;
        };
        bench: {
            beginner: number;
            novice: number;
            intermediate: number;
            advanced: number;
            elite: number;
        };
        deadlift: {
            beginner: number;
            novice: number;
            intermediate: number;
            advanced: number;
            elite: number;
        };
    };
    female: {
        squat: {
            beginner: number;
            novice: number;
            intermediate: number;
            advanced: number;
            elite: number;
        };
        bench: {
            beginner: number;
            novice: number;
            intermediate: number;
            advanced: number;
            elite: number;
        };
        deadlift: {
            beginner: number;
            novice: number;
            intermediate: number;
            advanced: number;
            elite: number;
        };
    };
    /**
     * Classify a lift based on bodyweight ratio
     * @param lift1rm - The 1RM weight
     * @param bodyweight - User's bodyweight (same units as lift1rm)
     * @param liftType - Type of lift (squat, bench, deadlift)
     * @param isMale - True for male standards
     * @returns Classification level
     */
    classify(lift1rm: number, bodyweight: number, liftType: "squat" | "bench" | "deadlift", isMale?: boolean): {
        level: "untrained" | "beginner" | "novice" | "intermediate" | "advanced" | "elite";
        ratio: number;
        nextLevel?: string;
        nextLevelWeight?: number;
    };
};
export declare const OneRepMaxService: {
    /**
     * Record a new 1RM entry and check for PRs
     */
    record(params: {
        userId: string;
        exerciseId: string;
        weight: number;
        reps: number;
        rpe?: number;
        workoutId?: string;
        setId?: string;
        bodyweightKg?: number;
        formula?: OneRMFormula;
    }): Promise<{
        entry: OneRMEntry;
        isPr: boolean;
        previousPr?: number;
        achievements: string[];
    }>;
    /**
     * Get 1RM history for a specific exercise
     */
    getExerciseHistory(userId: string, exerciseId: string, options?: {
        limit?: number;
        days?: number;
    }): Promise<OneRMEntry[]>;
    /**
     * Get 1RM progression data for charts
     */
    getProgression(userId: string, exerciseId: string, options?: {
        period?: "daily" | "weekly" | "monthly";
        days?: number;
    }): Promise<OneRMProgression>;
    /**
     * Get user's compound total (Squat + Bench + Deadlift)
     */
    getCompoundTotal(userId: string): Promise<CompoundTotal | null>;
    /**
     * Get user's best 1RM for all exercises
     */
    getAllBestLifts(userId: string): Promise<Array<{
        exerciseId: string;
        exerciseName: string;
        best1rm: number;
        recordedAt: Date;
    }>>;
    /**
     * Get 1RM leaderboard for an exercise
     */
    getLeaderboard(exerciseId: string, options?: {
        limit?: number;
        offset?: number;
    }): Promise<Array<{
        rank: number;
        userId: string;
        username: string;
        best1rm: number;
        relativeStrength?: number;
        recordedAt: Date;
    }>>;
    /**
     * Check and grant 1RM-based achievements
     */
    checkAchievements(userId: string, exerciseId: string, estimated1rm: number, bodyweightKg?: number, isPr?: boolean): Promise<string[]>;
    /**
     * Delete a 1RM entry
     * Note: Can only delete entries that are not PRs or if there are newer PRs
     */
    deleteEntry(userId: string, entryId: string): Promise<{
        deleted: boolean;
        message: string;
    }>;
    /**
     * Get user's PR for a specific exercise
     */
    getExercisePR(userId: string, exerciseId: string): Promise<OneRMEntry | null>;
    /**
     * Calculate and update Wilks/DOTS scores for a user
     */
    updatePowerliftingScores(userId: string, bodyweightKg: number, isMale?: boolean): Promise<{
        wilks: number | null;
        dots: number | null;
        total: number;
    }>;
    /**
     * Compare user's lifts against strength standards
     */
    getStrengthClassification(userId: string, bodyweightLbs: number, isMale?: boolean): Promise<{
        squat?: {
            level: string;
            ratio: number;
            nextLevel?: string;
            nextLevelWeight?: number;
        };
        bench?: {
            level: string;
            ratio: number;
            nextLevel?: string;
            nextLevelWeight?: number;
        };
        deadlift?: {
            level: string;
            ratio: number;
            nextLevel?: string;
            nextLevelWeight?: number;
        };
        overall?: string;
    }>;
    /**
     * Map database row to OneRMEntry
     */
    mapEntry(row: {
        id: string;
        user_id: string;
        exercise_id: string;
        estimated_1rm: string;
        actual_1rm: string | null;
        source_weight: string;
        source_reps: number;
        source_rpe: number | null;
        formula_used: string;
        workout_id: string | null;
        set_id: string | null;
        is_pr: boolean;
        bodyweight_kg: string | null;
        relative_strength: string | null;
        recorded_at: Date;
        exercise_name?: string | null;
    }): OneRMEntry;
};
export default OneRepMaxService;
