/**
 * Exercise Groups Service
 *
 * Manages supersets, giant sets, circuits, drop sets, and cluster sets.
 * Handles CRUD operations, rest time calculations, and preset management.
 */
import { z } from 'zod';
export declare const GROUP_TYPES: {
    readonly SUPERSET: "superset";
    readonly GIANT_SET: "giant_set";
    readonly CIRCUIT: "circuit";
    readonly DROP_SET: "drop_set";
    readonly CLUSTER: "cluster";
};
export type GroupType = typeof GROUP_TYPES[keyof typeof GROUP_TYPES];
declare const exerciseInGroupSchema: z.ZodObject<{
    exerciseId: z.ZodString;
    order: z.ZodNumber;
    sets: z.ZodOptional<z.ZodNumber>;
    reps: z.ZodOptional<z.ZodUnion<[z.ZodNumber, z.ZodString]>>;
    weight: z.ZodOptional<z.ZodNumber>;
    duration: z.ZodOptional<z.ZodNumber>;
    notes: z.ZodOptional<z.ZodString>;
}, "strip", z.ZodTypeAny, {
    exerciseId: string;
    order: number;
    notes?: string | undefined;
    duration?: number | undefined;
    sets?: number | undefined;
    reps?: string | number | undefined;
    weight?: number | undefined;
}, {
    exerciseId: string;
    order: number;
    notes?: string | undefined;
    duration?: number | undefined;
    sets?: number | undefined;
    reps?: string | number | undefined;
    weight?: number | undefined;
}>;
export type ExerciseInGroup = z.infer<typeof exerciseInGroupSchema>;
declare const createGroupSchema: z.ZodObject<{
    workoutId: z.ZodOptional<z.ZodString>;
    templateId: z.ZodOptional<z.ZodString>;
    programDayId: z.ZodOptional<z.ZodString>;
    groupType: z.ZodEnum<["superset", "giant_set", "circuit", "drop_set", "cluster"]>;
    exercises: z.ZodArray<z.ZodObject<{
        exerciseId: z.ZodString;
        order: z.ZodNumber;
        sets: z.ZodOptional<z.ZodNumber>;
        reps: z.ZodOptional<z.ZodUnion<[z.ZodNumber, z.ZodString]>>;
        weight: z.ZodOptional<z.ZodNumber>;
        duration: z.ZodOptional<z.ZodNumber>;
        notes: z.ZodOptional<z.ZodString>;
    }, "strip", z.ZodTypeAny, {
        exerciseId: string;
        order: number;
        notes?: string | undefined;
        duration?: number | undefined;
        sets?: number | undefined;
        reps?: string | number | undefined;
        weight?: number | undefined;
    }, {
        exerciseId: string;
        order: number;
        notes?: string | undefined;
        duration?: number | undefined;
        sets?: number | undefined;
        reps?: string | number | undefined;
        weight?: number | undefined;
    }>, "many">;
    restBetweenExercises: z.ZodOptional<z.ZodNumber>;
    restAfterGroup: z.ZodOptional<z.ZodNumber>;
    circuitRounds: z.ZodOptional<z.ZodNumber>;
    circuitTimed: z.ZodOptional<z.ZodBoolean>;
    circuitTimePerExercise: z.ZodOptional<z.ZodNumber>;
    circuitTransitionTime: z.ZodOptional<z.ZodNumber>;
    name: z.ZodOptional<z.ZodString>;
    color: z.ZodOptional<z.ZodString>;
    position: z.ZodOptional<z.ZodNumber>;
}, "strip", z.ZodTypeAny, {
    exercises: {
        exerciseId: string;
        order: number;
        notes?: string | undefined;
        duration?: number | undefined;
        sets?: number | undefined;
        reps?: string | number | undefined;
        weight?: number | undefined;
    }[];
    groupType: "superset" | "cluster" | "giant_set" | "circuit" | "drop_set";
    color?: string | undefined;
    workoutId?: string | undefined;
    name?: string | undefined;
    templateId?: string | undefined;
    position?: number | undefined;
    programDayId?: string | undefined;
    restBetweenExercises?: number | undefined;
    restAfterGroup?: number | undefined;
    circuitRounds?: number | undefined;
    circuitTimed?: boolean | undefined;
    circuitTimePerExercise?: number | undefined;
    circuitTransitionTime?: number | undefined;
}, {
    exercises: {
        exerciseId: string;
        order: number;
        notes?: string | undefined;
        duration?: number | undefined;
        sets?: number | undefined;
        reps?: string | number | undefined;
        weight?: number | undefined;
    }[];
    groupType: "superset" | "cluster" | "giant_set" | "circuit" | "drop_set";
    color?: string | undefined;
    workoutId?: string | undefined;
    name?: string | undefined;
    templateId?: string | undefined;
    position?: number | undefined;
    programDayId?: string | undefined;
    restBetweenExercises?: number | undefined;
    restAfterGroup?: number | undefined;
    circuitRounds?: number | undefined;
    circuitTimed?: boolean | undefined;
    circuitTimePerExercise?: number | undefined;
    circuitTransitionTime?: number | undefined;
}>;
export type CreateGroupInput = z.infer<typeof createGroupSchema>;
declare const updateGroupSchema: z.ZodObject<Omit<{
    workoutId: z.ZodOptional<z.ZodOptional<z.ZodString>>;
    templateId: z.ZodOptional<z.ZodOptional<z.ZodString>>;
    programDayId: z.ZodOptional<z.ZodOptional<z.ZodString>>;
    groupType: z.ZodOptional<z.ZodEnum<["superset", "giant_set", "circuit", "drop_set", "cluster"]>>;
    exercises: z.ZodOptional<z.ZodArray<z.ZodObject<{
        exerciseId: z.ZodString;
        order: z.ZodNumber;
        sets: z.ZodOptional<z.ZodNumber>;
        reps: z.ZodOptional<z.ZodUnion<[z.ZodNumber, z.ZodString]>>;
        weight: z.ZodOptional<z.ZodNumber>;
        duration: z.ZodOptional<z.ZodNumber>;
        notes: z.ZodOptional<z.ZodString>;
    }, "strip", z.ZodTypeAny, {
        exerciseId: string;
        order: number;
        notes?: string | undefined;
        duration?: number | undefined;
        sets?: number | undefined;
        reps?: string | number | undefined;
        weight?: number | undefined;
    }, {
        exerciseId: string;
        order: number;
        notes?: string | undefined;
        duration?: number | undefined;
        sets?: number | undefined;
        reps?: string | number | undefined;
        weight?: number | undefined;
    }>, "many">>;
    restBetweenExercises: z.ZodOptional<z.ZodOptional<z.ZodNumber>>;
    restAfterGroup: z.ZodOptional<z.ZodOptional<z.ZodNumber>>;
    circuitRounds: z.ZodOptional<z.ZodOptional<z.ZodNumber>>;
    circuitTimed: z.ZodOptional<z.ZodOptional<z.ZodBoolean>>;
    circuitTimePerExercise: z.ZodOptional<z.ZodOptional<z.ZodNumber>>;
    circuitTransitionTime: z.ZodOptional<z.ZodOptional<z.ZodNumber>>;
    name: z.ZodOptional<z.ZodOptional<z.ZodString>>;
    color: z.ZodOptional<z.ZodOptional<z.ZodString>>;
    position: z.ZodOptional<z.ZodOptional<z.ZodNumber>>;
}, "workoutId" | "templateId" | "programDayId">, "strip", z.ZodTypeAny, {
    color?: string | undefined;
    name?: string | undefined;
    exercises?: {
        exerciseId: string;
        order: number;
        notes?: string | undefined;
        duration?: number | undefined;
        sets?: number | undefined;
        reps?: string | number | undefined;
        weight?: number | undefined;
    }[] | undefined;
    position?: number | undefined;
    groupType?: "superset" | "cluster" | "giant_set" | "circuit" | "drop_set" | undefined;
    restBetweenExercises?: number | undefined;
    restAfterGroup?: number | undefined;
    circuitRounds?: number | undefined;
    circuitTimed?: boolean | undefined;
    circuitTimePerExercise?: number | undefined;
    circuitTransitionTime?: number | undefined;
}, {
    color?: string | undefined;
    name?: string | undefined;
    exercises?: {
        exerciseId: string;
        order: number;
        notes?: string | undefined;
        duration?: number | undefined;
        sets?: number | undefined;
        reps?: string | number | undefined;
        weight?: number | undefined;
    }[] | undefined;
    position?: number | undefined;
    groupType?: "superset" | "cluster" | "giant_set" | "circuit" | "drop_set" | undefined;
    restBetweenExercises?: number | undefined;
    restAfterGroup?: number | undefined;
    circuitRounds?: number | undefined;
    circuitTimed?: boolean | undefined;
    circuitTimePerExercise?: number | undefined;
    circuitTransitionTime?: number | undefined;
}>;
export type UpdateGroupInput = z.infer<typeof updateGroupSchema>;
declare const logGroupSetSchema: z.ZodObject<{
    groupId: z.ZodString;
    workoutId: z.ZodString;
    roundNumber: z.ZodNumber;
    exerciseIndex: z.ZodNumber;
    exerciseId: z.ZodString;
    weight: z.ZodOptional<z.ZodNumber>;
    reps: z.ZodNumber;
    durationSeconds: z.ZodOptional<z.ZodNumber>;
    rpe: z.ZodOptional<z.ZodNumber>;
    rir: z.ZodOptional<z.ZodNumber>;
    notes: z.ZodOptional<z.ZodString>;
    skipped: z.ZodOptional<z.ZodBoolean>;
}, "strip", z.ZodTypeAny, {
    workoutId: string;
    exerciseId: string;
    reps: number;
    groupId: string;
    roundNumber: number;
    exerciseIndex: number;
    notes?: string | undefined;
    weight?: number | undefined;
    skipped?: boolean | undefined;
    rpe?: number | undefined;
    durationSeconds?: number | undefined;
    rir?: number | undefined;
}, {
    workoutId: string;
    exerciseId: string;
    reps: number;
    groupId: string;
    roundNumber: number;
    exerciseIndex: number;
    notes?: string | undefined;
    weight?: number | undefined;
    skipped?: boolean | undefined;
    rpe?: number | undefined;
    durationSeconds?: number | undefined;
    rir?: number | undefined;
}>;
export type LogGroupSetInput = z.infer<typeof logGroupSetSchema>;
export interface ExerciseGroup {
    id: string;
    workoutId: string | null;
    templateId: string | null;
    programDayId: string | null;
    userId: string;
    groupType: GroupType;
    exercises: ExerciseInGroup[];
    restBetweenExercises: number;
    restAfterGroup: number;
    circuitRounds: number;
    circuitTimed: boolean;
    circuitTimePerExercise: number;
    circuitTransitionTime: number;
    name: string | null;
    color: string;
    position: number;
    createdAt: Date;
    updatedAt: Date;
}
export interface GroupPreset {
    id: string;
    userId: string;
    name: string;
    groupType: GroupType;
    exercises: ExerciseInGroup[];
    restBetweenExercises: number;
    restAfterGroup: number;
    circuitRounds: number;
    circuitTimed: boolean;
    circuitTimePerExercise: number;
    color: string;
    timesUsed: number;
    lastUsedAt: Date | null;
    createdAt: Date;
    updatedAt: Date;
}
declare class ExerciseGroupsService {
    /**
     * Create a new exercise group
     */
    createGroup(userId: string, input: CreateGroupInput): Promise<ExerciseGroup>;
    /**
     * Get a single exercise group by ID
     */
    getGroup(groupId: string, userId: string): Promise<ExerciseGroup | null>;
    /**
     * Get all groups for a workout
     */
    getGroupsForWorkout(workoutId: string, userId: string): Promise<ExerciseGroup[]>;
    /**
     * Get all groups for a template
     */
    getGroupsForTemplate(templateId: string): Promise<ExerciseGroup[]>;
    /**
     * Update an exercise group
     */
    updateGroup(groupId: string, userId: string, input: UpdateGroupInput): Promise<ExerciseGroup | null>;
    /**
     * Delete an exercise group
     */
    deleteGroup(groupId: string, userId: string): Promise<boolean>;
    /**
     * Reorder exercises within a group
     */
    reorderExercises(groupId: string, userId: string, newOrder: string[]): Promise<ExerciseGroup | null>;
    /**
     * Add an exercise to an existing group
     */
    addExerciseToGroup(groupId: string, userId: string, exerciseData: ExerciseInGroup): Promise<ExerciseGroup | null>;
    /**
     * Remove an exercise from a group
     */
    removeExerciseFromGroup(groupId: string, userId: string, exerciseId: string): Promise<ExerciseGroup | null>;
    /**
     * Log a set within an exercise group
     */
    logGroupSet(userId: string, input: LogGroupSetInput): Promise<{
        id: string;
    }>;
    /**
     * Get all logged sets for a group in a workout
     */
    getGroupSets(groupId: string, workoutId: string, userId: string): Promise<Record<string, unknown>[]>;
    /**
     * Save current group as a preset
     */
    saveAsPreset(userId: string, name: string, group: Pick<ExerciseGroup, 'groupType' | 'exercises' | 'restBetweenExercises' | 'restAfterGroup' | 'circuitRounds' | 'circuitTimed' | 'circuitTimePerExercise' | 'color'>): Promise<GroupPreset>;
    /**
     * Get user's presets
     */
    getPresets(userId: string): Promise<GroupPreset[]>;
    /**
     * Create a group from a preset
     */
    createFromPreset(userId: string, presetId: string, parentRef: {
        workoutId?: string;
        templateId?: string;
        programDayId?: string;
    }): Promise<ExerciseGroup>;
    /**
     * Delete a preset
     */
    deletePreset(presetId: string, userId: string): Promise<boolean>;
    /**
     * Get default rest between exercises based on group type
     */
    getDefaultRestBetween(groupType: GroupType): number;
    /**
     * Get default rest after completing group based on type
     */
    getDefaultRestAfter(groupType: GroupType): number;
    /**
     * Calculate total estimated time for a group
     */
    calculateGroupDuration(group: ExerciseGroup): number;
    /**
     * Get group display label (e.g., "2x Superset", "3x Circuit")
     */
    getGroupLabel(group: ExerciseGroup): string;
}
export declare const exerciseGroupsService: ExerciseGroupsService;
export {};
