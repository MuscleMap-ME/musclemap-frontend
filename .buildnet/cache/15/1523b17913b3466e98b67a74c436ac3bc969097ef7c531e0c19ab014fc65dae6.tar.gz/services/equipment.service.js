"use strict";
/**
 * Equipment Service
 *
 * Manages equipment types, location equipment (crowd-sourced), and user home equipment.
 * Implements consensus-based verification: equipment is verified when 3+ users report it present.
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.getEquipmentTypes = getEquipmentTypes;
exports.getEquipmentTypesByCategory = getEquipmentTypesByCategory;
exports.getEquipmentCategories = getEquipmentCategories;
exports.getLocationEquipment = getLocationEquipment;
exports.getVerifiedLocationEquipment = getVerifiedLocationEquipment;
exports.reportEquipment = reportEquipment;
exports.getUserReportsForLocation = getUserReportsForLocation;
exports.getUserHomeEquipment = getUserHomeEquipment;
exports.setUserHomeEquipment = setUserHomeEquipment;
exports.addUserHomeEquipment = addUserHomeEquipment;
exports.removeUserHomeEquipment = removeUserHomeEquipment;
exports.getUserHomeEquipmentIds = getUserHomeEquipmentIds;
const client_1 = require("../db/client");
const logger_1 = require("../lib/logger");
const cache_service_1 = __importStar(require("../lib/cache.service"));
const log = logger_1.loggers.core;
// Minimum reports required for verification
const VERIFICATION_THRESHOLD = 3;
// =====================
// Equipment Types (Reference Data)
// =====================
/**
 * Get all equipment types (cached)
 */
async function getEquipmentTypes() {
    return cache_service_1.default.getOrSet(cache_service_1.CACHE_PREFIX.EQUIPMENT_TYPES, cache_service_1.CACHE_TTL.EQUIPMENT_TYPES, async () => {
        const rows = await client_1.db.queryAll(`
        SELECT id, name, category, description, icon_url, display_order
        FROM equipment_types
        ORDER BY display_order, name
      `);
        return rows.map((row) => ({
            id: row.id,
            name: row.name,
            category: row.category,
            description: row.description,
            iconUrl: row.icon_url,
            displayOrder: row.display_order,
        }));
    });
}
/**
 * Get equipment types by category (cached)
 */
async function getEquipmentTypesByCategory(category) {
    return cache_service_1.default.getOrSet(`${cache_service_1.CACHE_PREFIX.EQUIPMENT_TYPES}:cat:${category}`, cache_service_1.CACHE_TTL.EQUIPMENT_TYPES, async () => {
        const rows = await client_1.db.queryAll(`
        SELECT id, name, category, description, icon_url, display_order
        FROM equipment_types
        WHERE category = $1
        ORDER BY display_order, name
      `, [category]);
        return rows.map((row) => ({
            id: row.id,
            name: row.name,
            category: row.category,
            description: row.description,
            iconUrl: row.icon_url,
            displayOrder: row.display_order,
        }));
    });
}
/**
 * Get equipment categories (cached)
 */
async function getEquipmentCategories() {
    return cache_service_1.default.getOrSet(cache_service_1.CACHE_PREFIX.EQUIPMENT_CATEGORIES, cache_service_1.CACHE_TTL.EQUIPMENT_CATEGORIES, async () => {
        const rows = await client_1.db.queryAll(`
        SELECT DISTINCT category FROM equipment_types ORDER BY category
      `);
        return rows.map((r) => r.category);
    });
}
// =====================
// Location Equipment (Crowd-Sourced)
// =====================
/**
 * Get equipment at a specific location (hangout)
 */
async function getLocationEquipment(hangoutId) {
    const rows = await client_1.db.queryAll(`
    SELECT
      le.equipment_type_id,
      et.name,
      et.category,
      le.confirmed_count,
      le.denied_count,
      le.is_verified,
      le.first_reported_at,
      le.last_reported_at
    FROM location_equipment le
    JOIN equipment_types et ON et.id = le.equipment_type_id
    WHERE le.hangout_id = $1
    ORDER BY le.is_verified DESC, le.confirmed_count DESC, et.display_order
  `, [hangoutId]);
    return rows.map((row) => ({
        equipmentTypeId: row.equipment_type_id,
        equipmentName: row.name,
        category: row.category,
        confirmedCount: row.confirmed_count,
        deniedCount: row.denied_count,
        isVerified: row.is_verified,
        firstReportedAt: row.first_reported_at,
        lastReportedAt: row.last_reported_at,
    }));
}
/**
 * Get verified equipment at a location (for workout recommendations)
 */
async function getVerifiedLocationEquipment(hangoutId) {
    const rows = await client_1.db.queryAll(`
    SELECT equipment_type_id
    FROM location_equipment
    WHERE hangout_id = $1 AND is_verified = TRUE
  `, [hangoutId]);
    return rows.map((r) => r.equipment_type_id);
}
/**
 * Report equipment at a location
 * Implements consensus logic: updates aggregate counts and verification status
 */
async function reportEquipment(userId, hangoutId, equipmentTypeIds, reportType) {
    log.info({ userId, hangoutId, equipmentTypeIds, reportType }, 'Reporting equipment at location');
    for (const equipmentTypeId of equipmentTypeIds) {
        // Upsert user's individual report
        await client_1.db.query(`
      INSERT INTO equipment_reports (hangout_id, equipment_type_id, user_id, report_type)
      VALUES ($1, $2, $3, $4)
      ON CONFLICT (hangout_id, equipment_type_id, user_id)
      DO UPDATE SET report_type = $4, created_at = NOW()
    `, [hangoutId, equipmentTypeId, userId, reportType]);
        // Count all reports for this equipment at this location
        const counts = await client_1.db.queryOne(`
      SELECT
        COUNT(*) FILTER (WHERE report_type = 'present') as present_count,
        COUNT(*) FILTER (WHERE report_type = 'absent') as absent_count
      FROM equipment_reports
      WHERE hangout_id = $1 AND equipment_type_id = $2
    `, [hangoutId, equipmentTypeId]);
        const confirmedCount = parseInt(counts?.present_count || '0');
        const deniedCount = parseInt(counts?.absent_count || '0');
        const isVerified = confirmedCount >= VERIFICATION_THRESHOLD;
        // Upsert aggregate record
        await client_1.db.query(`
      INSERT INTO location_equipment (hangout_id, equipment_type_id, confirmed_count, denied_count, is_verified, last_reported_at)
      VALUES ($1, $2, $3, $4, $5, NOW())
      ON CONFLICT (hangout_id, equipment_type_id)
      DO UPDATE SET
        confirmed_count = $3,
        denied_count = $4,
        is_verified = $5,
        last_reported_at = NOW()
    `, [hangoutId, equipmentTypeId, confirmedCount, deniedCount, isVerified]);
        if (isVerified) {
            log.info({ hangoutId, equipmentTypeId, confirmedCount }, 'Equipment verified at location');
        }
    }
}
/**
 * Get user's existing reports for a location
 */
async function getUserReportsForLocation(userId, hangoutId) {
    const rows = await client_1.db.queryAll(`
    SELECT equipment_type_id, report_type
    FROM equipment_reports
    WHERE user_id = $1 AND hangout_id = $2
  `, [userId, hangoutId]);
    return rows.map((r) => ({
        equipmentTypeId: r.equipment_type_id,
        reportType: r.report_type,
    }));
}
// =====================
// User Home Equipment
// =====================
/**
 * Get user's home equipment
 */
async function getUserHomeEquipment(userId, locationType) {
    const whereClause = locationType
        ? `WHERE uhe.user_id = $1 AND uhe.location_type = $2`
        : `WHERE uhe.user_id = $1`;
    const params = locationType ? [userId, locationType] : [userId];
    const rows = await client_1.db.queryAll(`
    SELECT
      uhe.id,
      uhe.user_id,
      uhe.equipment_type_id,
      et.name,
      et.category,
      uhe.location_type,
      uhe.notes
    FROM user_home_equipment uhe
    JOIN equipment_types et ON et.id = uhe.equipment_type_id
    ${whereClause}
    ORDER BY et.display_order, et.name
  `, params);
    return rows.map((row) => ({
        id: row.id,
        userId: row.user_id,
        equipmentTypeId: row.equipment_type_id,
        equipmentName: row.name,
        category: row.category,
        locationType: row.location_type,
        notes: row.notes,
    }));
}
/**
 * Set user's home equipment (replaces existing for the location type)
 */
async function setUserHomeEquipment(userId, equipmentTypeIds, locationType = 'home') {
    log.info({ userId, equipmentTypeIds, locationType }, 'Setting user home equipment');
    // Delete existing equipment for this location type
    await client_1.db.query(`DELETE FROM user_home_equipment WHERE user_id = $1 AND location_type = $2`, [userId, locationType]);
    // Insert new equipment
    for (const equipmentTypeId of equipmentTypeIds) {
        await client_1.db.query(`
      INSERT INTO user_home_equipment (user_id, equipment_type_id, location_type)
      VALUES ($1, $2, $3)
      ON CONFLICT (user_id, equipment_type_id, location_type) DO NOTHING
    `, [userId, equipmentTypeId, locationType]);
    }
}
/**
 * Add single equipment to user's home
 */
async function addUserHomeEquipment(userId, equipmentTypeId, locationType = 'home', notes) {
    await client_1.db.query(`
    INSERT INTO user_home_equipment (user_id, equipment_type_id, location_type, notes)
    VALUES ($1, $2, $3, $4)
    ON CONFLICT (user_id, equipment_type_id, location_type)
    DO UPDATE SET notes = COALESCE($4, user_home_equipment.notes)
  `, [userId, equipmentTypeId, locationType, notes || null]);
}
/**
 * Remove equipment from user's home
 */
async function removeUserHomeEquipment(userId, equipmentTypeId, locationType = 'home') {
    await client_1.db.query(`DELETE FROM user_home_equipment WHERE user_id = $1 AND equipment_type_id = $2 AND location_type = $3`, [userId, equipmentTypeId, locationType]);
}
/**
 * Get equipment IDs for user's home (simple list)
 */
async function getUserHomeEquipmentIds(userId, locationType) {
    const whereClause = locationType
        ? `WHERE user_id = $1 AND location_type = $2`
        : `WHERE user_id = $1`;
    const params = locationType ? [userId, locationType] : [userId];
    const rows = await client_1.db.queryAll(`SELECT equipment_type_id FROM user_home_equipment ${whereClause}`, params);
    return rows.map((r) => r.equipment_type_id);
}
//# sourceMappingURL=equipment.service.js.map