"use strict";
/**
 * Geo Service
 *
 * Location-based services using PostGIS:
 * - Find nearby hangouts with efficient spatial queries
 * - Geohash-based clustering
 * - Distance calculations
 * - Bounding box queries
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.geoService = void 0;
const client_1 = require("../db/client");
const logger_1 = require("../lib/logger");
const cache_service_1 = __importStar(require("../lib/cache.service"));
const _log = logger_1.loggers.core;
// Import geohash utilities (pure JS fallback)
const native_1 = require("@musclemap/native");
/**
 * Check if PostGIS is available
 */
async function hasPostGIS() {
    try {
        const result = await (0, client_1.queryOne)("SELECT EXISTS(SELECT 1 FROM pg_extension WHERE extname = 'postgis') as has");
        return result?.has ?? false;
    }
    catch {
        return false;
    }
}
exports.geoService = {
    /**
     * Find nearby hangouts with cursor-based pagination
     */
    async findNearby(query) {
        const { lat, lng, radiusM, typeId, limit = 20, cursor, userId } = query;
        // Validate coordinates
        if (lat < -90 || lat > 90 || lng < -180 || lng > 180) {
            throw new Error('Invalid coordinates');
        }
        if (radiusM <= 0 || radiusM > 100000) {
            throw new Error('Radius must be between 1 and 100,000 meters');
        }
        // Parse cursor
        let lastDistance = 0;
        let lastId = 0;
        if (cursor) {
            try {
                const decoded = Buffer.from(cursor, 'base64url').toString();
                const [d, i] = decoded.split(':');
                lastDistance = parseFloat(d);
                lastId = parseInt(i, 10);
            }
            catch {
                // Invalid cursor, start from beginning
            }
        }
        // Check for PostGIS
        const usePostGIS = await hasPostGIS();
        let rows;
        if (usePostGIS) {
            // PostGIS spatial query - Build params array dynamically
            // Base params: $1=lng, $2=lat, $3=radiusM, $4=lastDistance, $5=lastId
            const baseParams = [lng, lat, radiusM, lastDistance, lastId];
            let paramIndex = 6;
            // Handle userId join with parameterized query
            let userJoin = '';
            let memberSelect = ', NULL as is_member';
            if (userId) {
                userJoin = `LEFT JOIN hangout_memberships hm ON hm.hangout_id = h.id AND hm.user_id = $${paramIndex}`;
                memberSelect = ', (hm.user_id IS NOT NULL) as is_member';
                baseParams.push(userId);
                paramIndex++;
            }
            // Handle typeId filter
            let typeFilter = '';
            if (typeId) {
                typeFilter = `AND h.type_id = $${paramIndex}`;
                baseParams.push(typeId);
                paramIndex++;
            }
            // Add limit as last param
            baseParams.push(limit + 1);
            const limitParam = `$${paramIndex}`;
            const result = await (0, client_1.queryAll)(`
        SELECT
          h.id, h.name, h.type_id, ht.name as type_name, ht.slug as type_slug,
          ST_Distance(h.location, ST_MakePoint($1, $2)::geography) as distance_m,
          h.member_count, h.post_count, h.is_verified,
          ST_Y(h.location::geometry) as lat, ST_X(h.location::geometry) as lng,
          h.cover_image_url, h.description, h.city, h.country_code
          ${memberSelect}
        FROM hangouts h
        JOIN hangout_types ht ON ht.id = h.type_id
        ${userJoin}
        WHERE h.is_active = TRUE
          AND ST_DWithin(h.location, ST_MakePoint($1, $2)::geography, $3)
          AND (ST_Distance(h.location, ST_MakePoint($1, $2)::geography) > $4
               OR (ST_Distance(h.location, ST_MakePoint($1, $2)::geography) = $4 AND h.id > $5))
          ${typeFilter}
        ORDER BY distance_m, h.id
        LIMIT ${limitParam}
        `, baseParams);
            rows = result;
        }
        else {
            // Fallback without PostGIS using lat/lng columns
            const { minLat, maxLat, minLng, maxLng } = native_1.distance.boundingBox(lat, lng, radiusM);
            // Build params array dynamically for parameterized query
            // Base params: $1=minLat, $2=maxLat, $3=minLng, $4=maxLng, $5=lastId
            const baseParams = [minLat, maxLat, minLng, maxLng, lastId];
            let paramIndex = 6;
            // Handle userId join with parameterized query
            let userJoin = '';
            let memberSelect = ', NULL as is_member';
            if (userId) {
                userJoin = `LEFT JOIN hangout_memberships hm ON hm.hangout_id = h.id AND hm.user_id = $${paramIndex}`;
                memberSelect = ', (hm.user_id IS NOT NULL) as is_member';
                baseParams.push(userId);
                paramIndex++;
            }
            // Handle typeId filter
            let typeFilter = '';
            if (typeId) {
                typeFilter = `AND h.type_id = $${paramIndex}`;
                baseParams.push(typeId);
                paramIndex++;
            }
            // Add limit as last param
            baseParams.push(limit + 1);
            const limitParam = `$${paramIndex}`;
            const result = await (0, client_1.queryAll)(`
        SELECT
          h.id, h.name, h.type_id, ht.name as type_name, ht.slug as type_slug,
          0 as distance_m,
          h.member_count, h.post_count, h.is_verified,
          h.latitude as lat, h.longitude as lng,
          h.cover_image_url, h.description, h.city, h.country_code
          ${memberSelect}
        FROM hangouts h
        JOIN hangout_types ht ON ht.id = h.type_id
        ${userJoin}
        WHERE h.is_active = TRUE
          AND h.latitude BETWEEN $1 AND $2
          AND h.longitude BETWEEN $3 AND $4
          AND h.id > $5
          ${typeFilter}
        ORDER BY h.id
        LIMIT ${limitParam}
        `, baseParams);
            // Calculate actual distances and filter
            rows = result
                .map((r) => ({
                ...r,
                distance_m: native_1.distance.haversine(lat, lng, r.lat, r.lng),
            }))
                .filter((r) => r.distance_m <= radiusM)
                .sort((a, b) => a.distance_m - b.distance_m || a.id - b.id);
        }
        // Handle pagination
        const hasMore = rows.length > limit;
        const resultRows = hasMore ? rows.slice(0, limit) : rows;
        const hangouts = resultRows.map((r) => ({
            id: r.id,
            name: r.name,
            typeId: r.type_id,
            typeName: r.type_name,
            typeSlug: r.type_slug,
            distanceM: Math.round(r.distance_m),
            memberCount: r.member_count,
            postCount: r.post_count,
            isVerified: r.is_verified,
            location: { lat: r.lat, lng: r.lng },
            coverImageUrl: r.cover_image_url ?? undefined,
            description: r.description ?? undefined,
            city: r.city ?? undefined,
            countryCode: r.country_code ?? undefined,
            isMember: r.is_member ?? undefined,
        }));
        let nextCursor;
        if (hasMore && resultRows.length > 0) {
            const last = resultRows[resultRows.length - 1];
            nextCursor = Buffer.from(`${last.distance_m}:${last.id}`).toString('base64url');
        }
        return { hangouts, nextCursor };
    },
    /**
     * Find hangouts by geohash prefix (for clustering)
     */
    async findByGeohash(geohashPrefix, options = {}) {
        const { limit = 100, typeId } = options;
        const typeFilter = typeId ? 'AND h.type_id = $3' : '';
        const rows = await (0, client_1.queryAll)(`
      SELECT
        h.id, h.name, h.type_id, ht.name as type_name, ht.slug as type_slug,
        h.member_count, h.post_count, h.is_verified,
        COALESCE(ST_Y(h.location::geometry), h.latitude) as lat,
        COALESCE(ST_X(h.location::geometry), h.longitude) as lng,
        h.cover_image_url, h.description, h.city, h.country_code
      FROM hangouts h
      JOIN hangout_types ht ON ht.id = h.type_id
      WHERE h.is_active = TRUE
        AND h.geohash LIKE $1 || '%'
        ${typeFilter}
      ORDER BY h.member_count DESC
      LIMIT $2
      `, typeId ? [geohashPrefix, limit, typeId] : [geohashPrefix, limit]);
        return rows.map((r) => ({
            id: r.id,
            name: r.name,
            typeId: r.type_id,
            typeName: r.type_name,
            typeSlug: r.type_slug,
            distanceM: 0,
            memberCount: r.member_count,
            postCount: r.post_count,
            isVerified: r.is_verified,
            location: { lat: r.lat, lng: r.lng },
            coverImageUrl: r.cover_image_url ?? undefined,
            description: r.description ?? undefined,
            city: r.city ?? undefined,
            countryCode: r.country_code ?? undefined,
        }));
    },
    /**
     * Get geo stats for a region
     */
    async getStats(lat, lng, radiusM) {
        const usePostGIS = await hasPostGIS();
        if (usePostGIS) {
            const result = await (0, client_1.queryOne)(`
        SELECT
          COUNT(*) as hangout_count,
          COALESCE(SUM(member_count), 0) as member_count,
          COALESCE(SUM(post_count), 0) as post_count
        FROM hangouts h
        WHERE h.is_active = TRUE
          AND ST_DWithin(h.location, ST_MakePoint($1, $2)::geography, $3)
        `, [lng, lat, radiusM]);
            return {
                hangoutCount: parseInt(result?.hangout_count || '0', 10),
                memberCount: parseInt(result?.member_count || '0', 10),
                postCount: parseInt(result?.post_count || '0', 10),
            };
        }
        // Fallback
        const { minLat, maxLat, minLng, maxLng } = native_1.distance.boundingBox(lat, lng, radiusM);
        const result = await (0, client_1.queryOne)(`
      SELECT
        COUNT(*) as hangout_count,
        COALESCE(SUM(member_count), 0) as member_count,
        COALESCE(SUM(post_count), 0) as post_count
      FROM hangouts h
      WHERE h.is_active = TRUE
        AND h.latitude BETWEEN $1 AND $2
        AND h.longitude BETWEEN $3 AND $4
      `, [minLat, maxLat, minLng, maxLng]);
        return {
            hangoutCount: parseInt(result?.hangout_count || '0', 10),
            memberCount: parseInt(result?.member_count || '0', 10),
            postCount: parseInt(result?.post_count || '0', 10),
        };
    },
    /**
     * Get all hangout types (cached)
     */
    async getTypes() {
        return cache_service_1.default.getOrSet(cache_service_1.CACHE_PREFIX.HANGOUT_TYPES, cache_service_1.CACHE_TTL.HANGOUT_TYPES, async () => {
            const rows = await (0, client_1.queryAll)('SELECT id, slug, name, description, icon_url FROM hangout_types ORDER BY name');
            return rows.map((r) => ({
                id: r.id,
                slug: r.slug,
                name: r.name,
                description: r.description ?? undefined,
                iconUrl: r.icon_url ?? undefined,
            }));
        });
    },
    /**
     * Encode coordinates to geohash
     */
    encodeGeohash(lat, lng, precision = 9) {
        return native_1.geohash.encode(lat, lng, precision);
    },
    /**
     * Decode geohash to coordinates
     */
    decodeGeohash(hash) {
        return native_1.geohash.decode(hash);
    },
    /**
     * Get geohash neighbors
     */
    getGeohashNeighbors(hash) {
        return native_1.geohash.neighbors(hash);
    },
    /**
     * Calculate distance between two points
     */
    calculateDistance(lat1, lng1, lat2, lng2) {
        return native_1.distance.haversine(lat1, lng1, lat2, lng2);
    },
    /**
     * Get optimal geohash precision for a given radius
     */
    getOptimalPrecision(radiusMeters) {
        const cellWidths = [5009400, 1252350, 156543, 39136, 4892, 1223, 153, 38, 5, 1, 0.15, 0.04];
        for (let i = 0; i < cellWidths.length; i++) {
            if (radiusMeters >= cellWidths[i]) {
                return i + 1;
            }
        }
        return 12;
    },
};
//# sourceMappingURL=geo.service.js.map