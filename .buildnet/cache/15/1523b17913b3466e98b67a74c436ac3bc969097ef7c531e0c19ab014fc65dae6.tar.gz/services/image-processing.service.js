"use strict";
/**
 * Image Processing Service
 *
 * Processes uploaded exercise images for consistency:
 * - Resize to standard dimensions
 * - Convert to WebP format
 * - Generate thumbnails
 * - Strip EXIF metadata for privacy
 *
 * Uses lazy-loaded sharp to support Bun runtime.
 * On Bun: Image processing is degraded (returns original).
 * On Node.js: Full sharp processing with native performance.
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.processExerciseImage = processExerciseImage;
exports.validateImage = validateImage;
exports.generateFilename = generateFilename;
exports.getUploadDir = getUploadDir;
exports.ensureUploadDirs = ensureUploadDirs;
exports.saveImages = saveImages;
exports.deleteImages = deleteImages;
exports.getImageInfo = getImageInfo;
const logger_1 = require("../lib/logger");
const fs = __importStar(require("fs/promises"));
const path = __importStar(require("path"));
const crypto = __importStar(require("crypto"));
const sharp_compat_1 = require("../lib/sharp-compat");
const log = logger_1.loggers.api;
// Detect Bun runtime for logging
const isBun = typeof globalThis.Bun !== 'undefined';
// Image processing constants
const MAX_WIDTH = 800;
const MAX_HEIGHT = 600;
const THUMBNAIL_WIDTH = 200;
const THUMBNAIL_HEIGHT = 150;
const WEBP_QUALITY = 85;
/**
 * Process an exercise image for upload
 * - Resizes to max 800x600 maintaining aspect ratio
 * - Converts to WebP format
 * - Strips EXIF metadata
 * - Generates a thumbnail
 *
 * On Bun runtime: Returns minimally processed images (degraded mode)
 */
async function processExerciseImage(buffer) {
    const originalSize = buffer.length;
    // Check if full processing is available (Node.js with sharp)
    if ((0, sharp_compat_1.isFullProcessingAvailable)()) {
        // Use native sharp for full processing
        const sharp = (await Promise.resolve().then(() => __importStar(require('sharp')))).default;
        const metadata = await sharp(buffer).metadata();
        if (!metadata.width || !metadata.height) {
            throw new Error('Could not read image dimensions');
        }
        // Process main image
        const processed = await sharp(buffer)
            .rotate() // Auto-rotate based on EXIF
            .resize(MAX_WIDTH, MAX_HEIGHT, {
            fit: 'inside',
            withoutEnlargement: true,
        })
            .webp({ quality: WEBP_QUALITY })
            .toBuffer({ resolveWithObject: true });
        // Generate thumbnail
        const thumbnail = await sharp(buffer)
            .rotate()
            .resize(THUMBNAIL_WIDTH, THUMBNAIL_HEIGHT, {
            fit: 'cover',
            position: 'center',
        })
            .webp({ quality: 75 })
            .toBuffer({ resolveWithObject: true });
        log.info(`Image processed: ${originalSize} → ${processed.info.size} bytes (${Math.round((1 - processed.info.size / originalSize) * 100)}% reduction)`);
        return {
            processedBuffer: processed.data,
            thumbnailBuffer: thumbnail.data,
            width: processed.info.width,
            height: processed.info.height,
            thumbnailWidth: thumbnail.info.width,
            thumbnailHeight: thumbnail.info.height,
            format: 'webp',
            originalSize,
            processedSize: processed.info.size,
            thumbnailSize: thumbnail.info.size,
        };
    }
    else {
        // Bun runtime - degraded mode, return original
        log.warn('Image processing running in degraded mode (Bun runtime)');
        const metadata = await (0, sharp_compat_1.getImageMetadata)(buffer);
        if (!metadata.width || !metadata.height) {
            throw new Error('Could not read image dimensions');
        }
        return {
            processedBuffer: buffer,
            thumbnailBuffer: buffer,
            width: metadata.width,
            height: metadata.height,
            thumbnailWidth: metadata.width,
            thumbnailHeight: metadata.height,
            format: 'webp',
            originalSize,
            processedSize: buffer.length,
            thumbnailSize: buffer.length,
        };
    }
}
/**
 * Validate image before processing
 *
 * On Bun runtime: Uses basic validation (file size, magic bytes)
 * On Node.js: Full sharp validation including format and dimensions
 */
async function validateImage(buffer) {
    try {
        // Check file size first (max 10MB) - works on both runtimes
        if (buffer.length > 10 * 1024 * 1024) {
            return { valid: false, error: 'Image too large. Maximum size is 10MB' };
        }
        // Get metadata using runtime-appropriate method
        const metadata = (0, sharp_compat_1.isFullProcessingAvailable)()
            ? await (await Promise.resolve().then(() => __importStar(require('sharp')))).default(buffer).metadata()
            : await (0, sharp_compat_1.getImageMetadata)(buffer);
        // Check format
        const allowedFormats = ['jpeg', 'jpg', 'png', 'webp', 'heif', 'heic', 'gif'];
        if (!metadata.format || !allowedFormats.includes(metadata.format)) {
            return { valid: false, error: `Invalid format: ${metadata.format}. Allowed: ${allowedFormats.join(', ')}` };
        }
        // Check dimensions (minimum 200x200)
        if (!metadata.width || !metadata.height) {
            return { valid: false, error: 'Could not read image dimensions' };
        }
        if (metadata.width < 200 || metadata.height < 200) {
            return { valid: false, error: 'Image too small. Minimum size is 200x200 pixels' };
        }
        return { valid: true };
    }
    catch (_err) {
        return { valid: false, error: 'Invalid image file' };
    }
}
/**
 * Generate a unique filename for the image
 */
function generateFilename(exerciseId, userId) {
    const timestamp = Date.now();
    const random = crypto.randomBytes(4).toString('hex');
    return `${exerciseId}_${userId}_${timestamp}_${random}`;
}
/**
 * Get the upload directory path
 */
function getUploadDir() {
    const baseDir = process.env.UPLOAD_DIR || '/var/www/musclemap.me/uploads';
    return path.join(baseDir, 'exercise-images');
}
/**
 * Ensure upload directories exist
 */
async function ensureUploadDirs() {
    const baseDir = getUploadDir();
    const dirs = [
        baseDir,
        path.join(baseDir, 'originals'),
        path.join(baseDir, 'processed'),
        path.join(baseDir, 'thumbnails'),
    ];
    for (const dir of dirs) {
        await fs.mkdir(dir, { recursive: true });
    }
}
/**
 * Save processed images to disk
 */
async function saveImages(originalBuffer, processedImage, filename) {
    await ensureUploadDirs();
    const baseDir = getUploadDir();
    // Save original
    const originalPath = path.join(baseDir, 'originals', `${filename}.original`);
    await fs.writeFile(originalPath, originalBuffer);
    // Save processed
    const processedPath = path.join(baseDir, 'processed', `${filename}.webp`);
    await fs.writeFile(processedPath, processedImage.processedBuffer);
    // Save thumbnail
    const thumbnailPath = path.join(baseDir, 'thumbnails', `${filename}_thumb.webp`);
    await fs.writeFile(thumbnailPath, processedImage.thumbnailBuffer);
    // Generate URLs (relative to web root)
    const urlBase = '/uploads/exercise-images';
    return {
        originalUrl: `${urlBase}/originals/${filename}.original`,
        processedUrl: `${urlBase}/processed/${filename}.webp`,
        thumbnailUrl: `${urlBase}/thumbnails/${filename}_thumb.webp`,
        filename,
    };
}
/**
 * Delete images from disk
 */
async function deleteImages(filename) {
    const baseDir = getUploadDir();
    const paths = [
        path.join(baseDir, 'originals', `${filename}.original`),
        path.join(baseDir, 'processed', `${filename}.webp`),
        path.join(baseDir, 'thumbnails', `${filename}_thumb.webp`),
    ];
    for (const filePath of paths) {
        try {
            await fs.unlink(filePath);
        }
        catch (err) {
            // Ignore if file doesn't exist
            if (err.code !== 'ENOENT') {
                log.error(`Failed to delete ${filePath}:`, err);
            }
        }
    }
}
/**
 * Get image info from file
 *
 * On Bun runtime: Uses basic metadata extraction
 * On Node.js: Full sharp metadata
 */
async function getImageInfo(filePath) {
    try {
        const buffer = await fs.readFile(filePath);
        // Get metadata using runtime-appropriate method
        const metadata = (0, sharp_compat_1.isFullProcessingAvailable)()
            ? await (await Promise.resolve().then(() => __importStar(require('sharp')))).default(buffer).metadata()
            : await (0, sharp_compat_1.getImageMetadata)(buffer);
        return {
            width: metadata.width || 0,
            height: metadata.height || 0,
            format: metadata.format || 'unknown',
            size: buffer.length,
        };
    }
    catch {
        return null;
    }
}
//# sourceMappingURL=image-processing.service.js.map