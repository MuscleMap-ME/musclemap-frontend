/**
 * Video Processing Service
 *
 * Handles video processing tasks like thumbnail generation using FFmpeg.
 * Runs FFmpeg as a child process for video manipulation.
 */
export interface ThumbnailResult {
    success: boolean;
    thumbnailPath?: string;
    error?: string;
}
export interface VideoMetadata {
    duration?: number;
    width?: number;
    height?: number;
    codec?: string;
    fps?: number;
}
export interface ProcessingOptions {
    quality?: number;
    scale?: {
        width?: number;
        height?: number;
    };
    timestamp?: number;
}
/**
 * Check if FFmpeg is available on the system
 */
export declare function checkFfmpegAvailable(): Promise<boolean>;
export declare const VideoProcessingService: {
    /**
     * Generate a thumbnail from a video file
     *
     * @param videoPath - Path to the input video file
     * @param outputPath - Path where thumbnail will be saved (should end in .jpg or .png)
     * @param options - Processing options (timestamp, quality, scale)
     */
    generateThumbnail(videoPath: string, outputPath: string, options?: ProcessingOptions): Promise<ThumbnailResult>;
    /**
     * Get video metadata using FFprobe
     */
    getVideoMetadata(videoPath: string): Promise<VideoMetadata | null>;
    /**
     * Generate multiple thumbnails at different timestamps
     * Useful for creating preview strips
     */
    generateThumbnailStrip(videoPath: string, outputDir: string, count?: number, options?: Omit<ProcessingOptions, "timestamp">): Promise<string[]>;
    /**
     * Convert video to web-friendly format (MP4 H.264)
     * For future use with video optimization
     */
    convertToWebFormat(inputPath: string, outputPath: string, options?: {
        maxWidth?: number;
        maxHeight?: number;
        crf?: number;
    }): Promise<{
        success: boolean;
        error?: string;
    }>;
};
export default VideoProcessingService;
