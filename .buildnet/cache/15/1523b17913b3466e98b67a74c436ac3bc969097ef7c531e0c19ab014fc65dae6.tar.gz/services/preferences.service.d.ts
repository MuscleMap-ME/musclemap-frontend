/**
 * Preferences Service
 *
 * Business logic for user preferences, profiles, dashboard layouts,
 * sound packs, hydration tracking, and device settings.
 *
 * Uses raw SQL queries with the pg pool client (no Knex).
 */
import { UserPreferences, PreferenceProfile, DashboardWidget, DashboardLayoutConfig, WidgetDefinition, SoundPack, DeviceSettings, HydrationLog, Platform, HydrationSource } from '@musclemap/shared';
export declare function getUserPreferences(userId: string): Promise<{
    preferences: UserPreferences;
    activeProfileId: string | null;
    version: number;
}>;
export declare function updateUserPreferences(userId: string, updates: Partial<UserPreferences>): Promise<{
    preferences: UserPreferences;
    version: number;
}>;
export declare function resetUserPreferences(userId: string): Promise<UserPreferences>;
export declare function getEffectivePreferences(userId: string): Promise<UserPreferences>;
export declare function listProfiles(userId: string): Promise<PreferenceProfile[]>;
export declare function getProfile(userId: string, profileId: string): Promise<PreferenceProfile | null>;
export declare function createProfile(userId: string, data: {
    name: string;
    description?: string;
    icon?: string;
    color?: string;
    preferencesOverride?: Partial<UserPreferences>;
    isDefault?: boolean;
}): Promise<PreferenceProfile>;
export declare function updateProfile(userId: string, profileId: string, data: {
    name?: string;
    description?: string;
    icon?: string;
    color?: string;
    preferencesOverride?: Partial<UserPreferences>;
    isDefault?: boolean;
    sortOrder?: number;
}): Promise<PreferenceProfile | null>;
export declare function deleteProfile(userId: string, profileId: string): Promise<boolean>;
export declare function activateProfile(userId: string, profileId: string): Promise<boolean>;
export declare function deactivateProfile(userId: string): Promise<void>;
export declare function getDashboardLayout(userId: string, platform?: Platform, profileId?: string): Promise<DashboardLayoutConfig | null>;
export declare function saveDashboardLayout(userId: string, data: {
    widgets: DashboardWidget[];
    columns?: number;
    rowHeight?: number;
    platform?: Platform;
    profileId?: string;
}): Promise<DashboardLayoutConfig>;
export declare function getAvailableWidgets(): Promise<WidgetDefinition[]>;
export declare function getSystemSoundPacks(): Promise<SoundPack[]>;
export declare function getUserSoundPacks(userId: string): Promise<SoundPack[]>;
export declare function createUserSoundPack(userId: string, data: {
    name: string;
    description?: string;
    sounds: SoundPack['sounds'];
    isPublic?: boolean;
}): Promise<SoundPack>;
export declare function deleteUserSoundPack(userId: string, packId: string): Promise<boolean>;
export declare function logHydration(userId: string, amountOz: number, workoutSessionId?: string, source?: HydrationSource): Promise<HydrationLog>;
export declare function getTodayHydration(userId: string): Promise<{
    logs: HydrationLog[];
    totalOz: number;
}>;
export declare function getHydrationHistory(userId: string, days?: number): Promise<{
    date: string;
    totalOz: number;
}[]>;
export declare function listDevices(userId: string): Promise<DeviceSettings[]>;
export declare function registerDevice(userId: string, data: {
    deviceId: string;
    deviceName?: string;
    platform: Platform;
    deviceModel?: string;
    osVersion?: string;
    appVersion?: string;
    pushToken?: string;
}): Promise<DeviceSettings>;
export declare function updateDeviceSettings(userId: string, deviceId: string, data: {
    deviceName?: string;
    settingsOverride?: Partial<UserPreferences>;
    syncEnabled?: boolean;
    pushEnabled?: boolean;
    pushToken?: string;
}): Promise<DeviceSettings | null>;
export declare function removeDevice(userId: string, deviceId: string): Promise<boolean>;
export declare function syncDevice(userId: string, deviceId: string): Promise<{
    preferences: UserPreferences;
    lastSyncAt: string;
}>;
