/**
 * Exercise Image Validator Service
 *
 * Two-stage AI validation for exercise image submissions:
 * 1. NSFW Detection - Block inappropriate content
 * 2. Exercise Verification - Check if image shows the correct exercise
 *
 * Uses existing nsfwjs integration + heuristic checks for exercise verification.
 *
 * On Bun runtime: Basic validation only (NSFW detection returns 'review')
 * On Node.js: Full validation with NSFW detection and image stats
 */
import { ModerationResult } from '../lib/nsfw-detector';
export interface ValidationResult {
    passed: boolean;
    nsfwScore: number;
    exerciseMatchScore: number;
    notes: string[];
    requiresManualReview: boolean;
    rejectionReason?: string;
    nsfwDetails?: ModerationResult;
}
/**
 * Validate an exercise image submission
 */
export declare function validateExerciseImage(imageBuffer: Buffer, exerciseName: string): Promise<ValidationResult>;
/**
 * Quick check if image is likely safe (for preview before full upload)
 */
export declare function quickSafetyCheck(imageBuffer: Buffer): Promise<{
    likelySafe: boolean;
    reason?: string;
}>;
