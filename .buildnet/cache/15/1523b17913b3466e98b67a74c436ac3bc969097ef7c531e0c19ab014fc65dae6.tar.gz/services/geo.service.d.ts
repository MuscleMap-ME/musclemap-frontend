/**
 * Geo Service
 *
 * Location-based services using PostGIS:
 * - Find nearby hangouts with efficient spatial queries
 * - Geohash-based clustering
 * - Distance calculations
 * - Bounding box queries
 */
interface NearbyQuery {
    lat: number;
    lng: number;
    radiusM: number;
    typeId?: number;
    limit?: number;
    cursor?: string;
    userId?: string;
}
interface HangoutResult {
    id: number;
    name: string;
    typeId: number;
    typeName: string;
    typeSlug: string;
    distanceM: number;
    memberCount: number;
    postCount: number;
    isVerified: boolean;
    location: {
        lat: number;
        lng: number;
    };
    coverImageUrl?: string;
    description?: string;
    city?: string;
    countryCode?: string;
    isMember?: boolean;
}
interface GeoStats {
    hangoutCount: number;
    memberCount: number;
    postCount: number;
}
export declare const geoService: {
    /**
     * Find nearby hangouts with cursor-based pagination
     */
    findNearby(query: NearbyQuery): Promise<{
        hangouts: HangoutResult[];
        nextCursor?: string;
    }>;
    /**
     * Find hangouts by geohash prefix (for clustering)
     */
    findByGeohash(geohashPrefix: string, options?: {
        limit?: number;
        typeId?: number;
    }): Promise<HangoutResult[]>;
    /**
     * Get geo stats for a region
     */
    getStats(lat: number, lng: number, radiusM: number): Promise<GeoStats>;
    /**
     * Get all hangout types (cached)
     */
    getTypes(): Promise<Array<{
        id: number;
        slug: string;
        name: string;
        description?: string;
        iconUrl?: string;
    }>>;
    /**
     * Encode coordinates to geohash
     */
    encodeGeohash(lat: number, lng: number, precision?: number): string;
    /**
     * Decode geohash to coordinates
     */
    decodeGeohash(hash: string): {
        lat: number;
        lng: number;
    };
    /**
     * Get geohash neighbors
     */
    getGeohashNeighbors(hash: string): string[];
    /**
     * Calculate distance between two points
     */
    calculateDistance(lat1: number, lng1: number, lat2: number, lng2: number): number;
    /**
     * Get optimal geohash precision for a given radius
     */
    getOptimalPrecision(radiusMeters: number): number;
};
export {};
