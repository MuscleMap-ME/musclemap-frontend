/**
 * Live Activity Logger Service
 *
 * Logs anonymous activity events for real-time monitoring.
 *
 * Privacy-First Architecture:
 * - Privacy settings are checked BEFORE any logging (gate at collection)
 * - Events are completely anonymous (no user_id stored)
 * - Users who opt out are NEVER logged - not even aggregated
 * - Location data is only included if user explicitly allows it
 */
export interface ActivityEventInput {
    type: 'workout.completed' | 'exercise.completed' | 'achievement.earned';
    exerciseId?: string;
    exerciseName?: string;
    muscleGroup?: string;
    location?: {
        latitude?: number;
        longitude?: number;
        countryCode?: string;
        region?: string;
        city?: string;
    };
}
export interface LiveActivityEvent {
    id: string;
    type: string;
    timestamp: string;
    exerciseName?: string;
    muscleGroup?: string;
    geoBucket?: string;
    city?: string;
    country?: string;
}
/**
 * Get approximate center coordinates for a geo bucket.
 * This is used for map display - returns center of the ~10km cell.
 */
export declare function getGeoBucketCenter(_geoBucket: string): {
    lat: number;
    lng: number;
} | null;
/**
 * Log an anonymous activity event.
 *
 * CRITICAL: This function respects privacy settings absolutely.
 * If the user has opted out, NO activity is logged - not even anonymized.
 *
 * @param userId - The user's ID (used ONLY to check privacy settings)
 * @param event - The activity event to log
 * @returns true if logged, false if user opted out
 */
export declare function logActivityEvent(userId: string, event: ActivityEventInput): Promise<boolean>;
/**
 * Delete activity events older than 24 hours.
 * This should be called by a scheduled job.
 */
export declare function cleanupOldEvents(): Promise<number>;
/**
 * Get activity stats for a time window.
 */
export declare function getActivityStats(minutes?: number): Promise<{
    total: number;
    byMuscle: Record<string, number>;
    byCountry: Record<string, number>;
    byType: Record<string, number>;
}>;
/**
 * Get geo-clustered activity data for map display.
 */
export declare function getMapData(minutes?: number): Promise<Array<{
    geoBucket: string;
    count: number;
    city?: string;
    country?: string;
    lat?: number;
    lng?: number;
}>>;
/**
 * Get hierarchy drill-down data.
 */
export declare function getHierarchyData(level: 'global' | 'country' | 'region', parentCode?: string, minutes?: number): Promise<Array<{
    name: string;
    code: string;
    count: number;
}>>;
/**
 * Get trending exercises.
 */
export declare function getTrendingExercises(minutes?: number, limit?: number): Promise<Array<{
    exerciseId: string;
    exerciseName: string;
    muscleGroup: string;
    count: number;
}>>;
/**
 * Get recent activity events for the feed.
 */
export declare function getRecentEvents(limit?: number): Promise<LiveActivityEvent[]>;
