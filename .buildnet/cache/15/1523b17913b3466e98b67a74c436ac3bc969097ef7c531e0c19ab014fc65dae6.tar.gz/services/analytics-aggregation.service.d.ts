/**
 * Analytics Aggregation Service
 *
 * Handles scheduled aggregation tasks for the Empire analytics dashboard:
 * - Daily rollups (aggregate previous day's metrics)
 * - User activity summaries (denormalized per-user stats)
 * - Segment recalculation (dynamic behavioral segments)
 * - Cohort retention updates
 * - Materialized view refresh
 *
 * Designed for scale:
 * - Processes in batches to avoid memory issues
 * - Uses efficient SQL aggregations
 * - Supports incremental updates
 */
/**
 * Calculate daily rollups for a specific date.
 * Called by scheduled job at midnight.
 */
declare function calculateDailyRollups(date?: Date): Promise<void>;
/**
 * Update user activity summaries.
 * Called every 15 minutes for recently active users.
 */
declare function updateUserSummaries(userIds?: string[]): Promise<number>;
/**
 * Recalculate dynamic segment memberships.
 * Called every hour.
 */
declare function recalculateSegments(): Promise<void>;
/**
 * Update cohort retention metrics.
 * Called daily at 1:30 AM.
 */
declare function updateCohortRetention(): Promise<void>;
/**
 * Refresh all analytics materialized views.
 * Called every 15 minutes.
 */
declare function refreshMaterializedViews(): Promise<void>;
export declare const analyticsAggregation: {
    calculateDailyRollups: typeof calculateDailyRollups;
    updateUserSummaries: typeof updateUserSummaries;
    recalculateSegments: typeof recalculateSegments;
    updateCohortRetention: typeof updateCohortRetention;
    refreshMaterializedViews: typeof refreshMaterializedViews;
    runJob(jobName: string): Promise<void>;
};
export default analyticsAggregation;
