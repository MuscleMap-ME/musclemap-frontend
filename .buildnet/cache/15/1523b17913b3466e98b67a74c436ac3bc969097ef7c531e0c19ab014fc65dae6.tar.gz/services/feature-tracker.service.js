"use strict";
/**
 * Feature Tracker Service
 *
 * Tracks feature usage events for analytics in the Empire control panel.
 *
 * Architecture:
 * - Events are stored in feature_usage_events table
 * - Privacy settings are respected (users who opt out are NOT tracked)
 * - Supports batch tracking for efficiency
 * - Integrates with user activity summaries
 *
 * Usage:
 *   await featureTracker.track({
 *     userId: 'user_123',
 *     featureId: 'workout_log',
 *     action: 'complete',
 *     metadata: { exerciseCount: 5 }
 *   });
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.featureTracker = void 0;
exports.trackFeature = trackFeature;
exports.trackView = trackView;
exports.trackInteract = trackInteract;
exports.trackComplete = trackComplete;
const client_1 = require("../db/client");
const logger_1 = require("../lib/logger");
const redis_1 = require("../lib/redis");
const log = logger_1.loggers.core;
// Privacy settings checked: minimalistMode (opt_out column in user_privacy_mode)
// Feature category mapping (derived from feature_id prefix or lookup)
const FEATURE_CATEGORIES = {
    workout: 'fitness',
    prescription: 'fitness',
    muscle: 'fitness',
    exercise: 'fitness',
    '1rm': 'fitness',
    rest: 'fitness',
    superset: 'fitness',
    leaderboard: 'social',
    community: 'social',
    profile: 'social',
    high_five: 'social',
    follow: 'social',
    crew: 'social',
    competition: 'competition',
    rivalry: 'competition',
    credits: 'economy',
    store: 'economy',
    stats: 'progression',
    achievement: 'progression',
    rank: 'progression',
    milestone: 'progression',
    skill: 'progression',
    journey: 'progression',
    settings: 'profile',
    archetype: 'profile',
    theme: 'profile',
    privacy: 'profile',
    messages: 'messaging',
    message: 'messaging',
    notifications: 'notifications',
    notification: 'notifications',
    onboarding: 'onboarding',
    tutorial: 'onboarding',
    progress: 'analytics',
    history: 'analytics',
    export: 'analytics',
};
// ============================================
// PRIVACY CHECK
// ============================================
async function shouldTrackUser(userId) {
    // Check cache first
    const redisClient = (0, redis_1.getRedis)();
    if (redisClient) {
        const cached = await redisClient.get(`analytics:opt_out:${userId}`);
        if (cached !== null) {
            return cached !== '1';
        }
    }
    // Check privacy settings
    const settings = await (0, client_1.queryOne)(`SELECT
       COALESCE(minimalist_mode, FALSE) as opt_out
     FROM user_privacy_mode
     WHERE user_id = $1`, [userId]);
    // Default is opted IN to analytics
    const optedOut = settings?.opt_out ?? false;
    // Cache for 5 minutes
    if (redisClient) {
        await redisClient.setex(`analytics:opt_out:${userId}`, 300, optedOut ? '1' : '0');
    }
    return !optedOut;
}
// ============================================
// CATEGORY RESOLUTION
// ============================================
function getCategoryFromFeatureId(featureId) {
    // Try prefix matching
    for (const [prefix, category] of Object.entries(FEATURE_CATEGORIES)) {
        if (featureId.startsWith(prefix)) {
            return category;
        }
    }
    // Fallback to 'other'
    return 'other';
}
async function resolveFeatureCategory(featureId) {
    // First try to get from feature_definitions table
    const definition = await (0, client_1.queryOne)('SELECT category FROM feature_definitions WHERE id = $1', [featureId]);
    if (definition) {
        return definition.category;
    }
    // Fallback to prefix matching
    return getCategoryFromFeatureId(featureId);
}
// ============================================
// MAIN SERVICE
// ============================================
exports.featureTracker = {
    /**
     * Track a single feature usage event
     */
    async track(event) {
        try {
            // Privacy check - don't track users who opted out
            if (!(await shouldTrackUser(event.userId))) {
                return false;
            }
            const category = await resolveFeatureCategory(event.featureId);
            await (0, client_1.query)(`INSERT INTO feature_usage_events
         (user_id, session_id, feature_id, feature_category, action, metadata, duration_ms)
         VALUES ($1, $2, $3, $4, $5, $6, $7)`, [
                event.userId,
                event.sessionId || null,
                event.featureId,
                category,
                event.action,
                JSON.stringify(event.metadata || {}),
                event.durationMs || null,
            ]);
            // Mark user as needing summary update (batch processed by scheduled job)
            const redisClient = (0, redis_1.getRedis)();
            if (redisClient) {
                await redisClient.sadd('analytics:users_to_update', event.userId);
                // Expire the set after 1 hour to prevent unbounded growth
                await redisClient.expire('analytics:users_to_update', 3600);
            }
            return true;
        }
        catch (error) {
            log.error('Error tracking feature usage', { error, event });
            return false;
        }
    },
    /**
     * Track multiple feature usage events efficiently
     */
    async trackBatch(events) {
        if (events.length === 0)
            return 0;
        let tracked = 0;
        try {
            // Group events by user to check privacy settings once per user
            const userIds = [...new Set(events.map((e) => e.userId))];
            const trackableUsers = new Set();
            for (const userId of userIds) {
                if (await shouldTrackUser(userId)) {
                    trackableUsers.add(userId);
                }
            }
            // Filter to only trackable events
            const trackableEvents = events.filter((e) => trackableUsers.has(e.userId));
            if (trackableEvents.length === 0)
                return 0;
            // Resolve categories
            const categorizedEvents = await Promise.all(trackableEvents.map(async (event) => ({
                ...event,
                category: await resolveFeatureCategory(event.featureId),
            })));
            // Batch insert
            const values = categorizedEvents
                .map((e, i) => `($${i * 7 + 1}, $${i * 7 + 2}, $${i * 7 + 3}, $${i * 7 + 4}, $${i * 7 + 5}, $${i * 7 + 6}, $${i * 7 + 7})`)
                .join(', ');
            const params = categorizedEvents.flatMap((e) => [
                e.userId,
                e.sessionId || null,
                e.featureId,
                e.category,
                e.action,
                JSON.stringify(e.metadata || {}),
                e.durationMs || null,
            ]);
            await (0, client_1.query)(`INSERT INTO feature_usage_events
         (user_id, session_id, feature_id, feature_category, action, metadata, duration_ms)
         VALUES ${values}`, params);
            tracked = categorizedEvents.length;
            // Mark users for summary update
            const redisClient = (0, redis_1.getRedis)();
            if (redisClient) {
                await redisClient.sadd('analytics:users_to_update', ...trackableUsers);
                await redisClient.expire('analytics:users_to_update', 3600);
            }
        }
        catch (error) {
            log.error('Error batch tracking feature usage', { error, eventCount: events.length });
        }
        return tracked;
    },
    /**
     * Get feature usage summary for a specific user
     */
    async getUserFeatureUsage(userId, days = 30) {
        const results = await (0, client_1.queryAll)(`SELECT
         fue.feature_id,
         fue.feature_category,
         COALESCE(fd.name, fue.feature_id) as feature_name,
         COUNT(*) as use_count,
         MAX(fue.created_at) as last_used_at
       FROM feature_usage_events fue
       LEFT JOIN feature_definitions fd ON fd.id = fue.feature_id
       WHERE fue.user_id = $1
         AND fue.created_at > NOW() - INTERVAL '1 day' * $2
       GROUP BY fue.feature_id, fue.feature_category, fd.name
       ORDER BY use_count DESC`, [userId, days]);
        return results.map((r) => ({
            featureId: r.feature_id,
            featureCategory: r.feature_category,
            featureName: r.feature_name,
            useCount: parseInt(r.use_count),
            lastUsedAt: r.last_used_at,
        }));
    },
    /**
     * Get top features by usage across all users
     */
    async getTopFeatures(days = 30, limit = 20) {
        const results = await (0, client_1.queryAll)(`SELECT
         fue.feature_id,
         fue.feature_category,
         COALESCE(fd.name, fue.feature_id) as feature_name,
         COUNT(*) as total_uses,
         COUNT(DISTINCT fue.user_id) as unique_users
       FROM feature_usage_events fue
       LEFT JOIN feature_definitions fd ON fd.id = fue.feature_id
       WHERE fue.created_at > NOW() - INTERVAL '1 day' * $1
       GROUP BY fue.feature_id, fue.feature_category, fd.name
       ORDER BY total_uses DESC
       LIMIT $2`, [days, limit]);
        return results.map((r) => ({
            featureId: r.feature_id,
            featureCategory: r.feature_category,
            featureName: r.feature_name,
            totalUses: parseInt(r.total_uses),
            uniqueUsers: parseInt(r.unique_users),
        }));
    },
    /**
     * Get all feature definitions
     */
    async getFeatureDefinitions(activeOnly = true) {
        const results = await (0, client_1.queryAll)(`SELECT id, name, category, description, is_premium, is_active, tracking_enabled
       FROM feature_definitions
       ${activeOnly ? 'WHERE is_active = TRUE' : ''}
       ORDER BY category, sort_order, name`, []);
        return results.map((r) => ({
            id: r.id,
            name: r.name,
            category: r.category,
            description: r.description,
            isPremium: r.is_premium,
            isActive: r.is_active,
            trackingEnabled: r.tracking_enabled,
        }));
    },
    /**
     * Get feature popularity from materialized view (fast)
     */
    async getFeaturePopularity() {
        const results = await (0, client_1.queryAll)(`SELECT
         feature_id,
         feature_category,
         feature_name,
         total_uses,
         unique_users,
         uses_24h,
         uses_7d,
         uses_30d
       FROM mv_feature_popularity
       ORDER BY uses_30d DESC`, []);
        return results.map((r) => ({
            featureId: r.feature_id,
            featureCategory: r.feature_category,
            featureName: r.feature_name,
            totalUses: parseInt(r.total_uses),
            uniqueUsers: parseInt(r.unique_users),
            uses24h: parseInt(r.uses_24h),
            uses7d: parseInt(r.uses_7d),
            uses30d: parseInt(r.uses_30d),
        }));
    },
};
// ============================================
// CONVENIENCE TRACKING FUNCTIONS
// ============================================
/**
 * Quick track helper - fire and forget (doesn't await)
 */
function trackFeature(userId, featureId, action = 'view', metadata) {
    // Fire and forget - don't block the response
    exports.featureTracker.track({ userId, featureId, action, metadata }).catch((err) => {
        log.warn('Failed to track feature', { err, userId, featureId });
    });
}
/**
 * Track feature view (most common action)
 */
function trackView(userId, featureId, metadata) {
    trackFeature(userId, featureId, 'view', metadata);
}
/**
 * Track feature interaction
 */
function trackInteract(userId, featureId, metadata) {
    trackFeature(userId, featureId, 'interact', metadata);
}
/**
 * Track feature completion
 */
function trackComplete(userId, featureId, metadata) {
    trackFeature(userId, featureId, 'complete', metadata);
}
exports.default = exports.featureTracker;
//# sourceMappingURL=feature-tracker.service.js.map