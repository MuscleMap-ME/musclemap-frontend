/**
 * Internationalization Service
 *
 * Manages translations for:
 * - UI strings (static, loaded at startup)
 * - User-generated content (dynamic, on-demand)
 * - Content caching with Redis
 */
export declare const SUPPORTED_LANGUAGES: readonly ["en", "es", "fr", "de", "it", "pt-BR", "nl", "sv", "da", "fi", "pl", "cs", "ro", "hu", "tr", "el", "ru", "uk", "he", "ar", "hi", "th", "vi", "ja", "ko", "zh-Hans"];
export type SupportedLanguage = typeof SUPPORTED_LANGUAGES[number];
export declare const RTL_LANGUAGES: readonly ["he", "ar"];
interface TranslationRequest {
    contentType: string;
    contentId: string;
    fieldName: string;
    originalText: string;
    sourceLang: SupportedLanguage;
    targetLang: SupportedLanguage;
}
interface Translation {
    translatedText: string;
    isMachineTranslated: boolean;
    isHumanCorrected: boolean;
    confidenceScore?: number;
}
interface LanguageInfo {
    code: string;
    name: string;
    nativeName: string;
    rtl: boolean;
    enabled: boolean;
}
/**
 * Check if a language is supported
 */
export declare function isLanguageSupported(lang: string): lang is SupportedLanguage;
/**
 * Check if a language is RTL
 */
export declare function isRTL(lang: string): boolean;
/**
 * Normalize language code
 */
export declare function normalizeLanguageCode(lang: string): SupportedLanguage;
export declare const i18nService: {
    /**
     * Get all supported languages (cached)
     */
    getLanguages(): Promise<LanguageInfo[]>;
    /**
     * Get cached translation
     */
    getCachedTranslation(contentType: string, contentId: string, fieldName: string, targetLang: SupportedLanguage): Promise<Translation | null>;
    /**
     * Save a translation
     */
    saveTranslation(request: TranslationRequest, translation: Translation): Promise<void>;
    /**
     * Get translation for content (with optional machine translation)
     */
    translate(contentType: string, contentId: string, fieldName: string, originalText: string, sourceLang: SupportedLanguage, targetLang: SupportedLanguage, options?: {
        skipCache?: boolean;
        translateIfMissing?: boolean;
    }): Promise<Translation | null>;
    /**
     * Batch translate multiple fields
     */
    translateBatch(contentType: string, contentId: string, fields: Array<{
        fieldName: string;
        text: string;
    }>, sourceLang: SupportedLanguage, targetLang: SupportedLanguage): Promise<Record<string, Translation>>;
    /**
     * Delete all translations for a content item
     */
    deleteTranslations(contentType: string, contentId: string): Promise<void>;
    /**
     * Get user's preferred language
     */
    getUserLanguage(userId: string): Promise<SupportedLanguage>;
    /**
     * Set user's preferred language
     */
    setUserLanguage(userId: string, lang: SupportedLanguage): Promise<void>;
    /**
     * Get translation stats
     */
    getStats(): Promise<{
        totalTranslations: number;
        translationsByLanguage: Record<string, number>;
        machineTranslatedCount: number;
        humanCorrectedCount: number;
    }>;
};
export {};
