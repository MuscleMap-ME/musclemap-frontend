/**
 * Issues Service
 *
 * Comprehensive bug and issue tracking system:
 * - CRUD operations for issues
 * - Comments management
 * - Voting system
 * - Subscriptions
 * - Status management
 * - Search and filtering
 */
export declare enum IssueType {
    BUG = 0,
    FEATURE = 1,
    ENHANCEMENT = 2,
    ACCOUNT = 3,
    QUESTION = 4,
    OTHER = 5
}
export declare enum IssueStatus {
    OPEN = 0,
    IN_PROGRESS = 1,
    UNDER_REVIEW = 2,
    RESOLVED = 3,
    CLOSED = 4,
    WONT_FIX = 5,
    DUPLICATE = 6
}
export declare enum IssuePriority {
    LOW = 0,
    MEDIUM = 1,
    HIGH = 2,
    CRITICAL = 3
}
export declare enum UpdateType {
    UPDATE = 0,
    RELEASE = 1,
    ANNOUNCEMENT = 2,
    BUGFIX = 3,
    MAINTENANCE = 4
}
export declare enum RoadmapStatus {
    PLANNED = 0,
    IN_PROGRESS = 1,
    COMPLETED = 2,
    PAUSED = 3,
    CANCELLED = 4
}
export interface IssueLabel {
    id: string;
    name: string;
    slug: string;
    description?: string;
    color: string;
    icon?: string;
    displayOrder: number;
    isSystem: boolean;
}
export interface Issue {
    id: string;
    issueNumber: number;
    title: string;
    description: string;
    type: IssueType;
    status: IssueStatus;
    priority: IssuePriority;
    authorId: string;
    authorUsername?: string;
    authorDisplayName?: string;
    authorAvatarUrl?: string;
    assigneeId?: string;
    assigneeUsername?: string;
    assigneeDisplayName?: string;
    labelIds: string[];
    labels?: IssueLabel[];
    voteCount: number;
    commentCount: number;
    subscriberCount: number;
    viewCount: number;
    isPinned: boolean;
    isLocked: boolean;
    isPublic: boolean;
    resolvedAt?: Date;
    resolvedBy?: string;
    resolutionNote?: string;
    browserInfo?: Record<string, any>;
    deviceInfo?: Record<string, any>;
    pageUrl?: string;
    screenshotUrls: string[];
    relatedIssueIds: string[];
    duplicateOfId?: string;
    createdAt: Date;
    updatedAt: Date;
    hasVoted?: boolean;
    isSubscribed?: boolean;
}
export interface IssueComment {
    id: string;
    issueId: string;
    authorId: string;
    authorUsername?: string;
    authorDisplayName?: string;
    authorAvatarUrl?: string;
    authorRoles?: string[];
    parentId?: string;
    content: string;
    isStaffReply: boolean;
    isSolution: boolean;
    isHidden: boolean;
    editCount: number;
    lastEditedAt?: Date;
    createdAt: Date;
    updatedAt: Date;
}
export interface DevUpdate {
    id: string;
    title: string;
    content: string;
    type: UpdateType;
    authorId: string;
    authorUsername?: string;
    authorDisplayName?: string;
    relatedIssueIds: string[];
    isPublished: boolean;
    publishedAt?: Date;
    viewCount: number;
    createdAt: Date;
    updatedAt: Date;
}
export interface RoadmapItem {
    id: string;
    title: string;
    description?: string;
    status: RoadmapStatus;
    quarter?: string;
    category?: string;
    progress: number;
    relatedIssueIds: string[];
    voteCount: number;
    displayOrder: number;
    isPublic: boolean;
    startedAt?: Date;
    completedAt?: Date;
    createdAt: Date;
    updatedAt: Date;
    hasVoted?: boolean;
}
interface CreateIssueRequest {
    title: string;
    description: string;
    type: IssueType;
    priority?: IssuePriority;
    labelIds?: string[];
    browserInfo?: Record<string, any>;
    deviceInfo?: Record<string, any>;
    pageUrl?: string;
    screenshotUrls?: string[];
}
interface UpdateIssueRequest {
    title?: string;
    description?: string;
    type?: IssueType;
    status?: IssueStatus;
    priority?: IssuePriority;
    assigneeId?: string | null;
    labelIds?: string[];
    isPinned?: boolean;
    isLocked?: boolean;
    isPublic?: boolean;
    resolutionNote?: string;
    duplicateOfId?: string;
    relatedIssueIds?: string[];
}
interface ListIssuesOptions {
    status?: IssueStatus | IssueStatus[];
    type?: IssueType;
    authorId?: string;
    assigneeId?: string;
    labelSlug?: string;
    search?: string;
    sortBy?: 'newest' | 'oldest' | 'votes' | 'comments' | 'updated';
    limit?: number;
    offset?: number;
    userId?: string;
}
export declare const issuesService: {
    getLabels(): Promise<IssueLabel[]>;
    createIssue(authorId: string, request: CreateIssueRequest): Promise<Issue>;
    getIssueById(issueId: string, userId?: string): Promise<Issue | null>;
    getLabelsByIds(ids: string[]): Promise<IssueLabel[]>;
    listIssues(options?: ListIssuesOptions): Promise<{
        issues: Issue[];
        total: number;
    }>;
    updateIssue(issueId: string, actorId: string, request: UpdateIssueRequest, isAdmin?: boolean): Promise<Issue>;
    incrementViewCount(issueId: string): Promise<void>;
    vote(issueId: string, userId: string): Promise<{
        voted: boolean;
        voteCount: number;
    }>;
    subscribe(issueId: string, userId: string): Promise<{
        subscribed: boolean;
        subscriberCount: number;
    }>;
    createComment(issueId: string, authorId: string, content: string, parentId?: string, isStaff?: boolean): Promise<IssueComment>;
    getComments(issueId: string, options?: {
        limit?: number;
        offset?: number;
    }): Promise<{
        comments: IssueComment[];
        total: number;
    }>;
    markCommentAsSolution(commentId: string, issueId: string, actorId: string): Promise<void>;
    createDevUpdate(authorId: string, request: {
        title: string;
        content: string;
        type: UpdateType;
        relatedIssueIds?: string[];
        isPublished?: boolean;
    }): Promise<DevUpdate>;
    listDevUpdates(options?: {
        type?: UpdateType;
        limit?: number;
        offset?: number;
    }): Promise<{
        updates: DevUpdate[];
        total: number;
    }>;
    listRoadmapItems(options?: {
        status?: RoadmapStatus;
        quarter?: string;
        userId?: string;
    }): Promise<RoadmapItem[]>;
    voteRoadmapItem(roadmapId: string, userId: string): Promise<{
        voted: boolean;
        voteCount: number;
    }>;
    getStats(): Promise<{
        totalIssues: number;
        openIssues: number;
        resolvedIssues: number;
        totalVotes: number;
        issuesByType: Record<string, number>;
        issuesByStatus: Record<string, number>;
    }>;
};
export {};
