"use strict";
/**
 * Internationalization Service
 *
 * Manages translations for:
 * - UI strings (static, loaded at startup)
 * - User-generated content (dynamic, on-demand)
 * - Content caching with Redis
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.i18nService = exports.RTL_LANGUAGES = exports.SUPPORTED_LANGUAGES = void 0;
exports.isLanguageSupported = isLanguageSupported;
exports.isRTL = isRTL;
exports.normalizeLanguageCode = normalizeLanguageCode;
const client_1 = require("../db/client");
const logger_1 = require("../lib/logger");
const config_1 = require("../config");
const cache_service_1 = __importStar(require("../lib/cache.service"));
const log = logger_1.loggers.core;
// Supported languages (26 languages as specified)
exports.SUPPORTED_LANGUAGES = [
    'en', 'es', 'fr', 'de', 'it', 'pt-BR', 'nl', 'sv', 'da', 'fi',
    'pl', 'cs', 'ro', 'hu', 'tr', 'el', 'ru', 'uk', 'he', 'ar',
    'hi', 'th', 'vi', 'ja', 'ko', 'zh-Hans',
];
// RTL languages
exports.RTL_LANGUAGES = ['he', 'ar'];
/**
 * Map our language codes to LibreTranslate/standard codes
 */
function mapLanguageCode(lang) {
    const mapping = {
        'pt-BR': 'pt',
        'zh-Hans': 'zh',
    };
    return mapping[lang] || lang;
}
/**
 * Call external translation API (LibreTranslate compatible)
 */
async function callTranslationAPI(text, sourceLang, targetLang) {
    if (!config_1.config.TRANSLATION_ENABLED || !config_1.config.TRANSLATION_API_URL) {
        return null;
    }
    try {
        const body = {
            q: text,
            source: mapLanguageCode(sourceLang),
            target: mapLanguageCode(targetLang),
            format: 'text',
        };
        // Add API key if configured
        if (config_1.config.TRANSLATION_API_KEY) {
            body.api_key = config_1.config.TRANSLATION_API_KEY;
        }
        const response = await fetch(config_1.config.TRANSLATION_API_URL, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(body),
        });
        if (!response.ok) {
            log.warn({ status: response.status, sourceLang, targetLang }, 'Translation API returned error');
            return null;
        }
        const result = await response.json();
        return result.translatedText ?? null;
    }
    catch (error) {
        log.error({ error, sourceLang, targetLang }, 'Translation API call failed');
        return null;
    }
}
/**
 * Call translation API for batch of texts
 */
async function callBatchTranslationAPI(texts, sourceLang, targetLang) {
    if (!config_1.config.TRANSLATION_ENABLED || !config_1.config.TRANSLATION_API_URL) {
        return texts.map(() => null);
    }
    // LibreTranslate doesn't support batch, so translate in parallel
    const results = await Promise.all(texts.map(text => callTranslationAPI(text, sourceLang, targetLang)));
    return results;
}
/**
 * Check if a language is supported
 */
function isLanguageSupported(lang) {
    return exports.SUPPORTED_LANGUAGES.includes(lang);
}
/**
 * Check if a language is RTL
 */
function isRTL(lang) {
    return exports.RTL_LANGUAGES.includes(lang);
}
/**
 * Normalize language code
 */
function normalizeLanguageCode(lang) {
    const normalized = lang.toLowerCase().replace('_', '-');
    // Direct match
    if (isLanguageSupported(normalized)) {
        return normalized;
    }
    // Try without region
    const base = normalized.split('-')[0];
    if (isLanguageSupported(base)) {
        return base;
    }
    // Portuguese defaults to Brazilian
    if (base === 'pt') {
        return 'pt-BR';
    }
    // Chinese defaults to Simplified
    if (base === 'zh') {
        return 'zh-Hans';
    }
    // Default to English
    return 'en';
}
exports.i18nService = {
    /**
     * Get all supported languages (cached)
     */
    async getLanguages() {
        return cache_service_1.default.getOrSet(cache_service_1.CACHE_PREFIX.LANGUAGES, cache_service_1.CACHE_TTL.LANGUAGES, async () => {
            const rows = await (0, client_1.queryAll)('SELECT code, name, native_name, rtl, enabled FROM supported_languages ORDER BY name');
            // If table doesn't exist or is empty, return default list
            if (rows.length === 0) {
                return exports.SUPPORTED_LANGUAGES.map((code) => ({
                    code,
                    name: code,
                    nativeName: code,
                    rtl: isRTL(code),
                    enabled: true,
                }));
            }
            return rows.map((r) => ({
                code: r.code,
                name: r.name,
                nativeName: r.native_name,
                rtl: r.rtl,
                enabled: r.enabled,
            }));
        });
    },
    /**
     * Get cached translation
     */
    async getCachedTranslation(contentType, contentId, fieldName, targetLang) {
        const cacheKey = `${cache_service_1.CACHE_PREFIX.TRANSLATION}${contentType}:${contentId}:${fieldName}:${targetLang}`;
        // Try cache first
        const cached = await cache_service_1.default.get(cacheKey);
        if (cached !== null) {
            return cached;
        }
        // Query database
        const row = await (0, client_1.queryOne)(`SELECT translated_text, is_machine_translated, is_human_corrected, confidence_score
       FROM content_translations
       WHERE content_type = $1 AND content_id = $2 AND field_name = $3 AND target_lang = $4`, [contentType, contentId, fieldName, targetLang]);
        if (!row)
            return null;
        const translation = {
            translatedText: row.translated_text,
            isMachineTranslated: row.is_machine_translated,
            isHumanCorrected: row.is_human_corrected,
            confidenceScore: row.confidence_score ?? undefined,
        };
        // Cache the result
        await cache_service_1.default.set(cacheKey, translation, cache_service_1.CACHE_TTL.TRANSLATION);
        return translation;
    },
    /**
     * Save a translation
     */
    async saveTranslation(request, translation) {
        const { contentType, contentId, fieldName, originalText, sourceLang, targetLang } = request;
        await (0, client_1.query)(`INSERT INTO content_translations (
        content_type, content_id, field_name, source_lang, target_lang,
        original_text, translated_text, is_machine_translated, is_human_corrected, confidence_score
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
      ON CONFLICT (content_type, content_id, field_name, target_lang)
      DO UPDATE SET
        translated_text = EXCLUDED.translated_text,
        is_machine_translated = EXCLUDED.is_machine_translated,
        is_human_corrected = EXCLUDED.is_human_corrected,
        confidence_score = EXCLUDED.confidence_score,
        updated_at = NOW()`, [
            contentType,
            contentId,
            fieldName,
            sourceLang,
            targetLang,
            originalText,
            translation.translatedText,
            translation.isMachineTranslated,
            translation.isHumanCorrected,
            translation.confidenceScore ?? null,
        ]);
        // Invalidate cache
        const cacheKey = `${cache_service_1.CACHE_PREFIX.TRANSLATION}${contentType}:${contentId}:${fieldName}:${targetLang}`;
        await cache_service_1.default.del(cacheKey);
    },
    /**
     * Get translation for content (with optional machine translation)
     */
    async translate(contentType, contentId, fieldName, originalText, sourceLang, targetLang, options = {}) {
        const { skipCache = false, translateIfMissing = true } = options;
        // Same language, return original
        if (sourceLang === targetLang) {
            return {
                translatedText: originalText,
                isMachineTranslated: false,
                isHumanCorrected: false,
            };
        }
        // Try cache first
        if (!skipCache) {
            const cached = await this.getCachedTranslation(contentType, contentId, fieldName, targetLang);
            if (cached)
                return cached;
        }
        // If we shouldn't auto-translate, return null
        if (!translateIfMissing) {
            return null;
        }
        // Call translation API
        const translatedText = await callTranslationAPI(originalText, sourceLang, targetLang);
        if (translatedText) {
            // Cache the successful translation
            const translation = {
                translatedText,
                isMachineTranslated: true,
                isHumanCorrected: false,
            };
            // Store in database for persistence
            await this.saveTranslation({ contentType, contentId, fieldName, originalText, sourceLang, targetLang }, translation);
            return translation;
        }
        // Fallback to original text if API is unavailable
        return {
            translatedText: originalText,
            isMachineTranslated: false,
            isHumanCorrected: false,
        };
    },
    /**
     * Batch translate multiple fields
     */
    async translateBatch(contentType, contentId, fields, sourceLang, targetLang) {
        const result = {};
        // Try to get all from cache first
        const cachedResults = await Promise.all(fields.map((f) => this.getCachedTranslation(contentType, contentId, f.fieldName, targetLang)));
        const missing = [];
        fields.forEach((field, index) => {
            if (cachedResults[index]) {
                result[field.fieldName] = cachedResults[index];
            }
            else if (sourceLang === targetLang) {
                result[field.fieldName] = {
                    translatedText: field.text,
                    isMachineTranslated: false,
                    isHumanCorrected: false,
                };
            }
            else {
                missing.push({ ...field, index });
            }
        });
        // Batch translate missing fields
        if (missing.length > 0) {
            const textsToTranslate = missing.map(m => m.text);
            const translatedTexts = await callBatchTranslationAPI(textsToTranslate, sourceLang, targetLang);
            for (let i = 0; i < missing.length; i++) {
                const field = missing[i];
                const translatedText = translatedTexts[i];
                if (translatedText) {
                    const translation = {
                        translatedText,
                        isMachineTranslated: true,
                        isHumanCorrected: false,
                    };
                    // Store for caching
                    await this.saveTranslation({ contentType, contentId, fieldName: field.fieldName, originalText: field.text, sourceLang, targetLang }, translation);
                    result[field.fieldName] = translation;
                }
                else {
                    // Fallback to original
                    result[field.fieldName] = {
                        translatedText: field.text,
                        isMachineTranslated: false,
                        isHumanCorrected: false,
                    };
                }
            }
        }
        return result;
    },
    /**
     * Delete all translations for a content item
     */
    async deleteTranslations(contentType, contentId) {
        await (0, client_1.query)('DELETE FROM content_translations WHERE content_type = $1 AND content_id = $2', [contentType, contentId]);
        // Invalidate all caches for this content
        await cache_service_1.default.delPattern(`${cache_service_1.CACHE_PREFIX.TRANSLATION}${contentType}:${contentId}:*`);
    },
    /**
     * Get user's preferred language
     */
    async getUserLanguage(userId) {
        const row = await (0, client_1.queryOne)('SELECT preferred_language FROM users WHERE id = $1', [userId]);
        return normalizeLanguageCode(row?.preferred_language || 'en');
    },
    /**
     * Set user's preferred language
     */
    async setUserLanguage(userId, lang) {
        if (!isLanguageSupported(lang)) {
            throw new Error(`Unsupported language: ${lang}`);
        }
        await (0, client_1.query)('UPDATE users SET preferred_language = $1, updated_at = NOW() WHERE id = $2', [lang, userId]);
    },
    /**
     * Get translation stats
     */
    async getStats() {
        const stats = await (0, client_1.queryOne)(`SELECT
        COUNT(*) as total,
        COUNT(*) FILTER (WHERE is_machine_translated) as machine_translated,
        COUNT(*) FILTER (WHERE is_human_corrected) as human_corrected
       FROM content_translations`);
        const byLanguage = await (0, client_1.queryAll)(`SELECT target_lang, COUNT(*) as count
       FROM content_translations
       GROUP BY target_lang
       ORDER BY count DESC`);
        const translationsByLanguage = {};
        for (const row of byLanguage) {
            translationsByLanguage[row.target_lang] = parseInt(row.count, 10);
        }
        return {
            totalTranslations: parseInt(stats?.total || '0', 10),
            translationsByLanguage,
            machineTranslatedCount: parseInt(stats?.machine_translated || '0', 10),
            humanCorrectedCount: parseInt(stats?.human_corrected || '0', 10),
        };
    },
};
//# sourceMappingURL=i18n.service.js.map