/**
 * Physical Profile Personalization Service
 *
 * Uses collected user data to personalize workout recommendations:
 * - Physical profile (height, weight, body measurements)
 * - Goals (weight loss, muscle gain, strength, etc.)
 * - Limitations (injuries, disabilities, restrictions)
 * - Archetype (bodybuilder, powerlifter, military, etc.)
 * - Wearables data (heart rate, sleep, activity)
 * - PT test results
 */
export interface UserPhysicalProfile {
    height_cm?: number;
    weight_kg?: number;
    body_fat_percent?: number;
    age?: number;
    gender?: string;
    archetype?: string;
}
export interface UserGoal {
    id: string;
    goal_type: string;
    target_value?: number;
    current_value?: number;
    priority: number;
    status: string;
}
export interface UserLimitation {
    id: string;
    body_region_id: string;
    limitation_type: string;
    severity: string;
    status: string;
    avoid_movements?: string[];
    avoid_impact: boolean;
    avoid_weight_bearing: boolean;
    max_weight_lbs?: number;
}
export interface PersonalizationContext {
    userId: string;
    profile: UserPhysicalProfile;
    goals: UserGoal[];
    limitations: UserLimitation[];
    recentActivity: {
        avgHeartRate?: number;
        avgSleepHours?: number;
        weeklyWorkouts: number;
        currentStreak: number;
    };
    ptTestPerformance?: {
        testId: string;
        overallScore: number;
        weakAreas: string[];
        strongAreas: string[];
    };
}
export interface WorkoutRecommendation {
    type: 'exercise' | 'program' | 'modification' | 'warning';
    priority: 'high' | 'medium' | 'low';
    title: string;
    description: string;
    reasoning: string;
    exerciseId?: string;
    substituteFor?: string;
    parameters?: {
        suggestedSets?: number;
        suggestedReps?: string;
        suggestedWeight?: number;
        suggestedDuration?: number;
        restPeriod?: number;
    };
}
export interface PersonalizedPlan {
    userId: string;
    generatedAt: Date;
    recommendations: WorkoutRecommendation[];
    weeklySchedule: {
        day: string;
        focus: string;
        exercises: string[];
        duration: number;
    }[];
    adjustments: {
        type: string;
        reason: string;
        appliedTo: string[];
    }[];
}
/**
 * Get personalization context for a user
 */
export declare function getPersonalizationContext(userId: string): Promise<PersonalizationContext>;
/**
 * Generate personalized workout recommendations
 */
export declare function generateRecommendations(context: PersonalizationContext): Promise<WorkoutRecommendation[]>;
/**
 * Generate a complete personalized weekly plan
 */
export declare function generatePersonalizedPlan(userId: string): Promise<PersonalizedPlan>;
/**
 * Get exercise-specific recommendations for a workout session
 */
export declare function getExerciseRecommendations(userId: string, exerciseIds: string[]): Promise<Map<string, WorkoutRecommendation[]>>;
