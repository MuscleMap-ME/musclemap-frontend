/**
 * Health Import Service
 *
 * Handles importing workouts and activities from external sources:
 * - Apple Health (via file export or iOS companion app)
 * - Google Fit
 * - Strava
 * - Garmin
 * - Other fitness platforms
 *
 * Converts imported activities to workout sessions and awards credits for reps.
 */
export declare enum ImportSource {
    APPLE_HEALTH = "apple_health",
    GOOGLE_FIT = "google_fit",
    STRAVA = "strava",
    GARMIN = "garmin",
    FITBIT = "fitbit",
    MANUAL = "manual"
}
export declare enum ActivityType {
    STRENGTH_TRAINING = "strength_training",
    RUNNING = "running",
    CYCLING = "cycling",
    SWIMMING = "swimming",
    HIIT = "hiit",
    YOGA = "yoga",
    WALKING = "walking",
    HIKING = "hiking",
    OTHER = "other"
}
export declare enum SessionSource {
    APP = 0,
    APPLE_HEALTH = 1,
    GOOGLE_FIT = 2,
    STRAVA = 3,
    GARMIN = 4,
    FITBIT = 5,
    IMPORT = 6
}
interface ImportedActivity {
    id: string;
    userId: string;
    source: ImportSource;
    sourceId?: string;
    activityType: ActivityType;
    startedAt: Date;
    endedAt?: Date;
    durationSeconds?: number;
    distanceMeters?: number;
    caloriesBurned?: number;
    heartRateAvg?: number;
    heartRateMax?: number;
    stepsCount?: number;
    elevationGainMeters?: number;
    rawData?: Record<string, unknown>;
    processed: boolean;
    sessionId?: string;
    errorMessage?: string;
    createdAt: Date;
}
interface AppleHealthWorkout {
    workoutActivityType: string;
    startDate: string;
    endDate: string;
    duration?: number;
    totalDistance?: number;
    totalEnergyBurned?: number;
    averageHeartRate?: number;
    maxHeartRate?: number;
    metadata?: Record<string, unknown>;
}
interface AppleHealthExport {
    workouts: AppleHealthWorkout[];
}
interface ProcessResult {
    imported: number;
    skipped: number;
    failed: number;
    creditsAwarded: number;
    errors: string[];
}
export declare const healthImportService: {
    /**
     * Import Apple Health export data
     */
    importAppleHealth(userId: string, data: AppleHealthExport): Promise<ProcessResult>;
    /**
     * Process an imported activity (create session and award credits)
     */
    processActivity(userId: string, activityId: string): Promise<{
        sessionId: string;
        creditsAwarded: number;
    }>;
    /**
     * Get imported activities for a user
     */
    getActivities(userId: string, options?: {
        limit?: number;
        offset?: number;
        source?: ImportSource;
        processed?: boolean;
    }): Promise<{
        activities: ImportedActivity[];
        total: number;
    }>;
    /**
     * Get unprocessed activities
     */
    getUnprocessed(limit?: number): Promise<string[]>;
    /**
     * Get import stats for a user
     */
    getStats(userId: string): Promise<{
        totalImported: number;
        totalProcessed: number;
        totalCreditsAwarded: number;
        bySource: Record<string, number>;
        byActivityType: Record<string, number>;
    }>;
};
export {};
