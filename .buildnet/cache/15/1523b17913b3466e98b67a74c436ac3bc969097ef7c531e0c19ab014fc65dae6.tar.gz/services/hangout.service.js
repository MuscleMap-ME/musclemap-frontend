"use strict";
/**
 * Hangout Service
 *
 * Manages location-based community hubs:
 * - CRUD operations for hangouts
 * - Membership management
 * - Posts and discussions
 * - Activity feeds
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.hangoutService = exports.HangoutRole = void 0;
const crypto_1 = __importDefault(require("crypto"));
const client_1 = require("../db/client");
const geo_service_1 = require("./geo.service");
const credit_service_1 = require("../modules/economy/credit.service");
const errors_1 = require("../lib/errors");
const logger_1 = require("../lib/logger");
const log = logger_1.loggers.core;
// Role levels
var HangoutRole;
(function (HangoutRole) {
    HangoutRole[HangoutRole["MEMBER"] = 0] = "MEMBER";
    HangoutRole[HangoutRole["MODERATOR"] = 1] = "MODERATOR";
    HangoutRole[HangoutRole["ADMIN"] = 2] = "ADMIN";
    HangoutRole[HangoutRole["OWNER"] = 3] = "OWNER";
})(HangoutRole || (exports.HangoutRole = HangoutRole = {}));
exports.hangoutService = {
    /**
     * Create a new hangout
     */
    async create(request) {
        const { name, description, typeId, lat, lng, address, city, countryCode, radiusMeters = 500, coverImageUrl, createdBy, } = request;
        // Validate
        if (!name || name.length < 3 || name.length > 200) {
            throw new errors_1.ValidationError('Name must be between 3 and 200 characters');
        }
        if (lat < -90 || lat > 90 || lng < -180 || lng > 180) {
            throw new errors_1.ValidationError('Invalid coordinates');
        }
        // Verify type exists
        const hangoutType = await (0, client_1.queryOne)('SELECT id, name, slug FROM hangout_types WHERE id = $1', [typeId]);
        if (!hangoutType) {
            throw new errors_1.ValidationError('Invalid hangout type');
        }
        // Generate geohash
        const geohash = geo_service_1.geoService.encodeGeohash(lat, lng, 9);
        // Check if PostGIS is available
        const hasPostGIS = await (0, client_1.queryOne)("SELECT EXISTS(SELECT 1 FROM pg_extension WHERE extname = 'postgis') as has");
        let result;
        if (hasPostGIS?.has) {
            const row = await (0, client_1.queryOne)(`INSERT INTO hangouts (
          name, description, type_id, location, geohash, address, city, country_code,
          radius_meters, cover_image_url, created_by
        ) VALUES (
          $1, $2, $3, ST_MakePoint($4, $5)::geography, $6, $7, $8, $9, $10, $11, $12
        ) RETURNING id, created_at, updated_at`, [name, description, typeId, lng, lat, geohash, address, city, countryCode, radiusMeters, coverImageUrl, createdBy]);
            result = row;
        }
        else {
            const row = await (0, client_1.queryOne)(`INSERT INTO hangouts (
          name, description, type_id, latitude, longitude, geohash, address, city, country_code,
          radius_meters, cover_image_url, created_by
        ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12)
        RETURNING id, created_at, updated_at`, [name, description, typeId, lat, lng, geohash, address, city, countryCode, radiusMeters, coverImageUrl, createdBy]);
            result = row;
        }
        // Auto-join creator as owner
        await (0, client_1.query)('INSERT INTO hangout_memberships (hangout_id, user_id, role) VALUES ($1, $2, $3)', [result.id, createdBy, HangoutRole.OWNER]);
        log.info({ hangoutId: result.id, name, createdBy }, 'Hangout created');
        return {
            id: result.id,
            name,
            description,
            typeId,
            typeName: hangoutType.name,
            typeSlug: hangoutType.slug,
            location: { lat, lng },
            geohash,
            address,
            city,
            countryCode,
            radiusMeters,
            coverImageUrl,
            memberCount: 1,
            postCount: 0,
            isVerified: false,
            isActive: true,
            createdBy,
            createdAt: result.created_at,
            updatedAt: result.updated_at,
            userRole: HangoutRole.OWNER,
            isMember: true,
        };
    },
    /**
     * Get hangout by ID
     */
    async getById(hangoutId, userId) {
        // Build parameterized query to prevent SQL injection
        const params = [hangoutId];
        let userJoin = '';
        let userSelect = ', NULL as user_role, NULL as is_member';
        if (userId) {
            userJoin = `LEFT JOIN hangout_memberships hm ON hm.hangout_id = h.id AND hm.user_id = $2`;
            userSelect = ', hm.role as user_role, (hm.user_id IS NOT NULL) as is_member';
            params.push(userId);
        }
        const row = await (0, client_1.queryOne)(`SELECT
        h.id, h.name, h.description, h.type_id, ht.name as type_name, ht.slug as type_slug,
        COALESCE(ST_Y(h.location::geometry), h.latitude) as lat,
        COALESCE(ST_X(h.location::geometry), h.longitude) as lng,
        h.geohash, h.address, h.city, h.country_code, h.radius_meters, h.cover_image_url,
        h.member_count, h.post_count, h.is_verified, h.is_active, h.created_by,
        h.created_at, h.updated_at
        ${userSelect}
      FROM hangouts h
      JOIN hangout_types ht ON ht.id = h.type_id
      ${userJoin}
      WHERE h.id = $1`, params);
        if (!row)
            return null;
        return {
            id: row.id,
            name: row.name,
            description: row.description ?? undefined,
            typeId: row.type_id,
            typeName: row.type_name,
            typeSlug: row.type_slug,
            location: { lat: row.lat, lng: row.lng },
            geohash: row.geohash,
            address: row.address ?? undefined,
            city: row.city ?? undefined,
            countryCode: row.country_code ?? undefined,
            radiusMeters: row.radius_meters,
            coverImageUrl: row.cover_image_url ?? undefined,
            memberCount: row.member_count,
            postCount: row.post_count,
            isVerified: row.is_verified,
            isActive: row.is_active,
            createdBy: row.created_by ?? undefined,
            createdAt: row.created_at,
            updatedAt: row.updated_at,
            userRole: row.user_role,
            isMember: row.is_member ?? undefined,
        };
    },
    /**
     * Join a hangout
     */
    async join(hangoutId, userId) {
        // Check if hangout exists and is active
        const hangout = await (0, client_1.queryOne)('SELECT id, is_active FROM hangouts WHERE id = $1', [hangoutId]);
        if (!hangout) {
            throw new errors_1.NotFoundError('Hangout not found');
        }
        if (!hangout.is_active) {
            throw new errors_1.ValidationError('Hangout is not active');
        }
        // Check if already a member
        const existing = await (0, client_1.queryOne)('SELECT user_id FROM hangout_memberships WHERE hangout_id = $1 AND user_id = $2', [hangoutId, userId]);
        if (existing) {
            throw new errors_1.ValidationError('Already a member of this hangout');
        }
        // Join
        await (0, client_1.query)('INSERT INTO hangout_memberships (hangout_id, user_id, role) VALUES ($1, $2, $3)', [hangoutId, userId, HangoutRole.MEMBER]);
        log.info({ hangoutId, userId }, 'User joined hangout');
    },
    /**
     * Leave a hangout
     */
    async leave(hangoutId, userId) {
        // Check membership
        const membership = await (0, client_1.queryOne)('SELECT role FROM hangout_memberships WHERE hangout_id = $1 AND user_id = $2', [hangoutId, userId]);
        if (!membership) {
            throw new errors_1.NotFoundError('Not a member of this hangout');
        }
        if (membership.role === HangoutRole.OWNER) {
            throw new errors_1.ValidationError('Owner cannot leave. Transfer ownership first.');
        }
        await (0, client_1.query)('DELETE FROM hangout_memberships WHERE hangout_id = $1 AND user_id = $2', [hangoutId, userId]);
        log.info({ hangoutId, userId }, 'User left hangout');
    },
    /**
     * Get hangout members
     */
    async getMembers(hangoutId, options = {}) {
        const { limit = 50, offset = 0 } = options;
        const members = await (0, client_1.queryAll)(`SELECT
        hm.user_id, u.username, u.display_name, u.avatar_url, hm.role, hm.joined_at
      FROM hangout_memberships hm
      JOIN users u ON u.id = hm.user_id
      WHERE hm.hangout_id = $1
      ORDER BY hm.role DESC, hm.joined_at
      LIMIT $2 OFFSET $3`, [hangoutId, limit, offset]);
        const countResult = await (0, client_1.queryOne)('SELECT COUNT(*) as count FROM hangout_memberships WHERE hangout_id = $1', [hangoutId]);
        return {
            members: members.map((m) => ({
                userId: m.user_id,
                username: m.username,
                displayName: m.display_name ?? undefined,
                avatarUrl: m.avatar_url ?? undefined,
                role: m.role,
                joinedAt: m.joined_at,
            })),
            total: parseInt(countResult?.count || '0', 10),
        };
    },
    /**
     * Create a post in a hangout
     * Costs 1 credit
     */
    async createPost(request) {
        const { hangoutId, authorId, content, mediaUrls = [], contentLang = 'en' } = request;
        if (!content || content.length < 1 || content.length > 10000) {
            throw new errors_1.ValidationError('Content must be between 1 and 10,000 characters');
        }
        // Verify membership
        const membership = await (0, client_1.queryOne)('SELECT role FROM hangout_memberships WHERE hangout_id = $1 AND user_id = $2', [hangoutId, authorId]);
        if (!membership) {
            throw new errors_1.ForbiddenError('Must be a member to post');
        }
        // Charge 1 credit
        const postId = `hp_${crypto_1.default.randomBytes(12).toString('hex')}`;
        try {
            await credit_service_1.creditService.spend(authorId, 1, credit_service_1.CreditReason.POST_CREATED, credit_service_1.RefType.POST, postId, `post:${postId}`);
        }
        catch (error) {
            if (error.message?.includes('Insufficient')) {
                throw new errors_1.ValidationError('Insufficient credits to create post');
            }
            throw error;
        }
        // Create post
        const row = await (0, client_1.queryOne)(`INSERT INTO hangout_posts (id, hangout_id, author_id, content, content_lang, media_urls, credit_entry_id)
       VALUES ($1, $2, $3, $4, $5, $6, $7)
       RETURNING id, created_at, updated_at`, [postId, hangoutId, authorId, content, contentLang, JSON.stringify(mediaUrls), postId]);
        // Get author info
        const author = await (0, client_1.queryOne)('SELECT username, display_name, avatar_url FROM users WHERE id = $1', [authorId]);
        log.info({ hangoutId, postId, authorId }, 'Hangout post created');
        return {
            id: row.id,
            hangoutId,
            authorId,
            authorUsername: author?.username,
            authorDisplayName: author?.display_name ?? undefined,
            authorAvatarUrl: author?.avatar_url ?? undefined,
            content,
            contentLang,
            mediaUrls,
            commentCount: 0,
            likeCount: 0,
            isPinned: false,
            isHidden: false,
            createdAt: row.created_at,
            updatedAt: row.updated_at,
        };
    },
    /**
     * Get posts from a hangout
     */
    async getPosts(hangoutId, options = {}) {
        const { limit = 20, cursor } = options;
        let createdBefore = new Date();
        let lastId = '';
        if (cursor) {
            try {
                const decoded = Buffer.from(cursor, 'base64url').toString();
                const [ts, id] = decoded.split(':');
                createdBefore = new Date(ts);
                lastId = id;
            }
            catch {
                // Invalid cursor
            }
        }
        const rows = await (0, client_1.queryAll)(`SELECT
        hp.id, hp.hangout_id, hp.author_id, u.username, u.display_name, u.avatar_url,
        hp.content, hp.content_lang, hp.media_urls, hp.comment_count, hp.like_count,
        hp.is_pinned, hp.is_hidden, hp.created_at, hp.updated_at
      FROM hangout_posts hp
      LEFT JOIN users u ON u.id = hp.author_id
      WHERE hp.hangout_id = $1 AND hp.is_hidden = FALSE
        AND (hp.created_at < $2 OR (hp.created_at = $2 AND hp.id < $3))
      ORDER BY hp.is_pinned DESC, hp.created_at DESC, hp.id DESC
      LIMIT $4`, [hangoutId, createdBefore.toISOString(), lastId || 'z', limit + 1]);
        const hasMore = rows.length > limit;
        const resultRows = hasMore ? rows.slice(0, limit) : rows;
        const posts = resultRows.map((r) => ({
            id: r.id,
            hangoutId: r.hangout_id,
            authorId: r.author_id ?? undefined,
            authorUsername: r.username ?? undefined,
            authorDisplayName: r.display_name ?? undefined,
            authorAvatarUrl: r.avatar_url ?? undefined,
            content: r.content,
            contentLang: r.content_lang,
            mediaUrls: JSON.parse(r.media_urls || '[]'),
            commentCount: r.comment_count,
            likeCount: r.like_count,
            isPinned: r.is_pinned,
            isHidden: r.is_hidden,
            createdAt: r.created_at,
            updatedAt: r.updated_at,
        }));
        let nextCursor;
        if (hasMore && resultRows.length > 0) {
            const last = resultRows[resultRows.length - 1];
            nextCursor = Buffer.from(`${last.created_at.toISOString()}:${last.id}`).toString('base64url');
        }
        return { posts, nextCursor };
    },
    /**
     * Get user's hangout memberships
     */
    async getUserMemberships(userId, options = {}) {
        const { limit = 50, offset = 0 } = options;
        const rows = await (0, client_1.queryAll)(`SELECT
        h.id, h.name, ht.slug as type_slug, ht.name as type_name,
        h.member_count, hm.role, hm.joined_at, h.cover_image_url
      FROM hangout_memberships hm
      JOIN hangouts h ON h.id = hm.hangout_id
      JOIN hangout_types ht ON ht.id = h.type_id
      WHERE hm.user_id = $1 AND h.is_active = TRUE
      ORDER BY hm.joined_at DESC
      LIMIT $2 OFFSET $3`, [userId, limit, offset]);
        const countResult = await (0, client_1.queryOne)(`SELECT COUNT(*) as count FROM hangout_memberships hm
       JOIN hangouts h ON h.id = hm.hangout_id
       WHERE hm.user_id = $1 AND h.is_active = TRUE`, [userId]);
        return {
            hangouts: rows.map((r) => ({
                id: r.id,
                name: r.name,
                typeSlug: r.type_slug,
                typeName: r.type_name,
                memberCount: r.member_count,
                role: r.role,
                joinedAt: r.joined_at,
                coverImageUrl: r.cover_image_url ?? undefined,
            })),
            total: parseInt(countResult?.count || '0', 10),
        };
    },
};
//# sourceMappingURL=hangout.service.js.map