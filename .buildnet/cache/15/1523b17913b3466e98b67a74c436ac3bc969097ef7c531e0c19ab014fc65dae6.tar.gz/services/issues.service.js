"use strict";
/**
 * Issues Service
 *
 * Comprehensive bug and issue tracking system:
 * - CRUD operations for issues
 * - Comments management
 * - Voting system
 * - Subscriptions
 * - Status management
 * - Search and filtering
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.issuesService = exports.RoadmapStatus = exports.UpdateType = exports.IssuePriority = exports.IssueStatus = exports.IssueType = void 0;
const crypto_1 = __importDefault(require("crypto"));
const client_1 = require("../db/client");
const errors_1 = require("../lib/errors");
const logger_1 = require("../lib/logger");
const log = logger_1.loggers.core;
// Enums
var IssueType;
(function (IssueType) {
    IssueType[IssueType["BUG"] = 0] = "BUG";
    IssueType[IssueType["FEATURE"] = 1] = "FEATURE";
    IssueType[IssueType["ENHANCEMENT"] = 2] = "ENHANCEMENT";
    IssueType[IssueType["ACCOUNT"] = 3] = "ACCOUNT";
    IssueType[IssueType["QUESTION"] = 4] = "QUESTION";
    IssueType[IssueType["OTHER"] = 5] = "OTHER";
})(IssueType || (exports.IssueType = IssueType = {}));
var IssueStatus;
(function (IssueStatus) {
    IssueStatus[IssueStatus["OPEN"] = 0] = "OPEN";
    IssueStatus[IssueStatus["IN_PROGRESS"] = 1] = "IN_PROGRESS";
    IssueStatus[IssueStatus["UNDER_REVIEW"] = 2] = "UNDER_REVIEW";
    IssueStatus[IssueStatus["RESOLVED"] = 3] = "RESOLVED";
    IssueStatus[IssueStatus["CLOSED"] = 4] = "CLOSED";
    IssueStatus[IssueStatus["WONT_FIX"] = 5] = "WONT_FIX";
    IssueStatus[IssueStatus["DUPLICATE"] = 6] = "DUPLICATE";
})(IssueStatus || (exports.IssueStatus = IssueStatus = {}));
var IssuePriority;
(function (IssuePriority) {
    IssuePriority[IssuePriority["LOW"] = 0] = "LOW";
    IssuePriority[IssuePriority["MEDIUM"] = 1] = "MEDIUM";
    IssuePriority[IssuePriority["HIGH"] = 2] = "HIGH";
    IssuePriority[IssuePriority["CRITICAL"] = 3] = "CRITICAL";
})(IssuePriority || (exports.IssuePriority = IssuePriority = {}));
var UpdateType;
(function (UpdateType) {
    UpdateType[UpdateType["UPDATE"] = 0] = "UPDATE";
    UpdateType[UpdateType["RELEASE"] = 1] = "RELEASE";
    UpdateType[UpdateType["ANNOUNCEMENT"] = 2] = "ANNOUNCEMENT";
    UpdateType[UpdateType["BUGFIX"] = 3] = "BUGFIX";
    UpdateType[UpdateType["MAINTENANCE"] = 4] = "MAINTENANCE";
})(UpdateType || (exports.UpdateType = UpdateType = {}));
var RoadmapStatus;
(function (RoadmapStatus) {
    RoadmapStatus[RoadmapStatus["PLANNED"] = 0] = "PLANNED";
    RoadmapStatus[RoadmapStatus["IN_PROGRESS"] = 1] = "IN_PROGRESS";
    RoadmapStatus[RoadmapStatus["COMPLETED"] = 2] = "COMPLETED";
    RoadmapStatus[RoadmapStatus["PAUSED"] = 3] = "PAUSED";
    RoadmapStatus[RoadmapStatus["CANCELLED"] = 4] = "CANCELLED";
})(RoadmapStatus || (exports.RoadmapStatus = RoadmapStatus = {}));
// Service
exports.issuesService = {
    // ============================================
    // LABELS
    // ============================================
    async getLabels() {
        const rows = await (0, client_1.queryAll)('SELECT * FROM issue_labels ORDER BY display_order, name');
        return rows.map((r) => ({
            id: r.id,
            name: r.name,
            slug: r.slug,
            description: r.description ?? undefined,
            color: r.color,
            icon: r.icon ?? undefined,
            displayOrder: r.display_order,
            isSystem: r.is_system,
        }));
    },
    // ============================================
    // ISSUES CRUD
    // ============================================
    async createIssue(authorId, request) {
        const { title, description, type, priority = IssuePriority.MEDIUM, labelIds = [], browserInfo, deviceInfo, pageUrl, screenshotUrls = [], } = request;
        // Validate
        if (!title || title.length < 5 || title.length > 200) {
            throw new errors_1.ValidationError('Title must be between 5 and 200 characters');
        }
        if (!description || description.length < 20 || description.length > 10000) {
            throw new errors_1.ValidationError('Description must be between 20 and 10,000 characters');
        }
        if (type < 0 || type > 5) {
            throw new errors_1.ValidationError('Invalid issue type');
        }
        const issueId = `iss_${crypto_1.default.randomBytes(12).toString('hex')}`;
        const row = await (0, client_1.queryOne)(`INSERT INTO issues (
        id, title, description, type, priority, author_id, label_ids,
        browser_info, device_info, page_url, screenshot_urls
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)
      RETURNING id, issue_number, created_at, updated_at`, [
            issueId,
            title,
            description,
            type,
            priority,
            authorId,
            labelIds,
            browserInfo ? JSON.stringify(browserInfo) : null,
            deviceInfo ? JSON.stringify(deviceInfo) : null,
            pageUrl,
            screenshotUrls,
        ]);
        // Auto-subscribe author
        await (0, client_1.query)('INSERT INTO issue_subscribers (issue_id, user_id) VALUES ($1, $2) ON CONFLICT DO NOTHING', [issueId, authorId]);
        // Log status history
        await (0, client_1.query)(`INSERT INTO issue_status_history (issue_id, actor_id, action, new_value)
       VALUES ($1, $2, 'created', $3)`, [issueId, authorId, 'open']);
        log.info({ issueId, issueNumber: row.issue_number, authorId, type }, 'Issue created');
        // Fetch author info
        const author = await (0, client_1.queryOne)('SELECT username, display_name, avatar_url FROM users WHERE id = $1', [authorId]);
        return {
            id: row.id,
            issueNumber: row.issue_number,
            title,
            description,
            type,
            status: IssueStatus.OPEN,
            priority,
            authorId,
            authorUsername: author?.username,
            authorDisplayName: author?.display_name ?? undefined,
            authorAvatarUrl: author?.avatar_url ?? undefined,
            labelIds,
            voteCount: 0,
            commentCount: 0,
            subscriberCount: 1,
            viewCount: 0,
            isPinned: false,
            isLocked: false,
            isPublic: true,
            screenshotUrls,
            relatedIssueIds: [],
            createdAt: row.created_at,
            updatedAt: row.updated_at,
            hasVoted: false,
            isSubscribed: true,
        };
    },
    async getIssueById(issueId, userId) {
        const isNumber = /^\d+$/.test(issueId);
        const whereClause = isNumber ? 'i.issue_number = $1' : 'i.id = $1';
        // Use parameterized query to prevent SQL injection
        const params = [isNumber ? parseInt(issueId, 10) : issueId];
        const userJoins = userId
            ? `LEFT JOIN issue_votes iv ON iv.issue_id = i.id AND iv.user_id = $2
         LEFT JOIN issue_subscribers isub ON isub.issue_id = i.id AND isub.user_id = $2`
            : '';
        const userSelects = userId
            ? ', (iv.user_id IS NOT NULL) as has_voted, (isub.user_id IS NOT NULL) as is_subscribed'
            : ', NULL as has_voted, NULL as is_subscribed';
        if (userId) {
            params.push(userId);
        }
        const row = await (0, client_1.queryOne)(`SELECT i.*,
        ua.username as author_username, ua.display_name as author_display_name, ua.avatar_url as author_avatar_url,
        uas.username as assignee_username, uas.display_name as assignee_display_name
        ${userSelects}
      FROM issues i
      LEFT JOIN users ua ON ua.id = i.author_id
      LEFT JOIN users uas ON uas.id = i.assignee_id
      ${userJoins}
      WHERE ${whereClause}`, params);
        if (!row)
            return null;
        // Get labels
        let labels = [];
        if (row.label_ids && row.label_ids.length > 0) {
            labels = await this.getLabelsByIds(row.label_ids);
        }
        return {
            id: row.id,
            issueNumber: row.issue_number,
            title: row.title,
            description: row.description,
            type: row.type,
            status: row.status,
            priority: row.priority,
            authorId: row.author_id,
            authorUsername: row.author_username,
            authorDisplayName: row.author_display_name ?? undefined,
            authorAvatarUrl: row.author_avatar_url ?? undefined,
            assigneeId: row.assignee_id ?? undefined,
            assigneeUsername: row.assignee_username ?? undefined,
            assigneeDisplayName: row.assignee_display_name ?? undefined,
            labelIds: row.label_ids || [],
            labels,
            voteCount: row.vote_count,
            commentCount: row.comment_count,
            subscriberCount: row.subscriber_count,
            viewCount: row.view_count,
            isPinned: row.is_pinned,
            isLocked: row.is_locked,
            isPublic: row.is_public,
            resolvedAt: row.resolved_at ?? undefined,
            resolvedBy: row.resolved_by ?? undefined,
            resolutionNote: row.resolution_note ?? undefined,
            browserInfo: row.browser_info ? JSON.parse(row.browser_info) : undefined,
            deviceInfo: row.device_info ? JSON.parse(row.device_info) : undefined,
            pageUrl: row.page_url ?? undefined,
            screenshotUrls: row.screenshot_urls || [],
            relatedIssueIds: row.related_issue_ids || [],
            duplicateOfId: row.duplicate_of_id ?? undefined,
            createdAt: row.created_at,
            updatedAt: row.updated_at,
            hasVoted: row.has_voted ?? undefined,
            isSubscribed: row.is_subscribed ?? undefined,
        };
    },
    async getLabelsByIds(ids) {
        if (!ids.length)
            return [];
        const rows = await (0, client_1.queryAll)(`SELECT * FROM issue_labels WHERE id = ANY($1) ORDER BY display_order`, [ids]);
        return rows.map((r) => ({
            id: r.id,
            name: r.name,
            slug: r.slug,
            description: r.description ?? undefined,
            color: r.color,
            icon: r.icon ?? undefined,
            displayOrder: r.display_order,
            isSystem: r.is_system,
        }));
    },
    async listIssues(options = {}) {
        const { status, type, authorId, assigneeId, labelSlug, search, sortBy = 'newest', limit = 20, offset = 0, userId, } = options;
        const conditions = ['i.is_public = TRUE'];
        const params = [];
        let paramIndex = 1;
        if (status !== undefined) {
            if (Array.isArray(status)) {
                conditions.push(`i.status = ANY($${paramIndex++})`);
                params.push(status);
            }
            else {
                conditions.push(`i.status = $${paramIndex++}`);
                params.push(status);
            }
        }
        if (type !== undefined) {
            conditions.push(`i.type = $${paramIndex++}`);
            params.push(type);
        }
        if (authorId) {
            conditions.push(`i.author_id = $${paramIndex++}`);
            params.push(authorId);
        }
        if (assigneeId) {
            conditions.push(`i.assignee_id = $${paramIndex++}`);
            params.push(assigneeId);
        }
        if (labelSlug) {
            conditions.push(`EXISTS (
        SELECT 1 FROM issue_labels il
        WHERE il.id = ANY(i.label_ids) AND il.slug = $${paramIndex++}
      )`);
            params.push(labelSlug);
        }
        if (search) {
            conditions.push(`(
        i.title ILIKE $${paramIndex} OR i.description ILIKE $${paramIndex}
        OR to_tsvector('english', i.title || ' ' || i.description) @@ plainto_tsquery('english', $${paramIndex + 1})
      )`);
            params.push(`%${search}%`, search);
            paramIndex += 2;
        }
        const whereClause = conditions.join(' AND ');
        let orderBy = 'i.created_at DESC';
        switch (sortBy) {
            case 'oldest':
                orderBy = 'i.created_at ASC';
                break;
            case 'votes':
                orderBy = 'i.vote_count DESC, i.created_at DESC';
                break;
            case 'comments':
                orderBy = 'i.comment_count DESC, i.created_at DESC';
                break;
            case 'updated':
                orderBy = 'i.updated_at DESC';
                break;
        }
        // Use parameterized query to prevent SQL injection
        const userJoins = userId
            ? `LEFT JOIN issue_votes iv ON iv.issue_id = i.id AND iv.user_id = $${paramIndex++}`
            : '';
        const userSelects = userId ? ', (iv.user_id IS NOT NULL) as has_voted' : ', NULL as has_voted';
        if (userId) {
            params.push(userId);
        }
        // Get total count
        const countResult = await (0, client_1.queryOne)(`SELECT COUNT(*) as count FROM issues i WHERE ${whereClause}`, params.slice(0, params.length - (userId ? 1 : 0)) // Exclude userId from count query
        );
        const total = parseInt(countResult?.count || '0', 10);
        // Get issues
        const rows = await (0, client_1.queryAll)(`SELECT i.id, i.issue_number, i.title, i.description, i.type, i.status, i.priority,
        i.author_id, u.username as author_username, u.display_name as author_display_name,
        u.avatar_url as author_avatar_url, i.label_ids, i.vote_count, i.comment_count,
        i.subscriber_count, i.view_count, i.is_pinned, i.is_locked, i.created_at, i.updated_at
        ${userSelects}
      FROM issues i
      LEFT JOIN users u ON u.id = i.author_id
      ${userJoins}
      WHERE ${whereClause}
      ORDER BY i.is_pinned DESC, ${orderBy}
      LIMIT $${paramIndex} OFFSET $${paramIndex + 1}`, [...params, limit, offset]);
        // Get all label IDs for batch fetch
        const allLabelIds = [...new Set(rows.flatMap((r) => r.label_ids || []))];
        const labelsMap = new Map();
        if (allLabelIds.length > 0) {
            const labels = await this.getLabelsByIds(allLabelIds);
            labels.forEach((l) => labelsMap.set(l.id, l));
        }
        const issues = rows.map((r) => ({
            id: r.id,
            issueNumber: r.issue_number,
            title: r.title,
            description: r.description.substring(0, 300) + (r.description.length > 300 ? '...' : ''),
            type: r.type,
            status: r.status,
            priority: r.priority,
            authorId: r.author_id,
            authorUsername: r.author_username,
            authorDisplayName: r.author_display_name ?? undefined,
            authorAvatarUrl: r.author_avatar_url ?? undefined,
            labelIds: r.label_ids || [],
            labels: (r.label_ids || []).map((id) => labelsMap.get(id)).filter(Boolean),
            voteCount: r.vote_count,
            commentCount: r.comment_count,
            subscriberCount: r.subscriber_count,
            viewCount: r.view_count,
            isPinned: r.is_pinned,
            isLocked: r.is_locked,
            isPublic: true,
            screenshotUrls: [],
            relatedIssueIds: [],
            createdAt: r.created_at,
            updatedAt: r.updated_at,
            hasVoted: r.has_voted ?? undefined,
        }));
        return { issues, total };
    },
    async updateIssue(issueId, actorId, request, isAdmin = false) {
        const issue = await this.getIssueById(issueId);
        if (!issue) {
            throw new errors_1.NotFoundError('Issue not found');
        }
        // Check permissions
        const isAuthor = issue.authorId === actorId;
        if (!isAuthor && !isAdmin) {
            throw new errors_1.ForbiddenError('Only the author or admins can update this issue');
        }
        // Build update query
        const updates = [];
        const params = [];
        let paramIndex = 1;
        const trackChanges = [];
        if (request.title !== undefined && request.title !== issue.title) {
            updates.push(`title = $${paramIndex++}`);
            params.push(request.title);
        }
        if (request.description !== undefined && request.description !== issue.description) {
            updates.push(`description = $${paramIndex++}`);
            params.push(request.description);
        }
        if (request.type !== undefined && request.type !== issue.type) {
            updates.push(`type = $${paramIndex++}`);
            params.push(request.type);
            trackChanges.push({
                action: 'type_changed',
                oldValue: IssueType[issue.type],
                newValue: IssueType[request.type],
            });
        }
        if (request.status !== undefined && request.status !== issue.status) {
            if (!isAdmin && request.status !== IssueStatus.CLOSED) {
                throw new errors_1.ForbiddenError('Only admins can change status');
            }
            updates.push(`status = $${paramIndex++}`);
            params.push(request.status);
            trackChanges.push({
                action: 'status_changed',
                oldValue: IssueStatus[issue.status],
                newValue: IssueStatus[request.status],
            });
            // Handle resolved status
            if (request.status === IssueStatus.RESOLVED || request.status === IssueStatus.CLOSED) {
                updates.push(`resolved_at = NOW(), resolved_by = $${paramIndex++}`);
                params.push(actorId);
            }
        }
        if (request.priority !== undefined && request.priority !== issue.priority && isAdmin) {
            updates.push(`priority = $${paramIndex++}`);
            params.push(request.priority);
            trackChanges.push({
                action: 'priority_changed',
                oldValue: IssuePriority[issue.priority],
                newValue: IssuePriority[request.priority],
            });
        }
        if (request.assigneeId !== undefined && isAdmin) {
            updates.push(`assignee_id = $${paramIndex++}`);
            params.push(request.assigneeId);
            trackChanges.push({
                action: 'assignee_changed',
                oldValue: issue.assigneeId || 'none',
                newValue: request.assigneeId || 'none',
            });
        }
        if (request.labelIds !== undefined && isAdmin) {
            updates.push(`label_ids = $${paramIndex++}`);
            params.push(request.labelIds);
        }
        if (request.isPinned !== undefined && isAdmin) {
            updates.push(`is_pinned = $${paramIndex++}`);
            params.push(request.isPinned);
        }
        if (request.isLocked !== undefined && isAdmin) {
            updates.push(`is_locked = $${paramIndex++}`);
            params.push(request.isLocked);
        }
        if (request.isPublic !== undefined && isAdmin) {
            updates.push(`is_public = $${paramIndex++}`);
            params.push(request.isPublic);
        }
        if (request.resolutionNote !== undefined && isAdmin) {
            updates.push(`resolution_note = $${paramIndex++}`);
            params.push(request.resolutionNote);
        }
        if (request.duplicateOfId !== undefined && isAdmin) {
            updates.push(`duplicate_of_id = $${paramIndex++}, status = $${paramIndex++}`);
            params.push(request.duplicateOfId, IssueStatus.DUPLICATE);
            trackChanges.push({
                action: 'marked_duplicate',
                oldValue: '',
                newValue: request.duplicateOfId,
            });
        }
        if (request.relatedIssueIds !== undefined) {
            updates.push(`related_issue_ids = $${paramIndex++}`);
            params.push(request.relatedIssueIds);
        }
        if (updates.length === 0) {
            return issue;
        }
        updates.push('updated_at = NOW()');
        params.push(issue.id);
        await (0, client_1.query)(`UPDATE issues SET ${updates.join(', ')} WHERE id = $${paramIndex}`, params);
        // Log status changes
        for (const change of trackChanges) {
            await (0, client_1.query)(`INSERT INTO issue_status_history (issue_id, actor_id, action, old_value, new_value)
         VALUES ($1, $2, $3, $4, $5)`, [issue.id, actorId, change.action, change.oldValue, change.newValue]);
        }
        log.info({ issueId: issue.id, actorId, changes: trackChanges }, 'Issue updated');
        return (await this.getIssueById(issue.id));
    },
    async incrementViewCount(issueId) {
        await (0, client_1.query)('UPDATE issues SET view_count = view_count + 1 WHERE id = $1', [issueId]);
    },
    // ============================================
    // VOTING
    // ============================================
    async vote(issueId, userId) {
        const issue = await (0, client_1.queryOne)('SELECT id, vote_count FROM issues WHERE id = $1', [issueId]);
        if (!issue) {
            throw new errors_1.NotFoundError('Issue not found');
        }
        // Check if already voted
        const existing = await (0, client_1.queryOne)('SELECT user_id FROM issue_votes WHERE issue_id = $1 AND user_id = $2', [issueId, userId]);
        if (existing) {
            // Remove vote
            await (0, client_1.query)('DELETE FROM issue_votes WHERE issue_id = $1 AND user_id = $2', [issueId, userId]);
            return { voted: false, voteCount: issue.vote_count - 1 };
        }
        else {
            // Add vote
            await (0, client_1.query)('INSERT INTO issue_votes (issue_id, user_id) VALUES ($1, $2)', [issueId, userId]);
            return { voted: true, voteCount: issue.vote_count + 1 };
        }
    },
    // ============================================
    // SUBSCRIPTIONS
    // ============================================
    async subscribe(issueId, userId) {
        const issue = await (0, client_1.queryOne)('SELECT id, subscriber_count FROM issues WHERE id = $1', [issueId]);
        if (!issue) {
            throw new errors_1.NotFoundError('Issue not found');
        }
        const existing = await (0, client_1.queryOne)('SELECT user_id FROM issue_subscribers WHERE issue_id = $1 AND user_id = $2', [issueId, userId]);
        if (existing) {
            // Unsubscribe
            await (0, client_1.query)('DELETE FROM issue_subscribers WHERE issue_id = $1 AND user_id = $2', [
                issueId,
                userId,
            ]);
            return { subscribed: false, subscriberCount: issue.subscriber_count - 1 };
        }
        else {
            // Subscribe
            await (0, client_1.query)('INSERT INTO issue_subscribers (issue_id, user_id) VALUES ($1, $2)', [
                issueId,
                userId,
            ]);
            return { subscribed: true, subscriberCount: issue.subscriber_count + 1 };
        }
    },
    // ============================================
    // COMMENTS
    // ============================================
    async createComment(issueId, authorId, content, parentId, isStaff = false) {
        const issue = await (0, client_1.queryOne)('SELECT id, is_locked FROM issues WHERE id = $1', [issueId]);
        if (!issue) {
            throw new errors_1.NotFoundError('Issue not found');
        }
        if (issue.is_locked && !isStaff) {
            throw new errors_1.ForbiddenError('This issue is locked');
        }
        if (!content || content.length < 1 || content.length > 10000) {
            throw new errors_1.ValidationError('Comment must be between 1 and 10,000 characters');
        }
        if (parentId) {
            const parent = await (0, client_1.queryOne)('SELECT id FROM issue_comments WHERE id = $1 AND issue_id = $2', [parentId, issueId]);
            if (!parent) {
                throw new errors_1.NotFoundError('Parent comment not found');
            }
        }
        const commentId = `cmt_${crypto_1.default.randomBytes(12).toString('hex')}`;
        const row = await (0, client_1.queryOne)(`INSERT INTO issue_comments (id, issue_id, author_id, parent_id, content, is_staff_reply)
       VALUES ($1, $2, $3, $4, $5, $6) RETURNING id, created_at, updated_at`, [commentId, issueId, authorId, parentId, content, isStaff]);
        // Get author info
        const author = await (0, client_1.queryOne)('SELECT username, display_name, avatar_url, roles FROM users WHERE id = $1', [authorId]);
        log.info({ issueId, commentId, authorId }, 'Comment created');
        return {
            id: row.id,
            issueId,
            authorId,
            authorUsername: author?.username,
            authorDisplayName: author?.display_name ?? undefined,
            authorAvatarUrl: author?.avatar_url ?? undefined,
            authorRoles: author?.roles ? JSON.parse(author.roles) : undefined,
            parentId,
            content,
            isStaffReply: isStaff,
            isSolution: false,
            isHidden: false,
            editCount: 0,
            createdAt: row.created_at,
            updatedAt: row.updated_at,
        };
    },
    async getComments(issueId, options = {}) {
        const { limit = 50, offset = 0 } = options;
        const countResult = await (0, client_1.queryOne)('SELECT COUNT(*) as count FROM issue_comments WHERE issue_id = $1 AND is_hidden = FALSE', [issueId]);
        const total = parseInt(countResult?.count || '0', 10);
        const rows = await (0, client_1.queryAll)(`SELECT c.*, u.username, u.display_name, u.avatar_url, u.roles
       FROM issue_comments c
       LEFT JOIN users u ON u.id = c.author_id
       WHERE c.issue_id = $1 AND c.is_hidden = FALSE
       ORDER BY c.is_solution DESC, c.created_at ASC
       LIMIT $2 OFFSET $3`, [issueId, limit, offset]);
        const comments = rows.map((r) => ({
            id: r.id,
            issueId: r.issue_id,
            authorId: r.author_id,
            authorUsername: r.username,
            authorDisplayName: r.display_name ?? undefined,
            authorAvatarUrl: r.avatar_url ?? undefined,
            authorRoles: r.roles ? JSON.parse(r.roles) : undefined,
            parentId: r.parent_id ?? undefined,
            content: r.content,
            isStaffReply: r.is_staff_reply,
            isSolution: r.is_solution,
            isHidden: r.is_hidden,
            editCount: r.edit_count,
            lastEditedAt: r.last_edited_at ?? undefined,
            createdAt: r.created_at,
            updatedAt: r.updated_at,
        }));
        return { comments, total };
    },
    async markCommentAsSolution(commentId, issueId, actorId) {
        // Clear existing solution
        await (0, client_1.query)('UPDATE issue_comments SET is_solution = FALSE WHERE issue_id = $1', [issueId]);
        // Set new solution
        await (0, client_1.query)('UPDATE issue_comments SET is_solution = TRUE WHERE id = $1', [commentId]);
        await (0, client_1.query)(`INSERT INTO issue_status_history (issue_id, actor_id, action, new_value)
       VALUES ($1, $2, 'solution_marked', $3)`, [issueId, actorId, commentId]);
    },
    // ============================================
    // DEV UPDATES
    // ============================================
    async createDevUpdate(authorId, request) {
        const { title, content, type, relatedIssueIds = [], isPublished = false } = request;
        const updateId = `upd_${crypto_1.default.randomBytes(12).toString('hex')}`;
        const row = await (0, client_1.queryOne)(`INSERT INTO dev_updates (id, title, content, type, author_id, related_issue_ids, is_published, published_at)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
       RETURNING id, published_at, created_at, updated_at`, [updateId, title, content, type, authorId, relatedIssueIds, isPublished, isPublished ? new Date() : null]);
        const author = await (0, client_1.queryOne)('SELECT username, display_name FROM users WHERE id = $1', [authorId]);
        return {
            id: row.id,
            title,
            content,
            type,
            authorId,
            authorUsername: author?.username,
            authorDisplayName: author?.display_name ?? undefined,
            relatedIssueIds,
            isPublished,
            publishedAt: row.published_at ?? undefined,
            viewCount: 0,
            createdAt: row.created_at,
            updatedAt: row.updated_at,
        };
    },
    async listDevUpdates(options = {}) {
        const { type, limit = 20, offset = 0 } = options;
        const conditions = ['is_published = TRUE'];
        const params = [];
        let paramIndex = 1;
        if (type !== undefined) {
            conditions.push(`type = $${paramIndex++}`);
            params.push(type);
        }
        const whereClause = conditions.join(' AND ');
        const countResult = await (0, client_1.queryOne)(`SELECT COUNT(*) as count FROM dev_updates WHERE ${whereClause}`, params);
        const total = parseInt(countResult?.count || '0', 10);
        const rows = await (0, client_1.queryAll)(`SELECT d.*, u.username, u.display_name
       FROM dev_updates d
       LEFT JOIN users u ON u.id = d.author_id
       WHERE ${whereClause}
       ORDER BY d.published_at DESC
       LIMIT $${paramIndex} OFFSET $${paramIndex + 1}`, [...params, limit, offset]);
        const updates = rows.map((r) => ({
            id: r.id,
            title: r.title,
            content: r.content,
            type: r.type,
            authorId: r.author_id,
            authorUsername: r.username,
            authorDisplayName: r.display_name ?? undefined,
            relatedIssueIds: r.related_issue_ids || [],
            isPublished: r.is_published,
            publishedAt: r.published_at ?? undefined,
            viewCount: r.view_count,
            createdAt: r.created_at,
            updatedAt: r.updated_at,
        }));
        return { updates, total };
    },
    // ============================================
    // ROADMAP
    // ============================================
    async listRoadmapItems(options = {}) {
        const { status, quarter, userId } = options;
        const conditions = ['is_public = TRUE'];
        const params = [];
        let paramIndex = 1;
        if (status !== undefined) {
            conditions.push(`status = $${paramIndex++}`);
            params.push(status);
        }
        if (quarter) {
            conditions.push(`quarter = $${paramIndex++}`);
            params.push(quarter);
        }
        // Use parameterized query to prevent SQL injection
        const userJoins = userId
            ? `LEFT JOIN roadmap_votes rv ON rv.roadmap_id = r.id AND rv.user_id = $${paramIndex++}`
            : '';
        const userSelects = userId ? ', (rv.user_id IS NOT NULL) as has_voted' : ', NULL as has_voted';
        if (userId) {
            params.push(userId);
        }
        const rows = await (0, client_1.queryAll)(`SELECT r.* ${userSelects}
       FROM roadmap_items r
       ${userJoins}
       WHERE ${conditions.join(' AND ')}
       ORDER BY r.display_order, r.created_at`, params);
        return rows.map((r) => ({
            id: r.id,
            title: r.title,
            description: r.description ?? undefined,
            status: r.status,
            quarter: r.quarter ?? undefined,
            category: r.category ?? undefined,
            progress: r.progress,
            relatedIssueIds: r.related_issue_ids || [],
            voteCount: r.vote_count,
            displayOrder: r.display_order,
            isPublic: r.is_public,
            startedAt: r.started_at ?? undefined,
            completedAt: r.completed_at ?? undefined,
            createdAt: r.created_at,
            updatedAt: r.updated_at,
            hasVoted: r.has_voted ?? undefined,
        }));
    },
    async voteRoadmapItem(roadmapId, userId) {
        const item = await (0, client_1.queryOne)('SELECT id, vote_count FROM roadmap_items WHERE id = $1', [roadmapId]);
        if (!item) {
            throw new errors_1.NotFoundError('Roadmap item not found');
        }
        const existing = await (0, client_1.queryOne)('SELECT user_id FROM roadmap_votes WHERE roadmap_id = $1 AND user_id = $2', [roadmapId, userId]);
        if (existing) {
            await (0, client_1.query)('DELETE FROM roadmap_votes WHERE roadmap_id = $1 AND user_id = $2', [
                roadmapId,
                userId,
            ]);
            return { voted: false, voteCount: item.vote_count - 1 };
        }
        else {
            await (0, client_1.query)('INSERT INTO roadmap_votes (roadmap_id, user_id) VALUES ($1, $2)', [
                roadmapId,
                userId,
            ]);
            return { voted: true, voteCount: item.vote_count + 1 };
        }
    },
    // ============================================
    // STATISTICS
    // ============================================
    async getStats() {
        const stats = await (0, client_1.queryOne)(`SELECT
        COUNT(*) as total,
        COUNT(*) FILTER (WHERE status = 0) as open,
        COUNT(*) FILTER (WHERE status IN (3, 4)) as resolved
       FROM issues WHERE is_public = TRUE`);
        const voteCount = await (0, client_1.queryOne)('SELECT COUNT(*) as count FROM issue_votes');
        const byType = await (0, client_1.queryAll)(`SELECT type, COUNT(*) as count FROM issues WHERE is_public = TRUE GROUP BY type`);
        const byStatus = await (0, client_1.queryAll)(`SELECT status, COUNT(*) as count FROM issues WHERE is_public = TRUE GROUP BY status`);
        const typeMap = {};
        byType.forEach((r) => {
            typeMap[IssueType[r.type]] = parseInt(r.count, 10);
        });
        const statusMap = {};
        byStatus.forEach((r) => {
            statusMap[IssueStatus[r.status]] = parseInt(r.count, 10);
        });
        return {
            totalIssues: parseInt(stats?.total || '0', 10),
            openIssues: parseInt(stats?.open || '0', 10),
            resolvedIssues: parseInt(stats?.resolved || '0', 10),
            totalVotes: parseInt(voteCount?.count || '0', 10),
            issuesByType: typeMap,
            issuesByStatus: statusMap,
        };
    },
};
//# sourceMappingURL=issues.service.js.map