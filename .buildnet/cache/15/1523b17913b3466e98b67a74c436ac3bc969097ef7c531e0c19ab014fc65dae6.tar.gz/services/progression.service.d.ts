/**
 * Progressive Overload Service
 *
 * Handles tracking and analysis of progressive overload:
 * - Personal records tracking
 * - Progression history analysis
 * - Smart recommendations for weight/rep increases
 * - Plateau detection and deload suggestions
 */
export type RecordType = 'weight_1rm' | 'weight_5rm' | 'weight_10rm' | 'max_reps' | 'max_volume' | 'max_duration';
export type ProgressionStatus = 'progressing' | 'maintaining' | 'plateaued' | 'regressing' | 'deloading';
export type TargetType = 'weight' | 'reps' | 'volume' | 'frequency';
export interface PersonalRecord {
    id: string;
    userId: string;
    exerciseId: string;
    exerciseName?: string;
    recordType: RecordType;
    value: number;
    reps?: number;
    bodyweight?: number;
    workoutId?: string;
    setNumber?: number;
    achievedAt: Date;
}
export interface ExerciseProgression {
    exerciseId: string;
    exerciseName?: string;
    periodStart: Date;
    periodEnd: Date;
    periodType: 'day' | 'week' | 'month';
    totalSets: number;
    totalReps: number;
    totalVolume: number;
    maxWeight?: number;
    avgWeight?: number;
    estimated1RM?: number;
    progressionStatus: ProgressionStatus;
}
export interface ProgressionTarget {
    id: string;
    userId: string;
    exerciseId?: string;
    exerciseName?: string;
    targetType: TargetType;
    currentValue: number;
    targetValue: number;
    incrementValue?: number;
    incrementFrequency?: string;
    isActive: boolean;
    achievedAt?: Date;
    targetDate?: Date;
    progressPercent: number;
}
export interface ProgressionRecommendation {
    exerciseId: string;
    exerciseName: string;
    currentWeight?: number;
    currentReps?: number;
    recommendedWeight?: number;
    recommendedReps?: number;
    recommendationType: 'increase_weight' | 'increase_reps' | 'deload' | 'maintain' | 'try_variation';
    reason: string;
    confidence: number;
}
export interface ExerciseStats {
    exerciseId: string;
    exerciseName?: string;
    lastWorkoutDate?: Date;
    totalSessions: number;
    estimated1RM?: number;
    maxWeight?: number;
    maxReps?: number;
    averageRepsPerSet?: number;
    recentTrend: 'up' | 'stable' | 'down';
    weeklyVolume: number;
    records: PersonalRecord[];
}
export declare const ProgressionService: {
    /**
     * Get user's personal records for an exercise
     */
    getExerciseRecords(userId: string, exerciseId: string): Promise<PersonalRecord[]>;
    /**
     * Get all of user's personal records
     */
    getAllRecords(userId: string, options?: {
        limit?: number;
        recordType?: RecordType;
    }): Promise<PersonalRecord[]>;
    /**
     * Record a new personal record (called after workout logging)
     */
    checkAndRecordPR(userId: string, exerciseId: string, weight: number, reps: number, workoutId?: string, setNumber?: number, bodyweight?: number): Promise<PersonalRecord | null>;
    /**
     * Get exercise stats and recent history
     */
    getExerciseStats(userId: string, exerciseId: string): Promise<ExerciseStats | null>;
    /**
     * Get progression recommendations for an exercise
     */
    getRecommendations(userId: string, exerciseId: string): Promise<ProgressionRecommendation | null>;
    /**
     * Get recommendations for all recently trained exercises
     */
    getAllRecommendations(userId: string, limit?: number): Promise<ProgressionRecommendation[]>;
    /**
     * Create a progression target
     */
    createTarget(userId: string, input: {
        exerciseId?: string;
        targetType: TargetType;
        currentValue: number;
        targetValue: number;
        incrementValue?: number;
        incrementFrequency?: string;
        targetDate?: Date;
    }): Promise<ProgressionTarget>;
    /**
     * Get user's progression targets
     */
    getTargets(userId: string, options?: {
        exerciseId?: string;
        activeOnly?: boolean;
    }): Promise<ProgressionTarget[]>;
    /**
     * Update target progress
     */
    updateTargetProgress(targetId: string, userId: string, newCurrentValue: number): Promise<ProgressionTarget>;
    mapRecord(row: {
        id: string;
        user_id: string;
        exercise_id: string;
        record_type: string;
        value: string;
        reps: number | null;
        bodyweight: string | null;
        workout_id: string | null;
        set_number: number | null;
        achieved_at: Date;
        exercise_name?: string | null;
    }): PersonalRecord;
    mapTarget(row: {
        id: string;
        user_id: string;
        exercise_id: string | null;
        target_type: string;
        current_value: string;
        target_value: string;
        increment_value: string | null;
        increment_frequency: string | null;
        is_active: boolean;
        achieved_at: Date | null;
        target_date: Date | null;
        created_at: Date;
        exercise_name?: string | null;
    }): ProgressionTarget;
};
export default ProgressionService;
