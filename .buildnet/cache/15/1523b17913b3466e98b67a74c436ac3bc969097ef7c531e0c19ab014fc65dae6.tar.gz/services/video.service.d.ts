/**
 * Video Service
 *
 * Manages video assets, processing, and demo videos:
 * - Upload handling
 * - Processing queue with BullMQ
 * - Content-based deduplication
 * - Multi-resolution transcoding
 */
export declare enum VideoStatus {
    PENDING = 0,
    PROCESSING = 1,
    READY = 2,
    FAILED = 3,
    DELETED = 4
}
export declare enum ModerationStatus {
    PENDING = 0,
    APPROVED = 1,
    REJECTED = 2,
    FLAGGED = 3
}
export declare enum DemoVariant {
    DEFAULT = 0,
    MALE = 1,
    FEMALE = 2
}
interface VideoAsset {
    id: string;
    uploaderId?: string;
    storageKey: string;
    originalFilename?: string;
    fileSizeBytes?: number;
    durationMs?: number;
    width?: number;
    height?: number;
    status: VideoStatus;
    contentHash?: string;
    renditions: Record<string, {
        url: string;
        width: number;
        height: number;
        bitrate?: number;
    }>;
    createdAt: Date;
    updatedAt: Date;
}
interface CreateVideoRequest {
    uploaderId?: string;
    storageKey: string;
    originalFilename?: string;
    fileSizeBytes?: number;
}
interface ExerciseDemo {
    id: string;
    exerciseId: string;
    variant: DemoVariant;
    videoAssetId: string;
    isPrimary: boolean;
    displayOrder: number;
    videoUrl?: string;
    thumbnailUrl?: string;
    durationMs?: number;
}
interface UserVideoClip {
    id: string;
    userId: string;
    videoAssetId: string;
    exerciseId?: string;
    hangoutId?: number;
    title?: string;
    description?: string;
    tags: string[];
    moderationStatus: ModerationStatus;
    viewCount: number;
    likeCount: number;
    createdAt: Date;
    updatedAt: Date;
    videoUrl?: string;
    thumbnailUrl?: string;
    durationMs?: number;
    username?: string;
    displayName?: string;
    avatarUrl?: string;
}
interface CreateClipRequest {
    userId: string;
    videoAssetId: string;
    exerciseId?: string;
    hangoutId?: number;
    title?: string;
    description?: string;
    tags?: string[];
}
export declare const videoService: {
    /**
     * Create a video asset record (before processing)
     */
    createAsset(request: CreateVideoRequest): Promise<VideoAsset>;
    /**
     * Get video asset by ID
     */
    getAsset(videoId: string): Promise<VideoAsset | null>;
    /**
     * Update video asset after processing
     */
    updateAsset(videoId: string, update: {
        status?: VideoStatus;
        durationMs?: number;
        width?: number;
        height?: number;
        contentHash?: Buffer;
        renditions?: Record<string, unknown>;
        errorMessage?: string;
    }): Promise<void>;
    /**
     * Check for duplicate video by content hash
     */
    findDuplicate(contentHash: Buffer): Promise<VideoAsset | null>;
    /**
     * Acquire processing lock for a video
     */
    acquireProcessingLock(videoId: string, workerId: string): Promise<boolean>;
    /**
     * Release processing lock
     */
    releaseProcessingLock(videoId: string): Promise<void>;
    /**
     * Get pending videos for processing
     */
    getPendingVideos(limit?: number): Promise<string[]>;
    /**
     * Get demos for an exercise
     */
    getExerciseDemos(exerciseId: string, options?: {
        variant?: DemoVariant;
    }): Promise<ExerciseDemo[]>;
    /**
     * Add demo to an exercise
     */
    addExerciseDemo(exerciseId: string, videoAssetId: string, options?: {
        variant?: DemoVariant;
        isPrimary?: boolean;
        displayOrder?: number;
    }): Promise<ExerciseDemo>;
    /**
     * Create a user video clip
     */
    createClip(request: CreateClipRequest): Promise<UserVideoClip>;
    /**
     * Get user video clips
     */
    getUserClips(userId: string, options?: {
        limit?: number;
        offset?: number;
        moderationStatus?: ModerationStatus;
    }): Promise<{
        clips: UserVideoClip[];
        total: number;
    }>;
    /**
     * Get clips pending moderation
     */
    getPendingModeration(limit?: number): Promise<UserVideoClip[]>;
    /**
     * Update moderation status
     */
    updateModerationStatus(clipId: string, status: ModerationStatus): Promise<void>;
    /**
     * Increment view count
     */
    incrementViewCount(clipId: string): Promise<void>;
};
export {};
