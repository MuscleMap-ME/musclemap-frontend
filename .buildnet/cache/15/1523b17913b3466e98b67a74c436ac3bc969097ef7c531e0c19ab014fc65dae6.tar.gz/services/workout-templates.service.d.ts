/**
 * Workout Templates Service
 *
 * Handles CRUD operations for workout templates:
 * - Create, read, update, delete templates
 * - Template discovery and search
 * - Rating and usage tracking
 * - Template cloning/forking
 */
export interface TemplateExercise {
    exerciseId: string;
    name?: string;
    sets: number;
    reps?: number;
    weight?: number;
    duration?: number;
    restSeconds?: number;
    notes?: string;
}
export type TemplateDifficulty = 'beginner' | 'intermediate' | 'advanced' | 'elite';
export type TemplateCategory = 'strength' | 'hypertrophy' | 'endurance' | 'cardio' | 'mobility' | 'full_body';
export interface CreateTemplateInput {
    name: string;
    description?: string;
    exercises: TemplateExercise[];
    difficulty?: TemplateDifficulty;
    durationMinutes?: number;
    targetMuscles?: string[];
    equipmentRequired?: string[];
    category?: TemplateCategory;
    tags?: string[];
    isPublic?: boolean;
    forkedFromId?: string;
}
export interface UpdateTemplateInput {
    name?: string;
    description?: string;
    exercises?: TemplateExercise[];
    difficulty?: TemplateDifficulty;
    durationMinutes?: number;
    targetMuscles?: string[];
    equipmentRequired?: string[];
    category?: TemplateCategory;
    tags?: string[];
    isPublic?: boolean;
}
export interface WorkoutTemplate {
    id: string;
    creatorId: string;
    creatorUsername?: string;
    creatorDisplayName?: string;
    name: string;
    description?: string;
    exercises: TemplateExercise[];
    difficulty?: TemplateDifficulty;
    durationMinutes?: number;
    targetMuscles: string[];
    equipmentRequired: string[];
    category?: TemplateCategory;
    tags: string[];
    isPublic: boolean;
    isFeatured: boolean;
    forkedFromId?: string;
    version: number;
    timesUsed: number;
    timesCloned: number;
    averageRating?: number;
    ratingCount: number;
    userRating?: number;
    isSaved?: boolean;
    createdAt: Date;
    updatedAt: Date;
}
export interface TemplateSearchOptions {
    search?: string;
    category?: TemplateCategory;
    difficulty?: TemplateDifficulty;
    minRating?: number;
    targetMuscles?: string[];
    equipment?: string[];
    creator?: string;
    featured?: boolean;
    sortBy?: 'popular' | 'rating' | 'recent' | 'name';
    limit?: number;
    offset?: number;
}
export declare const WorkoutTemplatesService: {
    /**
     * Create a new workout template
     */
    create(userId: string, input: CreateTemplateInput): Promise<WorkoutTemplate>;
    /**
     * Get a template by ID
     */
    getById(templateId: string, userId?: string): Promise<WorkoutTemplate>;
    /**
     * Update a template
     */
    update(templateId: string, userId: string, input: UpdateTemplateInput): Promise<WorkoutTemplate>;
    /**
     * Delete a template
     */
    delete(templateId: string, userId: string): Promise<void>;
    /**
     * Get user's templates
     */
    getUserTemplates(userId: string, options?: {
        limit?: number;
        offset?: number;
    }): Promise<{
        templates: WorkoutTemplate[];
        total: number;
    }>;
    /**
     * Search public templates
     */
    search(options?: TemplateSearchOptions, _userId?: string): Promise<{
        templates: WorkoutTemplate[];
        total: number;
    }>;
    /**
     * Clone (fork) a template
     */
    clone(templateId: string, userId: string, newName?: string): Promise<WorkoutTemplate>;
    /**
     * Rate a template
     */
    rate(templateId: string, userId: string, rating: number, review?: string): Promise<void>;
    /**
     * Save a template (bookmark)
     */
    save(templateId: string, userId: string, folder?: string): Promise<void>;
    /**
     * Unsave a template
     */
    unsave(templateId: string, userId: string): Promise<void>;
    /**
     * Get user's saved templates
     */
    getSavedTemplates(userId: string, options?: {
        folder?: string;
        limit?: number;
        offset?: number;
    }): Promise<{
        templates: WorkoutTemplate[];
        total: number;
    }>;
    /**
     * Record template usage
     */
    recordUsage(templateId: string, userId: string, usageType: "logged" | "cloned" | "viewed", workoutId?: string): Promise<void>;
    /**
     * Map database row to template object
     */
    mapTemplate(row: {
        id: string;
        creator_id: string;
        name: string;
        description: string | null;
        exercises: TemplateExercise[];
        difficulty: string | null;
        duration_minutes: number | null;
        target_muscles: string[];
        equipment_required: string[];
        category: string | null;
        tags: string[];
        is_public: boolean;
        is_featured: boolean;
        forked_from_id: string | null;
        version: number;
        times_used: number;
        times_cloned: number;
        rating_sum: number;
        rating_count: number;
        created_at: Date;
        updated_at: Date;
    }): WorkoutTemplate;
};
export default WorkoutTemplatesService;
