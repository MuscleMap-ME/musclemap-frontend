/**
 * Notification Service
 *
 * Centralized service for creating and managing in-app notifications.
 * Supports different notification types and delivery channels.
 */
export type NotificationType = 'VERIFICATION_WITNESS_REQUEST' | 'VERIFICATION_CONFIRMED' | 'VERIFICATION_REJECTED' | 'VERIFICATION_EXPIRED' | 'HIGH_FIVE_RECEIVED' | 'FOLLOW_RECEIVED' | 'MENTION' | 'COMPETITION_INVITE' | 'COMPETITION_STARTED' | 'COMPETITION_ENDED' | 'COMPETITION_RANK_CHANGE' | 'NEW_MESSAGE' | 'GROUP_INVITE' | 'ACHIEVEMENT_UNLOCKED' | 'BADGE_EARNED' | 'SYSTEM_ANNOUNCEMENT' | 'FEATURE_RELEASED' | 'ACCOUNT_ALERT';
export type NotificationCategory = 'verification' | 'social' | 'competition' | 'messaging' | 'achievements' | 'system';
export interface CreateNotificationInput {
    userId: string;
    type: NotificationType;
    category: NotificationCategory;
    title: string;
    body?: string;
    icon?: string;
    imageUrl?: string;
    actionUrl?: string;
    actionLabel?: string;
    relatedUserId?: string;
    relatedEntityType?: string;
    relatedEntityId?: string;
    metadata?: Record<string, unknown>;
    expiresAt?: Date;
}
export interface Notification {
    id: string;
    userId: string;
    type: NotificationType;
    category: NotificationCategory;
    title: string;
    body?: string;
    icon?: string;
    imageUrl?: string;
    actionUrl?: string;
    actionLabel?: string;
    relatedUserId?: string;
    relatedUser?: {
        username: string;
        displayName?: string;
        avatarUrl?: string;
    };
    relatedEntityType?: string;
    relatedEntityId?: string;
    metadata?: Record<string, unknown>;
    isRead: boolean;
    readAt?: Date;
    pushSent: boolean;
    pushSentAt?: Date;
    expiresAt?: Date;
    createdAt: Date;
}
export interface NotificationPreferences {
    category: NotificationCategory;
    inAppEnabled: boolean;
    pushEnabled: boolean;
    emailEnabled: boolean;
    quietHoursStart?: string;
    quietHoursEnd?: string;
}
export declare const NotificationService: {
    /**
     * Create a new notification
     */
    create(input: CreateNotificationInput): Promise<Notification>;
    /**
     * Get notifications for a user
     */
    getForUser(userId: string, options?: {
        limit?: number;
        offset?: number;
        category?: NotificationCategory;
        unreadOnly?: boolean;
    }): Promise<{
        notifications: Notification[];
        total: number;
        unreadCount: number;
    }>;
    /**
     * Mark notifications as read
     */
    markAsRead(userId: string, notificationIds: string[]): Promise<number>;
    /**
     * Mark all notifications as read
     */
    markAllAsRead(userId: string, category?: NotificationCategory): Promise<number>;
    /**
     * Delete a notification
     */
    delete(userId: string, notificationId: string): Promise<boolean>;
    /**
     * Get notification preferences for a user
     */
    getPreferences(userId: string, category: NotificationCategory): Promise<NotificationPreferences>;
    /**
     * Update notification preferences
     */
    updatePreferences(userId: string, category: NotificationCategory, preferences: Partial<Omit<NotificationPreferences, "category">>): Promise<NotificationPreferences>;
    /**
     * Get unread count for a user
     */
    getUnreadCount(userId: string): Promise<number>;
    /**
     * Send verification witness request notification
     */
    sendVerificationWitnessRequest(witnessUserId: string, requesterUserId: string, verificationId: string, achievementName: string): Promise<Notification>;
    /**
     * Send verification confirmed notification
     */
    sendVerificationConfirmed(userId: string, witnessUserId: string, verificationId: string, achievementName: string): Promise<Notification>;
    /**
     * Send verification rejected notification
     */
    sendVerificationRejected(userId: string, witnessUserId: string, verificationId: string, achievementName: string, reason?: string): Promise<Notification>;
    mapNotification(row: {
        id: string;
        user_id: string;
        type: string;
        category: string;
        title: string;
        body: string | null;
        icon: string | null;
        image_url: string | null;
        action_url: string | null;
        action_label: string | null;
        related_user_id: string | null;
        related_entity_type: string | null;
        related_entity_id: string | null;
        metadata: Record<string, unknown>;
        is_read: boolean;
        read_at: Date | null;
        push_sent: boolean;
        push_sent_at: Date | null;
        expires_at: Date | null;
        created_at: Date;
    }): Notification;
    mapNotificationWithUser(row: {
        id: string;
        user_id: string;
        type: string;
        category: string;
        title: string;
        body: string | null;
        icon: string | null;
        image_url: string | null;
        action_url: string | null;
        action_label: string | null;
        related_user_id: string | null;
        related_entity_type: string | null;
        related_entity_id: string | null;
        metadata: Record<string, unknown>;
        is_read: boolean;
        read_at: Date | null;
        push_sent: boolean;
        push_sent_at: Date | null;
        expires_at: Date | null;
        created_at: Date;
        related_username: string | null;
        related_display_name: string | null;
        related_avatar_url: string | null;
    }): Notification;
};
export default NotificationService;
