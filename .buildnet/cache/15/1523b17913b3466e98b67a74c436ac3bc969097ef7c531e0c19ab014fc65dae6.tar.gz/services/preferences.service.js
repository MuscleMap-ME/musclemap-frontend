"use strict";
/**
 * Preferences Service
 *
 * Business logic for user preferences, profiles, dashboard layouts,
 * sound packs, hydration tracking, and device settings.
 *
 * Uses raw SQL queries with the pg pool client (no Knex).
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.getUserPreferences = getUserPreferences;
exports.updateUserPreferences = updateUserPreferences;
exports.resetUserPreferences = resetUserPreferences;
exports.getEffectivePreferences = getEffectivePreferences;
exports.listProfiles = listProfiles;
exports.getProfile = getProfile;
exports.createProfile = createProfile;
exports.updateProfile = updateProfile;
exports.deleteProfile = deleteProfile;
exports.activateProfile = activateProfile;
exports.deactivateProfile = deactivateProfile;
exports.getDashboardLayout = getDashboardLayout;
exports.saveDashboardLayout = saveDashboardLayout;
exports.getAvailableWidgets = getAvailableWidgets;
exports.getSystemSoundPacks = getSystemSoundPacks;
exports.getUserSoundPacks = getUserSoundPacks;
exports.createUserSoundPack = createUserSoundPack;
exports.deleteUserSoundPack = deleteUserSoundPack;
exports.logHydration = logHydration;
exports.getTodayHydration = getTodayHydration;
exports.getHydrationHistory = getHydrationHistory;
exports.listDevices = listDevices;
exports.registerDevice = registerDevice;
exports.updateDeviceSettings = updateDeviceSettings;
exports.removeDevice = removeDevice;
exports.syncDevice = syncDevice;
const client_js_1 = require("../db/client.js");
const shared_1 = require("@musclemap/shared");
async function getUserPreferences(userId) {
    const row = await (0, client_js_1.queryOne)(`SELECT * FROM user_preferences WHERE user_id = $1`, [userId]);
    if (!row) {
        // Create default preferences for user
        const id = `pref_${Date.now()}`;
        await (0, client_js_1.execute)(`INSERT INTO user_preferences (id, user_id, preferences, version)
       VALUES ($1, $2, $3, 1)`, [id, userId, JSON.stringify(shared_1.DEFAULT_PREFERENCES)]);
        return {
            preferences: shared_1.DEFAULT_PREFERENCES,
            activeProfileId: null,
            version: 1,
        };
    }
    // Parse preferences and merge with defaults to ensure all fields exist
    const storedPrefs = typeof row.preferences === 'string'
        ? JSON.parse(row.preferences)
        : row.preferences;
    return {
        preferences: (0, shared_1.mergeWithDefaults)(storedPrefs),
        activeProfileId: row.active_profile_id,
        version: row.version,
    };
}
async function updateUserPreferences(userId, updates) {
    // Get current preferences
    const current = await getUserPreferences(userId);
    // Deep merge updates
    const merged = {
        coaching: { ...current.preferences.coaching, ...updates.coaching },
        guidanceLevel: updates.guidanceLevel ?? current.preferences.guidanceLevel,
        dashboard: { ...current.preferences.dashboard, ...updates.dashboard },
        notifications: { ...current.preferences.notifications, ...updates.notifications },
        hydration: { ...current.preferences.hydration, ...updates.hydration },
        sounds: { ...current.preferences.sounds, ...updates.sounds },
        workout: { ...current.preferences.workout, ...updates.workout },
        display: { ...current.preferences.display, ...updates.display },
        units: { ...current.preferences.units, ...updates.units },
        privacy: { ...current.preferences.privacy, ...updates.privacy },
        music: { ...current.preferences.music, ...updates.music },
    };
    const newVersion = current.version + 1;
    await (0, client_js_1.execute)(`UPDATE user_preferences
     SET preferences = $1, version = $2, updated_at = NOW()
     WHERE user_id = $3`, [JSON.stringify(merged), newVersion, userId]);
    return { preferences: merged, version: newVersion };
}
async function resetUserPreferences(userId) {
    await (0, client_js_1.execute)(`UPDATE user_preferences
     SET preferences = $1, version = version + 1, updated_at = NOW()
     WHERE user_id = $2`, [JSON.stringify(shared_1.DEFAULT_PREFERENCES), userId]);
    return shared_1.DEFAULT_PREFERENCES;
}
async function getEffectivePreferences(userId) {
    const { preferences, activeProfileId } = await getUserPreferences(userId);
    if (!activeProfileId) {
        return preferences;
    }
    // Get active profile overrides
    const profile = await (0, client_js_1.queryOne)(`SELECT * FROM user_preference_profiles
     WHERE id = $1 AND user_id = $2`, [activeProfileId, userId]);
    if (!profile) {
        return preferences;
    }
    const overrides = typeof profile.preferences_override === 'string'
        ? JSON.parse(profile.preferences_override)
        : profile.preferences_override;
    return (0, shared_1.applyProfileOverrides)(preferences, overrides);
}
async function listProfiles(userId) {
    const rows = await (0, client_js_1.queryAll)(`SELECT * FROM user_preference_profiles
     WHERE user_id = $1
     ORDER BY sort_order ASC`, [userId]);
    return rows.map(mapProfileRow);
}
async function getProfile(userId, profileId) {
    const row = await (0, client_js_1.queryOne)(`SELECT * FROM user_preference_profiles
     WHERE id = $1 AND user_id = $2`, [profileId, userId]);
    return row ? mapProfileRow(row) : null;
}
async function createProfile(userId, data) {
    const id = `profile_${Date.now()}`;
    // If this is set as default, unset other defaults
    if (data.isDefault) {
        await (0, client_js_1.execute)(`UPDATE user_preference_profiles SET is_default = false WHERE user_id = $1`, [userId]);
    }
    const maxSortResult = await (0, client_js_1.queryOne)(`SELECT MAX(sort_order) as max FROM user_preference_profiles WHERE user_id = $1`, [userId]);
    const maxSort = maxSortResult?.max ?? 0;
    const row = await (0, client_js_1.queryOne)(`INSERT INTO user_preference_profiles
       (id, user_id, name, description, icon, color, preferences_override, is_default, sort_order)
     VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
     RETURNING *`, [
        id,
        userId,
        data.name,
        data.description || null,
        data.icon || 'settings',
        data.color || '#3B82F6',
        JSON.stringify(data.preferencesOverride || {}),
        data.isDefault || false,
        maxSort + 1,
    ]);
    if (!row) {
        throw new Error('Failed to create profile');
    }
    return mapProfileRow(row);
}
async function updateProfile(userId, profileId, data) {
    // If setting as default, unset other defaults
    if (data.isDefault) {
        await (0, client_js_1.execute)(`UPDATE user_preference_profiles SET is_default = false
       WHERE user_id = $1 AND id != $2`, [userId, profileId]);
    }
    // Build dynamic update
    const updates = [];
    const values = [];
    let paramCount = 1;
    if (data.name !== undefined) {
        updates.push(`name = $${paramCount++}`);
        values.push(data.name);
    }
    if (data.description !== undefined) {
        updates.push(`description = $${paramCount++}`);
        values.push(data.description);
    }
    if (data.icon !== undefined) {
        updates.push(`icon = $${paramCount++}`);
        values.push(data.icon);
    }
    if (data.color !== undefined) {
        updates.push(`color = $${paramCount++}`);
        values.push(data.color);
    }
    if (data.preferencesOverride !== undefined) {
        updates.push(`preferences_override = $${paramCount++}`);
        values.push(JSON.stringify(data.preferencesOverride));
    }
    if (data.isDefault !== undefined) {
        updates.push(`is_default = $${paramCount++}`);
        values.push(data.isDefault);
    }
    if (data.sortOrder !== undefined) {
        updates.push(`sort_order = $${paramCount++}`);
        values.push(data.sortOrder);
    }
    if (updates.length === 0) {
        return getProfile(userId, profileId);
    }
    updates.push(`updated_at = NOW()`);
    values.push(profileId, userId);
    const row = await (0, client_js_1.queryOne)(`UPDATE user_preference_profiles
     SET ${updates.join(', ')}
     WHERE id = $${paramCount++} AND user_id = $${paramCount}
     RETURNING *`, values);
    return row ? mapProfileRow(row) : null;
}
async function deleteProfile(userId, profileId) {
    // Clear active profile if this one is active
    await (0, client_js_1.execute)(`UPDATE user_preferences
     SET active_profile_id = NULL
     WHERE user_id = $1 AND active_profile_id = $2`, [userId, profileId]);
    const deleted = await (0, client_js_1.execute)(`DELETE FROM user_preference_profiles WHERE id = $1 AND user_id = $2`, [profileId, userId]);
    return deleted > 0;
}
async function activateProfile(userId, profileId) {
    // Verify profile exists and belongs to user
    const profile = await (0, client_js_1.queryOne)(`SELECT id FROM user_preference_profiles WHERE id = $1 AND user_id = $2`, [profileId, userId]);
    if (!profile) {
        return false;
    }
    await (0, client_js_1.execute)(`UPDATE user_preferences SET active_profile_id = $1 WHERE user_id = $2`, [profileId, userId]);
    return true;
}
async function deactivateProfile(userId) {
    await (0, client_js_1.execute)(`UPDATE user_preferences SET active_profile_id = NULL WHERE user_id = $1`, [userId]);
}
function mapProfileRow(row) {
    return {
        id: row.id,
        userId: row.user_id,
        name: row.name,
        description: row.description ?? undefined,
        icon: row.icon,
        color: row.color,
        preferencesOverride: typeof row.preferences_override === 'string'
            ? JSON.parse(row.preferences_override)
            : row.preferences_override,
        autoActivateRules: row.auto_activate_rules
            ? (typeof row.auto_activate_rules === 'string'
                ? JSON.parse(row.auto_activate_rules)
                : row.auto_activate_rules)
            : undefined,
        isDefault: row.is_default,
        sortOrder: row.sort_order,
        createdAt: row.created_at.toISOString(),
        updatedAt: row.updated_at.toISOString(),
    };
}
async function getDashboardLayout(userId, platform = 'web', profileId) {
    let row;
    if (profileId) {
        row = await (0, client_js_1.queryOne)(`SELECT * FROM user_dashboard_layouts
       WHERE user_id = $1 AND platform = $2 AND profile_id = $3`, [userId, platform, profileId]);
    }
    else {
        row = await (0, client_js_1.queryOne)(`SELECT * FROM user_dashboard_layouts
       WHERE user_id = $1 AND platform = $2 AND profile_id IS NULL`, [userId, platform]);
    }
    return row ? mapLayoutRow(row) : null;
}
async function saveDashboardLayout(userId, data) {
    const platform = data.platform || 'web';
    const profileId = data.profileId || null;
    // Upsert layout
    const existing = await getDashboardLayout(userId, platform, profileId || undefined);
    if (existing) {
        const row = await (0, client_js_1.queryOne)(`UPDATE user_dashboard_layouts
       SET widgets = $1, columns = $2, row_height = $3, updated_at = NOW()
       WHERE id = $4
       RETURNING *`, [
            JSON.stringify(data.widgets),
            data.columns || existing.columns,
            data.rowHeight || existing.rowHeight,
            existing.id,
        ]);
        if (!row) {
            throw new Error('Failed to update layout');
        }
        return mapLayoutRow(row);
    }
    else {
        const id = `layout_${Date.now()}`;
        const row = await (0, client_js_1.queryOne)(`INSERT INTO user_dashboard_layouts
         (id, user_id, profile_id, widgets, columns, row_height, platform)
       VALUES ($1, $2, $3, $4, $5, $6, $7)
       RETURNING *`, [
            id,
            userId,
            profileId,
            JSON.stringify(data.widgets),
            data.columns || 12,
            data.rowHeight || 100,
            platform,
        ]);
        if (!row) {
            throw new Error('Failed to create layout');
        }
        return mapLayoutRow(row);
    }
}
async function getAvailableWidgets() {
    const rows = await (0, client_js_1.queryAll)(`SELECT * FROM dashboard_widget_registry
     WHERE is_enabled = true
     ORDER BY sort_order ASC`);
    return rows.map((row) => ({
        id: row.id,
        name: row.name,
        description: row.description ?? undefined,
        category: row.category,
        defaultWidth: row.default_width,
        defaultHeight: row.default_height,
        minWidth: row.min_width,
        minHeight: row.min_height,
        maxWidth: row.max_width,
        maxHeight: row.max_height,
        isPremium: row.is_premium,
        isEnabled: row.is_enabled,
        sortOrder: row.sort_order,
    }));
}
function mapLayoutRow(row) {
    return {
        id: row.id,
        userId: row.user_id,
        profileId: row.profile_id ?? undefined,
        widgets: typeof row.widgets === 'string' ? JSON.parse(row.widgets) : row.widgets,
        columns: row.columns,
        rowHeight: row.row_height,
        platform: row.platform,
        createdAt: row.created_at.toISOString(),
        updatedAt: row.updated_at.toISOString(),
    };
}
async function getSystemSoundPacks() {
    const rows = await (0, client_js_1.queryAll)(`SELECT * FROM system_sound_packs ORDER BY sort_order ASC`);
    return rows.map((row) => ({
        id: row.id,
        name: row.name,
        description: row.description ?? undefined,
        category: row.category ?? undefined,
        sounds: typeof row.sounds === 'string' ? JSON.parse(row.sounds) : row.sounds,
        isPremium: row.is_premium,
        isPublic: true,
        userId: undefined,
    }));
}
async function getUserSoundPacks(userId) {
    const rows = await (0, client_js_1.queryAll)(`SELECT * FROM user_sound_packs WHERE user_id = $1`, [userId]);
    return rows.map((row) => ({
        id: row.id,
        name: row.name,
        description: row.description ?? undefined,
        sounds: typeof row.sounds === 'string' ? JSON.parse(row.sounds) : row.sounds,
        isPremium: false,
        isPublic: row.is_public,
        userId: row.user_id,
    }));
}
async function createUserSoundPack(userId, data) {
    const id = `sound_${Date.now()}`;
    const row = await (0, client_js_1.queryOne)(`INSERT INTO user_sound_packs (id, user_id, name, description, sounds, is_public)
     VALUES ($1, $2, $3, $4, $5, $6)
     RETURNING *`, [
        id,
        userId,
        data.name,
        data.description || null,
        JSON.stringify(data.sounds),
        data.isPublic || false,
    ]);
    if (!row) {
        throw new Error('Failed to create sound pack');
    }
    return {
        id: row.id,
        name: row.name,
        description: row.description ?? undefined,
        sounds: typeof row.sounds === 'string' ? JSON.parse(row.sounds) : row.sounds,
        isPremium: false,
        isPublic: row.is_public,
        userId: row.user_id,
    };
}
async function deleteUserSoundPack(userId, packId) {
    const deleted = await (0, client_js_1.execute)(`DELETE FROM user_sound_packs WHERE id = $1 AND user_id = $2`, [packId, userId]);
    return deleted > 0;
}
async function logHydration(userId, amountOz, workoutSessionId, source = 'manual') {
    const id = `hydration_${Date.now()}`;
    const row = await (0, client_js_1.queryOne)(`INSERT INTO user_hydration_logs (id, user_id, amount_oz, workout_session_id, source)
     VALUES ($1, $2, $3, $4, $5)
     RETURNING *`, [id, userId, amountOz, workoutSessionId || null, source]);
    if (!row) {
        throw new Error('Failed to log hydration');
    }
    return {
        id: row.id,
        userId: row.user_id,
        amountOz: typeof row.amount_oz === 'string' ? parseFloat(row.amount_oz) : row.amount_oz,
        workoutSessionId: row.workout_session_id ?? undefined,
        source: row.source,
        loggedAt: row.logged_at.toISOString(),
    };
}
async function getTodayHydration(userId) {
    const rows = await (0, client_js_1.queryAll)(`SELECT * FROM user_hydration_logs
     WHERE user_id = $1 AND logged_at >= CURRENT_DATE
     ORDER BY logged_at DESC`, [userId]);
    const logs = rows.map((row) => ({
        id: row.id,
        userId: row.user_id,
        amountOz: typeof row.amount_oz === 'string' ? parseFloat(row.amount_oz) : row.amount_oz,
        workoutSessionId: row.workout_session_id ?? undefined,
        source: row.source,
        loggedAt: row.logged_at.toISOString(),
    }));
    const totalOz = logs.reduce((sum, log) => sum + log.amountOz, 0);
    return { logs, totalOz };
}
async function getHydrationHistory(userId, days = 7) {
    const rows = await (0, client_js_1.queryAll)(`SELECT date_trunc('day', logged_at) as date, SUM(amount_oz) as total
     FROM user_hydration_logs
     WHERE user_id = $1 AND logged_at >= CURRENT_DATE - INTERVAL '${days} days'
     GROUP BY date_trunc('day', logged_at)
     ORDER BY date DESC`, [userId]);
    return rows.map((row) => ({
        date: row.date.toISOString().split('T')[0],
        totalOz: typeof row.total === 'string' ? parseFloat(row.total) : row.total ?? 0,
    }));
}
async function listDevices(userId) {
    const rows = await (0, client_js_1.queryAll)(`SELECT * FROM user_device_settings
     WHERE user_id = $1
     ORDER BY created_at DESC`, [userId]);
    return rows.map(mapDeviceRow);
}
async function registerDevice(userId, data) {
    // Upsert device
    const existing = await (0, client_js_1.queryOne)(`SELECT * FROM user_device_settings WHERE user_id = $1 AND device_id = $2`, [userId, data.deviceId]);
    if (existing) {
        const row = await (0, client_js_1.queryOne)(`UPDATE user_device_settings
       SET device_name = COALESCE($1, device_name),
           platform = $2,
           device_model = COALESCE($3, device_model),
           os_version = COALESCE($4, os_version),
           app_version = COALESCE($5, app_version),
           push_token = COALESCE($6, push_token),
           last_sync_at = NOW(),
           updated_at = NOW()
       WHERE id = $7
       RETURNING *`, [
            data.deviceName || null,
            data.platform,
            data.deviceModel || null,
            data.osVersion || null,
            data.appVersion || null,
            data.pushToken || null,
            existing.id,
        ]);
        if (!row) {
            throw new Error('Failed to update device');
        }
        return mapDeviceRow(row);
    }
    else {
        const id = `device_${Date.now()}`;
        const row = await (0, client_js_1.queryOne)(`INSERT INTO user_device_settings
         (id, user_id, device_id, device_name, platform, device_model, os_version, app_version, push_token, last_sync_at)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, NOW())
       RETURNING *`, [
            id,
            userId,
            data.deviceId,
            data.deviceName || null,
            data.platform,
            data.deviceModel || null,
            data.osVersion || null,
            data.appVersion || null,
            data.pushToken || null,
        ]);
        if (!row) {
            throw new Error('Failed to register device');
        }
        return mapDeviceRow(row);
    }
}
async function updateDeviceSettings(userId, deviceId, data) {
    // Build dynamic update
    const updates = [];
    const values = [];
    let paramCount = 1;
    if (data.deviceName !== undefined) {
        updates.push(`device_name = $${paramCount++}`);
        values.push(data.deviceName);
    }
    if (data.settingsOverride !== undefined) {
        updates.push(`settings_override = $${paramCount++}`);
        values.push(JSON.stringify(data.settingsOverride));
    }
    if (data.syncEnabled !== undefined) {
        updates.push(`sync_enabled = $${paramCount++}`);
        values.push(data.syncEnabled);
    }
    if (data.pushEnabled !== undefined) {
        updates.push(`push_enabled = $${paramCount++}`);
        values.push(data.pushEnabled);
    }
    if (data.pushToken !== undefined) {
        updates.push(`push_token = $${paramCount++}`);
        values.push(data.pushToken);
    }
    if (updates.length === 0) {
        const existing = await (0, client_js_1.queryOne)(`SELECT * FROM user_device_settings WHERE user_id = $1 AND device_id = $2`, [userId, deviceId]);
        return existing ? mapDeviceRow(existing) : null;
    }
    updates.push(`updated_at = NOW()`);
    values.push(userId, deviceId);
    const row = await (0, client_js_1.queryOne)(`UPDATE user_device_settings
     SET ${updates.join(', ')}
     WHERE user_id = $${paramCount++} AND device_id = $${paramCount}
     RETURNING *`, values);
    return row ? mapDeviceRow(row) : null;
}
async function removeDevice(userId, deviceId) {
    const deleted = await (0, client_js_1.execute)(`DELETE FROM user_device_settings WHERE user_id = $1 AND device_id = $2`, [userId, deviceId]);
    return deleted > 0;
}
async function syncDevice(userId, deviceId) {
    const preferences = await getEffectivePreferences(userId);
    await (0, client_js_1.execute)(`UPDATE user_device_settings SET last_sync_at = NOW() WHERE user_id = $1 AND device_id = $2`, [userId, deviceId]);
    return {
        preferences,
        lastSyncAt: new Date().toISOString(),
    };
}
function mapDeviceRow(row) {
    return {
        id: row.id,
        userId: row.user_id,
        deviceId: row.device_id,
        deviceName: row.device_name ?? undefined,
        platform: row.platform,
        deviceModel: row.device_model ?? undefined,
        osVersion: row.os_version ?? undefined,
        appVersion: row.app_version ?? undefined,
        settingsOverride: row.settings_override
            ? (typeof row.settings_override === 'string'
                ? JSON.parse(row.settings_override)
                : row.settings_override)
            : {},
        syncEnabled: row.sync_enabled,
        lastSyncAt: row.last_sync_at?.toISOString(),
        pushToken: row.push_token ?? undefined,
        pushEnabled: row.push_enabled,
        createdAt: row.created_at.toISOString(),
        updatedAt: row.updated_at.toISOString(),
    };
}
//# sourceMappingURL=preferences.service.js.map