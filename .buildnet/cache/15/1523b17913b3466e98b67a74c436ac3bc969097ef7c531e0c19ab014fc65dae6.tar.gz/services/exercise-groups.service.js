"use strict";
/**
 * Exercise Groups Service
 *
 * Manages supersets, giant sets, circuits, drop sets, and cluster sets.
 * Handles CRUD operations, rest time calculations, and preset management.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.exerciseGroupsService = exports.GROUP_TYPES = void 0;
const client_1 = require("../db/client");
const logger_1 = require("../lib/logger");
const zod_1 = require("zod");
const log = logger_1.loggers.db;
// ============================================
// TYPES & SCHEMAS
// ============================================
exports.GROUP_TYPES = {
    SUPERSET: 'superset',
    GIANT_SET: 'giant_set',
    CIRCUIT: 'circuit',
    DROP_SET: 'drop_set',
    CLUSTER: 'cluster',
};
const exerciseInGroupSchema = zod_1.z.object({
    exerciseId: zod_1.z.string(),
    order: zod_1.z.number().int().min(0),
    sets: zod_1.z.number().int().min(1).max(20).optional(),
    reps: zod_1.z.union([zod_1.z.number().int(), zod_1.z.string()]).optional(), // Can be "8-12" or 10
    weight: zod_1.z.number().min(0).optional(),
    duration: zod_1.z.number().int().min(0).optional(),
    notes: zod_1.z.string().max(500).optional(),
});
const createGroupSchema = zod_1.z.object({
    workoutId: zod_1.z.string().optional(),
    templateId: zod_1.z.string().optional(),
    programDayId: zod_1.z.string().optional(),
    groupType: zod_1.z.enum(['superset', 'giant_set', 'circuit', 'drop_set', 'cluster']),
    exercises: zod_1.z.array(exerciseInGroupSchema).min(2).max(10),
    restBetweenExercises: zod_1.z.number().int().min(0).max(600).optional(),
    restAfterGroup: zod_1.z.number().int().min(0).max(600).optional(),
    circuitRounds: zod_1.z.number().int().min(1).max(20).optional(),
    circuitTimed: zod_1.z.boolean().optional(),
    circuitTimePerExercise: zod_1.z.number().int().min(5).max(300).optional(),
    circuitTransitionTime: zod_1.z.number().int().min(0).max(60).optional(),
    name: zod_1.z.string().max(100).optional(),
    color: zod_1.z.string().regex(/^#[0-9A-Fa-f]{6}$/).optional(),
    position: zod_1.z.number().int().min(0).optional(),
});
const updateGroupSchema = createGroupSchema.partial().omit({ workoutId: true, templateId: true, programDayId: true });
const logGroupSetSchema = zod_1.z.object({
    groupId: zod_1.z.string(),
    workoutId: zod_1.z.string(),
    roundNumber: zod_1.z.number().int().min(1),
    exerciseIndex: zod_1.z.number().int().min(0),
    exerciseId: zod_1.z.string(),
    weight: zod_1.z.number().min(0).optional(),
    reps: zod_1.z.number().int().min(0),
    durationSeconds: zod_1.z.number().int().min(0).optional(),
    rpe: zod_1.z.number().int().min(1).max(10).optional(),
    rir: zod_1.z.number().int().min(0).max(10).optional(),
    notes: zod_1.z.string().max(500).optional(),
    skipped: zod_1.z.boolean().optional(),
});
// ============================================
// SERVICE CLASS
// ============================================
class ExerciseGroupsService {
    /**
     * Create a new exercise group
     */
    async createGroup(userId, input) {
        const data = createGroupSchema.parse(input);
        // Validate that at least one parent is provided
        if (!data.workoutId && !data.templateId && !data.programDayId) {
            throw new Error('Exercise group must belong to a workout, template, or program day');
        }
        // Validate group type matches exercise count
        if (data.groupType === exports.GROUP_TYPES.SUPERSET && data.exercises.length !== 2) {
            throw new Error('Superset must have exactly 2 exercises');
        }
        if (data.groupType === exports.GROUP_TYPES.GIANT_SET && data.exercises.length < 3) {
            throw new Error('Giant set must have at least 3 exercises');
        }
        // Apply default rest times based on group type
        const restBetween = data.restBetweenExercises ?? this.getDefaultRestBetween(data.groupType);
        const restAfter = data.restAfterGroup ?? this.getDefaultRestAfter(data.groupType);
        const result = await (0, client_1.queryOne)(`INSERT INTO exercise_groups (
        user_id, workout_id, template_id, program_day_id,
        group_type, exercises,
        rest_between_exercises, rest_after_group,
        circuit_rounds, circuit_timed, circuit_time_per_exercise, circuit_transition_time,
        name, color, position
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15)
      RETURNING
        id, workout_id as "workoutId", template_id as "templateId",
        program_day_id as "programDayId", user_id as "userId",
        group_type as "groupType", exercises,
        rest_between_exercises as "restBetweenExercises",
        rest_after_group as "restAfterGroup",
        circuit_rounds as "circuitRounds",
        circuit_timed as "circuitTimed",
        circuit_time_per_exercise as "circuitTimePerExercise",
        circuit_transition_time as "circuitTransitionTime",
        name, color, position,
        created_at as "createdAt", updated_at as "updatedAt"`, [
            userId,
            data.workoutId || null,
            data.templateId || null,
            data.programDayId || null,
            data.groupType,
            JSON.stringify(data.exercises),
            restBetween,
            restAfter,
            data.circuitRounds || 1,
            data.circuitTimed || false,
            data.circuitTimePerExercise || 30,
            data.circuitTransitionTime || 10,
            data.name || null,
            data.color || '#0066FF',
            data.position || 0,
        ]);
        if (!result) {
            throw new Error('Failed to create exercise group');
        }
        log.info({ groupId: result.id, userId, groupType: data.groupType }, 'Exercise group created');
        return result;
    }
    /**
     * Get a single exercise group by ID
     */
    async getGroup(groupId, userId) {
        const result = await (0, client_1.queryOne)(`SELECT
        id, workout_id as "workoutId", template_id as "templateId",
        program_day_id as "programDayId", user_id as "userId",
        group_type as "groupType", exercises,
        rest_between_exercises as "restBetweenExercises",
        rest_after_group as "restAfterGroup",
        circuit_rounds as "circuitRounds",
        circuit_timed as "circuitTimed",
        circuit_time_per_exercise as "circuitTimePerExercise",
        circuit_transition_time as "circuitTransitionTime",
        name, color, position,
        created_at as "createdAt", updated_at as "updatedAt"
      FROM exercise_groups
      WHERE id = $1 AND user_id = $2`, [groupId, userId]);
        return result ?? null;
    }
    /**
     * Get all groups for a workout
     */
    async getGroupsForWorkout(workoutId, userId) {
        return (0, client_1.queryAll)(`SELECT
        id, workout_id as "workoutId", template_id as "templateId",
        program_day_id as "programDayId", user_id as "userId",
        group_type as "groupType", exercises,
        rest_between_exercises as "restBetweenExercises",
        rest_after_group as "restAfterGroup",
        circuit_rounds as "circuitRounds",
        circuit_timed as "circuitTimed",
        circuit_time_per_exercise as "circuitTimePerExercise",
        circuit_transition_time as "circuitTransitionTime",
        name, color, position,
        created_at as "createdAt", updated_at as "updatedAt"
      FROM exercise_groups
      WHERE workout_id = $1 AND user_id = $2
      ORDER BY position ASC`, [workoutId, userId]);
    }
    /**
     * Get all groups for a template
     */
    async getGroupsForTemplate(templateId) {
        return (0, client_1.queryAll)(`SELECT
        id, workout_id as "workoutId", template_id as "templateId",
        program_day_id as "programDayId", user_id as "userId",
        group_type as "groupType", exercises,
        rest_between_exercises as "restBetweenExercises",
        rest_after_group as "restAfterGroup",
        circuit_rounds as "circuitRounds",
        circuit_timed as "circuitTimed",
        circuit_time_per_exercise as "circuitTimePerExercise",
        circuit_transition_time as "circuitTransitionTime",
        name, color, position,
        created_at as "createdAt", updated_at as "updatedAt"
      FROM exercise_groups
      WHERE template_id = $1
      ORDER BY position ASC`, [templateId]);
    }
    /**
     * Update an exercise group
     */
    async updateGroup(groupId, userId, input) {
        const data = updateGroupSchema.parse(input);
        // Build dynamic update query
        const updates = [];
        const values = [];
        let paramIndex = 1;
        if (data.groupType !== undefined) {
            updates.push(`group_type = $${paramIndex++}`);
            values.push(data.groupType);
        }
        if (data.exercises !== undefined) {
            updates.push(`exercises = $${paramIndex++}`);
            values.push(JSON.stringify(data.exercises));
        }
        if (data.restBetweenExercises !== undefined) {
            updates.push(`rest_between_exercises = $${paramIndex++}`);
            values.push(data.restBetweenExercises);
        }
        if (data.restAfterGroup !== undefined) {
            updates.push(`rest_after_group = $${paramIndex++}`);
            values.push(data.restAfterGroup);
        }
        if (data.circuitRounds !== undefined) {
            updates.push(`circuit_rounds = $${paramIndex++}`);
            values.push(data.circuitRounds);
        }
        if (data.circuitTimed !== undefined) {
            updates.push(`circuit_timed = $${paramIndex++}`);
            values.push(data.circuitTimed);
        }
        if (data.circuitTimePerExercise !== undefined) {
            updates.push(`circuit_time_per_exercise = $${paramIndex++}`);
            values.push(data.circuitTimePerExercise);
        }
        if (data.circuitTransitionTime !== undefined) {
            updates.push(`circuit_transition_time = $${paramIndex++}`);
            values.push(data.circuitTransitionTime);
        }
        if (data.name !== undefined) {
            updates.push(`name = $${paramIndex++}`);
            values.push(data.name);
        }
        if (data.color !== undefined) {
            updates.push(`color = $${paramIndex++}`);
            values.push(data.color);
        }
        if (data.position !== undefined) {
            updates.push(`position = $${paramIndex++}`);
            values.push(data.position);
        }
        if (updates.length === 0) {
            return this.getGroup(groupId, userId);
        }
        values.push(groupId, userId);
        const result = await (0, client_1.queryOne)(`UPDATE exercise_groups
       SET ${updates.join(', ')}
       WHERE id = $${paramIndex++} AND user_id = $${paramIndex}
       RETURNING
        id, workout_id as "workoutId", template_id as "templateId",
        program_day_id as "programDayId", user_id as "userId",
        group_type as "groupType", exercises,
        rest_between_exercises as "restBetweenExercises",
        rest_after_group as "restAfterGroup",
        circuit_rounds as "circuitRounds",
        circuit_timed as "circuitTimed",
        circuit_time_per_exercise as "circuitTimePerExercise",
        circuit_transition_time as "circuitTransitionTime",
        name, color, position,
        created_at as "createdAt", updated_at as "updatedAt"`, values);
        if (result) {
            log.info({ groupId, userId }, 'Exercise group updated');
        }
        return result ?? null;
    }
    /**
     * Delete an exercise group
     */
    async deleteGroup(groupId, userId) {
        const result = await (0, client_1.queryOne)(`DELETE FROM exercise_groups WHERE id = $1 AND user_id = $2 RETURNING id`, [groupId, userId]);
        if (result) {
            log.info({ groupId, userId }, 'Exercise group deleted');
            return true;
        }
        return false;
    }
    /**
     * Reorder exercises within a group
     */
    async reorderExercises(groupId, userId, newOrder) {
        const group = await this.getGroup(groupId, userId);
        if (!group)
            return null;
        // Reorder exercises based on the new order array (array of exerciseIds)
        const exerciseMap = new Map(group.exercises.map(e => [e.exerciseId, e]));
        const reorderedExercises = newOrder.map((exerciseId, index) => {
            const exercise = exerciseMap.get(exerciseId);
            if (!exercise) {
                throw new Error(`Exercise ${exerciseId} not found in group`);
            }
            return { ...exercise, order: index };
        });
        return this.updateGroup(groupId, userId, { exercises: reorderedExercises });
    }
    /**
     * Add an exercise to an existing group
     */
    async addExerciseToGroup(groupId, userId, exerciseData) {
        const group = await this.getGroup(groupId, userId);
        if (!group)
            return null;
        // Check if exercise already exists in group
        if (group.exercises.some(e => e.exerciseId === exerciseData.exerciseId)) {
            throw new Error('Exercise already exists in group');
        }
        // Add to the end
        const newExercise = { ...exerciseData, order: group.exercises.length };
        const updatedExercises = [...group.exercises, newExercise];
        // Auto-upgrade superset to giant set if adding 3rd exercise
        let groupType = group.groupType;
        if (groupType === exports.GROUP_TYPES.SUPERSET && updatedExercises.length > 2) {
            groupType = exports.GROUP_TYPES.GIANT_SET;
        }
        return this.updateGroup(groupId, userId, { exercises: updatedExercises, groupType });
    }
    /**
     * Remove an exercise from a group
     */
    async removeExerciseFromGroup(groupId, userId, exerciseId) {
        const group = await this.getGroup(groupId, userId);
        if (!group)
            return null;
        const updatedExercises = group.exercises
            .filter(e => e.exerciseId !== exerciseId)
            .map((e, index) => ({ ...e, order: index }));
        if (updatedExercises.length < 2) {
            throw new Error('Cannot remove exercise: group must have at least 2 exercises');
        }
        // Auto-downgrade giant set to superset if only 2 exercises remain
        let groupType = group.groupType;
        if (groupType === exports.GROUP_TYPES.GIANT_SET && updatedExercises.length === 2) {
            groupType = exports.GROUP_TYPES.SUPERSET;
        }
        return this.updateGroup(groupId, userId, { exercises: updatedExercises, groupType });
    }
    /**
     * Log a set within an exercise group
     */
    async logGroupSet(userId, input) {
        const data = logGroupSetSchema.parse(input);
        const result = await (0, client_1.queryOne)(`INSERT INTO exercise_group_sets (
        group_id, workout_id, user_id,
        round_number, exercise_index, exercise_id,
        weight, reps, duration_seconds, rpe, rir, notes, skipped
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13)
      RETURNING id`, [
            data.groupId,
            data.workoutId,
            userId,
            data.roundNumber,
            data.exerciseIndex,
            data.exerciseId,
            data.weight || null,
            data.reps,
            data.durationSeconds || null,
            data.rpe || null,
            data.rir || null,
            data.notes || null,
            data.skipped || false,
        ]);
        if (!result) {
            throw new Error('Failed to log group set');
        }
        return result;
    }
    /**
     * Get all logged sets for a group in a workout
     */
    async getGroupSets(groupId, workoutId, userId) {
        return (0, client_1.queryAll)(`SELECT
        id, round_number as "roundNumber", exercise_index as "exerciseIndex",
        exercise_id as "exerciseId", weight, reps, duration_seconds as "durationSeconds",
        rpe, rir, notes, skipped, performed_at as "performedAt"
      FROM exercise_group_sets
      WHERE group_id = $1 AND workout_id = $2 AND user_id = $3
      ORDER BY round_number ASC, exercise_index ASC, performed_at ASC`, [groupId, workoutId, userId]);
    }
    // ============================================
    // PRESETS
    // ============================================
    /**
     * Save current group as a preset
     */
    async saveAsPreset(userId, name, group) {
        const result = await (0, client_1.queryOne)(`INSERT INTO exercise_group_presets (
        user_id, name, group_type, exercises,
        rest_between_exercises, rest_after_group,
        circuit_rounds, circuit_timed, circuit_time_per_exercise, color
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
      RETURNING
        id, user_id as "userId", name,
        group_type as "groupType", exercises,
        rest_between_exercises as "restBetweenExercises",
        rest_after_group as "restAfterGroup",
        circuit_rounds as "circuitRounds",
        circuit_timed as "circuitTimed",
        circuit_time_per_exercise as "circuitTimePerExercise",
        color, times_used as "timesUsed",
        last_used_at as "lastUsedAt",
        created_at as "createdAt", updated_at as "updatedAt"`, [
            userId,
            name,
            group.groupType,
            JSON.stringify(group.exercises),
            group.restBetweenExercises,
            group.restAfterGroup,
            group.circuitRounds,
            group.circuitTimed,
            group.circuitTimePerExercise,
            group.color,
        ]);
        if (!result) {
            throw new Error('Failed to save preset');
        }
        log.info({ presetId: result.id, userId, name }, 'Exercise group preset saved');
        return result;
    }
    /**
     * Get user's presets
     */
    async getPresets(userId) {
        return (0, client_1.queryAll)(`SELECT
        id, user_id as "userId", name,
        group_type as "groupType", exercises,
        rest_between_exercises as "restBetweenExercises",
        rest_after_group as "restAfterGroup",
        circuit_rounds as "circuitRounds",
        circuit_timed as "circuitTimed",
        circuit_time_per_exercise as "circuitTimePerExercise",
        color, times_used as "timesUsed",
        last_used_at as "lastUsedAt",
        created_at as "createdAt", updated_at as "updatedAt"
      FROM exercise_group_presets
      WHERE user_id = $1
      ORDER BY times_used DESC, updated_at DESC`, [userId]);
    }
    /**
     * Create a group from a preset
     */
    async createFromPreset(userId, presetId, parentRef) {
        const preset = await (0, client_1.queryOne)(`SELECT
        group_type as "groupType", exercises,
        rest_between_exercises as "restBetweenExercises",
        rest_after_group as "restAfterGroup",
        circuit_rounds as "circuitRounds",
        circuit_timed as "circuitTimed",
        circuit_time_per_exercise as "circuitTimePerExercise",
        color
      FROM exercise_group_presets
      WHERE id = $1 AND user_id = $2`, [presetId, userId]);
        if (!preset) {
            throw new Error('Preset not found');
        }
        // Update preset usage
        await (0, client_1.query)(`UPDATE exercise_group_presets
       SET times_used = times_used + 1, last_used_at = NOW()
       WHERE id = $1`, [presetId]);
        return this.createGroup(userId, {
            ...parentRef,
            groupType: preset.groupType,
            exercises: preset.exercises,
            restBetweenExercises: preset.restBetweenExercises,
            restAfterGroup: preset.restAfterGroup,
            circuitRounds: preset.circuitRounds,
            circuitTimed: preset.circuitTimed,
            circuitTimePerExercise: preset.circuitTimePerExercise,
            color: preset.color,
        });
    }
    /**
     * Delete a preset
     */
    async deletePreset(presetId, userId) {
        const result = await (0, client_1.queryOne)(`DELETE FROM exercise_group_presets WHERE id = $1 AND user_id = $2 RETURNING id`, [presetId, userId]);
        return !!result;
    }
    // ============================================
    // UTILITY METHODS
    // ============================================
    /**
     * Get default rest between exercises based on group type
     */
    getDefaultRestBetween(groupType) {
        switch (groupType) {
            case exports.GROUP_TYPES.SUPERSET:
                return 0; // No rest between superset exercises
            case exports.GROUP_TYPES.GIANT_SET:
                return 0; // No rest between giant set exercises
            case exports.GROUP_TYPES.CIRCUIT:
                return 10; // Quick transition
            case exports.GROUP_TYPES.DROP_SET:
                return 0; // Immediate drop
            case exports.GROUP_TYPES.CLUSTER:
                return 15; // Brief pause for cluster sets
            default:
                return 0;
        }
    }
    /**
     * Get default rest after completing group based on type
     */
    getDefaultRestAfter(groupType) {
        switch (groupType) {
            case exports.GROUP_TYPES.SUPERSET:
                return 90; // Standard rest after superset
            case exports.GROUP_TYPES.GIANT_SET:
                return 120; // Longer rest after giant set
            case exports.GROUP_TYPES.CIRCUIT:
                return 60; // Rest between rounds
            case exports.GROUP_TYPES.DROP_SET:
                return 120; // Longer rest after drop set
            case exports.GROUP_TYPES.CLUSTER:
                return 180; // Full rest after cluster
            default:
                return 90;
        }
    }
    /**
     * Calculate total estimated time for a group
     */
    calculateGroupDuration(group) {
        const exerciseCount = group.exercises.length;
        if (group.circuitTimed) {
            // Timed circuit: (time per exercise + transition) * exercises * rounds
            const perRound = (group.circuitTimePerExercise + group.circuitTransitionTime) * exerciseCount;
            return (perRound * group.circuitRounds) + ((group.circuitRounds - 1) * group.restAfterGroup);
        }
        // Non-timed: estimate based on sets/reps
        // Assume 30 seconds per set average + rest times
        let totalSets = 0;
        for (const exercise of group.exercises) {
            totalSets += exercise.sets || 3;
        }
        const exerciseTime = totalSets * 30; // 30s per set average
        const restBetween = (exerciseCount - 1) * group.restBetweenExercises * group.circuitRounds;
        const restAfter = (group.circuitRounds - 1) * group.restAfterGroup;
        return exerciseTime + restBetween + restAfter;
    }
    /**
     * Get group display label (e.g., "2x Superset", "3x Circuit")
     */
    getGroupLabel(group) {
        const count = group.exercises.length;
        const rounds = group.circuitRounds > 1 ? ` x ${group.circuitRounds}` : '';
        switch (group.groupType) {
            case exports.GROUP_TYPES.SUPERSET:
                return `${count}x Superset${rounds}`;
            case exports.GROUP_TYPES.GIANT_SET:
                return `${count}x Giant Set${rounds}`;
            case exports.GROUP_TYPES.CIRCUIT:
                return `${count}x Circuit${rounds}`;
            case exports.GROUP_TYPES.DROP_SET:
                return `Drop Set (${count})`;
            case exports.GROUP_TYPES.CLUSTER:
                return `Cluster Set${rounds}`;
            default:
                return `${count}x Group`;
        }
    }
}
exports.exerciseGroupsService = new ExerciseGroupsService();
//# sourceMappingURL=exercise-groups.service.js.map