/**
 * Feature Tracker Service
 *
 * Tracks feature usage events for analytics in the Empire control panel.
 *
 * Architecture:
 * - Events are stored in feature_usage_events table
 * - Privacy settings are respected (users who opt out are NOT tracked)
 * - Supports batch tracking for efficiency
 * - Integrates with user activity summaries
 *
 * Usage:
 *   await featureTracker.track({
 *     userId: 'user_123',
 *     featureId: 'workout_log',
 *     action: 'complete',
 *     metadata: { exerciseCount: 5 }
 *   });
 */
export type FeatureAction = 'view' | 'interact' | 'complete' | 'abandon' | 'error';
export interface FeatureEvent {
    userId: string;
    featureId: string;
    action: FeatureAction;
    sessionId?: string;
    metadata?: Record<string, unknown>;
    durationMs?: number;
}
export interface FeatureUsage {
    featureId: string;
    featureCategory: string;
    featureName: string;
    useCount: number;
    lastUsedAt: string;
}
export interface FeatureDefinition {
    id: string;
    name: string;
    category: string;
    description: string | null;
    isPremium: boolean;
    isActive: boolean;
    trackingEnabled: boolean;
}
export declare const featureTracker: {
    /**
     * Track a single feature usage event
     */
    track(event: FeatureEvent): Promise<boolean>;
    /**
     * Track multiple feature usage events efficiently
     */
    trackBatch(events: FeatureEvent[]): Promise<number>;
    /**
     * Get feature usage summary for a specific user
     */
    getUserFeatureUsage(userId: string, days?: number): Promise<FeatureUsage[]>;
    /**
     * Get top features by usage across all users
     */
    getTopFeatures(days?: number, limit?: number): Promise<Array<{
        featureId: string;
        featureCategory: string;
        featureName: string;
        totalUses: number;
        uniqueUsers: number;
    }>>;
    /**
     * Get all feature definitions
     */
    getFeatureDefinitions(activeOnly?: boolean): Promise<FeatureDefinition[]>;
    /**
     * Get feature popularity from materialized view (fast)
     */
    getFeaturePopularity(): Promise<Array<{
        featureId: string;
        featureCategory: string;
        featureName: string;
        totalUses: number;
        uniqueUsers: number;
        uses24h: number;
        uses7d: number;
        uses30d: number;
    }>>;
};
/**
 * Quick track helper - fire and forget (doesn't await)
 */
export declare function trackFeature(userId: string, featureId: string, action?: FeatureAction, metadata?: Record<string, unknown>): void;
/**
 * Track feature view (most common action)
 */
export declare function trackView(userId: string, featureId: string, metadata?: Record<string, unknown>): void;
/**
 * Track feature interaction
 */
export declare function trackInteract(userId: string, featureId: string, metadata?: Record<string, unknown>): void;
/**
 * Track feature completion
 */
export declare function trackComplete(userId: string, featureId: string, metadata?: Record<string, unknown>): void;
export default featureTracker;
