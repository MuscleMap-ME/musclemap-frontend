/**
 * Image Processing Service
 *
 * Processes uploaded exercise images for consistency:
 * - Resize to standard dimensions
 * - Convert to WebP format
 * - Generate thumbnails
 * - Strip EXIF metadata for privacy
 *
 * Uses lazy-loaded sharp to support Bun runtime.
 * On Bun: Image processing is degraded (returns original).
 * On Node.js: Full sharp processing with native performance.
 */
export interface ProcessedImage {
    processedBuffer: Buffer;
    thumbnailBuffer: Buffer;
    width: number;
    height: number;
    thumbnailWidth: number;
    thumbnailHeight: number;
    format: 'webp';
    originalSize: number;
    processedSize: number;
    thumbnailSize: number;
}
export interface SavedImage {
    originalUrl: string;
    processedUrl: string;
    thumbnailUrl: string;
    filename: string;
}
/**
 * Process an exercise image for upload
 * - Resizes to max 800x600 maintaining aspect ratio
 * - Converts to WebP format
 * - Strips EXIF metadata
 * - Generates a thumbnail
 *
 * On Bun runtime: Returns minimally processed images (degraded mode)
 */
export declare function processExerciseImage(buffer: Buffer): Promise<ProcessedImage>;
/**
 * Validate image before processing
 *
 * On Bun runtime: Uses basic validation (file size, magic bytes)
 * On Node.js: Full sharp validation including format and dimensions
 */
export declare function validateImage(buffer: Buffer): Promise<{
    valid: boolean;
    error?: string;
}>;
/**
 * Generate a unique filename for the image
 */
export declare function generateFilename(exerciseId: string, userId: string): string;
/**
 * Get the upload directory path
 */
export declare function getUploadDir(): string;
/**
 * Ensure upload directories exist
 */
export declare function ensureUploadDirs(): Promise<void>;
/**
 * Save processed images to disk
 */
export declare function saveImages(originalBuffer: Buffer, processedImage: ProcessedImage, filename: string): Promise<SavedImage>;
/**
 * Delete images from disk
 */
export declare function deleteImages(filename: string): Promise<void>;
/**
 * Get image info from file
 *
 * On Bun runtime: Uses basic metadata extraction
 * On Node.js: Full sharp metadata
 */
export declare function getImageInfo(filePath: string): Promise<{
    width: number;
    height: number;
    format: string;
    size: number;
} | null>;
