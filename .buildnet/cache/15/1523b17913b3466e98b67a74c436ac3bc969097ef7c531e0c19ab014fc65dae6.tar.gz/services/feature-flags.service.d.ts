/**
 * Feature Flags Service
 *
 * Manages feature flags for gradual rollouts:
 * - XR mode
 * - New features
 * - A/B testing
 */
interface FeatureFlag {
    id: string;
    name: string;
    description?: string;
    enabled: boolean;
    rolloutPercentage: number;
    userAllowlist: string[];
    userBlocklist: string[];
    conditions: Record<string, unknown>;
    createdAt: Date;
    updatedAt: Date;
}
interface FlagEvaluation {
    enabled: boolean;
    reason: 'disabled' | 'allowlist' | 'blocklist' | 'rollout' | 'condition';
}
export declare const featureFlagsService: {
    /**
     * Get all feature flags
     */
    getAll(): Promise<FeatureFlag[]>;
    /**
     * Get a single feature flag
     */
    get(flagId: string): Promise<FeatureFlag | null>;
    /**
     * Evaluate if a feature is enabled for a user
     */
    isEnabled(flagId: string, userId?: string, context?: Record<string, unknown>): Promise<FlagEvaluation>;
    /**
     * Simple condition evaluation
     */
    evaluateConditions(conditions: Record<string, unknown>, context: Record<string, unknown>): boolean;
    /**
     * Update a feature flag
     */
    update(flagId: string, update: Partial<{
        enabled: boolean;
        rolloutPercentage: number;
        userAllowlist: string[];
        userBlocklist: string[];
        conditions: Record<string, unknown>;
    }>): Promise<void>;
    /**
     * Check if XR mode is enabled for a user
     */
    isXRModeEnabled(userId?: string): Promise<boolean>;
    /**
     * Get all enabled features for a user
     */
    getEnabledFeatures(userId?: string, context?: Record<string, unknown>): Promise<Record<string, boolean>>;
};
export {};
