/**
 * Bug Fix Queue
 *
 * BullMQ queue for processing confirmed bug reports
 * with automated Claude agent fixes
 */
import { Queue } from 'bullmq';
export interface BugFixJobData {
    feedbackId: string;
    title: string;
    description: string;
    stepsToReproduce: string | null;
    expectedBehavior: string | null;
    actualBehavior: string | null;
}
export interface BugFixJobResult {
    success: boolean;
    filesModified?: string[];
    testsPassed?: boolean;
    deployed?: boolean;
    deployCommit?: string;
    errorMessage?: string;
    agentOutput?: string;
}
export declare const bugFixQueue: Queue<BugFixJobData, BugFixJobResult, string, BugFixJobData, BugFixJobResult, string>;
export declare function startBugFixWorker(): void;
export declare function stopBugFixWorker(): Promise<void>;
