export { a as STORAGE_KEYS, S as StorageAdapter, b as StorageKey, g as getStorageAdapter, h as hasStorageAdapter, s as setStorageAdapter } from './types-B8_KDbOr.js';

/**
 * Schema Validation System
 *
 * Custom TypeScript-like runtime validation for API responses.
 * Supports: String, Number, Boolean, Null, Any, Union, Array, Object
 */
interface BaseSchema {
    kind: string;
    optional?: boolean;
    default?: unknown;
}
interface StringSchema extends BaseSchema {
    kind: 'string';
}
interface NumberSchema extends BaseSchema {
    kind: 'number';
}
interface BooleanSchema extends BaseSchema {
    kind: 'boolean';
}
interface NullSchema extends BaseSchema {
    kind: 'null';
}
interface AnySchema extends BaseSchema {
    kind: 'any';
}
interface UnionSchema extends BaseSchema {
    kind: 'union';
    anyOf: Schema[];
}
interface ArraySchema extends BaseSchema {
    kind: 'array';
    items: Schema;
}
interface ObjectSchema extends BaseSchema {
    kind: 'object';
    properties?: Record<string, Schema>;
    additionalProperties?: boolean;
}
interface RecordSchema extends BaseSchema {
    kind: 'record';
    keySchema: Schema;
    valueSchema: Schema;
}
type Schema = StringSchema | NumberSchema | BooleanSchema | NullSchema | AnySchema | UnionSchema | ArraySchema | ObjectSchema | RecordSchema;
interface ExternalSchema<T = unknown> {
    parse?: (data: unknown) => T;
    safeParse?: (data: unknown) => {
        success: boolean;
        data?: T;
        error?: unknown;
    };
}
type AnyValidationSchema = Schema | ExternalSchema;
/**
 * Type builder for schema definitions
 */
declare const Type: {
    String: (options?: Partial<Omit<StringSchema, "kind">>) => StringSchema;
    Number: (options?: Partial<Omit<NumberSchema, "kind">>) => NumberSchema;
    Boolean: (options?: Partial<Omit<BooleanSchema, "kind">>) => BooleanSchema;
    Null: () => NullSchema;
    Any: () => AnySchema;
    Optional: <T extends Schema>(schema: T) => T & {
        optional: true;
    };
    Union: (schemas: Schema[]) => UnionSchema;
    Array: (itemSchema: Schema, options?: {
        default?: unknown[];
    }) => ArraySchema;
    Object: (properties: Record<string, Schema>, options?: {
        default?: Record<string, unknown>;
        additionalProperties?: boolean;
    }) => ObjectSchema;
    Record: (keySchema: Schema, valueSchema: Schema, options?: {
        default?: Record<string, unknown>;
    }) => RecordSchema;
};
/**
 * Check if a value is our internal validation schema
 */
declare function isValidationSchema(schema: unknown): schema is Schema;
/**
 * Parse data against a schema, throwing on validation failure
 */
declare function parseWithSchema<T>(schema: Schema, data: unknown): T;
/**
 * Apply schema validation (supports internal schemas and external zod-like schemas)
 */
declare function applySchema<T>(schema: AnyValidationSchema | undefined, data: unknown): T;

/**
 * Clear the request cache
 */
declare function clearRequestCache(): void;
interface RequestOptions<T = unknown> {
    method?: 'GET' | 'POST' | 'PUT' | 'PATCH' | 'DELETE';
    body?: Record<string, unknown> | FormData;
    headers?: Record<string, string>;
    schema?: AnyValidationSchema;
    auth?: boolean;
    retries?: number;
    retryDelay?: number;
    cacheTtl?: number;
    cacheKey?: string;
    baseUrl?: string;
    onUnauthorized?: () => void | Promise<void>;
}
interface HttpClientConfig {
    baseUrl?: string;
    defaultHeaders?: Record<string, string>;
    onUnauthorized?: () => void | Promise<void>;
}
/**
 * Configure the HTTP client globally
 */
declare function configureHttpClient(config: HttpClientConfig): void;
/**
 * Make an HTTP request with retry logic, caching, and schema validation
 */
declare function request<T = unknown>(path: string, options?: RequestOptions<T>): Promise<T>;
/**
 * API helpers for building request options
 */
declare const apiHelpers: {
    withSchema: <T>(schema: AnyValidationSchema) => Partial<RequestOptions<T>>;
};

interface Exercise {
    id: string;
    name: string;
    type: string;
    difficulty: number;
    description: string | null;
    cues: string | null;
    primaryMuscles: string[];
}
interface ExerciseActivation {
    muscleId: string;
    muscleName: string;
    activation: number;
}
interface ExerciseWithActivations extends Exercise {
    activations: ExerciseActivation[];
}
interface Muscle {
    id: string;
    name: string;
    anatomicalName: string | null;
    muscleGroup: string;
    biasWeight: number;
    optimalWeeklyVolume: number | null;
    recoveryTime: number | null;
}
interface MuscleActivation {
    muscleId: string;
    muscleName: string;
    muscleGroup: string;
    rawActivation: number;
    biasWeight: number;
    normalizedActivation: number;
    colorTier: number;
}
interface WorkoutExercise {
    exerciseId: string;
    sets: number;
    reps?: number;
    weight?: number;
    duration?: number;
    notes?: string;
}
interface Workout {
    id: string;
    userId: string;
    date: string;
    totalTU: number;
    creditsUsed: number;
    notes: string | null;
    isPublic: boolean;
    exerciseData: WorkoutExercise[];
    muscleActivations: Record<string, number>;
    createdAt: string;
}
interface WorkoutStats {
    allTime: {
        workoutCount: number;
        totalTU: number;
    };
    thisWeek: {
        workoutCount: number;
        totalTU: number;
    };
    thisMonth: {
        workoutCount: number;
        totalTU: number;
    };
}
interface WorkoutPreview {
    totalTU: number;
    activations: MuscleActivation[];
}
interface Archetype {
    id: string;
    name: string;
    philosophy: string | null;
    description: string | null;
    focusAreas: string[];
    iconUrl: string | null;
}
interface ArchetypeLevel {
    id?: number;
    archetypeId?: string;
    level: number;
    name: string;
    totalTU?: number;
    total_tu?: number;
    description: string | null;
    muscleTargets?: Record<string, number>;
}
interface ArchetypeWithLevels extends Archetype {
    levels: ArchetypeLevel[];
}
interface ArchetypeProgress {
    archetypeId: string;
    archetypeName: string;
    currentLevel: number;
    currentLevelName: string;
    currentTU: number;
    nextLevelTU: number | null;
    progressPercent: number;
}
interface JourneyPath {
    archetype: string;
    name: string;
    philosophy: string;
    description: string;
    focusAreas: string[];
    isCurrent: boolean;
    percentComplete: number;
    levels: Array<{
        level: number;
        name: string;
        total_tu: number;
    }>;
}
interface JourneyMuscleBreakdown {
    id: string;
    name: string;
    group: string;
    totalActivation: number;
}
interface JourneyStats {
    weekly: {
        workouts: number;
        tu: number;
        avgTuPerWorkout: number;
    };
    monthly: {
        workouts: number;
        tu: number;
        avgTuPerWorkout: number;
    };
    allTime: {
        workouts: number;
        tu: number;
        avgTuPerWorkout: number;
    };
}
interface JourneyData {
    totalTU: number;
    totalWorkouts: number;
    currentLevel: number;
    currentLevelName: string;
    nextLevelTU: number;
    progressToNextLevel: number;
    currentArchetype: string | null;
    daysSinceJoined: number;
    streak: number;
    stats: JourneyStats;
    workoutHistory: Array<{
        date: string;
        tu: number;
        count: number;
    }>;
    muscleBreakdown: JourneyMuscleBreakdown[];
    muscleGroups: Array<{
        name: string;
        total: number;
    }>;
    paths: JourneyPath[];
    levels: Array<{
        level: number;
        name: string;
        total_tu: number;
        achieved: boolean;
    }>;
    topExercises: Array<{
        id: string;
        name: string;
        count: number;
    }>;
    recentWorkouts: Array<{
        id: string;
        date: string;
        tu: number;
        createdAt: string;
    }>;
}
type RivalStatus = 'pending' | 'active' | 'declined' | 'ended';
interface RivalOpponent {
    id: string;
    username: string;
    avatar?: string | null;
    archetype?: string | null;
    level?: number;
}
interface Rival {
    id: string;
    challengerId: string;
    challengedId: string;
    status: RivalStatus;
    createdAt: string;
    startedAt: string | null;
    endedAt: string | null;
    opponent: RivalOpponent;
    isChallenger: boolean;
    myTU: number;
    opponentTU: number;
    myLastWorkout: string | null;
    opponentLastWorkout: string | null;
    tuDifference: number;
    isWinning: boolean;
}
interface RivalStats {
    activeRivals: number;
    wins: number;
    losses: number;
    ties: number;
    totalTUEarned: number;
    currentStreak: number;
    longestStreak: number;
}
interface RivalSearchResult {
    id: string;
    username: string;
    avatar?: string;
    archetype?: string;
}
type WearableProvider = 'apple_health' | 'fitbit' | 'garmin' | 'google_fit' | 'whoop' | 'oura';
interface WearableConnection {
    id: string;
    userId: string;
    provider: WearableProvider;
    providerUserId?: string;
    isActive: boolean;
    lastSyncAt: string | null;
    syncError?: string | null;
    syncStatus?: 'idle' | 'syncing' | 'success' | 'error';
    createdAt: string;
}
interface HeartRateSample {
    timestamp: string;
    bpm: number;
    source?: string;
    context?: 'resting' | 'active' | 'workout' | 'sleep';
}
interface WorkoutSample {
    id: string;
    type: string;
    startTime: string;
    endTime: string;
    duration: number;
    calories?: number;
    distance?: number;
    avgHeartRate?: number;
    maxHeartRate?: number;
    minHeartRate?: number;
    steps?: number;
    elevationGain?: number;
    source: WearableProvider;
    externalId?: string;
}
interface ActivitySample {
    date: string;
    steps?: number;
    activeCalories?: number;
    totalCalories?: number;
    moveMinutes?: number;
    standHours?: number;
    exerciseMinutes?: number;
    distanceMeters?: number;
    floorsClimbed?: number;
    source: WearableProvider;
}
interface SleepSample {
    id?: string;
    startTime: string;
    endTime: string;
    duration: number;
    sleepStages?: {
        awake?: number;
        light?: number;
        deep?: number;
        rem?: number;
    };
    sleepScore?: number;
    source: WearableProvider;
}
interface BodyMeasurementSample {
    type: 'weight' | 'body_fat' | 'height' | 'bmi' | 'lean_mass';
    value: number;
    unit: string;
    measuredAt: string;
    source: WearableProvider;
}
interface HealthSyncPayload {
    heartRate?: HeartRateSample[];
    workouts?: WorkoutSample[];
    activity?: ActivitySample[];
    sleep?: SleepSample[];
    bodyMeasurements?: BodyMeasurementSample[];
}
interface HealthSyncResult {
    synced: {
        heartRate: number;
        workouts: number;
        activity: number;
        sleep: number;
        bodyMeasurements: number;
    };
    conflicts: SyncConflict[];
    lastSyncAt: string;
}
interface SyncConflict {
    type: 'workout' | 'activity' | 'bodyMeasurement';
    localId?: string;
    remoteId?: string;
    field?: string;
    localValue?: unknown;
    remoteValue?: unknown;
    resolution: 'local_wins' | 'remote_wins' | 'merged' | 'skipped';
    timestamp: string;
}
interface HealthSyncStatus {
    provider: WearableProvider;
    lastSyncAt: string | null;
    syncStatus: 'idle' | 'syncing' | 'success' | 'error';
    syncError: string | null;
    lastSyncedCounts?: {
        heartRate: number;
        workouts: number;
        activity: number;
        sleep: number;
        bodyMeasurements: number;
    };
}
type ConflictResolutionStrategy = 'local_wins' | 'remote_wins' | 'newest_wins' | 'merge';
interface SyncOptions {
    conflictStrategy?: ConflictResolutionStrategy;
    syncDirection?: 'upload' | 'download' | 'bidirectional';
    startDate?: string;
    endDate?: string;
}
interface HealthSummary {
    today: {
        steps: number;
        activeCalories: number;
        avgHeartRate: number | null;
        workoutMinutes: number;
        sleepHours: number | null;
    };
    thisWeek: {
        totalSteps: number;
        avgDailySteps: number;
        totalWorkoutMinutes: number;
        avgSleepHours: number | null;
        avgRestingHeartRate: number | null;
    };
    connections: WearableConnection[];
    syncStatus?: HealthSyncStatus[];
}
type CrewRole = 'owner' | 'captain' | 'member';
type CrewWarStatus = 'pending' | 'active' | 'completed' | 'cancelled';
interface Crew {
    id: string;
    name: string;
    tag: string;
    description: string | null;
    avatar: string | null;
    color: string;
    ownerId: string;
    memberCount: number;
    totalTU: number;
    weeklyTU: number;
    wins: number;
    losses: number;
    createdAt: string;
}
interface CrewMember {
    id: string;
    crewId: string;
    userId: string;
    role: CrewRole;
    joinedAt: string;
    weeklyTU: number;
    totalTU: number;
    username: string;
    avatar: string | null;
    archetype: string | null;
}
interface CrewWar {
    id: string;
    challengerCrewId: string;
    defendingCrewId: string;
    status: CrewWarStatus;
    startDate: string;
    endDate: string;
    challengerTU: number;
    defendingTU: number;
    winnerId: string | null;
    createdAt: string;
    challengerCrew: Pick<Crew, 'id' | 'name' | 'tag' | 'avatar' | 'color'>;
    defendingCrew: Pick<Crew, 'id' | 'name' | 'tag' | 'avatar' | 'color'>;
    isChallenger: boolean;
    myCrewTU: number;
    opponentCrewTU: number;
    daysRemaining: number;
    isWinning: boolean;
}
interface CrewStats {
    totalMembers: number;
    totalTU: number;
    weeklyTU: number;
    warsWon: number;
    warsLost: number;
    currentStreak: number;
    topContributors: {
        userId: string;
        username: string;
        avatar: string | null;
        weeklyTU: number;
    }[];
}
interface CrewLeaderboardEntry {
    rank: number;
    crew: Pick<Crew, 'id' | 'name' | 'tag' | 'avatar' | 'color' | 'memberCount' | 'weeklyTU'>;
}
interface MyCrewData {
    crew: Crew;
    membership: CrewMember;
    members: CrewMember[];
    wars: CrewWar[];
    stats: CrewStats;
}
interface CharacterStats {
    strength: number;
    constitution: number;
    dexterity: number;
    power: number;
    endurance: number;
    vitality: number;
    lastCalculatedAt?: string;
}
interface StatRanking {
    rank: number;
    total: number;
    percentile: number;
}
interface StatRankingsByScope {
    global: StatRanking;
    country?: StatRanking;
    state?: StatRanking;
    city?: StatRanking;
}
interface StatsWithRankings {
    stats: CharacterStats;
    rankings: Record<string, StatRankingsByScope>;
}
interface StatsHistoryEntry {
    snapshotDate: string;
    strength: number;
    constitution: number;
    dexterity: number;
    power: number;
    endurance: number;
    vitality: number;
}
interface ExtendedProfile {
    gender: string | null;
    city: string | null;
    county: string | null;
    state: string | null;
    country: string | null;
    countryCode: string | null;
    leaderboardOptIn: boolean;
    profileVisibility: string;
}
interface LeaderboardEntry {
    userId: string;
    username: string;
    avatarUrl: string | null;
    statValue: number;
    rank: number;
    gender?: string;
    country?: string;
    state?: string;
    city?: string;
}
interface StatInfo {
    id: string;
    name: string;
    abbr: string;
    description: string;
    color: string;
}
interface PrivacySettings {
    minimalistMode: boolean;
    optOutLeaderboards: boolean;
    optOutCommunityFeed: boolean;
    optOutCrews: boolean;
    optOutRivals: boolean;
    optOutHangouts: boolean;
    optOutMessaging: boolean;
    optOutHighFives: boolean;
    excludeFromStatsComparison: boolean;
    excludeFromLocationFeatures: boolean;
    excludeFromActivityFeed: boolean;
    hideGamification: boolean;
    hideAchievements: boolean;
    hideTips: boolean;
    hideSocialNotifications: boolean;
    hideProgressComparisons: boolean;
    disablePresenceTracking: boolean;
    disableWorkoutSharing: boolean;
    profileCompletelyPrivate: boolean;
}
interface PrivacySummary {
    mode: 'minimalist' | 'standard';
    summary: string;
    enabledFeatures: string[];
    disabledFeatures: string[];
    dataPrivacy: {
        excludedFromComparisons: boolean;
        excludedFromActivityFeed: boolean;
        locationHidden: boolean;
        presenceHidden: boolean;
        profilePrivate: boolean;
    };
}
interface OnboardingStatus {
    completed: boolean;
    completedAt: string | null;
    hasProfile: boolean;
    hasGender: boolean;
    hasUnits: boolean;
}
interface PhysicalProfile {
    gender: string | null;
    dateOfBirth: string | null;
    heightCm: number | null;
    heightFt: number | null;
    heightIn: number | null;
    weightKg: number | null;
    weightLbs: number | null;
    preferredUnits: 'metric' | 'imperial';
    onboardingCompletedAt: string | null;
}
interface PhysicalProfileInput {
    gender?: 'male' | 'female' | 'non_binary' | 'prefer_not_to_say';
    dateOfBirth?: string;
    heightCm?: number;
    heightFt?: number;
    heightIn?: number;
    weightKg?: number;
    weightLbs?: number;
    preferredUnits: 'metric' | 'imperial';
}
interface EquipmentType {
    id: string;
    name: string;
    category: string;
    description: string | null;
    iconUrl: string | null;
    displayOrder: number;
}
interface LocationEquipment {
    equipmentTypeId: string;
    equipmentName: string;
    category: string;
    confirmedCount: number;
    deniedCount: number;
    isVerified: boolean;
    firstReportedAt: string;
    lastReportedAt: string;
}
interface UserHomeEquipment {
    id: number;
    userId: string;
    equipmentTypeId: string;
    equipmentName: string;
    category: string;
    locationType: 'home' | 'work' | 'other';
    notes: string | null;
}
interface User {
    id: string | number;
    email?: string;
    username?: string;
    archetype?: string;
    [key: string]: unknown;
}
interface AuthResponse {
    token: string;
    user: User;
}
type RankName = 'novice' | 'trainee' | 'apprentice' | 'practitioner' | 'journeyperson' | 'expert' | 'master' | 'grandmaster';
interface RankDefinitionResponse {
    id: string;
    tier: number;
    name: RankName;
    displayName: string;
    xpThreshold: number;
    badgeIcon: string;
    badgeColor: string;
    perks: string[];
}
interface UserRankResponse {
    userId: string;
    currentRank: RankName;
    currentTier: number;
    displayName: string;
    totalXp: number;
    xpToNextRank: number | null;
    progressPercent: number;
    badgeIcon: string;
    badgeColor: string;
    perks?: string[];
    nextRank?: {
        name: RankName;
        displayName: string;
        xpThreshold: number;
        badgeIcon?: string;
        badgeColor?: string;
    } | null;
    veteranTier: number;
    veteranLabel: string | null;
    rankUpdatedAt: string | null;
    xpToday?: number;
    xpThisWeek?: number;
}
interface XpHistoryEntryResponse {
    id: string;
    amount: number;
    sourceType: string;
    sourceId?: string;
    reason: string;
    createdAt: string;
}
interface VeteranBadgeResponse {
    tier: 0 | 1 | 2 | 3;
    label: string | null;
    icon: string;
    color: string;
    monthsActive: number;
    nextTier?: {
        tier: number;
        monthsRequired: number;
        monthsRemaining: number;
    } | null;
}
interface RankLeaderboardEntry {
    rank: number;
    userId: string;
    username: string;
    displayName?: string;
    avatarUrl?: string;
    totalXp: number;
    currentRank: RankName;
    badgeIcon: string;
    badgeColor: string;
    veteranTier: number;
    country?: string;
}
interface RankLeaderboardResponse {
    data: {
        entries: RankLeaderboardEntry[];
        userRank: number | null;
    };
    pagination: PaginationMeta;
    meta: {
        scope: 'global' | 'country' | 'state' | 'city';
        filters: {
            country?: string;
            state?: string;
            city?: string;
        };
    };
}
interface PaginationMeta {
    total: number;
    limit: number;
    offset: number;
    hasMore: boolean;
}
interface Wallet {
    wallet: {
        balance: number;
        currency: string;
    };
}
interface Transaction {
    id: string | number;
    amount: number;
    description?: string;
    created_at?: string;
}
interface TransactionsResponse {
    transactions: Transaction[];
}
interface Subscription {
    status: 'active' | 'trialing' | 'canceled' | 'past_due' | 'incomplete' | null;
    currentPeriodEnd: string | null;
    cancelAtPeriodEnd: boolean;
}
interface BillingCheckoutResponse {
    url: string;
}
interface FoundingMemberStatus {
    isFoundingMember: boolean;
    memberNumber: number | null;
    joinedAt: string | null;
    perks: string[];
}
interface HighFiveUser {
    id: string | number;
    username?: string;
}
interface Encouragement {
    id: string | number;
    sender_name?: string;
    recipient_name?: string;
    type: string;
    message?: string | null;
    created_at?: string;
    read_at?: string | null;
}
interface HighFiveFeed {
    encouragements: Encouragement[];
}
interface HighFiveStats {
    sent?: number;
    received?: number;
    unread?: number;
}
interface Settings {
    email_notifications?: boolean;
    sms_notifications?: boolean;
    theme?: string;
}
interface SettingsResponse {
    settings?: Settings;
}
interface Profile {
    id?: string | number;
    username?: string;
    bio?: string;
    avatar?: string;
}
interface Stats {
    xp: number;
    level: number;
    levelName: string;
    rank: string;
    streak: number;
    workouts: number;
    lastWorkoutDate: string | null;
}
interface SkillTree {
    id: string;
    name: string;
    description?: string;
    category: string;
    icon?: string;
    color?: string;
    orderIndex: number;
}
interface SkillNode {
    id: string;
    treeId: string;
    name: string;
    description?: string;
    difficulty: number;
    prerequisites: string[];
    criteriaType: 'hold' | 'reps' | 'time' | 'form_check';
    criteriaValue?: number;
    criteriaDescription?: string;
    xpReward: number;
    creditReward: number;
    achievementId?: string;
    videoUrl?: string;
    thumbnailUrl?: string;
    tips: string[];
    commonMistakes: string[];
    tier: number;
    position: number;
}
interface SkillTreeWithNodes extends SkillTree {
    nodes: SkillNode[];
}
interface UserSkillProgress {
    id: string;
    userId: string;
    skillNodeId: string;
    status: 'locked' | 'available' | 'in_progress' | 'achieved';
    bestValue?: number;
    attemptCount: number;
    practiceMinutes: number;
    achievedAt?: string;
    verified: boolean;
    verificationVideoUrl?: string;
    notes?: string;
    createdAt: string;
    updatedAt: string;
}
interface SkillNodeWithProgress extends SkillNode {
    progress?: UserSkillProgress;
}
interface SkillProgressSummary {
    totalSkills: number;
    achievedSkills: number;
    inProgressSkills: number;
    availableSkills: number;
    totalPracticeMinutes: number;
    recentProgress: {
        skillName: string;
        achievedAt: string;
    }[];
}
interface SkillPracticeLog {
    id: string;
    userId: string;
    skillNodeId: string;
    practiceDate: string;
    durationMinutes: number;
    valueAchieved?: number;
    notes?: string;
    createdAt: string;
}
interface SkillPracticeLogWithName extends SkillPracticeLog {
    skillName: string;
}
interface SkillLeaderboardEntry {
    userId: string;
    username: string;
    bestValue: number;
    achievedAt: string;
}
interface FeedbackItem {
    id: string;
    type: 'bug_report' | 'feature_request' | 'question' | 'general';
    status: 'open' | 'in_progress' | 'resolved' | 'closed' | 'wont_fix';
    priority: 'low' | 'medium' | 'high' | 'critical';
    title: string;
    description: string;
    stepsToReproduce?: string | null;
    expectedBehavior?: string | null;
    actualBehavior?: string | null;
    category?: string | null;
    attachments?: string[];
    upvotes: number;
    createdAt: string;
    updatedAt: string;
    resolvedAt?: string | null;
    deviceInfo?: {
        userAgent?: string | null;
        screenSize?: string | null;
        appVersion?: string | null;
        platform?: string | null;
    };
}
interface FeedbackResponse {
    id: string;
    responderType: 'system' | 'admin' | 'user';
    message: string;
    createdAt: string;
}
interface FAQEntry {
    id: string;
    category: string;
    categoryLabel: string;
    question: string;
    answer: string;
    viewCount: number;
    helpfulCount: number;
    notHelpfulCount: number;
}
interface DataResponse<T> {
    data: T;
}
declare const apiClient: {
    auth: {
        login: (email: string, password: string) => Promise<AuthResponse>;
        register: (payload: {
            email: string;
            password: string;
            username?: string;
        }) => Promise<AuthResponse>;
        profile: () => Promise<User>;
    };
    billing: {
        subscription: () => Promise<DataResponse<Subscription | null>>;
        checkout: () => Promise<DataResponse<BillingCheckoutResponse>>;
        creditsCheckout: () => Promise<DataResponse<BillingCheckoutResponse>>;
        portal: () => Promise<DataResponse<BillingCheckoutResponse>>;
        foundingMember: () => Promise<DataResponse<FoundingMemberStatus>>;
        claimFoundingMember: () => Promise<DataResponse<FoundingMemberStatus>>;
    };
    exercises: {
        list: (type?: string) => Promise<DataResponse<Exercise[]>>;
        get: (id: string) => Promise<DataResponse<ExerciseWithActivations>>;
        types: () => Promise<DataResponse<string[]>>;
        search: (query: string) => Promise<DataResponse<Exercise[]>>;
        activations: (id: string) => Promise<DataResponse<Record<string, number>>>;
    };
    muscles: {
        list: (group?: string) => Promise<DataResponse<Muscle[]>>;
        get: (id: string) => Promise<DataResponse<Muscle>>;
        groups: () => Promise<DataResponse<string[]>>;
    };
    workouts: {
        create: (payload: {
            exercises: WorkoutExercise[];
            idempotencyKey: string;
            date?: string;
            notes?: string;
            isPublic?: boolean;
        }) => Promise<DataResponse<Workout>>;
        list: (limit?: number, offset?: number) => Promise<DataResponse<Workout[]>>;
        get: (id: string) => Promise<DataResponse<Workout>>;
        stats: () => Promise<DataResponse<WorkoutStats>>;
        muscleActivations: (days?: number) => Promise<DataResponse<MuscleActivation[]>>;
        preview: (exercises: WorkoutExercise[]) => Promise<DataResponse<WorkoutPreview>>;
    };
    archetypes: {
        list: () => Promise<DataResponse<Archetype[]>>;
        get: (id: string) => Promise<DataResponse<ArchetypeWithLevels>>;
        levels: (id: string) => Promise<DataResponse<ArchetypeLevel[]>>;
        myProgress: () => Promise<DataResponse<ArchetypeProgress | null>>;
        progressFor: (archetypeId: string) => Promise<DataResponse<ArchetypeProgress>>;
        select: (archetypeId: string) => Promise<DataResponse<{
            success: boolean;
            archetypeId: string;
        }>>;
    };
    journey: {
        get: () => Promise<DataResponse<JourneyData>>;
        paths: () => Promise<DataResponse<{
            paths: JourneyPath[];
        }>>;
        switchArchetype: (archetype: string) => Promise<{
            success: boolean;
            data: {
                archetype: string;
            };
        }>;
    };
    progress: {
        stats: () => Promise<DataResponse<Stats>>;
    };
    wallet: {
        balance: () => Promise<Wallet>;
        transactions: (limit?: number) => Promise<TransactionsResponse>;
        transfer: (payload: {
            recipient_id: string | number;
            amount: number;
        }) => Promise<{
            success?: boolean;
        }>;
    };
    highFives: {
        users: () => Promise<{
            users: HighFiveUser[];
        }>;
        received: () => Promise<HighFiveFeed>;
        sent: () => Promise<HighFiveFeed>;
        stats: () => Promise<HighFiveStats>;
        send: (payload: {
            recipient_id: string | number;
            type: string;
            message?: string;
        }) => Promise<{
            error?: string;
        }>;
    };
    settings: {
        fetch: () => Promise<SettingsResponse>;
        update: (updates: Partial<Settings>) => Promise<Settings>;
    };
    profile: {
        get: () => Promise<Profile>;
        update: (updates: Partial<Profile>) => Promise<Profile>;
        avatars: () => Promise<{
            avatars: unknown[];
        }>;
        themes: () => Promise<{
            themes: unknown[];
        }>;
    };
    rivals: {
        list: (status?: RivalStatus) => Promise<DataResponse<{
            rivals: Rival[];
            stats: RivalStats;
        }>>;
        get: (id: string) => Promise<DataResponse<Rival>>;
        pending: () => Promise<DataResponse<Rival[]>>;
        stats: () => Promise<DataResponse<RivalStats>>;
        search: (query: string, limit?: number) => Promise<DataResponse<RivalSearchResult[]>>;
        challenge: (userId: string) => Promise<DataResponse<Rival>>;
        accept: (id: string) => Promise<DataResponse<Rival>>;
        decline: (id: string) => Promise<{
            success: boolean;
        }>;
        end: (id: string) => Promise<{
            success: boolean;
        }>;
    };
    wearables: {
        /** Get health summary with today/week stats and connections */
        summary: () => Promise<DataResponse<HealthSummary>>;
        /** Get sync status for all connected providers */
        status: () => Promise<DataResponse<{
            syncStatus: HealthSyncStatus[];
        }>>;
        /** Get sync status for a specific provider */
        providerStatus: (provider: WearableProvider) => Promise<DataResponse<HealthSyncStatus>>;
        /** Connect a wearable provider */
        connect: (provider: WearableProvider, data?: {
            providerUserId?: string;
            accessToken?: string;
            refreshToken?: string;
            tokenExpiresAt?: string;
        }) => Promise<DataResponse<WearableConnection>>;
        /** Disconnect a wearable provider */
        disconnect: (provider: WearableProvider) => Promise<{
            success: boolean;
        }>;
        /** Sync health data with optional conflict resolution strategy */
        sync: (provider: WearableProvider, data: HealthSyncPayload, options?: SyncOptions) => Promise<DataResponse<HealthSyncResult>>;
        /** Get recent workouts from wearables */
        workouts: (limit?: number) => Promise<DataResponse<{
            workouts: WorkoutSample[];
        }>>;
        /** Get workouts for export to wearable (bi-directional sync) */
        exportWorkouts: (options?: {
            startDate?: string;
            endDate?: string;
            limit?: number;
        }) => Promise<DataResponse<{
            workouts: WorkoutSample[];
        }>>;
    };
    crews: {
        my: () => Promise<DataResponse<MyCrewData | null>>;
        create: (name: string, tag: string, description?: string, color?: string) => Promise<DataResponse<Crew>>;
        get: (id: string) => Promise<DataResponse<{
            crew: Crew;
            members: CrewMember[];
            stats: CrewStats;
        }>>;
        search: (query: string, limit?: number) => Promise<DataResponse<Crew[]>>;
        leaderboard: (limit?: number) => Promise<DataResponse<CrewLeaderboardEntry[]>>;
        invite: (crewId: string, inviteeId: string) => Promise<DataResponse<{
            id: string;
        }>>;
        acceptInvite: (inviteId: string) => Promise<DataResponse<CrewMember>>;
        leave: () => Promise<{
            success: boolean;
        }>;
        startWar: (crewId: string, defendingCrewId: string, durationDays?: number) => Promise<DataResponse<CrewWar>>;
        getWars: (crewId: string) => Promise<DataResponse<CrewWar[]>>;
    };
    characterStats: {
        /**
         * Get current user's character stats and rankings
         */
        me: () => Promise<DataResponse<StatsWithRankings>>;
        /**
         * Get another user's stats (if public)
         */
        getUser: (userId: string) => Promise<DataResponse<{
            userId: string;
            stats: CharacterStats;
        }>>;
        /**
         * Get stats history for progress charts
         */
        history: (days?: number) => Promise<DataResponse<StatsHistoryEntry[]>>;
        /**
         * Force recalculate all stats from workout history
         */
        recalculate: () => Promise<DataResponse<{
            stats: CharacterStats;
            message: string;
        }>>;
        /**
         * Get leaderboard rankings with filtering
         */
        leaderboard: (options?: {
            stat?: "strength" | "constitution" | "dexterity" | "power" | "endurance" | "vitality";
            scope?: "global" | "country" | "state" | "city";
            scopeValue?: string;
            gender?: "male" | "female" | "non_binary";
            limit?: number;
            offset?: number;
        }) => Promise<DataResponse<LeaderboardEntry[]>>;
        /**
         * Get current user's rankings across all scopes
         */
        myRankings: () => Promise<DataResponse<{
            rankings: Record<string, StatRankingsByScope>;
            profile: {
                gender: string | null;
                city: string | null;
                state: string | null;
                country: string | null;
            };
        }>>;
        /**
         * Get extended profile (gender, location)
         */
        extendedProfile: () => Promise<DataResponse<ExtendedProfile>>;
        /**
         * Update extended profile
         */
        updateExtendedProfile: (updates: Partial<{
            gender: "male" | "female" | "non_binary" | "prefer_not_to_say";
            city: string;
            county: string;
            state: string;
            country: string;
            countryCode: string;
            leaderboardOptIn: boolean;
            profileVisibility: "public" | "friends" | "private";
        }>) => Promise<DataResponse<ExtendedProfile>>;
        /**
         * Get information about the stats system
         */
        info: () => Promise<DataResponse<{
            stats: StatInfo[];
        }>>;
    };
    privacy: {
        /**
         * Get current user's privacy settings
         */
        get: () => Promise<DataResponse<PrivacySettings>>;
        /**
         * Update privacy settings
         */
        update: (updates: Partial<PrivacySettings>) => Promise<DataResponse<PrivacySettings>>;
        /**
         * Enable full minimalist mode (one-click privacy)
         * Disables all community features and excludes user from all comparisons
         */
        enableMinimalist: () => Promise<DataResponse<{
            minimalistMode: boolean;
            message: string;
        }>>;
        /**
         * Disable minimalist mode and restore defaults
         */
        disableMinimalist: () => Promise<DataResponse<{
            minimalistMode: boolean;
            message: string;
        }>>;
        /**
         * Get a user-friendly summary of privacy settings
         */
        summary: () => Promise<DataResponse<PrivacySummary>>;
    };
    onboarding: {
        /**
         * Get onboarding status
         */
        status: () => Promise<DataResponse<OnboardingStatus>>;
        /**
         * Get current physical profile
         */
        getProfile: () => Promise<DataResponse<PhysicalProfile>>;
        /**
         * Save physical profile during onboarding
         */
        saveProfile: (profile: PhysicalProfileInput) => Promise<DataResponse<{
            success: boolean;
            message: string;
        }>>;
        /**
         * Save home equipment during onboarding
         */
        saveHomeEquipment: (equipmentIds: string[], locationType?: "home" | "work" | "other") => Promise<DataResponse<{
            success: boolean;
            message: string;
            equipmentCount: number;
        }>>;
        /**
         * Mark onboarding as complete
         */
        complete: () => Promise<DataResponse<{
            success: boolean;
            message: string;
            completedAt: string;
        }>>;
        /**
         * Skip onboarding
         */
        skip: () => Promise<DataResponse<{
            success: boolean;
            message: string;
            skipped: boolean;
        }>>;
    };
    equipment: {
        /**
         * Get all equipment types
         */
        types: () => Promise<DataResponse<EquipmentType[]>>;
        /**
         * Get equipment types by category
         */
        typesByCategory: (category: string) => Promise<DataResponse<EquipmentType[]>>;
        /**
         * Get all equipment categories
         */
        categories: () => Promise<DataResponse<string[]>>;
        /**
         * Get equipment at a location
         */
        getLocationEquipment: (hangoutId: string) => Promise<DataResponse<LocationEquipment[]>>;
        /**
         * Get verified equipment at a location
         */
        getVerifiedLocationEquipment: (hangoutId: string) => Promise<DataResponse<string[]>>;
        /**
         * Report equipment at a location
         */
        reportEquipment: (hangoutId: string, types: string[], reportType: "present" | "absent") => Promise<DataResponse<{
            success: boolean;
            message: string;
            reportedCount: number;
        }>>;
        /**
         * Get user's reports for a location
         */
        getMyReports: (hangoutId: string) => Promise<DataResponse<{
            equipmentTypeId: string;
            reportType: "present" | "absent";
        }[]>>;
        /**
         * Get user's home equipment
         */
        getHomeEquipment: (locationType?: "home" | "work" | "other") => Promise<DataResponse<UserHomeEquipment[]>>;
        /**
         * Get user's home equipment IDs
         */
        getHomeEquipmentIds: (locationType?: "home" | "work" | "other") => Promise<DataResponse<string[]>>;
        /**
         * Set user's home equipment (replaces all)
         */
        setHomeEquipment: (equipmentIds: string[], locationType?: "home" | "work" | "other") => Promise<DataResponse<{
            success: boolean;
            message: string;
            equipmentCount: number;
        }>>;
        /**
         * Add single equipment to home
         */
        addHomeEquipment: (equipmentId: string, locationType?: "home" | "work" | "other", notes?: string) => Promise<DataResponse<{
            success: boolean;
            message: string;
        }>>;
        /**
         * Remove equipment from home
         */
        removeHomeEquipment: (equipmentId: string, locationType?: "home" | "work" | "other") => Promise<{
            success: boolean;
            message: string;
        }>;
    };
    hangouts: {
        /**
         * Get all hangout themes
         */
        themes: () => Promise<DataResponse<VirtualHangoutTheme[]>>;
        /**
         * List virtual hangouts
         */
        list: (themeId?: number, limit?: number, offset?: number) => Promise<DataResponse<VirtualHangout[]> & {
            meta: {
                total: number;
            };
        }>;
        /**
         * Get recommended hangouts for current user
         */
        recommended: (limit?: number) => Promise<DataResponse<VirtualHangout[]>>;
        /**
         * Get user's hangout memberships
         */
        my: (limit?: number, offset?: number) => Promise<DataResponse<VirtualHangout[]> & {
            meta: {
                total: number;
            };
        }>;
        /**
         * Get a single hangout
         */
        get: (id: number) => Promise<DataResponse<VirtualHangout>>;
        /**
         * Join a hangout
         */
        join: (id: number, showInMemberList?: boolean, receiveNotifications?: boolean) => Promise<DataResponse<{
            message: string;
        }>>;
        /**
         * Leave a hangout
         */
        leave: (id: number) => Promise<DataResponse<{
            message: string;
        }>>;
        /**
         * Get hangout members
         */
        members: (id: number, limit?: number, offset?: number) => Promise<DataResponse<HangoutMember[]> & {
            meta: {
                total: number;
            };
        }>;
        /**
         * Get hangout activity feed
         */
        activity: (id: number, limit?: number, offset?: number) => Promise<DataResponse<HangoutActivity[]>>;
        /**
         * Share a workout to a hangout
         */
        shareWorkout: (id: number, workoutId: string, message?: string) => Promise<DataResponse<{
            message: string;
        }>>;
        /**
         * Send heartbeat to update last active time
         */
        heartbeat: (id: number) => Promise<DataResponse<{
            acknowledged: boolean;
        }>>;
        /**
         * Get posts from hangout bulletin board
         */
        posts: (id: number, options?: {
            limit?: number;
            offset?: number;
            sortBy?: "hot" | "new" | "top";
        }) => Promise<DataResponse<BulletinPost[]> & {
            meta: {
                total: number;
                boardId: number;
            };
        }>;
        /**
         * Create a post in hangout bulletin board
         */
        createPost: (id: number, post: {
            title: string;
            content: string;
            postType?: string;
            mediaUrls?: string[];
        }) => Promise<DataResponse<BulletinPost>>;
    };
    communities: {
        /**
         * Create a new community
         */
        create: (data: {
            name: string;
            tagline?: string;
            description?: string;
            communityType: "goal" | "interest" | "institution" | "local" | "challenge";
            goalType?: string;
            institutionType?: string;
            privacy?: "public" | "private" | "secret";
            iconEmoji?: string;
            accentColor?: string;
            rules?: string;
            requiresApproval?: boolean;
            allowMemberPosts?: boolean;
        }) => Promise<DataResponse<Community>>;
        /**
         * Search/list communities
         */
        search: (options?: {
            query?: string;
            communityType?: string;
            goalType?: string;
            institutionType?: string;
            limit?: number;
            offset?: number;
        }) => Promise<DataResponse<Community[]> & {
            meta: {
                total: number;
            };
        }>;
        /**
         * Get user's communities
         */
        my: (limit?: number, offset?: number) => Promise<DataResponse<Community[]> & {
            meta: {
                total: number;
            };
        }>;
        /**
         * Get a community by ID or slug
         */
        get: (idOrSlug: string | number) => Promise<DataResponse<Community>>;
        /**
         * Join a community
         */
        join: (id: number) => Promise<DataResponse<{
            message: string;
            status: string;
        }>>;
        /**
         * Leave a community
         */
        leave: (id: number) => Promise<DataResponse<{
            message: string;
        }>>;
        /**
         * Get community members
         */
        members: (id: number, limit?: number, offset?: number, status?: string) => Promise<DataResponse<CommunityMember[]> & {
            meta: {
                total: number;
            };
        }>;
        /**
         * Get community events
         */
        events: (id: number, upcoming?: boolean, limit?: number, offset?: number) => Promise<DataResponse<CommunityEvent[]>>;
        /**
         * Create a community event
         */
        createEvent: (id: number, event: {
            title: string;
            description?: string;
            eventType: "meetup" | "challenge" | "workshop" | "competition" | "social";
            startsAt: string;
            endsAt?: string;
            timezone?: string;
            locationName?: string;
            locationAddress?: string;
            isVirtual?: boolean;
            virtualUrl?: string;
            maxParticipants?: number;
        }) => Promise<DataResponse<CommunityEvent>>;
        /**
         * Get posts from community bulletin board
         */
        posts: (id: number, options?: {
            limit?: number;
            offset?: number;
            sortBy?: "hot" | "new" | "top";
        }) => Promise<DataResponse<BulletinPost[]> & {
            meta: {
                total: number;
                boardId: number;
            };
        }>;
        /**
         * Create a post in community bulletin board
         */
        createPost: (id: number, post: {
            title: string;
            content: string;
            postType?: string;
            mediaUrls?: string[];
        }) => Promise<DataResponse<BulletinPost>>;
    };
    bulletin: {
        /**
         * Get a single post
         */
        getPost: (postId: string) => Promise<DataResponse<BulletinPost>>;
        /**
         * Vote on a post
         */
        votePost: (postId: string, voteType: "up" | "down") => Promise<DataResponse<{
            upvotes: number;
            downvotes: number;
            score: number;
        }>>;
        /**
         * Get comments for a post
         */
        getComments: (postId: string, limit?: number, offset?: number) => Promise<DataResponse<BulletinComment[]> & {
            meta: {
                total: number;
            };
        }>;
        /**
         * Add a comment to a post
         */
        addComment: (postId: string, content: string, parentId?: string) => Promise<DataResponse<BulletinComment>>;
        /**
         * Vote on a comment
         */
        voteComment: (commentId: string, voteType: "up" | "down") => Promise<DataResponse<{
            upvotes: number;
            downvotes: number;
            score: number;
        }>>;
        /**
         * Pin a post (moderator)
         */
        pinPost: (postId: string) => Promise<DataResponse<{
            message: string;
        }>>;
        /**
         * Unpin a post (moderator)
         */
        unpinPost: (postId: string) => Promise<DataResponse<{
            message: string;
        }>>;
        /**
         * Hide a post (moderator)
         */
        hidePost: (postId: string) => Promise<DataResponse<{
            message: string;
        }>>;
    };
    exerciseLeaderboards: {
        /**
         * Get leaderboard for a specific metric
         */
        get: (options: {
            exerciseId: string;
            metricKey: string;
            periodType?: "daily" | "weekly" | "monthly" | "all_time";
            hangoutId?: number;
            gender?: string;
            ageBand?: string;
            limit?: number;
            cursor?: string;
        }) => Promise<DataResponse<{
            entries: Array<{
                rank: number;
                userId: string;
                username: string;
                avatarUrl?: string;
                value: number;
                updatedAt: string;
            }>;
            nextCursor?: string;
            hasMore: boolean;
        }>>;
        /**
         * Get global leaderboard across all exercises
         */
        global: (options?: {
            periodType?: "daily" | "weekly" | "monthly" | "all_time";
            gender?: string;
            ageBand?: string;
            limit?: number;
        }) => Promise<DataResponse<{
            entries: Array<{
                rank: number;
                userId: string;
                username: string;
                avatarUrl?: string;
                totalPoints: number;
                recordCount: number;
            }>;
        }>>;
        /**
         * Get leaderboard for a specific hangout
         */
        hangout: (hangoutId: number, options?: {
            exerciseId?: string;
            metricKey?: string;
            periodType?: "daily" | "weekly" | "monthly" | "all_time";
            limit?: number;
        }) => Promise<DataResponse<{
            entries: Array<{
                rank: number;
                userId: string;
                username: string;
                avatarUrl?: string;
                value: number;
                updatedAt: string;
            }>;
        }>>;
        /**
         * Get current user's rank for a specific metric
         */
        myRank: (options: {
            exerciseId: string;
            metricKey: string;
            periodType?: "daily" | "weekly" | "monthly" | "all_time";
            hangoutId?: number;
        }) => Promise<DataResponse<{
            rank: number;
            percentile: number;
            value: number;
            totalParticipants: number;
        }>>;
        /**
         * Get available metric definitions
         */
        metrics: () => Promise<DataResponse<{
            id: string;
            exerciseId: string;
            metricKey: string;
            displayName: string;
            unit: string;
            direction: "higher" | "lower";
        }[]>>;
    };
    achievements: {
        /**
         * Get all achievement definitions
         */
        definitions: () => Promise<DataResponse<{
            id: string;
            key: string;
            name: string;
            description?: string;
            icon?: string;
            category: string;
            points: number;
            rarity: string;
            enabled: boolean;
        }[]>>;
        /**
         * Get current user's achievements
         */
        my: (options?: {
            limit?: number;
            cursor?: string;
            category?: string;
        }) => Promise<DataResponse<{
            id: string;
            achievementKey: string;
            achievementName: string;
            achievementDescription?: string;
            achievementIcon?: string;
            category: string;
            points: number;
            rarity: string;
            earnedAt: string;
            value?: number;
            hangoutId?: number;
            exerciseId?: string;
        }[]>>;
        /**
         * Get current user's achievement summary
         */
        summary: () => Promise<DataResponse<{
            totalPoints: number;
            totalAchievements: number;
            byCategory: Record<string, number>;
            byRarity: Record<string, number>;
            recentAchievements: Array<{
                id: string;
                achievementKey: string;
                achievementName: string;
                category: string;
                points: number;
                rarity: string;
                earnedAt: string;
            }>;
        }>>;
        /**
         * Get hangout achievement feed
         */
        hangoutFeed: (hangoutId: number, options?: {
            limit?: number;
            cursor?: string;
        }) => Promise<DataResponse<{
            id: string;
            userId: string;
            username: string;
            avatarUrl?: string;
            achievementName: string;
            achievementIcon?: string;
            points: number;
            rarity: string;
            earnedAt: string;
        }[]>>;
    };
    verifications: {
        /**
         * Get achievements that require verification
         */
        getRequired: () => Promise<DataResponse<{
            id: string;
            key: string;
            name: string;
            description?: string;
            tier: string;
            rarity: string;
            points: number;
        }[]>>;
        /**
         * Check if user can submit verification for an achievement
         */
        canVerify: (achievementId: string) => Promise<DataResponse<{
            canSubmit: boolean;
            reason?: string;
        }>>;
        /**
         * Submit verification with video
         */
        submit: (achievementId: string, data: {
            witnessUserId: string;
            notes?: string;
            video?: File;
        }) => Promise<DataResponse<{
            id: string;
            status: string;
            videoUrl?: string;
            thumbnailUrl?: string;
            expiresAt: string;
            witness: {
                witnessUserId: string;
                witnessUsername?: string;
                status: string;
            };
        }>>;
        /**
         * Get current user's verifications
         */
        my: (options?: {
            status?: string;
            limit?: number;
            offset?: number;
        }) => Promise<DataResponse<{
            id: string;
            achievementId: string;
            achievementKey: string;
            achievementName: string;
            achievementTier: string;
            videoUrl?: string;
            thumbnailUrl?: string;
            status: string;
            notes?: string;
            submittedAt: string;
            verifiedAt?: string;
            expiresAt: string;
            witness?: {
                witnessUserId: string;
                witnessUsername?: string;
                attestationText?: string;
                status: string;
                isPublic: boolean;
            };
        }[]>>;
        /**
         * Get a specific verification
         */
        get: (verificationId: string) => Promise<DataResponse<{
            id: string;
            userId: string;
            achievementId: string;
            achievementKey: string;
            achievementName: string;
            achievementTier: string;
            videoUrl?: string;
            thumbnailUrl?: string;
            status: string;
            notes?: string;
            submittedAt: string;
            verifiedAt?: string;
            expiresAt: string;
            username?: string;
            displayName?: string;
            avatarUrl?: string;
            witness?: {
                witnessUserId: string;
                witnessUsername?: string;
                witnessDisplayName?: string;
                attestationText?: string;
                relationship?: string;
                locationDescription?: string;
                status: string;
                isPublic: boolean;
                requestedAt: string;
                respondedAt?: string;
            };
        }>>;
        /**
         * Cancel a pending verification
         */
        cancel: (verificationId: string) => Promise<void>;
        /**
         * Get pending witness requests
         */
        witnessRequests: (options?: {
            status?: string;
            limit?: number;
            offset?: number;
        }) => Promise<DataResponse<{
            id: string;
            userId: string;
            achievementId: string;
            achievementKey: string;
            achievementName: string;
            achievementTier: string;
            videoUrl?: string;
            thumbnailUrl?: string;
            status: string;
            notes?: string;
            submittedAt: string;
            expiresAt: string;
            username?: string;
            displayName?: string;
            avatarUrl?: string;
        }[]>>;
        /**
         * Submit witness attestation
         */
        attest: (verificationId: string, data: {
            confirm: boolean;
            attestationText?: string;
            relationship?: string;
            locationDescription?: string;
            isPublic?: boolean;
        }) => Promise<DataResponse<{
            id: string;
            status: string;
            verifiedAt?: string;
            message: string;
        }>>;
    };
    cohortPreferences: {
        /**
         * Get current user's cohort preferences
         */
        get: () => Promise<DataResponse<{
            gender?: string;
            ageBand?: string;
            adaptiveCategory?: string;
            leaderboardOptIn: boolean;
            showGenderInLeaderboard: boolean;
            showAgeInLeaderboard: boolean;
        }>>;
        /**
         * Update cohort preferences
         */
        update: (updates: {
            gender?: string;
            ageBand?: string;
            adaptiveCategory?: string;
            showGenderInLeaderboard?: boolean;
            showAgeInLeaderboard?: boolean;
        }) => Promise<DataResponse<{
            gender?: string;
            ageBand?: string;
            adaptiveCategory?: string;
            leaderboardOptIn: boolean;
            showGenderInLeaderboard: boolean;
            showAgeInLeaderboard: boolean;
        }>>;
        /**
         * Opt into exercise leaderboards
         */
        optIn: () => Promise<DataResponse<{
            leaderboardOptIn: boolean;
            message: string;
        }>>;
        /**
         * Opt out of exercise leaderboards
         */
        optOut: () => Promise<DataResponse<{
            leaderboardOptIn: boolean;
            message: string;
        }>>;
        /**
         * Get available cohort options
         */
        options: () => Promise<DataResponse<{
            genderOptions: string[];
            ageBandOptions: string[];
            adaptiveCategoryOptions: string[];
        }>>;
    };
    checkins: {
        /**
         * Check in to a hangout
         */
        checkIn: (hangoutId: number, options?: {
            latitude?: number;
            longitude?: number;
        }) => Promise<DataResponse<{
            id: string;
            checkInTime: string;
            message: string;
        }>>;
        /**
         * Check out from a hangout
         */
        checkOut: (hangoutId: number, options?: {
            workoutId?: string;
        }) => Promise<DataResponse<{
            checkOutTime: string;
            duration: number;
            message: string;
        }>>;
        /**
         * Get active check-ins at a hangout
         */
        activeAt: (hangoutId: number) => Promise<DataResponse<{
            id: string;
            userId: string;
            username: string;
            avatarUrl?: string;
            checkInTime: string;
        }[]>>;
        /**
         * Get current user's active check-in
         */
        myActive: () => Promise<DataResponse<{
            id: string;
            hangoutId: number;
            hangoutName: string;
            checkInTime: string;
        } | null>>;
        /**
         * Get current user's check-in history
         */
        myHistory: (options?: {
            limit?: number;
            offset?: number;
        }) => Promise<DataResponse<{
            id: string;
            hangoutId: number;
            hangoutName: string;
            checkInTime: string;
            checkOutTime?: string;
            duration?: number;
            workoutId?: string;
        }[]>>;
    };
    /**
     * Generic GET request helper
     */
    get: <T = unknown>(path: string) => Promise<T>;
    /**
     * Generic POST request helper
     */
    post: <T = unknown>(path: string, body?: Record<string, unknown>) => Promise<T>;
    /**
     * Generic PUT request helper
     */
    put: <T = unknown>(path: string, body?: Record<string, unknown>) => Promise<T>;
    /**
     * Generic PATCH request helper
     */
    patch: <T = unknown>(path: string, body?: Record<string, unknown>) => Promise<T>;
    /**
     * Generic DELETE request helper
     */
    delete: <T = unknown>(path: string) => Promise<T>;
    social: {
        follow: (userId: string) => Promise<{
            success: boolean;
        }>;
        unfollow: (userId: string) => Promise<{
            success: boolean;
        }>;
        getFollowers: (userId: string, limit?: number, offset?: number) => Promise<{
            success: boolean;
            data: {
                followers: unknown[];
                total: number;
            };
        }>;
        getFollowing: (userId: string, limit?: number, offset?: number) => Promise<{
            success: boolean;
            data: {
                following: unknown[];
                total: number;
            };
        }>;
        isFollowing: (userId: string) => Promise<{
            success: boolean;
            data: {
                isFollowing: boolean;
            };
        }>;
        sendFriendRequest: (userId: string, context?: {
            hangoutId?: number;
            communityId?: number;
        }) => Promise<{
            success: boolean;
            data: unknown;
        }>;
        acceptFriendRequest: (friendshipId: string) => Promise<{
            success: boolean;
        }>;
        declineFriendRequest: (friendshipId: string) => Promise<{
            success: boolean;
        }>;
        getPendingFriendRequests: () => Promise<{
            success: boolean;
            data: unknown[];
        }>;
        getFriends: (limit?: number, offset?: number) => Promise<{
            success: boolean;
            data: {
                friends: unknown[];
                total: number;
            };
        }>;
        removeFriend: (friendId: string) => Promise<{
            success: boolean;
        }>;
        blockUser: (userId: string) => Promise<{
            success: boolean;
        }>;
        getBuddyPreferences: () => Promise<{
            success: boolean;
            data: unknown;
        }>;
        updateBuddyPreferences: (prefs: Record<string, unknown>) => Promise<{
            success: boolean;
            data: unknown;
        }>;
        findBuddyMatches: (limit?: number) => Promise<{
            success: boolean;
            data: unknown[];
        }>;
        sendBuddyRequest: (userId: string, message?: string) => Promise<{
            success: boolean;
            data: unknown;
        }>;
        getPendingBuddyRequests: () => Promise<{
            success: boolean;
            data: unknown[];
        }>;
        acceptBuddyRequest: (requestId: string) => Promise<{
            success: boolean;
            data: unknown;
        }>;
        declineBuddyRequest: (requestId: string) => Promise<{
            success: boolean;
        }>;
        getBuddyPairs: () => Promise<{
            success: boolean;
            data: unknown[];
        }>;
    };
    mentorship: {
        searchMentors: (options?: {
            specialties?: string[];
            minRating?: number;
            isPro?: boolean;
            maxHourlyRate?: number;
            limit?: number;
            offset?: number;
        }) => Promise<{
            success: boolean;
            data: {
                mentors: unknown[];
                total: number;
            };
        }>;
        getMentor: (userId: string) => Promise<{
            success: boolean;
            data: unknown;
        }>;
        updateMentorProfile: (profile: Record<string, unknown>) => Promise<{
            success: boolean;
            data: unknown;
        }>;
        requestMentorship: (mentorId: string, options?: {
            focusAreas?: string[];
            goals?: string;
        }) => Promise<{
            success: boolean;
            data: unknown;
        }>;
        getPendingRequests: () => Promise<{
            success: boolean;
            data: unknown[];
        }>;
        acceptMentorship: (mentorshipId: string) => Promise<{
            success: boolean;
            data: unknown;
        }>;
        declineMentorship: (mentorshipId: string) => Promise<{
            success: boolean;
        }>;
        getActiveMentorships: () => Promise<{
            success: boolean;
            data: unknown[];
        }>;
        getMentorshipHistory: (limit?: number, offset?: number) => Promise<{
            success: boolean;
            data: {
                mentorships: unknown[];
                total: number;
            };
        }>;
        completeMentorship: (mentorshipId: string, feedback: {
            rating: number;
            comment?: string;
        }) => Promise<{
            success: boolean;
        }>;
        cancelMentorship: (mentorshipId: string) => Promise<{
            success: boolean;
        }>;
        createCheckIn: (mentorshipId: string, checkIn: Record<string, unknown>) => Promise<{
            success: boolean;
            data: unknown;
        }>;
        getCheckIns: (mentorshipId: string, limit?: number, offset?: number) => Promise<{
            success: boolean;
            data: {
                checkIns: unknown[];
                total: number;
            };
        }>;
        completeCheckIn: (checkInId: string) => Promise<{
            success: boolean;
        }>;
    };
    communityAnalytics: {
        getDailyAnalytics: (communityId: number, options?: {
            startDate?: string;
            endDate?: string;
            limit?: number;
        }) => Promise<{
            success: boolean;
            data: unknown[];
        }>;
        refreshAnalytics: (communityId: number) => Promise<{
            success: boolean;
            data: unknown;
        }>;
        getHealthScore: (communityId: number) => Promise<{
            success: boolean;
            data: unknown;
        }>;
        calculateHealthScore: (communityId: number) => Promise<{
            success: boolean;
            data: unknown;
        }>;
        getHealthHistory: (communityId: number, limit?: number) => Promise<{
            success: boolean;
            data: unknown[];
        }>;
        getGrowthTrends: (communityId: number, period?: "daily" | "weekly" | "monthly", limit?: number) => Promise<{
            success: boolean;
            data: unknown[];
        }>;
        getEngagementBreakdown: (communityId: number, options?: {
            startDate?: string;
            endDate?: string;
        }) => Promise<{
            success: boolean;
            data: unknown;
        }>;
        getTopContributors: (communityId: number, days?: number, limit?: number) => Promise<{
            success: boolean;
            data: unknown[];
        }>;
        compareCommunities: (communityIds: number[]) => Promise<{
            success: boolean;
            data: unknown[];
        }>;
    };
    communityResources: {
        getResources: (communityId: number, options?: {
            resourceType?: string;
            category?: string;
            tags?: string[];
            isPinned?: boolean;
            searchQuery?: string;
            limit?: number;
            offset?: number;
            sortBy?: "newest" | "most_helpful" | "most_viewed";
        }) => Promise<{
            success: boolean;
            data: {
                resources: unknown[];
                total: number;
            };
        }>;
        getPinnedResources: (communityId: number) => Promise<{
            success: boolean;
            data: unknown[];
        }>;
        getCategories: (communityId: number) => Promise<{
            success: boolean;
            data: unknown[];
        }>;
        getResource: (resourceId: string) => Promise<{
            success: boolean;
            data: unknown;
        }>;
        createResource: (communityId: number, resource: Record<string, unknown>) => Promise<{
            success: boolean;
            data: unknown;
        }>;
        updateResource: (resourceId: string, updates: Record<string, unknown>) => Promise<{
            success: boolean;
        }>;
        deleteResource: (resourceId: string) => Promise<{
            success: boolean;
        }>;
        pinResource: (resourceId: string) => Promise<{
            success: boolean;
        }>;
        unpinResource: (resourceId: string) => Promise<{
            success: boolean;
        }>;
        markHelpful: (resourceId: string) => Promise<{
            success: boolean;
        }>;
        removeHelpful: (resourceId: string) => Promise<{
            success: boolean;
        }>;
        getMostHelpful: (options?: {
            limit?: number;
            communityIds?: number[];
        }) => Promise<{
            success: boolean;
            data: unknown[];
        }>;
    };
    reports: {
        submit: (report: {
            contentType: "post" | "comment" | "message" | "user" | "resource" | "event" | "hangout";
            contentId: string;
            reportedUserId: string;
            communityId?: number;
            reason: string;
            description?: string;
        }) => Promise<{
            success: boolean;
            data: unknown;
        }>;
        getMyReports: () => Promise<{
            success: boolean;
            data: unknown[];
        }>;
        getPendingReports: (options?: {
            communityId?: number;
            status?: string | string[];
            reason?: string;
            limit?: number;
            offset?: number;
        }) => Promise<{
            success: boolean;
            data: {
                reports: unknown[];
                total: number;
            };
        }>;
        getReport: (reportId: string) => Promise<{
            success: boolean;
            data: unknown;
        }>;
        assignReport: (reportId: string) => Promise<{
            success: boolean;
        }>;
        resolveReport: (reportId: string, resolution: {
            status: "resolved" | "dismissed";
            resolution: string;
            actionTaken: string;
        }) => Promise<{
            success: boolean;
        }>;
        getStats: (communityId?: number) => Promise<{
            success: boolean;
            data: unknown;
        }>;
        getUserModerationHistory: (userId: string) => Promise<{
            success: boolean;
            data: unknown[];
        }>;
        getUserModerationStatus: (userId: string) => Promise<{
            success: boolean;
            data: unknown | null;
        }>;
        applyModerationAction: (userId: string, action: {
            action: string;
            reason: string;
            durationHours?: number;
            notes?: string;
        }) => Promise<{
            success: boolean;
            data: unknown;
        }>;
    };
    archetypeCommunities: {
        getSuggestedCommunities: () => Promise<{
            success: boolean;
            data: unknown[];
        }>;
        handleArchetypeChange: (newArchetypeId: string, options?: {
            oldArchetypeId?: string;
            leaveOldCommunities?: boolean;
        }) => Promise<{
            success: boolean;
            data: {
                joined: number[];
                left: number[];
            };
        }>;
        getLinkedCommunities: (archetypeId: string) => Promise<{
            success: boolean;
            data: unknown[];
        }>;
        getDefaultCommunities: (archetypeId: string) => Promise<{
            success: boolean;
            data: unknown[];
        }>;
        linkCommunity: (archetypeId: string, communityId: number, options?: {
            isDefault?: boolean;
            priority?: number;
        }) => Promise<{
            success: boolean;
            data: unknown;
        }>;
        bulkLinkCommunities: (archetypeId: string, links: Array<{
            communityId: number;
            isDefault?: boolean;
            priority?: number;
        }>) => Promise<{
            success: boolean;
            data: {
                linked: number;
            };
        }>;
        unlinkCommunity: (archetypeId: string, communityId: number) => Promise<{
            success: boolean;
        }>;
        getAllArchetypesWithCommunities: () => Promise<{
            success: boolean;
            data: unknown[];
        }>;
    };
    skills: {
        /** Get all skill trees */
        getTrees: () => Promise<{
            trees: SkillTree[];
        }>;
        /** Get a specific skill tree with all nodes */
        getTree: (treeId: string) => Promise<{
            tree: SkillTreeWithNodes;
        }>;
        /** Get user's progress for a skill tree */
        getTreeProgress: (treeId: string) => Promise<{
            nodes: SkillNodeWithProgress[];
        }>;
        /** Get a specific skill node */
        getNode: (nodeId: string) => Promise<{
            node: SkillNode;
        }>;
        /** Get leaderboard for a skill */
        getNodeLeaderboard: (nodeId: string, limit?: number) => Promise<{
            leaderboard: SkillLeaderboardEntry[];
        }>;
        /** Get user's overall skill progress summary */
        getProgress: () => Promise<SkillProgressSummary>;
        /** Log a practice session */
        logPractice: (data: {
            skillNodeId: string;
            durationMinutes: number;
            valueAchieved?: number;
            notes?: string;
        }) => Promise<{
            practiceLog: SkillPracticeLog;
        }>;
        /** Mark a skill as achieved */
        achieveSkill: (data: {
            skillNodeId: string;
            verificationVideoUrl?: string;
        }) => Promise<{
            success: boolean;
            creditsAwarded?: number;
            xpAwarded?: number;
            error?: string;
        }>;
        /** Get practice history */
        getHistory: (options?: {
            limit?: number;
            offset?: number;
            skillNodeId?: string;
        }) => Promise<{
            logs: SkillPracticeLogWithName[];
            total: number;
        }>;
        /** Update notes for a skill */
        updateNotes: (nodeId: string, notes: string) => Promise<{
            success: boolean;
        }>;
    };
    ranks: {
        /** Get all rank definitions */
        definitions: () => Promise<DataResponse<RankDefinitionResponse[]>>;
        /** Get current user's rank info */
        me: () => Promise<DataResponse<UserRankResponse>>;
        /** Get another user's rank info */
        getUser: (userId: string) => Promise<DataResponse<UserRankResponse>>;
        /** Get XP history */
        history: (options?: {
            limit?: number;
            offset?: number;
            sourceType?: string;
        }) => Promise<DataResponse<XpHistoryEntryResponse[]> & {
            pagination: PaginationMeta;
        }>;
        /** Get XP-based leaderboard */
        leaderboard: (options?: {
            scope?: "global" | "country" | "state" | "city";
            country?: string;
            state?: string;
            city?: string;
            limit?: number;
            offset?: number;
        }) => Promise<RankLeaderboardResponse>;
        /** Get veteran badge info */
        veteranBadge: () => Promise<DataResponse<VeteranBadgeResponse>>;
    };
    feedback: {
        /** Create new feedback (bug report, feature request, question, general) */
        create: (payload: {
            type: "bug_report" | "feature_request" | "question" | "general";
            title: string;
            description: string;
            priority?: "low" | "medium" | "high" | "critical";
            stepsToReproduce?: string;
            expectedBehavior?: string;
            actualBehavior?: string;
            category?: string;
            attachments?: string[];
            metadata?: Record<string, unknown>;
            userAgent?: string;
            screenSize?: string;
            appVersion?: string;
            platform?: string;
        }) => Promise<DataResponse<{
            id: string;
            message: string;
        }>>;
        /** List user's own feedback */
        list: (options?: {
            type?: "bug_report" | "feature_request" | "question" | "general";
            status?: "open" | "in_progress" | "resolved" | "closed" | "wont_fix";
            limit?: number;
            cursor?: string;
        }) => Promise<DataResponse<FeedbackItem[]> & {
            meta: {
                hasMore: boolean;
                nextCursor: string | null;
            };
        }>;
        /** Get single feedback with responses */
        get: (id: string) => Promise<DataResponse<FeedbackItem & {
            responses: FeedbackResponse[];
        }>>;
        /** Add response to own feedback (follow-up) */
        respond: (id: string, message: string) => Promise<DataResponse<{
            id: string;
            message: string;
        }>>;
        /** Get popular feature requests */
        popularFeatures: (limit?: number) => Promise<DataResponse<(FeedbackItem & {
            userVoted: boolean;
        })[]>>;
        /** Upvote a feature request */
        upvote: (id: string) => Promise<DataResponse<{
            upvoted: boolean;
        }>>;
        /** Remove upvote from a feature request */
        removeUpvote: (id: string) => Promise<DataResponse<{
            upvoted: boolean;
        }>>;
        /** Get FAQ entries */
        getFaq: (options?: {
            category?: string;
            search?: string;
        }) => Promise<{
            data: Record<string, FAQEntry[]>;
            categories: string[];
        }>;
        /** Get FAQ categories */
        faqCategories: () => Promise<DataResponse<{
            name: string;
            label: string;
            count: number;
        }[]>>;
        /** Get single FAQ entry (increments view count) */
        getFaqEntry: (id: string) => Promise<DataResponse<FAQEntry>>;
        /** Mark FAQ as helpful or not helpful */
        markFaqHelpful: (id: string, helpful: boolean) => Promise<DataResponse<{
            recorded: boolean;
        }>>;
        /** Search FAQ and feature requests */
        search: (query: string) => Promise<DataResponse<{
            faq: FAQEntry[];
            features: FeedbackItem[];
        }>>;
    };
};
interface VirtualHangoutTheme {
    id: string;
    name: string;
    tagline?: string;
    description?: string;
    primaryColor: string;
    secondaryColor: string;
    accentColor: string;
    backgroundImageUrl?: string;
    iconUrl?: string;
    bannerUrl?: string;
    archetypeCategoryId?: string;
    goalTypes: string[];
    targetAudiences: string[];
    isActive: boolean;
}
interface VirtualHangout {
    id: number;
    themeId: string;
    themeName: string;
    customName?: string;
    customDescription?: string;
    customBannerUrl?: string;
    primaryColor: string;
    accentColor: string;
    memberCount: number;
    activeMemberCount: number;
    postCount: number;
    isActive: boolean;
    createdAt: string;
    updatedAt: string;
    isMember?: boolean;
    userRole?: number;
    lastVisitedAt?: string;
}
interface HangoutMember {
    userId: string;
    username: string;
    displayName?: string;
    avatarUrl?: string;
    role: number;
    joinedAt: string;
    lastActiveAt?: string;
    showInMemberList: boolean;
    receiveNotifications: boolean;
}
interface HangoutActivity {
    id: string;
    hangoutId: number;
    userId?: string;
    username?: string;
    activityType: 'join' | 'leave' | 'post' | 'workout_shared' | 'achievement' | 'milestone';
    activityData: Record<string, unknown>;
    createdAt: string;
}
interface Community {
    id: number;
    slug: string;
    name: string;
    tagline?: string;
    description?: string;
    communityType: 'goal' | 'interest' | 'institution' | 'local' | 'challenge';
    goalType?: string;
    institutionType?: string;
    archetypeId?: number;
    privacy: 'public' | 'private' | 'secret';
    iconEmoji: string;
    accentColor: string;
    bannerImageUrl?: string;
    logoImageUrl?: string;
    rules?: string;
    memberCount: number;
    postCount: number;
    isVerified: boolean;
    isActive: boolean;
    requiresApproval: boolean;
    allowMemberPosts: boolean;
    createdBy: string;
    createdAt: string;
    updatedAt: string;
    isMember?: boolean;
    userRole?: number;
    membershipStatus?: 'pending' | 'active' | 'suspended' | 'banned';
}
interface CommunityMember {
    userId: string;
    username: string;
    displayName?: string;
    avatarUrl?: string;
    role: number;
    title?: string;
    status: 'pending' | 'active' | 'suspended' | 'banned';
    joinedAt: string;
    lastActiveAt?: string;
    showInMemberList: boolean;
}
interface CommunityEvent {
    id: string;
    communityId: number;
    virtualHangoutId?: number;
    creatorId: string;
    title: string;
    description?: string;
    eventType: 'meetup' | 'challenge' | 'workshop' | 'competition' | 'social';
    startsAt: string;
    endsAt?: string;
    timezone: string;
    locationName?: string;
    locationAddress?: string;
    isVirtual: boolean;
    virtualUrl?: string;
    maxParticipants?: number;
    participantCount: number;
    status: 'draft' | 'scheduled' | 'ongoing' | 'completed' | 'cancelled';
    createdAt: string;
}
interface BulletinPost {
    id: string;
    boardId: number;
    authorId?: string;
    authorUsername?: string;
    authorDisplayName?: string;
    authorAvatarUrl?: string;
    title: string;
    content: string;
    contentLang: string;
    postType: 'discussion' | 'question' | 'announcement' | 'poll' | 'workout_share' | 'milestone';
    mediaUrls: string[];
    linkedWorkoutId?: string;
    linkedMilestoneId?: string;
    upvotes: number;
    downvotes: number;
    score: number;
    commentCount: number;
    viewCount: number;
    isPinned: boolean;
    isHighlighted: boolean;
    isHidden: boolean;
    createdAt: string;
    updatedAt: string;
    userVote?: 'up' | 'down';
}
interface BulletinComment {
    id: string;
    postId: string;
    parentId?: string;
    authorId?: string;
    authorUsername?: string;
    authorDisplayName?: string;
    authorAvatarUrl?: string;
    content: string;
    upvotes: number;
    downvotes: number;
    score: number;
    replyCount: number;
    isHidden: boolean;
    createdAt: string;
    updatedAt: string;
    userVote?: 'up' | 'down';
    replies?: BulletinComment[];
}

interface WebSocketMessage<T = unknown> {
    type: 'snapshot' | 'event' | 'heartbeat';
    data?: T;
}
interface UseWebSocketOptions<TSnapshot = unknown, TEvent = unknown> {
    autoConnect?: boolean;
    onMessage?: (data: TEvent) => void;
    onSnapshot?: (data: TSnapshot) => void;
    token?: string;
    /** Base URL for WebSocket connection (defaults to window.location in browser) */
    baseUrl?: string;
}
interface UseWebSocketResult<TSnapshot = unknown, TEvent = unknown> {
    connected: boolean;
    error: string | null;
    snapshot: TSnapshot | null;
    events: TEvent[];
    connect: () => void;
    disconnect: () => void;
    sendHeartbeat: () => void;
}
declare function useWebSocket<TSnapshot = unknown, TEvent = unknown>(endpoint: string, options?: UseWebSocketOptions<TSnapshot, TEvent>): UseWebSocketResult<TSnapshot, TEvent>;

interface AuthState {
    user: User | null;
    token: string | null;
    isAuthenticated: boolean;
    isLoading: boolean;
}
interface UseAuthOptions {
    onLogout?: () => void | Promise<void>;
}
interface UseAuthResult extends AuthState {
    login: (response: AuthResponse) => Promise<void>;
    logout: () => Promise<void>;
    updateUser: (updates: Partial<User>) => Promise<void>;
    refreshFromStorage: () => Promise<void>;
}
/**
 * Hook for managing authentication state
 */
declare function useAuth(options?: UseAuthOptions): UseAuthResult;
/**
 * Standalone auth functions for use outside React components
 */
declare const auth: {
    getToken: () => Promise<string | null>;
    getUser: () => Promise<User | null>;
    setAuth: (token: string, user: User) => Promise<void>;
    clearAuth: () => Promise<void>;
    isAuthenticated: () => Promise<boolean>;
};

export { type ActivitySample, type AnySchema, type AnyValidationSchema, type Archetype, type ArchetypeLevel, type ArchetypeProgress, type ArchetypeWithLevels, type ArraySchema, type AuthResponse, type AuthState, type BillingCheckoutResponse, type BodyMeasurementSample, type BooleanSchema, type BulletinComment, type BulletinPost, type CharacterStats, type Community, type CommunityEvent, type CommunityMember, type ConflictResolutionStrategy, type Crew, type CrewLeaderboardEntry, type CrewMember, type CrewRole, type CrewStats, type CrewWar, type CrewWarStatus, type Encouragement, type Exercise, type ExerciseActivation, type ExerciseWithActivations, type ExtendedProfile, type ExternalSchema, type FoundingMemberStatus, type HangoutActivity, type HangoutMember, type HealthSummary, type HealthSyncPayload, type HealthSyncResult, type HealthSyncStatus, type HeartRateSample, type HighFiveFeed, type HighFiveStats, type HighFiveUser, type HttpClientConfig, type JourneyData, type JourneyMuscleBreakdown, type JourneyPath, type JourneyStats, type LeaderboardEntry, type Muscle, type MuscleActivation, type MyCrewData, type NullSchema, type NumberSchema, type ObjectSchema, type PrivacySettings, type PrivacySummary, type Profile, type RequestOptions, type Rival, type RivalOpponent, type RivalSearchResult, type RivalStats, type RivalStatus, type Schema, type Settings, type SettingsResponse, type SleepSample, type StatInfo, type StatRanking, type StatRankingsByScope, type Stats, type StatsHistoryEntry, type StatsWithRankings, type StringSchema, type Subscription, type SyncConflict, type SyncOptions, type Transaction, type TransactionsResponse, Type, type UnionSchema, type UseAuthOptions, type UseAuthResult, type UseWebSocketOptions, type UseWebSocketResult, type User, type VirtualHangout, type VirtualHangoutTheme, type Wallet, type WearableConnection, type WearableProvider, type WebSocketMessage, type Workout, type WorkoutExercise, type WorkoutPreview, type WorkoutSample, type WorkoutStats, apiClient, apiHelpers, applySchema, auth, clearRequestCache, configureHttpClient, isValidationSchema, parseWithSchema, request, useAuth, useWebSocket };
