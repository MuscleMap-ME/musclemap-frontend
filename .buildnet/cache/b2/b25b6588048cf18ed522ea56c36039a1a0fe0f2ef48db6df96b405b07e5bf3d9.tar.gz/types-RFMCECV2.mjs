import {
  STORAGE_KEYS,
  getStorageAdapter,
  hasStorageAdapter,
  setStorageAdapter
} from "./chunk-TDLC3OOX.mjs";
export {
  STORAGE_KEYS,
  getStorageAdapter,
  hasStorageAdapter,
  setStorageAdapter
};
//# sourceMappingURL=types-RFMCECV2.mjs.map