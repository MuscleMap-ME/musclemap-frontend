// src/storage/types.ts
var STORAGE_KEYS = {
  TOKEN: "musclemap_token",
  USER: "musclemap_user"
};
var globalStorage = null;
function setStorageAdapter(adapter) {
  globalStorage = adapter;
}
function getStorageAdapter() {
  if (!globalStorage) {
    throw new Error(
      "Storage adapter not initialized. Call setStorageAdapter() before using auth/http modules."
    );
  }
  return globalStorage;
}
function hasStorageAdapter() {
  return globalStorage !== null;
}

export {
  STORAGE_KEYS,
  setStorageAdapter,
  getStorageAdapter,
  hasStorageAdapter
};
//# sourceMappingURL=chunk-TDLC3OOX.mjs.map