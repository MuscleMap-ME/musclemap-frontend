/**
 * Storage Adapter Interface
 *
 * Platform-agnostic storage abstraction that can be implemented
 * by localStorage (web) or expo-secure-store (native).
 */
interface StorageAdapter {
    getItem(key: string): Promise<string | null>;
    setItem(key: string, value: string): Promise<void>;
    removeItem(key: string): Promise<void>;
    clear(): Promise<void>;
}
/**
 * Storage keys used throughout the application
 */
declare const STORAGE_KEYS: {
    readonly TOKEN: "musclemap_token";
    readonly USER: "musclemap_user";
};
type StorageKey = (typeof STORAGE_KEYS)[keyof typeof STORAGE_KEYS];
declare function setStorageAdapter(adapter: StorageAdapter): void;
declare function getStorageAdapter(): StorageAdapter;
/**
 * Check if storage adapter has been initialized
 */
declare function hasStorageAdapter(): boolean;

export { type StorageAdapter as S, STORAGE_KEYS as a, type StorageKey as b, getStorageAdapter as g, hasStorageAdapter as h, setStorageAdapter as s };
