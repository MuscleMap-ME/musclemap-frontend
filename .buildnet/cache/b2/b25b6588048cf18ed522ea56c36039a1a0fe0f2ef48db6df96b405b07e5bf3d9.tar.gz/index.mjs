import {
  STORAGE_KEYS,
  getStorageAdapter,
  hasStorageAdapter,
  setStorageAdapter
} from "./chunk-TDLC3OOX.mjs";

// src/http/schema.ts
var RESPONSE_VALIDATION_ERROR = "Response validation failed";
function withDefault(schema, value) {
  if ((value === void 0 || value === null) && "default" in schema) {
    return schema.default;
  }
  return value;
}
function validateType(schema, value) {
  const normalized = withDefault(schema, value);
  if (normalized === void 0 || normalized === null) {
    if (schema.optional) return normalized;
    if ("default" in schema) return schema.default;
  }
  switch (schema.kind) {
    case "string":
      if (typeof normalized === "string") return normalized;
      break;
    case "number":
      if (typeof normalized === "number" && Number.isFinite(normalized)) return normalized;
      break;
    case "boolean":
      if (typeof normalized === "boolean") return normalized;
      break;
    case "null":
      if (normalized === null) return normalized;
      break;
    case "any":
      return normalized;
    case "union": {
      for (const option of schema.anyOf) {
        try {
          return validateType(option, normalized);
        } catch {
        }
      }
      break;
    }
    case "array": {
      const target = normalized ?? schema.default;
      if (Array.isArray(target)) {
        return target.map((item) => validateType(schema.items, item));
      }
      break;
    }
    case "object": {
      const source = normalized ?? schema.default;
      if (source && typeof source === "object" && !Array.isArray(source)) {
        const entries = Object.entries(schema.properties ?? {});
        const result = {};
        for (const [key, propSchema] of entries) {
          if (!(key in source)) {
            if ("default" in propSchema) {
              result[key] = propSchema.default;
            } else if (!propSchema.optional) {
              throw new Error(RESPONSE_VALIDATION_ERROR);
            }
            continue;
          }
          result[key] = validateType(propSchema, source[key]);
        }
        if (schema.additionalProperties !== false) {
          for (const [key, val] of Object.entries(source)) {
            if (!schema.properties || !(key in schema.properties)) {
              result[key] = val;
            }
          }
        }
        return result;
      }
      break;
    }
    case "record": {
      const source = normalized ?? schema.default;
      if (source && typeof source === "object" && !Array.isArray(source)) {
        const result = {};
        for (const [key, val] of Object.entries(source)) {
          validateType(schema.keySchema, key);
          result[key] = validateType(schema.valueSchema, val);
        }
        return result;
      }
      break;
    }
    default:
      return normalized;
  }
  throw new Error(RESPONSE_VALIDATION_ERROR);
}
function createType(kind, options = {}) {
  return { kind, ...options };
}
var Type = {
  String: (options = {}) => createType("string", options),
  Number: (options = {}) => createType("number", options),
  Boolean: (options = {}) => createType("boolean", options),
  Null: () => createType("null", {}),
  Any: () => createType("any", {}),
  Optional: (schema) => ({
    ...schema,
    optional: true
  }),
  Union: (schemas) => createType("union", { anyOf: schemas }),
  Array: (itemSchema, options = {}) => createType("array", { items: itemSchema, default: options.default }),
  Object: (properties, options = {}) => createType("object", {
    properties,
    default: options.default,
    additionalProperties: options.additionalProperties ?? true
  }),
  Record: (keySchema, valueSchema, options = {}) => createType("record", {
    keySchema,
    valueSchema,
    default: options.default
  })
};
function isValidationSchema(schema) {
  return Boolean(schema && typeof schema === "object" && "kind" in schema);
}
function parseWithSchema(schema, data) {
  return validateType(schema, data);
}
function applySchema(schema, data) {
  if (!schema) return data;
  if ("parse" in schema && typeof schema.parse === "function") {
    return schema.parse(data);
  }
  if ("safeParse" in schema && typeof schema.safeParse === "function") {
    const result = schema.safeParse(data);
    if (result.success) return result.data;
    throw new Error(RESPONSE_VALIDATION_ERROR);
  }
  if (isValidationSchema(schema)) {
    return parseWithSchema(schema, data);
  }
  return data;
}

// src/http/client.ts
var DEFAULT_API_BASE = "/api";
var DEFAULT_RETRY_DELAY = 200;
var DEFAULT_RETRIES = 2;
var DEFAULT_CACHE_TTL = 3e4;
var cache = /* @__PURE__ */ new Map();
var sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
async function safeJson(response) {
  try {
    const text = await response.text();
    return text ? JSON.parse(text) : null;
  } catch {
    return null;
  }
}
function buildCacheKey(url, method, body) {
  return `${method.toUpperCase()}:${url}:${body ? JSON.stringify(body) : ""}`;
}
function clearRequestCache() {
  cache.clear();
}
var clientConfig = {};
function configureHttpClient(config) {
  clientConfig = { ...clientConfig, ...config };
}
async function getToken() {
  try {
    const storage = getStorageAdapter();
    return await storage.getItem(STORAGE_KEYS.TOKEN);
  } catch {
    return null;
  }
}
async function clearAuth() {
  try {
    const storage = getStorageAdapter();
    await Promise.all([
      storage.removeItem(STORAGE_KEYS.TOKEN),
      storage.removeItem(STORAGE_KEYS.USER)
    ]);
  } catch {
  }
}
async function request(path, options = {}) {
  const {
    method = "GET",
    body,
    headers = {},
    schema,
    auth: auth2 = true,
    retries = DEFAULT_RETRIES,
    retryDelay = DEFAULT_RETRY_DELAY,
    cacheTtl,
    cacheKey: customCacheKey,
    baseUrl,
    onUnauthorized
  } = options;
  const base = baseUrl ?? clientConfig.baseUrl ?? DEFAULT_API_BASE;
  const url = path.startsWith("http") ? path : `${base}${path}`;
  const normalizedMethod = method.toUpperCase();
  const shouldCache = cacheTtl === void 0 ? normalizedMethod === "GET" : cacheTtl > 0;
  const ttl = cacheTtl === void 0 ? normalizedMethod === "GET" ? DEFAULT_CACHE_TTL : 0 : cacheTtl;
  const key = customCacheKey || buildCacheKey(url, normalizedMethod, body);
  if (shouldCache && cache.has(key)) {
    const entry = cache.get(key);
    if (entry.expires > Date.now()) {
      return entry.data;
    }
    cache.delete(key);
  }
  let attempt = 0;
  let lastError = null;
  while (attempt <= retries) {
    try {
      const isFormData = typeof FormData !== "undefined" && body instanceof FormData;
      const requestHeaders = {
        ...clientConfig.defaultHeaders,
        // Don't set Content-Type for FormData - browser will set it with boundary
        ...body && !isFormData ? { "Content-Type": "application/json" } : {},
        ...headers
      };
      if (auth2) {
        const token = await getToken();
        if (token) {
          requestHeaders["Authorization"] = `Bearer ${token}`;
        }
      }
      const response = await fetch(url, {
        method: normalizedMethod,
        headers: requestHeaders,
        body: body ? isFormData ? body : JSON.stringify(body) : void 0
      });
      if (response.status === 401 && auth2) {
        await clearAuth();
        const handler = onUnauthorized ?? clientConfig.onUnauthorized;
        if (handler) {
          await handler();
        }
        throw new Error("Unauthorized");
      }
      if (response.status >= 500 && attempt < retries) {
        attempt++;
        await sleep(retryDelay * attempt);
        continue;
      }
      if (!response.ok) {
        const errorBody = await safeJson(response);
        let errorMessage = `Request failed with status ${response.status}`;
        if (errorBody) {
          if (typeof errorBody.error === "object" && errorBody.error?.message) {
            errorMessage = errorBody.error.message;
          } else if (typeof errorBody.error === "string") {
            errorMessage = errorBody.error;
          } else if (errorBody.message) {
            errorMessage = errorBody.message;
          }
        }
        throw new Error(errorMessage);
      }
      const data = await safeJson(response);
      const parsed = applySchema(schema, data);
      if (shouldCache && ttl > 0) {
        cache.set(key, { data: parsed, expires: Date.now() + ttl });
      }
      return parsed;
    } catch (err) {
      lastError = err instanceof Error ? err : new Error(String(err));
      if (attempt >= retries) break;
      attempt++;
      await sleep(retryDelay * attempt);
    }
  }
  throw lastError || new Error("Request failed");
}
var apiHelpers = {
  withSchema: (schema) => ({ schema })
};

// src/api/index.ts
var ExerciseSchema = Type.Object(
  {
    id: Type.String(),
    name: Type.String(),
    type: Type.String(),
    difficulty: Type.Number(),
    description: Type.Union([Type.String(), Type.Null()]),
    cues: Type.Union([Type.String(), Type.Null()]),
    primaryMuscles: Type.Array(Type.String(), { default: [] })
  },
  { additionalProperties: true }
);
var ExerciseWithActivationsSchema = Type.Object(
  {
    id: Type.String(),
    name: Type.String(),
    type: Type.String(),
    difficulty: Type.Number(),
    description: Type.Union([Type.String(), Type.Null()]),
    cues: Type.Union([Type.String(), Type.Null()]),
    primaryMuscles: Type.Array(Type.String(), { default: [] }),
    activations: Type.Array(
      Type.Object({
        muscleId: Type.String(),
        muscleName: Type.String(),
        activation: Type.Number()
      }),
      { default: [] }
    )
  },
  { additionalProperties: true }
);
var MuscleSchema = Type.Object(
  {
    id: Type.String(),
    name: Type.String(),
    anatomicalName: Type.Union([Type.String(), Type.Null()]),
    muscleGroup: Type.String(),
    biasWeight: Type.Number(),
    optimalWeeklyVolume: Type.Union([Type.Number(), Type.Null()]),
    recoveryTime: Type.Union([Type.Number(), Type.Null()])
  },
  { additionalProperties: true }
);
var MuscleActivationSchema = Type.Object(
  {
    muscleId: Type.String(),
    muscleName: Type.String(),
    muscleGroup: Type.String(),
    rawActivation: Type.Number(),
    biasWeight: Type.Number(),
    normalizedActivation: Type.Number(),
    colorTier: Type.Number()
  },
  { additionalProperties: true }
);
var WorkoutExerciseSchema = Type.Object(
  {
    exerciseId: Type.String(),
    sets: Type.Number(),
    reps: Type.Optional(Type.Number()),
    weight: Type.Optional(Type.Number()),
    duration: Type.Optional(Type.Number()),
    notes: Type.Optional(Type.String())
  },
  { additionalProperties: true }
);
var WorkoutSchema = Type.Object(
  {
    id: Type.String(),
    userId: Type.String(),
    date: Type.String(),
    totalTU: Type.Number(),
    creditsUsed: Type.Number(),
    notes: Type.Union([Type.String(), Type.Null()]),
    isPublic: Type.Boolean(),
    exerciseData: Type.Array(WorkoutExerciseSchema, { default: [] }),
    muscleActivations: Type.Record(Type.String(), Type.Number(), { default: {} }),
    createdAt: Type.String()
  },
  { additionalProperties: true }
);
var WorkoutStatsSchema = Type.Object(
  {
    allTime: Type.Object({ workoutCount: Type.Number(), totalTU: Type.Number() }),
    thisWeek: Type.Object({ workoutCount: Type.Number(), totalTU: Type.Number() }),
    thisMonth: Type.Object({ workoutCount: Type.Number(), totalTU: Type.Number() })
  },
  { additionalProperties: true }
);
var WorkoutPreviewSchema = Type.Object(
  {
    totalTU: Type.Number(),
    activations: Type.Array(MuscleActivationSchema, { default: [] })
  },
  { additionalProperties: true }
);
var ArchetypeSchema = Type.Object(
  {
    id: Type.String(),
    name: Type.String(),
    philosophy: Type.Union([Type.String(), Type.Null()]),
    description: Type.Union([Type.String(), Type.Null()]),
    focusAreas: Type.Array(Type.String(), { default: [] }),
    iconUrl: Type.Union([Type.String(), Type.Null()])
  },
  { additionalProperties: true }
);
var ArchetypeLevelSchema = Type.Object(
  {
    id: Type.Optional(Type.Number()),
    archetypeId: Type.Optional(Type.String()),
    level: Type.Number(),
    name: Type.String(),
    totalTU: Type.Optional(Type.Number()),
    total_tu: Type.Optional(Type.Number()),
    description: Type.Union([Type.String(), Type.Null()]),
    muscleTargets: Type.Optional(Type.Record(Type.String(), Type.Number()))
  },
  { additionalProperties: true }
);
var ArchetypeWithLevelsSchema = Type.Object(
  {
    id: Type.String(),
    name: Type.String(),
    philosophy: Type.Union([Type.String(), Type.Null()]),
    description: Type.Union([Type.String(), Type.Null()]),
    focusAreas: Type.Array(Type.String(), { default: [] }),
    iconUrl: Type.Union([Type.String(), Type.Null()]),
    levels: Type.Array(ArchetypeLevelSchema, { default: [] })
  },
  { additionalProperties: true }
);
var ArchetypeProgressSchema = Type.Object(
  {
    archetypeId: Type.String(),
    archetypeName: Type.String(),
    currentLevel: Type.Number(),
    currentLevelName: Type.String(),
    currentTU: Type.Number(),
    nextLevelTU: Type.Union([Type.Number(), Type.Null()]),
    progressPercent: Type.Number()
  },
  { additionalProperties: true }
);
var RivalOpponentSchema = Type.Object(
  {
    id: Type.String(),
    username: Type.String(),
    avatar: Type.Optional(Type.Union([Type.String(), Type.Null()])),
    archetype: Type.Optional(Type.Union([Type.String(), Type.Null()])),
    level: Type.Optional(Type.Number())
  },
  { additionalProperties: true }
);
var RivalSchema = Type.Object(
  {
    id: Type.String(),
    challengerId: Type.String(),
    challengedId: Type.String(),
    status: Type.String(),
    createdAt: Type.String(),
    startedAt: Type.Union([Type.String(), Type.Null()]),
    endedAt: Type.Union([Type.String(), Type.Null()]),
    opponent: RivalOpponentSchema,
    isChallenger: Type.Boolean(),
    myTU: Type.Number(),
    opponentTU: Type.Number(),
    myLastWorkout: Type.Union([Type.String(), Type.Null()]),
    opponentLastWorkout: Type.Union([Type.String(), Type.Null()]),
    tuDifference: Type.Number(),
    isWinning: Type.Boolean()
  },
  { additionalProperties: true }
);
var RivalStatsSchema = Type.Object(
  {
    activeRivals: Type.Number(),
    wins: Type.Number(),
    losses: Type.Number(),
    ties: Type.Number(),
    totalTUEarned: Type.Number(),
    currentStreak: Type.Number(),
    longestStreak: Type.Number()
  },
  { additionalProperties: true }
);
var RivalSearchResultSchema = Type.Object(
  {
    id: Type.String(),
    username: Type.String(),
    avatar: Type.Optional(Type.String()),
    archetype: Type.Optional(Type.String())
  },
  { additionalProperties: true }
);
var WearableConnectionSchema = Type.Object(
  {
    id: Type.String(),
    userId: Type.String(),
    provider: Type.String(),
    providerUserId: Type.Optional(Type.String()),
    isActive: Type.Boolean(),
    lastSyncAt: Type.Union([Type.String(), Type.Null()]),
    syncError: Type.Optional(Type.Union([Type.String(), Type.Null()])),
    syncStatus: Type.Optional(Type.String()),
    createdAt: Type.String()
  },
  { additionalProperties: true }
);
var HealthSyncStatusSchema = Type.Object(
  {
    provider: Type.String(),
    lastSyncAt: Type.Union([Type.String(), Type.Null()]),
    syncStatus: Type.String(),
    syncError: Type.Union([Type.String(), Type.Null()])
  },
  { additionalProperties: true }
);
var HealthSummarySchema = Type.Object(
  {
    today: Type.Object({
      steps: Type.Number(),
      activeCalories: Type.Number(),
      avgHeartRate: Type.Union([Type.Number(), Type.Null()]),
      workoutMinutes: Type.Number(),
      sleepHours: Type.Union([Type.Number(), Type.Null()])
    }),
    thisWeek: Type.Object({
      totalSteps: Type.Number(),
      avgDailySteps: Type.Number(),
      totalWorkoutMinutes: Type.Number(),
      avgSleepHours: Type.Union([Type.Number(), Type.Null()]),
      avgRestingHeartRate: Type.Union([Type.Number(), Type.Null()])
    }),
    connections: Type.Array(WearableConnectionSchema, { default: [] }),
    syncStatus: Type.Optional(Type.Array(HealthSyncStatusSchema, { default: [] }))
  },
  { additionalProperties: true }
);
var HealthSyncResultSchema = Type.Object(
  {
    synced: Type.Object({
      heartRate: Type.Number(),
      workouts: Type.Number(),
      activity: Type.Number(),
      sleep: Type.Number(),
      bodyMeasurements: Type.Number()
    }),
    conflicts: Type.Array(Type.Object({
      type: Type.String(),
      localId: Type.Optional(Type.String()),
      remoteId: Type.Optional(Type.String()),
      resolution: Type.String(),
      timestamp: Type.String()
    }), { default: [] }),
    lastSyncAt: Type.String()
  },
  { additionalProperties: true }
);
var WorkoutSampleSchema = Type.Object(
  {
    id: Type.String(),
    type: Type.String(),
    startTime: Type.String(),
    endTime: Type.String(),
    duration: Type.Number(),
    calories: Type.Optional(Type.Number()),
    distance: Type.Optional(Type.Number()),
    avgHeartRate: Type.Optional(Type.Number()),
    maxHeartRate: Type.Optional(Type.Number()),
    minHeartRate: Type.Optional(Type.Number()),
    steps: Type.Optional(Type.Number()),
    elevationGain: Type.Optional(Type.Number()),
    source: Type.String(),
    externalId: Type.Optional(Type.String())
  },
  { additionalProperties: true }
);
var CrewSchema = Type.Object(
  {
    id: Type.String(),
    name: Type.String(),
    tag: Type.String(),
    description: Type.Union([Type.String(), Type.Null()]),
    avatar: Type.Union([Type.String(), Type.Null()]),
    color: Type.String(),
    ownerId: Type.String(),
    memberCount: Type.Number(),
    totalTU: Type.Number(),
    weeklyTU: Type.Number(),
    wins: Type.Number(),
    losses: Type.Number(),
    createdAt: Type.String()
  },
  { additionalProperties: true }
);
var CrewMemberSchema = Type.Object(
  {
    id: Type.String(),
    crewId: Type.String(),
    userId: Type.String(),
    role: Type.String(),
    joinedAt: Type.String(),
    weeklyTU: Type.Number(),
    totalTU: Type.Number(),
    username: Type.String(),
    avatar: Type.Union([Type.String(), Type.Null()]),
    archetype: Type.Union([Type.String(), Type.Null()])
  },
  { additionalProperties: true }
);
var CrewWarSchema = Type.Object(
  {
    id: Type.String(),
    challengerCrewId: Type.String(),
    defendingCrewId: Type.String(),
    status: Type.String(),
    startDate: Type.String(),
    endDate: Type.String(),
    challengerTU: Type.Number(),
    defendingTU: Type.Number(),
    winnerId: Type.Union([Type.String(), Type.Null()]),
    createdAt: Type.String(),
    challengerCrew: Type.Object({
      id: Type.String(),
      name: Type.String(),
      tag: Type.String(),
      avatar: Type.Union([Type.String(), Type.Null()]),
      color: Type.String()
    }),
    defendingCrew: Type.Object({
      id: Type.String(),
      name: Type.String(),
      tag: Type.String(),
      avatar: Type.Union([Type.String(), Type.Null()]),
      color: Type.String()
    }),
    isChallenger: Type.Boolean(),
    myCrewTU: Type.Number(),
    opponentCrewTU: Type.Number(),
    daysRemaining: Type.Number(),
    isWinning: Type.Boolean()
  },
  { additionalProperties: true }
);
var CrewStatsSchema = Type.Object(
  {
    totalMembers: Type.Number(),
    totalTU: Type.Number(),
    weeklyTU: Type.Number(),
    warsWon: Type.Number(),
    warsLost: Type.Number(),
    currentStreak: Type.Number(),
    topContributors: Type.Array(
      Type.Object({
        userId: Type.String(),
        username: Type.String(),
        avatar: Type.Union([Type.String(), Type.Null()]),
        weeklyTU: Type.Number()
      })
    )
  },
  { additionalProperties: true }
);
var MyCrewDataSchema = Type.Object(
  {
    crew: CrewSchema,
    membership: CrewMemberSchema,
    members: Type.Array(CrewMemberSchema, { default: [] }),
    wars: Type.Array(CrewWarSchema, { default: [] }),
    stats: CrewStatsSchema
  },
  { additionalProperties: true }
);
var CrewLeaderboardEntrySchema = Type.Object(
  {
    rank: Type.Number(),
    crew: Type.Object({
      id: Type.String(),
      name: Type.String(),
      tag: Type.String(),
      avatar: Type.Union([Type.String(), Type.Null()]),
      color: Type.String(),
      memberCount: Type.Number(),
      weeklyTU: Type.Number()
    })
  },
  { additionalProperties: true }
);
var JourneyDataSchema = Type.Object(
  {
    totalTU: Type.Number(),
    totalWorkouts: Type.Number(),
    currentLevel: Type.Number(),
    currentLevelName: Type.String(),
    nextLevelTU: Type.Number(),
    progressToNextLevel: Type.Number(),
    currentArchetype: Type.Union([Type.String(), Type.Null()]),
    daysSinceJoined: Type.Number(),
    streak: Type.Number(),
    stats: Type.Object({
      weekly: Type.Object({ workouts: Type.Number(), tu: Type.Number(), avgTuPerWorkout: Type.Number() }),
      monthly: Type.Object({ workouts: Type.Number(), tu: Type.Number(), avgTuPerWorkout: Type.Number() }),
      allTime: Type.Object({ workouts: Type.Number(), tu: Type.Number(), avgTuPerWorkout: Type.Number() })
    }),
    workoutHistory: Type.Array(Type.Object({ date: Type.String(), tu: Type.Number(), count: Type.Number() })),
    muscleBreakdown: Type.Array(Type.Any()),
    muscleGroups: Type.Array(Type.Any()),
    paths: Type.Array(Type.Any()),
    levels: Type.Array(Type.Any()),
    topExercises: Type.Array(Type.Any()),
    recentWorkouts: Type.Array(Type.Any())
  },
  { additionalProperties: true }
);
var CharacterStatsSchema = Type.Object(
  {
    strength: Type.Number(),
    constitution: Type.Number(),
    dexterity: Type.Number(),
    power: Type.Number(),
    endurance: Type.Number(),
    vitality: Type.Number(),
    lastCalculatedAt: Type.Optional(Type.String())
  },
  { additionalProperties: true }
);
var StatRankingSchema = Type.Object(
  {
    rank: Type.Number(),
    total: Type.Number(),
    percentile: Type.Number()
  },
  { additionalProperties: true }
);
var StatRankingsByScopeSchema = Type.Object(
  {
    global: StatRankingSchema,
    country: Type.Optional(StatRankingSchema),
    state: Type.Optional(StatRankingSchema),
    city: Type.Optional(StatRankingSchema)
  },
  { additionalProperties: true }
);
var StatsWithRankingsSchema = Type.Object(
  {
    stats: CharacterStatsSchema,
    rankings: Type.Record(Type.String(), StatRankingsByScopeSchema)
  },
  { additionalProperties: true }
);
var StatsHistoryEntrySchema = Type.Object(
  {
    snapshotDate: Type.String(),
    strength: Type.Number(),
    constitution: Type.Number(),
    dexterity: Type.Number(),
    power: Type.Number(),
    endurance: Type.Number(),
    vitality: Type.Number()
  },
  { additionalProperties: true }
);
var ExtendedProfileSchema = Type.Object(
  {
    gender: Type.Union([Type.String(), Type.Null()]),
    city: Type.Union([Type.String(), Type.Null()]),
    county: Type.Union([Type.String(), Type.Null()]),
    state: Type.Union([Type.String(), Type.Null()]),
    country: Type.Union([Type.String(), Type.Null()]),
    countryCode: Type.Union([Type.String(), Type.Null()]),
    leaderboardOptIn: Type.Boolean(),
    profileVisibility: Type.String()
  },
  { additionalProperties: true }
);
var LeaderboardEntrySchema = Type.Object(
  {
    userId: Type.String(),
    username: Type.String(),
    avatarUrl: Type.Union([Type.String(), Type.Null()]),
    statValue: Type.Number(),
    rank: Type.Number(),
    gender: Type.Optional(Type.String()),
    country: Type.Optional(Type.String()),
    state: Type.Optional(Type.String()),
    city: Type.Optional(Type.String())
  },
  { additionalProperties: true }
);
var StatInfoSchema = Type.Object(
  {
    id: Type.String(),
    name: Type.String(),
    abbr: Type.String(),
    description: Type.String(),
    color: Type.String()
  },
  { additionalProperties: true }
);
var PrivacySettingsSchema = Type.Object(
  {
    minimalistMode: Type.Boolean(),
    optOutLeaderboards: Type.Boolean(),
    optOutCommunityFeed: Type.Boolean(),
    optOutCrews: Type.Boolean(),
    optOutRivals: Type.Boolean(),
    optOutHangouts: Type.Boolean(),
    optOutMessaging: Type.Boolean(),
    optOutHighFives: Type.Boolean(),
    excludeFromStatsComparison: Type.Boolean(),
    excludeFromLocationFeatures: Type.Boolean(),
    excludeFromActivityFeed: Type.Boolean(),
    hideGamification: Type.Boolean(),
    hideAchievements: Type.Boolean(),
    hideTips: Type.Boolean(),
    hideSocialNotifications: Type.Boolean(),
    hideProgressComparisons: Type.Boolean(),
    disablePresenceTracking: Type.Boolean(),
    disableWorkoutSharing: Type.Boolean(),
    profileCompletelyPrivate: Type.Boolean()
  },
  { additionalProperties: true }
);
var PrivacySummarySchema = Type.Object(
  {
    mode: Type.String(),
    summary: Type.String(),
    enabledFeatures: Type.Array(Type.String()),
    disabledFeatures: Type.Array(Type.String()),
    dataPrivacy: Type.Object({
      excludedFromComparisons: Type.Boolean(),
      excludedFromActivityFeed: Type.Boolean(),
      locationHidden: Type.Boolean(),
      presenceHidden: Type.Boolean(),
      profilePrivate: Type.Boolean()
    })
  },
  { additionalProperties: true }
);
var OnboardingStatusSchema = Type.Object(
  {
    completed: Type.Boolean(),
    completedAt: Type.Union([Type.String(), Type.Null()]),
    hasProfile: Type.Boolean(),
    hasGender: Type.Boolean(),
    hasUnits: Type.Boolean()
  },
  { additionalProperties: true }
);
var PhysicalProfileSchema = Type.Object(
  {
    gender: Type.Union([Type.String(), Type.Null()]),
    dateOfBirth: Type.Union([Type.String(), Type.Null()]),
    heightCm: Type.Union([Type.Number(), Type.Null()]),
    heightFt: Type.Union([Type.Number(), Type.Null()]),
    heightIn: Type.Union([Type.Number(), Type.Null()]),
    weightKg: Type.Union([Type.Number(), Type.Null()]),
    weightLbs: Type.Union([Type.Number(), Type.Null()]),
    preferredUnits: Type.String(),
    onboardingCompletedAt: Type.Union([Type.String(), Type.Null()])
  },
  { additionalProperties: true }
);
var EquipmentTypeSchema = Type.Object(
  {
    id: Type.String(),
    name: Type.String(),
    category: Type.String(),
    description: Type.Union([Type.String(), Type.Null()]),
    iconUrl: Type.Union([Type.String(), Type.Null()]),
    displayOrder: Type.Number()
  },
  { additionalProperties: true }
);
var LocationEquipmentSchema = Type.Object(
  {
    equipmentTypeId: Type.String(),
    equipmentName: Type.String(),
    category: Type.String(),
    confirmedCount: Type.Number(),
    deniedCount: Type.Number(),
    isVerified: Type.Boolean(),
    firstReportedAt: Type.String(),
    lastReportedAt: Type.String()
  },
  { additionalProperties: true }
);
var UserHomeEquipmentSchema = Type.Object(
  {
    id: Type.Number(),
    userId: Type.String(),
    equipmentTypeId: Type.String(),
    equipmentName: Type.String(),
    category: Type.String(),
    locationType: Type.String(),
    notes: Type.Union([Type.String(), Type.Null()])
  },
  { additionalProperties: true }
);
var UserSchema = Type.Object(
  {
    id: Type.Union([Type.String(), Type.Number()]),
    email: Type.Optional(Type.String()),
    username: Type.Optional(Type.String()),
    archetype: Type.Optional(Type.String())
  },
  { additionalProperties: true }
);
var AuthResponseSchema = Type.Object(
  { token: Type.String(), user: UserSchema },
  { additionalProperties: true }
);
var WalletSchema = Type.Object(
  {
    wallet: Type.Object(
      { balance: Type.Number(), currency: Type.String({ default: "CR" }) },
      { additionalProperties: true }
    )
  },
  { additionalProperties: true }
);
var TransactionsSchema = Type.Object(
  {
    transactions: Type.Array(
      Type.Object(
        {
          id: Type.Union([Type.String(), Type.Number()]),
          amount: Type.Number(),
          description: Type.Optional(Type.String()),
          created_at: Type.Optional(Type.String())
        },
        { additionalProperties: true }
      ),
      { default: [] }
    )
  },
  { additionalProperties: true }
);
var SubscriptionSchema = Type.Object(
  {
    status: Type.Union([
      Type.String(),
      Type.Null()
    ]),
    currentPeriodEnd: Type.Union([Type.String(), Type.Null()]),
    cancelAtPeriodEnd: Type.Boolean({ default: false })
  },
  { additionalProperties: true }
);
var BillingCheckoutResponseSchema = Type.Object(
  { url: Type.String() },
  { additionalProperties: true }
);
var FoundingMemberStatusSchema = Type.Object(
  {
    isFoundingMember: Type.Boolean(),
    memberNumber: Type.Union([Type.Number(), Type.Null()]),
    joinedAt: Type.Union([Type.String(), Type.Null()]),
    perks: Type.Array(Type.String(), { default: [] })
  },
  { additionalProperties: true }
);
var HighFiveUserSchema = Type.Object(
  { id: Type.Union([Type.String(), Type.Number()]), username: Type.Optional(Type.String()) },
  { additionalProperties: true }
);
var HighFiveFeedSchema = Type.Object(
  {
    encouragements: Type.Array(
      Type.Object(
        {
          id: Type.Union([Type.String(), Type.Number()]),
          sender_name: Type.Optional(Type.String()),
          recipient_name: Type.Optional(Type.String()),
          type: Type.String(),
          message: Type.Optional(Type.Union([Type.String(), Type.Null()])),
          created_at: Type.Optional(Type.String()),
          read_at: Type.Optional(Type.Union([Type.String(), Type.Null()]))
        },
        { additionalProperties: true }
      ),
      { default: [] }
    )
  },
  { additionalProperties: true }
);
var HighFiveStatsSchema = Type.Object(
  {
    sent: Type.Optional(Type.Number()),
    received: Type.Optional(Type.Number()),
    unread: Type.Optional(Type.Number())
  },
  { additionalProperties: true }
);
var SettingsSchema = Type.Object(
  {
    email_notifications: Type.Optional(Type.Boolean()),
    sms_notifications: Type.Optional(Type.Boolean()),
    theme: Type.Optional(Type.String())
  },
  { additionalProperties: true }
);
var SettingsResponseSchema = Type.Object(
  {
    settings: Type.Optional(SettingsSchema)
  },
  { additionalProperties: true }
);
var ProfileSchema = Type.Object(
  {
    id: Type.Optional(Type.Union([Type.String(), Type.Number()])),
    username: Type.Optional(Type.String()),
    bio: Type.Optional(Type.String()),
    avatar: Type.Optional(Type.String())
  },
  { additionalProperties: true }
);
var StatsSchema = Type.Object(
  {
    xp: Type.Number(),
    level: Type.Number(),
    levelName: Type.String(),
    rank: Type.String(),
    streak: Type.Number(),
    workouts: Type.Number(),
    lastWorkoutDate: Type.Union([Type.String(), Type.Null()])
  },
  { additionalProperties: true }
);
function wrapInData(innerSchema) {
  return Type.Object({ data: innerSchema }, { additionalProperties: true });
}
var apiClient = {
  // Authentication
  auth: {
    login: async (email, password) => {
      const response = await request("/auth/login", {
        method: "POST",
        body: { email, password },
        auth: false,
        schema: wrapInData(AuthResponseSchema)
      });
      return response.data;
    },
    register: async (payload) => {
      const response = await request("/auth/register", {
        method: "POST",
        body: payload,
        auth: false,
        schema: wrapInData(AuthResponseSchema)
      });
      return response.data;
    },
    profile: () => request("/auth/me", { schema: UserSchema })
  },
  // Billing
  billing: {
    subscription: () => request("/billing/subscription", {
      schema: wrapInData(Type.Union([SubscriptionSchema, Type.Null()]))
    }),
    checkout: () => request("/billing/checkout", {
      method: "POST",
      schema: wrapInData(BillingCheckoutResponseSchema)
    }),
    creditsCheckout: () => request("/billing/credits/checkout", {
      method: "POST",
      schema: wrapInData(BillingCheckoutResponseSchema)
    }),
    portal: () => request("/billing/portal", {
      method: "POST",
      schema: wrapInData(BillingCheckoutResponseSchema)
    }),
    foundingMember: () => request("/billing/founding-member", {
      schema: wrapInData(FoundingMemberStatusSchema)
    }),
    claimFoundingMember: () => request("/billing/founding-member/claim", {
      method: "POST",
      schema: wrapInData(FoundingMemberStatusSchema)
    })
  },
  // Exercises
  exercises: {
    list: (type) => request(type ? `/exercises?type=${type}` : "/exercises", {
      schema: wrapInData(Type.Array(ExerciseSchema)),
      cacheTtl: 3e5
      // Cache for 5 minutes
    }),
    get: (id) => request(`/exercises/${id}`, {
      schema: wrapInData(ExerciseWithActivationsSchema),
      cacheTtl: 3e5
    }),
    types: () => request("/exercises/types", {
      schema: wrapInData(Type.Array(Type.String())),
      cacheTtl: 3e5
    }),
    search: (query) => request(`/exercises/search?q=${encodeURIComponent(query)}`, {
      schema: wrapInData(Type.Array(ExerciseSchema))
    }),
    activations: (id) => request(`/exercises/${id}/activations`, {
      schema: wrapInData(Type.Record(Type.String(), Type.Number())),
      cacheTtl: 3e5
    })
  },
  // Muscles
  muscles: {
    list: (group) => request(group ? `/muscles?group=${group}` : "/muscles", {
      schema: wrapInData(Type.Array(MuscleSchema)),
      cacheTtl: 3e5
    }),
    get: (id) => request(`/muscles/${id}`, {
      schema: wrapInData(MuscleSchema),
      cacheTtl: 3e5
    }),
    groups: () => request("/muscles/groups", {
      schema: wrapInData(Type.Array(Type.String())),
      cacheTtl: 3e5
    })
  },
  // Workouts
  workouts: {
    create: (payload) => request("/workouts", {
      method: "POST",
      body: payload,
      schema: wrapInData(WorkoutSchema)
    }),
    list: (limit = 50, offset = 0) => request(`/workouts/me?limit=${limit}&offset=${offset}`, {
      schema: wrapInData(Type.Array(WorkoutSchema))
    }),
    get: (id) => request(`/workouts/${id}`, {
      schema: wrapInData(WorkoutSchema)
    }),
    stats: () => request("/workouts/me/stats", {
      schema: wrapInData(WorkoutStatsSchema)
    }),
    muscleActivations: (days = 7) => request(`/workouts/me/muscles?days=${days}`, {
      schema: wrapInData(Type.Array(MuscleActivationSchema))
    }),
    preview: (exercises) => request("/workouts/preview", {
      method: "POST",
      body: { exercises },
      schema: wrapInData(WorkoutPreviewSchema)
    })
  },
  // Archetypes
  archetypes: {
    list: () => request("/archetypes", {
      schema: wrapInData(Type.Array(ArchetypeSchema)),
      cacheTtl: 3e5
    }),
    get: (id) => request(`/archetypes/${id}`, {
      schema: wrapInData(ArchetypeWithLevelsSchema),
      cacheTtl: 3e5
    }),
    levels: (id) => request(`/archetypes/${id}/levels`, {
      schema: wrapInData(Type.Array(ArchetypeLevelSchema)),
      cacheTtl: 3e5
    }),
    myProgress: () => request("/archetypes/me/progress", {
      schema: Type.Object({ data: Type.Union([ArchetypeProgressSchema, Type.Null()]) }, { additionalProperties: true })
    }),
    progressFor: (archetypeId) => request(`/archetypes/me/progress/${archetypeId}`, {
      schema: wrapInData(ArchetypeProgressSchema)
    }),
    select: (archetypeId) => request("/archetypes/me/select", {
      method: "POST",
      body: { archetypeId },
      schema: wrapInData(Type.Object({ success: Type.Boolean(), archetypeId: Type.String() }))
    })
  },
  // Journey (comprehensive progress tracking)
  journey: {
    get: () => request("/journey", {
      schema: wrapInData(JourneyDataSchema)
    }),
    paths: () => request("/journey/paths", {
      schema: wrapInData(Type.Object({ paths: Type.Array(Type.Any()) }))
    }),
    switchArchetype: (archetype) => request("/journey/switch", {
      method: "POST",
      body: { archetype },
      schema: Type.Object({
        success: Type.Boolean(),
        data: Type.Object({ archetype: Type.String() })
      }, { additionalProperties: true })
    })
  },
  // Progress (legacy stats)
  progress: {
    stats: () => request("/progress/stats", { schema: wrapInData(StatsSchema) })
  },
  // Wallet / Economy
  wallet: {
    balance: () => request("/economy/wallet", { schema: WalletSchema }),
    transactions: (limit = 20) => request(`/economy/transactions?limit=${limit}`, {
      schema: TransactionsSchema
    }),
    transfer: (payload) => request("/economy/transfer", {
      method: "POST",
      body: payload,
      schema: Type.Object({ success: Type.Optional(Type.Boolean()) }, { additionalProperties: true })
    })
  },
  // High Fives
  highFives: {
    users: () => request("/highfives/users", {
      schema: Type.Object(
        { users: Type.Array(HighFiveUserSchema, { default: [] }) },
        { additionalProperties: true }
      )
    }),
    received: () => request("/highfives/received", { schema: HighFiveFeedSchema }),
    sent: () => request("/highfives/sent", { schema: HighFiveFeedSchema }),
    stats: () => request("/highfives/stats", { schema: HighFiveStatsSchema }),
    send: (payload) => request("/highfives/send", {
      method: "POST",
      body: payload,
      schema: Type.Object({ error: Type.Optional(Type.String()) }, { additionalProperties: true })
    })
  },
  // Settings
  settings: {
    fetch: () => request("/settings", { schema: SettingsResponseSchema }),
    update: (updates) => request("/settings", { method: "PATCH", body: updates, schema: SettingsSchema })
  },
  // Profile
  profile: {
    get: () => request("/profile", { schema: ProfileSchema }),
    update: (updates) => request("/profile", { method: "PUT", body: updates, schema: ProfileSchema }),
    avatars: () => request("/profile/avatars", {
      schema: Type.Object(
        { avatars: Type.Array(Type.Any(), { default: [] }) },
        { additionalProperties: true }
      ),
      cacheTtl: 6e4
    }),
    themes: () => request("/profile/themes", {
      schema: Type.Object(
        { themes: Type.Array(Type.Any(), { default: [] }) },
        { additionalProperties: true }
      ),
      cacheTtl: 6e4
    })
  },
  // Rivals
  rivals: {
    list: (status) => request(
      status ? `/rivals?status=${status}` : "/rivals",
      {
        schema: wrapInData(
          Type.Object({
            rivals: Type.Array(RivalSchema),
            stats: RivalStatsSchema
          })
        )
      }
    ),
    get: (id) => request(`/rivals/${id}`, {
      schema: wrapInData(RivalSchema)
    }),
    pending: () => request("/rivals/pending", {
      schema: wrapInData(Type.Array(RivalSchema))
    }),
    stats: () => request("/rivals/stats", {
      schema: wrapInData(RivalStatsSchema)
    }),
    search: (query, limit = 20) => request(
      `/rivals/search?q=${encodeURIComponent(query)}&limit=${limit}`,
      {
        schema: wrapInData(Type.Array(RivalSearchResultSchema))
      }
    ),
    challenge: (userId) => request("/rivals", {
      method: "POST",
      body: { userId },
      schema: wrapInData(RivalSchema)
    }),
    accept: (id) => request(`/rivals/${id}/accept`, {
      method: "POST",
      schema: wrapInData(RivalSchema)
    }),
    decline: (id) => request(`/rivals/${id}/decline`, {
      method: "POST",
      schema: Type.Object({ success: Type.Boolean() }, { additionalProperties: true })
    }),
    end: (id) => request(`/rivals/${id}/end`, {
      method: "POST",
      schema: Type.Object({ success: Type.Boolean() }, { additionalProperties: true })
    })
  },
  // Wearables / Health Integration
  wearables: {
    /** Get health summary with today/week stats and connections */
    summary: () => request("/wearables", {
      schema: wrapInData(HealthSummarySchema)
    }),
    /** Get sync status for all connected providers */
    status: () => request("/wearables/status", {
      schema: wrapInData(Type.Object({
        syncStatus: Type.Array(HealthSyncStatusSchema, { default: [] })
      }))
    }),
    /** Get sync status for a specific provider */
    providerStatus: (provider) => request(`/wearables/status/${provider}`, {
      schema: wrapInData(HealthSyncStatusSchema)
    }),
    /** Connect a wearable provider */
    connect: (provider, data) => request("/wearables/connect", {
      method: "POST",
      body: { provider, ...data },
      schema: wrapInData(WearableConnectionSchema)
    }),
    /** Disconnect a wearable provider */
    disconnect: (provider) => request("/wearables/disconnect", {
      method: "POST",
      body: { provider },
      schema: Type.Object({ success: Type.Boolean() }, { additionalProperties: true })
    }),
    /** Sync health data with optional conflict resolution strategy */
    sync: (provider, data, options) => request(
      "/wearables/sync",
      {
        method: "POST",
        body: { provider, data, options },
        schema: wrapInData(HealthSyncResultSchema)
      }
    ),
    /** Get recent workouts from wearables */
    workouts: (limit = 10) => request(`/wearables/workouts?limit=${limit}`, {
      schema: wrapInData(Type.Object({ workouts: Type.Array(WorkoutSampleSchema, { default: [] }) }))
    }),
    /** Get workouts for export to wearable (bi-directional sync) */
    exportWorkouts: (options) => request(
      `/wearables/export?${new URLSearchParams(Object.entries(options || {}).filter(([, v]) => v !== void 0).map(([k, v]) => [k, String(v)])).toString()}`,
      {
        schema: wrapInData(Type.Object({ workouts: Type.Array(WorkoutSampleSchema, { default: [] }) }))
      }
    )
  },
  // Crews
  crews: {
    my: () => request("/crews/my", {
      schema: wrapInData(Type.Union([MyCrewDataSchema, Type.Null()]))
    }),
    create: (name, tag, description, color) => request("/crews", {
      method: "POST",
      body: { name, tag, description, color },
      schema: wrapInData(CrewSchema)
    }),
    get: (id) => request(`/crews/${id}`, {
      schema: wrapInData(
        Type.Object({
          crew: CrewSchema,
          members: Type.Array(CrewMemberSchema, { default: [] }),
          stats: CrewStatsSchema
        })
      )
    }),
    search: (query, limit = 20) => request(`/crews/search?q=${encodeURIComponent(query)}&limit=${limit}`, {
      schema: wrapInData(Type.Array(CrewSchema, { default: [] }))
    }),
    leaderboard: (limit = 50) => request(`/crews/leaderboard?limit=${limit}`, {
      schema: wrapInData(Type.Array(CrewLeaderboardEntrySchema, { default: [] }))
    }),
    invite: (crewId, inviteeId) => request(`/crews/${crewId}/invite`, {
      method: "POST",
      body: { inviteeId },
      schema: wrapInData(Type.Object({ id: Type.String() }, { additionalProperties: true }))
    }),
    acceptInvite: (inviteId) => request(`/crews/invites/${inviteId}/accept`, {
      method: "POST",
      schema: wrapInData(CrewMemberSchema)
    }),
    leave: () => request("/crews/leave", {
      method: "POST",
      schema: Type.Object({ success: Type.Boolean() }, { additionalProperties: true })
    }),
    startWar: (crewId, defendingCrewId, durationDays = 7) => request(`/crews/${crewId}/war`, {
      method: "POST",
      body: { defendingCrewId, durationDays },
      schema: wrapInData(CrewWarSchema)
    }),
    getWars: (crewId) => request(`/crews/${crewId}/wars`, {
      schema: wrapInData(Type.Array(CrewWarSchema, { default: [] }))
    })
  },
  // Character Stats (D&D-style attributes)
  characterStats: {
    /**
     * Get current user's character stats and rankings
     */
    me: () => request("/stats/me", {
      schema: wrapInData(StatsWithRankingsSchema)
    }),
    /**
     * Get another user's stats (if public)
     */
    getUser: (userId) => request(`/stats/user/${userId}`, {
      schema: wrapInData(
        Type.Object({
          userId: Type.String(),
          stats: CharacterStatsSchema
        })
      )
    }),
    /**
     * Get stats history for progress charts
     */
    history: (days = 30) => request(`/stats/history?days=${days}`, {
      schema: wrapInData(Type.Array(StatsHistoryEntrySchema))
    }),
    /**
     * Force recalculate all stats from workout history
     */
    recalculate: () => request("/stats/recalculate", {
      method: "POST",
      schema: wrapInData(
        Type.Object({
          stats: CharacterStatsSchema,
          message: Type.String()
        })
      )
    }),
    /**
     * Get leaderboard rankings with filtering
     */
    leaderboard: (options) => {
      const params = new URLSearchParams();
      if (options?.stat) params.set("stat", options.stat);
      if (options?.scope) params.set("scope", options.scope);
      if (options?.scopeValue) params.set("scopeValue", options.scopeValue);
      if (options?.gender) params.set("gender", options.gender);
      if (options?.limit) params.set("limit", String(options.limit));
      if (options?.offset) params.set("offset", String(options.offset));
      const query = params.toString();
      return request(`/stats/leaderboards${query ? `?${query}` : ""}`, {
        schema: wrapInData(Type.Array(LeaderboardEntrySchema))
      });
    },
    /**
     * Get current user's rankings across all scopes
     */
    myRankings: () => request("/stats/leaderboards/me", {
      schema: wrapInData(
        Type.Object({
          rankings: Type.Record(Type.String(), StatRankingsByScopeSchema),
          profile: Type.Object({
            gender: Type.Union([Type.String(), Type.Null()]),
            city: Type.Union([Type.String(), Type.Null()]),
            state: Type.Union([Type.String(), Type.Null()]),
            country: Type.Union([Type.String(), Type.Null()])
          })
        })
      )
    }),
    /**
     * Get extended profile (gender, location)
     */
    extendedProfile: () => request("/stats/profile/extended", {
      schema: wrapInData(ExtendedProfileSchema)
    }),
    /**
     * Update extended profile
     */
    updateExtendedProfile: (updates) => request("/stats/profile/extended", {
      method: "PUT",
      body: updates,
      schema: wrapInData(ExtendedProfileSchema)
    }),
    /**
     * Get information about the stats system
     */
    info: () => request("/stats/info", {
      schema: wrapInData(Type.Object({ stats: Type.Array(StatInfoSchema) })),
      cacheTtl: 3e5
      // Cache for 5 minutes
    })
  },
  // Privacy Settings (Minimalist Mode)
  privacy: {
    /**
     * Get current user's privacy settings
     */
    get: () => request("/privacy", {
      schema: wrapInData(PrivacySettingsSchema)
    }),
    /**
     * Update privacy settings
     */
    update: (updates) => request("/privacy", {
      method: "PUT",
      body: updates,
      schema: wrapInData(PrivacySettingsSchema)
    }),
    /**
     * Enable full minimalist mode (one-click privacy)
     * Disables all community features and excludes user from all comparisons
     */
    enableMinimalist: () => request("/privacy/enable-minimalist", {
      method: "POST",
      schema: wrapInData(
        Type.Object({
          minimalistMode: Type.Boolean(),
          message: Type.String()
        })
      )
    }),
    /**
     * Disable minimalist mode and restore defaults
     */
    disableMinimalist: () => request("/privacy/disable-minimalist", {
      method: "POST",
      schema: wrapInData(
        Type.Object({
          minimalistMode: Type.Boolean(),
          message: Type.String()
        })
      )
    }),
    /**
     * Get a user-friendly summary of privacy settings
     */
    summary: () => request("/privacy/summary", {
      schema: wrapInData(PrivacySummarySchema)
    })
  },
  // Onboarding
  onboarding: {
    /**
     * Get onboarding status
     */
    status: () => request("/onboarding/status", {
      schema: wrapInData(OnboardingStatusSchema)
    }),
    /**
     * Get current physical profile
     */
    getProfile: () => request("/onboarding/profile", {
      schema: wrapInData(PhysicalProfileSchema)
    }),
    /**
     * Save physical profile during onboarding
     */
    saveProfile: (profile) => request("/onboarding/profile", {
      method: "POST",
      body: profile,
      schema: wrapInData(
        Type.Object({
          success: Type.Boolean(),
          message: Type.String()
        })
      )
    }),
    /**
     * Save home equipment during onboarding
     */
    saveHomeEquipment: (equipmentIds, locationType = "home") => request("/onboarding/home-equipment", {
      method: "POST",
      body: { equipmentIds, locationType },
      schema: wrapInData(
        Type.Object({
          success: Type.Boolean(),
          message: Type.String(),
          equipmentCount: Type.Number()
        })
      )
    }),
    /**
     * Mark onboarding as complete
     */
    complete: () => request("/onboarding/complete", {
      method: "POST",
      schema: wrapInData(
        Type.Object({
          success: Type.Boolean(),
          message: Type.String(),
          completedAt: Type.String()
        })
      )
    }),
    /**
     * Skip onboarding
     */
    skip: () => request("/onboarding/skip", {
      method: "POST",
      schema: wrapInData(
        Type.Object({
          success: Type.Boolean(),
          message: Type.String(),
          skipped: Type.Boolean()
        })
      )
    })
  },
  // Equipment
  equipment: {
    /**
     * Get all equipment types
     */
    types: () => request("/equipment/types", {
      schema: wrapInData(Type.Array(EquipmentTypeSchema)),
      cacheTtl: 3e5
      // Cache for 5 minutes
    }),
    /**
     * Get equipment types by category
     */
    typesByCategory: (category) => request(`/equipment/types/${encodeURIComponent(category)}`, {
      schema: wrapInData(Type.Array(EquipmentTypeSchema)),
      cacheTtl: 3e5
    }),
    /**
     * Get all equipment categories
     */
    categories: () => request("/equipment/categories", {
      schema: wrapInData(Type.Array(Type.String())),
      cacheTtl: 3e5
    }),
    /**
     * Get equipment at a location
     */
    getLocationEquipment: (hangoutId) => request(`/locations/${hangoutId}/equipment`, {
      schema: wrapInData(Type.Array(LocationEquipmentSchema))
    }),
    /**
     * Get verified equipment at a location
     */
    getVerifiedLocationEquipment: (hangoutId) => request(`/locations/${hangoutId}/equipment/verified`, {
      schema: wrapInData(Type.Array(Type.String()))
    }),
    /**
     * Report equipment at a location
     */
    reportEquipment: (hangoutId, types, reportType) => request(
      `/locations/${hangoutId}/equipment`,
      {
        method: "POST",
        body: { types, reportType },
        schema: wrapInData(
          Type.Object({
            success: Type.Boolean(),
            message: Type.String(),
            reportedCount: Type.Number()
          })
        )
      }
    ),
    /**
     * Get user's reports for a location
     */
    getMyReports: (hangoutId) => request(
      `/locations/${hangoutId}/equipment/my-reports`,
      {
        schema: wrapInData(
          Type.Array(
            Type.Object({
              equipmentTypeId: Type.String(),
              reportType: Type.String()
            })
          )
        )
      }
    ),
    /**
     * Get user's home equipment
     */
    getHomeEquipment: (locationType) => request(
      `/equipment/home${locationType ? `?locationType=${locationType}` : ""}`,
      {
        schema: wrapInData(Type.Array(UserHomeEquipmentSchema))
      }
    ),
    /**
     * Get user's home equipment IDs
     */
    getHomeEquipmentIds: (locationType) => request(
      `/equipment/home/ids${locationType ? `?locationType=${locationType}` : ""}`,
      {
        schema: wrapInData(Type.Array(Type.String()))
      }
    ),
    /**
     * Set user's home equipment (replaces all)
     */
    setHomeEquipment: (equipmentIds, locationType = "home") => request("/equipment/home", {
      method: "PUT",
      body: { equipmentIds, locationType },
      schema: wrapInData(
        Type.Object({
          success: Type.Boolean(),
          message: Type.String(),
          equipmentCount: Type.Number()
        })
      )
    }),
    /**
     * Add single equipment to home
     */
    addHomeEquipment: (equipmentId, locationType = "home", notes) => request("/equipment/home", {
      method: "POST",
      body: { equipmentId, locationType, notes },
      schema: wrapInData(
        Type.Object({
          success: Type.Boolean(),
          message: Type.String()
        })
      )
    }),
    /**
     * Remove equipment from home
     */
    removeHomeEquipment: (equipmentId, locationType = "home") => request(
      `/equipment/home/${equipmentId}${locationType !== "home" ? `?locationType=${locationType}` : ""}`,
      {
        method: "DELETE",
        schema: Type.Object({
          success: Type.Boolean(),
          message: Type.String()
        }, { additionalProperties: true })
      }
    )
  },
  // Virtual Hangouts (themed community spaces)
  hangouts: {
    /**
     * Get all hangout themes
     */
    themes: () => request("/virtual-hangouts/themes", {
      schema: wrapInData(Type.Array(VirtualHangoutThemeSchema)),
      cacheTtl: 3e5
    }),
    /**
     * List virtual hangouts
     */
    list: (themeId, limit = 50, offset = 0) => request(
      `/virtual-hangouts?${new URLSearchParams({ ...themeId ? { themeId: String(themeId) } : {}, limit: String(limit), offset: String(offset) }).toString()}`,
      { schema: wrapInData(Type.Array(VirtualHangoutSchema)) }
    ),
    /**
     * Get recommended hangouts for current user
     */
    recommended: (limit = 5) => request(`/virtual-hangouts/recommended?limit=${limit}`, {
      schema: wrapInData(Type.Array(VirtualHangoutSchema))
    }),
    /**
     * Get user's hangout memberships
     */
    my: (limit = 50, offset = 0) => request(
      `/virtual-hangouts/my?limit=${limit}&offset=${offset}`,
      { schema: wrapInData(Type.Array(VirtualHangoutSchema)) }
    ),
    /**
     * Get a single hangout
     */
    get: (id) => request(`/virtual-hangouts/${id}`, {
      schema: wrapInData(VirtualHangoutSchema)
    }),
    /**
     * Join a hangout
     */
    join: (id, showInMemberList = true, receiveNotifications = true) => request(`/virtual-hangouts/${id}/join`, {
      method: "POST",
      body: { showInMemberList, receiveNotifications },
      schema: wrapInData(Type.Object({ message: Type.String() }))
    }),
    /**
     * Leave a hangout
     */
    leave: (id) => request(`/virtual-hangouts/${id}/leave`, {
      method: "POST",
      schema: wrapInData(Type.Object({ message: Type.String() }))
    }),
    /**
     * Get hangout members
     */
    members: (id, limit = 50, offset = 0) => request(
      `/virtual-hangouts/${id}/members?limit=${limit}&offset=${offset}`,
      { schema: wrapInData(Type.Array(HangoutMemberSchema)) }
    ),
    /**
     * Get hangout activity feed
     */
    activity: (id, limit = 50, offset = 0) => request(
      `/virtual-hangouts/${id}/activity?limit=${limit}&offset=${offset}`,
      { schema: wrapInData(Type.Array(HangoutActivitySchema)) }
    ),
    /**
     * Share a workout to a hangout
     */
    shareWorkout: (id, workoutId, message) => request(`/virtual-hangouts/${id}/share-workout`, {
      method: "POST",
      body: { workoutId, message },
      schema: wrapInData(Type.Object({ message: Type.String() }))
    }),
    /**
     * Send heartbeat to update last active time
     */
    heartbeat: (id) => request(`/virtual-hangouts/${id}/heartbeat`, {
      method: "POST",
      schema: wrapInData(Type.Object({ acknowledged: Type.Boolean() }))
    }),
    /**
     * Get posts from hangout bulletin board
     */
    posts: (id, options) => request(
      `/virtual-hangouts/${id}/posts?${new URLSearchParams({
        limit: String(options?.limit || 20),
        offset: String(options?.offset || 0),
        sortBy: options?.sortBy || "hot"
      }).toString()}`,
      { schema: wrapInData(Type.Array(BulletinPostSchema)) }
    ),
    /**
     * Create a post in hangout bulletin board
     */
    createPost: (id, post) => request(`/virtual-hangouts/${id}/posts`, {
      method: "POST",
      body: post,
      schema: wrapInData(BulletinPostSchema)
    })
  },
  // Communities (self-organized groups)
  communities: {
    /**
     * Create a new community
     */
    create: (data) => request("/communities", {
      method: "POST",
      body: data,
      schema: wrapInData(CommunitySchema)
    }),
    /**
     * Search/list communities
     */
    search: (options) => {
      const params = new URLSearchParams();
      if (options?.query) params.set("query", options.query);
      if (options?.communityType) params.set("communityType", options.communityType);
      if (options?.goalType) params.set("goalType", options.goalType);
      if (options?.institutionType) params.set("institutionType", options.institutionType);
      if (options?.limit) params.set("limit", String(options.limit));
      if (options?.offset) params.set("offset", String(options.offset));
      const query = params.toString();
      return request(
        `/communities${query ? `?${query}` : ""}`,
        { schema: wrapInData(Type.Array(CommunitySchema)) }
      );
    },
    /**
     * Get user's communities
     */
    my: (limit = 50, offset = 0) => request(
      `/communities/my?limit=${limit}&offset=${offset}`,
      { schema: wrapInData(Type.Array(CommunitySchema)) }
    ),
    /**
     * Get a community by ID or slug
     */
    get: (idOrSlug) => request(`/communities/${idOrSlug}`, {
      schema: wrapInData(CommunitySchema)
    }),
    /**
     * Join a community
     */
    join: (id) => request(`/communities/${id}/join`, {
      method: "POST",
      schema: wrapInData(Type.Object({ message: Type.String(), status: Type.String() }))
    }),
    /**
     * Leave a community
     */
    leave: (id) => request(`/communities/${id}/leave`, {
      method: "POST",
      schema: wrapInData(Type.Object({ message: Type.String() }))
    }),
    /**
     * Get community members
     */
    members: (id, limit = 50, offset = 0, status = "active") => request(
      `/communities/${id}/members?limit=${limit}&offset=${offset}&status=${status}`,
      { schema: wrapInData(Type.Array(CommunityMemberSchema)) }
    ),
    /**
     * Get community events
     */
    events: (id, upcoming = true, limit = 20, offset = 0) => request(
      `/communities/${id}/events?upcoming=${upcoming}&limit=${limit}&offset=${offset}`,
      { schema: wrapInData(Type.Array(CommunityEventSchema)) }
    ),
    /**
     * Create a community event
     */
    createEvent: (id, event) => request(`/communities/${id}/events`, {
      method: "POST",
      body: event,
      schema: wrapInData(CommunityEventSchema)
    }),
    /**
     * Get posts from community bulletin board
     */
    posts: (id, options) => request(
      `/communities/${id}/posts?${new URLSearchParams({
        limit: String(options?.limit || 20),
        offset: String(options?.offset || 0),
        sortBy: options?.sortBy || "hot"
      }).toString()}`,
      { schema: wrapInData(Type.Array(BulletinPostSchema)) }
    ),
    /**
     * Create a post in community bulletin board
     */
    createPost: (id, post) => request(`/communities/${id}/posts`, {
      method: "POST",
      body: post,
      schema: wrapInData(BulletinPostSchema)
    })
  },
  // Bulletin board actions (shared between hangouts and communities)
  bulletin: {
    /**
     * Get a single post
     */
    getPost: (postId) => request(`/bulletin/posts/${postId}`, {
      schema: wrapInData(BulletinPostSchema)
    }),
    /**
     * Vote on a post
     */
    votePost: (postId, voteType) => request(
      `/bulletin/posts/${postId}/vote`,
      {
        method: "POST",
        body: { voteType },
        schema: wrapInData(Type.Object({
          upvotes: Type.Number(),
          downvotes: Type.Number(),
          score: Type.Number()
        }))
      }
    ),
    /**
     * Get comments for a post
     */
    getComments: (postId, limit = 50, offset = 0) => request(
      `/bulletin/posts/${postId}/comments?limit=${limit}&offset=${offset}`,
      { schema: wrapInData(Type.Array(BulletinCommentSchema)) }
    ),
    /**
     * Add a comment to a post
     */
    addComment: (postId, content, parentId) => request(`/bulletin/posts/${postId}/comments`, {
      method: "POST",
      body: { content, parentId },
      schema: wrapInData(BulletinCommentSchema)
    }),
    /**
     * Vote on a comment
     */
    voteComment: (commentId, voteType) => request(
      `/bulletin/comments/${commentId}/vote`,
      {
        method: "POST",
        body: { voteType },
        schema: wrapInData(Type.Object({
          upvotes: Type.Number(),
          downvotes: Type.Number(),
          score: Type.Number()
        }))
      }
    ),
    /**
     * Pin a post (moderator)
     */
    pinPost: (postId) => request(`/bulletin/posts/${postId}/pin`, {
      method: "POST",
      schema: wrapInData(Type.Object({ message: Type.String() }))
    }),
    /**
     * Unpin a post (moderator)
     */
    unpinPost: (postId) => request(`/bulletin/posts/${postId}/unpin`, {
      method: "POST",
      schema: wrapInData(Type.Object({ message: Type.String() }))
    }),
    /**
     * Hide a post (moderator)
     */
    hidePost: (postId) => request(`/bulletin/posts/${postId}/hide`, {
      method: "POST",
      schema: wrapInData(Type.Object({ message: Type.String() }))
    })
  },
  // Exercise-Based Leaderboards
  exerciseLeaderboards: {
    /**
     * Get leaderboard for a specific metric
     */
    get: (options) => {
      const params = new URLSearchParams();
      params.set("exerciseId", options.exerciseId);
      params.set("metricKey", options.metricKey);
      if (options.periodType) params.set("periodType", options.periodType);
      if (options.hangoutId) params.set("hangoutId", String(options.hangoutId));
      if (options.gender) params.set("gender", options.gender);
      if (options.ageBand) params.set("ageBand", options.ageBand);
      if (options.limit) params.set("limit", String(options.limit));
      if (options.cursor) params.set("cursor", options.cursor);
      return request(`/leaderboards?${params.toString()}`, {
        schema: wrapInData(Type.Object({
          entries: Type.Array(Type.Object({
            rank: Type.Number(),
            userId: Type.String(),
            username: Type.String(),
            avatarUrl: Type.Optional(Type.String()),
            value: Type.Number(),
            updatedAt: Type.String()
          })),
          nextCursor: Type.Optional(Type.String()),
          hasMore: Type.Boolean()
        }))
      });
    },
    /**
     * Get global leaderboard across all exercises
     */
    global: (options) => {
      const params = new URLSearchParams();
      if (options?.periodType) params.set("periodType", options.periodType);
      if (options?.gender) params.set("gender", options.gender);
      if (options?.ageBand) params.set("ageBand", options.ageBand);
      if (options?.limit) params.set("limit", String(options.limit));
      const query = params.toString();
      return request(`/leaderboards/global${query ? `?${query}` : ""}`, {
        schema: wrapInData(Type.Object({
          entries: Type.Array(Type.Object({
            rank: Type.Number(),
            userId: Type.String(),
            username: Type.String(),
            avatarUrl: Type.Optional(Type.String()),
            totalPoints: Type.Number(),
            recordCount: Type.Number()
          }))
        }))
      });
    },
    /**
     * Get leaderboard for a specific hangout
     */
    hangout: (hangoutId, options) => {
      const params = new URLSearchParams();
      if (options?.exerciseId) params.set("exerciseId", options.exerciseId);
      if (options?.metricKey) params.set("metricKey", options.metricKey);
      if (options?.periodType) params.set("periodType", options.periodType);
      if (options?.limit) params.set("limit", String(options.limit));
      const query = params.toString();
      return request(`/hangouts/${hangoutId}/leaderboard${query ? `?${query}` : ""}`, {
        schema: wrapInData(Type.Object({
          entries: Type.Array(Type.Object({
            rank: Type.Number(),
            userId: Type.String(),
            username: Type.String(),
            avatarUrl: Type.Optional(Type.String()),
            value: Type.Number(),
            updatedAt: Type.String()
          }))
        }))
      });
    },
    /**
     * Get current user's rank for a specific metric
     */
    myRank: (options) => {
      const params = new URLSearchParams();
      params.set("exerciseId", options.exerciseId);
      params.set("metricKey", options.metricKey);
      if (options.periodType) params.set("periodType", options.periodType);
      if (options.hangoutId) params.set("hangoutId", String(options.hangoutId));
      return request(`/me/rank?${params.toString()}`, {
        schema: wrapInData(Type.Object({
          rank: Type.Number(),
          percentile: Type.Number(),
          value: Type.Number(),
          totalParticipants: Type.Number()
        }))
      });
    },
    /**
     * Get available metric definitions
     */
    metrics: () => request("/leaderboards/metrics", {
      schema: wrapInData(Type.Array(Type.Object({
        id: Type.String(),
        exerciseId: Type.String(),
        metricKey: Type.String(),
        displayName: Type.String(),
        unit: Type.String(),
        direction: Type.String()
      }))),
      cacheTtl: 3e5
      // Cache for 5 minutes
    })
  },
  // Achievements / Badges
  achievements: {
    /**
     * Get all achievement definitions
     */
    definitions: () => request("/achievements/definitions", {
      schema: wrapInData(Type.Array(Type.Object({
        id: Type.String(),
        key: Type.String(),
        name: Type.String(),
        description: Type.Optional(Type.String()),
        icon: Type.Optional(Type.String()),
        category: Type.String(),
        points: Type.Number(),
        rarity: Type.String(),
        enabled: Type.Boolean()
      }))),
      cacheTtl: 3e5
    }),
    /**
     * Get current user's achievements
     */
    my: (options) => {
      const params = new URLSearchParams();
      if (options?.limit) params.set("limit", String(options.limit));
      if (options?.cursor) params.set("cursor", options.cursor);
      if (options?.category) params.set("category", options.category);
      const query = params.toString();
      return request(`/me/achievements${query ? `?${query}` : ""}`, {
        schema: wrapInData(Type.Array(Type.Object({
          id: Type.String(),
          achievementKey: Type.String(),
          achievementName: Type.String(),
          achievementDescription: Type.Optional(Type.String()),
          achievementIcon: Type.Optional(Type.String()),
          category: Type.String(),
          points: Type.Number(),
          rarity: Type.String(),
          earnedAt: Type.String(),
          value: Type.Optional(Type.Number()),
          hangoutId: Type.Optional(Type.Number()),
          exerciseId: Type.Optional(Type.String())
        })))
      });
    },
    /**
     * Get current user's achievement summary
     */
    summary: () => request("/me/achievements/summary", {
      schema: wrapInData(Type.Object({
        totalPoints: Type.Number(),
        totalAchievements: Type.Number(),
        byCategory: Type.Record(Type.String(), Type.Number()),
        byRarity: Type.Record(Type.String(), Type.Number()),
        recentAchievements: Type.Array(Type.Object({
          id: Type.String(),
          achievementKey: Type.String(),
          achievementName: Type.String(),
          category: Type.String(),
          points: Type.Number(),
          rarity: Type.String(),
          earnedAt: Type.String()
        }))
      }))
    }),
    /**
     * Get hangout achievement feed
     */
    hangoutFeed: (hangoutId, options) => {
      const params = new URLSearchParams();
      if (options?.limit) params.set("limit", String(options.limit));
      if (options?.cursor) params.set("cursor", options.cursor);
      const query = params.toString();
      return request(`/hangouts/${hangoutId}/achievements${query ? `?${query}` : ""}`, {
        schema: wrapInData(Type.Array(Type.Object({
          id: Type.String(),
          userId: Type.String(),
          username: Type.String(),
          avatarUrl: Type.Optional(Type.String()),
          achievementName: Type.String(),
          achievementIcon: Type.Optional(Type.String()),
          points: Type.Number(),
          rarity: Type.String(),
          earnedAt: Type.String()
        })))
      });
    }
  },
  // Achievement Verification
  verifications: {
    /**
     * Get achievements that require verification
     */
    getRequired: () => request("/achievements/verification-required", {
      schema: wrapInData(Type.Array(Type.Object({
        id: Type.String(),
        key: Type.String(),
        name: Type.String(),
        description: Type.Optional(Type.String()),
        tier: Type.String(),
        rarity: Type.String(),
        points: Type.Number()
      }))),
      cacheTtl: 3e5
    }),
    /**
     * Check if user can submit verification for an achievement
     */
    canVerify: (achievementId) => request(`/achievements/${achievementId}/can-verify`),
    /**
     * Submit verification with video
     */
    submit: (achievementId, data) => {
      const formData = new FormData();
      formData.append("witness_user_id", data.witnessUserId);
      if (data.notes) formData.append("notes", data.notes);
      if (data.video) formData.append("video", data.video);
      return request(`/achievements/${achievementId}/verify`, {
        method: "POST",
        body: formData,
        headers: {}
        // Let browser set content-type with boundary
      });
    },
    /**
     * Get current user's verifications
     */
    my: (options) => {
      const params = new URLSearchParams();
      if (options?.status) params.set("status", options.status);
      if (options?.limit) params.set("limit", String(options.limit));
      if (options?.offset) params.set("offset", String(options.offset));
      const query = params.toString();
      return request(`/me/verifications${query ? `?${query}` : ""}`);
    },
    /**
     * Get a specific verification
     */
    get: (verificationId) => request(`/verifications/${verificationId}`),
    /**
     * Cancel a pending verification
     */
    cancel: (verificationId) => request(`/verifications/${verificationId}`, { method: "DELETE" }),
    /**
     * Get pending witness requests
     */
    witnessRequests: (options) => {
      const params = new URLSearchParams();
      if (options?.status) params.set("status", options.status);
      if (options?.limit) params.set("limit", String(options.limit));
      if (options?.offset) params.set("offset", String(options.offset));
      const query = params.toString();
      return request(`/me/witness-requests${query ? `?${query}` : ""}`);
    },
    /**
     * Submit witness attestation
     */
    attest: (verificationId, data) => request(`/verifications/${verificationId}/witness`, {
      method: "POST",
      body: {
        confirm: data.confirm,
        attestation_text: data.attestationText,
        relationship: data.relationship,
        location_description: data.locationDescription,
        is_public: data.isPublic
      }
    })
  },
  // Cohort Preferences (for leaderboard filtering)
  cohortPreferences: {
    /**
     * Get current user's cohort preferences
     */
    get: () => request("/me/cohort-preferences", {
      schema: wrapInData(Type.Object({
        gender: Type.Optional(Type.String()),
        ageBand: Type.Optional(Type.String()),
        adaptiveCategory: Type.Optional(Type.String()),
        leaderboardOptIn: Type.Boolean(),
        showGenderInLeaderboard: Type.Boolean(),
        showAgeInLeaderboard: Type.Boolean()
      }))
    }),
    /**
     * Update cohort preferences
     */
    update: (updates) => request("/me/cohort-preferences", {
      method: "PATCH",
      body: updates,
      schema: wrapInData(Type.Object({
        gender: Type.Optional(Type.String()),
        ageBand: Type.Optional(Type.String()),
        adaptiveCategory: Type.Optional(Type.String()),
        leaderboardOptIn: Type.Boolean(),
        showGenderInLeaderboard: Type.Boolean(),
        showAgeInLeaderboard: Type.Boolean()
      }))
    }),
    /**
     * Opt into exercise leaderboards
     */
    optIn: () => request("/me/leaderboard-opt-in", {
      method: "POST",
      schema: wrapInData(Type.Object({
        leaderboardOptIn: Type.Boolean(),
        message: Type.String()
      }))
    }),
    /**
     * Opt out of exercise leaderboards
     */
    optOut: () => request("/me/leaderboard-opt-out", {
      method: "POST",
      schema: wrapInData(Type.Object({
        leaderboardOptIn: Type.Boolean(),
        message: Type.String()
      }))
    }),
    /**
     * Get available cohort options
     */
    options: () => request("/cohort-options", {
      schema: wrapInData(Type.Object({
        genderOptions: Type.Array(Type.String()),
        ageBandOptions: Type.Array(Type.String()),
        adaptiveCategoryOptions: Type.Array(Type.String())
      })),
      cacheTtl: 3e5
    })
  },
  // Hangout Check-ins
  checkins: {
    /**
     * Check in to a hangout
     */
    checkIn: (hangoutId, options) => request(`/hangouts/${hangoutId}/check-in`, {
      method: "POST",
      body: options || {},
      schema: wrapInData(Type.Object({
        id: Type.String(),
        checkInTime: Type.String(),
        message: Type.String()
      }))
    }),
    /**
     * Check out from a hangout
     */
    checkOut: (hangoutId, options) => request(`/hangouts/${hangoutId}/check-out`, {
      method: "POST",
      body: options || {},
      schema: wrapInData(Type.Object({
        checkOutTime: Type.String(),
        duration: Type.Number(),
        message: Type.String()
      }))
    }),
    /**
     * Get active check-ins at a hangout
     */
    activeAt: (hangoutId) => request(`/hangouts/${hangoutId}/check-ins/active`, {
      schema: wrapInData(Type.Array(Type.Object({
        id: Type.String(),
        userId: Type.String(),
        username: Type.String(),
        avatarUrl: Type.Optional(Type.String()),
        checkInTime: Type.String()
      })))
    }),
    /**
     * Get current user's active check-in
     */
    myActive: () => request("/me/check-in", {
      schema: wrapInData(Type.Union([
        Type.Object({
          id: Type.String(),
          hangoutId: Type.Number(),
          hangoutName: Type.String(),
          checkInTime: Type.String()
        }),
        Type.Null()
      ]))
    }),
    /**
     * Get current user's check-in history
     */
    myHistory: (options) => {
      const params = new URLSearchParams();
      if (options?.limit) params.set("limit", String(options.limit));
      if (options?.offset) params.set("offset", String(options.offset));
      const query = params.toString();
      return request(`/me/check-ins${query ? `?${query}` : ""}`, {
        schema: wrapInData(Type.Array(Type.Object({
          id: Type.String(),
          hangoutId: Type.Number(),
          hangoutName: Type.String(),
          checkInTime: Type.String(),
          checkOutTime: Type.Optional(Type.String()),
          duration: Type.Optional(Type.Number()),
          workoutId: Type.Optional(Type.String())
        })))
      });
    }
  },
  /**
   * Generic GET request helper
   */
  get: (path) => request(path),
  /**
   * Generic POST request helper
   */
  post: (path, body) => request(path, { method: "POST", body }),
  /**
   * Generic PUT request helper
   */
  put: (path, body) => request(path, { method: "PUT", body }),
  /**
   * Generic PATCH request helper
   */
  patch: (path, body) => request(path, { method: "PATCH", body }),
  /**
   * Generic DELETE request helper
   */
  delete: (path) => request(path, { method: "DELETE" }),
  // =====================
  // Social Graph
  // =====================
  social: {
    // Follows
    follow: (userId) => request(`/users/${userId}/follow`, { method: "POST" }),
    unfollow: (userId) => request(`/users/${userId}/follow`, { method: "DELETE" }),
    getFollowers: (userId, limit = 50, offset = 0) => request(
      `/users/${userId}/followers?limit=${limit}&offset=${offset}`
    ),
    getFollowing: (userId, limit = 50, offset = 0) => request(
      `/users/${userId}/following?limit=${limit}&offset=${offset}`
    ),
    isFollowing: (userId) => request(`/users/${userId}/is-following`),
    // Friends
    sendFriendRequest: (userId, context) => request(`/users/${userId}/friend-request`, {
      method: "POST",
      body: context
    }),
    acceptFriendRequest: (friendshipId) => request(`/friend-requests/${friendshipId}/accept`, { method: "POST" }),
    declineFriendRequest: (friendshipId) => request(`/friend-requests/${friendshipId}/decline`, { method: "POST" }),
    getPendingFriendRequests: () => request("/friend-requests"),
    getFriends: (limit = 50, offset = 0) => request(
      `/friends?limit=${limit}&offset=${offset}`
    ),
    removeFriend: (friendId) => request(`/friends/${friendId}`, { method: "DELETE" }),
    blockUser: (userId) => request(`/users/${userId}/block`, { method: "POST" }),
    // Buddy
    getBuddyPreferences: () => request("/buddy/preferences"),
    updateBuddyPreferences: (prefs) => request("/buddy/preferences", { method: "PUT", body: prefs }),
    findBuddyMatches: (limit = 20) => request(`/buddy/matches?limit=${limit}`),
    sendBuddyRequest: (userId, message) => request(`/users/${userId}/buddy-request`, {
      method: "POST",
      body: message ? { message } : void 0
    }),
    getPendingBuddyRequests: () => request("/buddy/requests"),
    acceptBuddyRequest: (requestId) => request(`/buddy/requests/${requestId}/accept`, { method: "POST" }),
    declineBuddyRequest: (requestId) => request(`/buddy/requests/${requestId}/decline`, { method: "POST" }),
    getBuddyPairs: () => request("/buddy/pairs")
  },
  // =====================
  // Mentorship
  // =====================
  mentorship: {
    // Mentor search
    searchMentors: (options) => {
      const params = new URLSearchParams();
      if (options?.specialties) params.set("specialties", options.specialties.join(","));
      if (options?.minRating) params.set("minRating", String(options.minRating));
      if (options?.isPro !== void 0) params.set("isPro", String(options.isPro));
      if (options?.maxHourlyRate) params.set("maxHourlyRate", String(options.maxHourlyRate));
      if (options?.limit) params.set("limit", String(options.limit));
      if (options?.offset) params.set("offset", String(options.offset));
      const query = params.toString();
      return request(
        `/mentors${query ? `?${query}` : ""}`
      );
    },
    getMentor: (userId) => request(`/mentors/${userId}`),
    updateMentorProfile: (profile) => request("/mentor/profile", { method: "PUT", body: profile }),
    // Mentorships
    requestMentorship: (mentorId, options) => request(`/mentors/${mentorId}/request`, {
      method: "POST",
      body: options
    }),
    getPendingRequests: () => request("/mentorship/requests"),
    acceptMentorship: (mentorshipId) => request(`/mentorships/${mentorshipId}/accept`, { method: "POST" }),
    declineMentorship: (mentorshipId) => request(`/mentorships/${mentorshipId}/decline`, { method: "POST" }),
    getActiveMentorships: () => request("/mentorships/active"),
    getMentorshipHistory: (limit = 20, offset = 0) => request(
      `/mentorships/history?limit=${limit}&offset=${offset}`
    ),
    completeMentorship: (mentorshipId, feedback) => request(`/mentorships/${mentorshipId}/complete`, {
      method: "POST",
      body: feedback
    }),
    cancelMentorship: (mentorshipId) => request(`/mentorships/${mentorshipId}/cancel`, { method: "POST" }),
    // Check-ins
    createCheckIn: (mentorshipId, checkIn) => request(`/mentorships/${mentorshipId}/check-ins`, {
      method: "POST",
      body: checkIn
    }),
    getCheckIns: (mentorshipId, limit = 20, offset = 0) => request(
      `/mentorships/${mentorshipId}/check-ins?limit=${limit}&offset=${offset}`
    ),
    completeCheckIn: (checkInId) => request(`/check-ins/${checkInId}/complete`, { method: "POST" })
  },
  // =====================
  // Community Analytics
  // =====================
  communityAnalytics: {
    getDailyAnalytics: (communityId, options) => {
      const params = new URLSearchParams();
      if (options?.startDate) params.set("startDate", options.startDate);
      if (options?.endDate) params.set("endDate", options.endDate);
      if (options?.limit) params.set("limit", String(options.limit));
      const query = params.toString();
      return request(
        `/communities/${communityId}/analytics/daily${query ? `?${query}` : ""}`
      );
    },
    refreshAnalytics: (communityId) => request(`/communities/${communityId}/analytics/refresh`, { method: "POST" }),
    getHealthScore: (communityId) => request(`/communities/${communityId}/health`),
    calculateHealthScore: (communityId) => request(`/communities/${communityId}/health/calculate`, { method: "POST" }),
    getHealthHistory: (communityId, limit = 30) => request(`/communities/${communityId}/health/history?limit=${limit}`),
    getGrowthTrends: (communityId, period = "daily", limit = 12) => request(
      `/communities/${communityId}/analytics/growth?period=${period}&limit=${limit}`
    ),
    getEngagementBreakdown: (communityId, options) => {
      const params = new URLSearchParams();
      if (options?.startDate) params.set("startDate", options.startDate);
      if (options?.endDate) params.set("endDate", options.endDate);
      const query = params.toString();
      return request(
        `/communities/${communityId}/analytics/engagement${query ? `?${query}` : ""}`
      );
    },
    getTopContributors: (communityId, days = 30, limit = 10) => request(
      `/communities/${communityId}/analytics/top-contributors?days=${days}&limit=${limit}`
    ),
    compareCommunities: (communityIds) => request("/analytics/compare", {
      method: "POST",
      body: { communityIds }
    })
  },
  // =====================
  // Community Resources
  // =====================
  communityResources: {
    getResources: (communityId, options) => {
      const params = new URLSearchParams();
      if (options?.resourceType) params.set("resourceType", options.resourceType);
      if (options?.category) params.set("category", options.category);
      if (options?.tags) params.set("tags", options.tags.join(","));
      if (options?.isPinned !== void 0) params.set("isPinned", String(options.isPinned));
      if (options?.searchQuery) params.set("searchQuery", options.searchQuery);
      if (options?.limit) params.set("limit", String(options.limit));
      if (options?.offset) params.set("offset", String(options.offset));
      if (options?.sortBy) params.set("sortBy", options.sortBy);
      const query = params.toString();
      return request(
        `/communities/${communityId}/resources${query ? `?${query}` : ""}`
      );
    },
    getPinnedResources: (communityId) => request(`/communities/${communityId}/resources/pinned`),
    getCategories: (communityId) => request(`/communities/${communityId}/resources/categories`),
    getResource: (resourceId) => request(`/resources/${resourceId}`),
    createResource: (communityId, resource) => request(`/communities/${communityId}/resources`, {
      method: "POST",
      body: resource
    }),
    updateResource: (resourceId, updates) => request(`/resources/${resourceId}`, { method: "PUT", body: updates }),
    deleteResource: (resourceId) => request(`/resources/${resourceId}`, { method: "DELETE" }),
    pinResource: (resourceId) => request(`/resources/${resourceId}/pin`, { method: "POST" }),
    unpinResource: (resourceId) => request(`/resources/${resourceId}/pin`, { method: "DELETE" }),
    markHelpful: (resourceId) => request(`/resources/${resourceId}/helpful`, { method: "POST" }),
    removeHelpful: (resourceId) => request(`/resources/${resourceId}/helpful`, { method: "DELETE" }),
    getMostHelpful: (options) => {
      const params = new URLSearchParams();
      if (options?.limit) params.set("limit", String(options.limit));
      if (options?.communityIds) params.set("communityIds", options.communityIds.join(","));
      const query = params.toString();
      return request(`/resources/most-helpful${query ? `?${query}` : ""}`);
    }
  },
  // =====================
  // Content Reports (Moderation)
  // =====================
  reports: {
    submit: (report) => request("/reports", { method: "POST", body: report }),
    getMyReports: () => request("/reports/my"),
    // Moderation (admin only)
    getPendingReports: (options) => {
      const params = new URLSearchParams();
      if (options?.communityId) params.set("communityId", String(options.communityId));
      if (options?.status) params.set("status", Array.isArray(options.status) ? options.status.join(",") : options.status);
      if (options?.reason) params.set("reason", options.reason);
      if (options?.limit) params.set("limit", String(options.limit));
      if (options?.offset) params.set("offset", String(options.offset));
      const query = params.toString();
      return request(
        `/reports${query ? `?${query}` : ""}`
      );
    },
    getReport: (reportId) => request(`/reports/${reportId}`),
    assignReport: (reportId) => request(`/reports/${reportId}/assign`, { method: "POST" }),
    resolveReport: (reportId, resolution) => request(`/reports/${reportId}/resolve`, { method: "POST", body: resolution }),
    getStats: (communityId) => {
      const params = communityId ? `?communityId=${communityId}` : "";
      return request(`/reports/stats${params}`);
    },
    // User moderation
    getUserModerationHistory: (userId) => request(`/users/${userId}/moderation-history`),
    getUserModerationStatus: (userId) => request(`/users/${userId}/moderation-status`),
    applyModerationAction: (userId, action) => request(`/users/${userId}/moderate`, {
      method: "POST",
      body: action
    })
  },
  // =====================
  // Archetype Communities
  // =====================
  archetypeCommunities: {
    getSuggestedCommunities: () => request("/archetype/suggested-communities"),
    handleArchetypeChange: (newArchetypeId, options) => request("/archetype/change", {
      method: "POST",
      body: { newArchetypeId, ...options }
    }),
    getLinkedCommunities: (archetypeId) => request(`/archetypes/${archetypeId}/communities`),
    getDefaultCommunities: (archetypeId) => request(`/archetypes/${archetypeId}/communities/default`),
    linkCommunity: (archetypeId, communityId, options) => request(`/archetypes/${archetypeId}/communities`, {
      method: "POST",
      body: { communityId, ...options }
    }),
    bulkLinkCommunities: (archetypeId, links) => request(`/archetypes/${archetypeId}/communities/bulk`, {
      method: "POST",
      body: { links }
    }),
    unlinkCommunity: (archetypeId, communityId) => request(`/archetypes/${archetypeId}/communities/${communityId}`, { method: "DELETE" }),
    getAllArchetypesWithCommunities: () => request("/archetypes/communities")
  },
  // =====================
  // Skills (Gymnastics/Calisthenics Progression)
  // =====================
  skills: {
    /** Get all skill trees */
    getTrees: () => request("/skills/trees", { cacheTtl: 3e5 }),
    /** Get a specific skill tree with all nodes */
    getTree: (treeId) => request(`/skills/trees/${treeId}`, { cacheTtl: 3e5 }),
    /** Get user's progress for a skill tree */
    getTreeProgress: (treeId) => request(`/skills/trees/${treeId}/progress`),
    /** Get a specific skill node */
    getNode: (nodeId) => request(`/skills/nodes/${nodeId}`, { cacheTtl: 3e5 }),
    /** Get leaderboard for a skill */
    getNodeLeaderboard: (nodeId, limit = 10) => request(`/skills/nodes/${nodeId}/leaderboard?limit=${limit}`),
    /** Get user's overall skill progress summary */
    getProgress: () => request("/skills/progress"),
    /** Log a practice session */
    logPractice: (data) => request("/skills/practice", {
      method: "POST",
      body: data
    }),
    /** Mark a skill as achieved */
    achieveSkill: (data) => request("/skills/achieve", {
      method: "POST",
      body: data
    }),
    /** Get practice history */
    getHistory: (options) => request(
      `/skills/history?limit=${options?.limit ?? 20}&offset=${options?.offset ?? 0}${options?.skillNodeId ? `&skillNodeId=${options.skillNodeId}` : ""}`
    ),
    /** Update notes for a skill */
    updateNotes: (nodeId, notes) => request(`/skills/nodes/${nodeId}/notes`, {
      method: "PUT",
      body: { notes }
    })
  },
  // Ranks & XP System
  ranks: {
    /** Get all rank definitions */
    definitions: () => request("/ranks/definitions", {
      cacheTtl: 3e5
      // Cache for 5 minutes
    }),
    /** Get current user's rank info */
    me: () => request("/ranks/me"),
    /** Get another user's rank info */
    getUser: (userId) => request(`/ranks/user/${userId}`),
    /** Get XP history */
    history: (options) => {
      const params = new URLSearchParams();
      if (options?.limit) params.set("limit", String(options.limit));
      if (options?.offset) params.set("offset", String(options.offset));
      if (options?.sourceType) params.set("sourceType", options.sourceType);
      const query = params.toString();
      return request(
        `/ranks/history${query ? `?${query}` : ""}`
      );
    },
    /** Get XP-based leaderboard */
    leaderboard: (options) => {
      const params = new URLSearchParams();
      if (options?.scope) params.set("scope", options.scope);
      if (options?.country) params.set("country", options.country);
      if (options?.state) params.set("state", options.state);
      if (options?.city) params.set("city", options.city);
      if (options?.limit) params.set("limit", String(options.limit));
      if (options?.offset) params.set("offset", String(options.offset));
      const query = params.toString();
      return request(`/ranks/leaderboard${query ? `?${query}` : ""}`);
    },
    /** Get veteran badge info */
    veteranBadge: () => request("/ranks/veteran-badge")
  },
  // Feedback System (Bug Reports, Feature Requests, Questions, FAQ)
  feedback: {
    /** Create new feedback (bug report, feature request, question, general) */
    create: (payload) => request("/feedback", {
      method: "POST",
      body: payload
    }),
    /** List user's own feedback */
    list: (options) => {
      const params = new URLSearchParams();
      if (options?.type) params.set("type", options.type);
      if (options?.status) params.set("status", options.status);
      if (options?.limit) params.set("limit", String(options.limit));
      if (options?.cursor) params.set("cursor", options.cursor);
      const query = params.toString();
      return request(
        `/feedback${query ? `?${query}` : ""}`
      );
    },
    /** Get single feedback with responses */
    get: (id) => request(`/feedback/${id}`),
    /** Add response to own feedback (follow-up) */
    respond: (id, message) => request(`/feedback/${id}/respond`, {
      method: "POST",
      body: { message }
    }),
    /** Get popular feature requests */
    popularFeatures: (limit = 10) => request(`/feedback/features/popular?limit=${limit}`),
    /** Upvote a feature request */
    upvote: (id) => request(`/feedback/${id}/upvote`, {
      method: "POST"
    }),
    /** Remove upvote from a feature request */
    removeUpvote: (id) => request(`/feedback/${id}/upvote`, {
      method: "DELETE"
    }),
    /** Get FAQ entries */
    getFaq: (options) => {
      const params = new URLSearchParams();
      if (options?.category) params.set("category", options.category);
      if (options?.search) params.set("search", options.search);
      const query = params.toString();
      return request(
        `/faq${query ? `?${query}` : ""}`,
        { cacheTtl: 3e5 }
      );
    },
    /** Get FAQ categories */
    faqCategories: () => request("/faq/categories", {
      cacheTtl: 3e5
    }),
    /** Get single FAQ entry (increments view count) */
    getFaqEntry: (id) => request(`/faq/${id}`),
    /** Mark FAQ as helpful or not helpful */
    markFaqHelpful: (id, helpful) => request(`/faq/${id}/helpful`, {
      method: "POST",
      body: { helpful }
    }),
    /** Search FAQ and feature requests */
    search: (query) => request(`/feedback/search?q=${encodeURIComponent(query)}`)
  }
};
var VirtualHangoutThemeSchema = Type.Object({
  id: Type.String(),
  name: Type.String(),
  tagline: Type.Optional(Type.String()),
  description: Type.Optional(Type.String()),
  primaryColor: Type.String(),
  secondaryColor: Type.String(),
  accentColor: Type.String(),
  backgroundImageUrl: Type.Optional(Type.String()),
  iconUrl: Type.Optional(Type.String()),
  bannerUrl: Type.Optional(Type.String()),
  archetypeCategoryId: Type.Optional(Type.String()),
  goalTypes: Type.Array(Type.String()),
  targetAudiences: Type.Array(Type.String()),
  isActive: Type.Boolean()
}, { additionalProperties: true });
var VirtualHangoutSchema = Type.Object({
  id: Type.Number(),
  themeId: Type.String(),
  themeName: Type.String(),
  customName: Type.Optional(Type.String()),
  customDescription: Type.Optional(Type.String()),
  customBannerUrl: Type.Optional(Type.String()),
  primaryColor: Type.String(),
  accentColor: Type.String(),
  memberCount: Type.Number(),
  activeMemberCount: Type.Number(),
  postCount: Type.Number(),
  isActive: Type.Boolean(),
  createdAt: Type.String(),
  updatedAt: Type.String(),
  isMember: Type.Optional(Type.Boolean()),
  userRole: Type.Optional(Type.Number()),
  lastVisitedAt: Type.Optional(Type.String())
}, { additionalProperties: true });
var HangoutMemberSchema = Type.Object({
  userId: Type.String(),
  username: Type.String(),
  displayName: Type.Optional(Type.String()),
  avatarUrl: Type.Optional(Type.String()),
  role: Type.Number(),
  joinedAt: Type.String(),
  lastActiveAt: Type.Optional(Type.String()),
  showInMemberList: Type.Boolean(),
  receiveNotifications: Type.Boolean()
}, { additionalProperties: true });
var HangoutActivitySchema = Type.Object({
  id: Type.String(),
  hangoutId: Type.Number(),
  userId: Type.Optional(Type.String()),
  username: Type.Optional(Type.String()),
  activityType: Type.String(),
  activityData: Type.Record(Type.String(), Type.Any()),
  createdAt: Type.String()
}, { additionalProperties: true });
var CommunitySchema = Type.Object({
  id: Type.Number(),
  slug: Type.String(),
  name: Type.String(),
  tagline: Type.Optional(Type.String()),
  description: Type.Optional(Type.String()),
  communityType: Type.String(),
  goalType: Type.Optional(Type.String()),
  institutionType: Type.Optional(Type.String()),
  archetypeId: Type.Optional(Type.Number()),
  privacy: Type.String(),
  iconEmoji: Type.String(),
  accentColor: Type.String(),
  bannerImageUrl: Type.Optional(Type.String()),
  logoImageUrl: Type.Optional(Type.String()),
  rules: Type.Optional(Type.String()),
  memberCount: Type.Number(),
  postCount: Type.Number(),
  isVerified: Type.Boolean(),
  isActive: Type.Boolean(),
  requiresApproval: Type.Boolean(),
  allowMemberPosts: Type.Boolean(),
  createdBy: Type.String(),
  createdAt: Type.String(),
  updatedAt: Type.String(),
  isMember: Type.Optional(Type.Boolean()),
  userRole: Type.Optional(Type.Number()),
  membershipStatus: Type.Optional(Type.String())
}, { additionalProperties: true });
var CommunityMemberSchema = Type.Object({
  userId: Type.String(),
  username: Type.String(),
  displayName: Type.Optional(Type.String()),
  avatarUrl: Type.Optional(Type.String()),
  role: Type.Number(),
  title: Type.Optional(Type.String()),
  status: Type.String(),
  joinedAt: Type.String(),
  lastActiveAt: Type.Optional(Type.String()),
  showInMemberList: Type.Boolean()
}, { additionalProperties: true });
var CommunityEventSchema = Type.Object({
  id: Type.String(),
  communityId: Type.Number(),
  virtualHangoutId: Type.Optional(Type.Number()),
  creatorId: Type.String(),
  title: Type.String(),
  description: Type.Optional(Type.String()),
  eventType: Type.String(),
  startsAt: Type.String(),
  endsAt: Type.Optional(Type.String()),
  timezone: Type.String(),
  locationName: Type.Optional(Type.String()),
  locationAddress: Type.Optional(Type.String()),
  isVirtual: Type.Boolean(),
  virtualUrl: Type.Optional(Type.String()),
  maxParticipants: Type.Optional(Type.Number()),
  participantCount: Type.Number(),
  status: Type.String(),
  createdAt: Type.String()
}, { additionalProperties: true });
var BulletinPostSchema = Type.Object({
  id: Type.String(),
  boardId: Type.Number(),
  authorId: Type.Optional(Type.String()),
  authorUsername: Type.Optional(Type.String()),
  authorDisplayName: Type.Optional(Type.String()),
  authorAvatarUrl: Type.Optional(Type.String()),
  title: Type.String(),
  content: Type.String(),
  contentLang: Type.String(),
  postType: Type.String(),
  mediaUrls: Type.Array(Type.String()),
  linkedWorkoutId: Type.Optional(Type.String()),
  linkedMilestoneId: Type.Optional(Type.String()),
  upvotes: Type.Number(),
  downvotes: Type.Number(),
  score: Type.Number(),
  commentCount: Type.Number(),
  viewCount: Type.Number(),
  isPinned: Type.Boolean(),
  isHighlighted: Type.Boolean(),
  isHidden: Type.Boolean(),
  createdAt: Type.String(),
  updatedAt: Type.String(),
  userVote: Type.Optional(Type.String())
}, { additionalProperties: true });
var BulletinCommentSchema = Type.Object({
  id: Type.String(),
  postId: Type.String(),
  parentId: Type.Optional(Type.String()),
  authorId: Type.Optional(Type.String()),
  authorUsername: Type.Optional(Type.String()),
  authorDisplayName: Type.Optional(Type.String()),
  authorAvatarUrl: Type.Optional(Type.String()),
  content: Type.String(),
  upvotes: Type.Number(),
  downvotes: Type.Number(),
  score: Type.Number(),
  replyCount: Type.Number(),
  isHidden: Type.Boolean(),
  createdAt: Type.String(),
  updatedAt: Type.String(),
  userVote: Type.Optional(Type.String()),
  replies: Type.Optional(Type.Array(Type.Any()))
}, { additionalProperties: true });

// src/hooks/useWebSocket.ts
import { useState, useEffect, useRef, useCallback } from "react";
var WS_RECONNECT_DELAY = 3e3;
var WS_MAX_RECONNECT_ATTEMPTS = 5;
var WS_HEARTBEAT_INTERVAL = 3e4;
function buildWebSocketUrl(endpoint, token, baseUrl) {
  let url;
  if (baseUrl) {
    const wsProtocol = baseUrl.startsWith("https") ? "wss:" : "ws:";
    const host = baseUrl.replace(/^https?:\/\//, "");
    url = `${wsProtocol}//${host}${endpoint}`;
  } else if (typeof window !== "undefined") {
    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    url = `${protocol}//${window.location.host}${endpoint}`;
  } else {
    throw new Error("WebSocket URL cannot be determined. Provide baseUrl option.");
  }
  if (token) {
    url += `?token=${encodeURIComponent(token)}`;
  }
  return url;
}
function useWebSocket(endpoint, options = {}) {
  const { autoConnect = true, onMessage, onSnapshot, token, baseUrl } = options;
  const [connected, setConnected] = useState(false);
  const [error, setError] = useState(null);
  const [snapshot, setSnapshot] = useState(null);
  const [events, setEvents] = useState([]);
  const wsRef = useRef(null);
  const reconnectAttempts = useRef(0);
  const reconnectTimeout = useRef(null);
  const connect = useCallback(() => {
    if (wsRef.current?.readyState === WebSocket.OPEN) return;
    try {
      const url = buildWebSocketUrl(endpoint, token, baseUrl);
      const ws = new WebSocket(url);
      wsRef.current = ws;
      ws.onopen = () => {
        setConnected(true);
        setError(null);
        reconnectAttempts.current = 0;
      };
      ws.onmessage = (event) => {
        try {
          const data = JSON.parse(event.data);
          if (data.type === "snapshot") {
            setSnapshot(data.data);
            onSnapshot?.(data.data);
          } else if (data.type === "event") {
            setEvents((prev) => [data.data, ...prev].slice(0, 100));
            onMessage?.(data.data);
          }
        } catch (err) {
          console.error("Failed to parse WebSocket message:", err);
        }
      };
      ws.onerror = () => {
        setError("Connection error");
      };
      ws.onclose = (event) => {
        setConnected(false);
        wsRef.current = null;
        if (event.code !== 1e3 && reconnectAttempts.current < WS_MAX_RECONNECT_ATTEMPTS) {
          reconnectAttempts.current += 1;
          reconnectTimeout.current = setTimeout(connect, WS_RECONNECT_DELAY);
        }
      };
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to connect");
    }
  }, [endpoint, token, baseUrl, onMessage, onSnapshot]);
  const disconnect = useCallback(() => {
    if (reconnectTimeout.current) {
      clearTimeout(reconnectTimeout.current);
      reconnectTimeout.current = null;
    }
    if (wsRef.current) {
      wsRef.current.close(1e3);
      wsRef.current = null;
    }
    setConnected(false);
  }, []);
  const sendHeartbeat = useCallback(() => {
    if (wsRef.current?.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify({ type: "heartbeat" }));
    }
  }, []);
  useEffect(() => {
    if (autoConnect) {
      connect();
    }
    return () => {
      disconnect();
    };
  }, [autoConnect, connect, disconnect]);
  useEffect(() => {
    if (!connected) return;
    const interval = setInterval(sendHeartbeat, WS_HEARTBEAT_INTERVAL);
    return () => clearInterval(interval);
  }, [connected, sendHeartbeat]);
  return {
    connected,
    error,
    snapshot,
    events,
    connect,
    disconnect,
    sendHeartbeat
  };
}

// src/hooks/useAuth.ts
import { useState as useState2, useEffect as useEffect2, useCallback as useCallback2, useMemo } from "react";
async function getAuthFromStorage() {
  try {
    const storage = getStorageAdapter();
    const [token, userJson] = await Promise.all([
      storage.getItem(STORAGE_KEYS.TOKEN),
      storage.getItem(STORAGE_KEYS.USER)
    ]);
    let user = null;
    if (userJson) {
      try {
        user = JSON.parse(userJson);
      } catch {
        user = null;
      }
    }
    return { token, user };
  } catch {
    return { token: null, user: null };
  }
}
async function saveAuthToStorage(token, user) {
  const storage = getStorageAdapter();
  await Promise.all([
    storage.setItem(STORAGE_KEYS.TOKEN, token),
    storage.setItem(STORAGE_KEYS.USER, JSON.stringify(user))
  ]);
}
async function clearAuthFromStorage() {
  const storage = getStorageAdapter();
  await Promise.all([
    storage.removeItem(STORAGE_KEYS.TOKEN),
    storage.removeItem(STORAGE_KEYS.USER)
  ]);
}
function useAuth(options = {}) {
  const { onLogout } = options;
  const [user, setUser] = useState2(null);
  const [token, setToken] = useState2(null);
  const [isLoading, setIsLoading] = useState2(true);
  const isAuthenticated = useMemo(() => Boolean(token && user), [token, user]);
  const refreshFromStorage = useCallback2(async () => {
    setIsLoading(true);
    try {
      const { token: storedToken, user: storedUser } = await getAuthFromStorage();
      setToken(storedToken);
      setUser(storedUser);
    } finally {
      setIsLoading(false);
    }
  }, []);
  const login = useCallback2(async (response) => {
    await saveAuthToStorage(response.token, response.user);
    setToken(response.token);
    setUser(response.user);
  }, []);
  const logout = useCallback2(async () => {
    await clearAuthFromStorage();
    setToken(null);
    setUser(null);
    await onLogout?.();
  }, [onLogout]);
  const updateUser = useCallback2(
    async (updates) => {
      if (!user || !token) return;
      const updatedUser = { ...user, ...updates };
      await saveAuthToStorage(token, updatedUser);
      setUser(updatedUser);
    },
    [user, token]
  );
  useEffect2(() => {
    refreshFromStorage();
  }, [refreshFromStorage]);
  return {
    user,
    token,
    isAuthenticated,
    isLoading,
    login,
    logout,
    updateUser,
    refreshFromStorage
  };
}
var auth = {
  getToken: async () => {
    const { token } = await getAuthFromStorage();
    return token;
  },
  getUser: async () => {
    const { user } = await getAuthFromStorage();
    return user;
  },
  setAuth: async (token, user) => {
    await saveAuthToStorage(token, user);
  },
  clearAuth: async () => {
    await clearAuthFromStorage();
  },
  isAuthenticated: async () => {
    const { token, user } = await getAuthFromStorage();
    return Boolean(token && user);
  }
};
export {
  STORAGE_KEYS,
  Type,
  apiClient,
  apiHelpers,
  applySchema,
  auth,
  clearRequestCache,
  configureHttpClient,
  getStorageAdapter,
  hasStorageAdapter,
  isValidationSchema,
  parseWithSchema,
  request,
  setStorageAdapter,
  useAuth,
  useWebSocket
};
//# sourceMappingURL=index.mjs.map