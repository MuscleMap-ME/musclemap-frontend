// src/storage/native.ts
var SecureStore = null;
async function getSecureStore() {
  if (!SecureStore) {
    SecureStore = await import("expo-secure-store");
  }
  return SecureStore;
}
var NativeStorageAdapter = class {
  async getItem(key) {
    const store = await getSecureStore();
    return store.getItemAsync(key);
  }
  async setItem(key, value) {
    const store = await getSecureStore();
    await store.setItemAsync(key, value);
  }
  async removeItem(key) {
    const store = await getSecureStore();
    await store.deleteItemAsync(key);
  }
  async clear() {
    const store = await getSecureStore();
    const { STORAGE_KEYS } = await import("../types-RFMCECV2.mjs");
    await Promise.all([
      store.deleteItemAsync(STORAGE_KEYS.TOKEN),
      store.deleteItemAsync(STORAGE_KEYS.USER)
    ]);
  }
};
var nativeStorage = new NativeStorageAdapter();
export {
  NativeStorageAdapter,
  nativeStorage
};
//# sourceMappingURL=native.mjs.map