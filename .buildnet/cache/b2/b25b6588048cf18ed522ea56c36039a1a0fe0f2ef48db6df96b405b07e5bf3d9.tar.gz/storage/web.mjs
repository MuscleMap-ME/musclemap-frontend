// src/storage/web.ts
var WebStorageAdapter = class {
  async getItem(key) {
    if (typeof window === "undefined") {
      return null;
    }
    return localStorage.getItem(key);
  }
  async setItem(key, value) {
    if (typeof window === "undefined") {
      return;
    }
    localStorage.setItem(key, value);
  }
  async removeItem(key) {
    if (typeof window === "undefined") {
      return;
    }
    localStorage.removeItem(key);
  }
  async clear() {
    if (typeof window === "undefined") {
      return;
    }
    localStorage.clear();
  }
};
var webStorage = new WebStorageAdapter();
export {
  WebStorageAdapter,
  webStorage
};
//# sourceMappingURL=web.mjs.map