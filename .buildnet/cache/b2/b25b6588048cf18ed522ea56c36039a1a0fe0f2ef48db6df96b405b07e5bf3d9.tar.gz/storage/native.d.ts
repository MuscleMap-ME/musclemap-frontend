import { S as StorageAdapter } from '../types-B8_KDbOr.js';

/**
 * Native Storage Adapter
 *
 * expo-secure-store implementation for React Native
 * This file will be used in apps/mobile
 */

declare class NativeStorageAdapter implements StorageAdapter {
    getItem(key: string): Promise<string | null>;
    setItem(key: string, value: string): Promise<void>;
    removeItem(key: string): Promise<void>;
    clear(): Promise<void>;
}
/**
 * Default native storage adapter instance
 */
declare const nativeStorage: NativeStorageAdapter;

export { NativeStorageAdapter, nativeStorage };
