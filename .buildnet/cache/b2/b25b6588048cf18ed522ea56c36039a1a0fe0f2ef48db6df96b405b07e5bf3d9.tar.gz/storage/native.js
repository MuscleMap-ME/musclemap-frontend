"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __esm = (fn, res) => function __init() {
  return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// src/storage/types.ts
var types_exports = {};
__export(types_exports, {
  STORAGE_KEYS: () => STORAGE_KEYS,
  getStorageAdapter: () => getStorageAdapter,
  hasStorageAdapter: () => hasStorageAdapter,
  setStorageAdapter: () => setStorageAdapter
});
function setStorageAdapter(adapter) {
  globalStorage = adapter;
}
function getStorageAdapter() {
  if (!globalStorage) {
    throw new Error(
      "Storage adapter not initialized. Call setStorageAdapter() before using auth/http modules."
    );
  }
  return globalStorage;
}
function hasStorageAdapter() {
  return globalStorage !== null;
}
var STORAGE_KEYS, globalStorage;
var init_types = __esm({
  "src/storage/types.ts"() {
    "use strict";
    STORAGE_KEYS = {
      TOKEN: "musclemap_token",
      USER: "musclemap_user"
    };
    globalStorage = null;
  }
});

// src/storage/native.ts
var native_exports = {};
__export(native_exports, {
  NativeStorageAdapter: () => NativeStorageAdapter,
  nativeStorage: () => nativeStorage
});
module.exports = __toCommonJS(native_exports);
var SecureStore = null;
async function getSecureStore() {
  if (!SecureStore) {
    SecureStore = await import("expo-secure-store");
  }
  return SecureStore;
}
var NativeStorageAdapter = class {
  async getItem(key) {
    const store = await getSecureStore();
    return store.getItemAsync(key);
  }
  async setItem(key, value) {
    const store = await getSecureStore();
    await store.setItemAsync(key, value);
  }
  async removeItem(key) {
    const store = await getSecureStore();
    await store.deleteItemAsync(key);
  }
  async clear() {
    const store = await getSecureStore();
    const { STORAGE_KEYS: STORAGE_KEYS2 } = await Promise.resolve().then(() => (init_types(), types_exports));
    await Promise.all([
      store.deleteItemAsync(STORAGE_KEYS2.TOKEN),
      store.deleteItemAsync(STORAGE_KEYS2.USER)
    ]);
  }
};
var nativeStorage = new NativeStorageAdapter();
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  NativeStorageAdapter,
  nativeStorage
});
//# sourceMappingURL=native.js.map