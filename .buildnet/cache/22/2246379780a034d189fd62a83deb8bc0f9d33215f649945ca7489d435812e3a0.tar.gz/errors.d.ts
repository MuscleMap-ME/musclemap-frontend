export declare const DEFAULT_ERROR_MESSAGE = "Something went wrong";
export declare function safeStringify(value: unknown, maxLen?: number): string;
export declare function extractErrorMessage(input: unknown, fallback?: string): string;
//# sourceMappingURL=errors.d.ts.map