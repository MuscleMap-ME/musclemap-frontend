/**
 * Unit Conversion Utilities
 *
 * Comprehensive unit conversion system for MuscleMap.
 * All internal storage uses metric (kg, cm) - conversions happen at display layer.
 */
import type { WeightUnit, DistanceUnit, UnitsPreferences } from './preferences.js';
export type { WeightUnit, DistanceUnit, UnitsPreferences };
export type HeightUnit = 'ft_in' | 'cm';
export type LengthUnit = 'in' | 'cm';
export type TemperatureUnit = 'f' | 'c';
export declare const CONVERSIONS: {
    readonly KG_TO_LBS: 2.20462;
    readonly LBS_TO_KG: 0.453592;
    readonly CM_TO_IN: 0.393701;
    readonly IN_TO_CM: 2.54;
    readonly CM_TO_FT: 0.0328084;
    readonly FT_TO_CM: 30.48;
    readonly KM_TO_MI: 0.621371;
    readonly MI_TO_KM: 1.60934;
    readonly ML_TO_OZ: 0.033814;
    readonly OZ_TO_ML: 29.5735;
};
/**
 * Convert kilograms to pounds
 */
export declare function kgToLbs(kg: number): number;
/**
 * Convert pounds to kilograms
 */
export declare function lbsToKg(lbs: number): number;
/**
 * Convert weight based on unit preference
 * @param valueKg - Value in kilograms (storage unit)
 * @param toUnit - Target display unit
 */
export declare function convertWeight(valueKg: number, toUnit: WeightUnit): number;
/**
 * Convert weight from display unit to storage unit (kg)
 * @param value - Value in display unit
 * @param fromUnit - Source display unit
 */
export declare function weightToKg(value: number, fromUnit: WeightUnit): number;
/**
 * Convert centimeters to inches
 */
export declare function cmToIn(cm: number): number;
/**
 * Convert inches to centimeters
 */
export declare function inToCm(inches: number): number;
/**
 * Convert centimeters to feet and inches
 * @returns Object with feet and inches
 */
export declare function cmToFtIn(cm: number): {
    feet: number;
    inches: number;
};
/**
 * Convert feet and inches to centimeters
 */
export declare function ftInToCm(feet: number, inches?: number): number;
/**
 * Convert length/circumference based on unit preference
 * @param valueCm - Value in centimeters (storage unit)
 * @param toUnit - Target display unit ('cm' or 'in')
 */
export declare function convertLength(valueCm: number, toUnit: LengthUnit): number;
/**
 * Convert length from display unit to storage unit (cm)
 * @param value - Value in display unit
 * @param fromUnit - Source display unit
 */
export declare function lengthToCm(value: number, fromUnit: LengthUnit): number;
/**
 * Convert height based on unit preference
 * @param valueCm - Value in centimeters (storage unit)
 * @param toUnit - Target display unit
 */
export declare function convertHeight(valueCm: number, toUnit: HeightUnit): string;
/**
 * Convert kilometers to miles
 */
export declare function kmToMi(km: number): number;
/**
 * Convert miles to kilometers
 */
export declare function miToKm(mi: number): number;
/**
 * Convert distance based on unit preference
 * @param valueKm - Value in kilometers (storage unit)
 * @param toUnit - Target display unit
 */
export declare function convertDistance(valueKm: number, toUnit: DistanceUnit): number;
/**
 * Convert Celsius to Fahrenheit
 */
export declare function cToF(celsius: number): number;
/**
 * Convert Fahrenheit to Celsius
 */
export declare function fToC(fahrenheit: number): number;
/**
 * Format weight value with unit
 */
export declare function formatWeight(valueKg: number, unit: WeightUnit, decimals?: number): string;
/**
 * Format length/circumference value with unit
 */
export declare function formatLength(valueCm: number, unit: LengthUnit, decimals?: number): string;
/**
 * Format distance value with unit
 */
export declare function formatDistance(valueKm: number, unit: DistanceUnit, decimals?: number): string;
export declare const UNIT_LABELS: {
    readonly weight: {
        readonly kg: "Kilograms (kg)";
        readonly lbs: "Pounds (lbs)";
    };
    readonly length: {
        readonly cm: "Centimeters (cm)";
        readonly in: "Inches (in)";
    };
    readonly height: {
        readonly cm: "Centimeters (cm)";
        readonly ft_in: "Feet & Inches (ft'in\")";
    };
    readonly distance: {
        readonly km: "Kilometers (km)";
        readonly mi: "Miles (mi)";
    };
    readonly temperature: {
        readonly c: "Celsius (°C)";
        readonly f: "Fahrenheit (°F)";
    };
};
/**
 * Get display label for a measurement based on unit system
 * Used for form field labels like "Weight (kg)" or "Weight (lbs)"
 */
export declare function getMeasurementLabel(baseName: string, fieldType: 'weight' | 'length' | 'percentage', units: {
    weight: WeightUnit;
    height: HeightUnit;
}): string;
/**
 * Get the length unit based on height preference
 * If user prefers cm for height, they likely want cm for circumferences
 * If user prefers ft/in for height, they likely want inches for circumferences
 */
export declare function getLengthUnitFromHeightPref(heightPref: HeightUnit): LengthUnit;
export interface MeasurementFieldConfig {
    key: string;
    label: string;
    baseUnit: 'kg' | 'cm' | 'percent';
    category: 'weight' | 'composition' | 'upper' | 'lower';
}
export declare const BODY_MEASUREMENT_FIELDS: MeasurementFieldConfig[];
/**
 * Get display unit for a measurement field
 */
export declare function getDisplayUnitForField(field: MeasurementFieldConfig, units: {
    weight: WeightUnit;
    height: HeightUnit;
}): string;
/**
 * Convert a measurement value for display
 */
export declare function convertMeasurementForDisplay(value: number, field: MeasurementFieldConfig, units: {
    weight: WeightUnit;
    height: HeightUnit;
}): number;
/**
 * Convert a measurement value from display unit to storage unit
 */
export declare function convertMeasurementToStorage(value: number, field: MeasurementFieldConfig, units: {
    weight: WeightUnit;
    height: HeightUnit;
}): number;
//# sourceMappingURL=units.d.ts.map