/**
 * Rank System Types
 *
 * Shared types for the MuscleMap ranking/leveling system.
 * Used by both API and frontend.
 */
// Rank tier constants
export const RANK_TIERS = {
    NOVICE: 1,
    TRAINEE: 2,
    APPRENTICE: 3,
    PRACTITIONER: 4,
    JOURNEYPERSON: 5,
    EXPERT: 6,
    MASTER: 7,
    GRANDMASTER: 8,
};
// Rank badge visual info (for frontend rendering)
export const RANK_BADGE_VISUALS = {
    novice: { type: 'chevron', count: 0, variant: 'outline', color: '#6B7280' },
    trainee: { type: 'chevron', count: 1, color: '#22C55E' },
    apprentice: { type: 'chevron', count: 2, color: '#3B82F6' },
    practitioner: { type: 'chevron', count: 3, color: '#8B5CF6' },
    journeyperson: { type: 'star', count: 1, variant: 'bronze', color: '#EAB308' },
    expert: { type: 'star', count: 1, variant: 'silver', color: '#F97316' },
    master: { type: 'star', count: 2, variant: 'gold', color: '#EF4444' },
    grandmaster: { type: 'shield', count: 1, variant: 'diamond', color: '#EC4899' },
};
// Veteran badge visuals
export const VETERAN_BADGE_VISUALS = {
    0: { label: null, icon: '', color: '' },
    1: { label: '6 Months', icon: 'veteran-bronze', color: '#CD7F32' },
    2: { label: '1 Year', icon: 'veteran-silver', color: '#C0C0C0' },
    3: { label: '2+ Years', icon: 'veteran-gold', color: '#FFD700' },
};
//# sourceMappingURL=ranks.js.map