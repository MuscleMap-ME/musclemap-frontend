export {};
//# sourceMappingURL=errors.test.d.ts.map