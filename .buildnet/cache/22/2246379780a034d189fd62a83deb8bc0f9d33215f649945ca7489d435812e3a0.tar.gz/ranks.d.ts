/**
 * Rank System Types
 *
 * Shared types for the MuscleMap ranking/leveling system.
 * Used by both API and frontend.
 */
export declare const RANK_TIERS: {
    readonly NOVICE: 1;
    readonly TRAINEE: 2;
    readonly APPRENTICE: 3;
    readonly PRACTITIONER: 4;
    readonly JOURNEYPERSON: 5;
    readonly EXPERT: 6;
    readonly MASTER: 7;
    readonly GRANDMASTER: 8;
};
export type RankTier = (typeof RANK_TIERS)[keyof typeof RANK_TIERS];
export type RankName = 'novice' | 'trainee' | 'apprentice' | 'practitioner' | 'journeyperson' | 'expert' | 'master' | 'grandmaster';
export type XpSourceType = 'workout' | 'goal' | 'archetype' | 'streak' | 'achievement' | 'special' | 'backfill' | 'admin';
export interface RankDefinition {
    id: string;
    tier: RankTier;
    name: RankName;
    displayName: string;
    xpThreshold: number;
    badgeIcon: string;
    badgeColor: string;
    perks: string[];
}
export interface UserRankInfo {
    userId: string;
    currentRank: RankName;
    currentTier: RankTier;
    displayName: string;
    totalXp: number;
    xpToNextRank: number | null;
    progressPercent: number;
    badgeIcon: string;
    badgeColor: string;
    perks: string[];
    nextRank: {
        name: RankName;
        displayName: string;
        xpThreshold: number;
        badgeIcon?: string;
        badgeColor?: string;
    } | null;
    veteranTier: number;
    veteranLabel: string | null;
    rankUpdatedAt: string | null;
    xpToday?: number;
    xpThisWeek?: number;
}
export interface XpHistoryEntry {
    id: string;
    amount: number;
    sourceType: XpSourceType;
    sourceId?: string;
    reason: string;
    createdAt: string;
}
export interface VeteranBadge {
    tier: 0 | 1 | 2 | 3;
    label: string | null;
    icon: string;
    color: string;
    monthsActive: number;
    nextTier?: {
        tier: number;
        monthsRequired: number;
        monthsRemaining: number;
    } | null;
}
export interface RankLeaderboardEntry {
    rank: number;
    userId: string;
    username: string;
    displayName?: string;
    avatarUrl?: string;
    totalXp: number;
    currentRank: RankName;
    badgeIcon: string;
    badgeColor: string;
    veteranTier: number;
    country?: string;
}
export interface RankLeaderboardResponse {
    data: {
        entries: RankLeaderboardEntry[];
        userRank: number | null;
    };
    pagination: {
        total: number;
        limit: number;
        offset: number;
        hasMore: boolean;
    };
    meta: {
        scope: 'global' | 'country' | 'state' | 'city';
        filters: {
            country?: string;
            state?: string;
            city?: string;
        };
    };
}
export interface FieldVisibility {
    showLocation: boolean;
    showGender: boolean;
    showAge: boolean;
    showAbility: boolean;
    showStats: boolean;
    showAchievements: boolean;
    showRank: boolean;
    showWorkouts: boolean;
    showLanguages: boolean;
    showVeteranBadge: boolean;
    showAboutMe: boolean;
}
export interface UserLanguage {
    id: string;
    languageCode: string;
    name: string;
    nativeName: string;
    flagEmoji: string;
    proficiency: 'native' | 'fluent' | 'conversational' | 'basic';
    isPrimary: boolean;
}
export interface LanguageOption {
    code: string;
    name: string;
    nativeName: string;
    flagEmoji: string;
    region?: string;
}
export type ProfileVisibility = 'public' | 'friends' | 'private';
export type LocationVisibility = 'none' | 'country' | 'state' | 'city';
export type AgeBracket = '13-17' | '18-24' | '25-34' | '35-44' | '45-54' | '55-64' | '65+' | 'prefer_not_to_say';
export type AbilityCategory = 'standard' | 'adaptive' | 'wheelchair' | 'visually_impaired' | 'other' | 'prefer_not_to_say';
export interface ExtendedProfile {
    userId: string;
    gender?: string;
    genderCustomLabel?: string;
    ageBracket?: AgeBracket;
    abilityCategory?: AbilityCategory;
    abilityCustomLabel?: string;
    city?: string;
    state?: string;
    country?: string;
    countryCode?: string;
    aboutMe?: string;
    aboutMeVisibility?: ProfileVisibility;
    ghostMode: boolean;
    leaderboardOptIn: boolean;
    profileVisibility: ProfileVisibility;
    locationVisibilityLevel: LocationVisibility;
}
export interface ProfileUpdateRequest {
    displayName?: string;
    avatarUrl?: string;
    gender?: string;
    genderCustomLabel?: string;
    ageBracket?: AgeBracket;
    abilityCategory?: AbilityCategory;
    abilityCustomLabel?: string;
    city?: string;
    state?: string;
    country?: string;
    countryCode?: string;
    aboutMe?: string;
    aboutMeVisibility?: ProfileVisibility;
    ghostMode?: boolean;
    leaderboardOptIn?: boolean;
    profileVisibility?: ProfileVisibility;
    locationVisibilityLevel?: LocationVisibility;
    fieldVisibility?: Partial<FieldVisibility>;
}
export declare const RANK_BADGE_VISUALS: Record<RankName, {
    type: 'chevron' | 'star' | 'shield';
    count: number;
    variant?: 'outline' | 'bronze' | 'silver' | 'gold' | 'diamond';
    color: string;
}>;
export declare const VETERAN_BADGE_VISUALS: Record<0 | 1 | 2 | 3, {
    label: string | null;
    icon: string;
    color: string;
}>;
//# sourceMappingURL=ranks.d.ts.map