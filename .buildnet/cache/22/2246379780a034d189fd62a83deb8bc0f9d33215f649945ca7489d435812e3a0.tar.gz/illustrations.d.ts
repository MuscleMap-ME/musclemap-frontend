/**
 * Exercise Illustration Mapping
 *
 * Maps database exercise IDs to SVG illustration files
 * and provides utilities for muscle visualization.
 */
export declare const ACTIVATION_COLORS: {
    readonly max: "#EF4444";
    readonly high: "#F97316";
    readonly med: "#FB923C";
    readonly low: "#14B8A6";
    readonly min: "#0D7377";
    readonly none: "#475569";
};
export type ActivationLevel = keyof typeof ACTIVATION_COLORS;
/**
 * Get activation color based on percentage (0-100)
 */
export declare function getActivationColor(activation: number): string;
/**
 * Get activation level name based on percentage
 */
export declare function getActivationLevel(activation: number): ActivationLevel;
export type BodyType = 'male' | 'female' | 'youth';
export type BodyView = 'front' | 'back' | 'side';
/**
 * Get body silhouette SVG path
 */
export declare function getBodyIllustrationPath(type: BodyType, view: BodyView): string;
export type ExerciseView = 'front' | 'back' | 'side';
export interface ExerciseIllustration {
    id: string;
    file: string;
    view: ExerciseView;
    primaryMuscles: string[];
    secondaryMuscles: string[];
}
/**
 * Map database exercise IDs to illustration metadata
 * Uses normalized exercise names to match illustration files
 */
export declare const EXERCISE_ILLUSTRATIONS: Record<string, ExerciseIllustration>;
/**
 * Get illustration for an exercise by database ID
 * Returns undefined if no illustration exists
 */
export declare function getExerciseIllustration(exerciseId: string): ExerciseIllustration | undefined;
/**
 * Get illustration URL for an exercise
 * Returns a placeholder if no illustration exists
 */
export declare function getExerciseIllustrationUrl(exerciseId: string): string;
/**
 * Check if an exercise has an illustration
 */
export declare function hasExerciseIllustration(exerciseId: string): boolean;
/**
 * Muscle group colors for visualization
 */
export declare const MUSCLE_GROUP_COLORS: Record<string, {
    color: string;
    glow: string;
}>;
/**
 * Get color for a muscle group
 */
export declare function getMuscleGroupColor(muscleGroup: string): {
    color: string;
    glow: string;
};
/**
 * Map database muscle IDs to illustration muscle IDs
 * (Database uses abbreviated names, illustrations use full anatomical names)
 */
export declare const MUSCLE_ID_MAP: Record<string, string[]>;
/**
 * Convert database muscle ID to illustration muscle IDs
 */
export declare function getMuscleIllustrationIds(dbMuscleId: string): string[];
/**
 * Interface for muscle activation data used in visualization
 */
export interface MuscleVisualizationData {
    muscleId: string;
    illustrationIds: string[];
    activation: number;
    color: string;
    level: ActivationLevel;
}
/**
 * Convert database muscle activations to visualization format
 */
export declare function prepareVisualizationData(activations: Array<{
    muscleId: string;
    activation: number;
}>): MuscleVisualizationData[];
//# sourceMappingURL=illustrations.d.ts.map