/**
 * User Preferences Types
 *
 * Comprehensive type definitions for the MuscleMap user customization system.
 * These types are shared between the API and frontend.
 */
export const GUIDANCE_LEVELS = {
    beginner: {
        label: 'Beginner',
        description: 'Full guidance with all tips, detailed explanations, and step-by-step instructions',
    },
    intermediate: {
        label: 'Intermediate',
        description: 'Occasional tips and moderate detail for experienced users',
    },
    advanced: {
        label: 'Advanced',
        description: 'Minimal guidance with only essential information',
    },
    expert: {
        label: 'Expert',
        description: 'No guidance, data-focused view for power users',
    },
};
// ============================================
// DEFAULT PREFERENCES
// ============================================
export const DEFAULT_PREFERENCES = {
    coaching: {
        maxCoachVisible: false,
        mascotVisible: true,
        coachTipsEnabled: true,
        motivationalQuotes: true,
        formCuesEnabled: true,
        voiceGuidanceEnabled: false,
    },
    guidanceLevel: 'intermediate',
    dashboard: {
        layout: 'default',
        showQuickActions: true,
        showDailyTip: true,
        showMilestones: true,
        showAdventureMap: true,
        showMuscleMap: true,
        showNutrition: true,
        showChallenges: true,
        showInsights: true,
        showActivity: true,
        showHydration: true,
        showMusicPlayer: true,
        showCoachTips: true,
        showXpProgress: true,
        showDailyQuests: true,
    },
    notifications: {
        achievementsEnabled: true,
        goalSuccessEnabled: true,
        workoutReminders: true,
        socialNotifications: true,
        systemAnnouncements: true,
        quietHoursEnabled: false,
        quietHoursStart: '22:00',
        quietHoursEnd: '07:00',
        pushEnabled: true,
        emailEnabled: true,
    },
    hydration: {
        enabled: true, // Default ON per requirements
        intervalMinutes: 15,
        soundEnabled: true,
        vibrationEnabled: true,
        showDuringWorkout: true,
        showOutsideWorkout: false,
        dailyGoalOz: 64,
    },
    sounds: {
        masterVolume: 0.7,
        timerSoundEnabled: true,
        timerSoundType: 'beep',
        timerVibrationEnabled: true,
        metronomeEnabled: false,
        metronomeBpm: 60,
        metronomeAccent: 4,
        repCountSoundEnabled: false,
        setCompleteSoundEnabled: true,
        workoutCompleteSoundEnabled: true,
        achievementSoundEnabled: true,
        customSoundPackId: null,
        systemSoundPackId: 'default',
    },
    workout: {
        defaultRestSeconds: 90,
        autoStartTimer: true,
        showFloatingTimer: true,
        countdownWarningSeconds: 10,
        warmupReminder: true,
        cooldownReminder: true,
        stretchReminder: false,
        quickAdjustAmount: 30,
    },
    display: {
        theme: 'dark',
        reducedMotion: false,
        highContrast: false,
        textSize: 'normal',
        colorBlindMode: 'none',
        animationsEnabled: true,
    },
    units: {
        weight: 'lbs',
        distance: 'mi',
        height: 'ft_in',
        temperature: 'f',
    },
    privacy: {
        publicProfile: true,
        showLocation: false,
        showProgress: true,
        showWorkoutDetails: true,
        showOnLeaderboards: true,
        showAchievementsOnProfile: true,
    },
    music: {
        autoPlayOnWorkout: true,
        bpmMatchingEnabled: false,
        defaultProvider: null,
        defaultPlaylistId: null,
        fadeOnRest: true,
        volumeReductionOnTips: true,
        tipVolumeReduction: 0.5,
    },
};
// ============================================
// UTILITY FUNCTIONS
// ============================================
/**
 * Deep merge preferences with defaults
 */
export function mergeWithDefaults(partial) {
    return {
        coaching: { ...DEFAULT_PREFERENCES.coaching, ...partial.coaching },
        guidanceLevel: partial.guidanceLevel ?? DEFAULT_PREFERENCES.guidanceLevel,
        dashboard: { ...DEFAULT_PREFERENCES.dashboard, ...partial.dashboard },
        notifications: { ...DEFAULT_PREFERENCES.notifications, ...partial.notifications },
        hydration: { ...DEFAULT_PREFERENCES.hydration, ...partial.hydration },
        sounds: { ...DEFAULT_PREFERENCES.sounds, ...partial.sounds },
        workout: { ...DEFAULT_PREFERENCES.workout, ...partial.workout },
        display: { ...DEFAULT_PREFERENCES.display, ...partial.display },
        units: { ...DEFAULT_PREFERENCES.units, ...partial.units },
        privacy: { ...DEFAULT_PREFERENCES.privacy, ...partial.privacy },
        music: { ...DEFAULT_PREFERENCES.music, ...partial.music },
    };
}
/**
 * Apply profile overrides to base preferences
 */
export function applyProfileOverrides(base, override) {
    return {
        coaching: { ...base.coaching, ...override.coaching },
        guidanceLevel: override.guidanceLevel ?? base.guidanceLevel,
        dashboard: { ...base.dashboard, ...override.dashboard },
        notifications: { ...base.notifications, ...override.notifications },
        hydration: { ...base.hydration, ...override.hydration },
        sounds: { ...base.sounds, ...override.sounds },
        workout: { ...base.workout, ...override.workout },
        display: { ...base.display, ...override.display },
        units: { ...base.units, ...override.units },
        privacy: { ...base.privacy, ...override.privacy },
        music: { ...base.music, ...override.music },
    };
}
/**
 * Convert ounces to milliliters
 */
export function ozToMl(oz) {
    return Math.round(oz * 29.5735);
}
/**
 * Convert milliliters to ounces
 */
export function mlToOz(ml) {
    return Math.round((ml / 29.5735) * 10) / 10;
}
//# sourceMappingURL=preferences.js.map