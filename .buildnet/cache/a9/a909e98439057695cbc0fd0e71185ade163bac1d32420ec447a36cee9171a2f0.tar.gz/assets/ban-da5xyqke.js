import{i as c}from"./index-jpts4ub0.js";const e=[["path",{d:"M4.929 4.929 19.07 19.071",key:"196cmz"}],["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}]],a=c("ban",e);export{a as B};
