import{i as o}from"./index-jpts4ub0.js";const s=[["path",{d:"M5 12h14",key:"1ays0h"}]],e=o("minus",s);export{e as M};
