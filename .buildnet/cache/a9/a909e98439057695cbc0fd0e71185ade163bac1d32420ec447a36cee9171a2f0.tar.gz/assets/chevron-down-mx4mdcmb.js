import{i as o}from"./index-jpts4ub0.js";const n=[["path",{d:"m6 9 6 6 6-6",key:"qrunsl"}]],c=o("chevron-down",n);export{c as C};
