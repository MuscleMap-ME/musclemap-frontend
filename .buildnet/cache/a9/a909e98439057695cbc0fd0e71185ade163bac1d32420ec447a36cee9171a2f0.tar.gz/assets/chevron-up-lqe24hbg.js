import{i as o}from"./index-jpts4ub0.js";const e=[["path",{d:"m18 15-6-6-6 6",key:"153udz"}]],n=o("chevron-up",e);export{n as C};
