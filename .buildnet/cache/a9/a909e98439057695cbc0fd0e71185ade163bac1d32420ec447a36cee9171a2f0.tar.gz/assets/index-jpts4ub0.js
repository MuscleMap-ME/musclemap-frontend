const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/index-d0c3qloy.js","assets/react-vendor-jlwrghqw.js","assets/use-transform-m6z05g6d.js","assets/use-reduced-motion-dihklje8.js","assets/use-drag-controls-du7k4k50.js","assets/leaflet-vendor-iccovecq.css","assets/reactflow-vendor-hf98mhgi.css","assets/Cockatrice3D-gujij4pw.js","assets/react-three-fiber.esm-bazmew8x.js","assets/CompanionPanel-kigvzuwg.js","assets/Landing-j4pzoegb.js","assets/SEO-dnzrzrzq.js","assets/useNetworkStatus-m7fiwqva.js","assets/Login-j0zyug61.js","assets/errors-lhvg89bx.js","assets/Logo-r62i6wzb.js","assets/sanitize-kii6wngq.js","assets/purify.es-oz380bl2.js","assets/Signup-p1pfugla.js","assets/Dashboard-mmc1ijmj.js","assets/TipCard-eu8n85xc.js","assets/award-njg2q8cp.js","assets/chevron-right-fvoekljw.js","assets/GlassSurface-nwd9ay0q.js","assets/GlassButton-drvdez5v.js","assets/nutritionStore-e8l2xbde.js","assets/utensils-iarvlxvw.js","assets/droplets-c7k7by2c.js","assets/QuickLogModal-osmn3luy.js","assets/useNutrition-ke0tmtqq.js","assets/loader-circle-fxu9c4mr.js","assets/circle-check-big-bbot7bnb.js","assets/circle-alert-jr2p6d3v.js","assets/refresh-cw-i3m9o23g.js","assets/mic-ba2xop4i.js","assets/minus-keb9il49.js","assets/musicStore-d5lu01yq.js","assets/arrow-left-mqvxh17z.js","assets/send-mxbqfffq.js","assets/chevron-down-mx4mdcmb.js","assets/thumbs-up-emq5kav2.js","assets/SpotlightTour-f5dxh1la.js","assets/chevron-left-b75nwaqv.js","assets/circle-check-laihqna3.js","assets/LevelUpEffect-g28fidfx.js","assets/NearbyVenuesWidget-cdevfjk9.js","assets/navigation-tvbr19xe.js","assets/LootDrop-rknhl7qc.js","assets/XPProgress-kyn0idp6.js","assets/InsightCard-pbpum2vh.js","assets/RPGStatBar-pc6xmw73.js","assets/adventureMapStore-jsksh4tf.js","assets/HapticButton-lle1b0ac.js","assets/GlassProgress-e6sj1s2w.js","assets/GlassNav-hga9udrf.js","assets/MeshBackground-kr8d12n3.js","assets/MuscleActivationCard-endegux6.js","assets/clipboard-list-d9iuqs0r.js","assets/Onboarding-gradixe6.js","assets/ArchetypeSelector-jv0r4lot.js","assets/skip-forward-m3cwvtbg.js","assets/Workout-ki77an0n.js","assets/illustrations-ic2b8t64.js","assets/MuscleViewer-mnxhchn6.js","assets/MuscleActivationBadge-nxpmtu87.js","assets/FloatingRestTimer-jcp0ydii.js","assets/timer-ds08x0ls.js","assets/minimize-2-k8b1xc7t.js","assets/volume-2-g153j5v0.js","assets/volume-x-o7gkr3zt.js","assets/info-ot8l2mb6.js","assets/check-nr5akxcn.js","assets/trash-2-ddi3tlg3.js","assets/rotate-ccw-bnquc2ge.js","assets/copy-gd2tjmv7.js","assets/pause-gxy9ngvv.js","assets/flag-o930wnis.js","assets/trending-down-edc4v8a9.js","assets/pen-ey5r1sis.js","assets/chevron-up-lqe24hbg.js","assets/save-msofayyo.js","assets/Journey-lit2kfd6.js","assets/MuscleHeatmap-mp4upl9v.js","assets/Profile-enzivbk0.js","assets/WeeklyHeatmap-m1sk17vw.js","assets/Settings-hgxsxzru.js","assets/history-m1255iv8.js","assets/triangle-alert-hozdgepq.js","assets/Progression-bqwvjqk2.js","assets/Exercises-d6ldu9ra.js","assets/auth-ie96b8o0.js","assets/Stats-hgrx3zhq.js","assets/CommunityDashboard-lpcew5l7.js","assets/ActivityFeed-gi5z5pu8.js","assets/date-vendor-jlofrghl.js","assets/Competitions-dczglajf.js","assets/Locations-gfz0zi4p.js","assets/HighFives-259zdss5.js","assets/Messages-n5pis5xh.js","assets/Crews-mpso8dk2.js","assets/Rivals-m7irxk6w.js","assets/Credits-e7vpmz38.js","assets/Wallet-jkqnm7ii.js","assets/SkinsStore-gqcjici5.js","assets/Health-fd6rpwbz.js","assets/Goals-dz86d6ug.js","assets/Limitations-oi6bavlw.js","assets/PTTests-papi75q2.js","assets/DesignSystem-eqh94s47.js","assets/Features-dqmznmq6.js","assets/Technology-esd2c5dh.js","assets/RouteNode-b0njulr9.js","assets/ArchitectureAtlas-bw0tquh8.js","assets/Science-khtwvj9z.js","assets/Design-esylxu93.js","assets/Docs-liufbhwg.js","assets/DocsAtlas-d2paiiq2.js","assets/Privacy-ee491jka.js","assets/Skills-j40bmmdu.js","assets/MartialArts-ohefcpc5.js","assets/Issues-cjxi9nyt.js","assets/NewIssue-ntmimfin.js","assets/MyIssues-hesxyfmz.js","assets/DevUpdates-et6drnm9.js","assets/Roadmap-dmgdgdsi.js","assets/RoadmapAtlas-k61c1j1c.js","assets/AdminControl-1hblt4l3.js","assets/AdminIssues-fzl6pcm9.js","assets/AdminMonitoring-fsh23maf.js","assets/server-iwadnzww.js","assets/circle-x-dv4hhxxi.js","assets/AICoach-ibblprua.js","assets/OfflineIndicator-hw2xmx00.js","assets/wifi-off-i224vxzi.js","assets/wifi-mvqmjnmd.js","assets/MobileDebugOverlay-likvzvt9.js","assets/MemoryWarningBanner-lceurren.js","assets/ForgotPassword-lwrp13l4.js","assets/ResetPassword-6frbzynl.js","assets/ActivityLog-hq2lj7oj.js","assets/download-jj6wj68d.js","assets/PersonalRecords-okirovbp.js","assets/Progress-photos-cb2y40ti.js","assets/WorkoutTemplates-kfmu50e4.js","assets/funnel-c9oce1tm.js","assets/square-pen-bgj4llcx.js","assets/BodyMeasurements-gwv5qauk.js","assets/Trainers-3i3bv8t8.js","assets/Marketplace-f6pg7nm4.js","assets/Trading-eh1wu730.js","assets/Collection-ociff6yw.js","assets/MysteryBoxes-lr47o8o9.js","assets/Recovery-gcuvvi6d.js","assets/CareerReadiness-lejx454y.js","assets/Leaderboard-xmq3yn42.js","assets/JourneyHealth-bsesblqn.js","assets/RecoveryDashboard-ml3xusfx.js","assets/ProgressionTargets-hdirizyn.js","assets/CareerPage-ou5wij7s.js","assets/SkeletonStats-ohgrnhkb.js","assets/CareerGoalPage-o7mh4c8i.js","assets/CareerStandardPage-cn9kru4a.js","assets/MuscleMapUIShowcase-ldl6i8sc.js","assets/Achievements-i4d1djbr.js","assets/AchievementVerification-jyyxe379.js","assets/MyVerifications-k7zvgwin.js","assets/WitnessAttestation-nkpc0u6i.js","assets/IssueDetail-j8j68yp1.js","assets/AdminMetrics-pd9vycr6.js","assets/gauge-e8zx5ywu.js","assets/memory-stick-j7fs4xww.js","assets/database-ojhr4edz.js","assets/AdminDisputes-n1d3ezh6.js","assets/AdminFraud-ircxz5jj.js","assets/EmpireControl-lw3p775v.js","assets/file-code-xf6mdzrj.js","assets/terminal-jd0ng5hn.js","assets/lock-d0b4pk1v.js","assets/mail-mda2un2q.js","assets/eye-ho97qkjj.js","assets/external-link-ehps1zn3.js","assets/EmpireUserDetail-huz6jk9v.js","assets/ban-da5xyqke.js","assets/TestScorecard-jc4zsl1k.js","assets/DeploymentControl-cpmxowmk.js","assets/square-m7a31pzx.js","assets/package-m9fersi7.js","assets/cpu-n23vhymh.js","assets/hard-drive-dmrklnvs.js","assets/git-branch-ie85ablv.js","assets/CommandCenter-jrinxsiz.js","assets/share-2-o0ywshyh.js","assets/file-hxhb45mg.js","assets/shield-alert-sy29iuwc.js","assets/monitor-ny0rldgw.js","assets/key-l3dcetuo.js","assets/arrow-up-down-nj38lxh5.js","assets/file-text-bxbdysb7.js","assets/layers-fywzydj5.js","assets/BugTracker-gapt5vmx.js","assets/smartphone-238ivdkn.js","assets/AdminExerciseImages-hwwogv6n.js","assets/image-f6s5it0l.js","assets/AnatomyViewer-kj6cd9lq.js","assets/registry-klrsw2vy.js","assets/LiveActivityMonitor-h7dsjtzz.js","assets/zoom-out-culr8s4n.js","assets/building-2-cuzsw3ws.js","assets/AdventureMap-jiqm9qr1.js","assets/AdventureHUD-m3aaokea.js","assets/index-m2xga5tt.js","assets/MapExplore-kzh6z0t6.js","assets/Discover-jx3igaar.js","assets/list-mzem22vc.js","assets/PluginMarketplace-fqmg984q.js","assets/plug-ditm3dlq.js","assets/PluginSettings-okpoy0fx.js","assets/CommunityBulletinBoard-fpenvdm4.js","assets/PluginGuide-jik14ls7.js","assets/ContributeIdeas-gkx2uy0e.js","assets/Nutrition-hgex45px.js","assets/NutritionSettings-klp5pk8t.js","assets/GlassMobileNav-iz79yjmx.js","assets/Recipes-d64wkok5.js","assets/MealPlans-bjd88iey.js","assets/shopping-cart-he38hzlt.js","assets/ShoppingList-ea89zxd1.js","assets/printer-gmjuqwbm.js","assets/NutritionHistory-ggsyvwy9.js"])))=>i.map(i=>d[i]);
import{r as m,j as c,a as $e,u as et,d as Ot,c as Td,e as vc,L as bd,N as wd,B as Id,f as xd,g as M,h as at,i as Ed}from"./react-vendor-jlwrghqw.js";import{H as Ad,s as Sc,R as _d,o as Cd,I as kd,A as Rd,f as Pd,a as Md,g as p,u as Ts,b as Lt,c as Od}from"./apollo-vendor-buzfmx8b.js";import{c as Nd,u as $d}from"./reactflow-vendor-fc60audz.js";import{c as ke,P as Tc}from"./recharts-vendor-mjjw1g2w.js";import"./leaflet-vendor-miye99o2.js";import"./d3-vendor-esoaovas.js";(function(){const t=document.createElement("link").relList;if(t&&t.supports&&t.supports("modulepreload"))return;for(const i of document.querySelectorAll('link[rel="modulepreload"]'))s(i);new MutationObserver(i=>{for(const a of i)if(a.type==="childList")for(const o of a.addedNodes)o.tagName==="LINK"&&o.rel==="modulepreload"&&s(o)}).observe(document,{childList:!0,subtree:!0});function n(i){const a={};return i.integrity&&(a.integrity=i.integrity),i.referrerPolicy&&(a.referrerPolicy=i.referrerPolicy),i.crossOrigin==="use-credentials"?a.credentials="include":i.crossOrigin==="anonymous"?a.credentials="omit":a.credentials="same-origin",a}function s(i){if(i.ep)return;i.ep=!0;const a=n(i);fetch(i.href,a)}})();var ar={TOKEN:"musclemap_token",USER:"musclemap_user"},or=null;function Dd(e){or=e}function bc(){if(!or)throw new Error("Storage adapter not initialized. Call setStorageAdapter() before using auth/http modules.");return or}var cr="Response validation failed";function jd(e,t){return t==null&&"default"in e?e.default:t}function ft(e,t){const n=jd(e,t);if(n==null){if(e.optional)return n;if("default"in e)return e.default}switch(e.kind){case"string":if(typeof n=="string")return n;break;case"number":if(typeof n=="number"&&Number.isFinite(n))return n;break;case"boolean":if(typeof n=="boolean")return n;break;case"null":if(n===null)return n;break;case"any":return n;case"union":{for(const s of e.anyOf)try{return ft(s,n)}catch{}break}case"array":{const s=n??e.default;if(Array.isArray(s))return s.map(i=>ft(e.items,i));break}case"object":{const s=n??e.default;if(s&&typeof s=="object"&&!Array.isArray(s)){const i=Object.entries(e.properties??{}),a={};for(const[o,l]of i){if(!(o in s)){if("default"in l)a[o]=l.default;else if(!l.optional)throw new Error(cr);continue}a[o]=ft(l,s[o])}if(e.additionalProperties!==!1)for(const[o,l]of Object.entries(s))(!e.properties||!(o in e.properties))&&(a[o]=l);return a}break}case"record":{const s=n??e.default;if(s&&typeof s=="object"&&!Array.isArray(s)){const i={};for(const[a,o]of Object.entries(s))ft(e.keySchema,a),i[a]=ft(e.valueSchema,o);return i}break}default:return n}throw new Error(cr)}function Ve(e,t={}){return{kind:e,...t}}var r={String:(e={})=>Ve("string",e),Number:(e={})=>Ve("number",e),Boolean:(e={})=>Ve("boolean",e),Null:()=>Ve("null",{}),Any:()=>Ve("any",{}),Optional:e=>({...e,optional:!0}),Union:e=>Ve("union",{anyOf:e}),Array:(e,t={})=>Ve("array",{items:e,default:t.default}),Object:(e,t={})=>Ve("object",{properties:e,default:t.default,additionalProperties:t.additionalProperties??!0}),Record:(e,t,n={})=>Ve("record",{keySchema:e,valueSchema:t,default:n.default})};function Ld(e){return!!(e&&typeof e=="object"&&"kind"in e)}function Ud(e,t){return ft(e,t)}function Vd(e,t){if(!e)return t;if("parse"in e&&typeof e.parse=="function")return e.parse(t);if("safeParse"in e&&typeof e.safeParse=="function"){const n=e.safeParse(t);if(n.success)return n.data;throw new Error(cr)}return Ld(e)?Ud(e,t):t}var Bd="/api",Fd=200,qd=2,Wd=3e4,Pn=new Map,Yi=e=>new Promise(t=>setTimeout(t,e));async function Ki(e){try{const t=await e.text();return t?JSON.parse(t):null}catch{return null}}function zd(e,t,n){return`${t.toUpperCase()}:${e}:${n?JSON.stringify(n):""}`}var Kt={};function Hd(e){Kt={...Kt,...e}}async function Gd(){try{return await bc().getItem(ar.TOKEN)}catch{return null}}async function Yd(){try{const e=bc();await Promise.all([e.removeItem(ar.TOKEN),e.removeItem(ar.USER)])}catch{}}async function S(e,t={}){const{method:n="GET",body:s,headers:i={},schema:a,auth:o=!0,retries:l=qd,retryDelay:u=Fd,cacheTtl:d,cacheKey:h,baseUrl:f,onUnauthorized:g}=t,y=f??Kt.baseUrl??Bd,v=e.startsWith("http")?e:`${y}${e}`,T=n.toUpperCase(),b=d===void 0?T==="GET":d>0,I=d===void 0?T==="GET"?Wd:0:d,x=h||zd(v,T,s);if(b&&Pn.has(x)){const A=Pn.get(x);if(A.expires>Date.now())return A.data;Pn.delete(x)}let w=0,_=null;for(;w<=l;)try{const A=typeof FormData<"u"&&s instanceof FormData,k={...Kt.defaultHeaders,...s&&!A?{"Content-Type":"application/json"}:{},...i};if(o){const N=await Gd();N&&(k.Authorization=`Bearer ${N}`)}const R=await fetch(v,{method:T,headers:k,body:s?A?s:JSON.stringify(s):void 0});if(R.status===401&&o){await Yd();const N=g??Kt.onUnauthorized;throw N&&await N(),new Error("Unauthorized")}if(R.status>=500&&w<l){w++,await Yi(u*w);continue}if(!R.ok){const N=await Ki(R);let F=`Request failed with status ${R.status}`;throw N&&(typeof N.error=="object"&&N.error?.message?F=N.error.message:typeof N.error=="string"?F=N.error:N.message&&(F=N.message)),new Error(F)}const P=await Ki(R),O=Vd(a,P);return b&&I>0&&Pn.set(x,{data:O,expires:Date.now()+I}),O}catch(A){if(_=A instanceof Error?A:new Error(String(A)),w>=l)break;w++,await Yi(u*w)}throw _||new Error("Request failed")}var Qi=r.Object({id:r.String(),name:r.String(),type:r.String(),difficulty:r.Number(),description:r.Union([r.String(),r.Null()]),cues:r.Union([r.String(),r.Null()]),primaryMuscles:r.Array(r.String(),{default:[]})},{additionalProperties:!0}),Kd=r.Object({id:r.String(),name:r.String(),type:r.String(),difficulty:r.Number(),description:r.Union([r.String(),r.Null()]),cues:r.Union([r.String(),r.Null()]),primaryMuscles:r.Array(r.String(),{default:[]}),activations:r.Array(r.Object({muscleId:r.String(),muscleName:r.String(),activation:r.Number()}),{default:[]})},{additionalProperties:!0}),Ji=r.Object({id:r.String(),name:r.String(),anatomicalName:r.Union([r.String(),r.Null()]),muscleGroup:r.String(),biasWeight:r.Number(),optimalWeeklyVolume:r.Union([r.Number(),r.Null()]),recoveryTime:r.Union([r.Number(),r.Null()])},{additionalProperties:!0}),wc=r.Object({muscleId:r.String(),muscleName:r.String(),muscleGroup:r.String(),rawActivation:r.Number(),biasWeight:r.Number(),normalizedActivation:r.Number(),colorTier:r.Number()},{additionalProperties:!0}),Qd=r.Object({exerciseId:r.String(),sets:r.Number(),reps:r.Optional(r.Number()),weight:r.Optional(r.Number()),duration:r.Optional(r.Number()),notes:r.Optional(r.String())},{additionalProperties:!0}),bs=r.Object({id:r.String(),userId:r.String(),date:r.String(),totalTU:r.Number(),creditsUsed:r.Number(),notes:r.Union([r.String(),r.Null()]),isPublic:r.Boolean(),exerciseData:r.Array(Qd,{default:[]}),muscleActivations:r.Record(r.String(),r.Number(),{default:{}}),createdAt:r.String()},{additionalProperties:!0}),Jd=r.Object({allTime:r.Object({workoutCount:r.Number(),totalTU:r.Number()}),thisWeek:r.Object({workoutCount:r.Number(),totalTU:r.Number()}),thisMonth:r.Object({workoutCount:r.Number(),totalTU:r.Number()})},{additionalProperties:!0}),Xd=r.Object({totalTU:r.Number(),activations:r.Array(wc,{default:[]})},{additionalProperties:!0}),Zd=r.Object({id:r.String(),name:r.String(),philosophy:r.Union([r.String(),r.Null()]),description:r.Union([r.String(),r.Null()]),focusAreas:r.Array(r.String(),{default:[]}),iconUrl:r.Union([r.String(),r.Null()])},{additionalProperties:!0}),Ic=r.Object({id:r.Optional(r.Number()),archetypeId:r.Optional(r.String()),level:r.Number(),name:r.String(),totalTU:r.Optional(r.Number()),total_tu:r.Optional(r.Number()),description:r.Union([r.String(),r.Null()]),muscleTargets:r.Optional(r.Record(r.String(),r.Number()))},{additionalProperties:!0}),em=r.Object({id:r.String(),name:r.String(),philosophy:r.Union([r.String(),r.Null()]),description:r.Union([r.String(),r.Null()]),focusAreas:r.Array(r.String(),{default:[]}),iconUrl:r.Union([r.String(),r.Null()]),levels:r.Array(Ic,{default:[]})},{additionalProperties:!0}),Xi=r.Object({archetypeId:r.String(),archetypeName:r.String(),currentLevel:r.Number(),currentLevelName:r.String(),currentTU:r.Number(),nextLevelTU:r.Union([r.Number(),r.Null()]),progressPercent:r.Number()},{additionalProperties:!0}),tm=r.Object({id:r.String(),username:r.String(),avatar:r.Optional(r.Union([r.String(),r.Null()])),archetype:r.Optional(r.Union([r.String(),r.Null()])),level:r.Optional(r.Number())},{additionalProperties:!0}),Ut=r.Object({id:r.String(),challengerId:r.String(),challengedId:r.String(),status:r.String(),createdAt:r.String(),startedAt:r.Union([r.String(),r.Null()]),endedAt:r.Union([r.String(),r.Null()]),opponent:tm,isChallenger:r.Boolean(),myTU:r.Number(),opponentTU:r.Number(),myLastWorkout:r.Union([r.String(),r.Null()]),opponentLastWorkout:r.Union([r.String(),r.Null()]),tuDifference:r.Number(),isWinning:r.Boolean()},{additionalProperties:!0}),Zi=r.Object({activeRivals:r.Number(),wins:r.Number(),losses:r.Number(),ties:r.Number(),totalTUEarned:r.Number(),currentStreak:r.Number(),longestStreak:r.Number()},{additionalProperties:!0}),nm=r.Object({id:r.String(),username:r.String(),avatar:r.Optional(r.String()),archetype:r.Optional(r.String())},{additionalProperties:!0}),xc=r.Object({id:r.String(),userId:r.String(),provider:r.String(),providerUserId:r.Optional(r.String()),isActive:r.Boolean(),lastSyncAt:r.Union([r.String(),r.Null()]),syncError:r.Optional(r.Union([r.String(),r.Null()])),syncStatus:r.Optional(r.String()),createdAt:r.String()},{additionalProperties:!0}),lr=r.Object({provider:r.String(),lastSyncAt:r.Union([r.String(),r.Null()]),syncStatus:r.String(),syncError:r.Union([r.String(),r.Null()])},{additionalProperties:!0}),sm=r.Object({today:r.Object({steps:r.Number(),activeCalories:r.Number(),avgHeartRate:r.Union([r.Number(),r.Null()]),workoutMinutes:r.Number(),sleepHours:r.Union([r.Number(),r.Null()])}),thisWeek:r.Object({totalSteps:r.Number(),avgDailySteps:r.Number(),totalWorkoutMinutes:r.Number(),avgSleepHours:r.Union([r.Number(),r.Null()]),avgRestingHeartRate:r.Union([r.Number(),r.Null()])}),connections:r.Array(xc,{default:[]}),syncStatus:r.Optional(r.Array(lr,{default:[]}))},{additionalProperties:!0}),rm=r.Object({synced:r.Object({heartRate:r.Number(),workouts:r.Number(),activity:r.Number(),sleep:r.Number(),bodyMeasurements:r.Number()}),conflicts:r.Array(r.Object({type:r.String(),localId:r.Optional(r.String()),remoteId:r.Optional(r.String()),resolution:r.String(),timestamp:r.String()}),{default:[]}),lastSyncAt:r.String()},{additionalProperties:!0}),ea=r.Object({id:r.String(),type:r.String(),startTime:r.String(),endTime:r.String(),duration:r.Number(),calories:r.Optional(r.Number()),distance:r.Optional(r.Number()),avgHeartRate:r.Optional(r.Number()),maxHeartRate:r.Optional(r.Number()),minHeartRate:r.Optional(r.Number()),steps:r.Optional(r.Number()),elevationGain:r.Optional(r.Number()),source:r.String(),externalId:r.Optional(r.String())},{additionalProperties:!0}),Wn=r.Object({id:r.String(),name:r.String(),tag:r.String(),description:r.Union([r.String(),r.Null()]),avatar:r.Union([r.String(),r.Null()]),color:r.String(),ownerId:r.String(),memberCount:r.Number(),totalTU:r.Number(),weeklyTU:r.Number(),wins:r.Number(),losses:r.Number(),createdAt:r.String()},{additionalProperties:!0}),Kn=r.Object({id:r.String(),crewId:r.String(),userId:r.String(),role:r.String(),joinedAt:r.String(),weeklyTU:r.Number(),totalTU:r.Number(),username:r.String(),avatar:r.Union([r.String(),r.Null()]),archetype:r.Union([r.String(),r.Null()])},{additionalProperties:!0}),ur=r.Object({id:r.String(),challengerCrewId:r.String(),defendingCrewId:r.String(),status:r.String(),startDate:r.String(),endDate:r.String(),challengerTU:r.Number(),defendingTU:r.Number(),winnerId:r.Union([r.String(),r.Null()]),createdAt:r.String(),challengerCrew:r.Object({id:r.String(),name:r.String(),tag:r.String(),avatar:r.Union([r.String(),r.Null()]),color:r.String()}),defendingCrew:r.Object({id:r.String(),name:r.String(),tag:r.String(),avatar:r.Union([r.String(),r.Null()]),color:r.String()}),isChallenger:r.Boolean(),myCrewTU:r.Number(),opponentCrewTU:r.Number(),daysRemaining:r.Number(),isWinning:r.Boolean()},{additionalProperties:!0}),Ec=r.Object({totalMembers:r.Number(),totalTU:r.Number(),weeklyTU:r.Number(),warsWon:r.Number(),warsLost:r.Number(),currentStreak:r.Number(),topContributors:r.Array(r.Object({userId:r.String(),username:r.String(),avatar:r.Union([r.String(),r.Null()]),weeklyTU:r.Number()}))},{additionalProperties:!0}),im=r.Object({crew:Wn,membership:Kn,members:r.Array(Kn,{default:[]}),wars:r.Array(ur,{default:[]}),stats:Ec},{additionalProperties:!0}),am=r.Object({rank:r.Number(),crew:r.Object({id:r.String(),name:r.String(),tag:r.String(),avatar:r.Union([r.String(),r.Null()]),color:r.String(),memberCount:r.Number(),weeklyTU:r.Number()})},{additionalProperties:!0}),om=r.Object({totalTU:r.Number(),totalWorkouts:r.Number(),currentLevel:r.Number(),currentLevelName:r.String(),nextLevelTU:r.Number(),progressToNextLevel:r.Number(),currentArchetype:r.Union([r.String(),r.Null()]),daysSinceJoined:r.Number(),streak:r.Number(),stats:r.Object({weekly:r.Object({workouts:r.Number(),tu:r.Number(),avgTuPerWorkout:r.Number()}),monthly:r.Object({workouts:r.Number(),tu:r.Number(),avgTuPerWorkout:r.Number()}),allTime:r.Object({workouts:r.Number(),tu:r.Number(),avgTuPerWorkout:r.Number()})}),workoutHistory:r.Array(r.Object({date:r.String(),tu:r.Number(),count:r.Number()})),muscleBreakdown:r.Array(r.Any()),muscleGroups:r.Array(r.Any()),paths:r.Array(r.Any()),levels:r.Array(r.Any()),topExercises:r.Array(r.Any()),recentWorkouts:r.Array(r.Any())},{additionalProperties:!0}),dr=r.Object({strength:r.Number(),constitution:r.Number(),dexterity:r.Number(),power:r.Number(),endurance:r.Number(),vitality:r.Number(),lastCalculatedAt:r.Optional(r.String())},{additionalProperties:!0}),Mn=r.Object({rank:r.Number(),total:r.Number(),percentile:r.Number()},{additionalProperties:!0}),Ac=r.Object({global:Mn,country:r.Optional(Mn),state:r.Optional(Mn),city:r.Optional(Mn)},{additionalProperties:!0}),cm=r.Object({stats:dr,rankings:r.Record(r.String(),Ac)},{additionalProperties:!0}),lm=r.Object({snapshotDate:r.String(),strength:r.Number(),constitution:r.Number(),dexterity:r.Number(),power:r.Number(),endurance:r.Number(),vitality:r.Number()},{additionalProperties:!0}),ta=r.Object({gender:r.Union([r.String(),r.Null()]),city:r.Union([r.String(),r.Null()]),county:r.Union([r.String(),r.Null()]),state:r.Union([r.String(),r.Null()]),country:r.Union([r.String(),r.Null()]),countryCode:r.Union([r.String(),r.Null()]),leaderboardOptIn:r.Boolean(),profileVisibility:r.String()},{additionalProperties:!0}),um=r.Object({userId:r.String(),username:r.String(),avatarUrl:r.Union([r.String(),r.Null()]),statValue:r.Number(),rank:r.Number(),gender:r.Optional(r.String()),country:r.Optional(r.String()),state:r.Optional(r.String()),city:r.Optional(r.String())},{additionalProperties:!0}),dm=r.Object({id:r.String(),name:r.String(),abbr:r.String(),description:r.String(),color:r.String()},{additionalProperties:!0}),na=r.Object({minimalistMode:r.Boolean(),optOutLeaderboards:r.Boolean(),optOutCommunityFeed:r.Boolean(),optOutCrews:r.Boolean(),optOutRivals:r.Boolean(),optOutHangouts:r.Boolean(),optOutMessaging:r.Boolean(),optOutHighFives:r.Boolean(),excludeFromStatsComparison:r.Boolean(),excludeFromLocationFeatures:r.Boolean(),excludeFromActivityFeed:r.Boolean(),hideGamification:r.Boolean(),hideAchievements:r.Boolean(),hideTips:r.Boolean(),hideSocialNotifications:r.Boolean(),hideProgressComparisons:r.Boolean(),disablePresenceTracking:r.Boolean(),disableWorkoutSharing:r.Boolean(),profileCompletelyPrivate:r.Boolean()},{additionalProperties:!0}),mm=r.Object({mode:r.String(),summary:r.String(),enabledFeatures:r.Array(r.String()),disabledFeatures:r.Array(r.String()),dataPrivacy:r.Object({excludedFromComparisons:r.Boolean(),excludedFromActivityFeed:r.Boolean(),locationHidden:r.Boolean(),presenceHidden:r.Boolean(),profilePrivate:r.Boolean()})},{additionalProperties:!0}),hm=r.Object({completed:r.Boolean(),completedAt:r.Union([r.String(),r.Null()]),hasProfile:r.Boolean(),hasGender:r.Boolean(),hasUnits:r.Boolean()},{additionalProperties:!0}),pm=r.Object({gender:r.Union([r.String(),r.Null()]),dateOfBirth:r.Union([r.String(),r.Null()]),heightCm:r.Union([r.Number(),r.Null()]),heightFt:r.Union([r.Number(),r.Null()]),heightIn:r.Union([r.Number(),r.Null()]),weightKg:r.Union([r.Number(),r.Null()]),weightLbs:r.Union([r.Number(),r.Null()]),preferredUnits:r.String(),onboardingCompletedAt:r.Union([r.String(),r.Null()])},{additionalProperties:!0}),sa=r.Object({id:r.String(),name:r.String(),category:r.String(),description:r.Union([r.String(),r.Null()]),iconUrl:r.Union([r.String(),r.Null()]),displayOrder:r.Number()},{additionalProperties:!0}),fm=r.Object({equipmentTypeId:r.String(),equipmentName:r.String(),category:r.String(),confirmedCount:r.Number(),deniedCount:r.Number(),isVerified:r.Boolean(),firstReportedAt:r.String(),lastReportedAt:r.String()},{additionalProperties:!0}),gm=r.Object({id:r.Number(),userId:r.String(),equipmentTypeId:r.String(),equipmentName:r.String(),category:r.String(),locationType:r.String(),notes:r.Union([r.String(),r.Null()])},{additionalProperties:!0}),_c=r.Object({id:r.Union([r.String(),r.Number()]),email:r.Optional(r.String()),username:r.Optional(r.String()),archetype:r.Optional(r.String())},{additionalProperties:!0}),ra=r.Object({token:r.String(),user:_c},{additionalProperties:!0}),ym=r.Object({wallet:r.Object({balance:r.Number(),currency:r.String({default:"CR"})},{additionalProperties:!0})},{additionalProperties:!0}),vm=r.Object({transactions:r.Array(r.Object({id:r.Union([r.String(),r.Number()]),amount:r.Number(),description:r.Optional(r.String()),created_at:r.Optional(r.String())},{additionalProperties:!0}),{default:[]})},{additionalProperties:!0}),Sm=r.Object({status:r.Union([r.String(),r.Null()]),currentPeriodEnd:r.Union([r.String(),r.Null()]),cancelAtPeriodEnd:r.Boolean({default:!1})},{additionalProperties:!0}),ws=r.Object({url:r.String()},{additionalProperties:!0}),ia=r.Object({isFoundingMember:r.Boolean(),memberNumber:r.Union([r.Number(),r.Null()]),joinedAt:r.Union([r.String(),r.Null()]),perks:r.Array(r.String(),{default:[]})},{additionalProperties:!0}),Tm=r.Object({id:r.Union([r.String(),r.Number()]),username:r.Optional(r.String())},{additionalProperties:!0}),aa=r.Object({encouragements:r.Array(r.Object({id:r.Union([r.String(),r.Number()]),sender_name:r.Optional(r.String()),recipient_name:r.Optional(r.String()),type:r.String(),message:r.Optional(r.Union([r.String(),r.Null()])),created_at:r.Optional(r.String()),read_at:r.Optional(r.Union([r.String(),r.Null()]))},{additionalProperties:!0}),{default:[]})},{additionalProperties:!0}),bm=r.Object({sent:r.Optional(r.Number()),received:r.Optional(r.Number()),unread:r.Optional(r.Number())},{additionalProperties:!0}),Cc=r.Object({email_notifications:r.Optional(r.Boolean()),sms_notifications:r.Optional(r.Boolean()),theme:r.Optional(r.String())},{additionalProperties:!0}),wm=r.Object({settings:r.Optional(Cc)},{additionalProperties:!0}),oa=r.Object({id:r.Optional(r.Union([r.String(),r.Number()])),username:r.Optional(r.String()),bio:r.Optional(r.String()),avatar:r.Optional(r.String())},{additionalProperties:!0}),Im=r.Object({xp:r.Number(),level:r.Number(),levelName:r.String(),rank:r.String(),streak:r.Number(),workouts:r.Number(),lastWorkoutDate:r.Union([r.String(),r.Null()])},{additionalProperties:!0});function C(e){return r.Object({data:e},{additionalProperties:!0})}var xm={auth:{login:async(e,t)=>(await S("/auth/login",{method:"POST",body:{email:e,password:t},auth:!1,schema:C(ra)})).data,register:async e=>(await S("/auth/register",{method:"POST",body:e,auth:!1,schema:C(ra)})).data,profile:()=>S("/auth/me",{schema:_c})},billing:{subscription:()=>S("/billing/subscription",{schema:C(r.Union([Sm,r.Null()]))}),checkout:()=>S("/billing/checkout",{method:"POST",schema:C(ws)}),creditsCheckout:()=>S("/billing/credits/checkout",{method:"POST",schema:C(ws)}),portal:()=>S("/billing/portal",{method:"POST",schema:C(ws)}),foundingMember:()=>S("/billing/founding-member",{schema:C(ia)}),claimFoundingMember:()=>S("/billing/founding-member/claim",{method:"POST",schema:C(ia)})},exercises:{list:e=>S(e?`/exercises?type=${e}`:"/exercises",{schema:C(r.Array(Qi)),cacheTtl:3e5}),get:e=>S(`/exercises/${e}`,{schema:C(Kd),cacheTtl:3e5}),types:()=>S("/exercises/types",{schema:C(r.Array(r.String())),cacheTtl:3e5}),search:e=>S(`/exercises/search?q=${encodeURIComponent(e)}`,{schema:C(r.Array(Qi))}),activations:e=>S(`/exercises/${e}/activations`,{schema:C(r.Record(r.String(),r.Number())),cacheTtl:3e5})},muscles:{list:e=>S(e?`/muscles?group=${e}`:"/muscles",{schema:C(r.Array(Ji)),cacheTtl:3e5}),get:e=>S(`/muscles/${e}`,{schema:C(Ji),cacheTtl:3e5}),groups:()=>S("/muscles/groups",{schema:C(r.Array(r.String())),cacheTtl:3e5})},workouts:{create:e=>S("/workouts",{method:"POST",body:e,schema:C(bs)}),list:(e=50,t=0)=>S(`/workouts/me?limit=${e}&offset=${t}`,{schema:C(r.Array(bs))}),get:e=>S(`/workouts/${e}`,{schema:C(bs)}),stats:()=>S("/workouts/me/stats",{schema:C(Jd)}),muscleActivations:(e=7)=>S(`/workouts/me/muscles?days=${e}`,{schema:C(r.Array(wc))}),preview:e=>S("/workouts/preview",{method:"POST",body:{exercises:e},schema:C(Xd)})},archetypes:{list:()=>S("/archetypes",{schema:C(r.Array(Zd)),cacheTtl:3e5}),get:e=>S(`/archetypes/${e}`,{schema:C(em),cacheTtl:3e5}),levels:e=>S(`/archetypes/${e}/levels`,{schema:C(r.Array(Ic)),cacheTtl:3e5}),myProgress:()=>S("/archetypes/me/progress",{schema:r.Object({data:r.Union([Xi,r.Null()])},{additionalProperties:!0})}),progressFor:e=>S(`/archetypes/me/progress/${e}`,{schema:C(Xi)}),select:e=>S("/archetypes/me/select",{method:"POST",body:{archetypeId:e},schema:C(r.Object({success:r.Boolean(),archetypeId:r.String()}))})},journey:{get:()=>S("/journey",{schema:C(om)}),paths:()=>S("/journey/paths",{schema:C(r.Object({paths:r.Array(r.Any())}))}),switchArchetype:e=>S("/journey/switch",{method:"POST",body:{archetype:e},schema:r.Object({success:r.Boolean(),data:r.Object({archetype:r.String()})},{additionalProperties:!0})})},progress:{stats:()=>S("/progress/stats",{schema:C(Im)})},wallet:{balance:()=>S("/economy/wallet",{schema:ym}),transactions:(e=20)=>S(`/economy/transactions?limit=${e}`,{schema:vm}),transfer:e=>S("/economy/transfer",{method:"POST",body:e,schema:r.Object({success:r.Optional(r.Boolean())},{additionalProperties:!0})})},highFives:{users:()=>S("/highfives/users",{schema:r.Object({users:r.Array(Tm,{default:[]})},{additionalProperties:!0})}),received:()=>S("/highfives/received",{schema:aa}),sent:()=>S("/highfives/sent",{schema:aa}),stats:()=>S("/highfives/stats",{schema:bm}),send:e=>S("/highfives/send",{method:"POST",body:e,schema:r.Object({error:r.Optional(r.String())},{additionalProperties:!0})})},settings:{fetch:()=>S("/settings",{schema:wm}),update:e=>S("/settings",{method:"PATCH",body:e,schema:Cc})},profile:{get:()=>S("/profile",{schema:oa}),update:e=>S("/profile",{method:"PUT",body:e,schema:oa}),avatars:()=>S("/profile/avatars",{schema:r.Object({avatars:r.Array(r.Any(),{default:[]})},{additionalProperties:!0}),cacheTtl:6e4}),themes:()=>S("/profile/themes",{schema:r.Object({themes:r.Array(r.Any(),{default:[]})},{additionalProperties:!0}),cacheTtl:6e4})},rivals:{list:e=>S(e?`/rivals?status=${e}`:"/rivals",{schema:C(r.Object({rivals:r.Array(Ut),stats:Zi}))}),get:e=>S(`/rivals/${e}`,{schema:C(Ut)}),pending:()=>S("/rivals/pending",{schema:C(r.Array(Ut))}),stats:()=>S("/rivals/stats",{schema:C(Zi)}),search:(e,t=20)=>S(`/rivals/search?q=${encodeURIComponent(e)}&limit=${t}`,{schema:C(r.Array(nm))}),challenge:e=>S("/rivals",{method:"POST",body:{userId:e},schema:C(Ut)}),accept:e=>S(`/rivals/${e}/accept`,{method:"POST",schema:C(Ut)}),decline:e=>S(`/rivals/${e}/decline`,{method:"POST",schema:r.Object({success:r.Boolean()},{additionalProperties:!0})}),end:e=>S(`/rivals/${e}/end`,{method:"POST",schema:r.Object({success:r.Boolean()},{additionalProperties:!0})})},wearables:{summary:()=>S("/wearables",{schema:C(sm)}),status:()=>S("/wearables/status",{schema:C(r.Object({syncStatus:r.Array(lr,{default:[]})}))}),providerStatus:e=>S(`/wearables/status/${e}`,{schema:C(lr)}),connect:(e,t)=>S("/wearables/connect",{method:"POST",body:{provider:e,...t},schema:C(xc)}),disconnect:e=>S("/wearables/disconnect",{method:"POST",body:{provider:e},schema:r.Object({success:r.Boolean()},{additionalProperties:!0})}),sync:(e,t,n)=>S("/wearables/sync",{method:"POST",body:{provider:e,data:t,options:n},schema:C(rm)}),workouts:(e=10)=>S(`/wearables/workouts?limit=${e}`,{schema:C(r.Object({workouts:r.Array(ea,{default:[]})}))}),exportWorkouts:e=>S(`/wearables/export?${new URLSearchParams(Object.entries(e||{}).filter(([,t])=>t!==void 0).map(([t,n])=>[t,String(n)])).toString()}`,{schema:C(r.Object({workouts:r.Array(ea,{default:[]})}))})},crews:{my:()=>S("/crews/my",{schema:C(r.Union([im,r.Null()]))}),create:(e,t,n,s)=>S("/crews",{method:"POST",body:{name:e,tag:t,description:n,color:s},schema:C(Wn)}),get:e=>S(`/crews/${e}`,{schema:C(r.Object({crew:Wn,members:r.Array(Kn,{default:[]}),stats:Ec}))}),search:(e,t=20)=>S(`/crews/search?q=${encodeURIComponent(e)}&limit=${t}`,{schema:C(r.Array(Wn,{default:[]}))}),leaderboard:(e=50)=>S(`/crews/leaderboard?limit=${e}`,{schema:C(r.Array(am,{default:[]}))}),invite:(e,t)=>S(`/crews/${e}/invite`,{method:"POST",body:{inviteeId:t},schema:C(r.Object({id:r.String()},{additionalProperties:!0}))}),acceptInvite:e=>S(`/crews/invites/${e}/accept`,{method:"POST",schema:C(Kn)}),leave:()=>S("/crews/leave",{method:"POST",schema:r.Object({success:r.Boolean()},{additionalProperties:!0})}),startWar:(e,t,n=7)=>S(`/crews/${e}/war`,{method:"POST",body:{defendingCrewId:t,durationDays:n},schema:C(ur)}),getWars:e=>S(`/crews/${e}/wars`,{schema:C(r.Array(ur,{default:[]}))})},characterStats:{me:()=>S("/stats/me",{schema:C(cm)}),getUser:e=>S(`/stats/user/${e}`,{schema:C(r.Object({userId:r.String(),stats:dr}))}),history:(e=30)=>S(`/stats/history?days=${e}`,{schema:C(r.Array(lm))}),recalculate:()=>S("/stats/recalculate",{method:"POST",schema:C(r.Object({stats:dr,message:r.String()}))}),leaderboard:e=>{const t=new URLSearchParams;e?.stat&&t.set("stat",e.stat),e?.scope&&t.set("scope",e.scope),e?.scopeValue&&t.set("scopeValue",e.scopeValue),e?.gender&&t.set("gender",e.gender),e?.limit&&t.set("limit",String(e.limit)),e?.offset&&t.set("offset",String(e.offset));const n=t.toString();return S(`/stats/leaderboards${n?`?${n}`:""}`,{schema:C(r.Array(um))})},myRankings:()=>S("/stats/leaderboards/me",{schema:C(r.Object({rankings:r.Record(r.String(),Ac),profile:r.Object({gender:r.Union([r.String(),r.Null()]),city:r.Union([r.String(),r.Null()]),state:r.Union([r.String(),r.Null()]),country:r.Union([r.String(),r.Null()])})}))}),extendedProfile:()=>S("/stats/profile/extended",{schema:C(ta)}),updateExtendedProfile:e=>S("/stats/profile/extended",{method:"PUT",body:e,schema:C(ta)}),info:()=>S("/stats/info",{schema:C(r.Object({stats:r.Array(dm)})),cacheTtl:3e5})},privacy:{get:()=>S("/privacy",{schema:C(na)}),update:e=>S("/privacy",{method:"PUT",body:e,schema:C(na)}),enableMinimalist:()=>S("/privacy/enable-minimalist",{method:"POST",schema:C(r.Object({minimalistMode:r.Boolean(),message:r.String()}))}),disableMinimalist:()=>S("/privacy/disable-minimalist",{method:"POST",schema:C(r.Object({minimalistMode:r.Boolean(),message:r.String()}))}),summary:()=>S("/privacy/summary",{schema:C(mm)})},onboarding:{status:()=>S("/onboarding/status",{schema:C(hm)}),getProfile:()=>S("/onboarding/profile",{schema:C(pm)}),saveProfile:e=>S("/onboarding/profile",{method:"POST",body:e,schema:C(r.Object({success:r.Boolean(),message:r.String()}))}),saveHomeEquipment:(e,t="home")=>S("/onboarding/home-equipment",{method:"POST",body:{equipmentIds:e,locationType:t},schema:C(r.Object({success:r.Boolean(),message:r.String(),equipmentCount:r.Number()}))}),complete:()=>S("/onboarding/complete",{method:"POST",schema:C(r.Object({success:r.Boolean(),message:r.String(),completedAt:r.String()}))}),skip:()=>S("/onboarding/skip",{method:"POST",schema:C(r.Object({success:r.Boolean(),message:r.String(),skipped:r.Boolean()}))})},equipment:{types:()=>S("/equipment/types",{schema:C(r.Array(sa)),cacheTtl:3e5}),typesByCategory:e=>S(`/equipment/types/${encodeURIComponent(e)}`,{schema:C(r.Array(sa)),cacheTtl:3e5}),categories:()=>S("/equipment/categories",{schema:C(r.Array(r.String())),cacheTtl:3e5}),getLocationEquipment:e=>S(`/locations/${e}/equipment`,{schema:C(r.Array(fm))}),getVerifiedLocationEquipment:e=>S(`/locations/${e}/equipment/verified`,{schema:C(r.Array(r.String()))}),reportEquipment:(e,t,n)=>S(`/locations/${e}/equipment`,{method:"POST",body:{types:t,reportType:n},schema:C(r.Object({success:r.Boolean(),message:r.String(),reportedCount:r.Number()}))}),getMyReports:e=>S(`/locations/${e}/equipment/my-reports`,{schema:C(r.Array(r.Object({equipmentTypeId:r.String(),reportType:r.String()})))}),getHomeEquipment:e=>S(`/equipment/home${e?`?locationType=${e}`:""}`,{schema:C(r.Array(gm))}),getHomeEquipmentIds:e=>S(`/equipment/home/ids${e?`?locationType=${e}`:""}`,{schema:C(r.Array(r.String()))}),setHomeEquipment:(e,t="home")=>S("/equipment/home",{method:"PUT",body:{equipmentIds:e,locationType:t},schema:C(r.Object({success:r.Boolean(),message:r.String(),equipmentCount:r.Number()}))}),addHomeEquipment:(e,t="home",n)=>S("/equipment/home",{method:"POST",body:{equipmentId:e,locationType:t,notes:n},schema:C(r.Object({success:r.Boolean(),message:r.String()}))}),removeHomeEquipment:(e,t="home")=>S(`/equipment/home/${e}${t!=="home"?`?locationType=${t}`:""}`,{method:"DELETE",schema:r.Object({success:r.Boolean(),message:r.String()},{additionalProperties:!0})})},hangouts:{themes:()=>S("/virtual-hangouts/themes",{schema:C(r.Array(Em)),cacheTtl:3e5}),list:(e,t=50,n=0)=>S(`/virtual-hangouts?${new URLSearchParams({...e?{themeId:String(e)}:{},limit:String(t),offset:String(n)}).toString()}`,{schema:C(r.Array(On))}),recommended:(e=5)=>S(`/virtual-hangouts/recommended?limit=${e}`,{schema:C(r.Array(On))}),my:(e=50,t=0)=>S(`/virtual-hangouts/my?limit=${e}&offset=${t}`,{schema:C(r.Array(On))}),get:e=>S(`/virtual-hangouts/${e}`,{schema:C(On)}),join:(e,t=!0,n=!0)=>S(`/virtual-hangouts/${e}/join`,{method:"POST",body:{showInMemberList:t,receiveNotifications:n},schema:C(r.Object({message:r.String()}))}),leave:e=>S(`/virtual-hangouts/${e}/leave`,{method:"POST",schema:C(r.Object({message:r.String()}))}),members:(e,t=50,n=0)=>S(`/virtual-hangouts/${e}/members?limit=${t}&offset=${n}`,{schema:C(r.Array(Am))}),activity:(e,t=50,n=0)=>S(`/virtual-hangouts/${e}/activity?limit=${t}&offset=${n}`,{schema:C(r.Array(_m))}),shareWorkout:(e,t,n)=>S(`/virtual-hangouts/${e}/share-workout`,{method:"POST",body:{workoutId:t,message:n},schema:C(r.Object({message:r.String()}))}),heartbeat:e=>S(`/virtual-hangouts/${e}/heartbeat`,{method:"POST",schema:C(r.Object({acknowledged:r.Boolean()}))}),posts:(e,t)=>S(`/virtual-hangouts/${e}/posts?${new URLSearchParams({limit:String(t?.limit||20),offset:String(t?.offset||0),sortBy:t?.sortBy||"hot"}).toString()}`,{schema:C(r.Array(Vt))}),createPost:(e,t)=>S(`/virtual-hangouts/${e}/posts`,{method:"POST",body:t,schema:C(Vt)})},communities:{create:e=>S("/communities",{method:"POST",body:e,schema:C(Nn)}),search:e=>{const t=new URLSearchParams;e?.query&&t.set("query",e.query),e?.communityType&&t.set("communityType",e.communityType),e?.goalType&&t.set("goalType",e.goalType),e?.institutionType&&t.set("institutionType",e.institutionType),e?.limit&&t.set("limit",String(e.limit)),e?.offset&&t.set("offset",String(e.offset));const n=t.toString();return S(`/communities${n?`?${n}`:""}`,{schema:C(r.Array(Nn))})},my:(e=50,t=0)=>S(`/communities/my?limit=${e}&offset=${t}`,{schema:C(r.Array(Nn))}),get:e=>S(`/communities/${e}`,{schema:C(Nn)}),join:e=>S(`/communities/${e}/join`,{method:"POST",schema:C(r.Object({message:r.String(),status:r.String()}))}),leave:e=>S(`/communities/${e}/leave`,{method:"POST",schema:C(r.Object({message:r.String()}))}),members:(e,t=50,n=0,s="active")=>S(`/communities/${e}/members?limit=${t}&offset=${n}&status=${s}`,{schema:C(r.Array(Cm))}),events:(e,t=!0,n=20,s=0)=>S(`/communities/${e}/events?upcoming=${t}&limit=${n}&offset=${s}`,{schema:C(r.Array(ca))}),createEvent:(e,t)=>S(`/communities/${e}/events`,{method:"POST",body:t,schema:C(ca)}),posts:(e,t)=>S(`/communities/${e}/posts?${new URLSearchParams({limit:String(t?.limit||20),offset:String(t?.offset||0),sortBy:t?.sortBy||"hot"}).toString()}`,{schema:C(r.Array(Vt))}),createPost:(e,t)=>S(`/communities/${e}/posts`,{method:"POST",body:t,schema:C(Vt)})},bulletin:{getPost:e=>S(`/bulletin/posts/${e}`,{schema:C(Vt)}),votePost:(e,t)=>S(`/bulletin/posts/${e}/vote`,{method:"POST",body:{voteType:t},schema:C(r.Object({upvotes:r.Number(),downvotes:r.Number(),score:r.Number()}))}),getComments:(e,t=50,n=0)=>S(`/bulletin/posts/${e}/comments?limit=${t}&offset=${n}`,{schema:C(r.Array(la))}),addComment:(e,t,n)=>S(`/bulletin/posts/${e}/comments`,{method:"POST",body:{content:t,parentId:n},schema:C(la)}),voteComment:(e,t)=>S(`/bulletin/comments/${e}/vote`,{method:"POST",body:{voteType:t},schema:C(r.Object({upvotes:r.Number(),downvotes:r.Number(),score:r.Number()}))}),pinPost:e=>S(`/bulletin/posts/${e}/pin`,{method:"POST",schema:C(r.Object({message:r.String()}))}),unpinPost:e=>S(`/bulletin/posts/${e}/unpin`,{method:"POST",schema:C(r.Object({message:r.String()}))}),hidePost:e=>S(`/bulletin/posts/${e}/hide`,{method:"POST",schema:C(r.Object({message:r.String()}))})},exerciseLeaderboards:{get:e=>{const t=new URLSearchParams;return t.set("exerciseId",e.exerciseId),t.set("metricKey",e.metricKey),e.periodType&&t.set("periodType",e.periodType),e.hangoutId&&t.set("hangoutId",String(e.hangoutId)),e.gender&&t.set("gender",e.gender),e.ageBand&&t.set("ageBand",e.ageBand),e.limit&&t.set("limit",String(e.limit)),e.cursor&&t.set("cursor",e.cursor),S(`/leaderboards?${t.toString()}`,{schema:C(r.Object({entries:r.Array(r.Object({rank:r.Number(),userId:r.String(),username:r.String(),avatarUrl:r.Optional(r.String()),value:r.Number(),updatedAt:r.String()})),nextCursor:r.Optional(r.String()),hasMore:r.Boolean()}))})},global:e=>{const t=new URLSearchParams;e?.periodType&&t.set("periodType",e.periodType),e?.gender&&t.set("gender",e.gender),e?.ageBand&&t.set("ageBand",e.ageBand),e?.limit&&t.set("limit",String(e.limit));const n=t.toString();return S(`/leaderboards/global${n?`?${n}`:""}`,{schema:C(r.Object({entries:r.Array(r.Object({rank:r.Number(),userId:r.String(),username:r.String(),avatarUrl:r.Optional(r.String()),totalPoints:r.Number(),recordCount:r.Number()}))}))})},hangout:(e,t)=>{const n=new URLSearchParams;t?.exerciseId&&n.set("exerciseId",t.exerciseId),t?.metricKey&&n.set("metricKey",t.metricKey),t?.periodType&&n.set("periodType",t.periodType),t?.limit&&n.set("limit",String(t.limit));const s=n.toString();return S(`/hangouts/${e}/leaderboard${s?`?${s}`:""}`,{schema:C(r.Object({entries:r.Array(r.Object({rank:r.Number(),userId:r.String(),username:r.String(),avatarUrl:r.Optional(r.String()),value:r.Number(),updatedAt:r.String()}))}))})},myRank:e=>{const t=new URLSearchParams;return t.set("exerciseId",e.exerciseId),t.set("metricKey",e.metricKey),e.periodType&&t.set("periodType",e.periodType),e.hangoutId&&t.set("hangoutId",String(e.hangoutId)),S(`/me/rank?${t.toString()}`,{schema:C(r.Object({rank:r.Number(),percentile:r.Number(),value:r.Number(),totalParticipants:r.Number()}))})},metrics:()=>S("/leaderboards/metrics",{schema:C(r.Array(r.Object({id:r.String(),exerciseId:r.String(),metricKey:r.String(),displayName:r.String(),unit:r.String(),direction:r.String()}))),cacheTtl:3e5})},achievements:{definitions:()=>S("/achievements/definitions",{schema:C(r.Array(r.Object({id:r.String(),key:r.String(),name:r.String(),description:r.Optional(r.String()),icon:r.Optional(r.String()),category:r.String(),points:r.Number(),rarity:r.String(),enabled:r.Boolean()}))),cacheTtl:3e5}),my:e=>{const t=new URLSearchParams;e?.limit&&t.set("limit",String(e.limit)),e?.cursor&&t.set("cursor",e.cursor),e?.category&&t.set("category",e.category);const n=t.toString();return S(`/me/achievements${n?`?${n}`:""}`,{schema:C(r.Array(r.Object({id:r.String(),achievementKey:r.String(),achievementName:r.String(),achievementDescription:r.Optional(r.String()),achievementIcon:r.Optional(r.String()),category:r.String(),points:r.Number(),rarity:r.String(),earnedAt:r.String(),value:r.Optional(r.Number()),hangoutId:r.Optional(r.Number()),exerciseId:r.Optional(r.String())})))})},summary:()=>S("/me/achievements/summary",{schema:C(r.Object({totalPoints:r.Number(),totalAchievements:r.Number(),byCategory:r.Record(r.String(),r.Number()),byRarity:r.Record(r.String(),r.Number()),recentAchievements:r.Array(r.Object({id:r.String(),achievementKey:r.String(),achievementName:r.String(),category:r.String(),points:r.Number(),rarity:r.String(),earnedAt:r.String()}))}))}),hangoutFeed:(e,t)=>{const n=new URLSearchParams;t?.limit&&n.set("limit",String(t.limit)),t?.cursor&&n.set("cursor",t.cursor);const s=n.toString();return S(`/hangouts/${e}/achievements${s?`?${s}`:""}`,{schema:C(r.Array(r.Object({id:r.String(),userId:r.String(),username:r.String(),avatarUrl:r.Optional(r.String()),achievementName:r.String(),achievementIcon:r.Optional(r.String()),points:r.Number(),rarity:r.String(),earnedAt:r.String()})))})}},verifications:{getRequired:()=>S("/achievements/verification-required",{schema:C(r.Array(r.Object({id:r.String(),key:r.String(),name:r.String(),description:r.Optional(r.String()),tier:r.String(),rarity:r.String(),points:r.Number()}))),cacheTtl:3e5}),canVerify:e=>S(`/achievements/${e}/can-verify`),submit:(e,t)=>{const n=new FormData;return n.append("witness_user_id",t.witnessUserId),t.notes&&n.append("notes",t.notes),t.video&&n.append("video",t.video),S(`/achievements/${e}/verify`,{method:"POST",body:n,headers:{}})},my:e=>{const t=new URLSearchParams;e?.status&&t.set("status",e.status),e?.limit&&t.set("limit",String(e.limit)),e?.offset&&t.set("offset",String(e.offset));const n=t.toString();return S(`/me/verifications${n?`?${n}`:""}`)},get:e=>S(`/verifications/${e}`),cancel:e=>S(`/verifications/${e}`,{method:"DELETE"}),witnessRequests:e=>{const t=new URLSearchParams;e?.status&&t.set("status",e.status),e?.limit&&t.set("limit",String(e.limit)),e?.offset&&t.set("offset",String(e.offset));const n=t.toString();return S(`/me/witness-requests${n?`?${n}`:""}`)},attest:(e,t)=>S(`/verifications/${e}/witness`,{method:"POST",body:{confirm:t.confirm,attestation_text:t.attestationText,relationship:t.relationship,location_description:t.locationDescription,is_public:t.isPublic}})},cohortPreferences:{get:()=>S("/me/cohort-preferences",{schema:C(r.Object({gender:r.Optional(r.String()),ageBand:r.Optional(r.String()),adaptiveCategory:r.Optional(r.String()),leaderboardOptIn:r.Boolean(),showGenderInLeaderboard:r.Boolean(),showAgeInLeaderboard:r.Boolean()}))}),update:e=>S("/me/cohort-preferences",{method:"PATCH",body:e,schema:C(r.Object({gender:r.Optional(r.String()),ageBand:r.Optional(r.String()),adaptiveCategory:r.Optional(r.String()),leaderboardOptIn:r.Boolean(),showGenderInLeaderboard:r.Boolean(),showAgeInLeaderboard:r.Boolean()}))}),optIn:()=>S("/me/leaderboard-opt-in",{method:"POST",schema:C(r.Object({leaderboardOptIn:r.Boolean(),message:r.String()}))}),optOut:()=>S("/me/leaderboard-opt-out",{method:"POST",schema:C(r.Object({leaderboardOptIn:r.Boolean(),message:r.String()}))}),options:()=>S("/cohort-options",{schema:C(r.Object({genderOptions:r.Array(r.String()),ageBandOptions:r.Array(r.String()),adaptiveCategoryOptions:r.Array(r.String())})),cacheTtl:3e5})},checkins:{checkIn:(e,t)=>S(`/hangouts/${e}/check-in`,{method:"POST",body:t||{},schema:C(r.Object({id:r.String(),checkInTime:r.String(),message:r.String()}))}),checkOut:(e,t)=>S(`/hangouts/${e}/check-out`,{method:"POST",body:t||{},schema:C(r.Object({checkOutTime:r.String(),duration:r.Number(),message:r.String()}))}),activeAt:e=>S(`/hangouts/${e}/check-ins/active`,{schema:C(r.Array(r.Object({id:r.String(),userId:r.String(),username:r.String(),avatarUrl:r.Optional(r.String()),checkInTime:r.String()})))}),myActive:()=>S("/me/check-in",{schema:C(r.Union([r.Object({id:r.String(),hangoutId:r.Number(),hangoutName:r.String(),checkInTime:r.String()}),r.Null()]))}),myHistory:e=>{const t=new URLSearchParams;e?.limit&&t.set("limit",String(e.limit)),e?.offset&&t.set("offset",String(e.offset));const n=t.toString();return S(`/me/check-ins${n?`?${n}`:""}`,{schema:C(r.Array(r.Object({id:r.String(),hangoutId:r.Number(),hangoutName:r.String(),checkInTime:r.String(),checkOutTime:r.Optional(r.String()),duration:r.Optional(r.Number()),workoutId:r.Optional(r.String())})))})}},get:e=>S(e),post:(e,t)=>S(e,{method:"POST",body:t}),put:(e,t)=>S(e,{method:"PUT",body:t}),patch:(e,t)=>S(e,{method:"PATCH",body:t}),delete:e=>S(e,{method:"DELETE"}),social:{follow:e=>S(`/users/${e}/follow`,{method:"POST"}),unfollow:e=>S(`/users/${e}/follow`,{method:"DELETE"}),getFollowers:(e,t=50,n=0)=>S(`/users/${e}/followers?limit=${t}&offset=${n}`),getFollowing:(e,t=50,n=0)=>S(`/users/${e}/following?limit=${t}&offset=${n}`),isFollowing:e=>S(`/users/${e}/is-following`),sendFriendRequest:(e,t)=>S(`/users/${e}/friend-request`,{method:"POST",body:t}),acceptFriendRequest:e=>S(`/friend-requests/${e}/accept`,{method:"POST"}),declineFriendRequest:e=>S(`/friend-requests/${e}/decline`,{method:"POST"}),getPendingFriendRequests:()=>S("/friend-requests"),getFriends:(e=50,t=0)=>S(`/friends?limit=${e}&offset=${t}`),removeFriend:e=>S(`/friends/${e}`,{method:"DELETE"}),blockUser:e=>S(`/users/${e}/block`,{method:"POST"}),getBuddyPreferences:()=>S("/buddy/preferences"),updateBuddyPreferences:e=>S("/buddy/preferences",{method:"PUT",body:e}),findBuddyMatches:(e=20)=>S(`/buddy/matches?limit=${e}`),sendBuddyRequest:(e,t)=>S(`/users/${e}/buddy-request`,{method:"POST",body:t?{message:t}:void 0}),getPendingBuddyRequests:()=>S("/buddy/requests"),acceptBuddyRequest:e=>S(`/buddy/requests/${e}/accept`,{method:"POST"}),declineBuddyRequest:e=>S(`/buddy/requests/${e}/decline`,{method:"POST"}),getBuddyPairs:()=>S("/buddy/pairs")},mentorship:{searchMentors:e=>{const t=new URLSearchParams;e?.specialties&&t.set("specialties",e.specialties.join(",")),e?.minRating&&t.set("minRating",String(e.minRating)),e?.isPro!==void 0&&t.set("isPro",String(e.isPro)),e?.maxHourlyRate&&t.set("maxHourlyRate",String(e.maxHourlyRate)),e?.limit&&t.set("limit",String(e.limit)),e?.offset&&t.set("offset",String(e.offset));const n=t.toString();return S(`/mentors${n?`?${n}`:""}`)},getMentor:e=>S(`/mentors/${e}`),updateMentorProfile:e=>S("/mentor/profile",{method:"PUT",body:e}),requestMentorship:(e,t)=>S(`/mentors/${e}/request`,{method:"POST",body:t}),getPendingRequests:()=>S("/mentorship/requests"),acceptMentorship:e=>S(`/mentorships/${e}/accept`,{method:"POST"}),declineMentorship:e=>S(`/mentorships/${e}/decline`,{method:"POST"}),getActiveMentorships:()=>S("/mentorships/active"),getMentorshipHistory:(e=20,t=0)=>S(`/mentorships/history?limit=${e}&offset=${t}`),completeMentorship:(e,t)=>S(`/mentorships/${e}/complete`,{method:"POST",body:t}),cancelMentorship:e=>S(`/mentorships/${e}/cancel`,{method:"POST"}),createCheckIn:(e,t)=>S(`/mentorships/${e}/check-ins`,{method:"POST",body:t}),getCheckIns:(e,t=20,n=0)=>S(`/mentorships/${e}/check-ins?limit=${t}&offset=${n}`),completeCheckIn:e=>S(`/check-ins/${e}/complete`,{method:"POST"})},communityAnalytics:{getDailyAnalytics:(e,t)=>{const n=new URLSearchParams;t?.startDate&&n.set("startDate",t.startDate),t?.endDate&&n.set("endDate",t.endDate),t?.limit&&n.set("limit",String(t.limit));const s=n.toString();return S(`/communities/${e}/analytics/daily${s?`?${s}`:""}`)},refreshAnalytics:e=>S(`/communities/${e}/analytics/refresh`,{method:"POST"}),getHealthScore:e=>S(`/communities/${e}/health`),calculateHealthScore:e=>S(`/communities/${e}/health/calculate`,{method:"POST"}),getHealthHistory:(e,t=30)=>S(`/communities/${e}/health/history?limit=${t}`),getGrowthTrends:(e,t="daily",n=12)=>S(`/communities/${e}/analytics/growth?period=${t}&limit=${n}`),getEngagementBreakdown:(e,t)=>{const n=new URLSearchParams;t?.startDate&&n.set("startDate",t.startDate),t?.endDate&&n.set("endDate",t.endDate);const s=n.toString();return S(`/communities/${e}/analytics/engagement${s?`?${s}`:""}`)},getTopContributors:(e,t=30,n=10)=>S(`/communities/${e}/analytics/top-contributors?days=${t}&limit=${n}`),compareCommunities:e=>S("/analytics/compare",{method:"POST",body:{communityIds:e}})},communityResources:{getResources:(e,t)=>{const n=new URLSearchParams;t?.resourceType&&n.set("resourceType",t.resourceType),t?.category&&n.set("category",t.category),t?.tags&&n.set("tags",t.tags.join(",")),t?.isPinned!==void 0&&n.set("isPinned",String(t.isPinned)),t?.searchQuery&&n.set("searchQuery",t.searchQuery),t?.limit&&n.set("limit",String(t.limit)),t?.offset&&n.set("offset",String(t.offset)),t?.sortBy&&n.set("sortBy",t.sortBy);const s=n.toString();return S(`/communities/${e}/resources${s?`?${s}`:""}`)},getPinnedResources:e=>S(`/communities/${e}/resources/pinned`),getCategories:e=>S(`/communities/${e}/resources/categories`),getResource:e=>S(`/resources/${e}`),createResource:(e,t)=>S(`/communities/${e}/resources`,{method:"POST",body:t}),updateResource:(e,t)=>S(`/resources/${e}`,{method:"PUT",body:t}),deleteResource:e=>S(`/resources/${e}`,{method:"DELETE"}),pinResource:e=>S(`/resources/${e}/pin`,{method:"POST"}),unpinResource:e=>S(`/resources/${e}/pin`,{method:"DELETE"}),markHelpful:e=>S(`/resources/${e}/helpful`,{method:"POST"}),removeHelpful:e=>S(`/resources/${e}/helpful`,{method:"DELETE"}),getMostHelpful:e=>{const t=new URLSearchParams;e?.limit&&t.set("limit",String(e.limit)),e?.communityIds&&t.set("communityIds",e.communityIds.join(","));const n=t.toString();return S(`/resources/most-helpful${n?`?${n}`:""}`)}},reports:{submit:e=>S("/reports",{method:"POST",body:e}),getMyReports:()=>S("/reports/my"),getPendingReports:e=>{const t=new URLSearchParams;e?.communityId&&t.set("communityId",String(e.communityId)),e?.status&&t.set("status",Array.isArray(e.status)?e.status.join(","):e.status),e?.reason&&t.set("reason",e.reason),e?.limit&&t.set("limit",String(e.limit)),e?.offset&&t.set("offset",String(e.offset));const n=t.toString();return S(`/reports${n?`?${n}`:""}`)},getReport:e=>S(`/reports/${e}`),assignReport:e=>S(`/reports/${e}/assign`,{method:"POST"}),resolveReport:(e,t)=>S(`/reports/${e}/resolve`,{method:"POST",body:t}),getStats:e=>{const t=e?`?communityId=${e}`:"";return S(`/reports/stats${t}`)},getUserModerationHistory:e=>S(`/users/${e}/moderation-history`),getUserModerationStatus:e=>S(`/users/${e}/moderation-status`),applyModerationAction:(e,t)=>S(`/users/${e}/moderate`,{method:"POST",body:t})},archetypeCommunities:{getSuggestedCommunities:()=>S("/archetype/suggested-communities"),handleArchetypeChange:(e,t)=>S("/archetype/change",{method:"POST",body:{newArchetypeId:e,...t}}),getLinkedCommunities:e=>S(`/archetypes/${e}/communities`),getDefaultCommunities:e=>S(`/archetypes/${e}/communities/default`),linkCommunity:(e,t,n)=>S(`/archetypes/${e}/communities`,{method:"POST",body:{communityId:t,...n}}),bulkLinkCommunities:(e,t)=>S(`/archetypes/${e}/communities/bulk`,{method:"POST",body:{links:t}}),unlinkCommunity:(e,t)=>S(`/archetypes/${e}/communities/${t}`,{method:"DELETE"}),getAllArchetypesWithCommunities:()=>S("/archetypes/communities")},skills:{getTrees:()=>S("/skills/trees",{cacheTtl:3e5}),getTree:e=>S(`/skills/trees/${e}`,{cacheTtl:3e5}),getTreeProgress:e=>S(`/skills/trees/${e}/progress`),getNode:e=>S(`/skills/nodes/${e}`,{cacheTtl:3e5}),getNodeLeaderboard:(e,t=10)=>S(`/skills/nodes/${e}/leaderboard?limit=${t}`),getProgress:()=>S("/skills/progress"),logPractice:e=>S("/skills/practice",{method:"POST",body:e}),achieveSkill:e=>S("/skills/achieve",{method:"POST",body:e}),getHistory:e=>S(`/skills/history?limit=${e?.limit??20}&offset=${e?.offset??0}${e?.skillNodeId?`&skillNodeId=${e.skillNodeId}`:""}`),updateNotes:(e,t)=>S(`/skills/nodes/${e}/notes`,{method:"PUT",body:{notes:t}})},ranks:{definitions:()=>S("/ranks/definitions",{cacheTtl:3e5}),me:()=>S("/ranks/me"),getUser:e=>S(`/ranks/user/${e}`),history:e=>{const t=new URLSearchParams;e?.limit&&t.set("limit",String(e.limit)),e?.offset&&t.set("offset",String(e.offset)),e?.sourceType&&t.set("sourceType",e.sourceType);const n=t.toString();return S(`/ranks/history${n?`?${n}`:""}`)},leaderboard:e=>{const t=new URLSearchParams;e?.scope&&t.set("scope",e.scope),e?.country&&t.set("country",e.country),e?.state&&t.set("state",e.state),e?.city&&t.set("city",e.city),e?.limit&&t.set("limit",String(e.limit)),e?.offset&&t.set("offset",String(e.offset));const n=t.toString();return S(`/ranks/leaderboard${n?`?${n}`:""}`)},veteranBadge:()=>S("/ranks/veteran-badge")},feedback:{create:e=>S("/feedback",{method:"POST",body:e}),list:e=>{const t=new URLSearchParams;e?.type&&t.set("type",e.type),e?.status&&t.set("status",e.status),e?.limit&&t.set("limit",String(e.limit)),e?.cursor&&t.set("cursor",e.cursor);const n=t.toString();return S(`/feedback${n?`?${n}`:""}`)},get:e=>S(`/feedback/${e}`),respond:(e,t)=>S(`/feedback/${e}/respond`,{method:"POST",body:{message:t}}),popularFeatures:(e=10)=>S(`/feedback/features/popular?limit=${e}`),upvote:e=>S(`/feedback/${e}/upvote`,{method:"POST"}),removeUpvote:e=>S(`/feedback/${e}/upvote`,{method:"DELETE"}),getFaq:e=>{const t=new URLSearchParams;e?.category&&t.set("category",e.category),e?.search&&t.set("search",e.search);const n=t.toString();return S(`/faq${n?`?${n}`:""}`,{cacheTtl:3e5})},faqCategories:()=>S("/faq/categories",{cacheTtl:3e5}),getFaqEntry:e=>S(`/faq/${e}`),markFaqHelpful:(e,t)=>S(`/faq/${e}/helpful`,{method:"POST",body:{helpful:t}}),search:e=>S(`/feedback/search?q=${encodeURIComponent(e)}`)}},Em=r.Object({id:r.String(),name:r.String(),tagline:r.Optional(r.String()),description:r.Optional(r.String()),primaryColor:r.String(),secondaryColor:r.String(),accentColor:r.String(),backgroundImageUrl:r.Optional(r.String()),iconUrl:r.Optional(r.String()),bannerUrl:r.Optional(r.String()),archetypeCategoryId:r.Optional(r.String()),goalTypes:r.Array(r.String()),targetAudiences:r.Array(r.String()),isActive:r.Boolean()},{additionalProperties:!0}),On=r.Object({id:r.Number(),themeId:r.String(),themeName:r.String(),customName:r.Optional(r.String()),customDescription:r.Optional(r.String()),customBannerUrl:r.Optional(r.String()),primaryColor:r.String(),accentColor:r.String(),memberCount:r.Number(),activeMemberCount:r.Number(),postCount:r.Number(),isActive:r.Boolean(),createdAt:r.String(),updatedAt:r.String(),isMember:r.Optional(r.Boolean()),userRole:r.Optional(r.Number()),lastVisitedAt:r.Optional(r.String())},{additionalProperties:!0}),Am=r.Object({userId:r.String(),username:r.String(),displayName:r.Optional(r.String()),avatarUrl:r.Optional(r.String()),role:r.Number(),joinedAt:r.String(),lastActiveAt:r.Optional(r.String()),showInMemberList:r.Boolean(),receiveNotifications:r.Boolean()},{additionalProperties:!0}),_m=r.Object({id:r.String(),hangoutId:r.Number(),userId:r.Optional(r.String()),username:r.Optional(r.String()),activityType:r.String(),activityData:r.Record(r.String(),r.Any()),createdAt:r.String()},{additionalProperties:!0}),Nn=r.Object({id:r.Number(),slug:r.String(),name:r.String(),tagline:r.Optional(r.String()),description:r.Optional(r.String()),communityType:r.String(),goalType:r.Optional(r.String()),institutionType:r.Optional(r.String()),archetypeId:r.Optional(r.Number()),privacy:r.String(),iconEmoji:r.String(),accentColor:r.String(),bannerImageUrl:r.Optional(r.String()),logoImageUrl:r.Optional(r.String()),rules:r.Optional(r.String()),memberCount:r.Number(),postCount:r.Number(),isVerified:r.Boolean(),isActive:r.Boolean(),requiresApproval:r.Boolean(),allowMemberPosts:r.Boolean(),createdBy:r.String(),createdAt:r.String(),updatedAt:r.String(),isMember:r.Optional(r.Boolean()),userRole:r.Optional(r.Number()),membershipStatus:r.Optional(r.String())},{additionalProperties:!0}),Cm=r.Object({userId:r.String(),username:r.String(),displayName:r.Optional(r.String()),avatarUrl:r.Optional(r.String()),role:r.Number(),title:r.Optional(r.String()),status:r.String(),joinedAt:r.String(),lastActiveAt:r.Optional(r.String()),showInMemberList:r.Boolean()},{additionalProperties:!0}),ca=r.Object({id:r.String(),communityId:r.Number(),virtualHangoutId:r.Optional(r.Number()),creatorId:r.String(),title:r.String(),description:r.Optional(r.String()),eventType:r.String(),startsAt:r.String(),endsAt:r.Optional(r.String()),timezone:r.String(),locationName:r.Optional(r.String()),locationAddress:r.Optional(r.String()),isVirtual:r.Boolean(),virtualUrl:r.Optional(r.String()),maxParticipants:r.Optional(r.Number()),participantCount:r.Number(),status:r.String(),createdAt:r.String()},{additionalProperties:!0}),Vt=r.Object({id:r.String(),boardId:r.Number(),authorId:r.Optional(r.String()),authorUsername:r.Optional(r.String()),authorDisplayName:r.Optional(r.String()),authorAvatarUrl:r.Optional(r.String()),title:r.String(),content:r.String(),contentLang:r.String(),postType:r.String(),mediaUrls:r.Array(r.String()),linkedWorkoutId:r.Optional(r.String()),linkedMilestoneId:r.Optional(r.String()),upvotes:r.Number(),downvotes:r.Number(),score:r.Number(),commentCount:r.Number(),viewCount:r.Number(),isPinned:r.Boolean(),isHighlighted:r.Boolean(),isHidden:r.Boolean(),createdAt:r.String(),updatedAt:r.String(),userVote:r.Optional(r.String())},{additionalProperties:!0}),la=r.Object({id:r.String(),postId:r.String(),parentId:r.Optional(r.String()),authorId:r.Optional(r.String()),authorUsername:r.Optional(r.String()),authorDisplayName:r.Optional(r.String()),authorAvatarUrl:r.Optional(r.String()),content:r.String(),upvotes:r.Number(),downvotes:r.Number(),score:r.Number(),replyCount:r.Number(),isHidden:r.Boolean(),createdAt:r.String(),updatedAt:r.String(),userVote:r.Optional(r.String()),replies:r.Optional(r.Array(r.Any()))},{additionalProperties:!0}),km=3e3,Rm=5,Pm=3e4;function Mm(e,t,n){let s;if(n){const i=n.startsWith("https")?"wss:":"ws:",a=n.replace(/^https?:\/\//,"");s=`${i}//${a}${e}`}else if(typeof window<"u")s=`${window.location.protocol==="https:"?"wss:":"ws:"}//${window.location.host}${e}`;else throw new Error("WebSocket URL cannot be determined. Provide baseUrl option.");return t&&(s+=`?token=${encodeURIComponent(t)}`),s}function dE(e,t={}){const{autoConnect:n=!0,onMessage:s,onSnapshot:i,token:a,baseUrl:o}=t,[l,u]=m.useState(!1),[d,h]=m.useState(null),[f,g]=m.useState(null),[y,v]=m.useState([]),T=m.useRef(null),b=m.useRef(0),I=m.useRef(null),x=m.useCallback(()=>{if(T.current?.readyState!==WebSocket.OPEN)try{const A=Mm(e,a,o),k=new WebSocket(A);T.current=k,k.onopen=()=>{u(!0),h(null),b.current=0},k.onmessage=R=>{try{const P=JSON.parse(R.data);P.type==="snapshot"?(g(P.data),i?.(P.data)):P.type==="event"&&(v(O=>[P.data,...O].slice(0,100)),s?.(P.data))}catch{}},k.onerror=()=>{h("Connection error")},k.onclose=R=>{u(!1),T.current=null,R.code!==1e3&&b.current<Rm&&(b.current+=1,I.current=setTimeout(x,km))}}catch(A){h(A instanceof Error?A.message:"Failed to connect")}},[e,a,o,s,i]),w=m.useCallback(()=>{I.current&&(clearTimeout(I.current),I.current=null),T.current&&(T.current.close(1e3),T.current=null),u(!1)},[]),_=m.useCallback(()=>{T.current?.readyState===WebSocket.OPEN&&T.current.send(JSON.stringify({type:"heartbeat"}))},[]);return m.useEffect(()=>(n&&x(),()=>{w()}),[n,x,w]),m.useEffect(()=>{if(!l)return;const A=setInterval(_,Pm);return()=>clearInterval(A)},[l,_]),{connected:l,error:d,snapshot:f,events:y,connect:x,disconnect:w,sendHeartbeat:_}}const Om="modulepreload",Nm=function(e){return"/"+e},ua={},E=function(t,n,s){let i=Promise.resolve();if(n&&n.length>0){document.getElementsByTagName("link");const o=document.querySelector("meta[property=csp-nonce]"),l=o?.nonce||o?.getAttribute("nonce");i=Promise.allSettled(n.map(u=>{if(u=Nm(u),u in ua)return;ua[u]=!0;const d=u.endsWith(".css"),h=d?'[rel="stylesheet"]':"";if(document.querySelector(`link[href="${u}"]${h}`))return;const f=document.createElement("link");if(f.rel=d?"stylesheet":Om,d||(f.as="script"),f.crossOrigin="",f.href=u,l&&f.setAttribute("nonce",l),document.head.appendChild(f),d)return new Promise((g,y)=>{f.addEventListener("load",g),f.addEventListener("error",()=>y(new Error(`Unable to preload CSS for ${u}`)))})}))}function a(o){const l=new Event("vite:preloadError",{cancelable:!0});if(l.payload=o,window.dispatchEvent(l),!l.defaultPrevented)throw o}return i.then(o=>{for(const l of o||[])l.status==="rejected"&&a(l.reason);return t().catch(a)})};function $m(){if(typeof window>"u")return!1;try{const e=navigator.userAgent||"",t=/iPad|iPhone|iPod/.test(e),n=!!navigator.brave,s=$e.createElement("div",{key:"test"},"test"),i=m.cloneElement(s,{"data-test":"true"});if(!i||!i.props)return!0;const a=m.Children.toArray(s);return!!(!Array.isArray(a)||t&&n)}catch{return!0}}let Is=null;function da(){return Is===null&&(Is=$m()),Is}function ma({children:e,mode:t="sync",initial:n=!0}){return m.useEffect(()=>{try{const s=new XMLHttpRequest;s.open("POST","/api/client-error",!0),s.setRequestHeader("Content-Type","application/json"),s.send(JSON.stringify({type:"component_mount",message:`[AnimatePresenceLite] Mounted, mode: ${t}, restrictive: ${da()}`,source:"AnimatePresenceLite.tsx",time:new Date().toISOString()}))}catch{}},[t,n]),da()?c.jsx(c.Fragment,{children:e}):c.jsx(Dm,{mode:t,initial:n,children:e})}function Dm({children:e,mode:t="sync",initial:n=!0}){const[s,i]=m.useState(()=>{try{return n?m.Children.toArray(e):[]}catch{return[]}}),[a,o]=m.useState(!1),l=m.useRef([]);return m.useEffect(()=>{try{l.current=m.Children.toArray(e)}catch{}},[e]),m.useEffect(()=>{try{const u=m.Children.toArray(e),d=l.current,h=u.map(y=>y?.key),f=d.map(y=>y?.key);if(JSON.stringify(h)!==JSON.stringify(f))if(t==="wait"){o(!0),i(v=>v.map(T=>{try{return m.cloneElement(T,{"data-animate-state":"exit"})}catch{return T}}));const y=setTimeout(()=>{i(u.map(T=>{try{return m.cloneElement(T,{"data-animate-state":"enter"})}catch{return T}}));const v=setTimeout(()=>{i(u),o(!1)},300);return()=>clearTimeout(v)},200);return()=>clearTimeout(y)}else i(u);l.current=u}catch{i([e])}},[e,t]),s.length===0?e?c.jsx(c.Fragment,{children:e}):null:c.jsx(c.Fragment,{children:s})}function jm({isVisible:e,progress:t=0}){const[n,s]=m.useState(e),[i,a]=m.useState(!1);return m.useEffect(()=>{if(e)s(!0),a(!1);else if(n){a(!0);const o=setTimeout(()=>{s(!1),a(!1)},300);return()=>clearTimeout(o)}},[e,n]),n?c.jsxs("div",{className:`fixed top-0 left-0 right-0 z-[9999] h-1 overflow-hidden transition-opacity duration-300 ${i?"opacity-0":"opacity-100"}`,children:[c.jsx("div",{className:"absolute inset-0 bg-black/10"}),c.jsx("div",{className:"h-full bg-gradient-to-r from-[var(--brand-blue-500)] via-[var(--brand-pulse-500)] to-[var(--brand-blue-400)] transition-[width] duration-200 ease-out",style:{width:`${t<100?Math.max(t,30):100}%`,boxShadow:"0 0 10px rgba(0, 102, 255, 0.5), 0 0 20px rgba(0, 102, 255, 0.3)"}}),c.jsx("div",{className:"absolute top-0 h-full w-32 bg-gradient-to-r from-transparent via-white/30 to-transparent animate-shimmer",style:{animation:"shimmer 1.5s linear infinite"}}),c.jsx("style",{children:`
        @keyframes shimmer {
          0% { transform: translateX(-100%); }
          100% { transform: translateX(400%); }
        }
      `})]}):null}const Lm=m.lazy(()=>E(()=>import("./index-d0c3qloy.js"),__vite__mapDeps([0,1,2,3,4,5,6])).then(e=>({default:e.AnimatePresence})));function Um(){if(typeof window>"u")return!1;try{const e=navigator.userAgent||"",t=/iPad|iPhone|iPod/.test(e),n=!!navigator.brave;if(t&&n)return!0;if(t)try{const s=document.createElement("canvas");if(!(s.getContext("webgl")||s.getContext("experimental-webgl")))return!0}catch{return!0}return!1}catch{return!0}}function Vm(){if(typeof window<"u"){if(window.matchMedia("(prefers-reduced-motion: reduce)").matches)return!1;const t=navigator.connection||navigator.mozConnection||navigator.webkitConnection;if(t&&(t.effectiveType==="2g"||t.effectiveType==="slow-2g"||t.saveData)||navigator.deviceMemory&&navigator.deviceMemory<4||navigator.hardwareConcurrency&&navigator.hardwareConcurrency<4)return!1}return!0}let xs=null,Es=null;function Bm(){return xs===null&&(xs=Vm()),xs}function Fm(){return Es===null&&(Es=Um()),Es}function qm({children:e,mode:t="wait",initial:n=!0}){const[s,i]=m.useState(!1),[a,o]=m.useState(!1);return m.useEffect(()=>{const l=Fm();o(l);try{const d=new XMLHttpRequest;d.open("POST","/api/client-error",!0),d.setRequestHeader("Content-Type","application/json"),d.send(JSON.stringify({type:"component_mount",message:`[AdaptiveAnimatePresence] Mounted, restrictive: ${l}`,source:"AdaptiveAnimatePresence.tsx",time:new Date().toISOString()}))}catch{}if(l)return;const u=setTimeout(()=>{i(Bm())},100);return()=>clearTimeout(u)},[]),a?c.jsx(c.Fragment,{children:e}):s?c.jsx(m.Suspense,{fallback:c.jsx(ma,{mode:t,initial:n,children:e}),children:c.jsx(Lm,{mode:t,initial:n,children:e})}):c.jsx(ma,{mode:t,initial:n,children:e})}function Wm({isVisible:e,progress:t=0}){return c.jsx(jm,{isVisible:e,progress:t})}const Gr="musclemap-apollo-cache",we="cache",mr=5*1024*1024;function Yr(){try{return!(typeof indexedDB>"u"||indexedDB===null||typeof IDBFactory>"u")}catch{return!1}}async function zm(e){try{if(!Yr())return!1;const{openDB:t}=await E(async()=>{const{openDB:a}=await import("./index-n74ppay5.js");return{openDB:a}},[]),{persistCache:n}=await E(async()=>{const{persistCache:a}=await import("./index-fpv2v8v8.js");return{persistCache:a}},[]);try{(await t("__idb_test__",1,{upgrade(o){o.createObjectStore("test")}})).close(),await indexedDB.deleteDatabase("__idb_test__")}catch{return!1}const s=await t(Gr,1,{upgrade(a){a.objectStoreNames.contains(we)||a.createObjectStore(we)}});return await n({cache:e,storage:{async getItem(a){try{return await s.get(we,a)}catch{return null}},async setItem(a,o){try{await s.put(we,o,a)}catch(l){if(l?.name==="QuotaExceededError")try{await s.clear(we),await s.put(we,o,a)}catch{}}},async removeItem(a){try{await s.delete(we,a)}catch{}}},maxSize:mr,trigger:"write",debounce:1e3,debug:!1}),!0}catch{return!1}}async function kc(){try{if(!Yr())return;const{openDB:e}=await E(async()=>{const{openDB:n}=await import("./index-n74ppay5.js");return{openDB:n}},[]),t=await e(Gr,1);t.objectStoreNames.contains(we)&&await t.clear(we)}catch{}}async function Hm(){try{if(!Yr())return null;const{openDB:e}=await E(async()=>{const{openDB:a}=await import("./index-n74ppay5.js");return{openDB:a}},[]),t=await e(Gr,1);if(!t.objectStoreNames.contains(we))return null;const n=await t.getAllKeys(we),s=await t.getAll(we);let i=0;for(const a of s)i+=new Blob([JSON.stringify(a)]).size;return{entries:n.length,sizeBytes:i,sizeMB:(i/(1024*1024)).toFixed(2),maxSizeMB:(mr/(1024*1024)).toFixed(2),percentUsed:(i/mr*100).toFixed(1)}}catch{return null}}class Gm{memoryStorage=new Map;state=null;TEST_KEY="__mm_storage_test__";testLocalStorage(){try{if(typeof localStorage>"u"||localStorage===null)return!1;localStorage.setItem(this.TEST_KEY,"test");const t=localStorage.getItem(this.TEST_KEY);return localStorage.removeItem(this.TEST_KEY),t==="test"}catch{return!1}}testSessionStorage(){try{if(typeof sessionStorage>"u"||sessionStorage===null)return!1;sessionStorage.setItem(this.TEST_KEY,"test");const t=sessionStorage.getItem(this.TEST_KEY);return sessionStorage.removeItem(this.TEST_KEY),t==="test"}catch{return!1}}detectStorageType(){return this.state&&Date.now()-this.state.testedAt<5*60*1e3?this.state:this.testLocalStorage()?(this.state={type:"localStorage",available:!0,testedAt:Date.now()},this.state):this.testSessionStorage()?(this.state={type:"sessionStorage",available:!0,testedAt:Date.now()},this.state):(this.state={type:"memory",available:!0,testedAt:Date.now()},this.state)}getNativeStorage(){const t=this.detectStorageType();try{switch(t.type){case"localStorage":if(typeof localStorage<"u"&&localStorage!==null)return localStorage;break;case"sessionStorage":if(typeof sessionStorage<"u"&&sessionStorage!==null)return sessionStorage;break}}catch{}return null}getItem(t){const n=this.getNativeStorage();if(n)try{return n.getItem(t)}catch{}return this.memoryStorage.get(t)??null}setItem(t,n){const s=this.getNativeStorage();if(s)try{s.setItem(t,n);return}catch{}this.memoryStorage.set(t,n)}removeItem(t){const n=this.getNativeStorage();if(n)try{n.removeItem(t)}catch{}this.memoryStorage.delete(t)}clear(){const t=this.getNativeStorage();if(t)try{t.clear()}catch{}this.memoryStorage.clear()}getStorageType(){return this.detectStorageType().type}isPersistent(){return this.detectStorageType().type==="localStorage"}getStorageInfo(){const t=this.detectStorageType();return{type:t.type,isPersistent:t.type==="localStorage",memoryItemCount:this.memoryStorage.size}}}const de=new Gm,As="/api/graphql",Rc=5e3,hr=100,Ym=`
  mutation LogQAEvents($input: QALogInput!) {
    logQAEvents(input: $input) {
      success
      count
      sessionId
    }
  }
`;let ie=null,Re=[],Qt=null,Jt=null,Xt=null;function Km(){return`qa_${Date.now()}_${Math.random().toString(36).substring(2,9)}`}function xt(){try{return window.location.href}catch{return"unknown"}}function Pc(){try{return navigator.userAgent}catch{return"unknown"}}function oe(e,t){if(!ie?.isActive)return;const n={event_type:e,event_data:t,url:xt(),timestamp:new Date().toISOString()};Re.push(n),Re.length>hr&&(Re=Re.slice(-hr))}async function Zt(){if(!ie?.isActive||Re.length===0)return;const e=[...Re];Re=[];const t={query:Ym,variables:{input:{sessionId:ie.id,userAgent:Pc(),events:e.map(n=>({eventType:n.event_type,eventData:n.event_data,url:n.url,timestamp:n.timestamp}))}}};try{if(navigator.sendBeacon){const n=new Blob([JSON.stringify(t)],{type:"application/json"});navigator.sendBeacon(As,n)||await fetch(As,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(t),keepalive:!0})}else await fetch(As,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(t),keepalive:!0})}catch{Re=[...e,...Re].slice(-hr)}}function Mc(){window.onerror=(e,t,n,s,i)=>(oe("js_error",{message:String(e),source:t,lineno:n,colno:s,stack:i?.stack,name:i?.name}),!1),window.onunhandledrejection=e=>{const t=e.reason;oe("promise_rejection",{message:t?.message||String(t),stack:t?.stack,name:t?.name})},Jt=console.error,console.error=(...e)=>{oe("console_error",{message:e.map(t=>{try{return typeof t=="object"?JSON.stringify(t):String(t)}catch{return String(t)}}).join(" "),args:e.map(t=>{try{return t instanceof Error?{message:t.message,stack:t.stack,name:t.name}:typeof t=="object"?JSON.stringify(t).substring(0,500):String(t)}catch{return String(t)}})}),Jt?.apply(console,e)},Xt=console.warn,console.warn=(...e)=>{oe("console_warn",{message:e.map(t=>{try{return typeof t=="object"?JSON.stringify(t):String(t)}catch{return String(t)}}).join(" ")}),Xt?.apply(console,e)}}function Qm(){Jt&&(console.error=Jt,Jt=null),Xt&&(console.warn=Xt,Xt=null)}function Oc(){let e=xt(),t=Date.now();const n=history.pushState;history.pushState=function(...s){const i=n.apply(this,s),a=xt(),o=Date.now()-t;return oe("navigation",{from:e,to:a,loadTime:o,method:"pushState"}),e=a,t=Date.now(),i},window.addEventListener("popstate",()=>{const s=xt(),i=Date.now()-t;oe("navigation",{from:e,to:s,loadTime:i,method:"popstate"}),e=s,t=Date.now()})}function Nc(){document.addEventListener("click",e=>{const t=e.target;if(!t)return;const n=t.matches('button, a, [role="button"], input[type="submit"], [data-qa-track]'),s=t.closest('button, a, [role="button"], input[type="submit"], [data-qa-track]');if(n||s){const i=n?t:s;oe("interaction",{element:i.tagName.toLowerCase(),text:i.textContent?.substring(0,100)?.trim(),id:i.id||void 0,className:i.className||void 0,href:i.href||void 0,type:i.type||void 0})}},{passive:!0}),document.addEventListener("submit",e=>{const t=e.target;t&&oe("form_submit",{action:t.action,method:t.method,id:t.id||void 0,name:t.name||void 0})},{passive:!0})}function $c(){document.addEventListener("error",e=>{const t=e.target;if(t.tagName==="IMG"){const n=t;oe("image_error",{src:n.src,alt:n.alt,naturalWidth:n.naturalWidth,naturalHeight:n.naturalHeight})}},{capture:!0,passive:!0})}function Dc(){if(window.addEventListener("load",()=>{setTimeout(()=>{try{const e=performance.getEntriesByType("navigation");if(e.length>0){const t=e[0],n=t.loadEventEnd-t.startTime;n>2e3&&oe("slow_page_load",{loadTime:n,domContentLoaded:t.domContentLoadedEventEnd-t.startTime,domInteractive:t.domInteractive-t.startTime,url:xt()})}}catch{}},0)}),"PerformanceObserver"in window)try{new PerformanceObserver(t=>{for(const n of t.getEntries())n.duration>100&&oe("long_task",{duration:n.duration,startTime:n.startTime,name:n.name})}).observe({entryTypes:["longtask"]})}catch{}}function jc(){const e=window.fetch;window.fetch=async function(...t){const n=Date.now(),s=typeof t[0]=="string"?t[0]:t[0].url;try{const i=await e.apply(this,t),a=Date.now()-n;return a>3e3&&oe("slow_request",{url:s,duration:a,status:i.status,method:t[1]?.method||"GET"}),!i.ok&&i.status!==401&&oe("network_error",{url:s,status:i.status,statusText:i.statusText,method:t[1]?.method||"GET",duration:a}),i}catch(i){const a=Date.now()-n;throw oe("network_error",{url:s,error:i.message,method:t[1]?.method||"GET",duration:a,isOffline:!navigator.onLine}),i}}}function Jm(){if(ie?.isActive)return ie.id;ie={id:Km(),startedAt:new Date().toISOString(),isActive:!0},Mc(),Oc(),Nc(),$c(),Dc(),jc(),Qt=setInterval(Zt,Rc),window.addEventListener("beforeunload",Zt),document.addEventListener("visibilitychange",()=>{document.hidden&&Zt()});try{sessionStorage.setItem("qa_session_id",ie.id),sessionStorage.setItem("qa_session_started",ie.startedAt)}catch{}return oe("session_start",{sessionId:ie.id,userAgent:Pc(),screenWidth:window.screen?.width,screenHeight:window.screen?.height,devicePixelRatio:window.devicePixelRatio,online:navigator.onLine,language:navigator.language}),ie.id}function Xm(){if(ie?.isActive){oe("session_end",{sessionId:ie.id,duration:Date.now()-new Date(ie.startedAt).getTime(),totalEvents:Re.length}),Zt(),Qt&&(clearInterval(Qt),Qt=null),Qm();try{sessionStorage.removeItem("qa_session_id"),sessionStorage.removeItem("qa_session_started")}catch{}ie={...ie,isActive:!1}}}function pr(){return ie?.isActive??!1}function Zm(){try{const e=sessionStorage.getItem("qa_session_id"),t=sessionStorage.getItem("qa_session_started");e&&t&&(ie={id:e,startedAt:t,isActive:!0},Mc(),Oc(),Nc(),$c(),Dc(),jc(),Qt=setInterval(Zt,Rc),oe("page_load",{url:xt(),referrer:document.referrer}))}catch{}}function eh(){if(!(typeof window>"u"))try{const e=new URLSearchParams(window.location.search),t=e.get("qa");if(t==="start"){Jm(),e.delete("qa");const n=window.location.pathname+(e.toString()?"?"+e.toString():"");history.replaceState({},"",n)}else if(t==="end"){Xm(),e.delete("qa");const n=window.location.pathname+(e.toString()?"?"+e.toString():"");history.replaceState({},"",n)}else Zm()}catch{}}function ha(e,t,n){if(ie?.isActive)for(const s of n)oe("graphql_error",{operation:e,operationType:t,message:s.message,path:s.path,extensions:s.extensions})}const th=!0;function Lc(){return typeof crypto<"u"&&crypto.randomUUID?crypto.randomUUID():`${Date.now().toString(36)}-${Math.random().toString(36).slice(2,11)}`}function Kr(){return typeof crypto<"u"&&crypto.randomUUID?crypto.randomUUID().split("-")[0]:Math.random().toString(36).slice(2,10)}const pa="mm_trace_session";function nh(){if(typeof sessionStorage>"u")return Kr();let e=sessionStorage.getItem(pa);return e||(e=Lc(),sessionStorage.setItem(pa,e)),e}let cn=null;function Tn(){return cn={traceId:Lc(),spanId:Kr(),sessionId:nh()},cn}function sh(){return cn}function Uc(){const e=cn||Tn();return{"X-Trace-ID":e.traceId,"X-Span-ID":e.spanId,"X-Session-ID":e.sessionId,...e.parentSpanId?{"X-Parent-Span-ID":e.parentSpanId}:{}}}const Pe=[],rh=50,ih=5e3;let _s=null;function cs(e,t,n){const s=cn||Tn(),i={id:Kr(),traceId:s.traceId,parentSpanId:s.parentSpanId,operationName:e,operationType:t,startedAt:Date.now(),status:"in_progress",attributes:n};return Pe.push(i),oh(),i.id}function ls(e,t){const n=Pe.find(s=>s.id===e);n&&(n.endedAt=Date.now(),n.durationMs=n.endedAt-n.startedAt,n.status=t?"error":"success",t&&(n.errorMessage=t.message))}function ah(e,t){const n=Pe.find(s=>s.id===e);n&&(n.attributes={...n.attributes,...t})}function oh(){_s||(_s=setTimeout(()=>{fr(),_s=null},ih),Pe.length>=rh&&fr())}async function fr(){if(Pe.length===0)return;const e=Pe.filter(s=>s.status!=="in_progress");if(e.length===0)return;const t=new Set(e.map(s=>s.id)),n=Pe.filter(s=>!t.has(s.id));Pe.length=0,Pe.push(...n);try{(await fetch("/api/trace/frontend-log",{method:"POST",headers:{"Content-Type":"application/json",...Uc()},body:JSON.stringify({spans:e})})).ok}catch{}}typeof window<"u"&&th&&window.addEventListener("beforeunload",()=>{const e=Pe.filter(t=>t.status!=="in_progress");e.length>0&&navigator.sendBeacon&&navigator.sendBeacon("/api/trace/frontend-log",JSON.stringify({spans:e}))});function ch(e,t){Tn();const n=cs(`navigation:${e}`,"navigation",{path:e,...t});ls(n)}function lh(e,t,n){return cs(`interaction:${e}:${t}`,"interaction",{action:e,target:t,...n})}const he={workouts:200,exercises:500,goals:100,messages:500,notifications:200,feed:100};function ye(e,t){return e.length<=t?e:e.slice(-t)}const fa=3e4,uh=6e4;function dh(){const e=navigator.connection;if(!e?.effectiveType)return fa;switch(e.effectiveType){case"slow-2g":case"2g":case"3g":return uh;default:return fa}}function mh(e,t){const n=new AbortController,s=dh(),i=setTimeout(()=>n.abort(),s);return fetch(e,{...t,signal:n.signal}).finally(()=>clearTimeout(i))}const hh=new Ad({uri:"/api/graphql",credentials:"include",fetch:mh}),ph=Sc((e,{headers:t})=>{try{const n=de.getItem("musclemap-auth");if(n){const i=JSON.parse(n)?.state?.token;if(i)return{headers:{...t,authorization:`Bearer ${i}`}}}}catch{}return{headers:t}}),fh=Sc((e,{headers:t})=>{Tn();const n=e.operationName||"anonymous",s=e.query.definitions[0]?.operation||"query",i=cs(`graphql:${s}:${n}`,"graphql",{operationName:n,operationType:s});return{headers:{...t,...Uc()},spanId:i}}),gh=new Md((e,t)=>t(e).map(n=>{const s=e.getContext();return s?.spanId&&!n.errors?.length&&ls(s.spanId),n})),yh=new _d({delay:{initial:300,max:5e3,jitter:!0},attempts:{max:3,retryIf:(e,t)=>!!e&&!e.result}}),vh=Cd(({graphQLErrors:e,networkError:t,operation:n,response:s})=>{const i=n.getContext();if(i?.spanId){const a=t||(e?.[0]?new Error(e[0].message):void 0);ls(i.spanId,a)}if(pr()&&e&&e.length>0&&ha(n.operationName||"unknown",n.query.definitions[0]?.kind==="OperationDefinition"?n.query.definitions[0].operation:"unknown",e.map(a=>({message:a.message,path:a.path,extensions:a.extensions}))),pr()&&t&&ha(n.operationName||"unknown","network",[{message:t.message}]),e)for(const a of e){const{extensions:o}=a;if(o?.code==="UNAUTHENTICATED"){const l=n.operationName?.toLowerCase()||"",u=l==="login"||l==="register",d=typeof window<"u"&&(window.location.pathname==="/login"||window.location.pathname==="/signup");!u&&!d&&(de.removeItem("musclemap-auth"),window.location.href="/login")}}}),bn=new kd({typePolicies:{Query:{fields:{myWorkouts:{keyArgs:["filter","sortBy"],merge(e=[],t,{args:n}){if(!n?.cursor)return ye(t,he.workouts);const s=[...e,...t];return ye(s,he.workouts)}},exercises:{keyArgs:["filter","muscleGroup","category"],merge(e=[],t,{args:n}){if(!n?.cursor)return ye(t,he.exercises);const s=[...e,...t];return ye(s,he.exercises)}},leaderboard:{keyArgs:["type","timeframe"]},stats:{keyArgs:["userId","period"]},communityStats:{keyArgs:!1,read(e,{canRead:t,toReference:n}){return e}},me:{keyArgs:!1},user:{keyArgs:["id"]},goals:{keyArgs:["userId","status"],merge(e=[],t,{args:n}){if(!n?.cursor)return ye(t,he.goals);const s=[...e,...t];return ye(s,he.goals)}},messages:{keyArgs:["conversationId"],merge(e,t,{args:n}){if(!e||!n?.before&&!n?.after)return t?.messages?{...t,messages:ye(t.messages,he.messages)}:t;if(!t?.messages)return e;const s=new Set(e.messages?.map(o=>o.id)||[]),i=t.messages.filter(o=>!s.has(o.id));if(n?.before){const o=[...i,...e.messages||[]];return{...t,messages:ye(o,he.messages)}}const a=[...e.messages||[],...i];return{...e,messages:ye(a,he.messages)}}},notifications:{keyArgs:["unreadOnly"],merge(e=[],t,{args:n}){if(n?.offset===0||!n?.offset)return ye(t,he.notifications);const s=[...e,...t];return ye(s,he.notifications)}},activityFeed:{keyArgs:["type"],merge(e=[],t,{args:n}){if(n?.offset===0||!n?.offset)return ye(t,he.feed);const s=[...e,...t];return ye(s,he.feed)}}}},User:{keyFields:["id"],fields:{workouts:{merge:!1}}},Workout:{keyFields:["id"],fields:{exercises:{merge:!1}}},Exercise:{keyFields:["id"]},Goal:{keyFields:["id"]},CharacterStats:{keyFields:["userId"]},Achievement:{keyFields:["id"]},Notification:{keyFields:["id"]},Message:{keyFields:["id"]},Conversation:{keyFields:["id"],fields:{messages:{merge:!1}}},Issue:{keyFields:["id"]},Comment:{keyFields:["id"]}}}),Qr=new Rd({link:Pd([yh,fh,vh,gh,ph,hh]),cache:bn,defaultOptions:{watchQuery:{fetchPolicy:"cache-and-network",nextFetchPolicy:"cache-first",errorPolicy:"all",notifyOnNetworkStatusChange:!0,returnPartialData:!0},query:{fetchPolicy:"cache-first",errorPolicy:"all",returnPartialData:!0},mutate:{errorPolicy:"all"}},connectToDevTools:!1});let ga=!1;async function Sh(){if(!ga)try{await zm(bn),ga=!0}catch{}}async function Vc(){try{await Qr.clearStore(),await kc()}catch{}}function Ye(){try{return{collected:bn.gc().length}}catch{return{collected:0}}}function us(){try{const e=bn.extract(),t=Object.keys(e),n=e.ROOT_QUERY?Object.keys(e.ROOT_QUERY):[],s=JSON.stringify(e),i=Math.round(s.length/1024);return{rootQueryCount:n.length,totalEntries:t.length,estimatedSizeKB:i}}catch{return{rootQueryCount:0,totalEntries:0,estimatedSizeKB:0}}}function Th(e){try{return bn.evict({id:"ROOT_QUERY",fieldName:e})}catch{return!1}}async function bh(){try{await Qr.resetStore(),await kc(),Ye()}catch{}}const Bc=p`
  fragment UserCoreFields on User {
    id
    username
    displayName
    avatar
  }
`,wh=p`
  fragment UserExtendedFields on User {
    id
    email
    username
    displayName
    avatar
    level
    xp
    roles
    createdAt
  }
`;p`
  fragment UserProfileFields on User {
    id
    email
    username
    displayName
    avatar
    bio
    level
    xp
    totalTu
    wealthTier
    creditBalance
    roles
    verified
    createdAt
    updatedAt
  }
`;p`
  fragment ExerciseCoreFields on Exercise {
    id
    name
    type
    primaryMuscles
    equipment
    difficulty
    imageUrl
  }
`;const Fc=p`
  fragment ExerciseFullFields on Exercise {
    id
    name
    description
    type
    primaryMuscles
    secondaryMuscles
    equipment
    difficulty
    instructions
    tips
    imageUrl
    videoUrl
  }
`;p`
  fragment WorkoutCoreFields on Workout {
    id
    date
    totalTu
    exerciseCount
    notes
    createdAt
  }
`;const Ih=p`
  fragment WorkoutSetFields on WorkoutSet {
    id
    exerciseId
    setNumber
    reps
    weight
    rpe
    tu
    notes
    createdAt
  }
`;p`
  fragment WorkoutFullFields on Workout {
    id
    date
    totalTu
    notes
    exerciseCount
    duration
    createdAt
    sets {
      ...WorkoutSetFields
    }
  }
  ${Ih}
`;const xh=p`
  fragment MuscleFields on Muscle {
    id
    name
    group
    subGroup
    description
  }
`;p`
  fragment MuscleActivationFields on MuscleActivation {
    muscleId
    intensity
    lastWorked
    totalVolume
  }
`;p`
  fragment StatsPeriodFields on StatsPeriod {
    workouts
    tu
    avgTuPerWorkout
  }
`;p`
  fragment CharacterStatsFields on CharacterStats {
    strength
    endurance
    flexibility
    power
    speed
    balance
  }
`;p`
  fragment BalanceFields on Balance {
    credits
    pending
    lifetime
  }
`;p`
  fragment TransactionFields on Transaction {
    id
    type
    amount
    description
    balanceAfter
    createdAt
  }
`;p`
  fragment WalletInfoFields on WalletInfo {
    balance
    lifetimeEarned
    lifetimeSpent
    wealthTier
    wealthTierName
    wealthTierColor
    creditsToNextTier
    wealthTierProgress
  }
`;const Eh=p`
  fragment AchievementFields on Achievement {
    id
    key
    name
    description
    category
    tier
    iconUrl
    xpReward
    creditReward
    requiresVerification
    createdAt
  }
`;p`
  fragment UserAchievementFields on UserAchievement {
    id
    achievementId
    status
    progress
    progressMax
    unlockedAt
    verifiedAt
    achievement {
      ...AchievementFields
    }
  }
  ${Eh}
`;p`
  fragment FeedItemFields on FeedItem {
    id
    type
    payload
    visibilityScope
    geoBucket
    createdAt
    user {
      ...UserCoreFields
    }
  }
  ${Bc}
`;p`
  fragment ConversationFields on Conversation {
    id
    type
    name
    avatarUrl
    lastMessageAt
    unreadCount
    muted
    pinned
  }
`;p`
  fragment MessageFields on Message {
    id
    conversationId
    senderId
    content
    type
    replyToId
    editedAt
    deletedAt
    createdAt
    sender {
      ...UserCoreFields
    }
  }
  ${Bc}
`;const Ah=p`
  fragment GoalFields on Goal {
    id
    type
    title
    description
    target
    current
    unit
    deadline
    status
    isPrimary
    createdAt
    updatedAt
  }
`,_h=p`
  fragment ArchetypeFields on Archetype {
    id
    name
    description
    icon
    color
    category
    traits
    strengths
    focusAreas
  }
`,Ch=p`
  fragment JourneyFields on Journey {
    userId
    archetype {
      ...ArchetypeFields
    }
    currentLevel
    currentXP
    xpToNextLevel
    totalXP
    completedMilestones
    unlockedAbilities
  }
  ${_h}
`;p`
  fragment PageInfoFields on PageInfo {
    hasNextPage
    hasPreviousPage
    startCursor
    endCursor
  }
`;const kh=p`
  fragment WitnessInfoFields on WitnessInfo {
    id
    witnessUserId
    witnessUsername
    witnessDisplayName
    witnessAvatarUrl
    attestationText
    relationship
    locationDescription
    status
    isPublic
    requestedAt
    respondedAt
  }
`;p`
  fragment VerificationFields on AchievementVerification {
    id
    userId
    achievementId
    achievementKey
    achievementName
    achievementTier
    videoUrl
    thumbnailUrl
    videoDurationSeconds
    status
    notes
    rejectionReason
    submittedAt
    verifiedAt
    expiresAt
    createdAt
    updatedAt
    username
    displayName
    avatarUrl
    witness {
      ...WitnessInfoFields
    }
  }
  ${kh}
`;const Rh=p`
  fragment LeaderboardEntryFields on LeaderboardEntry {
    rank
    userId
    username
    displayName
    avatar
    value
    trend
  }
`;p`
  fragment CompetitionFields on Competition {
    id
    name
    description
    type
    metric
    startDate
    endDate
    status
    entryFee
    prizePool
    maxParticipants
    participantCount
    createdBy
    createdAt
  }
`;const Ph=p`
  fragment TrainerProfileFields on TrainerProfile {
    userId
    displayName
    bio
    specialties
    certifications
    hourlyRateCredits
    perClassRateCredits
    verified
    verifiedAt
    ratingAvg
    ratingCount
    totalClassesTaught
    totalStudentsTrained
    totalCreditsEarned
    status
    createdAt
  }
`;p`
  fragment TrainerClassFields on TrainerClass {
    id
    trainerUserId
    title
    description
    category
    difficulty
    startAt
    durationMinutes
    locationType
    locationDetails
    capacity
    enrolledCount
    creditsPerStudent
    trainerWagePerStudent
    status
    createdAt
  }
`;p`
  query Me {
    me {
      ...UserExtendedFields
    }
  }
  ${wh}
`;p`
  query MyCapabilities {
    myCapabilities {
      canCreateWorkout
      canJoinHangouts
      canMessage
      canVote
      isAdmin
      isPremium
      dailyWorkoutLimit
      remainingWorkouts
    }
  }
`;const mE=p`
  query Exercises($search: String, $muscleGroup: String, $equipment: String, $limit: Int) {
    exercises(search: $search, muscleGroup: $muscleGroup, equipment: $equipment, limit: $limit) {
      ...ExerciseFullFields
    }
  }
  ${Fc}
`;p`
  query Exercise($id: ID!) {
    exercise(id: $id) {
      ...ExerciseFullFields
    }
  }
  ${Fc}
`;p`
  query Muscles {
    muscles {
      ...MuscleFields
    }
  }
  ${xh}
`;const hE=p`
  query MyMuscleActivations {
    myMuscleActivations {
      muscleId
      activation
    }
  }
`,pE=p`
  query ExerciseHistory($exerciseIds: [ID!]!) {
    exerciseHistory(exerciseIds: $exerciseIds) {
      exerciseId
      exerciseName
      bestWeight
      best1RM
      bestVolume
      lastPerformedAt
      totalSessions
    }
  }
`;p`
  query MyWorkouts($limit: Int, $offset: Int) {
    myWorkouts(limit: $limit, offset: $offset) {
      id
      userId
      exercises {
        exerciseId
        name
        sets
        reps
        weight
        notes
      }
      duration
      notes
      totalTU
      createdAt
    }
  }
`;p`
  query MyWorkoutStats {
    myWorkoutStats {
      totalWorkouts
      totalExercises
      totalSets
      totalReps
      totalWeight
      averageWorkoutDuration
      currentStreak
      longestStreak
      thisWeek
      thisMonth
    }
  }
`;p`
  query Workout($id: ID!) {
    workout(id: $id) {
      id
      userId
      exercises {
        exerciseId
        name
        sets
        reps
        weight
        notes
      }
      duration
      notes
      totalTU
      createdAt
    }
  }
`;const fE=p`
  query Goals($status: String) {
    goals(status: $status) {
      ...GoalFields
      userId
    }
  }
  ${Ah}
`,gE=p`
  query GoalSuggestions {
    goalSuggestions {
      type
      title
      description
      target
      unit
      reason
    }
  }
`,yE=p`
  query Journey {
    journey {
      ...JourneyFields
    }
  }
  ${Ch}
`,vE=p`
  query JourneyOverview {
    journeyOverview {
      currentArchetype
      totalTU
      currentLevel
      currentLevelName
      daysSinceJoined
      totalWorkouts
      streak
      nextLevelTU
      stats {
        weekly {
          workouts
          tu
          avgTuPerWorkout
        }
        monthly {
          workouts
          tu
          avgTuPerWorkout
        }
        allTime {
          workouts
          tu
          avgTuPerWorkout
        }
      }
      workoutHistory {
        date
        tu
        count
      }
      topExercises {
        id
        name
        count
      }
      levels {
        level
        name
        totalTu
        achieved
      }
      muscleGroups {
        name
        total
      }
      muscleBreakdown {
        id
        name
        group
        totalActivation
      }
      recentWorkouts {
        id
        date
        tu
        createdAt
      }
      paths {
        archetype
        name
        philosophy
        focusAreas
        isCurrent
        percentComplete
      }
    }
  }
`,SE=p`
  query Archetypes {
    archetypes {
      id
      name
      description
      philosophy
      icon
      color
      categoryId
      primaryStats
      bonuses
    }
  }
`,TE=p`
  query ArchetypeCategories {
    archetypeCategories {
      id
      name
      description
      icon
      displayOrder
      archetypes {
        id
        name
        description
        philosophy
        icon
        color
        categoryId
        primaryStats
        bonuses
      }
    }
  }
`,bE=p`
  query MyStats {
    myStats {
      userId
      level
      xp
      xpToNextLevel
      strength
      endurance
      agility
      flexibility
      balance
      mentalFocus
      totalWorkouts
      totalExercises
      currentStreak
      longestStreak
      lastWorkoutAt
    }
  }
`;p`
  query Leaderboards($type: String) {
    leaderboards(type: $type) {
      ...LeaderboardEntryFields
      level
      xp
      stat
    }
  }
  ${Rh}
`;const wE=p`
  query MyStatsWithRankings {
    myStatsWithRankings {
      stats {
        userId
        level
        xp
        xpToNextLevel
        strength
        endurance
        agility
        flexibility
        balance
        mentalFocus
        totalWorkouts
        totalExercises
        currentStreak
        longestStreak
        lastWorkoutAt
      }
      rankings
    }
  }
`,IE=p`
  query ExtendedProfile {
    extendedProfile {
      height
      weight
      age
      gender
      fitnessLevel
      goals
      preferredUnits
      city
      county
      state
      country
      countryCode
      leaderboardOptIn
      profileVisibility
      weeklyActivity
      volumeTrend {
        label
        value
      }
      previousStrength
    }
  }
`,xE=p`
  query StatLeaderboard($stat: String, $scope: String, $scopeValue: String, $limit: Int, $afterRank: Int) {
    statLeaderboard(stat: $stat, scope: $scope, scopeValue: $scopeValue, limit: $limit, afterRank: $afterRank) {
      entries {
        userId
        username
        avatarUrl
        statValue
        rank
        gender
        country
        state
        city
      }
      total
      nextCursor
    }
  }
`,EE=p`
  query BodyMeasurements($limit: Int, $cursor: String) {
    bodyMeasurements(limit: $limit, cursor: $cursor) {
      measurements {
        id
        userId
        weightKg
        bodyFatPercentage
        leanMassKg
        neckCm
        shouldersCm
        chestCm
        waistCm
        hipsCm
        leftBicepCm
        rightBicepCm
        leftForearmCm
        rightForearmCm
        leftThighCm
        rightThighCm
        leftCalfCm
        rightCalfCm
        measurementSource
        notes
        measurementDate
        createdAt
      }
      pagination {
        hasMore
        nextCursor
        count
      }
    }
  }
`,AE=p`
  query LatestBodyMeasurement {
    latestBodyMeasurement {
      id
      userId
      weightKg
      bodyFatPercentage
      leanMassKg
      neckCm
      shouldersCm
      chestCm
      waistCm
      hipsCm
      leftBicepCm
      rightBicepCm
      leftForearmCm
      rightForearmCm
      leftThighCm
      rightThighCm
      leftCalfCm
      rightCalfCm
      measurementSource
      notes
      measurementDate
      createdAt
    }
  }
`,_E=p`
  query BodyMeasurementComparison($days: Int) {
    bodyMeasurementComparison(days: $days) {
      weightKg { current past change changePercent }
      bodyFatPercentage { current past change changePercent }
      leanMassKg { current past change changePercent }
      neckCm { current past change changePercent }
      shouldersCm { current past change changePercent }
      chestCm { current past change changePercent }
      waistCm { current past change changePercent }
      hipsCm { current past change changePercent }
      leftBicepCm { current past change changePercent }
      rightBicepCm { current past change changePercent }
      leftForearmCm { current past change changePercent }
      rightForearmCm { current past change changePercent }
      leftThighCm { current past change changePercent }
      rightThighCm { current past change changePercent }
      leftCalfCm { current past change changePercent }
      rightCalfCm { current past change changePercent }
      currentDate
      pastDate
      daysBetween
    }
  }
`,CE=p`
  query PublicCommunityStats {
    publicCommunityStats {
      activeNow {
        value
        display
      }
      activeWorkouts {
        value
        display
      }
      totalUsers {
        value
        display
      }
      totalWorkouts {
        value
        display
      }
      recentActivity {
        id
        type
        message
        timestamp
      }
      milestone {
        type
        value
        reached
      }
    }
  }
`,kE=p`
  query CommunityStats {
    communityStats {
      activeUsers
      activeWorkouts
      totalWorkoutsToday
      totalWorkoutsWeek
      topArchetype
    }
  }
`,RE=p`
  query CreditsBalance {
    creditsBalance {
      credits
      pending
      lifetime
    }
  }
`;p`
  query EconomyBalance {
    economyBalance {
      credits
      pending
      lifetime
    }
  }
`;const PE=p`
  query Tips($context: String, $exerciseId: ID) {
    tips(context: $context, exerciseId: $exerciseId) {
      id
      type
      title
      content
      category
      exerciseId
      priority
      seen
    }
  }
`;p`
  query Health {
    health {
      status
      timestamp
    }
  }
`;p`
  query HealthDetailed {
    healthDetailed {
      status
      version
      uptime
      database {
        connected
        latency
      }
      redis {
        connected
        latency
      }
      memory {
        used
        total
        percentage
      }
    }
  }
`;const ME=p`
  query ActiveWorkoutSession {
    activeWorkoutSession {
      id
      userId
      startedAt
      pausedAt
      totalPausedTime
      lastActivityAt
      currentExerciseIndex
      currentSetIndex
      restTimerRemaining
      restTimerTotalDuration
      restTimerStartedAt
      sets {
        id
        exerciseId
        exerciseName
        setNumber
        reps
        weightKg
        rpe
        tu
        isPRWeight
        isPRReps
        isPR1RM
        performedAt
      }
      totalVolume
      totalReps
      estimatedCalories
    }
  }
`;p`
  query WorkoutSession($id: ID!) {
    workoutSession(id: $id) {
      id
      userId
      startedAt
      pausedAt
      totalPausedTime
      lastActivityAt
      currentExerciseIndex
      currentSetIndex
      sets {
        id
        exerciseId
        exerciseName
        setNumber
        reps
        weightKg
        rpe
        tu
        isPRWeight
        isPRReps
        isPR1RM
        performedAt
      }
      totalVolume
      totalReps
      estimatedCalories
    }
  }
`;const OE=p`
  query RecoverableSessions($limit: Int) {
    recoverableSessions(limit: $limit) {
      id
      startedAt
      archivedAt
      archiveReason
      setsLogged
      totalVolume
      musclesWorked
      canRecover
    }
  }
`;p`
  query WorkoutMuscleBreakdown($workoutId: ID!) {
    workoutMuscleBreakdown(workoutId: $workoutId) {
      muscleId
      muscleName
      totalTU
      setCount
      exercises {
        exerciseId
        exerciseName
        tu
        setCount
      }
    }
  }
`;const NE=p`
  query ExerciseSubstitutions($exerciseId: ID!, $equipment: [String!], $maxResults: Int) {
    exerciseSubstitutions(exerciseId: $exerciseId, equipment: $equipment, maxResults: $maxResults) {
      exercise {
        id
        name
        description
        primaryMuscles
        secondaryMuscles
        equipment
        difficulty
        imageUrl
      }
      similarityScore
      matchedMuscles
      missingMuscles
    }
  }
`;p`
  query Profile {
    profile {
      id
      userId
      displayName
      bio
      avatar
      location
      website
      socialLinks
      fitnessGoals
      preferredWorkoutTime
      experienceLevel
      visibility
      wealthTier {
        tier
        name
        color
        icon
      }
      createdAt
      updatedAt
    }
  }
`;const $E=p`
  query Conversations($tab: String) {
    conversations(tab: $tab) {
      id
      type
      name
      participants {
        userId
        username
        displayName
        avatarUrl
        lastActiveAt
      }
      lastMessage {
        id
        content
        createdAt
        senderId
      }
      lastMessageAt
      unreadCount
      starred
      archivedAt
      createdAt
      updatedAt
    }
  }
`,DE=p`
  query ConversationMessages($conversationId: ID!, $limit: Int, $before: ID) {
    conversationMessages(conversationId: $conversationId, limit: $limit, before: $before) {
      id
      conversationId
      senderId
      senderUsername
      senderDisplayName
      content
      contentType
      replyTo {
        id
        content
        senderName
      }
      reactions {
        emoji
        count
        users
        userReacted
      }
      pinnedAt
      editedAt
      editCount
      deliveredAt
      readAt
      createdAt
    }
  }
`,jE=p`
  query PinnedMessages($conversationId: ID!) {
    pinnedMessages(conversationId: $conversationId) {
      id
      content
      senderName
      createdAt
    }
  }
`,LE=p`
  query TypingUsers($conversationId: ID!) {
    typingUsers(conversationId: $conversationId) {
      userId
      username
      avatarUrl
    }
  }
`,UE=p`
  query UserPresence($userIds: [ID!]!) {
    userPresence(userIds: $userIds) {
      userId
      status
      lastSeen
    }
  }
`,VE=p`
  query BlockStatus($userId: ID!) {
    blockStatus(userId: $userId) {
      isBlocked
      blockedBy
    }
  }
`,BE=p`
  query MessageTemplates {
    messageTemplates {
      id
      name
      content
      shortcut
      category
      useCount
    }
  }
`,FE=p`
  query ScheduledMessages {
    scheduledMessages {
      id
      conversationId
      content
      scheduledFor
      status
    }
  }
`,qE=p`
  query SearchMessages($query: String!, $conversationId: ID, $limit: Int, $offset: Int) {
    searchMessages(query: $query, conversationId: $conversationId, limit: $limit, offset: $offset) {
      messages {
        id
        content
        senderName
        conversationId
        createdAt
        highlight
      }
      total
    }
  }
`,WE=p`
  query SearchUsers($query: String!, $limit: Int) {
    searchUsers(query: $query, limit: $limit) {
      id
      username
      displayName
      avatarUrl
      canMessage
    }
  }
`,zE=p`
  query Issues($status: Int, $type: Int, $labelSlug: String, $search: String, $sortBy: String, $limit: Int, $offset: Int) {
    issues(status: $status, type: $type, labelSlug: $labelSlug, search: $search, sortBy: $sortBy, limit: $limit, offset: $offset) {
      issues {
        id
        issueNumber
        title
        description
        type
        status
        priority
        labels {
          id
          name
          slug
          color
          icon
        }
        authorUsername
        authorAvatarUrl
        voteCount
        hasVoted
        commentCount
        isPinned
        isLocked
        createdAt
        updatedAt
      }
      total
      hasMore
    }
  }
`;p`
  query Issue($id: ID!) {
    issue(id: $id) {
      id
      title
      description
      status
      priority
      labels
      author {
        id
        username
        avatar
      }
      comments {
        id
        content
        author {
          id
          username
          avatar
        }
        isSolution
        createdAt
      }
      voteCount
      hasVoted
      commentCount
      createdAt
      updatedAt
    }
  }
`;const HE=p`
  query IssueLabels {
    issueLabels {
      id
      name
      slug
      color
      icon
      description
    }
  }
`,GE=p`
  query IssueStats {
    issueStats {
      totalIssues
      openIssues
      resolvedIssues
      totalVotes
      issuesByType
      issuesByStatus
    }
  }
`;p`
  query MyIssues {
    myIssues {
      id
      title
      status
      priority
      voteCount
      commentCount
      createdAt
    }
  }
`;const YE=p`
  query Roadmap {
    roadmap {
      id
      title
      description
      status
      category
      quarter
      priority
      progress
      voteCount
      hasVoted
      relatedIssueIds
      completedAt
    }
  }
`;p`
  query Updates($limit: Int) {
    updates(limit: $limit) {
      id
      title
      content
      type
      createdAt
    }
  }
`;p`
  query Achievements {
    achievements {
      id
      name
      description
      icon
      rarity
      category
      requirement
      progress
      unlockedAt
    }
  }
`;const KE=p`
  query AchievementDefinitions($category: String) {
    achievementDefinitions(category: $category) {
      id
      key
      name
      description
      icon
      category
      points
      rarity
      tier
      creditsReward
      xpReward
      requiresVerification
      unlockHint
    }
  }
`,QE=p`
  query MyAchievements($category: String, $limit: Int, $offset: Int) {
    myAchievements(category: $category, limit: $limit, offset: $offset) {
      achievements {
        id
        achievementKey
        achievementName
        achievementDescription
        achievementIcon
        category
        points
        rarity
        creditsEarned
        xpEarned
        isVerified
        witnessUsername
        earnedAt
      }
      total
    }
  }
`;p`
  query MyAchievementSummary {
    myAchievementSummary {
      totalPoints
      totalAchievements
      totalCredits
      totalXp
      byCategory
      byRarity
      recentAchievements {
        id
        achievementKey
        achievementName
        achievementDescription
        achievementIcon
        category
        points
        rarity
        creditsEarned
        xpEarned
        earnedAt
      }
    }
  }
`;const JE=p`
  query MyVerifications($status: String, $limit: Int, $offset: Int) {
    myVerifications(status: $status, limit: $limit, offset: $offset) {
      verifications {
        id
        userId
        achievementId
        achievementKey
        achievementName
        achievementTier
        videoUrl
        thumbnailUrl
        videoDurationSeconds
        status
        notes
        rejectionReason
        submittedAt
        verifiedAt
        expiresAt
        createdAt
        updatedAt
        username
        displayName
        avatarUrl
        witness {
          id
          witnessUserId
          witnessUsername
          witnessDisplayName
          witnessAvatarUrl
          attestationText
          relationship
          locationDescription
          status
          isPublic
          requestedAt
          respondedAt
        }
      }
      total
    }
  }
`,XE=p`
  query MyWitnessRequests($status: String, $limit: Int, $offset: Int) {
    myWitnessRequests(status: $status, limit: $limit, offset: $offset) {
      verifications {
        id
        userId
        achievementId
        achievementKey
        achievementName
        achievementTier
        videoUrl
        thumbnailUrl
        status
        notes
        submittedAt
        expiresAt
        username
        displayName
        avatarUrl
        witness {
          id
          witnessUserId
          witnessUsername
          status
          requestedAt
        }
      }
      total
    }
  }
`,ZE=p`
  query SkillTrees {
    skillTrees {
      id
      name
      description
      icon
      color
      nodeCount
    }
  }
`,eA=p`
  query SkillTree($treeId: ID!) {
    skillTree(treeId: $treeId) {
      id
      name
      description
      icon
      color
      nodeCount
      nodes {
        id
        treeId
        name
        description
        tier
        position
        difficulty
        criteriaType
        criteriaValue
        criteriaDescription
        xpReward
        creditReward
        tips
      }
    }
  }
`,tA=p`
  query SkillTreeProgress($treeId: ID!) {
    skillTreeProgress(treeId: $treeId) {
      id
      treeId
      name
      description
      tier
      position
      difficulty
      criteriaType
      criteriaValue
      criteriaDescription
      xpReward
      creditReward
      tips
      progress {
        status
        practiceMinutes
        practiceCount
        bestValue
        achievedAt
      }
    }
  }
`,nA=p`
  query SkillSummary {
    skillSummary {
      totalSkills
      achievedSkills
      inProgressSkills
      availableSkills
      lockedSkills
      totalPracticeMinutes
    }
  }
`;p`
  query SkillProgress {
    skillSummary {
      totalSkills
      achievedSkills
      inProgressSkills
      availableSkills
      lockedSkills
      totalPracticeMinutes
    }
  }
`;const sA=p`
  query MartialArtsProgress {
    martialArtsProgress {
      totalTechniques
      masteredTechniques
      learningTechniques
      availableTechniques
      totalPracticeMinutes
      disciplineProgress {
        disciplineId
        disciplineName
        mastered
        total
      }
    }
  }
`,rA=p`
  query MartialArtsDisciplines($militaryOnly: Boolean) {
    martialArtsDisciplines(militaryOnly: $militaryOnly) {
      id
      name
      description
      originCountry
      focusAreas
      icon
      color
      orderIndex
      isMilitary
    }
  }
`,iA=p`
  query MartialArtsDiscipline($id: ID!) {
    martialArtsDiscipline(id: $id) {
      id
      name
      description
      originCountry
      focusAreas
      icon
      color
      orderIndex
      isMilitary
      categories {
        id
        disciplineId
        name
        description
        orderIndex
      }
    }
  }
`,aA=p`
  query MartialArtsTechniques($disciplineId: ID!) {
    martialArtsTechniques(disciplineId: $disciplineId) {
      id
      disciplineId
      categoryId
      name
      description
      category
      difficulty
      prerequisites
      keyPoints
      commonMistakes
      drillSuggestions
      videoUrl
      thumbnailUrl
      muscleGroups
      xpReward
      creditReward
      tier
      position
    }
  }
`,oA=p`
  query MartialArtsDisciplineProgress($disciplineId: ID!) {
    martialArtsDisciplineProgress(disciplineId: $disciplineId) {
      id
      disciplineId
      categoryId
      name
      description
      category
      difficulty
      prerequisites
      keyPoints
      commonMistakes
      drillSuggestions
      videoUrl
      thumbnailUrl
      muscleGroups
      xpReward
      creditReward
      tier
      position
      progress {
        id
        userId
        techniqueId
        status
        proficiency
        practiceCount
        totalPracticeMinutes
        lastPracticed
        masteredAt
        notes
        createdAt
        updatedAt
      }
    }
  }
`;p`
  query MartialArtsDisciplineLeaderboard($disciplineId: ID!, $limit: Int) {
    martialArtsDisciplineLeaderboard(disciplineId: $disciplineId, limit: $limit) {
      userId
      username
      masteredCount
      totalPracticeMinutes
    }
  }
`;p`
  query MartialArtsPracticeHistory($limit: Int, $offset: Int, $disciplineId: ID) {
    martialArtsPracticeHistory(limit: $limit, offset: $offset, disciplineId: $disciplineId) {
      logs {
        id
        userId
        techniqueId
        techniqueName
        disciplineName
        practiceDate
        durationMinutes
        repsPerformed
        roundsPerformed
        partnerDrill
        notes
        createdAt
      }
      total
    }
  }
`;const cA=p`
  query EconomyWallet {
    economyWallet {
      balance {
        credits
        pending
        lifetime
      }
      transactions {
        id
        type
        amount
        description
        createdAt
      }
    }
  }
`,lA=p`
  query EconomyPricing {
    economyPricing {
      id
      name
      credits
      price
      bonus
      popular
    }
  }
`;p`
  query EconomyHistory($limit: Int) {
    economyHistory(limit: $limit) {
      id
      type
      amount
      description
      createdAt
    }
  }
`;const uA=p`
  query MyPersonalRecords($limit: Int, $recordType: String) {
    myPersonalRecords(limit: $limit, recordType: $recordType) {
      id
      userId
      exerciseId
      exerciseName
      recordType
      value
      unit
      reps
      bodyweight
      workoutId
      setNumber
      achievedAt
      previousValue
      details {
        weight
        reps
        estimated1RM
      }
    }
  }
`,dA=p`
  query MyEntitlements {
    myEntitlements {
      unlimited
      reason
      trialEndsAt
      subscriptionEndsAt
      creditBalance
      creditsVisible
      daysLeftInTrial
    }
  }
`,mA=p`
  query MyWalletInfo {
    myWalletInfo {
      balance
      lifetimeEarned
      lifetimeSpent
      totalTransferredOut
      totalTransferredIn
      status
      vipTier
      transactions {
        id
        type
        amount
        action
        createdAt
      }
    }
  }
`,hA=p`
  query CommunityFeed($limit: Int, $offset: Int) {
    communityFeed(limit: $limit, offset: $offset) {
      id
      type
      user {
        id
        username
        avatar
        level
      }
      content
      workout {
        id
        totalTU
        duration
      }
      achievement {
        id
        name
        icon
      }
      reactions {
        type
        count
        hasReacted
      }
      comments {
        id
        content
        author {
          id
          username
          avatar
        }
        createdAt
      }
      createdAt
    }
  }
`,pA=p`
  query CommunityPresence {
    communityPresence {
      total
      byGeoBucket {
        geoBucket
        count
      }
      redisEnabled
    }
  }
`;p`
  query Prescription($id: ID!) {
    prescription(id: $id) {
      id
      userId
      exercises {
        exerciseId
        name
        sets
        reps
        weight
        restSeconds
        notes
      }
      targetMuscles
      difficulty
      estimatedDuration
      createdAt
    }
  }
`;const fA=p`
  query Competitions($status: String) {
    competitions(status: $status) {
      id
      name
      description
      type
      status
      startDate
      endDate
      prizePool
      participantCount
      maxParticipants
      goalTu
      hasJoined
      leaderboard {
        userId
        username
        displayName
        avatar
        score
        rank
        tuEarned
      }
      createdAt
    }
  }
`,gA=p`
  query MyCompetitionEntries {
    myCompetitionEntries {
      id
      competitionId
      competition {
        id
        name
        type
      }
      rank
      score
      joinedAt
    }
  }
`,yA=p`
  query Rivals($status: String) {
    rivals(status: $status) {
      rivals {
        id
        challengerId
        challengedId
        status
        createdAt
        startedAt
        endedAt
        challengerTU
        challengedTU
        opponent {
          id
          username
          avatar
          archetype
          level
        }
        isChallenger
        myTU
        opponentTU
        myLastWorkout
        opponentLastWorkout
        tuDifference
        isWinning
      }
      stats {
        activeRivals
        wins
        losses
        ties
        totalTUEarned
        currentStreak
        longestStreak
      }
    }
  }
`,vA=p`
  query PendingRivals {
    pendingRivals {
      id
      challengerId
      challengedId
      status
      createdAt
      opponent {
        id
        username
        avatar
        archetype
        level
      }
      isChallenger
      myTU
      opponentTU
    }
  }
`;p`
  query RivalStats {
    rivalStats {
      activeRivals
      wins
      losses
      ties
      totalTUEarned
      currentStreak
      longestStreak
    }
  }
`;const SA=p`
  query SearchPotentialRivals($query: String!, $limit: Int) {
    searchPotentialRivals(query: $query, limit: $limit) {
      id
      username
      avatar
      archetype
      level
    }
  }
`,TA=p`
  query MyCrew {
    myCrew {
      crew {
        id
        name
        tag
        description
        avatar
        color
        ownerId
        memberCount
        totalTU
        weeklyTU
        wins
        losses
        createdAt
      }
      membership {
        id
        crewId
        userId
        role
        joinedAt
        weeklyTU
        totalTU
        username
        avatar
        archetype
      }
      members {
        id
        crewId
        userId
        role
        joinedAt
        weeklyTU
        totalTU
        username
        avatar
        archetype
      }
      wars {
        id
        challengerCrewId
        defendingCrewId
        status
        startDate
        endDate
        challengerTU
        defendingTU
        winnerId
        createdAt
        challengerCrew {
          id
          name
          tag
          avatar
          color
        }
        defendingCrew {
          id
          name
          tag
          avatar
          color
        }
        isChallenger
        myCrewTU
        opponentCrewTU
        daysRemaining
        isWinning
      }
      stats {
        totalMembers
        totalTU
        weeklyTU
        warsWon
        warsLost
        currentStreak
        topContributors {
          userId
          username
          avatar
          weeklyTU
        }
      }
    }
  }
`;p`
  query Crew($id: ID!) {
    crew(id: $id) {
      crew {
        id
        name
        tag
        description
        avatar
        color
        ownerId
        memberCount
        totalTU
        weeklyTU
        wins
        losses
        createdAt
      }
      members {
        id
        crewId
        userId
        role
        joinedAt
        weeklyTU
        totalTU
        username
        avatar
        archetype
      }
      stats {
        totalMembers
        totalTU
        weeklyTU
        warsWon
        warsLost
        currentStreak
        topContributors {
          userId
          username
          avatar
          weeklyTU
        }
      }
    }
  }
`;const bA=p`
  query CrewLeaderboard($limit: Int) {
    crewLeaderboard(limit: $limit) {
      rank
      crew {
        id
        name
        tag
        avatar
        color
        memberCount
        weeklyTU
      }
    }
  }
`,wA=p`
  query SearchCrews($query: String!, $limit: Int) {
    searchCrews(query: $query, limit: $limit) {
      id
      name
      tag
      description
      avatar
      color
      ownerId
      memberCount
      totalTU
      weeklyTU
      wins
      losses
      createdAt
    }
  }
`,IA=p`
  query Trainers($verified: Boolean, $specialty: String, $status: String, $limit: Int, $offset: Int) {
    trainers(verified: $verified, specialty: $specialty, status: $status, limit: $limit, offset: $offset) {
      trainers {
        userId
        displayName
        bio
        specialties
        certifications
        hourlyRateCredits
        perClassRateCredits
        verified
        verifiedAt
        ratingAvg
        ratingCount
        totalClassesTaught
        totalStudentsTrained
        totalCreditsEarned
        status
        createdAt
      }
      total
    }
  }
`,xA=p`
  query MyTrainerProfile {
    myTrainerProfile {
      ...TrainerProfileFields
    }
  }
  ${Ph}
`;p`
  query TrainerClasses($input: TrainerClassesInput) {
    trainerClasses(input: $input) {
      classes {
        id
        trainerUserId
        title
        description
        category
        difficulty
        startAt
        durationMinutes
        locationType
        locationDetails
        capacity
        enrolledCount
        creditsPerStudent
        trainerWagePerStudent
        status
        createdAt
      }
      total
    }
  }
`;const EA=p`
  query UpcomingClasses($limit: Int) {
    trainerClasses(input: { upcoming: true, limit: $limit }) {
      classes {
        id
        trainerUserId
        title
        description
        category
        difficulty
        startAt
        durationMinutes
        locationType
        locationDetails
        capacity
        enrolledCount
        creditsPerStudent
        status
        createdAt
      }
      total
    }
  }
`,AA=p`
  query MyTrainerClasses($status: String, $limit: Int, $offset: Int) {
    myTrainerClasses(status: $status, limit: $limit, offset: $offset) {
      classes {
        id
        trainerUserId
        title
        description
        category
        difficulty
        startAt
        durationMinutes
        locationType
        locationDetails
        capacity
        enrolledCount
        creditsPerStudent
        trainerWagePerStudent
        status
        createdAt
      }
      total
    }
  }
`,_A=p`
  query MyClassEnrollments($status: String, $limit: Int, $offset: Int) {
    myClassEnrollments(status: $status, limit: $limit, offset: $offset) {
      enrollments {
        id
        classId
        userId
        status
        creditsPaid
        enrolledAt
        cancelledAt
        class {
          id
          trainerUserId
          title
          description
          category
          difficulty
          startAt
          durationMinutes
          locationType
          locationDetails
          capacity
          enrolledCount
          creditsPerStudent
          status
        }
      }
      total
    }
  }
`;p`
  query ClassEnrollments($classId: ID!) {
    classEnrollments(classId: $classId) {
      id
      classId
      userId
      status
      creditsPaid
      enrolledAt
      cancelledAt
    }
  }
`;p`
  query ClassAttendance($classId: ID!) {
    classAttendance(classId: $classId) {
      id
      classId
      userId
      attended
      markedBy
      rating
      feedback
      markedAt
    }
  }
`;p`
  query Notifications($unreadOnly: Boolean, $limit: Int) {
    notifications(unreadOnly: $unreadOnly, limit: $limit) {
      id
      type
      title
      message
      data
      readAt
      createdAt
    }
  }
`;p`
  query NotificationUnreadCount {
    notificationUnreadCount
  }
`;p`
  query Buddy {
    buddy {
      userId
      species
      nickname
      level
      xp
      xpToNextLevel
      stage
      stageName
      stageDescription
      equippedAura
      equippedArmor
      equippedWings
      equippedTool
      equippedSkin
      equippedEmotePack
      equippedVoicePack
      unlockedAbilities
      visible
      showOnProfile
      showInWorkouts
      totalXpEarned
      workoutsTogether
      streaksWitnessed
      prsCelebrated
      createdAt
      updatedAt
    }
  }
`;p`
  query BuddyInventory($category: String) {
    buddyInventory(category: $category) {
      id
      sku
      name
      category
      slot
      rarity
      equipped
      icon
      description
    }
  }
`;p`
  query BuddyEvolutionPath($species: String!) {
    buddyEvolutionPath(species: $species) {
      species
      stage
      minLevel
      stageName
      description
      unlockedFeatures
    }
  }
`;p`
  query BuddyLeaderboard($species: String, $limit: Int, $offset: Int) {
    buddyLeaderboard(species: $species, limit: $limit, offset: $offset) {
      entries {
        rank
        userId
        username
        species
        nickname
        level
        stage
        stageName
      }
      total
    }
  }
`;const CA=p`
  query CollectionStats {
    collectionStats {
      totalOwned
      totalValue
      rarityBreakdown {
        rarity
        count
      }
      categoryBreakdown {
        category
        count
      }
      completedSets
    }
  }
`,kA=p`
  query CollectionItems(
    $category: String
    $rarity: String
    $sortBy: String
    $limit: Int
    $offset: Int
  ) {
    collectionItems(
      category: $category
      rarity: $rarity
      sortBy: $sortBy
      limit: $limit
      offset: $offset
    ) {
      items {
        id
        cosmeticId
        name
        description
        category
        rarity
        icon
        previewUrl
        acquiredAt
        isFavorite
        isNew
        estimatedValue
        isTradeable
        isGiftable
      }
      total
      hasMore
    }
  }
`,RA=p`
  query CollectionFavorites {
    collectionFavorites {
      id
      cosmeticId
      name
      description
      category
      rarity
      icon
      previewUrl
      acquiredAt
      isFavorite
      isNew
      estimatedValue
    }
  }
`,PA=p`
  query CollectionSets {
    collectionSets {
      id
      name
      description
      icon
      theme
      isLimited
      expirationDate
      ownedCount
      totalCount
      rewards {
        threshold
        icon
        description
        claimed
      }
    }
  }
`;p`
  query CollectionSetDetail($setId: ID!) {
    collectionSetDetail(setId: $setId) {
      set {
        id
        name
        description
        icon
        theme
        isLimited
        expirationDate
      }
      progress {
        ownedCount
        totalCount
        completionPercent
        rewardsClaimed
      }
      items {
        id
        name
        icon
        rarity
        owned
      }
      claimableRewards {
        threshold
        icon
        description
      }
    }
  }
`;const MA=p`
  query CollectionShowcase($userId: ID) {
    collectionShowcase(userId: $userId) {
      id
      cosmeticId
      name
      rarity
      icon
      previewUrl
    }
  }
`,OA=p`
  query CollectionNewCount {
    collectionNewCount
  }
`,NA=p`
  query MarketplaceListings(
    $search: String
    $listingType: String
    $category: String
    $rarity: String
    $sortBy: String
    $minPrice: Int
    $maxPrice: Int
    $cursor: String
    $limit: Int
  ) {
    marketplaceListings(
      search: $search
      listingType: $listingType
      category: $category
      rarity: $rarity
      sortBy: $sortBy
      minPrice: $minPrice
      maxPrice: $maxPrice
      cursor: $cursor
      limit: $limit
    ) {
      listings {
        id
        sellerId
        listingType
        price
        currentBid
        bidCount
        expiresAt
        createdAt
        cosmeticName
        cosmeticIcon
        rarity
        category
        sellerUsername
        allowOffers
        minOffer
      }
      nextCursor
      hasMore
    }
  }
`,$A=p`
  query MarketplaceWatchlist {
    marketplaceWatchlist {
      id
      listingId
      price
      listingType
      expiresAt
      status
      cosmeticName
      cosmeticIcon
      rarity
      createdAt
    }
  }
`,DA=p`
  query MarketplaceStats {
    marketplaceStats {
      totalSales
      totalPurchases
      totalRevenue
      avgRating
      sellerLevel
      feeDiscount
    }
  }
`,jA=p`
  query TradesIncoming {
    tradesIncoming {
      id
      initiatorId
      initiatorUsername
      receiverId
      receiverUsername
      initiatorItems {
        id
        name
        rarity
        icon
        previewUrl
      }
      initiatorCredits
      receiverItems {
        id
        name
        rarity
        icon
        previewUrl
      }
      receiverCredits
      status
      message
      valueWarning
      expiresAt
      createdAt
    }
  }
`,LA=p`
  query TradesOutgoing {
    tradesOutgoing {
      id
      initiatorId
      initiatorUsername
      receiverId
      receiverUsername
      initiatorItems {
        id
        name
        rarity
        icon
        previewUrl
      }
      initiatorCredits
      receiverItems {
        id
        name
        rarity
        icon
        previewUrl
      }
      receiverCredits
      status
      message
      valueWarning
      expiresAt
      createdAt
    }
  }
`,UA=p`
  query TradesHistory($limit: Int) {
    tradesHistory(limit: $limit) {
      id
      user1Id
      user1Username
      user2Id
      user2Username
      status
      completedAt
    }
  }
`;p`
  query Trade($id: ID!) {
    trade(id: $id) {
      id
      initiatorId
      initiatorUsername
      receiverId
      receiverUsername
      initiatorItems {
        id
        name
        rarity
        icon
        previewUrl
      }
      initiatorCredits
      receiverItems {
        id
        name
        rarity
        icon
        previewUrl
      }
      receiverCredits
      status
      message
      valueWarning
      expiresAt
      createdAt
    }
  }
`;const VA=p`
  query MysteryBoxes {
    mysteryBoxes {
      id
      name
      description
      boxType
      price
      dropRates
      availableFrom
      availableUntil
      maxPurchasesPerDay
      createdAt
    }
  }
`;p`
  query MysteryBox($id: ID!) {
    mysteryBox(id: $id) {
      box {
        id
        name
        description
        boxType
        price
        dropRates
      }
      recentDrops {
        rarity
        openedAt
        name
        previewUrl
        username
      }
      dropStats {
        rarity
        count
      }
    }
  }
`;const BA=p`
  query MysteryBoxHistory($limit: Int) {
    mysteryBoxHistory(limit: $limit) {
      id
      boxId
      boxName
      cosmeticId
      cosmeticName
      rarity
      previewUrl
      creditsSpent
      wasPityReward
      openedAt
    }
  }
`,FA=p`
  query MysteryBoxPity {
    mysteryBoxPity {
      boxType
      epicCounter
      legendaryCounter
      epicThreshold
      legendaryThreshold
      lastEpicAt
      lastLegendaryAt
    }
  }
`,qA=p`
  query Skins {
    skins {
      id
      name
      description
      category
      rarity
      price
      unlockRequirement
      creditsRequired
      imageUrl
    }
  }
`,WA=p`
  query OwnedSkins {
    ownedSkins {
      id
      name
      description
      category
      rarity
      price
      imageUrl
    }
  }
`,zA=p`
  query EquippedSkins {
    equippedSkins {
      id
      name
      description
      category
      rarity
      price
      imageUrl
    }
  }
`,HA=p`
  query UnlockableSkins {
    unlockableSkins {
      id
      name
      description
      category
      rarity
      price
      unlockRequirement
      creditsRequired
      imageUrl
    }
  }
`;p`
  query AdminUsers($limit: Int, $offset: Int, $search: String) {
    adminUsers(limit: $limit, offset: $offset, search: $search) {
      id
      username
      email
      level
      roles
      creditBalance
      banned
      createdAt
      lastActiveAt
    }
  }
`;p`
  query AdminFeedbackStats {
    adminFeedbackStats {
      total
      pending
      resolved
      byType
    }
  }
`;p`
  query AdminBugsStats {
    adminBugsStats {
      total
      open
      inProgress
      resolved
      critical
    }
  }
`;p`
  query AdminTestScorecard {
    adminTestScorecard {
      passRate
      totalTests
      passed
      failed
      skipped
      categories {
        name
        passRate
        tests
      }
      lastRun
    }
  }
`;const GA=p`
  query WorkoutTemplates($input: WorkoutTemplateSearchInput) {
    workoutTemplates(input: $input) {
      templates {
        id
        creatorId
        creatorUsername
        creatorDisplayName
        name
        description
        exercises {
          exerciseId
          name
          sets
          reps
          weight
          duration
          restSeconds
          notes
        }
        difficulty
        durationMinutes
        targetMuscles
        equipmentRequired
        category
        tags
        isPublic
        isFeatured
        timesUsed
        timesCloned
        averageRating
        ratingCount
        userRating
        isSaved
        createdAt
        updatedAt
      }
      total
    }
  }
`;p`
  query WorkoutTemplate($id: ID!) {
    workoutTemplate(id: $id) {
      id
      creatorId
      creatorUsername
      creatorDisplayName
      name
      description
      exercises {
        exerciseId
        name
        sets
        reps
        weight
        duration
        restSeconds
        notes
      }
      difficulty
      durationMinutes
      targetMuscles
      equipmentRequired
      category
      tags
      isPublic
      isFeatured
      timesUsed
      timesCloned
      averageRating
      ratingCount
      userRating
      isSaved
      createdAt
      updatedAt
    }
  }
`;const YA=p`
  query MyWorkoutTemplates($limit: Int, $offset: Int) {
    myWorkoutTemplates(limit: $limit, offset: $offset) {
      templates {
        id
        creatorId
        creatorUsername
        creatorDisplayName
        name
        description
        exercises {
          exerciseId
          name
          sets
          reps
          weight
          duration
          restSeconds
          notes
        }
        difficulty
        durationMinutes
        targetMuscles
        equipmentRequired
        category
        tags
        isPublic
        isFeatured
        timesUsed
        timesCloned
        averageRating
        ratingCount
        userRating
        isSaved
        createdAt
        updatedAt
      }
      total
    }
  }
`,KA=p`
  query SavedWorkoutTemplates($folder: String, $limit: Int, $offset: Int) {
    savedWorkoutTemplates(folder: $folder, limit: $limit, offset: $offset) {
      templates {
        id
        creatorId
        creatorUsername
        creatorDisplayName
        name
        description
        exercises {
          exerciseId
          name
          sets
          reps
          weight
          duration
          restSeconds
          notes
        }
        difficulty
        durationMinutes
        targetMuscles
        equipmentRequired
        category
        tags
        isPublic
        isFeatured
        timesUsed
        timesCloned
        averageRating
        ratingCount
        userRating
        isSaved
        createdAt
        updatedAt
      }
      total
    }
  }
`;p`
  query FeaturedWorkoutTemplates($limit: Int) {
    featuredWorkoutTemplates(limit: $limit) {
      id
      creatorId
      creatorUsername
      creatorDisplayName
      name
      description
      exercises {
        exerciseId
        name
        sets
        reps
        weight
        duration
        restSeconds
        notes
      }
      difficulty
      durationMinutes
      targetMuscles
      equipmentRequired
      category
      tags
      isPublic
      isFeatured
      timesUsed
      timesCloned
      averageRating
      ratingCount
      userRating
      isSaved
      createdAt
      updatedAt
    }
  }
`;const QA=p`
  query RecoveryScore($forceRecalculate: Boolean) {
    recoveryScore(forceRecalculate: $forceRecalculate) {
      id
      userId
      score
      classification
      factors {
        sleepDurationScore
        sleepQualityScore
        restDaysScore
        hrvBonus
        strainPenalty
        consistencyBonus
        sleepDetails {
          hoursSlept
          targetHours
          qualityRating
        }
        restDetails {
          daysSinceLastWorkout
          workoutsThisWeek
          averageIntensity
        }
        hrvDetails {
          currentHrv
          baselineHrv
          percentOfBaseline
        }
      }
      recommendedIntensity
      recommendedWorkoutTypes
      trend
      trendConfidence
      calculatedAt
      expiresAt
      dataSources
    }
  }
`,JA=p`
  query RecoveryStatus {
    recoveryStatus {
      currentScore {
        id
        score
        classification
        recommendedIntensity
        trend
      }
      lastSleep {
        id
        bedTime
        wakeTime
        sleepDurationMinutes
        quality
        notes
      }
      sleepStats {
        avgDuration
        avgQuality
        totalNights
        sleepDebt
        consistency
      }
      recommendations {
        id
        type
        priority
        title
        description
        actionItems {
          action
          completed
        }
      }
      sleepGoal {
        id
        targetHours
        targetBedTime
        targetWakeTime
      }
      nextWorkoutSuggestion {
        intensity
        types
        reason
      }
    }
  }
`,XA=p`
  query MuscleRecoveryStatus {
    muscleRecoveryStatus {
      muscleGroups {
        muscleGroup
        recoveryPercentage
        lastWorked
        hoursUntilRecovered
      }
      overallRecovery
      recommendations
    }
  }
`,ZA=p`
  query SleepTracking($limit: Int) {
    sleepTracking(limit: $limit) {
      logs {
        id
        bedTime
        wakeTime
        sleepDurationMinutes
        quality
        notes
        createdAt
      }
      stats {
        avgDuration
        avgQuality
        sleepDebt
      }
    }
  }
`;p`
  query RecoveryHistory($days: Int) {
    recoveryHistory(days: $days) {
      scores {
        id
        score
        classification
        calculatedAt
      }
      averageScore
      trend
      bestScore
      worstScore
      daysTracked
    }
  }
`;const e_=p`
  query RecoveryRecommendations {
    recoveryRecommendations {
      id
      type
      priority
      title
      description
      actionItems {
        action
        completed
      }
    }
  }
`;p`
  query LastSleep {
    lastSleep {
      id
      bedTime
      wakeTime
      sleepDurationMinutes
      quality
      notes
      factors {
        lateExercise
        lateFood
        screenBeforeBed
        caffeineAfter6pm
        alcoholConsumed
      }
      createdAt
    }
  }
`;const t_=p`
  query SleepHistory($limit: Int, $cursor: String, $startDate: DateTime, $endDate: DateTime) {
    sleepHistory(limit: $limit, cursor: $cursor, startDate: $startDate, endDate: $endDate) {
      logs {
        id
        bedTime
        wakeTime
        sleepDurationMinutes
        quality
        notes
        createdAt
      }
      nextCursor
      hasMore
    }
  }
`;p`
  query SleepStats($period: String) {
    sleepStats(period: $period) {
      avgDuration
      avgQuality
      totalNights
      sleepDebt
      consistency
      qualityDistribution {
        poor
        fair
        good
        excellent
      }
    }
  }
`;p`
  query WeeklySleepStats($weeks: Int) {
    weeklySleepStats(weeks: $weeks) {
      weekStart
      weekEnd
      avgDuration
      avgQuality
      nightsTracked
      sleepDebt
    }
  }
`;p`
  query SleepGoal {
    sleepGoal {
      id
      targetHours
      targetBedTime
      targetWakeTime
      reminderEnabled
      reminderMinutesBefore
    }
  }
`;const n_=p`
  query CareerStandards($category: String) {
    careerStandards(category: $category) {
      id
      name
      fullName
      agency
      category
      description
      officialUrl
      scoringType
      recertificationPeriodMonths
      events {
        id
        name
        description
        metricType
        metricUnit
        direction
        passingThreshold
        exerciseMappings
        tips
        orderIndex
      }
      eventCount
      icon
      maxScore
      passingScore
    }
  }
`,s_=p`
  query CareerStandard($id: ID!) {
    careerStandard(id: $id) {
      id
      name
      fullName
      agency
      category
      description
      officialUrl
      scoringType
      recertificationPeriodMonths
      events {
        id
        name
        description
        metricType
        metricUnit
        direction
        passingThreshold
        exerciseMappings
        tips
        orderIndex
      }
      eventCount
      icon
      maxScore
      passingScore
    }
  }
`,r_=p`
  query CareerStandardCategories {
    careerStandardCategories {
      category
      count
      icon
    }
  }
`,i_=p`
  query MyCareerGoals {
    myCareerGoals {
      id
      standard {
        id
        name
        fullName
        agency
        category
        description
        icon
        eventCount
        scoringType
        maxScore
        passingScore
      }
      standardId
      targetDate
      priority
      status
      agencyName
      notes
      readiness {
        score
        status
        trend
        trendDelta
        eventBreakdown {
          eventId
          eventName
          passed
          value
          status
        }
        weakEvents
        lastAssessmentAt
        eventsPassed
        eventsTotal
      }
      daysRemaining
      createdAt
      updatedAt
    }
  }
`,a_=p`
  query MyCareerReadiness($goalId: ID) {
    myCareerReadiness(goalId: $goalId) {
      score
      status
      trend
      trendDelta
      eventBreakdown {
        eventId
        eventName
        passed
        value
        status
      }
      weakEvents
      lastAssessmentAt
      eventsPassed
      eventsTotal
    }
  }
`,o_=p`
  query CareerExerciseRecommendations($goalId: ID!) {
    careerExerciseRecommendations(goalId: $goalId) {
      exerciseId
      exerciseName
      targetEvents
    }
  }
`,c_=p`
  query CareerGoal($goalId: ID!) {
    careerGoal(goalId: $goalId) {
      id
      standard {
        id
        name
        fullName
        agency
        category
        icon
      }
      standardId
      targetDate
      priority
      status
      agencyName
      notes
      readiness {
        score
        status
        eventsPassed
        eventsTotal
      }
      daysRemaining
      createdAt
    }
  }
`,l_=p`
  query CareerGoalReadiness($goalId: ID!) {
    careerGoalReadiness(goalId: $goalId) {
      score
      status
      eventsPassed
      eventsTotal
      weakEvents
      lastAssessmentAt
      events {
        id
        name
        currentValue
        passingValue
        unit
        isPassing
      }
    }
  }
`,u_=p`
  query CareerGoalTrend($goalId: ID!) {
    careerGoalTrend(goalId: $goalId) {
      date
      score
      eventsPassed
      eventsTotal
    }
  }
`,d_=p`
  query MySettings {
    mySettings {
      theme
      reducedMotion
      highContrast
      textSize
      isPublic
      showLocation
      showProgress
      equipment
    }
  }
`,m_=p`
  query MessagingPrivacy {
    messagingPrivacy {
      messagingEnabled
    }
  }
`,h_=p`
  query MyProfileLevel {
    me {
      id
      level
    }
  }
`,p_=p`
  query MyFullProfile {
    myFullProfile {
      id
      username
      displayName
      avatarUrl
      avatarId
      xp
      level
      rank
      wealthTier
      age
      gender
      heightCm
      weightKg
      preferredUnits
      ghostMode
      leaderboardOptIn
      aboutMe
      limitations
      equipmentInventory
      weeklyActivity
      theme
    }
  }
`,f_=p`
  query MyAvatars {
    myAvatars {
      id
      name
      rarity
      unlockLevel
      imageUrl
      description
    }
  }
`,g_=p`
  query MyThemes {
    myThemes {
      id
      name
      rarity
      unlockLevel
      colors
      description
    }
  }
`,y_=p`
  query HighFiveStats {
    highFiveStats {
      sent
      received
      unread
    }
  }
`,v_=p`
  query HighFiveUsers {
    highFiveUsers {
      id
      username
      level
      currentArchetype
      avatarUrl
    }
  }
`,S_=p`
  query HighFivesReceived {
    highFivesReceived {
      id
      type
      message
      senderName
      senderId
      readAt
      createdAt
    }
  }
`,T_=p`
  query HighFivesSent {
    highFivesSent {
      id
      type
      message
      recipientName
      recipientId
      createdAt
    }
  }
`,b_=p`
  query MyLimitations($status: String) {
    limitations(status: $status) {
      id
      userId
      bodyRegionId
      bodyRegionName
      limitationType
      severity
      status
      name
      description
      medicalNotes
      avoidMovements
      avoidImpact
      avoidWeightBearing
      maxWeightLbs
      maxReps
      romFlexionPercent
      romExtensionPercent
      romRotationPercent
      onsetDate
      expectedRecoveryDate
      lastReviewed
      diagnosedBy
      ptApproved
      createdAt
      updatedAt
    }
  }
`,w_=p`
  query BodyRegions {
    bodyRegions {
      id
      name
      icon
      children {
        id
        name
        icon
      }
    }
  }
`;p`
  query PTTests {
    ptTests {
      id
      name
      description
      institution
      components
      scoringMethod
      maxScore
      passingScore
      testFrequency
      sourceUrl
      lastUpdated
      category
    }
  }
`;const I_=p`
  query PTTestsByInstitution {
    ptTestsByInstitution {
      tests {
        id
        name
        description
        institution
        components
        scoringMethod
        maxScore
        passingScore
        testFrequency
        sourceUrl
        lastUpdated
        category
      }
      byInstitution
    }
  }
`;p`
  query PTTest($id: ID!) {
    ptTest(id: $id) {
      id
      name
      description
      institution
      components
      scoringMethod
      maxScore
      passingScore
      testFrequency
      sourceUrl
      lastUpdated
      category
    }
  }
`;const x_=p`
  query MyArchetypePTTest {
    myArchetypePTTest {
      id
      name
      description
      institution
      components
      scoringMethod
      maxScore
      passingScore
      testFrequency
      sourceUrl
    }
  }
`,E_=p`
  query PTTestResults($testId: ID, $limit: Int) {
    ptTestResults(testId: $testId, limit: $limit) {
      id
      testId
      testName
      institution
      testDate
      componentResults
      totalScore
      passed
      category
      official
      location
      proctor
      notes
      recordedAt
    }
  }
`;p`
  query PTTestResult($id: ID!) {
    ptTestResult(id: $id) {
      result {
        id
        testId
        testName
        institution
        testDate
        componentResults
        totalScore
        passed
        category
        official
        location
        proctor
        notes
        recordedAt
      }
      components
      previousResults {
        testDate
        totalScore
        passed
      }
    }
  }
`;p`
  query PTTestLeaderboard($testId: ID!) {
    ptTestLeaderboard(testId: $testId) {
      rank
      userId
      username
      displayName
      avatar
      score
      testDate
      passed
      category
    }
  }
`;const A_=p`
  query ProgressPhotos($limit: Int, $cursor: String, $photoType: String) {
    progressPhotos(limit: $limit, cursor: $cursor, photoType: $photoType) {
      photos {
        id
        userId
        storagePath
        thumbnailPath
        photoType
        pose
        isPrivate
        weightKg
        bodyFatPercentage
        notes
        photoDate
        createdAt
      }
      pagination {
        hasMore
        nextCursor
        count
      }
    }
  }
`;p`
  query ProgressPhoto($id: ID!) {
    progressPhoto(id: $id) {
      id
      userId
      storagePath
      thumbnailPath
      photoType
      pose
      isPrivate
      weightKg
      bodyFatPercentage
      notes
      photoDate
      createdAt
    }
  }
`;p`
  query ProgressPhotoTimeline($days: Int) {
    progressPhotoTimeline(days: $days) {
      timeline
    }
  }
`;p`
  query ProgressPhotoComparison($photoType: String, $pose: String) {
    progressPhotoComparison(photoType: $photoType, pose: $pose) {
      first {
        id
        storagePath
        thumbnailPath
        photoType
        pose
        weightKg
        photoDate
      }
      middle {
        id
        storagePath
        thumbnailPath
        photoType
        pose
        weightKg
        photoDate
      }
      last {
        id
        storagePath
        thumbnailPath
        photoType
        pose
        weightKg
        photoDate
      }
      totalPhotos
      daysBetween
      allPhotos {
        id
        storagePath
        thumbnailPath
        photoType
        pose
        weightKg
        photoDate
      }
      message
    }
  }
`;const __=p`
  query ProgressPhotoStats {
    progressPhotoStats {
      byType
      firstPhoto
      lastPhoto
      totalPhotos
    }
  }
`,C_=p`
  query WearablesSummary {
    wearablesSummary {
      today {
        steps
        activeCalories
        avgHeartRate
        workoutMinutes
        sleepHours
      }
      thisWeek {
        totalSteps
        avgDailySteps
        totalWorkoutMinutes
        avgSleepHours
        avgRestingHeartRate
      }
    }
  }
`,k_=p`
  query WearablesStatus {
    wearablesStatus {
      syncStatus {
        provider
        lastSyncAt
        isConnected
      }
    }
  }
`;p`
  query WearableConnections {
    wearableConnections {
      provider
      lastSyncAt
      isConnected
    }
  }
`;const R_=p`
  query ProgressionMastery {
    progressionMastery {
      archetypeId
      archetypeName
      totalTu
      tier
    }
  }
`,P_=p`
  query ProgressionAchievements {
    progressionAchievements {
      id
      name
      description
      earned
      earnedAt
      iconUrl
    }
  }
`,M_=p`
  query ProgressionNutrition {
    progressionNutrition {
      tips {
        id
        title
        content
      }
    }
  }
`,O_=p`
  query ProgressionLeaderboard($limit: Int) {
    progressionLeaderboard(limit: $limit) {
      rank
      userId
      username
      avatar
      level
      xp
      totalTu
    }
  }
`;p`
  query ProgressionRecords($limit: Int, $recordType: String) {
    progressionRecords(limit: $limit, recordType: $recordType) {
      id
      exerciseId
      exerciseName
      recordType
      value
      previousValue
      unit
      achievedAt
    }
  }
`;p`
  query ProgressionExerciseRecords($exerciseId: ID!) {
    progressionExerciseRecords(exerciseId: $exerciseId) {
      id
      exerciseId
      exerciseName
      recordType
      value
      previousValue
      unit
      achievedAt
    }
  }
`;p`
  query ProgressionExerciseStats($exerciseId: ID!) {
    progressionExerciseStats(exerciseId: $exerciseId) {
      exerciseId
      exerciseName
      totalSets
      totalReps
      totalVolume
      maxWeight
      avgWeight
      lastWorkoutAt
      history {
        date
        sets
        reps
        weight
        volume
      }
    }
  }
`;p`
  query ProgressionRecommendations($limit: Int) {
    progressionRecommendations(limit: $limit) {
      exerciseId
      exerciseName
      recommendationType
      currentValue
      recommendedValue
      unit
      message
      confidence
    }
  }
`;const N_=p`
  query ProgressionTargets($exerciseId: ID, $includeCompleted: Boolean) {
    progressionTargets(exerciseId: $exerciseId, includeCompleted: $includeCompleted) {
      id
      exerciseId
      exerciseName
      targetType
      currentValue
      targetValue
      incrementValue
      incrementFrequency
      targetDate
      status
      progress
      createdAt
      completedAt
    }
  }
`,$_=p`
  query ProgressionMilestones {
    milestones {
      id
      type
      title
      description
      target
      current
      reward
      claimed
      unlockedAt
    }
  }
`,D_=p`
  query NearbyLocations($lat: Float!, $lng: Float!, $type: String, $limit: Int) {
    nearbyLocations(lat: $lat, lng: $lng, type: $type, limit: $limit) {
      id
      name
      type
      city
      description
      lat
      lng
      avgRating
      ratingCount
      distance
      createdAt
    }
  }
`,j_=p`
  query SearchLocations($query: String!, $type: String, $limit: Int) {
    searchLocations(query: $query, type: $type, limit: $limit) {
      id
      name
      type
      city
      description
      lat
      lng
      avgRating
      ratingCount
      distance
      createdAt
    }
  }
`,L_=p`
  query LocationDetails($id: ID!) {
    location(id: $id) {
      location {
        id
        name
        type
        city
        description
        lat
        lng
        avgRating
        ratingCount
        createdAt
      }
      ratings {
        avgRating
        avgSafety
        avgCrowd
        avgClean
        totalRatings
      }
      amenities {
        amenity
        count
      }
      comments {
        id
        userId
        username
        comment
        upvotes
        createdAt
      }
    }
  }
`,U_=p`
  query Milestones {
    milestones {
      id
      name
      description
      threshold
      currentValue
      progress
      completedAt
      reward
      rewardClaimed
    }
  }
`,V_=p`
  query NutritionDashboard {
    nutritionDashboard {
      enabled
      preferences {
        caloriesEnabled
        macrosEnabled
        micronutrientsEnabled
        waterTrackingEnabled
        mealRemindersEnabled
      }
      goals {
        dailyCalories
        proteinGrams
        carbsGrams
        fatGrams
        fiberGrams
        waterLiters
      }
      todaySummary {
        date
        totalCalories
        totalProteinG
        totalCarbsG
        totalFatG
        totalFiberG
        waterMl
        mealCount
      }
      streaks {
        currentLoggingStreak
        longestLoggingStreak
        currentGoalStreak
        longestGoalStreak
        lastLoggedAt
      }
    }
  }
`;p`
  query PendingEquipmentSuggestions($venueId: ID!) {
    pendingEquipmentSuggestions(venueId: $venueId) {
      id
      venueId
      equipmentType
      quantity
      condition
      notes
      photoUrl
      status
      supportCount
      rejectCount
      suggestedBy {
        id
        username
        displayName
        avatar
      }
      locationVerified
      createdAt
    }
  }
`;p`
  query EquipmentConsensus($equipmentItemId: ID!) {
    equipmentConsensus(equipmentItemId: $equipmentItemId) {
      totalVotes
      conditionVotes {
        condition
        count
        percentage
      }
      existsVotes {
        exists
        count
        percentage
      }
      lastVerifiedAt
      confidenceLevel
    }
  }
`;p`
  mutation SuggestEquipment($venueId: ID!, $input: EquipmentSuggestionInput!) {
    suggestEquipment(venueId: $venueId, input: $input) {
      success
      suggestion {
        id
        equipmentType
        status
        supportCount
        createdAt
      }
      creditsEarned
      message
    }
  }
`;p`
  mutation VoteOnSuggestion($suggestionId: ID!, $support: Boolean!, $latitude: Float, $longitude: Float) {
    voteOnSuggestion(suggestionId: $suggestionId, support: $support, latitude: $latitude, longitude: $longitude) {
      success
      suggestion {
        id
        status
        supportCount
        rejectCount
      }
      creditsEarned
    }
  }
`;p`
  mutation VoteEquipmentCondition($equipmentItemId: ID!, $condition: String!, $latitude: Float, $longitude: Float) {
    voteEquipmentCondition(equipmentItemId: $equipmentItemId, condition: $condition, latitude: $latitude, longitude: $longitude) {
      success
      equipment {
        id
        condition
        consensusCondition
        verificationCount
        confidenceLevel
      }
      creditsEarned
    }
  }
`;p`
  mutation ReportEquipmentRemoved($equipmentItemId: ID!, $reason: String, $latitude: Float, $longitude: Float) {
    reportEquipmentRemoved(equipmentItemId: $equipmentItemId, reason: $reason, latitude: $latitude, longitude: $longitude) {
      success
      creditsEarned
      message
    }
  }
`;p`
  query OutdoorEquipmentTypes {
    outdoorEquipmentTypes {
      id
      name
      slug
      category
      description
      iconName
      muscleGroups
    }
  }
`;const Mh=p`
  query MascotState {
    mascot {
      id
      userId
      nickname
      stage
      xp
      progression {
        currentXp
        prevStageXp
        nextStageXp
        progressPercent
        isMaxStage
      }
      isVisible
      isMinimized
      soundsEnabled
      tipsEnabled
      createdAt
    }
  }
`,Oh=p`
  query MascotShop {
    mascotShop {
      slotNumber
      cosmetic {
        id
        itemKey
        name
        description
        slot
        rarity
        price
        requiredStage
        assetUrl
      }
      discountPercent
      finalPrice
      expiresAt
      owned
    }
  }
`;p`
  query MascotWardrobe {
    mascotWardrobe {
      inventory {
        id
        cosmetic {
          id
          itemKey
          name
          description
          slot
          rarity
          price
          requiredStage
          assetUrl
        }
        acquiredAt
        acquiredMethod
        isFavorite
        isNew
      }
      presets {
        id
        name
        icon
        loadout {
          skin { id itemKey name slot assetUrl }
          eyes { id itemKey name slot assetUrl }
          outfit { id itemKey name slot assetUrl }
          accessory { id itemKey name slot assetUrl }
          aura { id itemKey name slot assetUrl }
          trail { id itemKey name slot assetUrl }
          emoteVictory { id itemKey name slot assetUrl }
          emoteDefeat { id itemKey name slot assetUrl }
          emoteIdle { id itemKey name slot assetUrl }
        }
        createdAt
      }
      currentLoadout {
        skin { id itemKey name slot assetUrl }
        eyes { id itemKey name slot assetUrl }
        outfit { id itemKey name slot assetUrl }
        accessory { id itemKey name slot assetUrl }
        aura { id itemKey name slot assetUrl }
        trail { id itemKey name slot assetUrl }
        emoteVictory { id itemKey name slot assetUrl }
        emoteDefeat { id itemKey name slot assetUrl }
        emoteIdle { id itemKey name slot assetUrl }
      }
    }
  }
`;const Nh=p`
  query MascotPendingReactions($limit: Int) {
    mascotPendingReactions(limit: $limit) {
      id
      eventId
      reactionType
      message
      emote
      animation
      duration
      intensity
      soundEffect
      shown
      createdAt
    }
  }
`,B_=p`
  query JourneyHealth($journeyId: ID!) {
    journeyHealth(journeyId: $journeyId) {
      score
      trend
      lastCalculated
      factors {
        name
        score
        weight
      }
    }
  }
`,F_=p`
  query JourneyHealthAlerts($journeyId: ID, $status: String, $limit: Int) {
    journeyHealthAlerts(journeyId: $journeyId, status: $status, limit: $limit) {
      id
      type
      severity
      message
      actionUrl
      createdAt
    }
  }
`,q_=p`
  query JourneyRecommendations($journeyId: ID!) {
    journeyRecommendations(journeyId: $journeyId) {
      id
      type
      title
      description
      priority
      actionLabel
      actionUrl
    }
  }
`;p`
  query StalledJourneys($thresholdDays: Int) {
    stalledJourneys(thresholdDays: $thresholdDays) {
      journeyId
      userId
      username
      stalledDays
      lastActivityAt
      reason
    }
  }
`;p`
  query CreditEarningSummary {
    creditEarningSummary {
      todayEarned
      weekEarned
      monthEarned
      availableOpportunities
      streakBonus
    }
  }
`;p`
  query CreditEarnEvents($unreadOnly: Boolean, $limit: Int) {
    creditEarnEvents(unreadOnly: $unreadOnly, limit: $limit) {
      events {
        id
        type
        amount
        description
        createdAt
        shown
      }
      unreadCount
    }
  }
`;p`
  query BonusEventTypes($enabledOnly: Boolean) {
    bonusEventTypes(enabledOnly: $enabledOnly) {
      id
      name
      multiplier
      startTime
      endTime
      description
    }
  }
`;p`
  query BonusEventHistory($limit: Int) {
    bonusEventHistory(limit: $limit) {
      id
      eventTypeId
      eventName
      multiplier
      earnedAt
      baseAmount
      bonusAmount
    }
  }
`;p`
  query CreditPackages {
    creditPackages {
      id
      name
      credits
      price
      currency
      bonus
      popular
    }
  }
`;p`
  query MascotCreditLoanOffer {
    mascotCreditLoanOffer {
      available
      maxAmount
      interestRate
      repaymentDays
      currentLoan {
        amount
        dueDate
        amountOwed
      }
    }
  }
`;p`
  query MascotOvertrainingAlerts {
    mascotOvertrainingAlerts {
      id
      muscleGroup
      severity
      message
      suggestedRestDays
      createdAt
    }
  }
`;p`
  query MascotWorkoutSuggestions($limit: Int) {
    mascotWorkoutSuggestions(limit: $limit) {
      id
      type
      title
      description
      exercises {
        id
        name
        sets
        reps
      }
      reason
    }
  }
`;p`
  query MascotMilestoneProgress {
    mascotMilestoneProgress {
      currentPhase
      phaseName
      totalMilestones
      completedMilestones
      nextMilestone {
        id
        name
        description
        progress
        target
      }
    }
  }
`;p`
  query MascotMasterAbilities {
    mascotMasterAbilities {
      key
      name
      description
      unlocked
      unlockCost
      requirements
    }
  }
`;p`
  query MascotGeneratedPrograms($status: String) {
    mascotGeneratedPrograms(status: $status) {
      id
      name
      description
      duration
      difficulty
      status
      createdAt
    }
  }
`;p`
  query MascotCrewSuggestions($limit: Int) {
    mascotCrewSuggestions(limit: $limit) {
      userId
      username
      avatarUrl
      compatibility
      reason
      mutualFriends
    }
  }
`;p`
  query MascotRivalryAlerts($limit: Int) {
    mascotRivalryAlerts(limit: $limit) {
      id
      rivalUserId
      rivalUsername
      alertType
      message
      statComparison {
        stat
        yourValue
        theirValue
      }
      createdAt
    }
  }
`;p`
  query MascotNegotiatedRate($trainerId: ID!) {
    mascotNegotiatedRate(trainerId: $trainerId) {
      originalRate
      negotiatedRate
      discountPercent
      validUntil
    }
  }
`;p`
  query PrescriptionHistory($limit: Int, $offset: Int) {
    prescriptionHistory(limit: $limit, offset: $offset) {
      id
      createdAt
      targetMuscles
      difficulty
      totalDuration
      exerciseCount
      rating
      feedback
    }
  }
`;p`
  query BiomechanicsProfile {
    biomechanicsProfile {
      limbLengths {
        armSpan
        torsoLength
        legLength
        femurLength
        tibiaLength
      }
      mobility {
        shoulderFlexion
        hipFlexion
        ankleFlexion
        spineFlexion
      }
      injuries {
        area
        type
        severity
        excludeExercises
      }
      preferences {
        preferredEquipment
        avoidedExercises
        favoriteExercises
      }
    }
  }
`;p`
  query TrainingPrograms($input: ProgramSearchInput) {
    trainingPrograms(input: $input) {
      id
      name
      description
      duration
      difficulty
      category
      rating
      enrollmentCount
      author {
        id
        username
        avatarUrl
      }
    }
  }
`;p`
  query TrainingProgram($id: ID!) {
    trainingProgram(id: $id) {
      id
      name
      description
      duration
      difficulty
      category
      rating
      enrollmentCount
      workouts {
        day
        name
        exercises {
          id
          name
          sets
          reps
          rest
        }
      }
      author {
        id
        username
        avatarUrl
      }
    }
  }
`;p`
  query FeaturedPrograms($limit: Int) {
    featuredPrograms(limit: $limit) {
      id
      name
      description
      duration
      difficulty
      rating
      enrollmentCount
      thumbnailUrl
    }
  }
`;p`
  query MyEnrollments($status: String, $limit: Int, $offset: Int) {
    myEnrollments(status: $status, limit: $limit, offset: $offset) {
      id
      programId
      programName
      status
      currentDay
      totalDays
      startedAt
      lastWorkoutAt
      progress
    }
  }
`;p`
  query TodaysWorkout($programId: ID) {
    todaysWorkout(programId: $programId) {
      day
      workout {
        id
        name
        exercises {
          id
          name
          sets
          reps
        }
      }
      completed
    }
  }
`;p`
  query Mentors($verified: Boolean, $specialty: String, $limit: Int) {
    mentors(verified: $verified, specialty: $specialty, limit: $limit) {
      userId
      displayName
      avatarUrl
      specialties
      hourlyRate
      rating
      reviewCount
      verified
      maxMentees
      currentMentees
    }
  }
`;p`
  query Mentor($userId: ID!) {
    mentor(userId: $userId) {
      userId
      displayName
      avatarUrl
      bio
      specialties
      hourlyRate
      rating
      reviewCount
      verified
      maxMentees
      currentMentees
      availability
      reviews {
        id
        rating
        comment
        createdAt
        menteeUsername
      }
    }
  }
`;p`
  query MyMentorProfile {
    myMentorProfile {
      userId
      displayName
      bio
      specialties
      hourlyRate
      verified
      maxMentees
      currentMentees
      availability
      totalEarnings
      activeRequests
    }
  }
`;p`
  query ActiveMentorships {
    activeMentorships {
      id
      mentor {
        userId
        displayName
        avatarUrl
      }
      mentee {
        userId
        displayName
        avatarUrl
      }
      status
      focusAreas
      startDate
      lastCheckIn
    }
  }
`;p`
  query MentorshipCheckIns($mentorshipId: ID!, $limit: Int) {
    mentorshipCheckIns(mentorshipId: $mentorshipId, limit: $limit) {
      id
      mentorshipId
      notes
      goals
      progress
      createdAt
      createdBy
    }
  }
`;p`
  query MyOrganizations {
    myOrganizations {
      id
      name
      slug
      logoUrl
      role
      memberCount
    }
  }
`;p`
  query Organization($id: ID, $slug: String) {
    organization(id: $id, slug: $slug) {
      id
      name
      slug
      description
      logoUrl
      memberCount
      subscription
      settings
      myRole
    }
  }
`;p`
  query OrganizationMembers($orgId: ID!, $limit: Int, $offset: Int) {
    organizationMembers(orgId: $orgId, limit: $limit, offset: $offset) {
      members {
        userId
        username
        displayName
        avatarUrl
        role
        unitId
        unitName
        joinedAt
      }
      total
    }
  }
`;p`
  query OrganizationUnits($orgId: ID!) {
    organizationUnits(orgId: $orgId) {
      id
      name
      description
      parentId
      memberCount
      managerUserId
      managerName
    }
  }
`;p`
  query OrganizationStats($orgId: ID!) {
    organizationStats(orgId: $orgId) {
      totalMembers
      activeMembers
      totalWorkouts
      avgWorkoutsPerMember
      topPerformers {
        userId
        username
        workoutCount
        rank
      }
    }
  }
`;p`
  query AdminServerStatus {
    adminServerStatus {
      pm2Processes {
        name
        pid
        status
        cpu
        memory
        uptime
        restarts
      }
      systemInfo {
        hostname
        platform
        cpuUsage
        memoryUsage
        diskUsage
        nodeVersion
      }
    }
  }
`;p`
  query AdminDatabaseStats {
    adminDatabaseStats {
      connections {
        active
        idle
        waiting
        total
        maxConnections
      }
      tableStats {
        name
        rowCount
        size
        indexSize
      }
      slowQueries {
        query
        duration
        timestamp
      }
    }
  }
`;p`
  query AdminSecurityLogs($limit: Int, $eventType: String) {
    adminSecurityLogs(limit: $limit, eventType: $eventType) {
      id
      eventType
      userId
      username
      ipAddress
      userAgent
      success
      details
      timestamp
    }
  }
`;p`
  query AdminFeatureFlags {
    adminFeatureFlags {
      id
      key
      name
      description
      enabled
      percentage
      updatedAt
      updatedBy
    }
  }
`;p`
  query AdminAlertRules {
    adminAlertRules {
      id
      name
      type
      threshold
      comparison
      windowMinutes
      enabled
      channels
      lastTriggered
    }
  }
`;p`
  query AdminAlertHistory($limit: Int, $ruleId: ID) {
    adminAlertHistory(limit: $limit, ruleId: $ruleId) {
      id
      ruleId
      ruleName
      triggeredAt
      value
      resolvedAt
      acknowledgedBy
      notes
    }
  }
`;p`
  query AdminBackups($limit: Int) {
    adminBackups(limit: $limit) {
      id
      filename
      size
      createdAt
      type
      status
      downloadUrl
    }
  }
`;p`
  query AdminUserAnalytics($period: String) {
    adminUserAnalytics(period: $period) {
      dau
      wau
      mau
      newUsers
      churnedUsers
      retentionRate
      avgSessionDuration
      featureAdoption {
        feature
        adoptionRate
        activeUsers
      }
      cohorts {
        cohortDate
        size
        retained {
          day
          count
          rate
        }
      }
    }
  }
`;const W_=p`
  mutation Register($input: RegisterInput!) {
    register(input: $input) {
      token
      user {
        id
        email
        username
        level
        xp
        roles
        createdAt
      }
    }
  }
`,z_=p`
  mutation Login($input: LoginInput!) {
    login(input: $input) {
      token
      user {
        id
        email
        username
        displayName
        level
        xp
        roles
        createdAt
        archetype {
          id
          name
        }
      }
    }
  }
`;p`
  mutation UpdateProfile($input: ProfileInput!) {
    updateProfile(input: $input) {
      id
      userId
      displayName
      bio
      avatar
      location
      visibility
      createdAt
      updatedAt
    }
  }
`;const H_=p`
  mutation CreateWorkout($input: WorkoutInput!) {
    createWorkout(input: $input) {
      workout {
        id
        userId
        exercises {
          exerciseId
          name
          sets
          reps
          weight
          notes
        }
        notes
        totalTU
        createdAt
      }
      tuEarned
      characterStats {
        userId
        level
        xp
        xpToNextLevel
        strength
        endurance
        agility
        flexibility
        balance
        mentalFocus
        totalWorkouts
        currentStreak
      }
      levelUp
      newLevel
      achievements {
        id
        name
        description
        icon
        rarity
        unlockedAt
      }
    }
  }
`;p`
  mutation PreviewWorkout($input: WorkoutInput!) {
    previewWorkout(input: $input) {
      exercises {
        exerciseId
        name
        sets
        reps
        weight
      }
      estimatedTU
      estimatedXP
      musclesTargeted
    }
  }
`;const G_=p`
  mutation CreateGoal($input: GoalInput!) {
    createGoal(input: $input) {
      id
      userId
      type
      title
      description
      target
      current
      unit
      deadline
      status
      createdAt
      updatedAt
    }
  }
`,Y_=p`
  mutation UpdateGoal($id: ID!, $input: GoalInput!) {
    updateGoal(id: $id, input: $input) {
      id
      userId
      type
      title
      description
      target
      current
      unit
      deadline
      status
      isPrimary
      createdAt
      updatedAt
    }
  }
`,K_=p`
  mutation DeleteGoal($id: ID!) {
    deleteGoal(id: $id)
  }
`,Q_=p`
  mutation SelectArchetype($archetypeId: ID!) {
    selectArchetype(archetypeId: $archetypeId) {
      success
      archetype {
        id
        name
        description
      }
      journey {
        userId
        currentLevel
        currentXP
        xpToNextLevel
        totalXP
        completedMilestones
        unlockedAbilities
      }
    }
  }
`;p`
  mutation ChargeCredits($input: ChargeInput!) {
    chargeCredits(input: $input) {
      success
      newBalance
      error
    }
  }
`;p`
  mutation MarkTipSeen($tipId: ID!) {
    markTipSeen(tipId: $tipId)
  }
`;p`
  mutation LogFrontendError($input: FrontendLogInput!) {
    logFrontendError(input: $input)
  }
`;const J_=p`
  mutation StartWorkoutSession($input: StartWorkoutSessionInput) {
    startWorkoutSession(input: $input) {
      session {
        id
        userId
        startedAt
        currentExerciseIndex
        currentSetIndex
        totalVolume
        totalReps
        estimatedCalories
      }
      setLogged {
        id
      }
      prsAchieved {
        exerciseId
        prType
      }
    }
  }
`,X_=p`
  mutation LogSet($input: LogSetInput!) {
    logSet(input: $input) {
      session {
        id
        totalVolume
        totalReps
        estimatedCalories
        currentExerciseIndex
        currentSetIndex
      }
      setLogged {
        id
        exerciseId
        exerciseName
        setNumber
        reps
        weightKg
        rpe
        tu
        isPRWeight
        isPRReps
        isPR1RM
        performedAt
      }
      prsAchieved {
        exerciseId
        prType
        newValue
      }
    }
  }
`,Z_=p`
  mutation UpdateSet($input: UpdateSetInput!) {
    updateSet(input: $input) {
      id
      exerciseId
      exerciseName
      setNumber
      reps
      weightKg
      rpe
      tu
      isPRWeight
      isPRReps
      isPR1RM
      performedAt
    }
  }
`,e1=p`
  mutation DeleteSet($setId: ID!) {
    deleteSet(setId: $setId)
  }
`,t1=p`
  mutation PauseWorkoutSession($sessionId: ID!) {
    pauseWorkoutSession(sessionId: $sessionId) {
      id
      pausedAt
      totalPausedTime
    }
  }
`,n1=p`
  mutation ResumeWorkoutSession($sessionId: ID!) {
    resumeWorkoutSession(sessionId: $sessionId) {
      id
      pausedAt
      totalPausedTime
    }
  }
`,s1=p`
  mutation CompleteWorkoutSession($input: CompleteWorkoutSessionInput!) {
    completeWorkoutSession(input: $input) {
      workout {
        id
        userId
      }
      session {
        id
      }
      totalTU
      totalVolume
      totalSets
      totalReps
      duration
      creditsCharged
      xpEarned
      levelUp
    }
  }
`,r1=p`
  mutation AbandonWorkoutSession($sessionId: ID!, $reason: String) {
    abandonWorkoutSession(sessionId: $sessionId, reason: $reason)
  }
`,i1=p`
  mutation RecoverWorkoutSession($archivedSessionId: ID!) {
    recoverWorkoutSession(archivedSessionId: $archivedSessionId) {
      id
      userId
      startedAt
      currentExerciseIndex
      currentSetIndex
      totalVolume
      totalReps
      estimatedCalories
    }
  }
`,a1=p`
  mutation CreateConversation($type: String!, $participantIds: [ID!]!) {
    createConversation(type: $type, participantIds: $participantIds) {
      id
      type
      name
      participants {
        userId
        username
        displayName
        avatarUrl
      }
      createdAt
    }
  }
`,o1=p`
  mutation SendMessage($conversationId: ID!, $content: String!, $replyToId: ID) {
    sendMessage(conversationId: $conversationId, content: $content, replyToId: $replyToId) {
      id
      conversationId
      senderId
      content
      replyTo {
        id
        content
        senderName
      }
      createdAt
    }
  }
`,c1=p`
  mutation EditMessage($messageId: ID!, $content: String!) {
    editMessage(messageId: $messageId, content: $content) {
      id
      content
      editedAt
      editCount
    }
  }
`,l1=p`
  mutation MarkConversationRead($conversationId: ID!) {
    markConversationRead(conversationId: $conversationId)
  }
`,u1=p`
  mutation DeleteMessage($messageId: ID!) {
    deleteMessage(messageId: $messageId)
  }
`,d1=p`
  mutation PinMessage($messageId: ID!) {
    pinMessage(messageId: $messageId) {
      id
      pinnedAt
    }
  }
`,m1=p`
  mutation UnpinMessage($messageId: ID!) {
    unpinMessage(messageId: $messageId)
  }
`,h1=p`
  mutation AddReaction($messageId: ID!, $emoji: String!) {
    addReaction(messageId: $messageId, emoji: $emoji) {
      id
      emoji
    }
  }
`,p1=p`
  mutation RemoveReaction($messageId: ID!, $emoji: String!) {
    removeReaction(messageId: $messageId, emoji: $emoji)
  }
`,f1=p`
  mutation SetTypingStatus($conversationId: ID!, $isTyping: Boolean!) {
    setTypingStatus(conversationId: $conversationId, isTyping: $isTyping)
  }
`,g1=p`
  mutation StarConversation($conversationId: ID!) {
    starConversation(conversationId: $conversationId)
  }
`,y1=p`
  mutation UnstarConversation($conversationId: ID!) {
    unstarConversation(conversationId: $conversationId)
  }
`,v1=p`
  mutation ArchiveConversation($conversationId: ID!) {
    archiveConversation(conversationId: $conversationId)
  }
`,S1=p`
  mutation UnarchiveConversation($conversationId: ID!) {
    unarchiveConversation(conversationId: $conversationId)
  }
`,T1=p`
  mutation ForwardMessage($messageId: ID!, $toConversationIds: [ID!]!, $addComment: String) {
    forwardMessage(messageId: $messageId, toConversationIds: $toConversationIds, addComment: $addComment) {
      id
      content
      createdAt
    }
  }
`,b1=p`
  mutation SetDisappearingMessages($conversationId: ID!, $ttl: Int) {
    setDisappearingMessages(conversationId: $conversationId, ttl: $ttl)
  }
`,w1=p`
  mutation ScheduleMessage($conversationId: ID!, $content: String!, $scheduledFor: String!) {
    scheduleMessage(conversationId: $conversationId, content: $content, scheduledFor: $scheduledFor) {
      id
      content
      scheduledFor
      status
    }
  }
`,I1=p`
  mutation CancelScheduledMessage($scheduledId: ID!) {
    cancelScheduledMessage(scheduledId: $scheduledId)
  }
`,x1=p`
  mutation CreateMessageTemplate($name: String!, $content: String!, $shortcut: String) {
    createMessageTemplate(name: $name, content: $content, shortcut: $shortcut) {
      id
      name
      content
      shortcut
    }
  }
`,E1=p`
  mutation BlockUser($userId: ID!) {
    blockUser(userId: $userId)
  }
`,A1=p`
  mutation UnblockUser($userId: ID!) {
    unblockUser(userId: $userId)
  }
`,_1=p`
  mutation CreateIssue($input: IssueInput!) {
    createIssue(input: $input) {
      id
      issueNumber
      title
      description
      type
      status
      priority
      labels {
        id
        name
        color
        icon
      }
      createdAt
    }
  }
`;p`
  mutation UpdateIssue($id: ID!, $input: IssueUpdateInput!) {
    updateIssue(id: $id, input: $input) {
      id
      title
      description
      status
      priority
      labels
      updatedAt
    }
  }
`;const C1=p`
  mutation VoteOnIssue($issueId: ID!, $vote: Int!) {
    voteOnIssue(issueId: $issueId, vote: $vote) {
      id
      voteCount
      hasVoted
    }
  }
`;p`
  mutation CreateIssueComment($issueId: ID!, $content: String!) {
    createIssueComment(issueId: $issueId, content: $content) {
      id
      content
      author {
        id
        username
        avatar
      }
      createdAt
    }
  }
`;p`
  mutation SubscribeToIssue($issueId: ID!) {
    subscribeToIssue(issueId: $issueId)
  }
`;p`
  mutation CreateRoadmapItem($input: RoadmapInput!) {
    createRoadmapItem(input: $input) {
      id
      title
      description
      status
      quarter
      priority
    }
  }
`;const k1=p`
  mutation VoteOnRoadmapItem($itemId: ID!) {
    voteOnRoadmapItem(itemId: $itemId) {
      id
      voteCount
      hasVoted
    }
  }
`;p`
  mutation LogSkillPractice($input: SkillPracticeInput!) {
    logSkillPractice(input: $input) {
      id
      skillNodeId
      durationMinutes
      valueAchieved
      notes
      createdAt
    }
  }
`;const R1=p`
  mutation LogSkillPractice($input: SkillPracticeInput!) {
    logSkillPractice(input: $input) {
      id
      skillNodeId
      durationMinutes
      valueAchieved
      notes
      createdAt
    }
  }
`,P1=p`
  mutation AchieveSkill($skillNodeId: ID!) {
    achieveSkill(skillNodeId: $skillNodeId) {
      success
      error
      xpAwarded
      creditsAwarded
    }
  }
`,M1=p`
  mutation PracticeMartialArt($input: TechniquePracticeInput!) {
    practiceMartialArt(input: $input) {
      id
      userId
      techniqueId
      techniqueName
      disciplineName
      practiceDate
      durationMinutes
      repsPerformed
      roundsPerformed
      partnerDrill
      notes
      createdAt
    }
  }
`,O1=p`
  mutation MasterMartialArt($techniqueId: ID!) {
    masterMartialArt(techniqueId: $techniqueId) {
      success
      creditsAwarded
      xpAwarded
      error
    }
  }
`;p`
  mutation UpdateMartialArtNotes($techniqueId: ID!, $notes: String!) {
    updateMartialArtNotes(techniqueId: $techniqueId, notes: $notes)
  }
`;const N1=p`
  mutation GeneratePrescription($input: PrescriptionInput!) {
    generatePrescription(input: $input) {
      id
      userId
      exercises {
        exerciseId
        name
        sets
        reps
        restSeconds
        notes
        primaryMuscles
      }
      warmup {
        exerciseId
        name
        sets
        reps
        restSeconds
        notes
      }
      cooldown {
        exerciseId
        name
        sets
        reps
        restSeconds
        notes
      }
      muscleCoverage
      difficulty
      targetDuration
      actualDuration
      createdAt
    }
  }
`,$1=p`
  mutation CreateWorkoutTemplate($input: CreateWorkoutTemplateInput!) {
    createWorkoutTemplate(input: $input) {
      id
      name
      description
      exercises {
        exerciseId
        name
        sets
        reps
        weight
        duration
        restSeconds
        notes
      }
      difficulty
      durationMinutes
      targetMuscles
      equipmentRequired
      category
      tags
      isPublic
      createdAt
    }
  }
`,D1=p`
  mutation UpdateWorkoutTemplate($id: ID!, $input: UpdateWorkoutTemplateInput!) {
    updateWorkoutTemplate(id: $id, input: $input) {
      id
      name
      description
      exercises {
        exerciseId
        name
        sets
        reps
        weight
        duration
        restSeconds
        notes
      }
      difficulty
      durationMinutes
      targetMuscles
      equipmentRequired
      category
      tags
      isPublic
      updatedAt
    }
  }
`,j1=p`
  mutation DeleteWorkoutTemplate($id: ID!) {
    deleteWorkoutTemplate(id: $id)
  }
`,L1=p`
  mutation CloneWorkoutTemplate($id: ID!) {
    cloneWorkoutTemplate(id: $id) {
      id
      name
      description
      exercises {
        exerciseId
        name
        sets
        reps
        weight
        duration
        restSeconds
        notes
      }
      difficulty
      durationMinutes
      targetMuscles
      equipmentRequired
      category
      tags
      isPublic
      forkedFromId
      createdAt
    }
  }
`;p`
  mutation RateWorkoutTemplate($id: ID!, $rating: Int!) {
    rateWorkoutTemplate(id: $id, rating: $rating) {
      id
      averageRating
      ratingCount
      userRating
    }
  }
`;const U1=p`
  mutation SaveWorkoutTemplate($id: ID!) {
    saveWorkoutTemplate(id: $id)
  }
`,V1=p`
  mutation UnsaveWorkoutTemplate($id: ID!) {
    unsaveWorkoutTemplate(id: $id)
  }
`,B1=p`
  mutation JoinCompetition($competitionId: ID!) {
    joinCompetition(competitionId: $competitionId) {
      success
      message
      entry {
        id
        competitionId
        userId
        rank
        score
        joinedAt
      }
    }
  }
`,F1=p`
  mutation CreateCompetition($input: CompetitionInput!) {
    createCompetition(input: $input) {
      id
      name
      description
      type
      status
      startDate
      endDate
      participantCount
      goalTu
      hasJoined
      createdAt
    }
  }
`,q1=p`
  mutation ChallengeRival($opponentId: ID!) {
    challengeRival(opponentId: $opponentId) {
      id
      challengerId
      challengedId
      status
      createdAt
      opponent {
        id
        username
        avatar
        archetype
        level
      }
      isChallenger
      myTU
      opponentTU
    }
  }
`,W1=p`
  mutation AcceptRivalry($rivalryId: ID!) {
    acceptRivalry(rivalryId: $rivalryId) {
      id
      status
      startedAt
      opponent {
        id
        username
        avatar
      }
      isChallenger
      myTU
      opponentTU
    }
  }
`,z1=p`
  mutation DeclineRivalry($rivalryId: ID!) {
    declineRivalry(rivalryId: $rivalryId)
  }
`,H1=p`
  mutation EndRivalry($rivalryId: ID!) {
    endRivalry(rivalryId: $rivalryId)
  }
`,G1=p`
  mutation CreateCrew($input: CreateCrewInput!) {
    createCrew(input: $input) {
      id
      name
      tag
      description
      avatar
      color
      ownerId
      memberCount
      totalTU
      weeklyTU
      wins
      losses
      createdAt
    }
  }
`,Y1=p`
  mutation LeaveCrew {
    leaveCrew
  }
`;p`
  mutation JoinCrew($crewId: ID!) {
    joinCrew(crewId: $crewId) {
      id
      crewId
      userId
      role
      joinedAt
      weeklyTU
      totalTU
      username
      avatar
      archetype
    }
  }
`;p`
  mutation InviteToCrew($crewId: ID!, $inviteeId: ID!) {
    inviteToCrew(crewId: $crewId, inviteeId: $inviteeId) {
      id
      crewId
      inviterId
      inviteeId
      status
      createdAt
      expiresAt
    }
  }
`;p`
  mutation AcceptCrewInvite($inviteId: ID!) {
    acceptCrewInvite(inviteId: $inviteId) {
      id
      crewId
      userId
      role
      joinedAt
      weeklyTU
      totalTU
      username
      avatar
      archetype
    }
  }
`;p`
  mutation StartCrewWar($crewId: ID!, $defendingCrewId: ID!, $durationDays: Int) {
    startCrewWar(crewId: $crewId, defendingCrewId: $defendingCrewId, durationDays: $durationDays) {
      id
      challengerCrewId
      defendingCrewId
      status
      startDate
      endDate
      challengerTU
      defendingTU
      winnerId
      createdAt
    }
  }
`;const K1=p`
  mutation UpsertTrainerProfile($input: TrainerProfileInput!) {
    upsertTrainerProfile(input: $input) {
      userId
      displayName
      bio
      specialties
      certifications
      hourlyRateCredits
      perClassRateCredits
      verified
      verifiedAt
      ratingAvg
      ratingCount
      totalClassesTaught
      totalStudentsTrained
      totalCreditsEarned
      status
      createdAt
    }
  }
`;p`
  mutation UpdateTrainerStatus($status: String!) {
    updateTrainerStatus(status: $status)
  }
`;const Q1=p`
  mutation CreateTrainerClass($input: CreateTrainerClassInput!) {
    createTrainerClass(input: $input) {
      id
      trainerUserId
      title
      description
      category
      difficulty
      startAt
      durationMinutes
      locationType
      locationDetails
      capacity
      enrolledCount
      creditsPerStudent
      trainerWagePerStudent
      status
      createdAt
    }
  }
`;p`
  mutation UpdateTrainerClass($classId: ID!, $input: UpdateTrainerClassInput!) {
    updateTrainerClass(classId: $classId, input: $input) {
      id
      trainerUserId
      title
      description
      category
      difficulty
      startAt
      durationMinutes
      locationType
      locationDetails
      capacity
      enrolledCount
      creditsPerStudent
      trainerWagePerStudent
      status
      createdAt
    }
  }
`;p`
  mutation CancelTrainerClass($classId: ID!, $reason: String) {
    cancelTrainerClass(classId: $classId, reason: $reason)
  }
`;const J1=p`
  mutation EnrollInClass($classId: ID!) {
    enrollInClass(classId: $classId) {
      id
      classId
      userId
      status
      creditsPaid
      enrolledAt
    }
  }
`,X1=p`
  mutation UnenrollFromClass($classId: ID!) {
    unenrollFromClass(classId: $classId)
  }
`;p`
  mutation MarkClassAttendance($classId: ID!, $attendees: [AttendeeInput!]!) {
    markClassAttendance(classId: $classId, attendees: $attendees) {
      attendeeCount
      wageEarned
    }
  }
`;const Z1=p`
  mutation CreateCareerGoal($input: CareerGoalInput!) {
    createCareerGoal(input: $input) {
      id
      standard {
        id
        name
        fullName
        agency
        category
        icon
      }
      standardId
      targetDate
      priority
      status
      agencyName
      notes
      readiness {
        score
        status
        eventsPassed
        eventsTotal
      }
      daysRemaining
      createdAt
    }
  }
`;p`
  mutation UpdateCareerGoal($goalId: ID!, $input: CareerGoalUpdateInput!) {
    updateCareerGoal(goalId: $goalId, input: $input) {
      id
      targetDate
      priority
      status
      agencyName
      notes
      updatedAt
    }
  }
`;const eC=p`
  mutation DeleteCareerGoal($goalId: ID!) {
    deleteCareerGoal(goalId: $goalId)
  }
`;p`
  mutation LogCareerAssessment($input: CareerAssessmentInput!) {
    logCareerAssessment(input: $input) {
      id
      goalId
      standardId
      assessmentType
      results
      totalScore
      passed
      assessedAt
      createdAt
    }
  }
`;p`
  mutation UpdateTrainerProfile($input: TrainerProfileInput!) {
    updateTrainerProfile(input: $input) {
      id
      name
      bio
      specialties
      hourlyRate
      available
    }
  }
`;p`
  mutation CreateClass($input: ClassInput!) {
    createClass(input: $input) {
      id
      name
      description
      type
      duration
      maxParticipants
      scheduledAt
      price
    }
  }
`;p`
  mutation CreateBuddy($input: CreateBuddyInput!) {
    createBuddy(input: $input) {
      userId
      species
      nickname
      level
      xp
      xpToNextLevel
      stage
      stageName
    }
  }
`;p`
  mutation UpdateBuddySpecies($species: String!) {
    updateBuddySpecies(species: $species) {
      userId
      species
      nickname
      level
      stage
      stageName
    }
  }
`;p`
  mutation UpdateBuddyNickname($nickname: String) {
    updateBuddyNickname(nickname: $nickname)
  }
`;p`
  mutation UpdateBuddySettings($input: BuddySettingsInput!) {
    updateBuddySettings(input: $input)
  }
`;p`
  mutation FeedBuddy($xpAmount: Int!) {
    feedBuddy(xpAmount: $xpAmount) {
      newXp
      newLevel
      leveledUp
      newStage
      evolved
    }
  }
`;p`
  mutation EquipBuddyCosmetic($sku: String!, $slot: String!) {
    equipBuddyCosmetic(sku: $sku, slot: $slot)
  }
`;p`
  mutation UnequipBuddyCosmetic($slot: String!) {
    unequipBuddyCosmetic(slot: $slot)
  }
`;const tC=p`
  mutation ToggleFavorite($itemId: ID!) {
    toggleFavorite(itemId: $itemId) {
      id
      isFavorite
    }
  }
`,nC=p`
  mutation MarkItemSeen($itemId: ID!) {
    markItemSeen(itemId: $itemId) {
      success
    }
  }
`,sC=p`
  mutation MarkAllSeen {
    markAllSeen {
      success
    }
  }
`,rC=p`
  mutation ClaimSetReward($setId: ID!, $threshold: Float!) {
    claimSetReward(setId: $setId, threshold: $threshold) {
      success
      reward {
        type
        value
        description
      }
    }
  }
`;p`
  mutation CreateListing($input: ListingInput!) {
    createListing(input: $input) {
      id
      item {
        id
        name
      }
      price
      status
      createdAt
    }
  }
`;const iC=p`
  mutation PurchaseListing($listingId: ID!) {
    purchaseListing(listingId: $listingId) {
      success
      newBalance
      message
    }
  }
`,aC=p`
  mutation MakeOffer($listingId: ID!, $amount: Int!, $message: String) {
    makeOffer(listingId: $listingId, amount: $amount, message: $message) {
      success
      offerId
      message
    }
  }
`,oC=p`
  mutation AddToWatchlist($listingId: ID!) {
    addToWatchlist(listingId: $listingId) {
      success
    }
  }
`,cC=p`
  mutation RemoveFromWatchlist($listingId: ID!) {
    removeFromWatchlist(listingId: $listingId) {
      success
    }
  }
`,lC=p`
  mutation CreateTrade($input: CreateTradeInput!) {
    createTrade(input: $input) {
      success
      trade {
        id
        initiatorId
        initiatorUsername
        receiverId
        receiverUsername
        initiatorItems {
          id
          name
          rarity
          icon
        }
        initiatorCredits
        receiverItems {
          id
          name
          rarity
          icon
        }
        receiverCredits
        status
        message
        createdAt
      }
      valueWarning
      message
    }
  }
`,uC=p`
  mutation AcceptTrade($tradeId: ID!) {
    acceptTrade(tradeId: $tradeId) {
      success
      trade {
        id
        status
      }
      message
    }
  }
`,dC=p`
  mutation RejectTrade($tradeId: ID!) {
    rejectTrade(tradeId: $tradeId) {
      success
      trade {
        id
        status
      }
      message
    }
  }
`,mC=p`
  mutation CancelTrade($tradeId: ID!) {
    cancelTrade(tradeId: $tradeId) {
      success
      trade {
        id
        status
      }
      message
    }
  }
`,hC=p`
  mutation CancelVerification($verificationId: ID!) {
    cancelVerification(verificationId: $verificationId)
  }
`,pC=p`
  mutation OpenMysteryBox($boxId: ID!, $quantity: Int) {
    openMysteryBox(boxId: $boxId, quantity: $quantity) {
      success
      results {
        cosmeticId
        cosmeticName
        rarity
        previewUrl
        wasPityReward
        isDuplicate
        refundAmount
      }
      newBalance
    }
  }
`,fC=p`
  mutation PurchaseSkin($skinId: ID!) {
    purchaseSkin(skinId: $skinId) {
      success
      skin {
        id
        name
      }
      newBalance
      message
    }
  }
`,gC=p`
  mutation EquipSkin($skinId: ID!) {
    equipSkin(skinId: $skinId) {
      success
      message
    }
  }
`,yC=p`
  mutation UnequipSkin($skinId: ID!) {
    unequipSkin(skinId: $skinId) {
      success
      message
    }
  }
`;p`
  mutation SubmitFeedback($input: FeedbackInput!) {
    submitFeedback(input: $input) {
      id
      type
      message
      status
      createdAt
    }
  }
`;p`
  mutation AdminAdjustCredits($userId: ID!, $amount: Int!, $reason: String!) {
    adminAdjustCredits(userId: $userId, amount: $amount, reason: $reason) {
      success
      newBalance
    }
  }
`;p`
  mutation AdminBanUser($userId: ID!, $reason: String!, $duration: Int) {
    adminBanUser(userId: $userId, reason: $reason, duration: $duration) {
      success
    }
  }
`;p`
  mutation AdminGrantAchievement($userId: ID!, $achievementId: ID!) {
    adminGrantAchievement(userId: $userId, achievementId: $achievementId) {
      success
    }
  }
`;p`
  mutation AdminBulkUpdateIssues($issueIds: [ID!]!, $status: String!) {
    adminBulkUpdateIssues(issueIds: $issueIds, status: $status) {
      id
      status
    }
  }
`;p`
  mutation UpdatePresence($status: String!) {
    updatePresence(status: $status) {
      activeUsers
      workoutsInProgress
    }
  }
`;const vC=p`
  mutation LogSleep($input: SleepLogInput!) {
    logSleep(input: $input) {
      id
      bedTime
      wakeTime
      sleepDurationMinutes
      quality
      notes
      factors {
        lateExercise
        lateFood
        screenBeforeBed
        caffeineAfter6pm
        alcoholConsumed
      }
      sleepDebt
      createdAt
    }
  }
`;p`
  mutation UpdateSleepLog($id: ID!, $input: SleepLogInput!) {
    updateSleepLog(id: $id, input: $input) {
      id
      bedTime
      wakeTime
      sleepDurationMinutes
      quality
      notes
    }
  }
`;p`
  mutation DeleteSleepLog($id: ID!) {
    deleteSleepLog(id: $id)
  }
`;p`
  mutation UpdateSleepGoal($input: SleepGoalInput!) {
    updateSleepGoal(input: $input) {
      id
      targetHours
      targetBedTime
      targetWakeTime
      reminderEnabled
      reminderMinutesBefore
    }
  }
`;const SC=p`
  mutation AcknowledgeRecoveryRecommendation($recommendationId: ID!, $followed: Boolean, $feedback: String) {
    acknowledgeRecoveryRecommendation(recommendationId: $recommendationId, followed: $followed, feedback: $feedback)
  }
`,TC=p`
  mutation CreateBodyMeasurement($input: BodyMeasurementInput!) {
    createBodyMeasurement(input: $input) {
      id
      userId
      weightKg
      bodyFatPercentage
      leanMassKg
      neckCm
      shouldersCm
      chestCm
      waistCm
      hipsCm
      leftBicepCm
      rightBicepCm
      leftForearmCm
      rightForearmCm
      leftThighCm
      rightThighCm
      leftCalfCm
      rightCalfCm
      measurementSource
      notes
      measurementDate
      createdAt
    }
  }
`,bC=p`
  mutation UpdateBodyMeasurement($id: ID!, $input: BodyMeasurementInput!) {
    updateBodyMeasurement(id: $id, input: $input) {
      id
      userId
      weightKg
      bodyFatPercentage
      leanMassKg
      neckCm
      shouldersCm
      chestCm
      waistCm
      hipsCm
      leftBicepCm
      rightBicepCm
      leftForearmCm
      rightForearmCm
      leftThighCm
      rightThighCm
      leftCalfCm
      rightCalfCm
      measurementSource
      notes
      measurementDate
      createdAt
    }
  }
`,wC=p`
  mutation DeleteBodyMeasurement($id: ID!) {
    deleteBodyMeasurement(id: $id)
  }
`,IC=p`
  mutation RecalculateStats {
    recalculateStats {
      userId
      level
      xp
      xpToNextLevel
      strength
      endurance
      agility
      flexibility
      balance
      mentalFocus
      totalWorkouts
      totalExercises
      currentStreak
      longestStreak
      lastWorkoutAt
    }
  }
`,xC=p`
  mutation UpdateSettings($input: UserSettingsInput!) {
    updateSettings(input: $input) {
      theme
      reducedMotion
      highContrast
      textSize
      isPublic
      showLocation
      showProgress
      equipment
    }
  }
`,EC=p`
  mutation UpdateMessagingPrivacy($enabled: Boolean!) {
    updateMessagingPrivacy(enabled: $enabled) {
      messagingEnabled
    }
  }
`,AC=p`
  mutation CompleteOnboarding {
    completeOnboarding {
      success
      message
    }
  }
`,_C=p`
  mutation UpdateMyFullProfile($input: FullProfileInput!) {
    updateMyFullProfile(input: $input) {
      id
      username
      displayName
      avatarUrl
      avatarId
      xp
      level
      rank
      wealthTier
      age
      gender
      heightCm
      weightKg
      preferredUnits
      ghostMode
      leaderboardOptIn
      aboutMe
      limitations
      equipmentInventory
      weeklyActivity
      theme
    }
  }
`,CC=p`
  mutation SendHighFive($input: HighFiveInput!) {
    sendHighFive(input: $input) {
      success
      error
    }
  }
`,kC=p`
  mutation TransferCreditsByUsername($input: TransferByUsernameInput!) {
    transferCreditsByUsername(input: $input) {
      success
      error
      transactionId
      amount
      fee
      newBalance
      recipientUsername
    }
  }
`,RC=p`
  mutation CreateLimitation($input: LimitationInput!) {
    createLimitation(input: $input) {
      id
      userId
      bodyRegionId
      bodyRegionName
      limitationType
      severity
      status
      name
      description
      medicalNotes
      avoidMovements
      avoidImpact
      avoidWeightBearing
      maxWeightLbs
      maxReps
      onsetDate
      expectedRecoveryDate
      diagnosedBy
      ptApproved
      createdAt
    }
  }
`,PC=p`
  mutation UpdateLimitation($id: ID!, $input: LimitationInput!) {
    updateLimitation(id: $id, input: $input) {
      id
      userId
      bodyRegionId
      bodyRegionName
      limitationType
      severity
      status
      name
      description
      medicalNotes
      avoidMovements
      avoidImpact
      avoidWeightBearing
      maxWeightLbs
      maxReps
      onsetDate
      expectedRecoveryDate
      diagnosedBy
      ptApproved
      createdAt
      updatedAt
    }
  }
`,MC=p`
  mutation DeleteLimitation($id: ID!) {
    deleteLimitation(id: $id)
  }
`,OC=p`
  mutation RecordPTTestResult($input: PTTestResultInput!) {
    recordPTTestResult(input: $input) {
      id
      totalScore
      passed
      category
    }
  }
`,NC=p`
  mutation CreateProgressPhoto($input: ProgressPhotoInput!) {
    createProgressPhoto(input: $input) {
      id
      userId
      storagePath
      thumbnailPath
      photoType
      pose
      isPrivate
      weightKg
      bodyFatPercentage
      notes
      photoDate
      createdAt
    }
  }
`;p`
  mutation UpdateProgressPhoto($id: ID!, $input: ProgressPhotoUpdateInput!) {
    updateProgressPhoto(id: $id, input: $input) {
      id
      userId
      storagePath
      thumbnailPath
      photoType
      pose
      isPrivate
      weightKg
      bodyFatPercentage
      notes
      photoDate
      createdAt
    }
  }
`;const $C=p`
  mutation DeleteProgressPhoto($id: ID!) {
    deleteProgressPhoto(id: $id)
  }
`,DC=p`
  mutation SyncWearables {
    syncWearables {
      success
      message
      lastSyncAt
    }
  }
`;p`
  mutation CreateProgressionTarget($input: ProgressionTargetInput!) {
    createProgressionTarget(input: $input) {
      id
      exerciseId
      exerciseName
      targetType
      currentValue
      targetValue
      incrementValue
      incrementFrequency
      targetDate
      status
      progress
      createdAt
    }
  }
`;p`
  mutation UpdateProgressionTarget($id: ID!, $currentValue: Float!) {
    updateProgressionTarget(id: $id, currentValue: $currentValue) {
      id
      exerciseId
      exerciseName
      targetType
      currentValue
      targetValue
      status
      progress
      completedAt
    }
  }
`;const jC=p`
  mutation CreateLocation($input: LocationInput!) {
    createLocation(input: $input) {
      id
      name
      type
      city
      description
      lat
      lng
      createdAt
    }
  }
`,LC=p`
  mutation RateLocation($locationId: ID!, $input: LocationRatingInput!) {
    rateLocation(locationId: $locationId, input: $input) {
      id
      locationId
      rating
      safetyRating
      crowdLevel
      cleanliness
      comment
      createdAt
    }
  }
`,UC=p`
  mutation VoteLocationComment($commentId: ID!, $vote: Int!) {
    voteLocationComment(commentId: $commentId, vote: $vote) {
      id
      userId
      username
      comment
      upvotes
      createdAt
    }
  }
`,$h=p`
  mutation UpdateMascotNickname($nickname: String!) {
    updateMascotNickname(nickname: $nickname) {
      id
      nickname
      stage
      xp
      isVisible
      isMinimized
      soundsEnabled
      tipsEnabled
    }
  }
`,Dh=p`
  mutation UpdateMascotSettings($input: MascotSettingsInput!) {
    updateMascotSettings(input: $input) {
      id
      nickname
      stage
      xp
      isVisible
      isMinimized
      soundsEnabled
      tipsEnabled
    }
  }
`,jh=p`
  mutation PurchaseMascotCosmetic($cosmeticId: ID!) {
    purchaseMascotCosmetic(cosmeticId: $cosmeticId) {
      success
      error
      cosmetic {
        id
        itemKey
        name
        slot
        rarity
        price
      }
      newBalance
    }
  }
`,Lh=p`
  mutation EquipMascotCosmetic($cosmeticId: ID!, $slot: String!) {
    equipMascotCosmetic(cosmeticId: $cosmeticId, slot: $slot) {
      skin { id itemKey name slot assetUrl }
      eyes { id itemKey name slot assetUrl }
      outfit { id itemKey name slot assetUrl }
      accessory { id itemKey name slot assetUrl }
      aura { id itemKey name slot assetUrl }
      trail { id itemKey name slot assetUrl }
      emoteVictory { id itemKey name slot assetUrl }
      emoteDefeat { id itemKey name slot assetUrl }
      emoteIdle { id itemKey name slot assetUrl }
    }
  }
`;p`
  mutation UnequipMascotCosmetic($slot: String!) {
    unequipMascotCosmetic(slot: $slot) {
      skin { id itemKey name slot assetUrl }
      eyes { id itemKey name slot assetUrl }
      outfit { id itemKey name slot assetUrl }
      accessory { id itemKey name slot assetUrl }
      aura { id itemKey name slot assetUrl }
      trail { id itemKey name slot assetUrl }
      emoteVictory { id itemKey name slot assetUrl }
      emoteDefeat { id itemKey name slot assetUrl }
      emoteIdle { id itemKey name slot assetUrl }
    }
  }
`;const Uh=p`
  mutation MarkMascotReactionsSeen($reactionIds: [ID!]!) {
    markMascotReactionsSeen(reactionIds: $reactionIds)
  }
`,qc={},{useDebugValue:Vh}=$e,{useSyncExternalStoreWithSelector:Bh}=$d;let ya=!1;const Fh=e=>e;function qh(e,t=Fh,n){(qc?"production":void 0)!=="production"&&n&&!ya&&(ya=!0);const s=Bh(e.subscribe,e.getState,e.getServerState||e.getInitialState,t,n);return Vh(s),s}const va=e=>{const t=typeof e=="function"?Nd(e):e,n=(s,i)=>qh(t,s,i);return Object.assign(n,t),n},ht=e=>e?va(e):va,Wh={},zh=e=>(t,n,s)=>{const i=s.subscribe;return s.subscribe=(o,l,u)=>{let d=o;if(l){const h=u?.equalityFn||Object.is;let f=o(s.getState());d=g=>{const y=o(g);if(!h(f,y)){const v=f;l(f=y,v)}},u?.fireImmediately&&l(f,f)}return i(d)},e(t,n,s)},wn=zh;function ln(e,t){let n;try{n=e()}catch{return}return{getItem:i=>{var a;const o=u=>u===null?null:JSON.parse(u,void 0),l=(a=n.getItem(i))!=null?a:null;return l instanceof Promise?l.then(o):o(l)},setItem:(i,a)=>n.setItem(i,JSON.stringify(a,void 0)),removeItem:i=>n.removeItem(i)}}const un=e=>t=>{try{const n=e(t);return n instanceof Promise?n:{then(s){return un(s)(n)},catch(s){return this}}}catch(n){return{then(s){return this},catch(s){return un(s)(n)}}}},Hh=(e,t)=>(n,s,i)=>{let a={getStorage:()=>localStorage,serialize:JSON.stringify,deserialize:JSON.parse,partialize:b=>b,version:0,merge:(b,I)=>({...I,...b}),...t},o=!1;const l=new Set,u=new Set;let d;try{d=a.getStorage()}catch{}if(!d)return e((...b)=>{n(...b)},s,i);const h=un(a.serialize),f=()=>{const b=a.partialize({...s()});let I;const x=h({state:b,version:a.version}).then(w=>d.setItem(a.name,w)).catch(w=>{I=w});if(I)throw I;return x},g=i.setState;i.setState=(b,I)=>{g(b,I),f()};const y=e((...b)=>{n(...b),f()},s,i);let v;const T=()=>{var b;if(!d)return;o=!1,l.forEach(x=>x(s()));const I=((b=a.onRehydrateStorage)==null?void 0:b.call(a,s()))||void 0;return un(d.getItem.bind(d))(a.name).then(x=>{if(x)return a.deserialize(x)}).then(x=>{if(x)if(typeof x.version=="number"&&x.version!==a.version){if(a.migrate)return a.migrate(x.state,x.version)}else return x.state}).then(x=>{var w;return v=a.merge(x,(w=s())!=null?w:y),n(v,!0),f()}).then(()=>{I?.(v,void 0),o=!0,u.forEach(x=>x(v))}).catch(x=>{I?.(void 0,x)})};return i.persist={setOptions:b=>{a={...a,...b},b.getStorage&&(d=b.getStorage())},clearStorage:()=>{d?.removeItem(a.name)},getOptions:()=>a,rehydrate:()=>T(),hasHydrated:()=>o,onHydrate:b=>(l.add(b),()=>{l.delete(b)}),onFinishHydration:b=>(u.add(b),()=>{u.delete(b)})},T(),v||y},Gh=(e,t)=>(n,s,i)=>{let a={storage:ln(()=>localStorage),partialize:T=>T,version:0,merge:(T,b)=>({...b,...T}),...t},o=!1;const l=new Set,u=new Set;let d=a.storage;if(!d)return e((...T)=>{n(...T)},s,i);const h=()=>{const T=a.partialize({...s()});return d.setItem(a.name,{state:T,version:a.version})},f=i.setState;i.setState=(T,b)=>{f(T,b),h()};const g=e((...T)=>{n(...T),h()},s,i);i.getInitialState=()=>g;let y;const v=()=>{var T,b;if(!d)return;o=!1,l.forEach(x=>{var w;return x((w=s())!=null?w:g)});const I=((b=a.onRehydrateStorage)==null?void 0:b.call(a,(T=s())!=null?T:g))||void 0;return un(d.getItem.bind(d))(a.name).then(x=>{if(x)if(typeof x.version=="number"&&x.version!==a.version){if(a.migrate)return[!0,a.migrate(x.state,x.version)]}else return[!1,x.state];return[!1,void 0]}).then(x=>{var w;const[_,A]=x;if(y=a.merge(A,(w=s())!=null?w:g),n(y,!0),_)return h()}).then(()=>{I?.(y,void 0),y=s(),o=!0,u.forEach(x=>x(y))}).catch(x=>{I?.(void 0,x)})};return i.persist={setOptions:T=>{a={...a,...T},T.storage&&(d=T.storage)},clearStorage:()=>{d?.removeItem(a.name)},getOptions:()=>a,rehydrate:()=>v(),hasHydrated:()=>o,onHydrate:T=>(l.add(T),()=>{l.delete(T)}),onFinishHydration:T=>(u.add(T),()=>{u.delete(T)})},a.skipHydration||v(),y||g},Yh=(e,t)=>"getStorage"in t||"serialize"in t||"deserialize"in t?Hh(e,t):Gh(e,t),Jr=Yh,ds={getItem:e=>{try{return de.getItem(e)}catch{return null}},setItem:(e,t)=>{try{de.setItem(e,t)}catch{}},removeItem:e=>{try{de.removeItem(e)}catch{}}};function Wc(){try{return de.getItem("musclemap_token")}catch{return null}}function Sa(e){try{de.setItem("musclemap_token",e)}catch{}}function Kh(){try{de.removeItem("musclemap_token")}catch{}}function Ta(e){try{de.setItem("musclemap_user",JSON.stringify(e))}catch{}}function Qh(){try{de.removeItem("musclemap_user")}catch{}}function Jh(){try{return ln(()=>ds)}catch{const t={},n={getItem:s=>t[s]??null,setItem:(s,i)=>{t[s]=i},removeItem:s=>{delete t[s]}};return ln(()=>n)}}const Ke=ht(Jr((e,t)=>({user:null,token:null,isAuthenticated:!1,loading:!0,_hasHydrated:!1,setHasHydrated:n=>e({_hasHydrated:n,loading:!1}),setAuth:(n,s)=>{Sa(s),Ta(n),e({user:n,token:s,isAuthenticated:!0,loading:!1})},updateUser:n=>e(s=>({user:s.user?{...s.user,...n}:null})),logout:async()=>{Kh(),Qh(),await Vc(),e({user:null,token:null,isAuthenticated:!1,loading:!1})},getAuthHeader:()=>{const n=t().token;return n?{Authorization:`Bearer ${n}`}:{}},checkAuth:()=>{const n=t();return n._hasHydrated&&n.isAuthenticated}}),{name:"musclemap-auth",storage:Jh(),partialize:e=>({user:e.user,token:e.token,isAuthenticated:e.isAuthenticated}),onRehydrateStorage:()=>(e,t)=>{t?ds.removeItem("musclemap-auth"):e?.token&&(Sa(e.token),e.user&&Ta(e.user)),setTimeout(()=>{Ke.getState().setHasHydrated(!0)},0)}}));typeof window<"u"&&(setTimeout(()=>{try{const e=Ke.getState();e._hasHydrated||e.setHasHydrated(!0)}catch{}},100),setTimeout(()=>{try{const e=Ke.getState();e._hasHydrated||e.setHasHydrated(!0)}catch{}},500),setTimeout(()=>{try{const e=Ke.getState();e._hasHydrated||e.setHasHydrated(!0)}catch{try{Ke.setState({_hasHydrated:!0,loading:!1})}catch{}}},2e3));function ms(){const e=Ke();return{user:e.user,token:e.token,isAuthenticated:e.isAuthenticated,loading:e.loading,hasHydrated:e._hasHydrated,login:e.setAuth,logout:e.logout,updateUser:e.updateUser,getAuthHeader:e.getAuthHeader}}function dn(){return Ke.getState().token}function VC(){const e=dn();return e?{Authorization:`Bearer ${e}`}:{}}const zc=m.createContext(null);function Xh({children:e}){const t=ms(),n={user:t.user,setUser:s=>Ke.getState().updateUser(s),login:t.login,logout:t.logout,loading:t.loading,isAuthenticated:t.isAuthenticated};return c.jsx(zc.Provider,{value:n,children:e})}function Zh(){const e=m.useContext(zc),t=ms();return e||{user:t.user,setUser:t.updateUser,login:t.login,logout:t.logout,loading:t.loading,isAuthenticated:t.isAuthenticated}}const se={DARK:"dark",LIGHT:"light",SYSTEM:"system"},ba={dark:{background:"#0a0a0f",backgroundSecondary:"#111118",surface:"rgba(255, 255, 255, 0.05)",surfaceHover:"rgba(255, 255, 255, 0.08)",border:"rgba(255, 255, 255, 0.1)",text:"#ffffff",textSecondary:"rgba(255, 255, 255, 0.7)",textMuted:"rgba(255, 255, 255, 0.5)",primary:"#0066FF",primaryHover:"#0052CC",accent:"#8B5CF6",success:"#22C55E",warning:"#F59E0B",error:"#EF4444"},light:{background:"#ffffff",backgroundSecondary:"#f8f9fa",surface:"rgba(0, 0, 0, 0.03)",surfaceHover:"rgba(0, 0, 0, 0.06)",border:"rgba(0, 0, 0, 0.1)",text:"#111111",textSecondary:"rgba(0, 0, 0, 0.7)",textMuted:"rgba(0, 0, 0, 0.5)",primary:"#0066FF",primaryHover:"#0052CC",accent:"#8B5CF6",success:"#22C55E",warning:"#F59E0B",error:"#EF4444"}},Hc="musclemap_theme",ep=m.createContext(null);function tp(){return typeof window>"u"||window.matchMedia("(prefers-color-scheme: dark)").matches?se.DARK:se.LIGHT}function np(){if(typeof window>"u")return se.DARK;try{const e=de.getItem(Hc);if(e&&Object.values(se).includes(e))return e}catch{}return se.DARK}function sp({children:e}){const[t,n]=m.useState(np),[s,i]=m.useState(tp),a=t===se.SYSTEM?s:t;m.useEffect(()=>{const d=window.matchMedia("(prefers-color-scheme: dark)"),h=f=>{i(f.matches?se.DARK:se.LIGHT)};return d.addEventListener("change",h),()=>d.removeEventListener("change",h)},[]),m.useEffect(()=>{const d=document.documentElement;d.classList.remove("theme-dark","theme-light"),d.classList.add(`theme-${a}`);const h=ba[a];Object.entries(h).forEach(([g,y])=>{d.style.setProperty(`--color-${g}`,y)});const f=document.querySelector('meta[name="theme-color"]');f&&f.setAttribute("content",h.background)},[a]),m.useEffect(()=>{try{de.setItem(Hc,t)}catch{}},[t]);const o=m.useCallback(d=>{Object.values(se).includes(d)&&n(d)},[]),l=m.useCallback(()=>{n(d=>d===se.DARK?se.LIGHT:d===se.LIGHT?se.DARK:s===se.DARK?se.LIGHT:se.DARK)},[s]),u=m.useMemo(()=>({theme:a,themeSetting:t,colors:ba[a],isDark:a===se.DARK,setTheme:o,toggleTheme:l,themeOptions:se}),[a,t,o,l]);return c.jsx(ep.Provider,{value:u,children:e})}const rp=(e,t,n)=>{const s=e[t];return s?typeof s=="function"?s():Promise.resolve(s):new Promise((i,a)=>{(typeof queueMicrotask=="function"?queueMicrotask:setTimeout)(a.bind(null,new Error("Unknown variable dynamic import: "+t+(t.split("/").length!==n?". Note that variables only represent file names one level deep.":""))))})},Qe={EN:"en",ES:"es",FR:"fr",DE:"de",PT:"pt",JA:"ja",ZH:"zh",KO:"ko"},Cs={en:{name:"English",nativeName:"English",dir:"ltr"},es:{name:"Spanish",nativeName:"Español",dir:"ltr"},fr:{name:"French",nativeName:"Français",dir:"ltr"},de:{name:"German",nativeName:"Deutsch",dir:"ltr"},pt:{name:"Portuguese",nativeName:"Português",dir:"ltr"},ja:{name:"Japanese",nativeName:"日本語",dir:"ltr"},zh:{name:"Chinese",nativeName:"中文",dir:"ltr"},ko:{name:"Korean",nativeName:"한국어",dir:"ltr"}},Bt={"common.loading":"Loading...","common.save":"Save","common.cancel":"Cancel","common.delete":"Delete","common.edit":"Edit","common.confirm":"Confirm","common.back":"Back","common.next":"Next","common.done":"Done","common.close":"Close","common.search":"Search","common.filter":"Filter","common.sort":"Sort","common.refresh":"Refresh","common.retry":"Retry","common.error":"Error","common.success":"Success","common.warning":"Warning","auth.login":"Log In","auth.logout":"Log Out","auth.signup":"Sign Up","auth.email":"Email","auth.password":"Password","auth.forgotPassword":"Forgot Password?","auth.createAccount":"Create Account","auth.alreadyHaveAccount":"Already have an account?","nav.dashboard":"Dashboard","nav.workout":"Workout","nav.exercises":"Exercises","nav.journey":"Journey","nav.profile":"Profile","nav.settings":"Settings","nav.community":"Community","workout.start":"Start Workout","workout.pause":"Pause","workout.resume":"Resume","workout.finish":"Finish Workout","workout.addSet":"Add Set","workout.rest":"Rest","workout.skip":"Skip","workout.weight":"Weight","workout.reps":"Reps","workout.sets":"Sets","workout.duration":"Duration","workout.volume":"Volume","workout.calories":"Calories","stats.totalWorkouts":"Total Workouts","stats.totalVolume":"Total Volume","stats.streakDays":"Day Streak","stats.level":"Level","stats.xp":"XP","error.generic":"Something went wrong. Please try again.","error.network":"Network error. Check your connection.","error.unauthorized":"Please log in to continue.","error.notFound":"Not found.","error.validation":"Please check your input."},Gc="musclemap_locale",ip=m.createContext(null);function ap(){if(typeof navigator>"u")return Qe.EN;const e=navigator.language?.split("-")[0];return Object.values(Qe).includes(e)?e:Qe.EN}function op(){if(typeof window>"u")return Qe.EN;try{const e=de.getItem(Gc);if(e&&Object.values(Qe).includes(e))return e}catch{}return ap()}function cp({children:e}){const[t,n]=m.useState(op),[s,i]=m.useState(Bt),[a,o]=m.useState(!1);m.useEffect(()=>{async function y(){if(t===Qe.EN){i(Bt);return}o(!0);try{const v=await rp(Object.assign({"../locales/en.json":()=>E(()=>import("./en-il2mt11a.js"),[])}),`../locales/${t}.json`,3).catch(()=>null);v?.default?i({...Bt,...v.default}):i(Bt)}catch{i(Bt)}finally{o(!1)}}y()},[t]),m.useEffect(()=>{try{de.setItem(Gc,t)}catch{}document.documentElement.lang=t;const y=Cs[t];y&&(document.documentElement.dir=y.dir)},[t]);const l=m.useCallback((y,v={})=>{let T=s[y]||y;return Object.entries(v).forEach(([b,I])=>{T=T.replace(new RegExp(`{{${b}}}`,"g"),String(I))}),T},[s]),u=m.useCallback(y=>{Object.values(Qe).includes(y)&&n(y)},[]),d=m.useCallback((y,v={})=>new Intl.NumberFormat(t,v).format(y),[t]),h=m.useCallback((y,v={})=>new Intl.DateTimeFormat(t,v).format(new Date(y)),[t]),f=m.useCallback((y,v={})=>{const T=new Intl.RelativeTimeFormat(t,{numeric:"auto",...v}),b=Date.now(),I=new Date(y).getTime(),x=Math.round((I-b)/1e3),w=[{unit:"year",seconds:31536e3},{unit:"month",seconds:2592e3},{unit:"week",seconds:604800},{unit:"day",seconds:86400},{unit:"hour",seconds:3600},{unit:"minute",seconds:60},{unit:"second",seconds:1}];for(const{unit:_,seconds:A}of w)if(Math.abs(x)>=A||_==="second"){const k=Math.round(x/A);return T.format(k,_)}},[t]),g=m.useMemo(()=>({locale:t,localeInfo:Cs[t],locales:Qe,localeList:Object.entries(Cs).map(([y,v])=>({code:y,...v})),isLoading:a,t:l,formatNumber:d,formatDate:h,formatRelativeTime:f,setLocale:u}),[t,a,l,d,h,f,u]);return c.jsx(ip.Provider,{value:g,children:e})}const Yc="musclemap_motion_preference",Te={SYSTEM:"system",REDUCED:"reduced",FULL:"full"};function lp(){if(typeof window>"u")return Te.SYSTEM;try{const e=localStorage.getItem(Yc);if(e&&Object.values(Te).includes(e))return e}catch{}return Te.SYSTEM}function up(e){if(!(typeof window>"u"))try{localStorage.setItem(Yc,e)}catch{}}function dp(){return typeof window>"u"?!1:window.matchMedia?.("(prefers-reduced-motion: reduce)").matches??!1}function In(){const[e,t]=m.useState(dp),[n,s]=m.useState(lp);m.useEffect(()=>{if(typeof window>"u")return;const o=window.matchMedia("(prefers-reduced-motion: reduce)");t(o.matches);const l=u=>t(u.matches);return o.addEventListener("change",l),()=>o.removeEventListener("change",l)},[]);const i=m.useCallback(o=>{Object.values(Te).includes(o)&&(s(o),up(o))},[]),a=m.useMemo(()=>{switch(n){case Te.REDUCED:return!1;case Te.FULL:return!0;case Te.SYSTEM:default:return!e}},[n,e]);return{prefersReducedMotion:e,motionAllowed:a,userMotionPref:n,setUserMotionPref:i}}function BC(){const{motionAllowed:e}=In();return e}const hs=m.createContext(null);function mp({children:e}){const{prefersReducedMotion:t,motionAllowed:n,userMotionPref:s,setUserMotionPref:i}=In(),a=m.useMemo(()=>({prefersReducedMotion:t,motionAllowed:n,shouldAnimate:n,reducedMotion:!n,userMotionPref:s,setUserMotionPref:i,setReducedMotion:o=>{i(o?Te.REDUCED:Te.FULL)},shouldReduceMotion:!n,motionOptions:Te}),[t,n,s,i]);return c.jsx(hs.Provider,{value:a,children:e})}function FC(){const e=m.useContext(hs),t=In();return e||{prefersReducedMotion:t.prefersReducedMotion,motionAllowed:t.motionAllowed,shouldAnimate:t.motionAllowed,reducedMotion:!t.motionAllowed,userMotionPref:t.userMotionPref,setUserMotionPref:t.setUserMotionPref,setReducedMotion:n=>{t.setUserMotionPref(n?Te.REDUCED:Te.FULL)},shouldReduceMotion:!t.motionAllowed,motionOptions:Te}}function Kc(){const e=m.useContext(hs),t=In();return e?e.motionAllowed:t.motionAllowed}function qC(){const e=m.useContext(hs),t=In();return e?e.shouldReduceMotion:!t.motionAllowed}const wa="/api/trace/frontend-log";class hp{queue;flushInterval;sessionId;flushIntervalId;constructor(){this.queue=[],this.flushInterval=5e3,this.sessionId=this.generateSessionId(),this.flushIntervalId=null,this.setupErrorHandlers(),this.startFlushTimer()}generateSessionId(){return"fs_"+Date.now().toString(36)+Math.random().toString(36).substr(2,9)}setupErrorHandlers(){window.onerror=(t,n,s,i,a)=>(this.error("unhandled_error",{message:t,source:n,lineno:s,colno:i,stack:a?.stack}),!1),window.onunhandledrejection=t=>{this.error("unhandled_rejection",{reason:t.reason?.message||String(t.reason),stack:t.reason?.stack})},document.addEventListener("visibilitychange",()=>{this.event("visibility_change",{hidden:document.hidden})}),window.addEventListener("beforeunload",()=>{this.flush(!0)})}getContext(){return{sessionId:this.sessionId,url:window.location.pathname,userAgent:navigator.userAgent,screenWidth:window.innerWidth,screenHeight:window.innerHeight,timestamp:new Date().toISOString(),userId:this.getUserId()}}getUserId(){try{const t=dn();if(t){const n=JSON.parse(atob(t.split(".")[1]));return n.userId||n.id}}catch{}return null}log(t,n,s={}){const i={level:t,type:n,data:s,...this.getContext()};this.queue.push(i),t==="error"&&this.flush()}error(t,n){this.log("error",t,n)}warn(t,n){this.log("warn",t,n)}info(t,n){this.log("info",t,n)}debug(t,n){this.log("debug",t,n)}event(t,n){this.log("info",t,n)}pageView(t,n={}){this.log("info","page_view",{page:t,...n})}action(t,n={}){this.log("info","user_action",{action:t,...n})}apiCall(t,n,s,i,a=null){this.log(a?"error":"info","api_call",{method:t,url:n,duration:s,status:i,error:a})}performance(t,n,s={}){this.log("info","performance",{metric:t,value:n,...s})}componentMount(t){this.log("debug","component_mount",{component:t})}componentError(t,n){this.log("error","component_error",{component:t,message:n.message,stack:n.stack})}startFlushTimer(){this.flushIntervalId&&clearInterval(this.flushIntervalId),this.flushIntervalId=setInterval(()=>this.flush(),this.flushInterval)}stopFlushTimer(){this.flushIntervalId&&(clearInterval(this.flushIntervalId),this.flushIntervalId=null)}destroy(){this.flush(!0),this.stopFlushTimer()}async flush(t=!1){if(this.queue.length===0)return;const n=[...this.queue];this.queue=[];const s=dn(),i={"Content-Type":"application/json"};s&&(i.Authorization=`Bearer ${s}`);const a=JSON.stringify({entries:n});if(t&&navigator.sendBeacon)navigator.sendBeacon(wa,a);else try{const o=await fetch(wa,{method:"POST",headers:i,body:a,keepalive:!0});if(o.status===404||o.status===410){this.queue=[];return}!o.ok&&(o.status===429||o.status>=500)&&this.queue.unshift(...n)}catch{this.queue.unshift(...n)}}}const De=new hp,WC=async(e,t={})=>{const n=performance.now();try{const s=await fetch(e,t),i=Math.round(performance.now()-n);return De.apiCall(t.method||"GET",e,i,s.status),s}catch(s){const i=Math.round(performance.now()-n);throw De.apiCall(t.method||"GET",e,i,0,s.message),s}},Xr=m.createContext({});function Zr(e){const t=m.useRef(null);return t.current===null&&(t.current=e()),t.current}const ei=typeof window<"u",Qc=ei?m.useLayoutEffect:m.useEffect,xn=m.createContext(null);function ti(e,t){e.indexOf(t)===-1&&e.push(t)}function ni(e,t){const n=e.indexOf(t);n>-1&&e.splice(n,1)}function zC([...e],t,n){const s=t<0?e.length+t:t;if(s>=0&&s<e.length){const i=n<0?e.length+n:n,[a]=e.splice(t,1);e.splice(i,0,a)}return e}const qe=(e,t,n)=>n>t?t:n<e?e:n;let HC=()=>{},si=()=>{};const We={},Jc=e=>/^-?(?:\d+(?:\.\d+)?|\.\d+)$/u.test(e);function Xc(e){return typeof e=="object"&&e!==null}const Zc=e=>/^0[^.\s]+$/u.test(e);function ri(e){let t;return()=>(t===void 0&&(t=e()),t)}const xe=e=>e,pp=(e,t)=>n=>t(e(n)),En=(...e)=>e.reduce(pp),mn=(e,t,n)=>{const s=t-e;return s===0?1:(n-e)/s};class ii{constructor(){this.subscriptions=[]}add(t){return ti(this.subscriptions,t),()=>ni(this.subscriptions,t)}notify(t,n,s){const i=this.subscriptions.length;if(i)if(i===1)this.subscriptions[0](t,n,s);else for(let a=0;a<i;a++){const o=this.subscriptions[a];o&&o(t,n,s)}}getSize(){return this.subscriptions.length}clear(){this.subscriptions.length=0}}const Oe=e=>e*1e3,Ie=e=>e/1e3;function el(e,t){return t?e*(1e3/t):0}const tl=(e,t,n)=>(((1-3*n+3*t)*e+(3*n-6*t))*e+3*t)*e,fp=1e-7,gp=12;function yp(e,t,n,s,i){let a,o,l=0;do o=t+(n-t)/2,a=tl(o,s,i)-e,a>0?n=o:t=o;while(Math.abs(a)>fp&&++l<gp);return o}function An(e,t,n,s){if(e===t&&n===s)return xe;const i=a=>yp(a,0,1,e,n);return a=>a===0||a===1?a:tl(i(a),t,s)}const nl=e=>t=>t<=.5?e(2*t)/2:(2-e(2*(1-t)))/2,sl=e=>t=>1-e(1-t),rl=An(.33,1.53,.69,.99),ai=sl(rl),il=nl(ai),al=e=>(e*=2)<1?.5*ai(e):.5*(2-Math.pow(2,-10*(e-1))),oi=e=>1-Math.sin(Math.acos(e)),ol=sl(oi),cl=nl(oi),vp=An(.42,0,1,1),Sp=An(0,0,.58,1),ll=An(.42,0,.58,1),Tp=e=>Array.isArray(e)&&typeof e[0]!="number",ul=e=>Array.isArray(e)&&typeof e[0]=="number",bp={linear:xe,easeIn:vp,easeInOut:ll,easeOut:Sp,circIn:oi,circInOut:cl,circOut:ol,backIn:ai,backInOut:il,backOut:rl,anticipate:al},wp=e=>typeof e=="string",Ia=e=>{if(ul(e)){si(e.length===4);const[t,n,s,i]=e;return An(t,n,s,i)}else if(wp(e))return bp[e];return e},$n=["setup","read","resolveKeyframes","preUpdate","update","preRender","render","postRender"],Me={value:null,addProjectionMetrics:null};function Ip(e,t){let n=new Set,s=new Set,i=!1,a=!1;const o=new WeakSet;let l={delta:0,timestamp:0,isProcessing:!1},u=0;function d(f){o.has(f)&&(h.schedule(f),e()),u++,f(l)}const h={schedule:(f,g=!1,y=!1)=>{const T=y&&i?n:s;return g&&o.add(f),T.has(f)||T.add(f),f},cancel:f=>{s.delete(f),o.delete(f)},process:f=>{if(l=f,i){a=!0;return}i=!0,[n,s]=[s,n],n.forEach(d),t&&Me.value&&Me.value.frameloop[t].push(u),u=0,n.clear(),i=!1,a&&(a=!1,h.process(f))}};return h}const xp=40;function dl(e,t){let n=!1,s=!0;const i={delta:0,timestamp:0,isProcessing:!1},a=()=>n=!0,o=$n.reduce((w,_)=>(w[_]=Ip(a,t?_:void 0),w),{}),{setup:l,read:u,resolveKeyframes:d,preUpdate:h,update:f,preRender:g,render:y,postRender:v}=o,T=()=>{const w=We.useManualTiming?i.timestamp:performance.now();n=!1,We.useManualTiming||(i.delta=s?1e3/60:Math.max(Math.min(w-i.timestamp,xp),1)),i.timestamp=w,i.isProcessing=!0,l.process(i),u.process(i),d.process(i),h.process(i),f.process(i),g.process(i),y.process(i),v.process(i),i.isProcessing=!1,n&&t&&(s=!1,e(T))},b=()=>{n=!0,s=!0,i.isProcessing||e(T)};return{schedule:$n.reduce((w,_)=>{const A=o[_];return w[_]=(k,R=!1,P=!1)=>(n||b(),A.schedule(k,R,P)),w},{}),cancel:w=>{for(let _=0;_<$n.length;_++)o[$n[_]].cancel(w)},state:i,steps:o}}const{schedule:G,cancel:Xe,state:ce,steps:ks}=dl(typeof requestAnimationFrame<"u"?requestAnimationFrame:xe,!0);let zn;function Ep(){zn=void 0}const ge={now:()=>(zn===void 0&&ge.set(ce.isProcessing||We.useManualTiming?ce.timestamp:performance.now()),zn),set:e=>{zn=e,queueMicrotask(Ep)}},ut={layout:0,mainThread:0,waapi:0},ml=e=>t=>typeof t=="string"&&t.startsWith(e),ci=ml("--"),Ap=ml("var(--"),li=e=>Ap(e)?_p.test(e.split("/*")[0].trim()):!1,_p=/var\(--(?:[\w-]+\s*|[\w-]+\s*,(?:\s*[^)(\s]|\s*\((?:[^)(]|\([^)(]*\))*\))+\s*)\)$/iu,Nt={test:e=>typeof e=="number",parse:parseFloat,transform:e=>e},hn={...Nt,transform:e=>qe(0,1,e)},Dn={...Nt,default:1},en=e=>Math.round(e*1e5)/1e5,ui=/-?(?:\d+(?:\.\d+)?|\.\d+)/gu;function Cp(e){return e==null}const kp=/^(?:#[\da-f]{3,8}|(?:rgb|hsl)a?\((?:-?[\d.]+%?[,\s]+){2}-?[\d.]+%?\s*(?:[,/]\s*)?(?:\b\d+(?:\.\d+)?|\.\d+)?%?\))$/iu,di=(e,t)=>n=>!!(typeof n=="string"&&kp.test(n)&&n.startsWith(e)||t&&!Cp(n)&&Object.prototype.hasOwnProperty.call(n,t)),hl=(e,t,n)=>s=>{if(typeof s!="string")return s;const[i,a,o,l]=s.match(ui);return{[e]:parseFloat(i),[t]:parseFloat(a),[n]:parseFloat(o),alpha:l!==void 0?parseFloat(l):1}},Rp=e=>qe(0,255,e),Rs={...Nt,transform:e=>Math.round(Rp(e))},ot={test:di("rgb","red"),parse:hl("red","green","blue"),transform:({red:e,green:t,blue:n,alpha:s=1})=>"rgba("+Rs.transform(e)+", "+Rs.transform(t)+", "+Rs.transform(n)+", "+en(hn.transform(s))+")"};function Pp(e){let t="",n="",s="",i="";return e.length>5?(t=e.substring(1,3),n=e.substring(3,5),s=e.substring(5,7),i=e.substring(7,9)):(t=e.substring(1,2),n=e.substring(2,3),s=e.substring(3,4),i=e.substring(4,5),t+=t,n+=n,s+=s,i+=i),{red:parseInt(t,16),green:parseInt(n,16),blue:parseInt(s,16),alpha:i?parseInt(i,16)/255:1}}const gr={test:di("#"),parse:Pp,transform:ot.transform},_n=e=>({test:t=>typeof t=="string"&&t.endsWith(e)&&t.split(" ").length===1,parse:parseFloat,transform:t=>`${t}${e}`}),Ge=_n("deg"),Ne=_n("%"),L=_n("px"),Mp=_n("vh"),Op=_n("vw"),xa={...Ne,parse:e=>Ne.parse(e)/100,transform:e=>Ne.transform(e*100)},gt={test:di("hsl","hue"),parse:hl("hue","saturation","lightness"),transform:({hue:e,saturation:t,lightness:n,alpha:s=1})=>"hsla("+Math.round(e)+", "+Ne.transform(en(t))+", "+Ne.transform(en(n))+", "+en(hn.transform(s))+")"},te={test:e=>ot.test(e)||gr.test(e)||gt.test(e),parse:e=>ot.test(e)?ot.parse(e):gt.test(e)?gt.parse(e):gr.parse(e),transform:e=>typeof e=="string"?e:e.hasOwnProperty("red")?ot.transform(e):gt.transform(e),getAnimatableNone:e=>{const t=te.parse(e);return t.alpha=0,te.transform(t)}},Np=/(?:#[\da-f]{3,8}|(?:rgb|hsl)a?\((?:-?[\d.]+%?[,\s]+){2}-?[\d.]+%?\s*(?:[,/]\s*)?(?:\b\d+(?:\.\d+)?|\.\d+)?%?\))/giu;function $p(e){return isNaN(e)&&typeof e=="string"&&(e.match(ui)?.length||0)+(e.match(Np)?.length||0)>0}const pl="number",fl="color",Dp="var",jp="var(",Ea="${}",Lp=/var\s*\(\s*--(?:[\w-]+\s*|[\w-]+\s*,(?:\s*[^)(\s]|\s*\((?:[^)(]|\([^)(]*\))*\))+\s*)\)|#[\da-f]{3,8}|(?:rgb|hsl)a?\((?:-?[\d.]+%?[,\s]+){2}-?[\d.]+%?\s*(?:[,/]\s*)?(?:\b\d+(?:\.\d+)?|\.\d+)?%?\)|-?(?:\d+(?:\.\d+)?|\.\d+)/giu;function pn(e){const t=e.toString(),n=[],s={color:[],number:[],var:[]},i=[];let a=0;const l=t.replace(Lp,u=>(te.test(u)?(s.color.push(a),i.push(fl),n.push(te.parse(u))):u.startsWith(jp)?(s.var.push(a),i.push(Dp),n.push(u)):(s.number.push(a),i.push(pl),n.push(parseFloat(u))),++a,Ea)).split(Ea);return{values:n,split:l,indexes:s,types:i}}function gl(e){return pn(e).values}function yl(e){const{split:t,types:n}=pn(e),s=t.length;return i=>{let a="";for(let o=0;o<s;o++)if(a+=t[o],i[o]!==void 0){const l=n[o];l===pl?a+=en(i[o]):l===fl?a+=te.transform(i[o]):a+=i[o]}return a}}const Up=e=>typeof e=="number"?0:te.test(e)?te.getAnimatableNone(e):e;function Vp(e){const t=gl(e);return yl(e)(t.map(Up))}const Ze={test:$p,parse:gl,createTransformer:yl,getAnimatableNone:Vp};function Ps(e,t,n){return n<0&&(n+=1),n>1&&(n-=1),n<1/6?e+(t-e)*6*n:n<1/2?t:n<2/3?e+(t-e)*(2/3-n)*6:e}function Bp({hue:e,saturation:t,lightness:n,alpha:s}){e/=360,t/=100,n/=100;let i=0,a=0,o=0;if(!t)i=a=o=n;else{const l=n<.5?n*(1+t):n+t-n*t,u=2*n-l;i=Ps(u,l,e+1/3),a=Ps(u,l,e),o=Ps(u,l,e-1/3)}return{red:Math.round(i*255),green:Math.round(a*255),blue:Math.round(o*255),alpha:s}}function Qn(e,t){return n=>n>0?t:e}const K=(e,t,n)=>e+(t-e)*n,Ms=(e,t,n)=>{const s=e*e,i=n*(t*t-s)+s;return i<0?0:Math.sqrt(i)},Fp=[gr,ot,gt],qp=e=>Fp.find(t=>t.test(e));function Aa(e){const t=qp(e);if(!t)return!1;let n=t.parse(e);return t===gt&&(n=Bp(n)),n}const _a=(e,t)=>{const n=Aa(e),s=Aa(t);if(!n||!s)return Qn(e,t);const i={...n};return a=>(i.red=Ms(n.red,s.red,a),i.green=Ms(n.green,s.green,a),i.blue=Ms(n.blue,s.blue,a),i.alpha=K(n.alpha,s.alpha,a),ot.transform(i))},yr=new Set(["none","hidden"]);function Wp(e,t){return yr.has(e)?n=>n<=0?e:t:n=>n>=1?t:e}function zp(e,t){return n=>K(e,t,n)}function mi(e){return typeof e=="number"?zp:typeof e=="string"?li(e)?Qn:te.test(e)?_a:Yp:Array.isArray(e)?vl:typeof e=="object"?te.test(e)?_a:Hp:Qn}function vl(e,t){const n=[...e],s=n.length,i=e.map((a,o)=>mi(a)(a,t[o]));return a=>{for(let o=0;o<s;o++)n[o]=i[o](a);return n}}function Hp(e,t){const n={...e,...t},s={};for(const i in n)e[i]!==void 0&&t[i]!==void 0&&(s[i]=mi(e[i])(e[i],t[i]));return i=>{for(const a in s)n[a]=s[a](i);return n}}function Gp(e,t){const n=[],s={color:0,var:0,number:0};for(let i=0;i<t.values.length;i++){const a=t.types[i],o=e.indexes[a][s[a]],l=e.values[o]??0;n[i]=l,s[a]++}return n}const Yp=(e,t)=>{const n=Ze.createTransformer(t),s=pn(e),i=pn(t);return s.indexes.var.length===i.indexes.var.length&&s.indexes.color.length===i.indexes.color.length&&s.indexes.number.length>=i.indexes.number.length?yr.has(e)&&!i.values.length||yr.has(t)&&!s.values.length?Wp(e,t):En(vl(Gp(s,i),i.values),n):Qn(e,t)};function Sl(e,t,n){return typeof e=="number"&&typeof t=="number"&&typeof n=="number"?K(e,t,n):mi(e)(e,t)}const Kp=e=>{const t=({timestamp:n})=>e(n);return{start:(n=!0)=>G.update(t,n),stop:()=>Xe(t),now:()=>ce.isProcessing?ce.timestamp:ge.now()}},Tl=(e,t,n=10)=>{let s="";const i=Math.max(Math.round(t/n),2);for(let a=0;a<i;a++)s+=Math.round(e(a/(i-1))*1e4)/1e4+", ";return`linear(${s.substring(0,s.length-2)})`},Jn=2e4;function hi(e){let t=0;const n=50;let s=e.next(t);for(;!s.done&&t<Jn;)t+=n,s=e.next(t);return t>=Jn?1/0:t}function Qp(e,t=100,n){const s=n({...e,keyframes:[0,t]}),i=Math.min(hi(s),Jn);return{type:"keyframes",ease:a=>s.next(i*a).value/t,duration:Ie(i)}}const Jp=5;function bl(e,t,n){const s=Math.max(t-Jp,0);return el(n-e(s),t-s)}const X={stiffness:100,damping:10,mass:1,velocity:0,duration:800,bounce:.3,visualDuration:.3,restSpeed:{granular:.01,default:2},restDelta:{granular:.005,default:.5},minDuration:.01,maxDuration:10,minDamping:.05,maxDamping:1},Os=.001;function Xp({duration:e=X.duration,bounce:t=X.bounce,velocity:n=X.velocity,mass:s=X.mass}){let i,a,o=1-t;o=qe(X.minDamping,X.maxDamping,o),e=qe(X.minDuration,X.maxDuration,Ie(e)),o<1?(i=d=>{const h=d*o,f=h*e,g=h-n,y=vr(d,o),v=Math.exp(-f);return Os-g/y*v},a=d=>{const f=d*o*e,g=f*n+n,y=Math.pow(o,2)*Math.pow(d,2)*e,v=Math.exp(-f),T=vr(Math.pow(d,2),o);return(-i(d)+Os>0?-1:1)*((g-y)*v)/T}):(i=d=>{const h=Math.exp(-d*e),f=(d-n)*e+1;return-Os+h*f},a=d=>{const h=Math.exp(-d*e),f=(n-d)*(e*e);return h*f});const l=5/e,u=ef(i,a,l);if(e=Oe(e),isNaN(u))return{stiffness:X.stiffness,damping:X.damping,duration:e};{const d=Math.pow(u,2)*s;return{stiffness:d,damping:o*2*Math.sqrt(s*d),duration:e}}}const Zp=12;function ef(e,t,n){let s=n;for(let i=1;i<Zp;i++)s=s-e(s)/t(s);return s}function vr(e,t){return e*Math.sqrt(1-t*t)}const tf=["duration","bounce"],nf=["stiffness","damping","mass"];function Ca(e,t){return t.some(n=>e[n]!==void 0)}function sf(e){let t={velocity:X.velocity,stiffness:X.stiffness,damping:X.damping,mass:X.mass,isResolvedFromDuration:!1,...e};if(!Ca(e,nf)&&Ca(e,tf))if(e.visualDuration){const n=e.visualDuration,s=2*Math.PI/(n*1.2),i=s*s,a=2*qe(.05,1,1-(e.bounce||0))*Math.sqrt(i);t={...t,mass:X.mass,stiffness:i,damping:a}}else{const n=Xp(e);t={...t,...n,mass:X.mass},t.isResolvedFromDuration=!0}return t}function Xn(e=X.visualDuration,t=X.bounce){const n=typeof e!="object"?{visualDuration:e,keyframes:[0,1],bounce:t}:e;let{restSpeed:s,restDelta:i}=n;const a=n.keyframes[0],o=n.keyframes[n.keyframes.length-1],l={done:!1,value:a},{stiffness:u,damping:d,mass:h,duration:f,velocity:g,isResolvedFromDuration:y}=sf({...n,velocity:-Ie(n.velocity||0)}),v=g||0,T=d/(2*Math.sqrt(u*h)),b=o-a,I=Ie(Math.sqrt(u/h)),x=Math.abs(b)<5;s||(s=x?X.restSpeed.granular:X.restSpeed.default),i||(i=x?X.restDelta.granular:X.restDelta.default);let w;if(T<1){const A=vr(I,T);w=k=>{const R=Math.exp(-T*I*k);return o-R*((v+T*I*b)/A*Math.sin(A*k)+b*Math.cos(A*k))}}else if(T===1)w=A=>o-Math.exp(-I*A)*(b+(v+I*b)*A);else{const A=I*Math.sqrt(T*T-1);w=k=>{const R=Math.exp(-T*I*k),P=Math.min(A*k,300);return o-R*((v+T*I*b)*Math.sinh(P)+A*b*Math.cosh(P))/A}}const _={calculatedDuration:y&&f||null,next:A=>{const k=w(A);if(y)l.done=A>=f;else{let R=A===0?v:0;T<1&&(R=A===0?Oe(v):bl(w,A,k));const P=Math.abs(R)<=s,O=Math.abs(o-k)<=i;l.done=P&&O}return l.value=l.done?o:k,l},toString:()=>{const A=Math.min(hi(_),Jn),k=Tl(R=>_.next(A*R).value,A,30);return A+"ms "+k},toTransition:()=>{}};return _}Xn.applyToOptions=e=>{const t=Qp(e,100,Xn);return e.ease=t.ease,e.duration=Oe(t.duration),e.type="keyframes",e};function Sr({keyframes:e,velocity:t=0,power:n=.8,timeConstant:s=325,bounceDamping:i=10,bounceStiffness:a=500,modifyTarget:o,min:l,max:u,restDelta:d=.5,restSpeed:h}){const f=e[0],g={done:!1,value:f},y=P=>l!==void 0&&P<l||u!==void 0&&P>u,v=P=>l===void 0?u:u===void 0||Math.abs(l-P)<Math.abs(u-P)?l:u;let T=n*t;const b=f+T,I=o===void 0?b:o(b);I!==b&&(T=I-f);const x=P=>-T*Math.exp(-P/s),w=P=>I+x(P),_=P=>{const O=x(P),N=w(P);g.done=Math.abs(O)<=d,g.value=g.done?I:N};let A,k;const R=P=>{y(g.value)&&(A=P,k=Xn({keyframes:[g.value,v(g.value)],velocity:bl(w,P,g.value),damping:i,stiffness:a,restDelta:d,restSpeed:h}))};return R(0),{calculatedDuration:null,next:P=>{let O=!1;return!k&&A===void 0&&(O=!0,_(P),R(P)),A!==void 0&&P>=A?k.next(P-A):(!O&&_(P),g)}}}function rf(e,t,n){const s=[],i=n||We.mix||Sl,a=e.length-1;for(let o=0;o<a;o++){let l=i(e[o],e[o+1]);if(t){const u=Array.isArray(t)?t[o]||xe:t;l=En(u,l)}s.push(l)}return s}function af(e,t,{clamp:n=!0,ease:s,mixer:i}={}){const a=e.length;if(si(a===t.length),a===1)return()=>t[0];if(a===2&&t[0]===t[1])return()=>t[1];const o=e[0]===e[1];e[0]>e[a-1]&&(e=[...e].reverse(),t=[...t].reverse());const l=rf(t,s,i),u=l.length,d=h=>{if(o&&h<e[0])return t[0];let f=0;if(u>1)for(;f<e.length-2&&!(h<e[f+1]);f++);const g=mn(e[f],e[f+1],h);return l[f](g)};return n?h=>d(qe(e[0],e[a-1],h)):d}function of(e,t){const n=e[e.length-1];for(let s=1;s<=t;s++){const i=mn(0,t,s);e.push(K(n,1,i))}}function cf(e){const t=[0];return of(t,e.length-1),t}function lf(e,t){return e.map(n=>n*t)}function uf(e,t){return e.map(()=>t||ll).splice(0,e.length-1)}function tn({duration:e=300,keyframes:t,times:n,ease:s="easeInOut"}){const i=Tp(s)?s.map(Ia):Ia(s),a={done:!1,value:t[0]},o=lf(n&&n.length===t.length?n:cf(t),e),l=af(o,t,{ease:Array.isArray(i)?i:uf(t,i)});return{calculatedDuration:e,next:u=>(a.value=l(u),a.done=u>=e,a)}}const df=e=>e!==null;function pi(e,{repeat:t,repeatType:n="loop"},s,i=1){const a=e.filter(df),l=i<0||t&&n!=="loop"&&t%2===1?0:a.length-1;return!l||s===void 0?a[l]:s}const mf={decay:Sr,inertia:Sr,tween:tn,keyframes:tn,spring:Xn};function wl(e){typeof e.type=="string"&&(e.type=mf[e.type])}class fi{constructor(){this.updateFinished()}get finished(){return this._finished}updateFinished(){this._finished=new Promise(t=>{this.resolve=t})}notifyFinished(){this.resolve()}then(t,n){return this.finished.then(t,n)}}const hf=e=>e/100;class ps extends fi{constructor(t){super(),this.state="idle",this.startTime=null,this.isStopped=!1,this.currentTime=0,this.holdTime=null,this.playbackSpeed=1,this.stop=()=>{const{motionValue:n}=this.options;n&&n.updatedAt!==ge.now()&&this.tick(ge.now()),this.isStopped=!0,this.state!=="idle"&&(this.teardown(),this.options.onStop?.())},ut.mainThread++,this.options=t,this.initAnimation(),this.play(),t.autoplay===!1&&this.pause()}initAnimation(){const{options:t}=this;wl(t);const{type:n=tn,repeat:s=0,repeatDelay:i=0,repeatType:a,velocity:o=0}=t;let{keyframes:l}=t;const u=n||tn;u!==tn&&typeof l[0]!="number"&&(this.mixKeyframes=En(hf,Sl(l[0],l[1])),l=[0,100]);const d=u({...t,keyframes:l});a==="mirror"&&(this.mirroredGenerator=u({...t,keyframes:[...l].reverse(),velocity:-o})),d.calculatedDuration===null&&(d.calculatedDuration=hi(d));const{calculatedDuration:h}=d;this.calculatedDuration=h,this.resolvedDuration=h+i,this.totalDuration=this.resolvedDuration*(s+1)-i,this.generator=d}updateTime(t){const n=Math.round(t-this.startTime)*this.playbackSpeed;this.holdTime!==null?this.currentTime=this.holdTime:this.currentTime=n}tick(t,n=!1){const{generator:s,totalDuration:i,mixKeyframes:a,mirroredGenerator:o,resolvedDuration:l,calculatedDuration:u}=this;if(this.startTime===null)return s.next(0);const{delay:d=0,keyframes:h,repeat:f,repeatType:g,repeatDelay:y,type:v,onUpdate:T,finalKeyframe:b}=this.options;this.speed>0?this.startTime=Math.min(this.startTime,t):this.speed<0&&(this.startTime=Math.min(t-i/this.speed,this.startTime)),n?this.currentTime=t:this.updateTime(t);const I=this.currentTime-d*(this.playbackSpeed>=0?1:-1),x=this.playbackSpeed>=0?I<0:I>i;this.currentTime=Math.max(I,0),this.state==="finished"&&this.holdTime===null&&(this.currentTime=i);let w=this.currentTime,_=s;if(f){const P=Math.min(this.currentTime,i)/l;let O=Math.floor(P),N=P%1;!N&&P>=1&&(N=1),N===1&&O--,O=Math.min(O,f+1),!!(O%2)&&(g==="reverse"?(N=1-N,y&&(N-=y/l)):g==="mirror"&&(_=o)),w=qe(0,1,N)*l}const A=x?{done:!1,value:h[0]}:_.next(w);a&&(A.value=a(A.value));let{done:k}=A;!x&&u!==null&&(k=this.playbackSpeed>=0?this.currentTime>=i:this.currentTime<=0);const R=this.holdTime===null&&(this.state==="finished"||this.state==="running"&&k);return R&&v!==Sr&&(A.value=pi(h,this.options,b,this.speed)),T&&T(A.value),R&&this.finish(),A}then(t,n){return this.finished.then(t,n)}get duration(){return Ie(this.calculatedDuration)}get iterationDuration(){const{delay:t=0}=this.options||{};return this.duration+Ie(t)}get time(){return Ie(this.currentTime)}set time(t){t=Oe(t),this.currentTime=t,this.startTime===null||this.holdTime!==null||this.playbackSpeed===0?this.holdTime=t:this.driver&&(this.startTime=this.driver.now()-t/this.playbackSpeed),this.driver?.start(!1)}get speed(){return this.playbackSpeed}set speed(t){this.updateTime(ge.now());const n=this.playbackSpeed!==t;this.playbackSpeed=t,n&&(this.time=Ie(this.currentTime))}play(){if(this.isStopped)return;const{driver:t=Kp,startTime:n}=this.options;this.driver||(this.driver=t(i=>this.tick(i))),this.options.onPlay?.();const s=this.driver.now();this.state==="finished"?(this.updateFinished(),this.startTime=s):this.holdTime!==null?this.startTime=s-this.holdTime:this.startTime||(this.startTime=n??s),this.state==="finished"&&this.speed<0&&(this.startTime+=this.calculatedDuration),this.holdTime=null,this.state="running",this.driver.start()}pause(){this.state="paused",this.updateTime(ge.now()),this.holdTime=this.currentTime}complete(){this.state!=="running"&&this.play(),this.state="finished",this.holdTime=null}finish(){this.notifyFinished(),this.teardown(),this.state="finished",this.options.onComplete?.()}cancel(){this.holdTime=null,this.startTime=0,this.tick(0),this.teardown(),this.options.onCancel?.()}teardown(){this.state="idle",this.stopDriver(),this.startTime=this.holdTime=null,ut.mainThread--}stopDriver(){this.driver&&(this.driver.stop(),this.driver=void 0)}sample(t){return this.startTime=0,this.tick(t,!0)}attachTimeline(t){return this.options.allowFlatten&&(this.options.type="keyframes",this.options.ease="linear",this.initAnimation()),this.driver?.stop(),t.observe(this)}}function GC(e){return new ps(e)}function pf(e){for(let t=1;t<e.length;t++)e[t]??(e[t]=e[t-1])}const ct=e=>e*180/Math.PI,Tr=e=>{const t=ct(Math.atan2(e[1],e[0]));return br(t)},ff={x:4,y:5,translateX:4,translateY:5,scaleX:0,scaleY:3,scale:e=>(Math.abs(e[0])+Math.abs(e[3]))/2,rotate:Tr,rotateZ:Tr,skewX:e=>ct(Math.atan(e[1])),skewY:e=>ct(Math.atan(e[2])),skew:e=>(Math.abs(e[1])+Math.abs(e[2]))/2},br=e=>(e=e%360,e<0&&(e+=360),e),ka=Tr,Ra=e=>Math.sqrt(e[0]*e[0]+e[1]*e[1]),Pa=e=>Math.sqrt(e[4]*e[4]+e[5]*e[5]),gf={x:12,y:13,z:14,translateX:12,translateY:13,translateZ:14,scaleX:Ra,scaleY:Pa,scale:e=>(Ra(e)+Pa(e))/2,rotateX:e=>br(ct(Math.atan2(e[6],e[5]))),rotateY:e=>br(ct(Math.atan2(-e[2],e[0]))),rotateZ:ka,rotate:ka,skewX:e=>ct(Math.atan(e[4])),skewY:e=>ct(Math.atan(e[1])),skew:e=>(Math.abs(e[1])+Math.abs(e[4]))/2};function wr(e){return e.includes("scale")?1:0}function Ir(e,t){if(!e||e==="none")return wr(t);const n=e.match(/^matrix3d\(([-\d.e\s,]+)\)$/u);let s,i;if(n)s=gf,i=n;else{const l=e.match(/^matrix\(([-\d.e\s,]+)\)$/u);s=ff,i=l}if(!i)return wr(t);const a=s[t],o=i[1].split(",").map(vf);return typeof a=="function"?a(o):o[a]}const yf=(e,t)=>{const{transform:n="none"}=getComputedStyle(e);return Ir(n,t)};function vf(e){return parseFloat(e.trim())}const $t=["transformPerspective","x","y","z","translateX","translateY","translateZ","scale","scaleX","scaleY","rotate","rotateX","rotateY","rotateZ","skew","skewX","skewY"],Dt=new Set($t),Ma=e=>e===Nt||e===L,Sf=new Set(["x","y","z"]),Tf=$t.filter(e=>!Sf.has(e));function bf(e){const t=[];return Tf.forEach(n=>{const s=e.getValue(n);s!==void 0&&(t.push([n,s.get()]),s.set(n.startsWith("scale")?1:0))}),t}const dt={width:({x:e},{paddingLeft:t="0",paddingRight:n="0"})=>e.max-e.min-parseFloat(t)-parseFloat(n),height:({y:e},{paddingTop:t="0",paddingBottom:n="0"})=>e.max-e.min-parseFloat(t)-parseFloat(n),top:(e,{top:t})=>parseFloat(t),left:(e,{left:t})=>parseFloat(t),bottom:({y:e},{top:t})=>parseFloat(t)+(e.max-e.min),right:({x:e},{left:t})=>parseFloat(t)+(e.max-e.min),x:(e,{transform:t})=>Ir(t,"x"),y:(e,{transform:t})=>Ir(t,"y")};dt.translateX=dt.x;dt.translateY=dt.y;const mt=new Set;let xr=!1,Er=!1,Ar=!1;function Il(){if(Er){const e=Array.from(mt).filter(s=>s.needsMeasurement),t=new Set(e.map(s=>s.element)),n=new Map;t.forEach(s=>{const i=bf(s);i.length&&(n.set(s,i),s.render())}),e.forEach(s=>s.measureInitialState()),t.forEach(s=>{s.render();const i=n.get(s);i&&i.forEach(([a,o])=>{s.getValue(a)?.set(o)})}),e.forEach(s=>s.measureEndState()),e.forEach(s=>{s.suspendedScrollY!==void 0&&window.scrollTo(0,s.suspendedScrollY)})}Er=!1,xr=!1,mt.forEach(e=>e.complete(Ar)),mt.clear()}function xl(){mt.forEach(e=>{e.readKeyframes(),e.needsMeasurement&&(Er=!0)})}function wf(){Ar=!0,xl(),Il(),Ar=!1}class gi{constructor(t,n,s,i,a,o=!1){this.state="pending",this.isAsync=!1,this.needsMeasurement=!1,this.unresolvedKeyframes=[...t],this.onComplete=n,this.name=s,this.motionValue=i,this.element=a,this.isAsync=o}scheduleResolve(){this.state="scheduled",this.isAsync?(mt.add(this),xr||(xr=!0,G.read(xl),G.resolveKeyframes(Il))):(this.readKeyframes(),this.complete())}readKeyframes(){const{unresolvedKeyframes:t,name:n,element:s,motionValue:i}=this;if(t[0]===null){const a=i?.get(),o=t[t.length-1];if(a!==void 0)t[0]=a;else if(s&&n){const l=s.readValue(n,o);l!=null&&(t[0]=l)}t[0]===void 0&&(t[0]=o),i&&a===void 0&&i.set(t[0])}pf(t)}setFinalKeyframe(){}measureInitialState(){}renderEndStyles(){}measureEndState(){}complete(t=!1){this.state="complete",this.onComplete(this.unresolvedKeyframes,this.finalKeyframe,t),mt.delete(this)}cancel(){this.state==="scheduled"&&(mt.delete(this),this.state="pending")}resume(){this.state==="pending"&&this.scheduleResolve()}}const If=e=>e.startsWith("--");function xf(e,t,n){If(t)?e.style.setProperty(t,n):e.style[t]=n}const Ef=ri(()=>window.ScrollTimeline!==void 0),Af={};function _f(e,t){const n=ri(e);return()=>Af[t]??n()}const El=_f(()=>{try{document.createElement("div").animate({opacity:0},{easing:"linear(0, 1)"})}catch{return!1}return!0},"linearEasing"),Gt=([e,t,n,s])=>`cubic-bezier(${e}, ${t}, ${n}, ${s})`,Oa={linear:"linear",ease:"ease",easeIn:"ease-in",easeOut:"ease-out",easeInOut:"ease-in-out",circIn:Gt([0,.65,.55,1]),circOut:Gt([.55,0,1,.45]),backIn:Gt([.31,.01,.66,-.59]),backOut:Gt([.33,1.53,.69,.99])};function Al(e,t){if(e)return typeof e=="function"?El()?Tl(e,t):"ease-out":ul(e)?Gt(e):Array.isArray(e)?e.map(n=>Al(n,t)||Oa.easeOut):Oa[e]}function Cf(e,t,n,{delay:s=0,duration:i=300,repeat:a=0,repeatType:o="loop",ease:l="easeOut",times:u}={},d=void 0){const h={[t]:n};u&&(h.offset=u);const f=Al(l,i);Array.isArray(f)&&(h.easing=f),Me.value&&ut.waapi++;const g={delay:s,duration:i,easing:Array.isArray(f)?"linear":f,fill:"both",iterations:a+1,direction:o==="reverse"?"alternate":"normal"};d&&(g.pseudoElement=d);const y=e.animate(h,g);return Me.value&&y.finished.finally(()=>{ut.waapi--}),y}function _l(e){return typeof e=="function"&&"applyToOptions"in e}function kf({type:e,...t}){return _l(e)&&El()?e.applyToOptions(t):(t.duration??(t.duration=300),t.ease??(t.ease="easeOut"),t)}class Rf extends fi{constructor(t){if(super(),this.finishedTime=null,this.isStopped=!1,!t)return;const{element:n,name:s,keyframes:i,pseudoElement:a,allowFlatten:o=!1,finalKeyframe:l,onComplete:u}=t;this.isPseudoElement=!!a,this.allowFlatten=o,this.options=t,si(typeof t.type!="string");const d=kf(t);this.animation=Cf(n,s,i,d,a),d.autoplay===!1&&this.animation.pause(),this.animation.onfinish=()=>{if(this.finishedTime=this.time,!a){const h=pi(i,this.options,l,this.speed);this.updateMotionValue?this.updateMotionValue(h):xf(n,s,h),this.animation.cancel()}u?.(),this.notifyFinished()}}play(){this.isStopped||(this.animation.play(),this.state==="finished"&&this.updateFinished())}pause(){this.animation.pause()}complete(){this.animation.finish?.()}cancel(){try{this.animation.cancel()}catch{}}stop(){if(this.isStopped)return;this.isStopped=!0;const{state:t}=this;t==="idle"||t==="finished"||(this.updateMotionValue?this.updateMotionValue():this.commitStyles(),this.isPseudoElement||this.cancel())}commitStyles(){this.isPseudoElement||this.animation.commitStyles?.()}get duration(){const t=this.animation.effect?.getComputedTiming?.().duration||0;return Ie(Number(t))}get iterationDuration(){const{delay:t=0}=this.options||{};return this.duration+Ie(t)}get time(){return Ie(Number(this.animation.currentTime)||0)}set time(t){this.finishedTime=null,this.animation.currentTime=Oe(t)}get speed(){return this.animation.playbackRate}set speed(t){t<0&&(this.finishedTime=null),this.animation.playbackRate=t}get state(){return this.finishedTime!==null?"finished":this.animation.playState}get startTime(){return Number(this.animation.startTime)}set startTime(t){this.animation.startTime=t}attachTimeline({timeline:t,observe:n}){return this.allowFlatten&&this.animation.effect?.updateTiming({easing:"linear"}),this.animation.onfinish=null,t&&Ef()?(this.animation.timeline=t,xe):n(this)}}const Cl={anticipate:al,backInOut:il,circInOut:cl};function Pf(e){return e in Cl}function Mf(e){typeof e.ease=="string"&&Pf(e.ease)&&(e.ease=Cl[e.ease])}const Na=10;class Of extends Rf{constructor(t){Mf(t),wl(t),super(t),t.startTime&&(this.startTime=t.startTime),this.options=t}updateMotionValue(t){const{motionValue:n,onUpdate:s,onComplete:i,element:a,...o}=this.options;if(!n)return;if(t!==void 0){n.set(t);return}const l=new ps({...o,autoplay:!1}),u=Oe(this.finishedTime??this.time);n.setWithVelocity(l.sample(u-Na).value,l.sample(u).value,Na),l.stop()}}const $a=(e,t)=>t==="zIndex"?!1:!!(typeof e=="number"||Array.isArray(e)||typeof e=="string"&&(Ze.test(e)||e==="0")&&!e.startsWith("url("));function Nf(e){const t=e[0];if(e.length===1)return!0;for(let n=0;n<e.length;n++)if(e[n]!==t)return!0}function $f(e,t,n,s){const i=e[0];if(i===null)return!1;if(t==="display"||t==="visibility")return!0;const a=e[e.length-1],o=$a(i,t),l=$a(a,t);return!o||!l?!1:Nf(e)||(n==="spring"||_l(n))&&s}function _r(e){e.duration=0,e.type="keyframes"}const Df=new Set(["opacity","clipPath","filter","transform"]),jf=ri(()=>Object.hasOwnProperty.call(Element.prototype,"animate"));function Lf(e){const{motionValue:t,name:n,repeatDelay:s,repeatType:i,damping:a,type:o}=e;if(!(t?.owner?.current instanceof HTMLElement))return!1;const{onUpdate:u,transformTemplate:d}=t.owner.getProps();return jf()&&n&&Df.has(n)&&(n!=="transform"||!d)&&!u&&!s&&i!=="mirror"&&a!==0&&o!=="inertia"}const Uf=40;class Vf extends fi{constructor({autoplay:t=!0,delay:n=0,type:s="keyframes",repeat:i=0,repeatDelay:a=0,repeatType:o="loop",keyframes:l,name:u,motionValue:d,element:h,...f}){super(),this.stop=()=>{this._animation&&(this._animation.stop(),this.stopTimeline?.()),this.keyframeResolver?.cancel()},this.createdAt=ge.now();const g={autoplay:t,delay:n,type:s,repeat:i,repeatDelay:a,repeatType:o,name:u,motionValue:d,element:h,...f},y=h?.KeyframeResolver||gi;this.keyframeResolver=new y(l,(v,T,b)=>this.onKeyframesResolved(v,T,g,!b),u,d,h),this.keyframeResolver?.scheduleResolve()}onKeyframesResolved(t,n,s,i){this.keyframeResolver=void 0;const{name:a,type:o,velocity:l,delay:u,isHandoff:d,onUpdate:h}=s;this.resolvedAt=ge.now(),$f(t,a,o,l)||((We.instantAnimations||!u)&&h?.(pi(t,s,n)),t[0]=t[t.length-1],_r(s),s.repeat=0);const g={startTime:i?this.resolvedAt?this.resolvedAt-this.createdAt>Uf?this.resolvedAt:this.createdAt:this.createdAt:void 0,finalKeyframe:n,...s,keyframes:t},y=!d&&Lf(g)?new Of({...g,element:g.motionValue.owner.current}):new ps(g);y.finished.then(()=>this.notifyFinished()).catch(xe),this.pendingTimeline&&(this.stopTimeline=y.attachTimeline(this.pendingTimeline),this.pendingTimeline=void 0),this._animation=y}get finished(){return this._animation?this.animation.finished:this._finished}then(t,n){return this.finished.finally(t).then(()=>{})}get animation(){return this._animation||(this.keyframeResolver?.resume(),wf()),this._animation}get duration(){return this.animation.duration}get iterationDuration(){return this.animation.iterationDuration}get time(){return this.animation.time}set time(t){this.animation.time=t}get speed(){return this.animation.speed}get state(){return this.animation.state}set speed(t){this.animation.speed=t}get startTime(){return this.animation.startTime}attachTimeline(t){return this._animation?this.stopTimeline=this.animation.attachTimeline(t):this.pendingTimeline=t,()=>this.stop()}play(){this.animation.play()}pause(){this.animation.pause()}complete(){this.animation.complete()}cancel(){this._animation&&this.animation.cancel(),this.keyframeResolver?.cancel()}}const Bf=/^var\(--(?:([\w-]+)|([\w-]+), ?([a-zA-Z\d ()%#.,-]+))\)/u;function Ff(e){const t=Bf.exec(e);if(!t)return[,];const[,n,s,i]=t;return[`--${n??s}`,i]}function kl(e,t,n=1){const[s,i]=Ff(e);if(!s)return;const a=window.getComputedStyle(t).getPropertyValue(s);if(a){const o=a.trim();return Jc(o)?parseFloat(o):o}return li(i)?kl(i,t,n+1):i}function yi(e,t){return e?.[t]??e?.default??e}const Rl=new Set(["width","height","top","left","right","bottom",...$t]),qf={test:e=>e==="auto",parse:e=>e},Pl=e=>t=>t.test(e),Ml=[Nt,L,Ne,Ge,Op,Mp,qf],Da=e=>Ml.find(Pl(e));function Wf(e){return typeof e=="number"?e===0:e!==null?e==="none"||e==="0"||Zc(e):!0}const zf=new Set(["brightness","contrast","saturate","opacity"]);function Hf(e){const[t,n]=e.slice(0,-1).split("(");if(t==="drop-shadow")return e;const[s]=n.match(ui)||[];if(!s)return e;const i=n.replace(s,"");let a=zf.has(t)?1:0;return s!==n&&(a*=100),t+"("+a+i+")"}const Gf=/\b([a-z-]*)\(.*?\)/gu,Cr={...Ze,getAnimatableNone:e=>{const t=e.match(Gf);return t?t.map(Hf).join(" "):e}},ja={...Nt,transform:Math.round},Yf={rotate:Ge,rotateX:Ge,rotateY:Ge,rotateZ:Ge,scale:Dn,scaleX:Dn,scaleY:Dn,scaleZ:Dn,skew:Ge,skewX:Ge,skewY:Ge,distance:L,translateX:L,translateY:L,translateZ:L,x:L,y:L,z:L,perspective:L,transformPerspective:L,opacity:hn,originX:xa,originY:xa,originZ:L},vi={borderWidth:L,borderTopWidth:L,borderRightWidth:L,borderBottomWidth:L,borderLeftWidth:L,borderRadius:L,radius:L,borderTopLeftRadius:L,borderTopRightRadius:L,borderBottomRightRadius:L,borderBottomLeftRadius:L,width:L,maxWidth:L,height:L,maxHeight:L,top:L,right:L,bottom:L,left:L,padding:L,paddingTop:L,paddingRight:L,paddingBottom:L,paddingLeft:L,margin:L,marginTop:L,marginRight:L,marginBottom:L,marginLeft:L,backgroundPositionX:L,backgroundPositionY:L,...Yf,zIndex:ja,fillOpacity:hn,strokeOpacity:hn,numOctaves:ja},Kf={...vi,color:te,backgroundColor:te,outlineColor:te,fill:te,stroke:te,borderColor:te,borderTopColor:te,borderRightColor:te,borderBottomColor:te,borderLeftColor:te,filter:Cr,WebkitFilter:Cr},Ol=e=>Kf[e];function Nl(e,t){let n=Ol(e);return n!==Cr&&(n=Ze),n.getAnimatableNone?n.getAnimatableNone(t):void 0}const Qf=new Set(["auto","none","0"]);function Jf(e,t,n){let s=0,i;for(;s<e.length&&!i;){const a=e[s];typeof a=="string"&&!Qf.has(a)&&pn(a).values.length&&(i=e[s]),s++}if(i&&n)for(const a of t)e[a]=Nl(n,i)}class Xf extends gi{constructor(t,n,s,i,a){super(t,n,s,i,a,!0)}readKeyframes(){const{unresolvedKeyframes:t,element:n,name:s}=this;if(!n||!n.current)return;super.readKeyframes();for(let u=0;u<t.length;u++){let d=t[u];if(typeof d=="string"&&(d=d.trim(),li(d))){const h=kl(d,n.current);h!==void 0&&(t[u]=h),u===t.length-1&&(this.finalKeyframe=d)}}if(this.resolveNoneKeyframes(),!Rl.has(s)||t.length!==2)return;const[i,a]=t,o=Da(i),l=Da(a);if(o!==l)if(Ma(o)&&Ma(l))for(let u=0;u<t.length;u++){const d=t[u];typeof d=="string"&&(t[u]=parseFloat(d))}else dt[s]&&(this.needsMeasurement=!0)}resolveNoneKeyframes(){const{unresolvedKeyframes:t,name:n}=this,s=[];for(let i=0;i<t.length;i++)(t[i]===null||Wf(t[i]))&&s.push(i);s.length&&Jf(t,s,n)}measureInitialState(){const{element:t,unresolvedKeyframes:n,name:s}=this;if(!t||!t.current)return;s==="height"&&(this.suspendedScrollY=window.pageYOffset),this.measuredOrigin=dt[s](t.measureViewportBox(),window.getComputedStyle(t.current)),n[0]=this.measuredOrigin;const i=n[n.length-1];i!==void 0&&t.getValue(s,i).jump(i,!1)}measureEndState(){const{element:t,name:n,unresolvedKeyframes:s}=this;if(!t||!t.current)return;const i=t.getValue(n);i&&i.jump(this.measuredOrigin,!1);const a=s.length-1,o=s[a];s[a]=dt[n](t.measureViewportBox(),window.getComputedStyle(t.current)),o!==null&&this.finalKeyframe===void 0&&(this.finalKeyframe=o),this.removedTransforms?.length&&this.removedTransforms.forEach(([l,u])=>{t.getValue(l).set(u)}),this.resolveNoneKeyframes()}}function Zf(e,t,n){if(e instanceof EventTarget)return[e];if(typeof e=="string"){let s=document;t&&(s=t.current);const i=n?.[e]??s.querySelectorAll(e);return i?Array.from(i):[]}return Array.from(e)}const $l=(e,t)=>t&&typeof e=="number"?t.transform(e):e;function Dl(e){return Xc(e)&&"offsetHeight"in e}const La=30,eg=e=>!isNaN(parseFloat(e)),Ua={current:void 0};class tg{constructor(t,n={}){this.canTrackVelocity=null,this.events={},this.updateAndNotify=s=>{const i=ge.now();if(this.updatedAt!==i&&this.setPrevFrameValue(),this.prev=this.current,this.setCurrent(s),this.current!==this.prev&&(this.events.change?.notify(this.current),this.dependents))for(const a of this.dependents)a.dirty()},this.hasAnimated=!1,this.setCurrent(t),this.owner=n.owner}setCurrent(t){this.current=t,this.updatedAt=ge.now(),this.canTrackVelocity===null&&t!==void 0&&(this.canTrackVelocity=eg(this.current))}setPrevFrameValue(t=this.current){this.prevFrameValue=t,this.prevUpdatedAt=this.updatedAt}onChange(t){return this.on("change",t)}on(t,n){this.events[t]||(this.events[t]=new ii);const s=this.events[t].add(n);return t==="change"?()=>{s(),G.read(()=>{this.events.change.getSize()||this.stop()})}:s}clearListeners(){for(const t in this.events)this.events[t].clear()}attach(t,n){this.passiveEffect=t,this.stopPassiveEffect=n}set(t){this.passiveEffect?this.passiveEffect(t,this.updateAndNotify):this.updateAndNotify(t)}setWithVelocity(t,n,s){this.set(n),this.prev=void 0,this.prevFrameValue=t,this.prevUpdatedAt=this.updatedAt-s}jump(t,n=!0){this.updateAndNotify(t),this.prev=t,this.prevUpdatedAt=this.prevFrameValue=void 0,n&&this.stop(),this.stopPassiveEffect&&this.stopPassiveEffect()}dirty(){this.events.change?.notify(this.current)}addDependent(t){this.dependents||(this.dependents=new Set),this.dependents.add(t)}removeDependent(t){this.dependents&&this.dependents.delete(t)}get(){return Ua.current&&Ua.current.push(this),this.current}getPrevious(){return this.prev}getVelocity(){const t=ge.now();if(!this.canTrackVelocity||this.prevFrameValue===void 0||t-this.updatedAt>La)return 0;const n=Math.min(this.updatedAt-this.prevUpdatedAt,La);return el(parseFloat(this.current)-parseFloat(this.prevFrameValue),n)}start(t){return this.stop(),new Promise(n=>{this.hasAnimated=!0,this.animation=t(n),this.events.animationStart&&this.events.animationStart.notify()}).then(()=>{this.events.animationComplete&&this.events.animationComplete.notify(),this.clearAnimation()})}stop(){this.animation&&(this.animation.stop(),this.events.animationCancel&&this.events.animationCancel.notify()),this.clearAnimation()}isAnimating(){return!!this.animation}clearAnimation(){delete this.animation}destroy(){this.dependents?.clear(),this.events.destroy?.notify(),this.clearListeners(),this.stop(),this.stopPassiveEffect&&this.stopPassiveEffect()}}function _t(e,t){return new tg(e,t)}const{schedule:Si,cancel:YC}=dl(queueMicrotask,!1),Ae={x:!1,y:!1};function jl(){return Ae.x||Ae.y}function ng(e){return e==="x"||e==="y"?Ae[e]?null:(Ae[e]=!0,()=>{Ae[e]=!1}):Ae.x||Ae.y?null:(Ae.x=Ae.y=!0,()=>{Ae.x=Ae.y=!1})}function Ll(e,t){const n=Zf(e),s=new AbortController,i={passive:!0,...t,signal:s.signal};return[n,i,()=>s.abort()]}function Va(e){return!(e.pointerType==="touch"||jl())}function sg(e,t,n={}){const[s,i,a]=Ll(e,n),o=l=>{if(!Va(l))return;const{target:u}=l,d=t(u,l);if(typeof d!="function"||!u)return;const h=f=>{Va(f)&&(d(f),u.removeEventListener("pointerleave",h))};u.addEventListener("pointerleave",h,i)};return s.forEach(l=>{l.addEventListener("pointerenter",o,i)}),a}const Ul=(e,t)=>t?e===t?!0:Ul(e,t.parentElement):!1,Ti=e=>e.pointerType==="mouse"?typeof e.button!="number"||e.button<=0:e.isPrimary!==!1,rg=new Set(["BUTTON","INPUT","SELECT","TEXTAREA","A"]);function ig(e){return rg.has(e.tagName)||e.tabIndex!==-1}const Hn=new WeakSet;function Ba(e){return t=>{t.key==="Enter"&&e(t)}}function Ns(e,t){e.dispatchEvent(new PointerEvent("pointer"+t,{isPrimary:!0,bubbles:!0}))}const ag=(e,t)=>{const n=e.currentTarget;if(!n)return;const s=Ba(()=>{if(Hn.has(n))return;Ns(n,"down");const i=Ba(()=>{Ns(n,"up")}),a=()=>Ns(n,"cancel");n.addEventListener("keyup",i,t),n.addEventListener("blur",a,t)});n.addEventListener("keydown",s,t),n.addEventListener("blur",()=>n.removeEventListener("keydown",s),t)};function Fa(e){return Ti(e)&&!jl()}function og(e,t,n={}){const[s,i,a]=Ll(e,n),o=l=>{const u=l.currentTarget;if(!Fa(l))return;Hn.add(u);const d=t(u,l),h=(y,v)=>{window.removeEventListener("pointerup",f),window.removeEventListener("pointercancel",g),Hn.has(u)&&Hn.delete(u),Fa(y)&&typeof d=="function"&&d(y,{success:v})},f=y=>{h(y,u===window||u===document||n.useGlobalTarget||Ul(u,y.target))},g=y=>{h(y,!1)};window.addEventListener("pointerup",f,i),window.addEventListener("pointercancel",g,i)};return s.forEach(l=>{(n.useGlobalTarget?window:l).addEventListener("pointerdown",o,i),Dl(l)&&(l.addEventListener("focus",d=>ag(d,i)),!ig(l)&&!l.hasAttribute("tabindex")&&(l.tabIndex=0))}),a}function Vl(e){return Xc(e)&&"ownerSVGElement"in e}function cg(e){return Vl(e)&&e.tagName==="svg"}const ue=e=>!!(e&&e.getVelocity),lg=[...Ml,te,Ze],ug=e=>lg.find(Pl(e)),bi=m.createContext({transformPagePoint:e=>e,isStatic:!1,reducedMotion:"never"});function qa(e,t){if(typeof e=="function")return e(t);e!=null&&(e.current=t)}function dg(...e){return t=>{let n=!1;const s=e.map(i=>{const a=qa(i,t);return!n&&typeof a=="function"&&(n=!0),a});if(n)return()=>{for(let i=0;i<s.length;i++){const a=s[i];typeof a=="function"?a():qa(e[i],null)}}}}function mg(...e){return m.useCallback(dg(...e),e)}class hg extends m.Component{getSnapshotBeforeUpdate(t){const n=this.props.childRef.current;if(n&&t.isPresent&&!this.props.isPresent){const s=n.offsetParent,i=Dl(s)&&s.offsetWidth||0,a=this.props.sizeRef.current;a.height=n.offsetHeight||0,a.width=n.offsetWidth||0,a.top=n.offsetTop,a.left=n.offsetLeft,a.right=i-a.width-a.left}return null}componentDidUpdate(){}render(){return this.props.children}}function pg({children:e,isPresent:t,anchorX:n,root:s}){const i=m.useId(),a=m.useRef(null),o=m.useRef({width:0,height:0,top:0,left:0,right:0}),{nonce:l}=m.useContext(bi),u=mg(a,e?.ref);return m.useInsertionEffect(()=>{const{width:d,height:h,top:f,left:g,right:y}=o.current;if(t||!a.current||!d||!h)return;const v=n==="left"?`left: ${g}`:`right: ${y}`;a.current.dataset.motionPopId=i;const T=document.createElement("style");l&&(T.nonce=l);const b=s??document.head;return b.appendChild(T),T.sheet&&T.sheet.insertRule(`
          [data-motion-pop-id="${i}"] {
            position: absolute !important;
            width: ${d}px !important;
            height: ${h}px !important;
            ${v}px !important;
            top: ${f}px !important;
          }
        `),()=>{b.contains(T)&&b.removeChild(T)}},[t]),c.jsx(hg,{isPresent:t,childRef:a,sizeRef:o,children:m.cloneElement(e,{ref:u})})}const fg=({children:e,initial:t,isPresent:n,onExitComplete:s,custom:i,presenceAffectsLayout:a,mode:o,anchorX:l,root:u})=>{const d=Zr(gg),h=m.useId();let f=!0,g=m.useMemo(()=>(f=!1,{id:h,initial:t,isPresent:n,custom:i,onExitComplete:y=>{d.set(y,!0);for(const v of d.values())if(!v)return;s&&s()},register:y=>(d.set(y,!1),()=>d.delete(y))}),[n,d,s]);return a&&f&&(g={...g}),m.useMemo(()=>{d.forEach((y,v)=>d.set(v,!1))},[n]),m.useEffect(()=>{!n&&!d.size&&s&&s()},[n]),o==="popLayout"&&(e=c.jsx(pg,{isPresent:n,anchorX:l,root:u,children:e})),c.jsx(xn.Provider,{value:g,children:e})};function gg(){return new Map}function Bl(e=!0){const t=m.useContext(xn);if(t===null)return[!0,null];const{isPresent:n,onExitComplete:s,register:i}=t,a=m.useId();m.useEffect(()=>{if(e)return i(a)},[e]);const o=m.useCallback(()=>e&&s&&s(a),[a,s,e]);return!n&&s?[!1,o]:[!0]}function KC(){return yg(m.useContext(xn))}function yg(e){return e===null?!0:e.isPresent}const jn=e=>e.key||"";function Wa(e){const t=[];return m.Children.forEach(e,n=>{m.isValidElement(n)&&t.push(n)}),t}const Ct=({children:e,custom:t,initial:n=!0,onExitComplete:s,presenceAffectsLayout:i=!0,mode:a="sync",propagate:o=!1,anchorX:l="left",root:u})=>{const[d,h]=Bl(o),f=m.useMemo(()=>Wa(e),[e]),g=o&&!d?[]:f.map(jn),y=m.useRef(!0),v=m.useRef(f),T=Zr(()=>new Map),[b,I]=m.useState(f),[x,w]=m.useState(f);Qc(()=>{y.current=!1,v.current=f;for(let k=0;k<x.length;k++){const R=jn(x[k]);g.includes(R)?T.delete(R):T.get(R)!==!0&&T.set(R,!1)}},[x,g.length,g.join("-")]);const _=[];if(f!==b){let k=[...f];for(let R=0;R<x.length;R++){const P=x[R],O=jn(P);g.includes(O)||(k.splice(R,0,P),_.push(P))}return a==="wait"&&_.length&&(k=_),w(Wa(k)),I(f),null}const{forceRender:A}=m.useContext(Xr);return c.jsx(c.Fragment,{children:x.map(k=>{const R=jn(k),P=o&&!d?!1:f===x||g.includes(R),O=()=>{if(T.has(R))T.set(R,!0);else return;let N=!0;T.forEach(F=>{F||(N=!1)}),N&&(A?.(),w(v.current),o&&h?.(),s&&s())};return c.jsx(fg,{isPresent:P,initial:!y.current||n?void 0:!1,custom:t,presenceAffectsLayout:i,mode:a,root:u,onExitComplete:P?void 0:O,anchorX:l,children:k},R)})})},Fl=m.createContext({strict:!1}),za={animation:["animate","variants","whileHover","whileTap","exit","whileInView","whileFocus","whileDrag"],exit:["exit"],drag:["drag","dragControls"],focus:["whileFocus"],hover:["whileHover","onHoverStart","onHoverEnd"],tap:["whileTap","onTap","onTapStart","onTapCancel"],pan:["onPan","onPanStart","onPanSessionStart","onPanEnd"],inView:["whileInView","onViewportEnter","onViewportLeave"],layout:["layout","layoutId"]},kt={};for(const e in za)kt[e]={isEnabled:t=>za[e].some(n=>!!t[n])};function vg(e){for(const t in e)kt[t]={...kt[t],...e[t]}}const Sg=new Set(["animate","exit","variants","initial","style","values","variants","transition","transformTemplate","custom","inherit","onBeforeLayoutMeasure","onAnimationStart","onAnimationComplete","onUpdate","onDragStart","onDrag","onDragEnd","onMeasureDragConstraints","onDirectionLock","onDragTransitionEnd","_dragX","_dragY","onHoverStart","onHoverEnd","onViewportEnter","onViewportLeave","globalTapTarget","ignoreStrict","viewport"]);function Zn(e){return e.startsWith("while")||e.startsWith("drag")&&e!=="draggable"||e.startsWith("layout")||e.startsWith("onTap")||e.startsWith("onPan")||e.startsWith("onLayout")||Sg.has(e)}let ql=e=>!Zn(e);function Tg(e){typeof e=="function"&&(ql=t=>t.startsWith("on")?!Zn(t):e(t))}try{Tg(require("@emotion/is-prop-valid").default)}catch{}function bg(e,t,n){const s={};for(const i in e)i==="values"&&typeof e.values=="object"||(ql(i)||n===!0&&Zn(i)||!t&&!Zn(i)||e.draggable&&i.startsWith("onDrag"))&&(s[i]=e[i]);return s}const fs=m.createContext({});function gs(e){return e!==null&&typeof e=="object"&&typeof e.start=="function"}function fn(e){return typeof e=="string"||Array.isArray(e)}const wi=["animate","whileInView","whileFocus","whileHover","whileTap","whileDrag","exit"],Ii=["initial",...wi];function ys(e){return gs(e.animate)||Ii.some(t=>fn(e[t]))}function Wl(e){return!!(ys(e)||e.variants)}function wg(e,t){if(ys(e)){const{initial:n,animate:s}=e;return{initial:n===!1||fn(n)?n:void 0,animate:fn(s)?s:void 0}}return e.inherit!==!1?t:{}}function Ig(e){const{initial:t,animate:n}=wg(e,m.useContext(fs));return m.useMemo(()=>({initial:t,animate:n}),[Ha(t),Ha(n)])}function Ha(e){return Array.isArray(e)?e.join(" "):e}function Ga(e,t){return t.max===t.min?0:e/(t.max-t.min)*100}const Ft={correct:(e,t)=>{if(!t.target)return e;if(typeof e=="string")if(L.test(e))e=parseFloat(e);else return e;const n=Ga(e,t.target.x),s=Ga(e,t.target.y);return`${n}% ${s}%`}},xg={correct:(e,{treeScale:t,projectionDelta:n})=>{const s=e,i=Ze.parse(e);if(i.length>5)return s;const a=Ze.createTransformer(e),o=typeof i[0]!="number"?1:0,l=n.x.scale*t.x,u=n.y.scale*t.y;i[0+o]/=l,i[1+o]/=u;const d=K(l,u,.5);return typeof i[2+o]=="number"&&(i[2+o]/=d),typeof i[3+o]=="number"&&(i[3+o]/=d),a(i)}},gn={borderRadius:{...Ft,applyTo:["borderTopLeftRadius","borderTopRightRadius","borderBottomLeftRadius","borderBottomRightRadius"]},borderTopLeftRadius:Ft,borderTopRightRadius:Ft,borderBottomLeftRadius:Ft,borderBottomRightRadius:Ft,boxShadow:xg};function QC(e){for(const t in e)gn[t]=e[t],ci(t)&&(gn[t].isCSSVariable=!0)}function zl(e,{layout:t,layoutId:n}){return Dt.has(e)||e.startsWith("origin")||(t||n!==void 0)&&(!!gn[e]||e==="opacity")}const Eg={x:"translateX",y:"translateY",z:"translateZ",transformPerspective:"perspective"},Ag=$t.length;function _g(e,t,n){let s="",i=!0;for(let a=0;a<Ag;a++){const o=$t[a],l=e[o];if(l===void 0)continue;let u=!0;if(typeof l=="number"?u=l===(o.startsWith("scale")?1:0):u=parseFloat(l)===0,!u||n){const d=$l(l,vi[o]);if(!u){i=!1;const h=Eg[o]||o;s+=`${h}(${d}) `}n&&(t[o]=d)}}return s=s.trim(),n?s=n(t,i?"":s):i&&(s="none"),s}function xi(e,t,n){const{style:s,vars:i,transformOrigin:a}=e;let o=!1,l=!1;for(const u in t){const d=t[u];if(Dt.has(u)){o=!0;continue}else if(ci(u)){i[u]=d;continue}else{const h=$l(d,vi[u]);u.startsWith("origin")?(l=!0,a[u]=h):s[u]=h}}if(t.transform||(o||n?s.transform=_g(t,e.transform,n):s.transform&&(s.transform="none")),l){const{originX:u="50%",originY:d="50%",originZ:h=0}=a;s.transformOrigin=`${u} ${d} ${h}`}}const Ei=()=>({style:{},transform:{},transformOrigin:{},vars:{}});function Hl(e,t,n){for(const s in t)!ue(t[s])&&!zl(s,n)&&(e[s]=t[s])}function Cg({transformTemplate:e},t){return m.useMemo(()=>{const n=Ei();return xi(n,t,e),Object.assign({},n.vars,n.style)},[t])}function kg(e,t){const n=e.style||{},s={};return Hl(s,n,e),Object.assign(s,Cg(e,t)),s}function Rg(e,t){const n={},s=kg(e,t);return e.drag&&e.dragListener!==!1&&(n.draggable=!1,s.userSelect=s.WebkitUserSelect=s.WebkitTouchCallout="none",s.touchAction=e.drag===!0?"none":`pan-${e.drag==="x"?"y":"x"}`),e.tabIndex===void 0&&(e.onTap||e.onTapStart||e.whileTap)&&(n.tabIndex=0),n.style=s,n}const Pg={offset:"stroke-dashoffset",array:"stroke-dasharray"},Mg={offset:"strokeDashoffset",array:"strokeDasharray"};function Og(e,t,n=1,s=0,i=!0){e.pathLength=1;const a=i?Pg:Mg;e[a.offset]=L.transform(-s);const o=L.transform(t),l=L.transform(n);e[a.array]=`${o} ${l}`}function Gl(e,{attrX:t,attrY:n,attrScale:s,pathLength:i,pathSpacing:a=1,pathOffset:o=0,...l},u,d,h){if(xi(e,l,d),u){e.style.viewBox&&(e.attrs.viewBox=e.style.viewBox);return}e.attrs=e.style,e.style={};const{attrs:f,style:g}=e;f.transform&&(g.transform=f.transform,delete f.transform),(g.transform||f.transformOrigin)&&(g.transformOrigin=f.transformOrigin??"50% 50%",delete f.transformOrigin),g.transform&&(g.transformBox=h?.transformBox??"fill-box",delete f.transformBox),t!==void 0&&(f.x=t),n!==void 0&&(f.y=n),s!==void 0&&(f.scale=s),i!==void 0&&Og(f,i,a,o,!1)}const Yl=()=>({...Ei(),attrs:{}}),Kl=e=>typeof e=="string"&&e.toLowerCase()==="svg";function Ng(e,t,n,s){const i=m.useMemo(()=>{const a=Yl();return Gl(a,t,Kl(s),e.transformTemplate,e.style),{...a.attrs,style:{...a.style}}},[t]);if(e.style){const a={};Hl(a,e.style,e),i.style={...a,...i.style}}return i}const $g=["animate","circle","defs","desc","ellipse","g","image","line","filter","marker","mask","metadata","path","pattern","polygon","polyline","rect","stop","switch","symbol","svg","text","tspan","use","view"];function Ai(e){return typeof e!="string"||e.includes("-")?!1:!!($g.indexOf(e)>-1||/[A-Z]/u.test(e))}function Dg(e,t,n,{latestValues:s},i,a=!1){const l=(Ai(e)?Ng:Rg)(t,s,i,e),u=bg(t,typeof e=="string",a),d=e!==m.Fragment?{...u,...l,ref:n}:{},{children:h}=t,f=m.useMemo(()=>ue(h)?h.get():h,[h]);return m.createElement(e,{...d,children:f})}function Ya(e){const t=[{},{}];return e?.values.forEach((n,s)=>{t[0][s]=n.get(),t[1][s]=n.getVelocity()}),t}function _i(e,t,n,s){if(typeof t=="function"){const[i,a]=Ya(s);t=t(n!==void 0?n:e.custom,i,a)}if(typeof t=="string"&&(t=e.variants&&e.variants[t]),typeof t=="function"){const[i,a]=Ya(s);t=t(n!==void 0?n:e.custom,i,a)}return t}function Gn(e){return ue(e)?e.get():e}function jg({scrapeMotionValuesFromProps:e,createRenderState:t},n,s,i){return{latestValues:Lg(n,s,i,e),renderState:t()}}function Lg(e,t,n,s){const i={},a=s(e,{});for(const g in a)i[g]=Gn(a[g]);let{initial:o,animate:l}=e;const u=ys(e),d=Wl(e);t&&d&&!u&&e.inherit!==!1&&(o===void 0&&(o=t.initial),l===void 0&&(l=t.animate));let h=n?n.initial===!1:!1;h=h||o===!1;const f=h?l:o;if(f&&typeof f!="boolean"&&!gs(f)){const g=Array.isArray(f)?f:[f];for(let y=0;y<g.length;y++){const v=_i(e,g[y]);if(v){const{transitionEnd:T,transition:b,...I}=v;for(const x in I){let w=I[x];if(Array.isArray(w)){const _=h?w.length-1:0;w=w[_]}w!==null&&(i[x]=w)}for(const x in T)i[x]=T[x]}}}return i}const Ql=e=>(t,n)=>{const s=m.useContext(fs),i=m.useContext(xn),a=()=>jg(e,t,s,i);return n?a():Zr(a)};function Ci(e,t,n){const{style:s}=e,i={};for(const a in s)(ue(s[a])||t.style&&ue(t.style[a])||zl(a,e)||n?.getValue(a)?.liveStyle!==void 0)&&(i[a]=s[a]);return i}const Ug=Ql({scrapeMotionValuesFromProps:Ci,createRenderState:Ei});function Jl(e,t,n){const s=Ci(e,t,n);for(const i in e)if(ue(e[i])||ue(t[i])){const a=$t.indexOf(i)!==-1?"attr"+i.charAt(0).toUpperCase()+i.substring(1):i;s[a]=e[i]}return s}const Vg=Ql({scrapeMotionValuesFromProps:Jl,createRenderState:Yl}),Bg=Symbol.for("motionComponentSymbol");function yt(e){return e&&typeof e=="object"&&Object.prototype.hasOwnProperty.call(e,"current")}function Fg(e,t,n){return m.useCallback(s=>{s&&e.onMount&&e.onMount(s),t&&(s?t.mount(s):t.unmount()),n&&(typeof n=="function"?n(s):yt(n)&&(n.current=s))},[t])}const ki=e=>e.replace(/([a-z])([A-Z])/gu,"$1-$2").toLowerCase(),qg="framerAppearId",Xl="data-"+ki(qg),Zl=m.createContext({});function Wg(e,t,n,s,i){const{visualElement:a}=m.useContext(fs),o=m.useContext(Fl),l=m.useContext(xn),u=m.useContext(bi).reducedMotion,d=m.useRef(null);s=s||o.renderer,!d.current&&s&&(d.current=s(e,{visualState:t,parent:a,props:n,presenceContext:l,blockInitialAnimation:l?l.initial===!1:!1,reducedMotionConfig:u}));const h=d.current,f=m.useContext(Zl);h&&!h.projection&&i&&(h.type==="html"||h.type==="svg")&&zg(d.current,n,i,f);const g=m.useRef(!1);m.useInsertionEffect(()=>{h&&g.current&&h.update(n,l)});const y=n[Xl],v=m.useRef(!!y&&!window.MotionHandoffIsComplete?.(y)&&window.MotionHasOptimisedAnimation?.(y));return Qc(()=>{h&&(g.current=!0,window.MotionIsMounted=!0,h.updateFeatures(),h.scheduleRenderMicrotask(),v.current&&h.animationState&&h.animationState.animateChanges())}),m.useEffect(()=>{h&&(!v.current&&h.animationState&&h.animationState.animateChanges(),v.current&&(queueMicrotask(()=>{window.MotionHandoffMarkAsComplete?.(y)}),v.current=!1),h.enteringChildren=void 0)}),h}function zg(e,t,n,s){const{layoutId:i,layout:a,drag:o,dragConstraints:l,layoutScroll:u,layoutRoot:d,layoutCrossfade:h}=t;e.projection=new n(e.latestValues,t["data-framer-portal-id"]?void 0:eu(e.parent)),e.projection.setOptions({layoutId:i,layout:a,alwaysMeasureLayout:!!o||l&&yt(l),visualElement:e,animationType:typeof a=="string"?a:"both",initialPromotionConfig:s,crossfade:h,layoutScroll:u,layoutRoot:d})}function eu(e){if(e)return e.options.allowProjection!==!1?e.projection:eu(e.parent)}function $s(e,{forwardMotionProps:t=!1}={},n,s){n&&vg(n);const i=Ai(e)?Vg:Ug;function a(l,u){let d;const h={...m.useContext(bi),...l,layoutId:Hg(l)},{isStatic:f}=h,g=Ig(l),y=i(l,f);if(!f&&ei){Gg();const v=Yg(h);d=v.MeasureLayout,g.visualElement=Wg(e,y,h,s,v.ProjectionNode)}return c.jsxs(fs.Provider,{value:g,children:[d&&g.visualElement?c.jsx(d,{visualElement:g.visualElement,...h}):null,Dg(e,l,Fg(y,g.visualElement,u),y,f,t)]})}a.displayName=`motion.${typeof e=="string"?e:`create(${e.displayName??e.name??""})`}`;const o=m.forwardRef(a);return o[Bg]=e,o}function Hg({layoutId:e}){const t=m.useContext(Xr).id;return t&&e!==void 0?t+"-"+e:e}function Gg(e,t){m.useContext(Fl).strict}function Yg(e){const{drag:t,layout:n}=kt;if(!t&&!n)return{};const s={...t,...n};return{MeasureLayout:t?.isEnabled(e)||n?.isEnabled(e)?s.MeasureLayout:void 0,ProjectionNode:s.ProjectionNode}}function Kg(e,t){if(typeof Proxy>"u")return $s;const n=new Map,s=(a,o)=>$s(a,o,e,t),i=(a,o)=>s(a,o);return new Proxy(i,{get:(a,o)=>o==="create"?s:(n.has(o)||n.set(o,$s(o,void 0,e,t)),n.get(o))})}function tu({top:e,left:t,right:n,bottom:s}){return{x:{min:t,max:n},y:{min:e,max:s}}}function Qg({x:e,y:t}){return{top:t.min,right:e.max,bottom:t.max,left:e.min}}function Jg(e,t){if(!t)return e;const n=t({x:e.left,y:e.top}),s=t({x:e.right,y:e.bottom});return{top:n.y,left:n.x,bottom:s.y,right:s.x}}function Ds(e){return e===void 0||e===1}function kr({scale:e,scaleX:t,scaleY:n}){return!Ds(e)||!Ds(t)||!Ds(n)}function rt(e){return kr(e)||nu(e)||e.z||e.rotate||e.rotateX||e.rotateY||e.skewX||e.skewY}function nu(e){return Ka(e.x)||Ka(e.y)}function Ka(e){return e&&e!=="0%"}function es(e,t,n){const s=e-n,i=t*s;return n+i}function Qa(e,t,n,s,i){return i!==void 0&&(e=es(e,i,s)),es(e,n,s)+t}function Rr(e,t=0,n=1,s,i){e.min=Qa(e.min,t,n,s,i),e.max=Qa(e.max,t,n,s,i)}function su(e,{x:t,y:n}){Rr(e.x,t.translate,t.scale,t.originPoint),Rr(e.y,n.translate,n.scale,n.originPoint)}const Ja=.999999999999,Xa=1.0000000000001;function Xg(e,t,n,s=!1){const i=n.length;if(!i)return;t.x=t.y=1;let a,o;for(let l=0;l<i;l++){a=n[l],o=a.projectionDelta;const{visualElement:u}=a.options;u&&u.props.style&&u.props.style.display==="contents"||(s&&a.options.layoutScroll&&a.scroll&&a!==a.root&&St(e,{x:-a.scroll.offset.x,y:-a.scroll.offset.y}),o&&(t.x*=o.x.scale,t.y*=o.y.scale,su(e,o)),s&&rt(a.latestValues)&&St(e,a.latestValues))}t.x<Xa&&t.x>Ja&&(t.x=1),t.y<Xa&&t.y>Ja&&(t.y=1)}function vt(e,t){e.min=e.min+t,e.max=e.max+t}function Za(e,t,n,s,i=.5){const a=K(e.min,e.max,i);Rr(e,t,n,a,s)}function St(e,t){Za(e.x,t.x,t.scaleX,t.scale,t.originX),Za(e.y,t.y,t.scaleY,t.scale,t.originY)}function ru(e,t){return tu(Jg(e.getBoundingClientRect(),t))}function Zg(e,t,n){const s=ru(e,n),{scroll:i}=t;return i&&(vt(s.x,i.offset.x),vt(s.y,i.offset.y)),s}const eo=()=>({translate:0,scale:1,origin:0,originPoint:0}),Tt=()=>({x:eo(),y:eo()}),to=()=>({min:0,max:0}),ne=()=>({x:to(),y:to()}),Pr={current:null},iu={current:!1};function ey(){if(iu.current=!0,!!ei)if(window.matchMedia){const e=window.matchMedia("(prefers-reduced-motion)"),t=()=>Pr.current=e.matches;e.addEventListener("change",t),t()}else Pr.current=!1}const ty=new WeakMap;function ny(e,t,n){for(const s in t){const i=t[s],a=n[s];if(ue(i))e.addValue(s,i);else if(ue(a))e.addValue(s,_t(i,{owner:e}));else if(a!==i)if(e.hasValue(s)){const o=e.getValue(s);o.liveStyle===!0?o.jump(i):o.hasAnimated||o.set(i)}else{const o=e.getStaticValue(s);e.addValue(s,_t(o!==void 0?o:i,{owner:e}))}}for(const s in n)t[s]===void 0&&e.removeValue(s);return t}const no=["AnimationStart","AnimationComplete","Update","BeforeLayoutMeasure","LayoutMeasure","LayoutAnimationStart","LayoutAnimationComplete"];class sy{scrapeMotionValuesFromProps(t,n,s){return{}}constructor({parent:t,props:n,presenceContext:s,reducedMotionConfig:i,blockInitialAnimation:a,visualState:o},l={}){this.current=null,this.children=new Set,this.isVariantNode=!1,this.isControllingVariants=!1,this.shouldReduceMotion=null,this.values=new Map,this.KeyframeResolver=gi,this.features={},this.valueSubscriptions=new Map,this.prevMotionValues={},this.events={},this.propEventSubscriptions={},this.notifyUpdate=()=>this.notify("Update",this.latestValues),this.render=()=>{this.current&&(this.triggerBuild(),this.renderInstance(this.current,this.renderState,this.props.style,this.projection))},this.renderScheduledAt=0,this.scheduleRender=()=>{const g=ge.now();this.renderScheduledAt<g&&(this.renderScheduledAt=g,G.render(this.render,!1,!0))};const{latestValues:u,renderState:d}=o;this.latestValues=u,this.baseTarget={...u},this.initialValues=n.initial?{...u}:{},this.renderState=d,this.parent=t,this.props=n,this.presenceContext=s,this.depth=t?t.depth+1:0,this.reducedMotionConfig=i,this.options=l,this.blockInitialAnimation=!!a,this.isControllingVariants=ys(n),this.isVariantNode=Wl(n),this.isVariantNode&&(this.variantChildren=new Set),this.manuallyAnimateOnMount=!!(t&&t.current);const{willChange:h,...f}=this.scrapeMotionValuesFromProps(n,{},this);for(const g in f){const y=f[g];u[g]!==void 0&&ue(y)&&y.set(u[g])}}mount(t){this.current=t,ty.set(t,this),this.projection&&!this.projection.instance&&this.projection.mount(t),this.parent&&this.isVariantNode&&!this.isControllingVariants&&(this.removeFromVariantTree=this.parent.addVariantChild(this)),this.values.forEach((n,s)=>this.bindToMotionValue(s,n)),iu.current||ey(),this.shouldReduceMotion=this.reducedMotionConfig==="never"?!1:this.reducedMotionConfig==="always"?!0:Pr.current,this.parent?.addChild(this),this.update(this.props,this.presenceContext)}unmount(){this.projection&&this.projection.unmount(),Xe(this.notifyUpdate),Xe(this.render),this.valueSubscriptions.forEach(t=>t()),this.valueSubscriptions.clear(),this.removeFromVariantTree&&this.removeFromVariantTree(),this.parent?.removeChild(this);for(const t in this.events)this.events[t].clear();for(const t in this.features){const n=this.features[t];n&&(n.unmount(),n.isMounted=!1)}this.current=null}addChild(t){this.children.add(t),this.enteringChildren??(this.enteringChildren=new Set),this.enteringChildren.add(t)}removeChild(t){this.children.delete(t),this.enteringChildren&&this.enteringChildren.delete(t)}bindToMotionValue(t,n){this.valueSubscriptions.has(t)&&this.valueSubscriptions.get(t)();const s=Dt.has(t);s&&this.onBindTransform&&this.onBindTransform();const i=n.on("change",o=>{this.latestValues[t]=o,this.props.onUpdate&&G.preRender(this.notifyUpdate),s&&this.projection&&(this.projection.isTransformDirty=!0),this.scheduleRender()});let a;window.MotionCheckAppearSync&&(a=window.MotionCheckAppearSync(this,t,n)),this.valueSubscriptions.set(t,()=>{i(),a&&a(),n.owner&&n.stop()})}sortNodePosition(t){return!this.current||!this.sortInstanceNodePosition||this.type!==t.type?0:this.sortInstanceNodePosition(this.current,t.current)}updateFeatures(){let t="animation";for(t in kt){const n=kt[t];if(!n)continue;const{isEnabled:s,Feature:i}=n;if(!this.features[t]&&i&&s(this.props)&&(this.features[t]=new i(this)),this.features[t]){const a=this.features[t];a.isMounted?a.update():(a.mount(),a.isMounted=!0)}}}triggerBuild(){this.build(this.renderState,this.latestValues,this.props)}measureViewportBox(){return this.current?this.measureInstanceViewportBox(this.current,this.props):ne()}getStaticValue(t){return this.latestValues[t]}setStaticValue(t,n){this.latestValues[t]=n}update(t,n){(t.transformTemplate||this.props.transformTemplate)&&this.scheduleRender(),this.prevProps=this.props,this.props=t,this.prevPresenceContext=this.presenceContext,this.presenceContext=n;for(let s=0;s<no.length;s++){const i=no[s];this.propEventSubscriptions[i]&&(this.propEventSubscriptions[i](),delete this.propEventSubscriptions[i]);const a="on"+i,o=t[a];o&&(this.propEventSubscriptions[i]=this.on(i,o))}this.prevMotionValues=ny(this,this.scrapeMotionValuesFromProps(t,this.prevProps,this),this.prevMotionValues),this.handleChildMotionValue&&this.handleChildMotionValue()}getProps(){return this.props}getVariant(t){return this.props.variants?this.props.variants[t]:void 0}getDefaultTransition(){return this.props.transition}getTransformPagePoint(){return this.props.transformPagePoint}getClosestVariantNode(){return this.isVariantNode?this:this.parent?this.parent.getClosestVariantNode():void 0}addVariantChild(t){const n=this.getClosestVariantNode();if(n)return n.variantChildren&&n.variantChildren.add(t),()=>n.variantChildren.delete(t)}addValue(t,n){const s=this.values.get(t);n!==s&&(s&&this.removeValue(t),this.bindToMotionValue(t,n),this.values.set(t,n),this.latestValues[t]=n.get())}removeValue(t){this.values.delete(t);const n=this.valueSubscriptions.get(t);n&&(n(),this.valueSubscriptions.delete(t)),delete this.latestValues[t],this.removeValueFromRenderState(t,this.renderState)}hasValue(t){return this.values.has(t)}getValue(t,n){if(this.props.values&&this.props.values[t])return this.props.values[t];let s=this.values.get(t);return s===void 0&&n!==void 0&&(s=_t(n===null?void 0:n,{owner:this}),this.addValue(t,s)),s}readValue(t,n){let s=this.latestValues[t]!==void 0||!this.current?this.latestValues[t]:this.getBaseTargetFromProps(this.props,t)??this.readValueFromInstance(this.current,t,this.options);return s!=null&&(typeof s=="string"&&(Jc(s)||Zc(s))?s=parseFloat(s):!ug(s)&&Ze.test(n)&&(s=Nl(t,n)),this.setBaseTarget(t,ue(s)?s.get():s)),ue(s)?s.get():s}setBaseTarget(t,n){this.baseTarget[t]=n}getBaseTarget(t){const{initial:n}=this.props;let s;if(typeof n=="string"||typeof n=="object"){const a=_i(this.props,n,this.presenceContext?.custom);a&&(s=a[t])}if(n&&s!==void 0)return s;const i=this.getBaseTargetFromProps(this.props,t);return i!==void 0&&!ue(i)?i:this.initialValues[t]!==void 0&&s===void 0?void 0:this.baseTarget[t]}on(t,n){return this.events[t]||(this.events[t]=new ii),this.events[t].add(n)}notify(t,...n){this.events[t]&&this.events[t].notify(...n)}scheduleRenderMicrotask(){Si.render(this.render)}}class au extends sy{constructor(){super(...arguments),this.KeyframeResolver=Xf}sortInstanceNodePosition(t,n){return t.compareDocumentPosition(n)&2?1:-1}getBaseTargetFromProps(t,n){return t.style?t.style[n]:void 0}removeValueFromRenderState(t,{vars:n,style:s}){delete n[t],delete s[t]}handleChildMotionValue(){this.childSubscription&&(this.childSubscription(),delete this.childSubscription);const{children:t}=this.props;ue(t)&&(this.childSubscription=t.on("change",n=>{this.current&&(this.current.textContent=`${n}`)}))}}function ou(e,{style:t,vars:n},s,i){const a=e.style;let o;for(o in t)a[o]=t[o];i?.applyProjectionStyles(a,s);for(o in n)a.setProperty(o,n[o])}function ry(e){return window.getComputedStyle(e)}class iy extends au{constructor(){super(...arguments),this.type="html",this.renderInstance=ou}readValueFromInstance(t,n){if(Dt.has(n))return this.projection?.isProjecting?wr(n):yf(t,n);{const s=ry(t),i=(ci(n)?s.getPropertyValue(n):s[n])||0;return typeof i=="string"?i.trim():i}}measureInstanceViewportBox(t,{transformPagePoint:n}){return ru(t,n)}build(t,n,s){xi(t,n,s.transformTemplate)}scrapeMotionValuesFromProps(t,n,s){return Ci(t,n,s)}}const cu=new Set(["baseFrequency","diffuseConstant","kernelMatrix","kernelUnitLength","keySplines","keyTimes","limitingConeAngle","markerHeight","markerWidth","numOctaves","targetX","targetY","surfaceScale","specularConstant","specularExponent","stdDeviation","tableValues","viewBox","gradientTransform","pathLength","startOffset","textLength","lengthAdjust"]);function ay(e,t,n,s){ou(e,t,void 0,s);for(const i in t.attrs)e.setAttribute(cu.has(i)?i:ki(i),t.attrs[i])}class oy extends au{constructor(){super(...arguments),this.type="svg",this.isSVGTag=!1,this.measureInstanceViewportBox=ne}getBaseTargetFromProps(t,n){return t[n]}readValueFromInstance(t,n){if(Dt.has(n)){const s=Ol(n);return s&&s.default||0}return n=cu.has(n)?n:ki(n),t.getAttribute(n)}scrapeMotionValuesFromProps(t,n,s){return Jl(t,n,s)}build(t,n,s){Gl(t,n,this.isSVGTag,s.transformTemplate,s.style)}renderInstance(t,n,s,i){ay(t,n,s,i)}mount(t){this.isSVGTag=Kl(t.tagName),super.mount(t)}}const cy=(e,t)=>Ai(e)?new oy(t):new iy(t,{allowProjection:e!==m.Fragment});function Et(e,t,n){const s=e.getProps();return _i(s,t,n!==void 0?n:s.custom,e)}const Mr=e=>Array.isArray(e);function ly(e,t,n){e.hasValue(t)?e.getValue(t).set(n):e.addValue(t,_t(n))}function uy(e){return Mr(e)?e[e.length-1]||0:e}function dy(e,t){const n=Et(e,t);let{transitionEnd:s={},transition:i={},...a}=n||{};a={...a,...s};for(const o in a){const l=uy(a[o]);ly(e,o,l)}}function my(e){return!!(ue(e)&&e.add)}function Or(e,t){const n=e.getValue("willChange");if(my(n))return n.add(t);if(!n&&We.WillChange){const s=new We.WillChange("auto");e.addValue("willChange",s),s.add(t)}}function lu(e){return e.props[Xl]}const hy=e=>e!==null;function py(e,{repeat:t,repeatType:n="loop"},s){const i=e.filter(hy),a=t&&n!=="loop"&&t%2===1?0:i.length-1;return i[a]}const fy={type:"spring",stiffness:500,damping:25,restSpeed:10},gy=e=>({type:"spring",stiffness:550,damping:e===0?2*Math.sqrt(550):30,restSpeed:10}),yy={type:"keyframes",duration:.8},vy={type:"keyframes",ease:[.25,.1,.35,1],duration:.3},Sy=(e,{keyframes:t})=>t.length>2?yy:Dt.has(e)?e.startsWith("scale")?gy(t[1]):fy:vy;function Ty({when:e,delay:t,delayChildren:n,staggerChildren:s,staggerDirection:i,repeat:a,repeatType:o,repeatDelay:l,from:u,elapsed:d,...h}){return!!Object.keys(h).length}const Ri=(e,t,n,s={},i,a)=>o=>{const l=yi(s,e)||{},u=l.delay||s.delay||0;let{elapsed:d=0}=s;d=d-Oe(u);const h={keyframes:Array.isArray(n)?n:[null,n],ease:"easeOut",velocity:t.getVelocity(),...l,delay:-d,onUpdate:g=>{t.set(g),l.onUpdate&&l.onUpdate(g)},onComplete:()=>{o(),l.onComplete&&l.onComplete()},name:e,motionValue:t,element:a?void 0:i};Ty(l)||Object.assign(h,Sy(e,h)),h.duration&&(h.duration=Oe(h.duration)),h.repeatDelay&&(h.repeatDelay=Oe(h.repeatDelay)),h.from!==void 0&&(h.keyframes[0]=h.from);let f=!1;if((h.type===!1||h.duration===0&&!h.repeatDelay)&&(_r(h),h.delay===0&&(f=!0)),(We.instantAnimations||We.skipAnimations)&&(f=!0,_r(h),h.delay=0),h.allowFlatten=!l.type&&!l.ease,f&&!a&&t.get()!==void 0){const g=py(h.keyframes,l);if(g!==void 0){G.update(()=>{h.onUpdate(g),h.onComplete()});return}}return l.isSync?new ps(h):new Vf(h)};function by({protectedKeys:e,needsAnimating:t},n){const s=e.hasOwnProperty(n)&&t[n]!==!0;return t[n]=!1,s}function uu(e,t,{delay:n=0,transitionOverride:s,type:i}={}){let{transition:a=e.getDefaultTransition(),transitionEnd:o,...l}=t;s&&(a=s);const u=[],d=i&&e.animationState&&e.animationState.getState()[i];for(const h in l){const f=e.getValue(h,e.latestValues[h]??null),g=l[h];if(g===void 0||d&&by(d,h))continue;const y={delay:n,...yi(a||{},h)},v=f.get();if(v!==void 0&&!f.isAnimating&&!Array.isArray(g)&&g===v&&!y.velocity)continue;let T=!1;if(window.MotionHandoffAnimation){const I=lu(e);if(I){const x=window.MotionHandoffAnimation(I,h,G);x!==null&&(y.startTime=x,T=!0)}}Or(e,h),f.start(Ri(h,f,g,e.shouldReduceMotion&&Rl.has(h)?{type:!1}:y,e,T));const b=f.animation;b&&u.push(b)}return o&&Promise.all(u).then(()=>{G.update(()=>{o&&dy(e,o)})}),u}function du(e,t,n,s=0,i=1){const a=Array.from(e).sort((d,h)=>d.sortNodePosition(h)).indexOf(t),o=e.size,l=(o-1)*s;return typeof n=="function"?n(a,o):i===1?a*s:l-a*s}function Nr(e,t,n={}){const s=Et(e,t,n.type==="exit"?e.presenceContext?.custom:void 0);let{transition:i=e.getDefaultTransition()||{}}=s||{};n.transitionOverride&&(i=n.transitionOverride);const a=s?()=>Promise.all(uu(e,s,n)):()=>Promise.resolve(),o=e.variantChildren&&e.variantChildren.size?(u=0)=>{const{delayChildren:d=0,staggerChildren:h,staggerDirection:f}=i;return wy(e,t,u,d,h,f,n)}:()=>Promise.resolve(),{when:l}=i;if(l){const[u,d]=l==="beforeChildren"?[a,o]:[o,a];return u().then(()=>d())}else return Promise.all([a(),o(n.delay)])}function wy(e,t,n=0,s=0,i=0,a=1,o){const l=[];for(const u of e.variantChildren)u.notify("AnimationStart",t),l.push(Nr(u,t,{...o,delay:n+(typeof s=="function"?0:s)+du(e.variantChildren,u,s,i,a)}).then(()=>u.notify("AnimationComplete",t)));return Promise.all(l)}function Iy(e,t,n={}){e.notify("AnimationStart",t);let s;if(Array.isArray(t)){const i=t.map(a=>Nr(e,a,n));s=Promise.all(i)}else if(typeof t=="string")s=Nr(e,t,n);else{const i=typeof t=="function"?Et(e,t,n.custom):t;s=Promise.all(uu(e,i,n))}return s.then(()=>{e.notify("AnimationComplete",t)})}function mu(e,t){if(!Array.isArray(t))return!1;const n=t.length;if(n!==e.length)return!1;for(let s=0;s<n;s++)if(t[s]!==e[s])return!1;return!0}const xy=Ii.length;function hu(e){if(!e)return;if(!e.isControllingVariants){const n=e.parent?hu(e.parent)||{}:{};return e.props.initial!==void 0&&(n.initial=e.props.initial),n}const t={};for(let n=0;n<xy;n++){const s=Ii[n],i=e.props[s];(fn(i)||i===!1)&&(t[s]=i)}return t}const Ey=[...wi].reverse(),Ay=wi.length;function _y(e){return t=>Promise.all(t.map(({animation:n,options:s})=>Iy(e,n,s)))}function Cy(e){let t=_y(e),n=so(),s=!0;const i=u=>(d,h)=>{const f=Et(e,h,u==="exit"?e.presenceContext?.custom:void 0);if(f){const{transition:g,transitionEnd:y,...v}=f;d={...d,...v,...y}}return d};function a(u){t=u(e)}function o(u){const{props:d}=e,h=hu(e.parent)||{},f=[],g=new Set;let y={},v=1/0;for(let b=0;b<Ay;b++){const I=Ey[b],x=n[I],w=d[I]!==void 0?d[I]:h[I],_=fn(w),A=I===u?x.isActive:null;A===!1&&(v=b);let k=w===h[I]&&w!==d[I]&&_;if(k&&s&&e.manuallyAnimateOnMount&&(k=!1),x.protectedKeys={...y},!x.isActive&&A===null||!w&&!x.prevProp||gs(w)||typeof w=="boolean")continue;const R=ky(x.prevProp,w);let P=R||I===u&&x.isActive&&!k&&_||b>v&&_,O=!1;const N=Array.isArray(w)?w:[w];let F=N.reduce(i(I),{});A===!1&&(F={});const{prevResolvedValues:Z={}}=x,z={...Z,...F},H=ee=>{P=!0,g.has(ee)&&(O=!0,g.delete(ee)),x.needsAnimating[ee]=!0;const W=e.getValue(ee);W&&(W.liveStyle=!1)};for(const ee in z){const W=F[ee],Y=Z[ee];if(y.hasOwnProperty(ee))continue;let Ce=!1;Mr(W)&&Mr(Y)?Ce=!mu(W,Y):Ce=W!==Y,Ce?W!=null?H(ee):g.add(ee):W!==void 0&&g.has(ee)?H(ee):x.protectedKeys[ee]=!0}x.prevProp=w,x.prevResolvedValues=F,x.isActive&&(y={...y,...F}),s&&e.blockInitialAnimation&&(P=!1);const Q=k&&R;P&&(!Q||O)&&f.push(...N.map(ee=>{const W={type:I};if(typeof ee=="string"&&s&&!Q&&e.manuallyAnimateOnMount&&e.parent){const{parent:Y}=e,Ce=Et(Y,ee);if(Y.enteringChildren&&Ce){const{delayChildren:Sd}=Ce.transition||{};W.delay=du(Y.enteringChildren,e,Sd)}}return{animation:ee,options:W}}))}if(g.size){const b={};if(typeof d.initial!="boolean"){const I=Et(e,Array.isArray(d.initial)?d.initial[0]:d.initial);I&&I.transition&&(b.transition=I.transition)}g.forEach(I=>{const x=e.getBaseTarget(I),w=e.getValue(I);w&&(w.liveStyle=!0),b[I]=x??null}),f.push({animation:b})}let T=!!f.length;return s&&(d.initial===!1||d.initial===d.animate)&&!e.manuallyAnimateOnMount&&(T=!1),s=!1,T?t(f):Promise.resolve()}function l(u,d){if(n[u].isActive===d)return Promise.resolve();e.variantChildren?.forEach(f=>f.animationState?.setActive(u,d)),n[u].isActive=d;const h=o(u);for(const f in n)n[f].protectedKeys={};return h}return{animateChanges:o,setActive:l,setAnimateFunction:a,getState:()=>n,reset:()=>{n=so()}}}function ky(e,t){return typeof t=="string"?t!==e:Array.isArray(t)?!mu(t,e):!1}function nt(e=!1){return{isActive:e,protectedKeys:{},needsAnimating:{},prevResolvedValues:{}}}function so(){return{animate:nt(!0),whileInView:nt(),whileHover:nt(),whileTap:nt(),whileDrag:nt(),whileFocus:nt(),exit:nt()}}class tt{constructor(t){this.isMounted=!1,this.node=t}update(){}}class Ry extends tt{constructor(t){super(t),t.animationState||(t.animationState=Cy(t))}updateAnimationControlsSubscription(){const{animate:t}=this.node.getProps();gs(t)&&(this.unmountControls=t.subscribe(this.node))}mount(){this.updateAnimationControlsSubscription()}update(){const{animate:t}=this.node.getProps(),{animate:n}=this.node.prevProps||{};t!==n&&this.updateAnimationControlsSubscription()}unmount(){this.node.animationState.reset(),this.unmountControls?.()}}let Py=0;class My extends tt{constructor(){super(...arguments),this.id=Py++}update(){if(!this.node.presenceContext)return;const{isPresent:t,onExitComplete:n}=this.node.presenceContext,{isPresent:s}=this.node.prevPresenceContext||{};if(!this.node.animationState||t===s)return;const i=this.node.animationState.setActive("exit",!t);n&&!t&&i.then(()=>{n(this.id)})}mount(){const{register:t,onExitComplete:n}=this.node.presenceContext||{};n&&n(this.id),t&&(this.unmount=t(this.id))}unmount(){}}const Oy={animation:{Feature:Ry},exit:{Feature:My}};function yn(e,t,n,s={passive:!0}){return e.addEventListener(t,n,s),()=>e.removeEventListener(t,n)}function Cn(e){return{point:{x:e.pageX,y:e.pageY}}}const Ny=e=>t=>Ti(t)&&e(t,Cn(t));function nn(e,t,n,s){return yn(e,t,Ny(n),s)}const pu=1e-4,$y=1-pu,Dy=1+pu,fu=.01,jy=0-fu,Ly=0+fu;function pe(e){return e.max-e.min}function Uy(e,t,n){return Math.abs(e-t)<=n}function ro(e,t,n,s=.5){e.origin=s,e.originPoint=K(t.min,t.max,e.origin),e.scale=pe(n)/pe(t),e.translate=K(n.min,n.max,e.origin)-e.originPoint,(e.scale>=$y&&e.scale<=Dy||isNaN(e.scale))&&(e.scale=1),(e.translate>=jy&&e.translate<=Ly||isNaN(e.translate))&&(e.translate=0)}function sn(e,t,n,s){ro(e.x,t.x,n.x,s?s.originX:void 0),ro(e.y,t.y,n.y,s?s.originY:void 0)}function io(e,t,n){e.min=n.min+t.min,e.max=e.min+pe(t)}function Vy(e,t,n){io(e.x,t.x,n.x),io(e.y,t.y,n.y)}function ao(e,t,n){e.min=t.min-n.min,e.max=e.min+pe(t)}function ts(e,t,n){ao(e.x,t.x,n.x),ao(e.y,t.y,n.y)}function be(e){return[e("x"),e("y")]}const gu=({current:e})=>e?e.ownerDocument.defaultView:null,oo=(e,t)=>Math.abs(e-t);function By(e,t){const n=oo(e.x,t.x),s=oo(e.y,t.y);return Math.sqrt(n**2+s**2)}class yu{constructor(t,n,{transformPagePoint:s,contextWindow:i=window,dragSnapToOrigin:a=!1,distanceThreshold:o=3}={}){if(this.startEvent=null,this.lastMoveEvent=null,this.lastMoveEventInfo=null,this.handlers={},this.contextWindow=window,this.updatePoint=()=>{if(!(this.lastMoveEvent&&this.lastMoveEventInfo))return;const g=Ls(this.lastMoveEventInfo,this.history),y=this.startEvent!==null,v=By(g.offset,{x:0,y:0})>=this.distanceThreshold;if(!y&&!v)return;const{point:T}=g,{timestamp:b}=ce;this.history.push({...T,timestamp:b});const{onStart:I,onMove:x}=this.handlers;y||(I&&I(this.lastMoveEvent,g),this.startEvent=this.lastMoveEvent),x&&x(this.lastMoveEvent,g)},this.handlePointerMove=(g,y)=>{this.lastMoveEvent=g,this.lastMoveEventInfo=js(y,this.transformPagePoint),G.update(this.updatePoint,!0)},this.handlePointerUp=(g,y)=>{this.end();const{onEnd:v,onSessionEnd:T,resumeAnimation:b}=this.handlers;if(this.dragSnapToOrigin&&b&&b(),!(this.lastMoveEvent&&this.lastMoveEventInfo))return;const I=Ls(g.type==="pointercancel"?this.lastMoveEventInfo:js(y,this.transformPagePoint),this.history);this.startEvent&&v&&v(g,I),T&&T(g,I)},!Ti(t))return;this.dragSnapToOrigin=a,this.handlers=n,this.transformPagePoint=s,this.distanceThreshold=o,this.contextWindow=i||window;const l=Cn(t),u=js(l,this.transformPagePoint),{point:d}=u,{timestamp:h}=ce;this.history=[{...d,timestamp:h}];const{onSessionStart:f}=n;f&&f(t,Ls(u,this.history)),this.removeListeners=En(nn(this.contextWindow,"pointermove",this.handlePointerMove),nn(this.contextWindow,"pointerup",this.handlePointerUp),nn(this.contextWindow,"pointercancel",this.handlePointerUp))}updateHandlers(t){this.handlers=t}end(){this.removeListeners&&this.removeListeners(),Xe(this.updatePoint)}}function js(e,t){return t?{point:t(e.point)}:e}function co(e,t){return{x:e.x-t.x,y:e.y-t.y}}function Ls({point:e},t){return{point:e,delta:co(e,vu(t)),offset:co(e,Fy(t)),velocity:qy(t,.1)}}function Fy(e){return e[0]}function vu(e){return e[e.length-1]}function qy(e,t){if(e.length<2)return{x:0,y:0};let n=e.length-1,s=null;const i=vu(e);for(;n>=0&&(s=e[n],!(i.timestamp-s.timestamp>Oe(t)));)n--;if(!s)return{x:0,y:0};const a=Ie(i.timestamp-s.timestamp);if(a===0)return{x:0,y:0};const o={x:(i.x-s.x)/a,y:(i.y-s.y)/a};return o.x===1/0&&(o.x=0),o.y===1/0&&(o.y=0),o}function Wy(e,{min:t,max:n},s){return t!==void 0&&e<t?e=s?K(t,e,s.min):Math.max(e,t):n!==void 0&&e>n&&(e=s?K(n,e,s.max):Math.min(e,n)),e}function lo(e,t,n){return{min:t!==void 0?e.min+t:void 0,max:n!==void 0?e.max+n-(e.max-e.min):void 0}}function zy(e,{top:t,left:n,bottom:s,right:i}){return{x:lo(e.x,n,i),y:lo(e.y,t,s)}}function uo(e,t){let n=t.min-e.min,s=t.max-e.max;return t.max-t.min<e.max-e.min&&([n,s]=[s,n]),{min:n,max:s}}function Hy(e,t){return{x:uo(e.x,t.x),y:uo(e.y,t.y)}}function Gy(e,t){let n=.5;const s=pe(e),i=pe(t);return i>s?n=mn(t.min,t.max-s,e.min):s>i&&(n=mn(e.min,e.max-i,t.min)),qe(0,1,n)}function Yy(e,t){const n={};return t.min!==void 0&&(n.min=t.min-e.min),t.max!==void 0&&(n.max=t.max-e.min),n}const $r=.35;function Ky(e=$r){return e===!1?e=0:e===!0&&(e=$r),{x:mo(e,"left","right"),y:mo(e,"top","bottom")}}function mo(e,t,n){return{min:ho(e,t),max:ho(e,n)}}function ho(e,t){return typeof e=="number"?e:e[t]||0}const Qy=new WeakMap;class Jy{constructor(t){this.openDragLock=null,this.isDragging=!1,this.currentDirection=null,this.originPoint={x:0,y:0},this.constraints=!1,this.hasMutatedConstraints=!1,this.elastic=ne(),this.latestPointerEvent=null,this.latestPanInfo=null,this.visualElement=t}start(t,{snapToCursor:n=!1,distanceThreshold:s}={}){const{presenceContext:i}=this.visualElement;if(i&&i.isPresent===!1)return;const a=f=>{const{dragSnapToOrigin:g}=this.getProps();g?this.pauseAnimation():this.stopAnimation(),n&&this.snapToCursor(Cn(f).point)},o=(f,g)=>{const{drag:y,dragPropagation:v,onDragStart:T}=this.getProps();if(y&&!v&&(this.openDragLock&&this.openDragLock(),this.openDragLock=ng(y),!this.openDragLock))return;this.latestPointerEvent=f,this.latestPanInfo=g,this.isDragging=!0,this.currentDirection=null,this.resolveConstraints(),this.visualElement.projection&&(this.visualElement.projection.isAnimationBlocked=!0,this.visualElement.projection.target=void 0),be(I=>{let x=this.getAxisMotionValue(I).get()||0;if(Ne.test(x)){const{projection:w}=this.visualElement;if(w&&w.layout){const _=w.layout.layoutBox[I];_&&(x=pe(_)*(parseFloat(x)/100))}}this.originPoint[I]=x}),T&&G.postRender(()=>T(f,g)),Or(this.visualElement,"transform");const{animationState:b}=this.visualElement;b&&b.setActive("whileDrag",!0)},l=(f,g)=>{this.latestPointerEvent=f,this.latestPanInfo=g;const{dragPropagation:y,dragDirectionLock:v,onDirectionLock:T,onDrag:b}=this.getProps();if(!y&&!this.openDragLock)return;const{offset:I}=g;if(v&&this.currentDirection===null){this.currentDirection=Xy(I),this.currentDirection!==null&&T&&T(this.currentDirection);return}this.updateAxis("x",g.point,I),this.updateAxis("y",g.point,I),this.visualElement.render(),b&&b(f,g)},u=(f,g)=>{this.latestPointerEvent=f,this.latestPanInfo=g,this.stop(f,g),this.latestPointerEvent=null,this.latestPanInfo=null},d=()=>be(f=>this.getAnimationState(f)==="paused"&&this.getAxisMotionValue(f).animation?.play()),{dragSnapToOrigin:h}=this.getProps();this.panSession=new yu(t,{onSessionStart:a,onStart:o,onMove:l,onSessionEnd:u,resumeAnimation:d},{transformPagePoint:this.visualElement.getTransformPagePoint(),dragSnapToOrigin:h,distanceThreshold:s,contextWindow:gu(this.visualElement)})}stop(t,n){const s=t||this.latestPointerEvent,i=n||this.latestPanInfo,a=this.isDragging;if(this.cancel(),!a||!i||!s)return;const{velocity:o}=i;this.startAnimation(o);const{onDragEnd:l}=this.getProps();l&&G.postRender(()=>l(s,i))}cancel(){this.isDragging=!1;const{projection:t,animationState:n}=this.visualElement;t&&(t.isAnimationBlocked=!1),this.panSession&&this.panSession.end(),this.panSession=void 0;const{dragPropagation:s}=this.getProps();!s&&this.openDragLock&&(this.openDragLock(),this.openDragLock=null),n&&n.setActive("whileDrag",!1)}updateAxis(t,n,s){const{drag:i}=this.getProps();if(!s||!Ln(t,i,this.currentDirection))return;const a=this.getAxisMotionValue(t);let o=this.originPoint[t]+s[t];this.constraints&&this.constraints[t]&&(o=Wy(o,this.constraints[t],this.elastic[t])),a.set(o)}resolveConstraints(){const{dragConstraints:t,dragElastic:n}=this.getProps(),s=this.visualElement.projection&&!this.visualElement.projection.layout?this.visualElement.projection.measure(!1):this.visualElement.projection?.layout,i=this.constraints;t&&yt(t)?this.constraints||(this.constraints=this.resolveRefConstraints()):t&&s?this.constraints=zy(s.layoutBox,t):this.constraints=!1,this.elastic=Ky(n),i!==this.constraints&&s&&this.constraints&&!this.hasMutatedConstraints&&be(a=>{this.constraints!==!1&&this.getAxisMotionValue(a)&&(this.constraints[a]=Yy(s.layoutBox[a],this.constraints[a]))})}resolveRefConstraints(){const{dragConstraints:t,onMeasureDragConstraints:n}=this.getProps();if(!t||!yt(t))return!1;const s=t.current,{projection:i}=this.visualElement;if(!i||!i.layout)return!1;const a=Zg(s,i.root,this.visualElement.getTransformPagePoint());let o=Hy(i.layout.layoutBox,a);if(n){const l=n(Qg(o));this.hasMutatedConstraints=!!l,l&&(o=tu(l))}return o}startAnimation(t){const{drag:n,dragMomentum:s,dragElastic:i,dragTransition:a,dragSnapToOrigin:o,onDragTransitionEnd:l}=this.getProps(),u=this.constraints||{},d=be(h=>{if(!Ln(h,n,this.currentDirection))return;let f=u&&u[h]||{};o&&(f={min:0,max:0});const g=i?200:1e6,y=i?40:1e7,v={type:"inertia",velocity:s?t[h]:0,bounceStiffness:g,bounceDamping:y,timeConstant:750,restDelta:1,restSpeed:10,...a,...f};return this.startAxisValueAnimation(h,v)});return Promise.all(d).then(l)}startAxisValueAnimation(t,n){const s=this.getAxisMotionValue(t);return Or(this.visualElement,t),s.start(Ri(t,s,0,n,this.visualElement,!1))}stopAnimation(){be(t=>this.getAxisMotionValue(t).stop())}pauseAnimation(){be(t=>this.getAxisMotionValue(t).animation?.pause())}getAnimationState(t){return this.getAxisMotionValue(t).animation?.state}getAxisMotionValue(t){const n=`_drag${t.toUpperCase()}`,s=this.visualElement.getProps(),i=s[n];return i||this.visualElement.getValue(t,(s.initial?s.initial[t]:void 0)||0)}snapToCursor(t){be(n=>{const{drag:s}=this.getProps();if(!Ln(n,s,this.currentDirection))return;const{projection:i}=this.visualElement,a=this.getAxisMotionValue(n);if(i&&i.layout){const{min:o,max:l}=i.layout.layoutBox[n];a.set(t[n]-K(o,l,.5))}})}scalePositionWithinConstraints(){if(!this.visualElement.current)return;const{drag:t,dragConstraints:n}=this.getProps(),{projection:s}=this.visualElement;if(!yt(n)||!s||!this.constraints)return;this.stopAnimation();const i={x:0,y:0};be(o=>{const l=this.getAxisMotionValue(o);if(l&&this.constraints!==!1){const u=l.get();i[o]=Gy({min:u,max:u},this.constraints[o])}});const{transformTemplate:a}=this.visualElement.getProps();this.visualElement.current.style.transform=a?a({},""):"none",s.root&&s.root.updateScroll(),s.updateLayout(),this.resolveConstraints(),be(o=>{if(!Ln(o,t,null))return;const l=this.getAxisMotionValue(o),{min:u,max:d}=this.constraints[o];l.set(K(u,d,i[o]))})}addListeners(){if(!this.visualElement.current)return;Qy.set(this.visualElement,this);const t=this.visualElement.current,n=nn(t,"pointerdown",u=>{const{drag:d,dragListener:h=!0}=this.getProps();d&&h&&this.start(u)}),s=()=>{const{dragConstraints:u}=this.getProps();yt(u)&&u.current&&(this.constraints=this.resolveRefConstraints())},{projection:i}=this.visualElement,a=i.addEventListener("measure",s);i&&!i.layout&&(i.root&&i.root.updateScroll(),i.updateLayout()),G.read(s);const o=yn(window,"resize",()=>this.scalePositionWithinConstraints()),l=i.addEventListener("didUpdate",({delta:u,hasLayoutChanged:d})=>{this.isDragging&&d&&(be(h=>{const f=this.getAxisMotionValue(h);f&&(this.originPoint[h]+=u[h].translate,f.set(f.get()+u[h].translate))}),this.visualElement.render())});return()=>{o(),n(),a(),l&&l()}}getProps(){const t=this.visualElement.getProps(),{drag:n=!1,dragDirectionLock:s=!1,dragPropagation:i=!1,dragConstraints:a=!1,dragElastic:o=$r,dragMomentum:l=!0}=t;return{...t,drag:n,dragDirectionLock:s,dragPropagation:i,dragConstraints:a,dragElastic:o,dragMomentum:l}}}function Ln(e,t,n){return(t===!0||t===e)&&(n===null||n===e)}function Xy(e,t=10){let n=null;return Math.abs(e.y)>t?n="y":Math.abs(e.x)>t&&(n="x"),n}class Zy extends tt{constructor(t){super(t),this.removeGroupControls=xe,this.removeListeners=xe,this.controls=new Jy(t)}mount(){const{dragControls:t}=this.node.getProps();t&&(this.removeGroupControls=t.subscribe(this.controls)),this.removeListeners=this.controls.addListeners()||xe}unmount(){this.removeGroupControls(),this.removeListeners()}}const po=e=>(t,n)=>{e&&G.postRender(()=>e(t,n))};class e0 extends tt{constructor(){super(...arguments),this.removePointerDownListener=xe}onPointerDown(t){this.session=new yu(t,this.createPanHandlers(),{transformPagePoint:this.node.getTransformPagePoint(),contextWindow:gu(this.node)})}createPanHandlers(){const{onPanSessionStart:t,onPanStart:n,onPan:s,onPanEnd:i}=this.node.getProps();return{onSessionStart:po(t),onStart:po(n),onMove:s,onEnd:(a,o)=>{delete this.session,i&&G.postRender(()=>i(a,o))}}}mount(){this.removePointerDownListener=nn(this.node.current,"pointerdown",t=>this.onPointerDown(t))}update(){this.session&&this.session.updateHandlers(this.createPanHandlers())}unmount(){this.removePointerDownListener(),this.session&&this.session.end()}}const Yn={hasAnimatedSinceResize:!0,hasEverUpdated:!1};let Us=!1;class t0 extends m.Component{componentDidMount(){const{visualElement:t,layoutGroup:n,switchLayoutGroup:s,layoutId:i}=this.props,{projection:a}=t;a&&(n.group&&n.group.add(a),s&&s.register&&i&&s.register(a),Us&&a.root.didUpdate(),a.addEventListener("animationComplete",()=>{this.safeToRemove()}),a.setOptions({...a.options,onExitComplete:()=>this.safeToRemove()})),Yn.hasEverUpdated=!0}getSnapshotBeforeUpdate(t){const{layoutDependency:n,visualElement:s,drag:i,isPresent:a}=this.props,{projection:o}=s;return o&&(o.isPresent=a,Us=!0,i||t.layoutDependency!==n||n===void 0||t.isPresent!==a?o.willUpdate():this.safeToRemove(),t.isPresent!==a&&(a?o.promote():o.relegate()||G.postRender(()=>{const l=o.getStack();(!l||!l.members.length)&&this.safeToRemove()}))),null}componentDidUpdate(){const{projection:t}=this.props.visualElement;t&&(t.root.didUpdate(),Si.postRender(()=>{!t.currentAnimation&&t.isLead()&&this.safeToRemove()}))}componentWillUnmount(){const{visualElement:t,layoutGroup:n,switchLayoutGroup:s}=this.props,{projection:i}=t;Us=!0,i&&(i.scheduleCheckAfterUnmount(),n&&n.group&&n.group.remove(i),s&&s.deregister&&s.deregister(i))}safeToRemove(){const{safeToRemove:t}=this.props;t&&t()}render(){return null}}function Su(e){const[t,n]=Bl(),s=m.useContext(Xr);return c.jsx(t0,{...e,layoutGroup:s,switchLayoutGroup:m.useContext(Zl),isPresent:t,safeToRemove:n})}function n0(e,t,n){const s=ue(e)?e:_t(e);return s.start(Ri("",s,t,n)),s.animation}const s0=(e,t)=>e.depth-t.depth;class r0{constructor(){this.children=[],this.isDirty=!1}add(t){ti(this.children,t),this.isDirty=!0}remove(t){ni(this.children,t),this.isDirty=!0}forEach(t){this.isDirty&&this.children.sort(s0),this.isDirty=!1,this.children.forEach(t)}}function i0(e,t){const n=ge.now(),s=({timestamp:i})=>{const a=i-n;a>=t&&(Xe(s),e(a-t))};return G.setup(s,!0),()=>Xe(s)}const Tu=["TopLeft","TopRight","BottomLeft","BottomRight"],a0=Tu.length,fo=e=>typeof e=="string"?parseFloat(e):e,go=e=>typeof e=="number"||L.test(e);function o0(e,t,n,s,i,a){i?(e.opacity=K(0,n.opacity??1,c0(s)),e.opacityExit=K(t.opacity??1,0,l0(s))):a&&(e.opacity=K(t.opacity??1,n.opacity??1,s));for(let o=0;o<a0;o++){const l=`border${Tu[o]}Radius`;let u=yo(t,l),d=yo(n,l);if(u===void 0&&d===void 0)continue;u||(u=0),d||(d=0),u===0||d===0||go(u)===go(d)?(e[l]=Math.max(K(fo(u),fo(d),s),0),(Ne.test(d)||Ne.test(u))&&(e[l]+="%")):e[l]=d}(t.rotate||n.rotate)&&(e.rotate=K(t.rotate||0,n.rotate||0,s))}function yo(e,t){return e[t]!==void 0?e[t]:e.borderRadius}const c0=bu(0,.5,ol),l0=bu(.5,.95,xe);function bu(e,t,n){return s=>s<e?0:s>t?1:n(mn(e,t,s))}function vo(e,t){e.min=t.min,e.max=t.max}function Ee(e,t){vo(e.x,t.x),vo(e.y,t.y)}function So(e,t){e.translate=t.translate,e.scale=t.scale,e.originPoint=t.originPoint,e.origin=t.origin}function To(e,t,n,s,i){return e-=t,e=es(e,1/n,s),i!==void 0&&(e=es(e,1/i,s)),e}function u0(e,t=0,n=1,s=.5,i,a=e,o=e){if(Ne.test(t)&&(t=parseFloat(t),t=K(o.min,o.max,t/100)-o.min),typeof t!="number")return;let l=K(a.min,a.max,s);e===a&&(l-=t),e.min=To(e.min,t,n,l,i),e.max=To(e.max,t,n,l,i)}function bo(e,t,[n,s,i],a,o){u0(e,t[n],t[s],t[i],t.scale,a,o)}const d0=["x","scaleX","originX"],m0=["y","scaleY","originY"];function wo(e,t,n,s){bo(e.x,t,d0,n?n.x:void 0,s?s.x:void 0),bo(e.y,t,m0,n?n.y:void 0,s?s.y:void 0)}function Io(e){return e.translate===0&&e.scale===1}function wu(e){return Io(e.x)&&Io(e.y)}function xo(e,t){return e.min===t.min&&e.max===t.max}function h0(e,t){return xo(e.x,t.x)&&xo(e.y,t.y)}function Eo(e,t){return Math.round(e.min)===Math.round(t.min)&&Math.round(e.max)===Math.round(t.max)}function Iu(e,t){return Eo(e.x,t.x)&&Eo(e.y,t.y)}function Ao(e){return pe(e.x)/pe(e.y)}function _o(e,t){return e.translate===t.translate&&e.scale===t.scale&&e.originPoint===t.originPoint}class p0{constructor(){this.members=[]}add(t){ti(this.members,t),t.scheduleRender()}remove(t){if(ni(this.members,t),t===this.prevLead&&(this.prevLead=void 0),t===this.lead){const n=this.members[this.members.length-1];n&&this.promote(n)}}relegate(t){const n=this.members.findIndex(i=>t===i);if(n===0)return!1;let s;for(let i=n;i>=0;i--){const a=this.members[i];if(a.isPresent!==!1){s=a;break}}return s?(this.promote(s),!0):!1}promote(t,n){const s=this.lead;if(t!==s&&(this.prevLead=s,this.lead=t,t.show(),s)){s.instance&&s.scheduleRender(),t.scheduleRender(),t.resumeFrom=s,n&&(t.resumeFrom.preserveOpacity=!0),s.snapshot&&(t.snapshot=s.snapshot,t.snapshot.latestValues=s.animationValues||s.latestValues),t.root&&t.root.isUpdating&&(t.isLayoutDirty=!0);const{crossfade:i}=t.options;i===!1&&s.hide()}}exitAnimationComplete(){this.members.forEach(t=>{const{options:n,resumingFrom:s}=t;n.onExitComplete&&n.onExitComplete(),s&&s.options.onExitComplete&&s.options.onExitComplete()})}scheduleRender(){this.members.forEach(t=>{t.instance&&t.scheduleRender(!1)})}removeLeadSnapshot(){this.lead&&this.lead.snapshot&&(this.lead.snapshot=void 0)}}function f0(e,t,n){let s="";const i=e.x.translate/t.x,a=e.y.translate/t.y,o=n?.z||0;if((i||a||o)&&(s=`translate3d(${i}px, ${a}px, ${o}px) `),(t.x!==1||t.y!==1)&&(s+=`scale(${1/t.x}, ${1/t.y}) `),n){const{transformPerspective:d,rotate:h,rotateX:f,rotateY:g,skewX:y,skewY:v}=n;d&&(s=`perspective(${d}px) ${s}`),h&&(s+=`rotate(${h}deg) `),f&&(s+=`rotateX(${f}deg) `),g&&(s+=`rotateY(${g}deg) `),y&&(s+=`skewX(${y}deg) `),v&&(s+=`skewY(${v}deg) `)}const l=e.x.scale*t.x,u=e.y.scale*t.y;return(l!==1||u!==1)&&(s+=`scale(${l}, ${u})`),s||"none"}const it={nodes:0,calculatedTargetDeltas:0,calculatedProjections:0},Vs=["","X","Y","Z"],g0=1e3;let y0=0;function Bs(e,t,n,s){const{latestValues:i}=t;i[e]&&(n[e]=i[e],t.setStaticValue(e,0),s&&(s[e]=0))}function xu(e){if(e.hasCheckedOptimisedAppear=!0,e.root===e)return;const{visualElement:t}=e.options;if(!t)return;const n=lu(t);if(window.MotionHasOptimisedAnimation(n,"transform")){const{layout:i,layoutId:a}=e.options;window.MotionCancelOptimisedAnimation(n,"transform",G,!(i||a))}const{parent:s}=e;s&&!s.hasCheckedOptimisedAppear&&xu(s)}function Eu({attachResizeListener:e,defaultParent:t,measureScroll:n,checkIsScrollRoot:s,resetTransform:i}){return class{constructor(o={},l=t?.()){this.id=y0++,this.animationId=0,this.animationCommitId=0,this.children=new Set,this.options={},this.isTreeAnimating=!1,this.isAnimationBlocked=!1,this.isLayoutDirty=!1,this.isProjectionDirty=!1,this.isSharedProjectionDirty=!1,this.isTransformDirty=!1,this.updateManuallyBlocked=!1,this.updateBlockedByResize=!1,this.isUpdating=!1,this.isSVG=!1,this.needsReset=!1,this.shouldResetTransform=!1,this.hasCheckedOptimisedAppear=!1,this.treeScale={x:1,y:1},this.eventHandlers=new Map,this.hasTreeAnimated=!1,this.layoutVersion=0,this.updateScheduled=!1,this.scheduleUpdate=()=>this.update(),this.projectionUpdateScheduled=!1,this.checkUpdateFailed=()=>{this.isUpdating&&(this.isUpdating=!1,this.clearAllSnapshots())},this.updateProjection=()=>{this.projectionUpdateScheduled=!1,Me.value&&(it.nodes=it.calculatedTargetDeltas=it.calculatedProjections=0),this.nodes.forEach(T0),this.nodes.forEach(x0),this.nodes.forEach(E0),this.nodes.forEach(b0),Me.addProjectionMetrics&&Me.addProjectionMetrics(it)},this.resolvedRelativeTargetAt=0,this.linkedParentVersion=0,this.hasProjected=!1,this.isVisible=!0,this.animationProgress=0,this.sharedNodes=new Map,this.latestValues=o,this.root=l?l.root||l:this,this.path=l?[...l.path,l]:[],this.parent=l,this.depth=l?l.depth+1:0;for(let u=0;u<this.path.length;u++)this.path[u].shouldResetTransform=!0;this.root===this&&(this.nodes=new r0)}addEventListener(o,l){return this.eventHandlers.has(o)||this.eventHandlers.set(o,new ii),this.eventHandlers.get(o).add(l)}notifyListeners(o,...l){const u=this.eventHandlers.get(o);u&&u.notify(...l)}hasListeners(o){return this.eventHandlers.has(o)}mount(o){if(this.instance)return;this.isSVG=Vl(o)&&!cg(o),this.instance=o;const{layoutId:l,layout:u,visualElement:d}=this.options;if(d&&!d.current&&d.mount(o),this.root.nodes.add(this),this.parent&&this.parent.children.add(this),this.root.hasTreeAnimated&&(u||l)&&(this.isLayoutDirty=!0),e){let h,f=0;const g=()=>this.root.updateBlockedByResize=!1;G.read(()=>{f=window.innerWidth}),e(o,()=>{const y=window.innerWidth;y!==f&&(f=y,this.root.updateBlockedByResize=!0,h&&h(),h=i0(g,250),Yn.hasAnimatedSinceResize&&(Yn.hasAnimatedSinceResize=!1,this.nodes.forEach(Ro)))})}l&&this.root.registerSharedNode(l,this),this.options.animate!==!1&&d&&(l||u)&&this.addEventListener("didUpdate",({delta:h,hasLayoutChanged:f,hasRelativeLayoutChanged:g,layout:y})=>{if(this.isTreeAnimationBlocked()){this.target=void 0,this.relativeTarget=void 0;return}const v=this.options.transition||d.getDefaultTransition()||R0,{onLayoutAnimationStart:T,onLayoutAnimationComplete:b}=d.getProps(),I=!this.targetLayout||!Iu(this.targetLayout,y),x=!f&&g;if(this.options.layoutRoot||this.resumeFrom||x||f&&(I||!this.currentAnimation)){this.resumeFrom&&(this.resumingFrom=this.resumeFrom,this.resumingFrom.resumingFrom=void 0);const w={...yi(v,"layout"),onPlay:T,onComplete:b};(d.shouldReduceMotion||this.options.layoutRoot)&&(w.delay=0,w.type=!1),this.startAnimation(w),this.setAnimationOrigin(h,x)}else f||Ro(this),this.isLead()&&this.options.onExitComplete&&this.options.onExitComplete();this.targetLayout=y})}unmount(){this.options.layoutId&&this.willUpdate(),this.root.nodes.remove(this);const o=this.getStack();o&&o.remove(this),this.parent&&this.parent.children.delete(this),this.instance=void 0,this.eventHandlers.clear(),Xe(this.updateProjection)}blockUpdate(){this.updateManuallyBlocked=!0}unblockUpdate(){this.updateManuallyBlocked=!1}isUpdateBlocked(){return this.updateManuallyBlocked||this.updateBlockedByResize}isTreeAnimationBlocked(){return this.isAnimationBlocked||this.parent&&this.parent.isTreeAnimationBlocked()||!1}startUpdate(){this.isUpdateBlocked()||(this.isUpdating=!0,this.nodes&&this.nodes.forEach(A0),this.animationId++)}getTransformTemplate(){const{visualElement:o}=this.options;return o&&o.getProps().transformTemplate}willUpdate(o=!0){if(this.root.hasTreeAnimated=!0,this.root.isUpdateBlocked()){this.options.onExitComplete&&this.options.onExitComplete();return}if(window.MotionCancelOptimisedAnimation&&!this.hasCheckedOptimisedAppear&&xu(this),!this.root.isUpdating&&this.root.startUpdate(),this.isLayoutDirty)return;this.isLayoutDirty=!0;for(let h=0;h<this.path.length;h++){const f=this.path[h];f.shouldResetTransform=!0,f.updateScroll("snapshot"),f.options.layoutRoot&&f.willUpdate(!1)}const{layoutId:l,layout:u}=this.options;if(l===void 0&&!u)return;const d=this.getTransformTemplate();this.prevTransformTemplateValue=d?d(this.latestValues,""):void 0,this.updateSnapshot(),o&&this.notifyListeners("willUpdate")}update(){if(this.updateScheduled=!1,this.isUpdateBlocked()){this.unblockUpdate(),this.clearAllSnapshots(),this.nodes.forEach(Co);return}if(this.animationId<=this.animationCommitId){this.nodes.forEach(ko);return}this.animationCommitId=this.animationId,this.isUpdating?(this.isUpdating=!1,this.nodes.forEach(I0),this.nodes.forEach(v0),this.nodes.forEach(S0)):this.nodes.forEach(ko),this.clearAllSnapshots();const l=ge.now();ce.delta=qe(0,1e3/60,l-ce.timestamp),ce.timestamp=l,ce.isProcessing=!0,ks.update.process(ce),ks.preRender.process(ce),ks.render.process(ce),ce.isProcessing=!1}didUpdate(){this.updateScheduled||(this.updateScheduled=!0,Si.read(this.scheduleUpdate))}clearAllSnapshots(){this.nodes.forEach(w0),this.sharedNodes.forEach(_0)}scheduleUpdateProjection(){this.projectionUpdateScheduled||(this.projectionUpdateScheduled=!0,G.preRender(this.updateProjection,!1,!0))}scheduleCheckAfterUnmount(){G.postRender(()=>{this.isLayoutDirty?this.root.didUpdate():this.root.checkUpdateFailed()})}updateSnapshot(){this.snapshot||!this.instance||(this.snapshot=this.measure(),this.snapshot&&!pe(this.snapshot.measuredBox.x)&&!pe(this.snapshot.measuredBox.y)&&(this.snapshot=void 0))}updateLayout(){if(!this.instance||(this.updateScroll(),!(this.options.alwaysMeasureLayout&&this.isLead())&&!this.isLayoutDirty))return;if(this.resumeFrom&&!this.resumeFrom.instance)for(let u=0;u<this.path.length;u++)this.path[u].updateScroll();const o=this.layout;this.layout=this.measure(!1),this.layoutVersion++,this.layoutCorrected=ne(),this.isLayoutDirty=!1,this.projectionDelta=void 0,this.notifyListeners("measure",this.layout.layoutBox);const{visualElement:l}=this.options;l&&l.notify("LayoutMeasure",this.layout.layoutBox,o?o.layoutBox:void 0)}updateScroll(o="measure"){let l=!!(this.options.layoutScroll&&this.instance);if(this.scroll&&this.scroll.animationId===this.root.animationId&&this.scroll.phase===o&&(l=!1),l&&this.instance){const u=s(this.instance);this.scroll={animationId:this.root.animationId,phase:o,isRoot:u,offset:n(this.instance),wasRoot:this.scroll?this.scroll.isRoot:u}}}resetTransform(){if(!i)return;const o=this.isLayoutDirty||this.shouldResetTransform||this.options.alwaysMeasureLayout,l=this.projectionDelta&&!wu(this.projectionDelta),u=this.getTransformTemplate(),d=u?u(this.latestValues,""):void 0,h=d!==this.prevTransformTemplateValue;o&&this.instance&&(l||rt(this.latestValues)||h)&&(i(this.instance,d),this.shouldResetTransform=!1,this.scheduleRender())}measure(o=!0){const l=this.measurePageBox();let u=this.removeElementScroll(l);return o&&(u=this.removeTransform(u)),P0(u),{animationId:this.root.animationId,measuredBox:l,layoutBox:u,latestValues:{},source:this.id}}measurePageBox(){const{visualElement:o}=this.options;if(!o)return ne();const l=o.measureViewportBox();if(!(this.scroll?.wasRoot||this.path.some(M0))){const{scroll:d}=this.root;d&&(vt(l.x,d.offset.x),vt(l.y,d.offset.y))}return l}removeElementScroll(o){const l=ne();if(Ee(l,o),this.scroll?.wasRoot)return l;for(let u=0;u<this.path.length;u++){const d=this.path[u],{scroll:h,options:f}=d;d!==this.root&&h&&f.layoutScroll&&(h.wasRoot&&Ee(l,o),vt(l.x,h.offset.x),vt(l.y,h.offset.y))}return l}applyTransform(o,l=!1){const u=ne();Ee(u,o);for(let d=0;d<this.path.length;d++){const h=this.path[d];!l&&h.options.layoutScroll&&h.scroll&&h!==h.root&&St(u,{x:-h.scroll.offset.x,y:-h.scroll.offset.y}),rt(h.latestValues)&&St(u,h.latestValues)}return rt(this.latestValues)&&St(u,this.latestValues),u}removeTransform(o){const l=ne();Ee(l,o);for(let u=0;u<this.path.length;u++){const d=this.path[u];if(!d.instance||!rt(d.latestValues))continue;kr(d.latestValues)&&d.updateSnapshot();const h=ne(),f=d.measurePageBox();Ee(h,f),wo(l,d.latestValues,d.snapshot?d.snapshot.layoutBox:void 0,h)}return rt(this.latestValues)&&wo(l,this.latestValues),l}setTargetDelta(o){this.targetDelta=o,this.root.scheduleUpdateProjection(),this.isProjectionDirty=!0}setOptions(o){this.options={...this.options,...o,crossfade:o.crossfade!==void 0?o.crossfade:!0}}clearMeasurements(){this.scroll=void 0,this.layout=void 0,this.snapshot=void 0,this.prevTransformTemplateValue=void 0,this.targetDelta=void 0,this.target=void 0,this.isLayoutDirty=!1}forceRelativeParentToResolveTarget(){this.relativeParent&&this.relativeParent.resolvedRelativeTargetAt!==ce.timestamp&&this.relativeParent.resolveTargetDelta(!0)}resolveTargetDelta(o=!1){const l=this.getLead();this.isProjectionDirty||(this.isProjectionDirty=l.isProjectionDirty),this.isTransformDirty||(this.isTransformDirty=l.isTransformDirty),this.isSharedProjectionDirty||(this.isSharedProjectionDirty=l.isSharedProjectionDirty);const u=!!this.resumingFrom||this!==l;if(!(o||u&&this.isSharedProjectionDirty||this.isProjectionDirty||this.parent?.isProjectionDirty||this.attemptToResolveRelativeTarget||this.root.updateBlockedByResize))return;const{layout:h,layoutId:f}=this.options;if(!this.layout||!(h||f))return;this.resolvedRelativeTargetAt=ce.timestamp;const g=this.getClosestProjectingParent();g&&this.linkedParentVersion!==g.layoutVersion&&!g.options.layoutRoot&&this.removeRelativeTarget(),!this.targetDelta&&!this.relativeTarget&&(g&&g.layout?this.createRelativeTarget(g,this.layout.layoutBox,g.layout.layoutBox):this.removeRelativeTarget()),!(!this.relativeTarget&&!this.targetDelta)&&(this.target||(this.target=ne(),this.targetWithTransforms=ne()),this.relativeTarget&&this.relativeTargetOrigin&&this.relativeParent&&this.relativeParent.target?(this.forceRelativeParentToResolveTarget(),Vy(this.target,this.relativeTarget,this.relativeParent.target)):this.targetDelta?(this.resumingFrom?this.target=this.applyTransform(this.layout.layoutBox):Ee(this.target,this.layout.layoutBox),su(this.target,this.targetDelta)):Ee(this.target,this.layout.layoutBox),this.attemptToResolveRelativeTarget&&(this.attemptToResolveRelativeTarget=!1,g&&!!g.resumingFrom==!!this.resumingFrom&&!g.options.layoutScroll&&g.target&&this.animationProgress!==1?this.createRelativeTarget(g,this.target,g.target):this.relativeParent=this.relativeTarget=void 0),Me.value&&it.calculatedTargetDeltas++)}getClosestProjectingParent(){if(!(!this.parent||kr(this.parent.latestValues)||nu(this.parent.latestValues)))return this.parent.isProjecting()?this.parent:this.parent.getClosestProjectingParent()}isProjecting(){return!!((this.relativeTarget||this.targetDelta||this.options.layoutRoot)&&this.layout)}createRelativeTarget(o,l,u){this.relativeParent=o,this.linkedParentVersion=o.layoutVersion,this.forceRelativeParentToResolveTarget(),this.relativeTarget=ne(),this.relativeTargetOrigin=ne(),ts(this.relativeTargetOrigin,l,u),Ee(this.relativeTarget,this.relativeTargetOrigin)}removeRelativeTarget(){this.relativeParent=this.relativeTarget=void 0}calcProjection(){const o=this.getLead(),l=!!this.resumingFrom||this!==o;let u=!0;if((this.isProjectionDirty||this.parent?.isProjectionDirty)&&(u=!1),l&&(this.isSharedProjectionDirty||this.isTransformDirty)&&(u=!1),this.resolvedRelativeTargetAt===ce.timestamp&&(u=!1),u)return;const{layout:d,layoutId:h}=this.options;if(this.isTreeAnimating=!!(this.parent&&this.parent.isTreeAnimating||this.currentAnimation||this.pendingAnimation),this.isTreeAnimating||(this.targetDelta=this.relativeTarget=void 0),!this.layout||!(d||h))return;Ee(this.layoutCorrected,this.layout.layoutBox);const f=this.treeScale.x,g=this.treeScale.y;Xg(this.layoutCorrected,this.treeScale,this.path,l),o.layout&&!o.target&&(this.treeScale.x!==1||this.treeScale.y!==1)&&(o.target=o.layout.layoutBox,o.targetWithTransforms=ne());const{target:y}=o;if(!y){this.prevProjectionDelta&&(this.createProjectionDeltas(),this.scheduleRender());return}!this.projectionDelta||!this.prevProjectionDelta?this.createProjectionDeltas():(So(this.prevProjectionDelta.x,this.projectionDelta.x),So(this.prevProjectionDelta.y,this.projectionDelta.y)),sn(this.projectionDelta,this.layoutCorrected,y,this.latestValues),(this.treeScale.x!==f||this.treeScale.y!==g||!_o(this.projectionDelta.x,this.prevProjectionDelta.x)||!_o(this.projectionDelta.y,this.prevProjectionDelta.y))&&(this.hasProjected=!0,this.scheduleRender(),this.notifyListeners("projectionUpdate",y)),Me.value&&it.calculatedProjections++}hide(){this.isVisible=!1}show(){this.isVisible=!0}scheduleRender(o=!0){if(this.options.visualElement?.scheduleRender(),o){const l=this.getStack();l&&l.scheduleRender()}this.resumingFrom&&!this.resumingFrom.instance&&(this.resumingFrom=void 0)}createProjectionDeltas(){this.prevProjectionDelta=Tt(),this.projectionDelta=Tt(),this.projectionDeltaWithTransform=Tt()}setAnimationOrigin(o,l=!1){const u=this.snapshot,d=u?u.latestValues:{},h={...this.latestValues},f=Tt();(!this.relativeParent||!this.relativeParent.options.layoutRoot)&&(this.relativeTarget=this.relativeTargetOrigin=void 0),this.attemptToResolveRelativeTarget=!l;const g=ne(),y=u?u.source:void 0,v=this.layout?this.layout.source:void 0,T=y!==v,b=this.getStack(),I=!b||b.members.length<=1,x=!!(T&&!I&&this.options.crossfade===!0&&!this.path.some(k0));this.animationProgress=0;let w;this.mixTargetDelta=_=>{const A=_/1e3;Po(f.x,o.x,A),Po(f.y,o.y,A),this.setTargetDelta(f),this.relativeTarget&&this.relativeTargetOrigin&&this.layout&&this.relativeParent&&this.relativeParent.layout&&(ts(g,this.layout.layoutBox,this.relativeParent.layout.layoutBox),C0(this.relativeTarget,this.relativeTargetOrigin,g,A),w&&h0(this.relativeTarget,w)&&(this.isProjectionDirty=!1),w||(w=ne()),Ee(w,this.relativeTarget)),T&&(this.animationValues=h,o0(h,d,this.latestValues,A,x,I)),this.root.scheduleUpdateProjection(),this.scheduleRender(),this.animationProgress=A},this.mixTargetDelta(this.options.layoutRoot?1e3:0)}startAnimation(o){this.notifyListeners("animationStart"),this.currentAnimation?.stop(),this.resumingFrom?.currentAnimation?.stop(),this.pendingAnimation&&(Xe(this.pendingAnimation),this.pendingAnimation=void 0),this.pendingAnimation=G.update(()=>{Yn.hasAnimatedSinceResize=!0,ut.layout++,this.motionValue||(this.motionValue=_t(0)),this.currentAnimation=n0(this.motionValue,[0,1e3],{...o,velocity:0,isSync:!0,onUpdate:l=>{this.mixTargetDelta(l),o.onUpdate&&o.onUpdate(l)},onStop:()=>{ut.layout--},onComplete:()=>{ut.layout--,o.onComplete&&o.onComplete(),this.completeAnimation()}}),this.resumingFrom&&(this.resumingFrom.currentAnimation=this.currentAnimation),this.pendingAnimation=void 0})}completeAnimation(){this.resumingFrom&&(this.resumingFrom.currentAnimation=void 0,this.resumingFrom.preserveOpacity=void 0);const o=this.getStack();o&&o.exitAnimationComplete(),this.resumingFrom=this.currentAnimation=this.animationValues=void 0,this.notifyListeners("animationComplete")}finishAnimation(){this.currentAnimation&&(this.mixTargetDelta&&this.mixTargetDelta(g0),this.currentAnimation.stop()),this.completeAnimation()}applyTransformsToTarget(){const o=this.getLead();let{targetWithTransforms:l,target:u,layout:d,latestValues:h}=o;if(!(!l||!u||!d)){if(this!==o&&this.layout&&d&&Au(this.options.animationType,this.layout.layoutBox,d.layoutBox)){u=this.target||ne();const f=pe(this.layout.layoutBox.x);u.x.min=o.target.x.min,u.x.max=u.x.min+f;const g=pe(this.layout.layoutBox.y);u.y.min=o.target.y.min,u.y.max=u.y.min+g}Ee(l,u),St(l,h),sn(this.projectionDeltaWithTransform,this.layoutCorrected,l,h)}}registerSharedNode(o,l){this.sharedNodes.has(o)||this.sharedNodes.set(o,new p0),this.sharedNodes.get(o).add(l);const d=l.options.initialPromotionConfig;l.promote({transition:d?d.transition:void 0,preserveFollowOpacity:d&&d.shouldPreserveFollowOpacity?d.shouldPreserveFollowOpacity(l):void 0})}isLead(){const o=this.getStack();return o?o.lead===this:!0}getLead(){const{layoutId:o}=this.options;return o?this.getStack()?.lead||this:this}getPrevLead(){const{layoutId:o}=this.options;return o?this.getStack()?.prevLead:void 0}getStack(){const{layoutId:o}=this.options;if(o)return this.root.sharedNodes.get(o)}promote({needsReset:o,transition:l,preserveFollowOpacity:u}={}){const d=this.getStack();d&&d.promote(this,u),o&&(this.projectionDelta=void 0,this.needsReset=!0),l&&this.setOptions({transition:l})}relegate(){const o=this.getStack();return o?o.relegate(this):!1}resetSkewAndRotation(){const{visualElement:o}=this.options;if(!o)return;let l=!1;const{latestValues:u}=o;if((u.z||u.rotate||u.rotateX||u.rotateY||u.rotateZ||u.skewX||u.skewY)&&(l=!0),!l)return;const d={};u.z&&Bs("z",o,d,this.animationValues);for(let h=0;h<Vs.length;h++)Bs(`rotate${Vs[h]}`,o,d,this.animationValues),Bs(`skew${Vs[h]}`,o,d,this.animationValues);o.render();for(const h in d)o.setStaticValue(h,d[h]),this.animationValues&&(this.animationValues[h]=d[h]);o.scheduleRender()}applyProjectionStyles(o,l){if(!this.instance||this.isSVG)return;if(!this.isVisible){o.visibility="hidden";return}const u=this.getTransformTemplate();if(this.needsReset){this.needsReset=!1,o.visibility="",o.opacity="",o.pointerEvents=Gn(l?.pointerEvents)||"",o.transform=u?u(this.latestValues,""):"none";return}const d=this.getLead();if(!this.projectionDelta||!this.layout||!d.target){this.options.layoutId&&(o.opacity=this.latestValues.opacity!==void 0?this.latestValues.opacity:1,o.pointerEvents=Gn(l?.pointerEvents)||""),this.hasProjected&&!rt(this.latestValues)&&(o.transform=u?u({},""):"none",this.hasProjected=!1);return}o.visibility="";const h=d.animationValues||d.latestValues;this.applyTransformsToTarget();let f=f0(this.projectionDeltaWithTransform,this.treeScale,h);u&&(f=u(h,f)),o.transform=f;const{x:g,y}=this.projectionDelta;o.transformOrigin=`${g.origin*100}% ${y.origin*100}% 0`,d.animationValues?o.opacity=d===this?h.opacity??this.latestValues.opacity??1:this.preserveOpacity?this.latestValues.opacity:h.opacityExit:o.opacity=d===this?h.opacity!==void 0?h.opacity:"":h.opacityExit!==void 0?h.opacityExit:0;for(const v in gn){if(h[v]===void 0)continue;const{correct:T,applyTo:b,isCSSVariable:I}=gn[v],x=f==="none"?h[v]:T(h[v],d);if(b){const w=b.length;for(let _=0;_<w;_++)o[b[_]]=x}else I?this.options.visualElement.renderState.vars[v]=x:o[v]=x}this.options.layoutId&&(o.pointerEvents=d===this?Gn(l?.pointerEvents)||"":"none")}clearSnapshot(){this.resumeFrom=this.snapshot=void 0}resetTree(){this.root.nodes.forEach(o=>o.currentAnimation?.stop()),this.root.nodes.forEach(Co),this.root.sharedNodes.clear()}}}function v0(e){e.updateLayout()}function S0(e){const t=e.resumeFrom?.snapshot||e.snapshot;if(e.isLead()&&e.layout&&t&&e.hasListeners("didUpdate")){const{layoutBox:n,measuredBox:s}=e.layout,{animationType:i}=e.options,a=t.source!==e.layout.source;i==="size"?be(h=>{const f=a?t.measuredBox[h]:t.layoutBox[h],g=pe(f);f.min=n[h].min,f.max=f.min+g}):Au(i,t.layoutBox,n)&&be(h=>{const f=a?t.measuredBox[h]:t.layoutBox[h],g=pe(n[h]);f.max=f.min+g,e.relativeTarget&&!e.currentAnimation&&(e.isProjectionDirty=!0,e.relativeTarget[h].max=e.relativeTarget[h].min+g)});const o=Tt();sn(o,n,t.layoutBox);const l=Tt();a?sn(l,e.applyTransform(s,!0),t.measuredBox):sn(l,n,t.layoutBox);const u=!wu(o);let d=!1;if(!e.resumeFrom){const h=e.getClosestProjectingParent();if(h&&!h.resumeFrom){const{snapshot:f,layout:g}=h;if(f&&g){const y=ne();ts(y,t.layoutBox,f.layoutBox);const v=ne();ts(v,n,g.layoutBox),Iu(y,v)||(d=!0),h.options.layoutRoot&&(e.relativeTarget=v,e.relativeTargetOrigin=y,e.relativeParent=h)}}}e.notifyListeners("didUpdate",{layout:n,snapshot:t,delta:l,layoutDelta:o,hasLayoutChanged:u,hasRelativeLayoutChanged:d})}else if(e.isLead()){const{onExitComplete:n}=e.options;n&&n()}e.options.transition=void 0}function T0(e){Me.value&&it.nodes++,e.parent&&(e.isProjecting()||(e.isProjectionDirty=e.parent.isProjectionDirty),e.isSharedProjectionDirty||(e.isSharedProjectionDirty=!!(e.isProjectionDirty||e.parent.isProjectionDirty||e.parent.isSharedProjectionDirty)),e.isTransformDirty||(e.isTransformDirty=e.parent.isTransformDirty))}function b0(e){e.isProjectionDirty=e.isSharedProjectionDirty=e.isTransformDirty=!1}function w0(e){e.clearSnapshot()}function Co(e){e.clearMeasurements()}function ko(e){e.isLayoutDirty=!1}function I0(e){const{visualElement:t}=e.options;t&&t.getProps().onBeforeLayoutMeasure&&t.notify("BeforeLayoutMeasure"),e.resetTransform()}function Ro(e){e.finishAnimation(),e.targetDelta=e.relativeTarget=e.target=void 0,e.isProjectionDirty=!0}function x0(e){e.resolveTargetDelta()}function E0(e){e.calcProjection()}function A0(e){e.resetSkewAndRotation()}function _0(e){e.removeLeadSnapshot()}function Po(e,t,n){e.translate=K(t.translate,0,n),e.scale=K(t.scale,1,n),e.origin=t.origin,e.originPoint=t.originPoint}function Mo(e,t,n,s){e.min=K(t.min,n.min,s),e.max=K(t.max,n.max,s)}function C0(e,t,n,s){Mo(e.x,t.x,n.x,s),Mo(e.y,t.y,n.y,s)}function k0(e){return e.animationValues&&e.animationValues.opacityExit!==void 0}const R0={duration:.45,ease:[.4,0,.1,1]},Oo=e=>typeof navigator<"u"&&navigator.userAgent&&navigator.userAgent.toLowerCase().includes(e),No=Oo("applewebkit/")&&!Oo("chrome/")?Math.round:xe;function $o(e){e.min=No(e.min),e.max=No(e.max)}function P0(e){$o(e.x),$o(e.y)}function Au(e,t,n){return e==="position"||e==="preserve-aspect"&&!Uy(Ao(t),Ao(n),.2)}function M0(e){return e!==e.root&&e.scroll?.wasRoot}const O0=Eu({attachResizeListener:(e,t)=>yn(e,"resize",t),measureScroll:()=>({x:document.documentElement.scrollLeft||document.body.scrollLeft,y:document.documentElement.scrollTop||document.body.scrollTop}),checkIsScrollRoot:()=>!0}),Fs={current:void 0},_u=Eu({measureScroll:e=>({x:e.scrollLeft,y:e.scrollTop}),defaultParent:()=>{if(!Fs.current){const e=new O0({});e.mount(window),e.setOptions({layoutScroll:!0}),Fs.current=e}return Fs.current},resetTransform:(e,t)=>{e.style.transform=t!==void 0?t:"none"},checkIsScrollRoot:e=>window.getComputedStyle(e).position==="fixed"}),N0={pan:{Feature:e0},drag:{Feature:Zy,ProjectionNode:_u,MeasureLayout:Su}};function Do(e,t,n){const{props:s}=e;e.animationState&&s.whileHover&&e.animationState.setActive("whileHover",n==="Start");const i="onHover"+n,a=s[i];a&&G.postRender(()=>a(t,Cn(t)))}class $0 extends tt{mount(){const{current:t}=this.node;t&&(this.unmount=sg(t,(n,s)=>(Do(this.node,s,"Start"),i=>Do(this.node,i,"End"))))}unmount(){}}class D0 extends tt{constructor(){super(...arguments),this.isActive=!1}onFocus(){let t=!1;try{t=this.node.current.matches(":focus-visible")}catch{t=!0}!t||!this.node.animationState||(this.node.animationState.setActive("whileFocus",!0),this.isActive=!0)}onBlur(){!this.isActive||!this.node.animationState||(this.node.animationState.setActive("whileFocus",!1),this.isActive=!1)}mount(){this.unmount=En(yn(this.node.current,"focus",()=>this.onFocus()),yn(this.node.current,"blur",()=>this.onBlur()))}unmount(){}}function jo(e,t,n){const{props:s}=e;if(e.current instanceof HTMLButtonElement&&e.current.disabled)return;e.animationState&&s.whileTap&&e.animationState.setActive("whileTap",n==="Start");const i="onTap"+(n==="End"?"":n),a=s[i];a&&G.postRender(()=>a(t,Cn(t)))}class j0 extends tt{mount(){const{current:t}=this.node;t&&(this.unmount=og(t,(n,s)=>(jo(this.node,s,"Start"),(i,{success:a})=>jo(this.node,i,a?"End":"Cancel")),{useGlobalTarget:this.node.props.globalTapTarget}))}unmount(){}}const Dr=new WeakMap,qs=new WeakMap,L0=e=>{const t=Dr.get(e.target);t&&t(e)},U0=e=>{e.forEach(L0)};function V0({root:e,...t}){const n=e||document;qs.has(n)||qs.set(n,{});const s=qs.get(n),i=JSON.stringify(t);return s[i]||(s[i]=new IntersectionObserver(U0,{root:e,...t})),s[i]}function B0(e,t,n){const s=V0(t);return Dr.set(e,n),s.observe(e),()=>{Dr.delete(e),s.unobserve(e)}}const F0={some:0,all:1};class q0 extends tt{constructor(){super(...arguments),this.hasEnteredView=!1,this.isInView=!1}startObserver(){this.unmount();const{viewport:t={}}=this.node.getProps(),{root:n,margin:s,amount:i="some",once:a}=t,o={root:n?n.current:void 0,rootMargin:s,threshold:typeof i=="number"?i:F0[i]},l=u=>{const{isIntersecting:d}=u;if(this.isInView===d||(this.isInView=d,a&&!d&&this.hasEnteredView))return;d&&(this.hasEnteredView=!0),this.node.animationState&&this.node.animationState.setActive("whileInView",d);const{onViewportEnter:h,onViewportLeave:f}=this.node.getProps(),g=d?h:f;g&&g(u)};return B0(this.node.current,o,l)}mount(){this.startObserver()}update(){if(typeof IntersectionObserver>"u")return;const{props:t,prevProps:n}=this.node;["amount","margin","root"].some(W0(t,n))&&this.startObserver()}unmount(){}}function W0({viewport:e={}},{viewport:t={}}={}){return n=>e[n]!==t[n]}const z0={inView:{Feature:q0},tap:{Feature:j0},focus:{Feature:D0},hover:{Feature:$0}},H0={layout:{ProjectionNode:_u,MeasureLayout:Su}},G0={...Oy,...z0,...N0,...H0},B=Kg(G0,cy),Y0={sm:48,md:75,lg:120,xl:180,xxl:240},K0={idle:{scale:1,rotate:0,transition:{duration:.3}},alert:{scale:1.02,rotate:[-1,1,-1,0],transition:{rotate:{duration:.4,ease:"easeInOut"},scale:{duration:.2}}},hunting:{scale:[1,1.03,1],x:[0,-2,2,-1,1,0],transition:{duration:1.5,repeat:1/0,ease:"easeInOut"}},found:{scale:[1,1.1,1.05],transition:{duration:.5,ease:"easeOut"}},victorious:{scale:[1,1.08,1],rotate:[0,-3,3,0],transition:{duration:.8,ease:"easeOut"}},concerned:{scale:.98,rotate:-2,transition:{duration:.3}},apologetic:{scale:.95,y:3,transition:{duration:.4}}},Q0={idle:{rotate:0},alert:{rotate:5},hunting:{rotate:[0,-8,8,-5,5,0],transition:{duration:1.2,repeat:1/0,ease:"easeInOut"}},found:{rotate:10},victorious:{rotate:15},concerned:{rotate:-5},apologetic:{rotate:-10}},J0={idle:{rotate:0},alert:{rotate:3},hunting:{rotate:[0,5,-5,3,-3,0],transition:{duration:1.5,repeat:1/0,ease:"easeInOut"}},found:{rotate:8},victorious:{rotate:12},concerned:{rotate:-3},apologetic:{rotate:-8}};function Lo({state:e="idle",size:t="lg",className:n="",reducedMotion:s=!1,color:i="currentColor",glowEnabled:a=!0}){const o=Y0[t],l=e==="hunting"||e==="found"||e==="victorious";return c.jsxs(B.div,{className:`relative inline-block ${n}`,style:{width:o,height:o},animate:s?void 0:e,variants:K0,children:[a&&l&&!s&&c.jsx(B.div,{className:"absolute inset-0 rounded-full",style:{background:`radial-gradient(circle, ${i}20 0%, transparent 70%)`,filter:"blur(8px)"},animate:{opacity:[.3,.6,.3],scale:[1,1.1,1]},transition:{duration:2,repeat:1/0,ease:"easeInOut"}}),c.jsxs("svg",{viewBox:"0 0 75 83",fill:"none",xmlns:"http://www.w3.org/2000/svg",className:"w-full h-full",style:{color:i},children:[c.jsx("defs",{children:c.jsx("style",{children:`
              .cockatrice-line {
                fill: none;
                stroke: currentColor;
                stroke-width: 1.2;
                stroke-linecap: round;
                stroke-linejoin: round;
              }
              .cockatrice-fill {
                fill: currentColor;
                stroke: none;
              }
              .cockatrice-detail {
                fill: none;
                stroke: currentColor;
                stroke-width: 0.8;
                stroke-linecap: round;
              }
            `})}),c.jsxs("g",{transform:"translate(2, 2)",children:[c.jsxs("g",{className:"cockatrice-head",children:[c.jsx("path",{className:"cockatrice-line",d:"M28 8 L26 2 L30 6 L28 1 L33 5 L32 0 L36 4 L38 2 L37 7"}),c.jsx("path",{className:"cockatrice-fill",d:"M28 8 L26 3 L30 6 L28 2 L33 5 L32 1 L36 4 L38 3 L37 7 Z"}),c.jsx("path",{className:"cockatrice-line",d:"M25 12 C20 12, 18 16, 18 20 C18 24, 22 28, 28 28 L32 28"}),c.jsx("circle",{className:"cockatrice-fill",cx:"24",cy:"18",r:"2"}),c.jsx("path",{className:"cockatrice-line",d:"M18 20 L10 22 L18 24"}),c.jsx("path",{className:"cockatrice-fill",d:"M18 20 L12 22 L18 23 Z"}),c.jsx("path",{className:"cockatrice-line",d:"M16 24 C14 26, 14 30, 16 32 C18 34, 20 32, 20 30"})]}),c.jsxs("g",{className:"cockatrice-neck",children:[c.jsx("path",{className:"cockatrice-line",d:"M28 28 C32 32, 34 36, 36 42"}),c.jsx("path",{className:"cockatrice-detail",d:"M29 30 C31 31, 32 33, 31 35"}),c.jsx("path",{className:"cockatrice-detail",d:"M31 33 C33 34, 34 36, 33 38"}),c.jsx("path",{className:"cockatrice-detail",d:"M33 36 C35 37, 36 39, 35 41"})]}),c.jsxs(B.g,{className:"cockatrice-wing",style:{transformOrigin:"45px 35px"},variants:Q0,animate:s?void 0:e,children:[c.jsx("path",{className:"cockatrice-line",d:"M36 35 L55 15 L60 22 L58 18 L65 28 L62 25 L68 35 L50 40 Z"}),c.jsx("path",{className:"cockatrice-detail",d:"M36 35 L55 17"}),c.jsx("path",{className:"cockatrice-detail",d:"M38 37 L58 20"}),c.jsx("path",{className:"cockatrice-detail",d:"M40 39 L62 26"}),c.jsx("path",{className:"cockatrice-detail",d:"M43 40 L65 32"}),c.jsx("path",{className:"cockatrice-detail",d:"M50 40 L52 44 L48 42"}),c.jsx("path",{className:"cockatrice-detail",d:"M54 38 L56 42 L52 41"})]}),c.jsxs("g",{className:"cockatrice-body",children:[c.jsx("path",{className:"cockatrice-line",d:"M36 42 C40 45, 42 50, 40 56 C38 62, 34 65, 30 68"}),c.jsx("path",{className:"cockatrice-detail",d:"M38 44 C40 46, 41 49, 40 52"}),c.jsx("path",{className:"cockatrice-detail",d:"M36 48 C38 50, 39 53, 38 56"}),c.jsx("path",{className:"cockatrice-detail",d:"M34 52 C36 54, 37 57, 36 60"}),c.jsx("path",{className:"cockatrice-detail",d:"M32 56 C34 58, 35 61, 34 64"})]}),c.jsxs("g",{className:"cockatrice-legs",children:[c.jsx("path",{className:"cockatrice-line",d:"M35 55 L38 65 L42 70"}),c.jsx("path",{className:"cockatrice-line",d:"M38 65 L36 72"}),c.jsx("path",{className:"cockatrice-line",d:"M38 65 L40 73"}),c.jsx("path",{className:"cockatrice-line",d:"M32 60 L30 68 L26 74"}),c.jsx("path",{className:"cockatrice-line",d:"M30 68 L32 75"}),c.jsx("path",{className:"cockatrice-line",d:"M30 68 L28 76"})]}),c.jsxs(B.g,{className:"cockatrice-tail",style:{transformOrigin:"30px 68px"},variants:J0,animate:s?void 0:e,children:[c.jsx("path",{className:"cockatrice-line",d:"M30 68 C25 72, 15 75, 8 72 C2 69, 0 62, 5 58 C10 54, 18 56, 22 60"}),c.jsx("path",{className:"cockatrice-detail",d:"M28 70 C26 71, 24 72, 22 71"}),c.jsx("path",{className:"cockatrice-detail",d:"M22 71 C20 72, 18 73, 16 72"}),c.jsx("path",{className:"cockatrice-detail",d:"M16 72 C14 73, 12 73, 10 72"}),c.jsx("path",{className:"cockatrice-detail",d:"M10 72 C8 71, 6 70, 5 68"}),c.jsx("path",{className:"cockatrice-detail",d:"M5 68 C4 66, 4 64, 5 62"}),c.jsx("path",{className:"cockatrice-line",d:"M5 58 L2 55 L8 57 L5 58"})]})]}),(e==="hunting"||e==="found")&&!s&&c.jsxs(B.g,{initial:{opacity:0},animate:{opacity:1},exit:{opacity:0},children:[c.jsx(B.circle,{cx:"8",cy:"22",r:"4",className:"cockatrice-detail",animate:{r:[4,5,4],opacity:[.5,1,.5]},transition:{duration:1,repeat:1/0}}),e==="found"&&c.jsx(c.Fragment,{children:c.jsx(B.path,{d:"M6 20 L10 20 M8 18 L8 22 M6 18 L10 22 M10 18 L6 22",className:"cockatrice-detail",initial:{scale:0},animate:{scale:1,rotate:45},style:{transformOrigin:"8px 20px"}})})]}),e==="victorious"&&!s&&c.jsxs(c.Fragment,{children:[c.jsx(B.circle,{cx:"15",cy:"10",r:"1.5",className:"cockatrice-fill",initial:{opacity:0,scale:0},animate:{opacity:[0,1,0],scale:[0,1,0]},transition:{duration:.6,delay:0}}),c.jsx(B.circle,{cx:"60",cy:"12",r:"1.5",className:"cockatrice-fill",initial:{opacity:0,scale:0},animate:{opacity:[0,1,0],scale:[0,1,0]},transition:{duration:.6,delay:.2}}),c.jsx(B.circle,{cx:"65",cy:"45",r:"1.5",className:"cockatrice-fill",initial:{opacity:0,scale:0},animate:{opacity:[0,1,0],scale:[0,1,0]},transition:{duration:.6,delay:.4}})]})]})]})}let lt=null;function Cu(){if(typeof window>"u"||typeof navigator>"u")return!1;try{const e=navigator.userAgent||"";return!!(/iPad|iPhone|iPod/.test(e)||/Macintosh/.test(e)&&navigator.maxTouchPoints>1||"standalone"in navigator)}catch{return!1}}function X0(){if(typeof window>"u"||typeof navigator>"u")return!1;try{if(navigator.brave)return!0;const e=navigator.userAgent||"";if(e.includes("Chrome")&&!e.includes("Edg")&&!e.includes("OPR"))try{const n=document.createElement("canvas").getContext("2d");n&&(n.fillStyle="#f00",n.fillRect(0,0,1,1),n.getImageData(0,0,1,1))}catch{return!0}return!1}catch{return!0}}function Z0(){if(typeof window>"u"||typeof navigator>"u")return!1;try{const e=navigator.userAgent||"";return/Safari/.test(e)&&!/Chrome/.test(e)&&!/Chromium/.test(e)}catch{return!1}}function ev(){if(typeof window>"u"||typeof navigator>"u")return!1;try{const e=navigator.userAgent||"";return/Firefox/.test(e)}catch{return!1}}function tv(){if(typeof window>"u")return!1;const e=Cu();if(!e)return!1;try{const t=document.createElement("canvas");if(!(t.getContext("webgl")||t.getContext("experimental-webgl")))return!0;const s=t.getContext("webgl2");return!("serviceWorker"in navigator)}catch{return!0}}function nv(){if(typeof document>"u")return{hasWebGL:!1,hasWebGL2:!1};try{const e=document.createElement("canvas"),t=e.getContext("webgl")||e.getContext("experimental-webgl"),n=e.getContext("webgl2");return{hasWebGL:!!t,hasWebGL2:!!n}}catch{return{hasWebGL:!1,hasWebGL2:!1}}}function sv(){if(typeof window>"u")return!1;try{const e=indexedDB.open("_browserCompat_test",1);return e.onerror=()=>{},e.onsuccess=()=>{try{e.result.close(),indexedDB.deleteDatabase("_browserCompat_test")}catch{}},!0}catch{return!1}}function rv(){if(typeof document>"u")return!1;try{return typeof document.createElement("div").animate=="function"}catch{return!1}}function iv(){if(typeof window>"u")return!1;try{return window.matchMedia("(prefers-reduced-motion: reduce)").matches}catch{return!1}}function av(){if(typeof navigator>"u")return{isSlowConnection:!1,saveData:!1};try{const e=navigator.connection||navigator.mozConnection||navigator.webkitConnection;return e?{isSlowConnection:e.effectiveType==="2g"||e.effectiveType==="slow-2g"||e.downlink&&e.downlink<1,saveData:!!e.saveData}:{isSlowConnection:!1,saveData:!1}}catch{return{isSlowConnection:!1,saveData:!1}}}function ov(){if(typeof navigator>"u")return{isLowMemory:!1,isLowCPU:!1};try{const e=navigator.deviceMemory,t=navigator.hardwareConcurrency;return{isLowMemory:e!==void 0&&e<4,isLowCPU:t!==void 0&&t<4}}catch{return{isLowMemory:!1,isLowCPU:!1}}}function cv(){return typeof window>"u"?{hasIntersectionObserver:!1,hasResizeObserver:!1,hasMutationObserver:!1}:{hasIntersectionObserver:"IntersectionObserver"in window,hasResizeObserver:"ResizeObserver"in window,hasMutationObserver:"MutationObserver"in window}}function lv(){if(lt)return lt;const e=Cu(),t=X0(),n=Z0(),s=ev(),i=tv(),a=nv(),o=cv(),l=av(),u=ov(),d=iv(),h=i||e&&t||!a.hasWebGL&&e||d;let f;return i||e&&t?f="none":d||l.saveData?f="minimal":l.isSlowConnection||u.isLowMemory||u.isLowCPU?f="reduced":f="full",lt={isRestrictive:h,isIOS:e,isBrave:t,isSafari:n,isFirefox:s,isLockdownMode:i,hasWebGL:a.hasWebGL,hasWebGL2:a.hasWebGL2,hasIndexedDB:sv(),hasServiceWorker:typeof navigator<"u"&&"serviceWorker"in navigator,hasWebAnimations:rv(),hasIntersectionObserver:o.hasIntersectionObserver,hasResizeObserver:o.hasResizeObserver,hasMutationObserver:o.hasMutationObserver,prefersReducedMotion:d,isSlowConnection:l.isSlowConnection,isLowMemory:u.isLowMemory,isLowCPU:u.isLowCPU,saveData:l.saveData,shouldUseStaticFallbacks:f==="none"||f==="minimal",shouldDisableComplexAnimations:f!=="full",shouldDisable3D:!a.hasWebGL||i,animationSafetyLevel:f},lt}function uv(){if(lt)return lt.isRestrictive;if(typeof window>"u")return!1;try{const e=navigator.userAgent||"",t=/iPad|iPhone|iPod/.test(e),n=!!navigator.brave;if(t&&n||window.matchMedia("(prefers-reduced-motion: reduce)").matches)return!0;if(t)try{const s=document.createElement("canvas");if(!(s.getContext("webgl")||s.getContext("experimental-webgl")))return!0}catch{return!0}return!1}catch{return!0}}function XC(){return lt||lv()}let Ws=null;function jr(){return Ws===null&&(Ws=uv()),Ws}const Uo={opacity:1,transform:"none",visibility:"visible"},dv={transition:"opacity 0.3s ease-out, transform 0.3s ease-out"};function j(e){const t=m.forwardRef(({style:n,children:s,initial:i,animate:a,exit:o,whileHover:l,whileTap:u,whileFocus:d,whileInView:h,whileDrag:f,variants:g,transition:y,layout:v,layoutId:T,onAnimationStart:b,onAnimationComplete:I,...x},w)=>{const _=m.useRef(null),A=w||_;if(m.useEffect(()=>{const R=w?.current||_.current;R&&jr()&&(R.style.opacity="1",R.style.visibility="visible",R.style.transform="none")},[w]),jr()){const R=e,P={...x};return c.jsx(R,{ref:A,...P,style:{...Uo,...dv,...n},children:s})}const k=B[e];return c.jsx(k,{ref:A,...x,initial:i,animate:a,exit:o,whileHover:l,whileTap:u,whileFocus:d,whileInView:h,whileDrag:f,variants:g,transition:y,layout:v,layoutId:T,onAnimationStart:b,onAnimationComplete:I,style:{...Uo,...n},children:s})});return t.displayName=`SafeMotion.${e}`,t}const ZC={div:j("div"),span:j("span"),p:j("p"),section:j("section"),article:j("article"),aside:j("aside"),main:j("main"),header:j("header"),footer:j("footer"),nav:j("nav"),h1:j("h1"),h2:j("h2"),h3:j("h3"),h4:j("h4"),h5:j("h5"),h6:j("h6"),a:j("a"),button:j("button"),form:j("form"),input:j("input"),label:j("label"),textarea:j("textarea"),select:j("select"),img:j("img"),video:j("video"),audio:j("audio"),ul:j("ul"),ol:j("ol"),li:j("li"),table:j("table"),thead:j("thead"),tbody:j("tbody"),tr:j("tr"),td:j("td"),th:j("th"),svg:j("svg"),path:j("path"),circle:j("circle"),rect:j("rect"),line:j("line"),polyline:j("polyline"),polygon:j("polygon"),g:j("g"),figure:j("figure"),figcaption:j("figcaption"),blockquote:j("blockquote"),pre:j("pre"),code:j("code"),hr:j("hr")};function ek({children:e,mode:t="sync",initial:n=!0,onExitComplete:s,presenceAffectsLayout:i}){const a=jr();return m.useEffect(()=>{if(a)return()=>{s?.()}},[a,s]),a?c.jsx(c.Fragment,{children:e}):c.jsx(Ct,{mode:t,initial:n,onExitComplete:s,presenceAffectsLayout:i,children:e})}const mv=[{title:"Looks like we've lost signal!",message:"The Cockatrice tried to reach our servers but got tangled in the web. Check your internet connection and we'll try again.",tip:"While you wait, maybe do a quick stretch?",mood:"concerned"},{title:"The tubes are clogged!",message:"Your internet connection seems to have wandered off. The Cockatrice is waiting patiently for it to return.",tip:"Try toggling WiFi or checking your router.",mood:"apologetic"},{title:"Connection took a coffee break",message:"We can't reach MuscleMap's servers right now. The Cockatrice suggests checking if your internet is feeling okay.",tip:"If this persists, our servers might be doing push-ups. Try again in a minute!",mood:"helpful"}],hv=[{title:"Page got lost in transit",message:"The content you requested took a wrong turn somewhere. This usually means there's been an update - let's try loading it fresh!",tip:"A quick refresh usually does the trick.",mood:"concerned"},{title:"Oops! Couldn't load that bit",message:"Part of the app didn't load properly. The Cockatrice has already dispatched a fresh copy - try again!",tip:"If this keeps happening, try clearing your browser cache.",mood:"helpful"},{title:"Update in progress?",message:"Looks like MuscleMap may have gotten an update while you were here. The page content needs a refresh.",tip:"Click 'Try Again' or refresh the page to get the latest version.",mood:"thinking"}],pv=[{title:"Well, that was unexpected!",message:"Something broke that shouldn't have. The Cockatrice has already reported this to our engineers - they're on it!",tip:"Your data is safe. Try refreshing to continue your workout.",mood:"apologetic"},{title:"Glitch in the matrix",message:"We encountered a bug. Don't worry - the Cockatrice has captured it and sent it to the bug containment facility.",tip:"Our team will squash this bug soon!",mood:"concerned"},{title:"The app did a face-plant",message:"Even the mightiest apps sometimes trip. This error has been automatically reported, and help is on the way.",tip:"Try the action again - it often works the second time!",mood:"apologetic"},{title:"Ouch! That hurt",message:"Something went wrong on our end. The Cockatrice is embarrassed but has already flagged this for immediate repair.",tip:"Your progress has been saved. Refresh to continue.",mood:"apologetic"}],fv=[{title:"Session got sleepy",message:"Your login session has expired - happens to the best of us after some time. Let's get you signed back in!",tip:"You'll be right back where you left off.",mood:"helpful"},{title:"Who goes there?",message:"The Cockatrice needs to verify it's really you. Your session may have timed out for security.",tip:"Sign in again to continue your fitness journey.",mood:"concerned"}],gv=[{title:"Can't go there!",message:"You don't have access to this area. The Cockatrice guards this content carefully.",tip:"If you think this is a mistake, contact support.",mood:"concerned"},{title:"VIP area ahead",message:"This feature requires special access. The Cockatrice suggests checking your subscription or permissions.",tip:"Upgrade your account to unlock more features!",mood:"helpful"}],yv=[{title:"Our servers are doing burpees",message:"The MuscleMap servers are taking a breather. They'll be back in fighting shape soon!",tip:"Try again in a few seconds.",mood:"apologetic"},{title:"Temporary turbulence",message:"Our servers hit a rough patch. The Cockatrice has alerted the ops team and they're flexing their fixing muscles.",tip:"This usually resolves quickly - hang tight!",mood:"thinking"},{title:"Server needs a spot",message:"Our backend is struggling with a heavy lift right now. Give it a moment and it'll push through.",tip:"Heavy traffic can cause this. Try again shortly.",mood:"helpful"}],vv=[{title:"Page went AWOL",message:"The Cockatrice searched high and low but couldn't find what you're looking for. It may have been moved or deleted.",tip:"Check the URL or head back to the homepage.",mood:"concerned"},{title:"Nothing here but tumbleweeds",message:"This page doesn't exist - or maybe it's just really good at hide and seek.",tip:"Try searching for what you need, or go back home.",mood:"helpful"}],Sv=[{title:"Whoa there, speedy!",message:"You're moving faster than the Cockatrice can keep up! Take a quick breather and try again.",tip:"Wait about 30 seconds before your next request.",mood:"concerned"},{title:"Too many reps too fast!",message:"Even in fitness, pacing matters. You've made too many requests - the Cockatrice needs a quick rest.",tip:"Slow and steady wins the race.",mood:"helpful"}],Tv=[{title:"Something seems off",message:"The data you entered didn't pass the Cockatrice's quality check. Double-check your input and try again.",tip:"Look for red highlights on form fields.",mood:"helpful"},{title:"That doesn't add up",message:"Some of the information provided isn't quite right. The Cockatrice is a stickler for details!",tip:"Review the form and fix any highlighted errors.",mood:"concerned"}],bv=[{title:"Taking too long...",message:"The request timed out - either the servers are busy or the operation is complex. The Cockatrice is patient, but has limits.",tip:"Try again, or wait a moment if the servers seem busy.",mood:"thinking"},{title:"Response got stuck",message:"We sent the request but never heard back. The digital carrier pigeon might have gotten lost.",tip:"Check your connection and try again.",mood:"apologetic"}],wv=[{title:"All fixed!",message:"The Cockatrice worked its magic and everything is back to normal. Crisis averted!",mood:"victorious"},{title:"Problem solved!",message:"Whatever was broken has been automatically repaired. The Cockatrice is pleased.",mood:"victorious"},{title:"Back in action!",message:"The issue has been resolved. You can continue your workout without interruption.",mood:"victorious"}],Vo=[{title:"Something went wrong",message:"An unexpected error occurred. The Cockatrice has logged it and our team will investigate.",tip:"Try refreshing the page or come back later.",mood:"apologetic"},{title:"Oops!",message:"We hit a snag. The good news? The Cockatrice is already working on it behind the scenes.",tip:"Your data should be safe. Try again in a moment.",mood:"concerned"}];function ku(e){const t=Math.floor(Math.random()*e.length);return e[t]}function Iv(e,t){if(t){if(t===401)return"auth";if(t===403)return"permission";if(t===404)return"notFound";if(t===422||t===400)return"validation";if(t===429)return"rateLimit";if(t===408)return"timeout";if(t>=500)return"server"}if(e){const n=e.message?.toLowerCase()||"",s=e.name?.toLowerCase()||"";if(n.includes("fetch")||n.includes("network")||n.includes("offline")||n.includes("internet")||s==="typeerror"&&n.includes("failed to fetch"))return"network";if(s==="chunkloaderror"||n.includes("loading chunk")||n.includes("loading css chunk")||n.includes("dynamically imported module"))return"chunk";if(n.includes("timeout")||n.includes("timed out")||s==="aborterror")return"timeout";if(n.includes("unauthorized")||n.includes("unauthenticated")||n.includes("session expired")||n.includes("token"))return"auth";if(n.includes("forbidden")||n.includes("permission")||n.includes("access denied"))return"permission"}return e instanceof Error?"runtime":"generic"}function xv(e){return ku({network:mv,chunk:hv,runtime:pv,auth:fv,permission:gv,server:yv,notFound:vv,rateLimit:Sv,validation:Tv,timeout:bv,generic:Vo}[e]||Vo)}function Bo(){return ku(wv)}const Lr="/api/errors/report",Fe=[];let rn=null;const Ev=2e3,Av=10;async function _v(e){try{const t=dn(),n={"Content-Type":"application/json"};t&&(n.Authorization=`Bearer ${t}`);const s=await fetch(Lr,{method:"POST",headers:n,body:JSON.stringify(e),signal:AbortSignal.timeout(5e3)});return s.ok?(await s.json()).data:((s.status>=500||s.status===429)&&Fo(e),null)}catch{return Fo(e),null}}function Fo(e){Fe.some(n=>n.message===e.message&&n.url===e.url)||(Fe.push(e),Fe.length>Av&&Fe.shift()),Cv()}function Cv(){rn||(rn=setTimeout(()=>{Ur(),rn=null},Ev))}async function Ur(){if(Fe.length===0)return;const e=[...Fe];Fe.length=0;try{const t=dn(),n={"Content-Type":"application/json"};if(t&&(n.Authorization=`Bearer ${t}`),navigator.sendBeacon){const s=new Blob([JSON.stringify({errors:e})],{type:"application/json"});navigator.sendBeacon(`${Lr}/batch`,s)}else await fetch(`${Lr}/batch`,{method:"POST",headers:n,body:JSON.stringify({errors:e}),keepalive:!0})}catch{e.forEach(t=>Fe.push(t))}}typeof window<"u"&&(window.addEventListener("beforeunload",()=>{rn&&clearTimeout(rn),Ur()}),document.addEventListener("visibilitychange",()=>{document.hidden&&Fe.length>0&&Ur()}));const kv={light:[10],medium:[20],heavy:[40],success:[10,50,10],warning:[20,30,20],error:[50,30,50],selection:[5]};function Un(e="light"){if(typeof navigator<"u"&&"vibrate"in navigator)try{navigator.vibrate(kv[e])}catch{}}function Rv({error:e,httpStatus:t,onRetry:n,onGoHome:s,componentName:i,errorContext:a,variant:o="fullscreen",retryCount:l=0,maxRetries:u=2,autoReport:d=!0,className:h=""}){const[f,g]=m.useState(!1),[y,v]=m.useState(!1),[T,b]=m.useState(null),[I,x]=m.useState(!1),w=Iv(e,t),[_,A]=m.useState(()=>xv(w));m.useEffect(()=>{if(!e||!d||y)return;(async()=>{g(!0);const H={type:w,message:e.message,stack:e.stack,componentName:i,httpStatus:t,url:window.location.href,userAgent:navigator.userAgent,timestamp:new Date().toISOString(),context:{...a,retryCount:l,errorName:e.name}};try{const Q=await _v(H);b(Q?.id||null),v(!0)}catch{v(!0)}finally{g(!1)}})()},[e,w,i,t,a,l,d,y]),m.useEffect(()=>{e&&Un("error")},[e]);const k=m.useCallback(()=>{Un("light"),n&&n()},[n]),R=m.useCallback(()=>{Un("light"),s?s():window.location.href="/"},[s]),P=m.useCallback(()=>{Un("light"),window.location.reload()},[]),O=n&&l<u,N=!O||l>=u,F={fullscreen:"min-h-screen bg-[#0a0a0f] flex items-center justify-center p-4",inline:"p-6 rounded-2xl bg-white/5 backdrop-blur-xl border border-white/10",modal:"fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm"},Z={fullscreen:"max-w-md w-full",inline:"w-full",modal:"max-w-md w-full"};return e?c.jsx("div",{className:`${F[o]} ${h}`,role:"alert","aria-live":"assertive",children:c.jsxs(B.div,{initial:{opacity:0,y:20,scale:.95},animate:{opacity:1,y:0,scale:1},exit:{opacity:0,y:-20,scale:.95},transition:{type:"spring",stiffness:300,damping:25},className:`${Z[o]} bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-8 text-center`,children:[c.jsx("div",{className:"flex justify-center mb-6",children:c.jsx(Ct,{mode:"wait",children:I?c.jsx(B.div,{initial:{scale:0},animate:{scale:1},exit:{scale:0},children:c.jsx(Lo,{state:"victorious",size:"xl"})},"success"):c.jsx(B.div,{initial:{scale:.8,opacity:0},animate:{scale:1,opacity:1},transition:{delay:.1},children:c.jsx(Lo,{state:_.mood,size:"xl"})},"error")})}),c.jsx(B.h1,{initial:{opacity:0,y:10},animate:{opacity:1,y:0},transition:{delay:.2},className:"text-2xl font-bold text-white mb-3",children:I?Bo().title:_.title}),c.jsx(B.p,{initial:{opacity:0,y:10},animate:{opacity:1,y:0},transition:{delay:.3},className:"text-gray-400 mb-4 leading-relaxed",children:I?Bo().message:_.message}),_.tip&&!I&&c.jsx(B.div,{initial:{opacity:0,y:10},animate:{opacity:1,y:0},transition:{delay:.4},className:"bg-violet-500/10 border border-violet-500/20 rounded-xl px-4 py-3 mb-6",children:c.jsxs("p",{className:"text-violet-300 text-sm flex items-center justify-center gap-2",children:[c.jsx("span",{className:"text-lg",children:"💡"}),_.tip]})}),f&&c.jsxs(B.div,{initial:{opacity:0},animate:{opacity:1},className:"text-gray-500 text-sm mb-4 flex items-center justify-center gap-2",children:[c.jsx(B.span,{animate:{rotate:360},transition:{duration:1,repeat:1/0,ease:"linear"},className:"inline-block w-4 h-4 border-2 border-gray-500 border-t-transparent rounded-full"}),"Reporting issue to our team..."]}),y&&!f&&c.jsxs(B.div,{initial:{opacity:0,y:5},animate:{opacity:1,y:0},className:"text-green-400/70 text-sm mb-4 flex items-center justify-center gap-2",children:[c.jsx("span",{className:"text-green-400",children:"✓"}),"Issue reported - our team has been notified",T&&c.jsxs("span",{className:"text-gray-500 text-xs ml-1",children:["(#",T.slice(0,8),")"]})]}),c.jsxs(B.div,{initial:{opacity:0,y:10},animate:{opacity:1,y:0},transition:{delay:.5},className:"flex flex-col sm:flex-row gap-3 justify-center",children:[O&&c.jsx("button",{onClick:k,className:"px-6 py-3 min-h-[48px] bg-gradient-to-r from-violet-600 to-purple-600 hover:from-violet-500 hover:to-purple-500 rounded-xl font-semibold text-white transition-all focus:outline-none focus:ring-2 focus:ring-violet-500 focus:ring-offset-2 focus:ring-offset-[#0a0a0f] active:scale-95",children:"Try Again"}),N&&c.jsx("button",{onClick:P,className:"px-6 py-3 min-h-[48px] bg-white/10 hover:bg-white/20 rounded-xl font-medium text-white transition-all focus:outline-none focus:ring-2 focus:ring-white/50 focus:ring-offset-2 focus:ring-offset-[#0a0a0f] active:scale-95",children:"Reload Page"}),c.jsx("button",{onClick:R,className:"px-6 py-3 min-h-[48px] bg-transparent hover:bg-white/5 rounded-xl font-medium text-gray-400 hover:text-white transition-all focus:outline-none focus:ring-2 focus:ring-white/30 focus:ring-offset-2 focus:ring-offset-[#0a0a0f] active:scale-95",children:"Go Home"})]}),!1,c.jsxs(B.p,{initial:{opacity:0},animate:{opacity:1},transition:{delay:.8},className:"mt-6 text-xs text-gray-600",children:["Cockatrice mascot from"," ",c.jsx("a",{href:"https://triptomean.com",target:"_blank",rel:"noopener noreferrer",className:"text-violet-500 hover:text-violet-400 underline",children:"TRIPTOMEAN.com"})]})]})}):null}class V extends $e.Component{constructor(t){super(t),this.state={hasError:!1,error:null,errorType:null,retryCount:0}}static getDerivedStateFromError(t){let n="runtime";return t.name==="ChunkLoadError"||t.message?.includes("Loading chunk")?n="chunk":(t.message?.includes("fetch")||t.message?.includes("network"))&&(n="network"),{hasError:!0,error:t,errorType:n}}componentDidCatch(t,n){if(De.componentError(this.props.name||"Unknown",t),De.error("react_error_boundary",{message:t.message,stack:t.stack,componentStack:n.componentStack,errorType:this.state.errorType}),this.props.onError)try{this.props.onError(t,n)}catch{}}handleRetry=()=>{this.setState(t=>({hasError:!1,error:null,errorType:null,retryCount:t.retryCount+1}))};handleGoHome=()=>{window.location.href="/"};render(){return this.state.hasError?this.props.fallback?this.props.fallback:c.jsx(Rv,{error:this.state.error,onRetry:this.handleRetry,onGoHome:this.handleGoHome,componentName:this.props.name,variant:this.props.inline?"inline":"fullscreen",retryCount:this.state.retryCount,maxRetries:2,autoReport:!0,errorContext:{errorType:this.state.errorType}}):this.props.children}}m.lazy(()=>E(()=>import("./Cockatrice3D-gujij4pw.js"),__vite__mapDeps([7,1,8,5,6])));const Ru=m.createContext(null),Pv={1:"Baby",2:"Adolescent",3:"Capable",4:"Armored",5:"Flying",6:"Magnificent"};function Mv({children:e}){const[t,n]=m.useState(null),[s,i]=m.useState(!1),a=m.useMemo(()=>typeof window>"u"?!1:window.matchMedia("(prefers-reduced-motion: reduce)").matches,[]),{data:o,loading:l,error:u,refetch:d}=Ts(Mh,{fetchPolicy:"cache-and-network",skip:!localStorage.getItem("musclemap_token")}),{data:h,loading:f,refetch:g}=Ts(Oh,{fetchPolicy:"cache-and-network",skip:!localStorage.getItem("musclemap_token")}),{data:y,refetch:v}=Ts(Nh,{variables:{limit:5},fetchPolicy:"cache-and-network",skip:!localStorage.getItem("musclemap_token")||!o?.mascot?.isVisible,pollInterval:3e4}),[T]=Lt($h),[b]=Lt(Dh),[I]=Lt(jh),[x]=Lt(Lh),[w]=Lt(Uh),_=o?.mascot||null,A=l||f,k=u||null,R=m.useMemo(()=>y?.mascotPendingReactions||[],[y?.mascotPendingReactions]);m.useEffect(()=>{if(R.length>0&&!a&&_?.isVisible){P(R[0]);const W=R.map(Y=>Y.id);w({variables:{reactionIds:W}}).catch(console.error)}},[R.length,a,_?.isVisible]);const P=m.useCallback(W=>{n(W),setTimeout(()=>n(null),3500)},[]),O=m.useCallback(async W=>{try{await b({variables:{input:W},optimisticResponse:{updateMascotSettings:{..._,...W,__typename:"MascotState"}}})}catch(Y){throw Y}},[b,_]),N=m.useCallback(async W=>{try{const{data:Y}=await T({variables:{nickname:W}});return Y?.updateMascotNickname?{success:!0}:{success:!1,error:"Failed to update nickname"}}catch(Y){return{success:!1,error:Y.message}}},[T]),F=m.useCallback(async W=>{try{const{data:Y}=await I({variables:{cosmeticId:W}});return Y?.purchaseMascotCosmetic?.success?(await d(),await g(),P({id:`purchase-${W}`,eventId:W,reactionType:"upgrade_purchased",message:"New cosmetic acquired!",emote:"🎉",animation:"celebrate",duration:3e3,intensity:1,shown:!1,createdAt:new Date().toISOString()}),{success:!0,upgrade:Y.purchaseMascotCosmetic.cosmetic}):{success:!1,error:Y?.purchaseMascotCosmetic?.error||"Purchase failed"}}catch(Y){return{success:!1,error:Y.message}}},[I,d,g,P]),Z=m.useCallback(async(W,Y)=>{try{const{data:Ce}=await x({variables:{cosmeticId:Y,slot:W}});return Ce?.equipMascotCosmetic?(await d(),{success:!0}):{success:!1,error:"Failed to equip cosmetic"}}catch(Ce){return{success:!1,error:Ce.message}}},[x,d]),z=m.useCallback(async()=>({tip:null,reason:"no_tips_available"}),[]),H=m.useCallback(async()=>{await Promise.all([d(),g(),v()])},[d,g,v]),Q=_?Pv[_.stage]||"Unknown":"",_e=m.useMemo(()=>({balance:0,upgrades:h?.mascotShop||[]}),[h]),ee=m.useMemo(()=>({state:_,stageName:Q,upgradesData:_e,events:R,reaction:t,panelOpen:s,loading:A,error:k,reducedMotion:a,setPanelOpen:i,updateSettings:O,setNickname:N,purchaseUpgrade:F,equipCosmetic:Z,showReaction:P,getNextTip:z,refetch:H}),[_,Q,_e,R,t,s,A,k,a,O,N,F,Z,P,z,H]);return c.jsx(Ru.Provider,{value:ee,children:e})}function Ov(){const e=m.useContext(Ru);if(!e)throw new Error("useCompanion must be used within a CompanionProvider");return e}const qo={1:{emoji:"🥚",label:"Baby"},2:{emoji:"🐣",label:"Adolescent"},3:{emoji:"🐥",label:"Capable"},4:{emoji:"🦅",label:"Armored"},5:{emoji:"🦋",label:"Flying"},6:{emoji:"🌟",label:"Magnificent"}},Nv={"aura-gold":"shadow-2xl shadow-yellow-400/50","aura-ember":"shadow-2xl shadow-orange-500/50","aura-frost":"shadow-2xl shadow-cyan-400/50","aura-shadow":"shadow-2xl shadow-purple-900/70","aura-cosmic":"shadow-2xl shadow-violet-400/60"},Vn={idle:{scale:1,y:0,rotate:0},workout_logged:{scale:[1,1.2,1],y:[0,-10,0],transition:{duration:.6,ease:"easeOut"}},streak_hit:{rotate:[0,10,-10,10,0],scale:[1,1.1,1],transition:{duration:.8}},pr_set:{scale:[1,1.3,1],y:[0,-20,0],transition:{duration:.8,ease:"easeOut"}},upgrade_purchased:{scale:[1,1.2,.9,1.1,1],rotate:[0,0,360],transition:{duration:1}},stage_evolved:{scale:[1,.8,1.5,1.2],y:[0,10,-30,0],transition:{duration:1.5,ease:"easeOut"}}};function $v({stage:e=1,equipped:t={},reaction:n=null,reducedMotion:s=!1,className:i=""}){const[a,o]=m.useState(!1),[l,u]=m.useState(null);m.useEffect(()=>{if(n&&!s){u(n),o(!0);const g=setTimeout(()=>{o(!1),u(null)},2e3);return()=>clearTimeout(g)}},[n,s]);const d=m.useMemo(()=>t.aura&&Nv[t.aura]||"",[t.aura]),h=qo[e]||qo[1],f=l&&Vn[l]||Vn.idle;return c.jsxs(B.div,{className:`relative w-full h-full flex items-center justify-center ${i}`,animate:a?f:"idle",variants:Vn,children:[c.jsxs("div",{className:`
          relative w-full h-full flex flex-col items-center justify-center
          rounded-full bg-gradient-to-br from-purple-600/20 to-indigo-600/20
          ${d}
          transition-shadow duration-300
        `,children:[c.jsx("span",{className:"text-5xl select-none",role:"img","aria-label":h.label,children:h.emoji}),t.wings&&e>=3&&c.jsx("span",{className:"absolute -top-3 left-1/2 -translate-x-1/2 text-xl animate-pulse",children:t.wings==="wings-dragon"?"🐉":"🦋"}),t.armor&&c.jsx("span",{className:"absolute -bottom-1 left-1/2 -translate-x-1/2 text-lg",children:"🛡️"}),t.tools&&c.jsx("span",{className:"absolute -right-1 top-1/2 -translate-y-1/2 text-sm",children:t.tools==="tool-slate"?"📊":t.tools==="tool-trophy"?"🏆":"🔮"}),c.jsx("div",{className:`
            absolute inset-0 rounded-full pointer-events-none
            bg-gradient-to-br from-purple-500/10 to-indigo-500/10
            ${e>=4?"animate-pulse":""}
          `})]}),t.badge&&c.jsx("div",{className:"absolute -bottom-2 -right-2 w-6 h-6 bg-yellow-500 rounded-full flex items-center justify-center text-xs shadow-lg",children:t.badge==="badge-streak-7"?"7":t.badge==="badge-streak-30"?"30":"🏅"})]})}const Wo={workout_logged:["💪 Great workout!","🔥 Keep it up!","⚡ Nice session!","💥 Crushed it!"],streak_hit:["🔥 Streak!","🏆 On fire!","⭐ Consistent!","💫 Amazing!"],pr_set:["🏆 New PR!","💪 Record broken!","🎉 Personal best!","⚡ Stronger!"],upgrade_purchased:["✨ Upgraded!","🌟 Nice choice!","💎 Equipped!","🎁 New gear!"],stage_evolved:["🌟 EVOLVED!","🚀 Level up!","⭐ Growing!","💫 Transformed!"],badge_awarded:["🏅 New badge!","🎖️ Achievement!","🏆 Earned it!"],goal_progress:["📈 Progress!","🎯 Getting closer!","💪 On track!"],default:["👋 Hello!","✨ Nice!"]};function Dv({event:e}){if(!e)return null;const t=e.event_type||"default",n=Wo[t]||Wo.default,s=n[Math.floor(Math.random()*n.length)],i=t==="stage_evolved";return c.jsxs(B.div,{className:"absolute -top-14 left-1/2 -translate-x-1/2 whitespace-nowrap z-20",initial:{opacity:0,y:10,scale:.8},animate:{opacity:1,y:0,scale:1},exit:{opacity:0,y:-10,scale:.8},transition:{type:"spring",stiffness:500,damping:30},children:[c.jsx("div",{className:`
          px-3 py-1.5 rounded-full shadow-lg
          ${i?"bg-gradient-to-r from-yellow-400 to-orange-500 text-black":"bg-white text-gray-900"}
          text-sm font-medium
        `,children:s}),c.jsx("div",{className:`
          absolute left-1/2 -translate-x-1/2 -bottom-1.5
          w-3 h-3 rotate-45
          ${i?"bg-gradient-to-br from-yellow-400 to-orange-500":"bg-white"}
        `}),e.xp_awarded>0&&c.jsxs(B.div,{className:"absolute -top-5 left-1/2 -translate-x-1/2 text-xs font-bold text-green-400",initial:{opacity:0,y:5},animate:{opacity:1,y:0},exit:{opacity:0,y:-5},children:["+",e.xp_awarded," XP"]}),e.units_awarded>0&&c.jsxs(B.div,{className:"absolute -top-5 right-0 text-xs font-bold text-yellow-400",initial:{opacity:0,y:5},animate:{opacity:1,y:0},exit:{opacity:0,y:-5},transition:{delay:.1},children:["+",e.units_awarded," 🪙"]})]})}const jv=m.lazy(()=>E(()=>import("./CompanionPanel-kigvzuwg.js"),__vite__mapDeps([9,1,5,6]))),Lv=["/messages"];function Uv(){const{user:e}=Zh(),t=et(),{state:n,panelOpen:s,setPanelOpen:i,reaction:a,reducedMotion:o,updateSettings:l,stageName:u}=Ov();if(!e||!n||!n.is_visible||Lv.includes(t.pathname))return null;const d=y=>{y.stopPropagation(),l({is_minimized:!n.is_minimized})},h=()=>{i(!0)},f=y=>{(y.key==="Enter"||y.key===" ")&&h()},g=o?{}:{initial:{scale:0,opacity:0},animate:{scale:1,opacity:1},exit:{scale:0,opacity:0}};return c.jsxs(c.Fragment,{children:[c.jsx(B.div,{className:"fixed bottom-20 right-4 z-40 sm:bottom-24",...g,role:"region","aria-label":"Training companion",children:n.is_minimized?c.jsxs(B.button,{onClick:d,className:"w-14 h-14 rounded-full bg-gradient-to-br from-purple-600 to-indigo-700 shadow-lg flex items-center justify-center hover:scale-105 transition-transform",whileHover:o?{}:{scale:1.1},whileTap:o?{}:{scale:.95},"aria-label":"Expand companion",children:[c.jsx("span",{className:"text-2xl",children:"🐾"}),c.jsx("span",{className:"absolute -top-1 -right-1 w-5 h-5 rounded-full bg-yellow-500 text-xs font-bold text-black flex items-center justify-center shadow-md",children:n.stage})]}):c.jsxs("div",{className:"relative",children:[c.jsx(Ct,{children:a&&c.jsx(Dv,{event:a})}),c.jsx(B.div,{className:"w-28 h-28 cursor-pointer",onClick:h,onKeyDown:f,whileHover:o?{}:{y:-6},role:"button","aria-label":"Open companion panel",tabIndex:0,children:c.jsx($v,{stage:n.stage,equipped:n.equipped_cosmetics,reaction:a?.event_type,reducedMotion:o})}),c.jsx("button",{onClick:d,className:"absolute -top-2 -right-2 w-7 h-7 rounded-full bg-gray-800 text-white text-sm flex items-center justify-center hover:bg-gray-700 transition-colors shadow-md","aria-label":"Minimize companion",children:"−"}),c.jsx("div",{className:"absolute -bottom-6 left-1/2 -translate-x-1/2 text-center whitespace-nowrap",children:n.nickname?c.jsx("span",{className:"text-xs text-gray-400 font-medium",children:n.nickname}):c.jsx("span",{className:"text-xs text-gray-500",children:u})})]})}),c.jsx(Ct,{children:s&&c.jsx(m.Suspense,{fallback:c.jsx("div",{className:"fixed inset-0 bg-black/50 z-50 flex items-center justify-center",children:c.jsx("div",{className:"w-8 h-8 border-2 border-purple-500 border-t-transparent rounded-full animate-spin"})}),children:c.jsx(jv,{onClose:()=>i(!1)})})})]})}const Vv=Object.freeze({__proto__:null,default:Uv});const Bv=e=>e.replace(/([a-z0-9])([A-Z])/g,"$1-$2").toLowerCase(),Fv=e=>e.replace(/^([A-Z])|[\s-_]+(\w)/g,(t,n,s)=>s?s.toUpperCase():n.toLowerCase()),zo=e=>{const t=Fv(e);return t.charAt(0).toUpperCase()+t.slice(1)},Pu=(...e)=>e.filter((t,n,s)=>!!t&&t.trim()!==""&&s.indexOf(t)===n).join(" ").trim(),qv=e=>{for(const t in e)if(t.startsWith("aria-")||t==="role"||t==="title")return!0};var Wv={xmlns:"http://www.w3.org/2000/svg",width:24,height:24,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:2,strokeLinecap:"round",strokeLinejoin:"round"};const zv=m.forwardRef(({color:e="currentColor",size:t=24,strokeWidth:n=2,absoluteStrokeWidth:s,className:i="",children:a,iconNode:o,...l},u)=>m.createElement("svg",{ref:u,...Wv,width:t,height:t,stroke:e,strokeWidth:s?Number(n)*24/Number(t):n,className:Pu("lucide",i),...!a&&!qv(l)&&{"aria-hidden":"true"},...l},[...o.map(([d,h])=>m.createElement(d,h)),...Array.isArray(a)?a:[a]]));const D=(e,t)=>{const n=m.forwardRef(({className:s,...i},a)=>m.createElement(zv,{ref:a,iconNode:t,className:Pu(`lucide-${Bv(zo(e))}`,`lucide-${e}`,s),...i}));return n.displayName=zo(e),n};const Hv=[["path",{d:"M22 12h-2.48a2 2 0 0 0-1.93 1.46l-2.35 8.36a.25.25 0 0 1-.48 0L9.24 2.18a.25.25 0 0 0-.48 0l-2.35 8.36A2 2 0 0 1 4.49 12H2",key:"169zse"}]],Mu=D("activity",Hv);const Gv=[["path",{d:"M12 6.528V3a1 1 0 0 1 1-1h0",key:"11qiee"}],["path",{d:"M18.237 21A15 15 0 0 0 22 11a6 6 0 0 0-10-4.472A6 6 0 0 0 2 11a15.1 15.1 0 0 0 3.763 10 3 3 0 0 0 3.648.648 5.5 5.5 0 0 1 5.178 0A3 3 0 0 0 18.237 21",key:"110c12"}]],Yv=D("apple",Gv);const Kv=[["path",{d:"M12 5v14",key:"s699le"}],["path",{d:"m19 12-7 7-7-7",key:"1idqje"}]],Qv=D("arrow-down",Kv);const Jv=[["path",{d:"M5 12h14",key:"1ays0h"}],["path",{d:"m12 5 7 7-7 7",key:"xquz4c"}]],Rt=D("arrow-right",Jv);const Xv=[["path",{d:"m5 12 7-7 7 7",key:"hav0vg"}],["path",{d:"M12 19V5",key:"x0mq9r"}]],Zv=D("arrow-up",Xv);const eS=[["path",{d:"M10.268 21a2 2 0 0 0 3.464 0",key:"vwvbt9"}],["path",{d:"M3.262 15.326A1 1 0 0 0 4 17h16a1 1 0 0 0 .74-1.673C19.41 13.956 18 12.499 18 8A6 6 0 0 0 6 8c0 4.499-1.411 5.956-2.738 7.326",key:"11g9vi"}]],tS=D("bell",eS);const nS=[["path",{d:"M12 7v14",key:"1akyts"}],["path",{d:"M3 18a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1h5a4 4 0 0 1 4 4 4 4 0 0 1 4-4h5a1 1 0 0 1 1 1v13a1 1 0 0 1-1 1h-6a3 3 0 0 0-3 3 3 3 0 0 0-3-3z",key:"ruj8y"}]],sS=D("book-open",nS);const rS=[["path",{d:"M12 18V5",key:"adv99a"}],["path",{d:"M15 13a4.17 4.17 0 0 1-3-4 4.17 4.17 0 0 1-3 4",key:"1e3is1"}],["path",{d:"M17.598 6.5A3 3 0 1 0 12 5a3 3 0 1 0-5.598 1.5",key:"1gqd8o"}],["path",{d:"M17.997 5.125a4 4 0 0 1 2.526 5.77",key:"iwvgf7"}],["path",{d:"M18 18a4 4 0 0 0 2-7.464",key:"efp6ie"}],["path",{d:"M19.967 17.483A4 4 0 1 1 12 18a4 4 0 1 1-7.967-.517",key:"1gq6am"}],["path",{d:"M6 18a4 4 0 0 1-2-7.464",key:"k1g0md"}],["path",{d:"M6.003 5.125a4 4 0 0 0-2.526 5.77",key:"q97ue3"}]],iS=D("brain",rS);const aS=[["path",{d:"M12 20v-9",key:"1qisl0"}],["path",{d:"M14 7a4 4 0 0 1 4 4v3a6 6 0 0 1-12 0v-3a4 4 0 0 1 4-4z",key:"uouzyp"}],["path",{d:"M14.12 3.88 16 2",key:"qol33r"}],["path",{d:"M21 21a4 4 0 0 0-3.81-4",key:"1b0z45"}],["path",{d:"M21 5a4 4 0 0 1-3.55 3.97",key:"5cxbf6"}],["path",{d:"M22 13h-4",key:"1jl80f"}],["path",{d:"M3 21a4 4 0 0 1 3.81-4",key:"1fjd4g"}],["path",{d:"M3 5a4 4 0 0 0 3.55 3.97",key:"1d7oge"}],["path",{d:"M6 13H2",key:"82j7cp"}],["path",{d:"m8 2 1.88 1.88",key:"fmnt4t"}],["path",{d:"M9 7.13V6a3 3 0 1 1 6 0v1.13",key:"1vgav8"}]],oS=D("bug",aS);const cS=[["path",{d:"M8 2v4",key:"1cmpym"}],["path",{d:"M16 2v4",key:"4m81vk"}],["rect",{width:"18",height:"18",x:"3",y:"4",rx:"2",key:"1hopcy"}],["path",{d:"M3 10h18",key:"8toen8"}]],Ou=D("calendar",cS);const lS=[["path",{d:"M13.997 4a2 2 0 0 1 1.76 1.05l.486.9A2 2 0 0 0 18.003 7H20a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V9a2 2 0 0 1 2-2h1.997a2 2 0 0 0 1.759-1.048l.489-.904A2 2 0 0 1 10.004 4z",key:"18u6gg"}],["circle",{cx:"12",cy:"13",r:"3",key:"1vg3eu"}]],uS=D("camera",lS);const dS=[["path",{d:"M3 3v16a2 2 0 0 0 2 2h16",key:"c24i48"}],["path",{d:"M18 17V9",key:"2bz60n"}],["path",{d:"M13 17V5",key:"1frdt8"}],["path",{d:"M8 17v-3",key:"17ska0"}]],Nu=D("chart-column",dS);const mS=[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3",key:"1u773s"}],["path",{d:"M12 17h.01",key:"p32p05"}]],$u=D("circle-question-mark",mS);const hS=[["path",{d:"M12 6v6l4 2",key:"mmk7yg"}],["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}]],Du=D("clock",hS);const pS=[["path",{d:"m16 18 6-6-6-6",key:"eg8j8"}],["path",{d:"m8 6-6 6 6 6",key:"ppft3o"}]],fS=D("code",pS);const gS=[["circle",{cx:"8",cy:"8",r:"6",key:"3yglwk"}],["path",{d:"M18.09 10.37A6 6 0 1 1 10.34 18",key:"t5s6rm"}],["path",{d:"M7 6h1v4",key:"1obek4"}],["path",{d:"m16.71 13.88.7.71-2.82 2.82",key:"1rbuyh"}]],yS=D("coins",gS);const vS=[["path",{d:"M15 6v12a3 3 0 1 0 3-3H6a3 3 0 1 0 3 3V6a3 3 0 1 0-3 3h12a3 3 0 1 0-3-3",key:"11bfej"}]],SS=D("command",vS);const TS=[["path",{d:"m16.24 7.76-1.804 5.411a2 2 0 0 1-1.265 1.265L7.76 16.24l1.804-5.411a2 2 0 0 1 1.265-1.265z",key:"9ktpf1"}],["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}]],Pi=D("compass",TS);const bS=[["path",{d:"M20 4v7a4 4 0 0 1-4 4H4",key:"6o5b7l"}],["path",{d:"m9 10-5 5 5 5",key:"1kshq7"}]],wS=D("corner-down-left",bS);const IS=[["path",{d:"M11.562 3.266a.5.5 0 0 1 .876 0L15.39 8.87a1 1 0 0 0 1.516.294L21.183 5.5a.5.5 0 0 1 .798.519l-2.834 10.246a1 1 0 0 1-.956.734H5.81a1 1 0 0 1-.957-.734L2.02 6.02a.5.5 0 0 1 .798-.519l4.276 3.664a1 1 0 0 0 1.516-.294z",key:"1vdc57"}],["path",{d:"M5 21h14",key:"11awu3"}]],xS=D("crown",IS);const ES=[["path",{d:"M17.596 12.768a2 2 0 1 0 2.829-2.829l-1.768-1.767a2 2 0 0 0 2.828-2.829l-2.828-2.828a2 2 0 0 0-2.829 2.828l-1.767-1.768a2 2 0 1 0-2.829 2.829z",key:"9m4mmf"}],["path",{d:"m2.5 21.5 1.4-1.4",key:"17g3f0"}],["path",{d:"m20.1 3.9 1.4-1.4",key:"1qn309"}],["path",{d:"M5.343 21.485a2 2 0 1 0 2.829-2.828l1.767 1.768a2 2 0 1 0 2.829-2.829l-6.364-6.364a2 2 0 1 0-2.829 2.829l1.768 1.767a2 2 0 0 0-2.828 2.829z",key:"1t2c92"}],["path",{d:"m9.6 14.4 4.8-4.8",key:"6umqxw"}]],Mi=D("dumbbell",ES);const AS=[["path",{d:"M12 3q1 4 4 6.5t3 5.5a1 1 0 0 1-14 0 5 5 0 0 1 1-3 1 1 0 0 0 5 0c0-2-1.5-3-1.5-5q0-2 2.5-4",key:"1slcih"}]],_S=D("flame",AS);const CS=[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"M12 2a14.5 14.5 0 0 0 0 20 14.5 14.5 0 0 0 0-20",key:"13o1zl"}],["path",{d:"M2 12h20",key:"9i4pu4"}]],kS=D("globe",CS);const RS=[["path",{d:"M18 11V6a2 2 0 0 0-2-2a2 2 0 0 0-2 2",key:"1fvzgz"}],["path",{d:"M14 10V4a2 2 0 0 0-2-2a2 2 0 0 0-2 2v2",key:"1kc0my"}],["path",{d:"M10 10.5V6a2 2 0 0 0-2-2a2 2 0 0 0-2 2v8",key:"10h0bg"}],["path",{d:"M18 8a2 2 0 1 1 4 0v6a8 8 0 0 1-8 8h-2c-2.8 0-4.5-.86-5.99-2.34l-3.6-3.6a2 2 0 0 1 2.83-2.82L7 15",key:"1s1gnw"}]],PS=D("hand",RS);const MS=[["path",{d:"M2 9.5a5.5 5.5 0 0 1 9.591-3.676.56.56 0 0 0 .818 0A5.49 5.49 0 0 1 22 9.5c0 2.29-1.5 4-3 5.5l-5.492 5.313a2 2 0 0 1-3 .019L5 15c-1.5-1.5-3-3.2-3-5.5",key:"mvr1a0"}]],ju=D("heart",MS);const OS=[["rect",{width:"7",height:"9",x:"3",y:"3",rx:"1",key:"10lvy0"}],["rect",{width:"7",height:"5",x:"14",y:"3",rx:"1",key:"16une8"}],["rect",{width:"7",height:"9",x:"14",y:"12",rx:"1",key:"1hutg5"}],["rect",{width:"7",height:"5",x:"3",y:"16",rx:"1",key:"ldoo1y"}]],NS=D("layout-dashboard",OS);const $S=[["path",{d:"M15 14c.2-1 .7-1.7 1.5-2.5 1-.9 1.5-2.2 1.5-3.5A6 6 0 0 0 6 8c0 1 .2 2.2 1.5 3.5.7.7 1.3 1.5 1.5 2.5",key:"1gvzjb"}],["path",{d:"M9 18h6",key:"x1upvd"}],["path",{d:"M10 22h4",key:"ceow96"}]],DS=D("lightbulb",$S);const jS=[["path",{d:"M20 10c0 4.993-5.539 10.193-7.399 11.799a1 1 0 0 1-1.202 0C9.539 20.193 4 14.993 4 10a8 8 0 0 1 16 0",key:"1r0f0z"}],["circle",{cx:"12",cy:"10",r:"3",key:"ilqhr7"}]],LS=D("map-pin",jS);const US=[["path",{d:"M14.106 5.553a2 2 0 0 0 1.788 0l3.659-1.83A1 1 0 0 1 21 4.619v12.764a1 1 0 0 1-.553.894l-4.553 2.277a2 2 0 0 1-1.788 0l-4.212-2.106a2 2 0 0 0-1.788 0l-3.659 1.83A1 1 0 0 1 3 19.381V6.618a1 1 0 0 1 .553-.894l4.553-2.277a2 2 0 0 1 1.788 0z",key:"169xi5"}],["path",{d:"M15 5.764v15",key:"1pn4in"}],["path",{d:"M9 3.236v15",key:"1uimfh"}]],Lu=D("map",US);const VS=[["path",{d:"M2.992 16.342a2 2 0 0 1 .094 1.167l-1.065 3.29a1 1 0 0 0 1.236 1.168l3.413-.998a2 2 0 0 1 1.099.092 10 10 0 1 0-4.777-4.719",key:"1sd12s"}]],Uu=D("message-circle",VS);const BS=[["path",{d:"M22 17a2 2 0 0 1-2 2H6.828a2 2 0 0 0-1.414.586l-2.202 2.202A.71.71 0 0 1 2 21.286V5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2z",key:"18887p"}]],FS=D("message-square",BS);const qS=[["path",{d:"M20.985 12.486a9 9 0 1 1-9.473-9.472c.405-.022.617.46.402.803a6 6 0 0 0 8.268 8.268c.344-.215.825-.004.803.401",key:"kfwtm"}]],WS=D("moon",qS);const zS=[["path",{d:"M15 18h-5",key:"95g1m2"}],["path",{d:"M18 14h-8",key:"sponae"}],["path",{d:"M4 22h16a2 2 0 0 0 2-2V4a2 2 0 0 0-2-2H8a2 2 0 0 0-2 2v16a2 2 0 0 1-4 0v-9a2 2 0 0 1 2-2h2",key:"39pd36"}],["rect",{width:"8",height:"4",x:"10",y:"6",rx:"1",key:"aywv1n"}]],HS=D("newspaper",zS);const GS=[["path",{d:"M12 22a1 1 0 0 1 0-20 10 9 0 0 1 10 9 5 5 0 0 1-5 5h-2.25a1.75 1.75 0 0 0-1.4 2.8l.3.4a1.75 1.75 0 0 1-1.4 2.8z",key:"e79jfc"}],["circle",{cx:"13.5",cy:"6.5",r:".5",fill:"currentColor",key:"1okk4w"}],["circle",{cx:"17.5",cy:"10.5",r:".5",fill:"currentColor",key:"f64h9f"}],["circle",{cx:"6.5",cy:"12.5",r:".5",fill:"currentColor",key:"qy21gx"}],["circle",{cx:"8.5",cy:"7.5",r:".5",fill:"currentColor",key:"fotxhn"}]],YS=D("palette",GS);const KS=[["path",{d:"M5 5a2 2 0 0 1 3.008-1.728l11.997 6.998a2 2 0 0 1 .003 3.458l-12 7A2 2 0 0 1 5 19z",key:"10ikf1"}]],QS=D("play",KS);const JS=[["path",{d:"M5 12h14",key:"1ays0h"}],["path",{d:"M12 5v14",key:"s699le"}]],XS=D("plus",JS);const ZS=[["path",{d:"M15.39 4.39a1 1 0 0 0 1.68-.474 2.5 2.5 0 1 1 3.014 3.015 1 1 0 0 0-.474 1.68l1.683 1.682a2.414 2.414 0 0 1 0 3.414L19.61 15.39a1 1 0 0 1-1.68-.474 2.5 2.5 0 1 0-3.014 3.015 1 1 0 0 1 .474 1.68l-1.683 1.682a2.414 2.414 0 0 1-3.414 0L8.61 19.61a1 1 0 0 0-1.68.474 2.5 2.5 0 1 1-3.014-3.015 1 1 0 0 0 .474-1.68l-1.683-1.682a2.414 2.414 0 0 1 0-3.414L4.39 8.61a1 1 0 0 1 1.68.474 2.5 2.5 0 1 0 3.014-3.015 1 1 0 0 1-.474-1.68l1.683-1.682a2.414 2.414 0 0 1 3.414 0z",key:"w46dr5"}]],eT=D("puzzle",ZS);const tT=[["path",{d:"M16.247 7.761a6 6 0 0 1 0 8.478",key:"1fwjs5"}],["path",{d:"M19.075 4.933a10 10 0 0 1 0 14.134",key:"ehdyv1"}],["path",{d:"M4.925 19.067a10 10 0 0 1 0-14.134",key:"1q22gi"}],["path",{d:"M7.753 16.239a6 6 0 0 1 0-8.478",key:"r2q7qm"}],["circle",{cx:"12",cy:"12",r:"2",key:"1c9p78"}]],nT=D("radio",tT);const sT=[["path",{d:"M21.3 15.3a2.4 2.4 0 0 1 0 3.4l-2.6 2.6a2.4 2.4 0 0 1-3.4 0L2.7 8.7a2.41 2.41 0 0 1 0-3.4l2.6-2.6a2.41 2.41 0 0 1 3.4 0Z",key:"icamh8"}],["path",{d:"m14.5 12.5 2-2",key:"inckbg"}],["path",{d:"m11.5 9.5 2-2",key:"fmmyf7"}],["path",{d:"m8.5 6.5 2-2",key:"vc6u1g"}],["path",{d:"m17.5 15.5 2-2",key:"wo5hmg"}]],rT=D("ruler",sT);const iT=[["path",{d:"m21 21-4.34-4.34",key:"14j7rj"}],["circle",{cx:"11",cy:"11",r:"8",key:"4ej97u"}]],Oi=D("search",iT);const aT=[["path",{d:"M9.671 4.136a2.34 2.34 0 0 1 4.659 0 2.34 2.34 0 0 0 3.319 1.915 2.34 2.34 0 0 1 2.33 4.033 2.34 2.34 0 0 0 0 3.831 2.34 2.34 0 0 1-2.33 4.033 2.34 2.34 0 0 0-3.319 1.915 2.34 2.34 0 0 1-4.659 0 2.34 2.34 0 0 0-3.32-1.915 2.34 2.34 0 0 1-2.33-4.033 2.34 2.34 0 0 0 0-3.831A2.34 2.34 0 0 1 6.35 6.051a2.34 2.34 0 0 0 3.319-1.915",key:"1i5ecw"}],["circle",{cx:"12",cy:"12",r:"3",key:"1v7zrd"}]],Ni=D("settings",aT);const oT=[["path",{d:"M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z",key:"oel41y"}]],cT=D("shield",oT);const lT=[["path",{d:"M11.017 2.814a1 1 0 0 1 1.966 0l1.051 5.558a2 2 0 0 0 1.594 1.594l5.558 1.051a1 1 0 0 1 0 1.966l-5.558 1.051a2 2 0 0 0-1.594 1.594l-1.051 5.558a1 1 0 0 1-1.966 0l-1.051-5.558a2 2 0 0 0-1.594-1.594l-5.558-1.051a1 1 0 0 1 0-1.966l5.558-1.051a2 2 0 0 0 1.594-1.594z",key:"1s2grr"}],["path",{d:"M20 2v4",key:"1rf3ol"}],["path",{d:"M22 4h-4",key:"gwowj6"}],["circle",{cx:"4",cy:"20",r:"2",key:"6kqj1y"}]],ns=D("sparkles",lT);const uT=[["path",{d:"M11.525 2.295a.53.53 0 0 1 .95 0l2.31 4.679a2.123 2.123 0 0 0 1.595 1.16l5.166.756a.53.53 0 0 1 .294.904l-3.736 3.638a2.123 2.123 0 0 0-.611 1.878l.882 5.14a.53.53 0 0 1-.771.56l-4.618-2.428a2.122 2.122 0 0 0-1.973 0L6.396 21.01a.53.53 0 0 1-.77-.56l.881-5.139a2.122 2.122 0 0 0-.611-1.879L2.16 9.795a.53.53 0 0 1 .294-.906l5.165-.755a2.122 2.122 0 0 0 1.597-1.16z",key:"r04s7s"}]],dT=D("star",uT);const mT=[["polyline",{points:"14.5 17.5 3 6 3 3 6 3 17.5 14.5",key:"1hfsw2"}],["line",{x1:"13",x2:"19",y1:"19",y2:"13",key:"1vrmhu"}],["line",{x1:"16",x2:"20",y1:"16",y2:"20",key:"1bron3"}],["line",{x1:"19",x2:"21",y1:"21",y2:"19",key:"13pww6"}],["polyline",{points:"14.5 6.5 18 3 21 3 21 6 17.5 9.5",key:"hbey2j"}],["line",{x1:"5",x2:"9",y1:"14",y2:"18",key:"1hf58s"}],["line",{x1:"7",x2:"4",y1:"17",y2:"20",key:"pidxm4"}],["line",{x1:"3",x2:"5",y1:"19",y2:"21",key:"1pehsh"}]],hT=D("swords",mT);const pT=[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["circle",{cx:"12",cy:"12",r:"6",key:"1vlfrh"}],["circle",{cx:"12",cy:"12",r:"2",key:"1c9p78"}]],Vu=D("target",pT);const fT=[["path",{d:"M16 7h6v6",key:"box55l"}],["path",{d:"m22 7-8.5 8.5-5-5L2 17",key:"1t1m79"}]],ss=D("trending-up",fT);const gT=[["path",{d:"M10 14.66v1.626a2 2 0 0 1-.976 1.696A5 5 0 0 0 7 21.978",key:"1n3hpd"}],["path",{d:"M14 14.66v1.626a2 2 0 0 0 .976 1.696A5 5 0 0 1 17 21.978",key:"rfe1zi"}],["path",{d:"M18 9h1.5a1 1 0 0 0 0-5H18",key:"7xy6bh"}],["path",{d:"M4 22h16",key:"57wxv0"}],["path",{d:"M6 9a6 6 0 0 0 12 0V3a1 1 0 0 0-1-1H7a1 1 0 0 0-1 1z",key:"1mhfuq"}],["path",{d:"M6 9H4.5a1 1 0 0 1 0-5H6",key:"tex48p"}]],Bu=D("trophy",gT);const yT=[["path",{d:"m16 11 2 2 4-4",key:"9rsbq5"}],["path",{d:"M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2",key:"1yyitq"}],["circle",{cx:"9",cy:"7",r:"4",key:"nufk8"}]],vT=D("user-check",yT);const ST=[["path",{d:"M10 15H6a4 4 0 0 0-4 4v2",key:"1nfge6"}],["path",{d:"m14.305 16.53.923-.382",key:"1itpsq"}],["path",{d:"m15.228 13.852-.923-.383",key:"eplpkm"}],["path",{d:"m16.852 12.228-.383-.923",key:"13v3q0"}],["path",{d:"m16.852 17.772-.383.924",key:"1i8mnm"}],["path",{d:"m19.148 12.228.383-.923",key:"1q8j1v"}],["path",{d:"m19.53 18.696-.382-.924",key:"vk1qj3"}],["path",{d:"m20.772 13.852.924-.383",key:"n880s0"}],["path",{d:"m20.772 16.148.924.383",key:"1g6xey"}],["circle",{cx:"18",cy:"15",r:"3",key:"gjjjvw"}],["circle",{cx:"9",cy:"7",r:"4",key:"nufk8"}]],TT=D("user-cog",ST);const bT=[["path",{d:"M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2",key:"975kel"}],["circle",{cx:"12",cy:"7",r:"4",key:"17ys0d"}]],wT=D("user",bT);const IT=[["path",{d:"M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2",key:"1yyitq"}],["path",{d:"M16 3.128a4 4 0 0 1 0 7.744",key:"16gr8j"}],["path",{d:"M22 21v-2a4 4 0 0 0-3-3.87",key:"kshegd"}],["circle",{cx:"9",cy:"7",r:"4",key:"nufk8"}]],$i=D("users",IT);const xT=[["path",{d:"M19 7V4a1 1 0 0 0-1-1H5a2 2 0 0 0 0 4h15a1 1 0 0 1 1 1v4h-3a2 2 0 0 0 0 4h3a1 1 0 0 0 1-1v-2a1 1 0 0 0-1-1",key:"18etb6"}],["path",{d:"M3 5v14a2 2 0 0 0 2 2h15a1 1 0 0 0 1-1v-4",key:"xoc0q4"}]],ET=D("wallet",xT);const AT=[["path",{d:"M18 6 6 18",key:"1bl5f8"}],["path",{d:"m6 6 12 12",key:"d8bk6v"}]],Di=D("x",AT);const _T=[["path",{d:"M4 14a1 1 0 0 1-.78-1.63l9.9-10.2a.5.5 0 0 1 .86.46l-1.92 6.02A1 1 0 0 0 13 10h7a1 1 0 0 1 .78 1.63l-9.9 10.2a.5.5 0 0 1-.86-.46l1.92-6.02A1 1 0 0 0 11 14z",key:"1xq2db"}]],ji=D("zap",_T),CT={LayoutDashboard:NS,Dumbbell:Mi,Activity:Mu,Map:Lu,BarChart3:Nu,TrendingUp:ss,Target:Vu,User:wT,Trophy:Bu,Coins:yS,Heart:ju,Apple:Yv,Sparkles:ns,Users:$i,Swords:hT,Hand:PS,MessageCircle:Uu,UserCheck:vT,Play:QS,Plus:XS,Calendar:Ou,MapPin:LS,Settings:Ni,Bell:tS,Shield:cT,Palette:YS,Clock:Du,ArrowRight:Rt,Search:Oi,Zap:ji,Compass:Pi,Wallet:ET,Moon:WS,Globe:kS,Ruler:rT,UserCog:TT,Puzzle:eT,Radio:nT,Newspaper:HS,BookOpen:sS,Code:fS,Bug:oS,Lightbulb:DS,MessageSquare:FS,Camera:uS},Vr={Pages:Pi,Exercises:Mi,Actions:ji,Community:$i,Settings:Ni,Recent:Du};function kT(e,t){return e?typeof e=="string"?CT[e]||Vr[t]||Rt:e:Vr[t]||Rt}const RT={hidden:{opacity:0,x:-8},visible:e=>({opacity:1,x:0,transition:{duration:.15,delay:e*.025}})},PT=m.memo(function({segments:t,className:n}){return!t||t.length===0?null:c.jsx("span",{className:n,children:t.map((s,i)=>s.highlight?c.jsx("mark",{className:"bg-transparent text-[var(--brand-blue-400)] font-semibold",children:s.text},i):c.jsx("span",{children:s.text},i))})}),MT=m.forwardRef(function({item:t,index:n=0,isSelected:s=!1,onClick:i,highlights:a},o){const{title:l,description:u,icon:d,category:h,shortcut:f}=t,g=kT(d,h);return c.jsxs(B.button,{ref:o,custom:n,variants:RT,initial:"hidden",animate:"visible",onClick:()=>i?.(t),className:`
        w-full flex items-center gap-3 px-4 py-3 text-left
        rounded-xl transition-all duration-150 group
        ${s?"bg-[var(--brand-blue-500)]/15 border border-[var(--brand-blue-500)]/30":"bg-transparent border border-transparent hover:bg-white/5"}
      `,style:{boxShadow:s?"0 0 20px rgba(0, 102, 255, 0.15), inset 0 1px 1px rgba(255, 255, 255, 0.05)":"none"},role:"option","aria-selected":s,children:[c.jsx("div",{className:`
          w-10 h-10 flex items-center justify-center rounded-lg flex-shrink-0
          transition-colors duration-150
          ${s?"bg-[var(--brand-blue-500)] text-white":"bg-white/10 text-white/60 group-hover:bg-white/15 group-hover:text-white/80"}
        `,children:c.jsx(g,{size:20,strokeWidth:1.5})}),c.jsxs("div",{className:"flex-1 min-w-0",children:[c.jsx("div",{className:`
            font-medium truncate transition-colors duration-150
            ${s?"text-white":"text-white/90"}
          `,children:a?c.jsx(PT,{segments:a}):l}),u&&c.jsx("div",{className:`
              text-sm truncate transition-colors duration-150
              ${s?"text-white/70":"text-white/50"}
            `,children:u})]}),c.jsxs("div",{className:"flex items-center gap-2 flex-shrink-0",children:[f&&!s&&c.jsx("span",{className:"text-xs text-white/30 font-mono hidden sm:block",children:f}),s&&c.jsx("kbd",{className:`
              px-2 py-1 text-xs font-medium rounded
              bg-white/10 text-white/70
              border border-white/10
            `,children:"Enter"})]})]})}),OT=m.memo(function({category:t,count:n,onClear:s}){const i=Vr[t]||Rt;return c.jsxs("div",{className:"flex items-center justify-between px-4 py-2 mt-2 first:mt-0",children:[c.jsxs("div",{className:"flex items-center gap-2",children:[c.jsx(i,{size:14,className:"text-white/30",strokeWidth:1.5}),c.jsx("span",{className:"text-xs font-medium text-white/40 uppercase tracking-wider",children:t}),n!==void 0&&c.jsxs("span",{className:"text-xs text-white/20",children:["(",n,")"]})]}),s&&c.jsx("button",{onClick:a=>{a.stopPropagation(),s()},className:"text-xs text-white/30 hover:text-white/60 transition-colors",children:"Clear"})]})}),NT=m.memo(function({query:t}){return c.jsxs("div",{className:"py-12 text-center",children:[c.jsx("div",{className:`
          w-16 h-16 mx-auto mb-4 rounded-2xl
          bg-white/5 flex items-center justify-center
        `,children:c.jsx(Oi,{size:28,className:"text-white/20",strokeWidth:1.5})}),c.jsx("p",{className:"text-white/60 font-medium",children:"No results found"}),c.jsx("p",{className:"text-white/40 text-sm mt-1",children:t?`Nothing matches "${t}"`:"Try searching for something"}),c.jsxs("div",{className:"mt-6 text-xs text-white/30 space-y-1",children:[c.jsx("p",{children:"Try searching for:"}),c.jsx("p",{className:"text-white/50",children:'"workout", "settings", "profile"'})]})]})}),$T=m.memo(MT),U={PAGES:"Pages",EXERCISES:"Exercises",ACTIONS:"Actions",COMMUNITY:"Community",SETTINGS:"Settings",RECENT:"Recent"},Pt=[U.RECENT,U.PAGES,U.ACTIONS,U.EXERCISES,U.COMMUNITY,U.SETTINGS],Fu=new Map,DT=new Set;function zs(e,t){if(!e||!t)return 0;const n=e.toLowerCase().trim(),s=t.toLowerCase();if(n.length===0)return 1;if(s===n)return 1e3;if(s.startsWith(n))return 900;const i=s.split(/\s+/),a=n.split(/\s+/);let o=0;for(const g of a)i.some(y=>y.startsWith(g))&&o++;if(o===a.length)return 800+o*10;const l=s.indexOf(n);if(l!==-1)return 700-Math.min(l*10,200);let u=0,d=0,h=-1,f=0;for(let g=0;g<s.length&&d<n.length;g++)if(s[g]===n[d]){if(f++,u+=10+f*5,(g===0||/\s/.test(s[g-1]))&&(u+=15),h!==-1){const y=g-h-1;u-=Math.min(y*2,20)}h=g,d++}else f=0;return d<n.length?0:Math.max(u,1)}function jT(e,t){if(!e||!t)return[{text:t,highlight:!1}];const n=e.toLowerCase().trim(),s=t.toLowerCase(),i=[];let a=0;const o=s.indexOf(n);if(o!==-1)return o>0&&i.push({text:t.slice(0,o),highlight:!1}),i.push({text:t.slice(o,o+e.length),highlight:!0}),o+e.length<t.length&&i.push({text:t.slice(o+e.length),highlight:!1}),i;let l=0;for(let u=0;u<t.length&&l<n.length;u++)s[u]===n[l]&&(u>a&&i.push({text:t.slice(a,u),highlight:!1}),i.push({text:t[u],highlight:!0}),a=u+1,l++);return a<t.length&&i.push({text:t.slice(a),highlight:!1}),i.length>0?i:[{text:t,highlight:!1}]}function qu(e){if(!e.id||!e.title)return!1;const t={category:U.ACTIONS,...e,keywords:Array.isArray(e.keywords)?e.keywords:[]};return Fu.set(e.id,t),BT(),!0}function LT(e){e.forEach(qu)}function UT(){return Array.from(Fu.values())}function Br(e,t={}){const{categories:n=[],maxResults:s=5}=t,i=(e||"").trim(),a=UT(),l=(n.length>0?a.filter(d=>n.includes(d.category)):a).map(d=>{const h=zs(i,d.title),f=d.description?zs(i,d.description)*.6:0,g=d.keywords.map(T=>zs(i,T)*.8),y=Math.max(0,...g),v=Math.max(h,f,y);return{...d,score:v,highlights:i?jT(i,d.title):null}}).filter(d=>d.score>0||!i).sort((d,h)=>h.score-d.score),u={};return Pt.forEach(d=>{const h=l.filter(f=>f.category===d);h.length>0&&(u[d]=h.slice(0,s))}),l.forEach(d=>{Pt.includes(d.category)||(u[d.category]||(u[d.category]=[]),u[d.category].length<s&&u[d.category].push(d))}),u}function VT(e,t={}){const n=Br(e,t),s=[];return Pt.forEach(i=>{n[i]&&s.push(...n[i])}),Object.keys(n).forEach(i=>{Pt.includes(i)||s.push(...n[i])}),s}function BT(){DT.forEach(e=>{try{e()}catch{}})}const FT=[{id:"page-dashboard",title:"Dashboard",description:"Your fitness overview",path:"/dashboard",icon:"LayoutDashboard",category:U.PAGES,keywords:["home","overview","main"],shortcut:"G then D"},{id:"page-workout",title:"Workout",description:"Start or continue a workout",path:"/workout",icon:"Dumbbell",category:U.PAGES,keywords:["exercise","training","gym","lift"],shortcut:"G then W"},{id:"page-exercises",title:"Exercises",description:"Browse exercise library",path:"/exercises",icon:"Activity",category:U.PAGES,keywords:["movements","library","database"],shortcut:"G then E"},{id:"page-journey",title:"Journey",description:"Your fitness journey and progress",path:"/journey",icon:"Map",category:U.PAGES,keywords:["progress","path","timeline","history"]},{id:"page-stats",title:"Stats",description:"View your statistics and analytics",path:"/stats",icon:"BarChart3",category:U.PAGES,keywords:["analytics","charts","data","numbers"]},{id:"page-progression",title:"Progression",description:"Track your strength progression",path:"/progression",icon:"TrendingUp",category:U.PAGES,keywords:["gains","improvement","growth"]},{id:"page-goals",title:"Goals",description:"Manage your fitness goals",path:"/goals",icon:"Target",category:U.PAGES,keywords:["objectives","targets","milestones"]},{id:"page-profile",title:"Profile",description:"View your profile",path:"/profile",icon:"User",category:U.PAGES,keywords:["account","me","personal"],shortcut:"G then P"},{id:"page-achievements",title:"Achievements",description:"View earned badges and accomplishments",path:"/achievements",icon:"Trophy",category:U.PAGES,keywords:["badges","awards","accomplishments","rewards"]},{id:"page-credits",title:"Credits",description:"Manage your credits",path:"/credits",icon:"Coins",category:U.PAGES,keywords:["points","currency","balance","money"]},{id:"page-wellness",title:"Wellness",description:"Wellness overview and tracking",path:"/wellness",icon:"Heart",category:U.PAGES,keywords:["health","vitals","body"]},{id:"page-nutrition",title:"Nutrition",description:"Track food and macros",path:"/nutrition",icon:"Apple",category:U.PAGES,keywords:["food","diet","macros","calories","eating"]},{id:"page-skills",title:"Skills",description:"Your skill trees",path:"/skills",icon:"Sparkles",category:U.PAGES,keywords:["abilities","talents","tree"]}],qT=[{id:"page-community",title:"Community",description:"Connect with other fitness enthusiasts",path:"/community",icon:"Users",category:U.COMMUNITY,keywords:["social","friends","people","network"],shortcut:"G then C"},{id:"page-competitions",title:"Competitions",description:"Join fitness challenges",path:"/competitions",icon:"Trophy",category:U.COMMUNITY,keywords:["challenges","contests","compete","leaderboard"]},{id:"page-crews",title:"Crews",description:"Manage your workout crews",path:"/crews",icon:"Users",category:U.COMMUNITY,keywords:["teams","groups","squad"]},{id:"page-rivals",title:"Rivals",description:"View your rivals",path:"/rivals",icon:"Swords",category:U.COMMUNITY,keywords:["opponents","competition","versus"]},{id:"page-highfives",title:"High Fives",description:"Send encouragement to others",path:"/highfives",icon:"Hand",category:U.COMMUNITY,keywords:["kudos","support","encourage","clap"]},{id:"page-messages",title:"Messages",description:"Your conversations",path:"/messages",icon:"MessageCircle",category:U.COMMUNITY,keywords:["chat","inbox","dms","conversations"],shortcut:"G then M"},{id:"page-trainers",title:"Trainers",description:"Find personal trainers",path:"/trainers",icon:"UserCheck",category:U.COMMUNITY,keywords:["coaches","mentors","professionals"]}],WT=[{id:"action-start-workout",title:"Start Workout",description:"Begin a new workout session",path:"/workout",icon:"Play",category:U.ACTIONS,keywords:["begin","new","exercise","train"]},{id:"action-log-food",title:"Log Food",description:"Quick log a meal or snack",path:"/nutrition",icon:"Plus",category:U.ACTIONS,keywords:["meal","eat","add","track"]},{id:"action-send-highfive",title:"Send High Five",description:"Encourage a friend",path:"/highfives",icon:"Hand",category:U.ACTIONS,keywords:["kudos","support","cheer"]},{id:"action-view-progress",title:"View Progress",description:"See your fitness journey",path:"/progression",icon:"TrendingUp",category:U.ACTIONS,keywords:["gains","growth","improvement"]},{id:"action-check-schedule",title:"Check Schedule",description:"View your workout schedule",path:"/journey",icon:"Calendar",category:U.ACTIONS,keywords:["plan","calendar","upcoming"]},{id:"action-find-gym",title:"Find Gym",description:"Locate nearby gyms",path:"/locations",icon:"MapPin",category:U.ACTIONS,keywords:["location","nearby","fitness center"]},{id:"action-join-competition",title:"Join Competition",description:"Browse active challenges",path:"/competitions",icon:"Trophy",category:U.ACTIONS,keywords:["challenge","contest","compete"]}],zT=[{id:"settings-main",title:"Settings",description:"App settings and preferences",path:"/settings",icon:"Settings",category:U.SETTINGS,keywords:["preferences","options","config","configure"],shortcut:"G then S"},{id:"settings-profile",title:"Edit Profile",description:"Update your profile information",path:"/settings?tab=profile",icon:"User",category:U.SETTINGS,keywords:["account","personal","info"]},{id:"settings-notifications",title:"Notifications",description:"Manage notification preferences",path:"/settings?tab=notifications",icon:"Bell",category:U.SETTINGS,keywords:["alerts","push","email"]},{id:"settings-privacy",title:"Privacy Settings",description:"Control your privacy",path:"/settings?tab=privacy",icon:"Shield",category:U.SETTINGS,keywords:["security","data","visibility"]},{id:"settings-theme",title:"Theme",description:"Change app appearance",path:"/settings?tab=appearance",icon:"Palette",category:U.SETTINGS,keywords:["dark","light","mode","color","appearance"]}];function HT(){LT([...FT,...qT,...WT,...zT])}HT();const Li="musclemap_command_recent",GT=5;function Wu(){try{const e=localStorage.getItem(Li);return e?JSON.parse(e):[]}catch{return[]}}function YT(e){if(e?.id)try{const n=Wu().filter(i=>i.id!==e.id),s=[{id:e.id,title:e.title,description:e.description,path:e.path,icon:typeof e.icon=="string"?e.icon:void 0,category:U.RECENT,timestamp:Date.now()},...n].slice(0,GT);return localStorage.setItem(Li,JSON.stringify(s)),s}catch{return[]}}function KT(){try{localStorage.removeItem(Li)}catch{}}const QT={hidden:{opacity:0},visible:{opacity:1,transition:{duration:.2}},exit:{opacity:0,transition:{duration:.15}}},JT={hidden:{opacity:0,scale:.96,y:-20},visible:{opacity:1,scale:1,y:0,transition:{type:"spring",stiffness:500,damping:35,mass:.8}},exit:{opacity:0,scale:.98,y:-10,transition:{duration:.12}}};function XT({isOpen:e=!1,onClose:t,onSelect:n,placeholder:s="Search exercises, pages, actions...",categories:i=null,recentSearches:a=!0,maxResults:o=5,initialQuery:l=""}){const u=Ot(),[d,h]=m.useState(l),[f,g]=m.useState(0),[y,v]=m.useState([]),T=m.useRef(null),b=m.useRef(null),I=m.useRef(null);m.useEffect(()=>{e&&a&&v(Wu())},[e,a]),m.useEffect(()=>{e&&(h(l),g(0),requestAnimationFrame(()=>{requestAnimationFrame(()=>{T.current?.focus()})}))},[e,l]);const x=m.useMemo(()=>{const O={maxResults:o,categories:i||[]};if(!d.trim()){const N=Br("",O);return a&&y.length>0&&(N[U.RECENT]=y),N}return Br(d,O)},[d,i,o,a,y]),w=m.useMemo(()=>{const O=[];return[U.RECENT,...Pt.filter(F=>F!==U.RECENT)].forEach(F=>{x[F]?.length&&x[F].forEach(Z=>{O.push({...Z,_category:F})})}),O},[x]);m.useEffect(()=>{f>=w.length&&g(Math.max(0,w.length-1))},[w.length,f]),m.useEffect(()=>{I.current&&b.current&&I.current.scrollIntoView({block:"nearest",behavior:"smooth"})},[f]);const _=m.useCallback(O=>{if(!O)return;const N=YT(O);v(N),O.action&&typeof O.action=="function"?O.action(O.data):O.path&&u(O.path),n?.(O),t?.()},[u,n,t]),A=m.useCallback(()=>{KT(),v([])},[]),k=m.useCallback(O=>{switch(O.key){case"ArrowDown":O.preventDefault(),g(N=>N<w.length-1?N+1:0);break;case"ArrowUp":O.preventDefault(),g(N=>N>0?N-1:w.length-1);break;case"Enter":O.preventDefault(),w[f]&&_(w[f]);break;case"Escape":O.preventDefault(),t?.();break;case"Tab":O.preventDefault();break;default:O.key.length===1&&!O.metaKey&&!O.ctrlKey&&g(0);break}},[w,f,_,t]),R=m.useCallback(()=>{if(w.length===0)return c.jsx(NT,{query:d});const O=[],N=[U.RECENT,...Pt.filter(Z=>Z!==U.RECENT)];let F=0;return N.forEach(Z=>{const z=x[Z];if(!z?.length)return;const H=F;O.push(c.jsxs("div",{children:[c.jsx(OT,{category:Z,count:z.length,onClear:Z===U.RECENT?A:void 0}),c.jsx("div",{className:"space-y-1 px-2",children:z.map((Q,_e)=>{const W=H+_e===f;return c.jsx($T,{ref:W?I:null,item:Q,index:_e,isSelected:W,onClick:_,highlights:Q.highlights},Q.id)})})]},Z)),F+=z.length}),O},[w,x,f,d,_,A]),P=m.useMemo(()=>typeof navigator<"u"&&/Mac|iPhone|iPad|iPod/.test(navigator.platform),[]);return e?Td.createPortal(c.jsx(Ct,{mode:"wait",children:e&&c.jsxs("div",{className:"fixed inset-0 z-[9999]",children:[c.jsx(B.div,{variants:QT,initial:"hidden",animate:"visible",exit:"exit",onClick:t,className:"absolute inset-0 bg-black/70 backdrop-blur-md"},"backdrop"),c.jsx("div",{className:"absolute inset-0 overflow-y-auto p-4 sm:p-6 md:p-8",children:c.jsxs(B.div,{variants:JT,initial:"hidden",animate:"visible",exit:"exit",className:`
                relative w-full max-w-2xl mx-auto mt-[10vh]
                rounded-2xl overflow-hidden
                border border-white/10
              `,style:{background:"rgba(20, 20, 25, 0.85)",backdropFilter:"blur(40px)",WebkitBackdropFilter:"blur(40px)",boxShadow:`
                  0 0 0 1px rgba(255, 255, 255, 0.05),
                  0 25px 50px -12px rgba(0, 0, 0, 0.5),
                  0 0 100px rgba(0, 102, 255, 0.1)
                `},role:"dialog","aria-modal":"true","aria-label":"Command palette",children:[c.jsxs("div",{className:"flex items-center gap-3 px-5 py-4 border-b border-white/10",children:[c.jsx(Oi,{size:22,className:"text-white/40 flex-shrink-0",strokeWidth:1.5}),c.jsx("input",{ref:T,type:"text",value:d,onChange:O=>h(O.target.value),onKeyDown:k,placeholder:s,className:`
                    flex-1 bg-transparent
                    text-white text-lg
                    placeholder:text-white/30
                    outline-none
                  `,autoComplete:"off",autoCorrect:"off",autoCapitalize:"off",spellCheck:"false"}),d&&c.jsx("button",{onClick:()=>h(""),className:`
                      p-1.5 rounded-lg
                      text-white/40 hover:text-white/70
                      hover:bg-white/10
                      transition-colors
                    `,"aria-label":"Clear search",children:c.jsx(Di,{size:18,strokeWidth:1.5})}),c.jsx("button",{onClick:t,className:`
                    px-2 py-1 rounded-md
                    text-xs font-medium text-white/40
                    bg-white/5 border border-white/10
                    hover:bg-white/10 hover:text-white/60
                    transition-colors
                  `,children:"ESC"})]}),c.jsx("div",{ref:b,className:`
                  max-h-[60vh] overflow-y-auto py-2
                  scrollbar-thin scrollbar-track-transparent
                  scrollbar-thumb-white/10 hover:scrollbar-thumb-white/20
                `,role:"listbox","aria-label":"Search results",children:R()}),c.jsxs("div",{className:`
                  flex items-center justify-between
                  px-5 py-3
                  border-t border-white/10
                  bg-white/[0.02]
                `,children:[c.jsxs("div",{className:"flex items-center gap-4 text-xs text-white/30",children:[c.jsxs("span",{className:"flex items-center gap-1.5",children:[c.jsx("kbd",{className:"px-1.5 py-0.5 rounded bg-white/10 border border-white/10",children:c.jsx(Zv,{size:12})}),c.jsx("kbd",{className:"px-1.5 py-0.5 rounded bg-white/10 border border-white/10",children:c.jsx(Qv,{size:12})}),c.jsx("span",{className:"ml-1",children:"Navigate"})]}),c.jsxs("span",{className:"flex items-center gap-1.5",children:[c.jsx("kbd",{className:"px-1.5 py-0.5 rounded bg-white/10 border border-white/10",children:c.jsx(wS,{size:12})}),c.jsx("span",{className:"ml-1",children:"Select"})]})]}),c.jsxs("div",{className:"flex items-center gap-3 text-xs text-white/30",children:[c.jsxs("span",{children:[w.length," results"]}),c.jsxs("span",{className:"flex items-center gap-1",children:[c.jsx("kbd",{className:"px-1.5 py-0.5 rounded bg-white/10 border border-white/10",children:P?c.jsx(SS,{size:10}):"Ctrl"}),c.jsx("span",{children:"+"}),c.jsx("kbd",{className:"px-1.5 py-0.5 rounded bg-white/10 border border-white/10",children:"K"})]})]})]})]},"palette")})]})}),document.body):null}const ZT=m.memo(XT),eb=Object.freeze({__proto__:null,default:ZT,registerCommand:qu}),zu=m.createContext(null);function tb(){const e=m.useContext(zu);if(!e)throw new Error("useCommandPaletteContext must be used within CommandPaletteProvider");return e}function nb(e={}){const{enableGlobalShortcut:t=!0,onOpen:n,onClose:s,onSelect:i,maxResults:a=10,categories:o=[]}=e,[l,u]=m.useState(!1),[d,h]=m.useState(""),[f,g]=m.useState(0),y=m.useRef(0),v=m.useMemo(()=>VT(d,{maxResults:a,categories:o}),[d,a,o]);m.useEffect(()=>{f>=v.length&&g(Math.max(0,v.length-1))},[v.length,f]),m.useEffect(()=>{l?g(0):h("")},[l]);const T=m.useCallback((k="")=>{h(k),u(!0),g(0),y.current=Date.now(),n?.()},[n]),b=m.useCallback(()=>{u(!1),h(""),g(0),s?.()},[s]),I=m.useCallback(()=>{l?b():T()},[l,T,b]),x=m.useCallback(()=>{g(k=>k<v.length-1?k+1:0)},[v.length]),w=m.useCallback(()=>{g(k=>k>0?k-1:v.length-1)},[v.length]),_=m.useCallback(()=>{const k=v[f];k&&(k.action&&typeof k.action=="function"&&k.action(k.data),i?.(k),b())},[v,f,i,b]),A=m.useCallback(k=>{k&&(k.action&&typeof k.action=="function"&&k.action(k.data),i?.(k),b())},[i,b]);return m.useEffect(()=>()=>{},[T,b,I]),m.useEffect(()=>{if(!t)return;const k=R=>{if((R.metaKey||R.ctrlKey)&&R.key==="k"){if(R.preventDefault(),R.stopPropagation(),Date.now()-y.current<100)return;I()}R.key==="Escape"&&l&&(R.preventDefault(),b())};return document.addEventListener("keydown",k,{capture:!0}),()=>{document.removeEventListener("keydown",k,{capture:!0})}},[t,l,I,b]),{isOpen:l,search:d,results:v,selectedIndex:f,open:T,close:b,toggle:I,setSearch:h,selectNext:x,selectPrev:w,executeSelected:_,handleSelect:A,initialQuery:d,setInitialQuery:h}}function sb({children:e,...t}){const n=nb(t);return c.jsx(zu.Provider,{value:n,children:e})}const rb={"/":()=>E(()=>import("./Landing-j4pzoegb.js"),__vite__mapDeps([10,1,11,12,3,5,6])),"/login":()=>E(()=>import("./Login-j0zyug61.js"),__vite__mapDeps([13,1,14,11,15,16,17,5,6])),"/signup":()=>E(()=>import("./Signup-p1pfugla.js"),__vite__mapDeps([18,1,11,15,16,17,14,5,6])),"/dashboard":()=>E(()=>import("./Dashboard-mmc1ijmj.js"),__vite__mapDeps([19,1,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,15,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,5,6])),"/onboarding":()=>E(()=>import("./Onboarding-gradixe6.js"),__vite__mapDeps([58,1,59,37,2,33,15,60,5,6])),"/workout":()=>E(()=>import("./Workout-ki77an0n.js"),__vite__mapDeps([61,1,20,62,63,64,23,24,65,4,66,67,60,68,69,32,30,35,21,33,70,39,71,22,72,73,74,75,76,77,78,79,80,45,46,5,6])),"/journey":()=>E(()=>import("./Journey-lit2kfd6.js"),__vite__mapDeps([81,1,59,37,2,33,44,47,48,63,82,5,6])),"/profile":()=>E(()=>import("./Profile-enzivbk0.js"),__vite__mapDeps([83,1,16,17,44,47,48,84,63,5,6])),"/settings":()=>E(()=>import("./Settings-hgxsxzru.js"),__vite__mapDeps([85,1,23,24,66,39,79,71,68,69,35,73,86,33,72,87,22,25,36,51,5,6])),"/progression":()=>E(()=>import("./Progression-bqwvjqk2.js"),__vite__mapDeps([88,1,5,6])),"/exercises":()=>E(()=>import("./Exercises-d6ldu9ra.js"),__vite__mapDeps([89,1,62,63,64,90,52,33,5,6])),"/stats":()=>E(()=>import("./Stats-hgrx3zhq.js"),__vite__mapDeps([91,1,25,36,51,23,24,49,84,63,82,50,5,6])),"/community":()=>E(()=>import("./CommunityDashboard-lpcew5l7.js"),__vite__mapDeps([92,1,90,93,94,5,6])),"/competitions":()=>E(()=>import("./Competitions-dczglajf.js"),__vite__mapDeps([95,1,5,6])),"/locations":()=>E(()=>import("./Locations-gfz0zi4p.js"),__vite__mapDeps([96,1,5,6])),"/highfives":()=>E(()=>import("./HighFives-259zdss5.js"),__vite__mapDeps([97,1,5,6])),"/messages":()=>E(()=>import("./Messages-n5pis5xh.js"),__vite__mapDeps([98,1,16,17,23,54,55,94,5,6])),"/crews":()=>E(()=>import("./Crews-mpso8dk2.js"),__vite__mapDeps([99,1,25,36,51,23,24,5,6])),"/rivals":()=>E(()=>import("./Rivals-m7irxk6w.js"),__vite__mapDeps([100,1,25,36,51,23,24,5,6])),"/credits":()=>E(()=>import("./Credits-e7vpmz38.js"),__vite__mapDeps([101,1,5,6])),"/wallet":()=>E(()=>import("./Wallet-jkqnm7ii.js"),__vite__mapDeps([102,1,25,36,51,5,6])),"/skins":()=>E(()=>import("./SkinsStore-gqcjici5.js"),__vite__mapDeps([103,1,5,6])),"/wellness":()=>E(()=>import("./Health-fd6rpwbz.js"),__vite__mapDeps([104,1,23,24,5,6])),"/goals":()=>E(()=>import("./Goals-dz86d6ug.js"),__vite__mapDeps([105,1,16,17,23,24,54,55,63,5,6])),"/limitations":()=>E(()=>import("./Limitations-oi6bavlw.js"),__vite__mapDeps([106,1,25,36,51,23,24,54,55,5,6])),"/pt-tests":()=>E(()=>import("./PTTests-papi75q2.js"),__vite__mapDeps([107,1,25,36,51,23,24,54,55,5,6])),"/design-system":()=>E(()=>import("./DesignSystem-eqh94s47.js"),__vite__mapDeps([108,1,23,24,53,54,55,56,5,6])),"/features":()=>E(()=>import("./Features-dqmznmq6.js"),__vite__mapDeps([109,1,23,24,55,56,11,5,6])),"/technology":()=>E(()=>import("./Technology-esd2c5dh.js"),__vite__mapDeps([110,1,23,24,55,111,112,5,6])),"/science":()=>E(()=>import("./Science-khtwvj9z.js"),__vite__mapDeps([113,1,23,24,55,5,6])),"/design":()=>E(()=>import("./Design-esylxu93.js"),__vite__mapDeps([114,1,23,24,54,55,56,5,6])),"/docs":()=>E(()=>import("./Docs-liufbhwg.js"),__vite__mapDeps([115,1,111,116,11,5,6])),"/privacy":()=>E(()=>import("./Privacy-ee491jka.js"),__vite__mapDeps([117,1,5])),"/skills":()=>E(()=>import("./Skills-j40bmmdu.js"),__vite__mapDeps([118,1,5,6])),"/martial-arts":()=>E(()=>import("./MartialArts-ohefcpc5.js"),__vite__mapDeps([119,1,5,6])),"/issues":()=>E(()=>import("./Issues-cjxi9nyt.js"),__vite__mapDeps([120,1,94,5,6])),"/issues/new":()=>E(()=>import("./NewIssue-ntmimfin.js"),__vite__mapDeps([121,1,16,17,5,6])),"/my-issues":()=>E(()=>import("./MyIssues-hesxyfmz.js"),__vite__mapDeps([122,1,94,5,6])),"/updates":()=>E(()=>import("./DevUpdates-et6drnm9.js"),__vite__mapDeps([123,1,94,5,6])),"/roadmap":()=>E(()=>import("./Roadmap-dmgdgdsi.js"),__vite__mapDeps([124,1,111,125,11,94,5,6])),"/admin-control":()=>E(()=>import("./AdminControl-1hblt4l3.js"),__vite__mapDeps([126,1,94,5,6])),"/admin/issues":()=>E(()=>import("./AdminIssues-fzl6pcm9.js"),__vite__mapDeps([127,1,94,5,6])),"/admin/monitoring":()=>E(()=>import("./AdminMonitoring-fsh23maf.js"),__vite__mapDeps([128,1,23,87,129,33,31,130,39,22,5,6]))},Ho=new Set;function Ui(e){const t=e.split("/").slice(0,3).join("/"),n=t===""?"/":t.replace(/\/$/,"");if(Ho.has(n))return;const s=rb[n];s&&(Ho.add(n),"requestIdleCallback"in window?requestIdleCallback(()=>s()):setTimeout(()=>s(),100))}function ib(e){$e.useEffect(()=>{const t=()=>{e.forEach(n=>Ui(n))};"requestIdleCallback"in window?requestIdleCallback(t):setTimeout(t,1e3)},[e])}const Vi="G-S4RPD5JD5L",Bi=()=>typeof window<"u"&&typeof window.gtag=="function";function Hu(e,t={}){if(Bi())try{window.gtag("event",e,{...t,send_to:Vi})}catch{}}function ab(e,t){if(Bi())try{window.gtag("event","page_view",{page_path:e,page_title:t||document.title,page_location:window.location.href,send_to:Vi})}catch{}}function tk(e,t={}){if(Bi())try{window.gtag("config",Vi,{user_id:e}),window.gtag("set","user_properties",{user_id:e,...t})}catch{}}function nk(e="email"){Hu("sign_up",{method:e})}function sk(e="email"){Hu("login",{method:e})}const rs={"dashboard.main":{description:"Main dashboard area",multiple:!0},"dashboard.sidebar":{description:"Dashboard sidebar",multiple:!0},"dashboard.header":{description:"Dashboard header area",multiple:!1},"dashboard.stats":{description:"Stats section",multiple:!0},"profile.tabs":{description:"Profile tab panels",multiple:!0},"profile.header":{description:"Profile header area",multiple:!1},"profile.sidebar":{description:"Profile sidebar",multiple:!0},"workout.summary":{description:"Workout summary section",multiple:!0},"workout.actions":{description:"Workout action buttons",multiple:!0},"workout.details":{description:"Workout detail panels",multiple:!0},"exercise.card":{description:"Exercise card extras",multiple:!0},"exercise.detail":{description:"Exercise detail panels",multiple:!0},"muscle.detail":{description:"Muscle detail panels",multiple:!0},"muscle.overlay":{description:"Muscle map overlays",multiple:!0},"sidebar.top":{description:"Top of sidebar nav",multiple:!0},"sidebar.bottom":{description:"Bottom of sidebar nav",multiple:!0},"settings.tabs":{description:"Settings tab panels",multiple:!0},"admin.dashboard":{description:"Admin dashboard widgets",multiple:!0}},ob=["app:ready","user:login","user:logout","route:changed","theme:changed","workout:started","workout:completed","workout:paused","exercise:started","exercise:completed","set:logged","achievement:unlocked","level:up","credits:changed"],Go={plugins:new Map,routes:[],widgets:Object.keys(rs).reduce((e,t)=>(e[t]=[],e),{}),navItems:[],commands:[],themes:[],activeThemeId:null,isLoading:!1,loadingPlugins:new Set,errors:[]},Ue=ht(wn((e,t)=>({...Go,registerPlugin:n=>{const{plugins:s}=t();return s.has(n.id)?!1:(e(i=>({plugins:new Map(i.plugins).set(n.id,{...n,enabled:!0,loadedAt:Date.now()})})),!0)},unregisterPlugin:n=>{const{plugins:s}=t();return s.has(n)?(e(i=>{const a=new Map(i.plugins);a.delete(n);const o={...i.widgets};return Object.keys(o).forEach(l=>{o[l]=o[l].filter(u=>u.pluginId!==n)}),{plugins:a,routes:i.routes.filter(l=>l.pluginId!==n),widgets:o,navItems:i.navItems.filter(l=>l.pluginId!==n),commands:i.commands.filter(l=>l.pluginId!==n),themes:i.themes.filter(l=>l.pluginId!==n)}}),!0):!1},setPluginEnabled:(n,s)=>{e(i=>{const a=new Map(i.plugins),o=a.get(n);return o&&a.set(n,{...o,enabled:s}),{plugins:a}})},getPlugin:n=>t().plugins.get(n),getEnabledPlugins:()=>{const{plugins:n}=t();return Array.from(n.values()).filter(s=>s.enabled)},registerRoute:(n,s)=>{e(i=>({routes:[...i.routes,{...s,pluginId:n,id:`${n}:${s.path}`}]}))},getRoutes:()=>{const{routes:n,plugins:s}=t();return n.filter(i=>s.get(i.pluginId)?.enabled)},registerWidget:(n,s,i)=>{if(!rs[s])return!1;const a=rs[s];return e(o=>{const l=o.widgets[s]||[];return!a.multiple&&l.length>0?o:{widgets:{...o.widgets,[s]:[...l,{...i,pluginId:n,id:`${n}:${i.id||s}`}]}}}),!0},getWidgetsForSlot:n=>{const{widgets:s,plugins:i}=t();return(s[n]||[]).filter(o=>i.get(o.pluginId)?.enabled)},registerNavItem:(n,s)=>{e(i=>({navItems:[...i.navItems,{...s,pluginId:n,id:`${n}:${s.path}`}].sort((a,o)=>(a.order||100)-(o.order||100))}))},getNavItems:(n=null)=>{const{navItems:s,plugins:i}=t();return s.filter(a=>!(!i.get(a.pluginId)?.enabled||n&&a.section!==n)).sort((a,o)=>(a.order||100)-(o.order||100))},registerCommand:(n,s)=>{e(i=>({commands:[...i.commands,{...s,pluginId:n,id:s.id||`${n}:${s.title}`}]}))},getCommands:()=>{const{commands:n,plugins:s}=t();return n.filter(i=>s.get(i.pluginId)?.enabled)},executeCommand:async(n,...s)=>{const{commands:i}=t(),a=i.find(o=>o.id===n);if(a&&typeof a.handler=="function")return await a.handler(...s)},registerTheme:(n,s)=>{e(i=>({themes:[...i.themes,{...s,pluginId:n,id:s.id||`${n}:theme`}]}))},setActiveTheme:n=>{e({activeThemeId:n})},getActiveTheme:()=>{const{themes:n,activeThemeId:s}=t();return s&&n.find(i=>i.id===s)||null},getThemes:()=>{const{themes:n,plugins:s}=t();return n.filter(i=>s.get(i.pluginId)?.enabled)},setPluginLoading:(n,s)=>{e(i=>{const a=new Set(i.loadingPlugins);return s?a.add(n):a.delete(n),{loadingPlugins:a,isLoading:a.size>0}})},addError:n=>{e(s=>({errors:[...s.errors,{...n,id:`error-${Date.now()}`,timestamp:Date.now()}]}))},clearErrors:(n=null)=>{e(s=>({errors:n?s.errors.filter(i=>i.pluginId!==n):[]}))},reset:()=>{e(Go)}}))),rk=()=>Ue(e=>Array.from(e.plugins.values())),cb=()=>Ue(e=>e.getRoutes()),lb=e=>Ue(t=>t.getWidgetsForSlot(e)),ub=()=>Ue(e=>e.getThemes()),db=()=>Ue(e=>e.getActiveTheme());class mb{constructor(){this.listeners=new Map,this.history=[],this.maxHistorySize=100,this.wildcardListeners=new Set}on(t,n,s={}){const{pluginId:i="core",once:a=!1}=s;if(t==="*"){const l={handler:n,pluginId:i,once:a};return this.wildcardListeners.add(l),()=>this.wildcardListeners.delete(l)}this.listeners.has(t)||this.listeners.set(t,new Set);const o={handler:n,pluginId:i,once:a};return this.listeners.get(t).add(o),()=>{const l=this.listeners.get(t);l&&(l.delete(o),l.size===0&&this.listeners.delete(t))}}once(t,n,s={}){return this.on(t,n,{...s,once:!0})}off(t,n){const s=this.listeners.get(t);if(s){for(const i of s)if(i.handler===n){s.delete(i);break}s.size===0&&this.listeners.delete(t)}}offPlugin(t){for(const[n,s]of this.listeners){for(const i of s)i.pluginId===t&&s.delete(i);s.size===0&&this.listeners.delete(n)}for(const n of this.wildcardListeners)n.pluginId===t&&this.wildcardListeners.delete(n)}emit(t,n={},s={}){const{pluginId:i="core"}=s,a=Date.now(),o={type:t,payload:n,meta:{pluginId:i,timestamp:a,...s}};this._addToHistory(o);const l=this.listeners.get(t)||new Set,u=this._getPatternListeners(t),d=[...l,...u,...this.wildcardListeners],h=[];for(const f of d)try{f.handler(o),f.once&&h.push({event:t,listener:f})}catch{}for(const{event:f,listener:g}of h)if(f==="*")this.wildcardListeners.delete(g);else{const y=this.listeners.get(f);y&&y.delete(g)}return o}async emitAsync(t,n={},s={}){const{pluginId:i="core"}=s,a=Date.now(),o={type:t,payload:n,meta:{pluginId:i,timestamp:a,...s}};this._addToHistory(o);const l=this.listeners.get(t)||new Set,u=this._getPatternListeners(t),d=[...l,...u,...this.wildcardListeners],h=[],f=[];for(const g of d)try{const y=await g.handler(o);f.push(y),g.once&&h.push({event:t,listener:g})}catch(y){f.push({error:y})}for(const{event:g,listener:y}of h)if(g==="*")this.wildcardListeners.delete(y);else{const v=this.listeners.get(g);v&&v.delete(y)}return f}_getPatternListeners(t){const n=[];for(const[s,i]of this.listeners)if(s.endsWith(":*")){const a=s.slice(0,-1);t.startsWith(a)&&n.push(...i)}return n}_addToHistory(t){this.history.push(t),this.history.length>this.maxHistorySize&&this.history.shift()}getHistory(t={}){let n=[...this.history];return t.event&&(n=n.filter(s=>s.type===t.event)),t.pluginId&&(n=n.filter(s=>s.meta.pluginId===t.pluginId)),t.since&&(n=n.filter(s=>s.meta.timestamp>=t.since)),n}clearHistory(){this.history=[]}getRegisteredEvents(){return Array.from(this.listeners.keys())}getListenerCount(t){const n=this.listeners.get(t);return n?n.size:0}hasListeners(t){return this.getListenerCount(t)>0||this.wildcardListeners.size>0}debug(){for(const[t,n]of this.listeners);}}const ae=new mb;ob.forEach(e=>{ae.listeners.has(e)||ae.listeners.set(e,new Set)});class hb{constructor(){this.filters=new Map,this.actions=new Map}addFilter(t,n,s={}){const{pluginId:i="core",priority:a=10}=s;this.filters.has(t)||this.filters.set(t,[]);const o={handler:n,pluginId:i,priority:a},l=this.filters.get(t);return l.push(o),l.sort((u,d)=>u.priority-d.priority),()=>this.removeFilter(t,n)}removeFilter(t,n){const s=this.filters.get(t);if(!s)return;const i=s.findIndex(a=>a.handler===n);i!==-1&&s.splice(i,1)}applyFilters(t,n,...s){const i=this.filters.get(t);if(!i||i.length===0)return n;let a=n;for(const o of i)try{a=o.handler(a,...s)}catch{}return a}async applyFiltersAsync(t,n,...s){const i=this.filters.get(t);if(!i||i.length===0)return n;let a=n;for(const o of i)try{a=await o.handler(a,...s)}catch{}return a}addAction(t,n,s={}){const{pluginId:i="core",priority:a=10}=s;this.actions.has(t)||this.actions.set(t,[]);const o={handler:n,pluginId:i,priority:a},l=this.actions.get(t);return l.push(o),l.sort((u,d)=>u.priority-d.priority),()=>this.removeAction(t,n)}removeAction(t,n){const s=this.actions.get(t);if(!s)return;const i=s.findIndex(a=>a.handler===n);i!==-1&&s.splice(i,1)}getActions(t,n={}){const s=this.actions.get(t);if(!s||s.length===0)return[];const i=[];for(const a of s)try{const o=a.handler(n);Array.isArray(o)?i.push(...o.map(l=>({...l,pluginId:a.pluginId}))):o&&i.push({...o,pluginId:a.pluginId})}catch{}return i}doAction(t,...n){const s=this.actions.get(t);if(s)for(const i of s)try{i.handler(...n)}catch{}}async doActionAsync(t,...n){const s=this.actions.get(t);if(s)for(const i of s)try{await i.handler(...n)}catch{}}removePluginHooks(t){for(const[n,s]of this.filters)this.filters.set(n,s.filter(i=>i.pluginId!==t));for(const[n,s]of this.actions)this.actions.set(n,s.filter(i=>i.pluginId!==t))}hasFilter(t){const n=this.filters.get(t);return n&&n.length>0}hasAction(t){const n=this.actions.get(t);return n&&n.length>0}getRegisteredHooks(){return{filters:Array.from(this.filters.keys()),actions:Array.from(this.actions.keys())}}debug(){for(const[t,n]of this.filters);for(const[t,n]of this.actions);}}const le=new hb,pb=["id","name","version"],fb=["routes","widgets","themes","commands","settings","graphql","hooks"];function gb(e){const t=[];for(const n of pb)e[n]||t.push(`Missing required field: ${n}`);if(e.id&&!/^[a-z0-9-]+$/.test(e.id)&&t.push("Plugin ID must be lowercase alphanumeric with hyphens only"),e.version&&!/^\d+\.\d+\.\d+/.test(e.version)&&t.push("Version must be in semver format (e.g., 1.0.0)"),e.capabilities)for(const n of e.capabilities)fb.includes(n)||t.push(`Unknown capability: ${n}`);return e.entry&&(e.entry.frontend&&typeof e.entry.frontend!="string"&&t.push("entry.frontend must be a string path"),e.entry.backend&&typeof e.entry.backend!="string"&&t.push("entry.backend must be a string path")),{valid:t.length===0,errors:t}}function yb(e,t={}){const n=e.id;return{pluginId:n,manifest:e,config:e.config||{},api:t.api||null,graphql:t.graphql||null,navigate:t.navigate||(()=>{}),notify:{success:s=>t.toast?.success?.(s),error:s=>t.toast?.error?.(s),info:s=>t.toast?.info?.(s),warning:s=>t.toast?.warning?.(s)},on:(s,i)=>ae.on(s,i,{pluginId:n}),once:(s,i)=>ae.once(s,i,{pluginId:n}),emit:(s,i)=>ae.emit(s,i,{pluginId:n}),off:(s,i)=>ae.off(s,i),addFilter:(s,i,a={})=>le.addFilter(s,i,{...a,pluginId:n}),addAction:(s,i,a={})=>le.addAction(s,i,{...a,pluginId:n}),applyFilters:le.applyFilters.bind(le),getActions:le.getActions.bind(le),storage:{get:s=>{try{const i=localStorage.getItem(`plugin:${n}:${s}`);return i?JSON.parse(i):null}catch{return null}},set:(s,i)=>{try{localStorage.setItem(`plugin:${n}:${s}`,JSON.stringify(i))}catch{}},remove:s=>{localStorage.removeItem(`plugin:${n}:${s}`)},clear:()=>{const s=`plugin:${n}:`;for(let i=localStorage.length-1;i>=0;i--){const a=localStorage.key(i);a?.startsWith(s)&&localStorage.removeItem(a)}}},log:{debug:(...s)=>{},info:(...s)=>{},warn:(...s)=>{},error:(...s)=>{}}}}async function Gu(e,t,n={}){const s=Ue.getState(),i=gb(e);if(!i.valid)return s.addError({pluginId:e.id||"unknown",type:"validation",message:`Invalid manifest: ${i.errors.join(", ")}`}),{success:!1,errors:i.errors};const a=e.id;if(s.plugins.has(a))return{success:!1,errors:["Plugin already loaded"]};s.setPluginLoading(a,!0);try{const o=yb(e,n);let l=t;return typeof t=="function"&&(l=await t(o)),s.registerPlugin({id:a,name:e.name,version:e.version,description:e.description,author:e.author,manifest:e,entry:l,context:o}),e.contributes&&await vb(a,e.contributes,l),l?.onLoad&&await l.onLoad(o),ae.emit("plugin:loaded",{pluginId:a,manifest:e}),s.setPluginLoading(a,!1),{success:!0,pluginId:a}}catch(o){return s.setPluginLoading(a,!1),s.addError({pluginId:a,type:"load",message:o.message,stack:o.stack}),{success:!1,errors:[o.message]}}}async function vb(e,t,n){const s=Ue.getState();if(t.routes)for(const i of t.routes){let a=i.component;typeof a=="string"&&n?.routes?.[a]&&(a=n.routes[a]),s.registerRoute(e,{path:i.path,title:i.title,icon:i.icon,component:a,protected:i.protected!==!1,admin:i.admin||!1})}if(t.widgets)for(const i of t.widgets){let a=i.component;typeof a=="string"&&n?.widgets?.[a]&&(a=n.widgets[a]),s.registerWidget(e,i.slot,{id:i.id||i.component,component:a,props:i.defaultProps||{},order:i.order||100})}if(t.navItems)for(const i of t.navItems)s.registerNavItem(e,{label:i.label,path:i.path,icon:i.icon,section:i.section||"main",order:i.order||100,badge:i.badge});if(t.commands)for(const i of t.commands){let a=i.handler;typeof a=="string"&&n?.commands?.[a]&&(a=n.commands[a]),s.registerCommand(e,{id:i.id,title:i.title,description:i.description,icon:i.icon,keybinding:i.keybinding,handler:a})}if(t.themes||n?.themes){const i=t.themes||n.themes||[];for(const a of i)s.registerTheme(e,{id:a.id,name:a.name,colors:a.colors,fonts:a.fonts,preview:a.preview})}}async function Yo(e){const t=Ue.getState(),n=t.plugins.get(e);if(!n)return{success:!1,errors:["Plugin not found"]};try{return n.entry?.onUnload&&await n.entry.onUnload(),ae.offPlugin(e),le.removePluginHooks(e),t.unregisterPlugin(e),ae.emit("plugin:unloaded",{pluginId:e}),{success:!0}}catch(s){return{success:!1,errors:[s.message]}}}async function Sb(e,t){const n=[];for(const s of e){const i=await Gu(s.manifest,s.entry,t);n.push({pluginId:s.manifest.id,...i})}return ae.emit("plugins:ready",{count:n.length}),n}function Tb({className:e=""}){return c.jsxs("div",{className:`animate-pulse rounded-xl bg-white/5 border border-white/10 p-4 ${e}`,children:[c.jsx("div",{className:"h-4 bg-white/10 rounded w-1/3 mb-3"}),c.jsx("div",{className:"h-20 bg-white/10 rounded"})]})}class bb extends $e.Component{constructor(t){super(t),this.state={hasError:!1,error:null}}static getDerivedStateFromError(t){return{hasError:!0,error:t}}componentDidCatch(t,n){}render(){return this.state.hasError?this.props.fallback?this.props.fallback:c.jsxs("div",{className:"rounded-xl bg-red-500/10 border border-red-500/20 p-4 text-red-400 text-sm",children:[c.jsx("p",{className:"font-medium",children:"Widget Error"}),c.jsxs("p",{className:"text-red-400/70 text-xs mt-1",children:["Plugin: ",this.props.pluginId]})]}):this.props.children}}function wb({widget:e,slot:t,context:n,skeleton:s,animate:i,className:a}){const{component:o,props:l,pluginId:u,id:d}=e,h=m.useMemo(()=>({...l,...n,pluginId:u,widgetId:d}),[l,n,u,d]),f=c.jsx(bb,{slot:t,pluginId:u,children:c.jsx(m.Suspense,{fallback:s||c.jsx(Tb,{}),children:typeof o=="function"?c.jsx(o,{...h}):o})});return i?c.jsx(B.div,{initial:{opacity:0,y:10},animate:{opacity:1,y:0},exit:{opacity:0,y:-10},transition:{duration:.2},className:a,children:f},d):c.jsx("div",{className:a,children:f},d)}function ik({name:e,context:t={},skeleton:n,fallback:s,className:i="",widgetClassName:a="",layout:o="vertical",gap:l=4,animate:u=!0,maxWidgets:d,emptyMessage:h}){const f=lb(e);if(!rs[e])return null;const g=d?f.slice(0,d):f;if(g.length===0)return s||(h?c.jsx("div",{className:`text-white/40 text-sm ${i}`,children:h}):null);const y={vertical:`flex flex-col gap-${l}`,horizontal:`flex flex-row gap-${l} overflow-x-auto`,grid:`grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-${l}`},v=`${y[o]||y.vertical} ${i}`;return c.jsx("div",{className:v,"data-widget-slot":e,children:c.jsx(Ct,{mode:"popLayout",children:g.map(T=>c.jsx(wb,{widget:T,slot:e,context:t,skeleton:n,animate:u,className:a},T.id))})})}const Fr=ht(wn((e,t)=>({sidebarOpen:!1,sidebarCollapsed:!1,mobileMenuOpen:!1,toggleSidebar:()=>e(n=>({sidebarOpen:!n.sidebarOpen})),setSidebarOpen:n=>e({sidebarOpen:n}),toggleSidebarCollapsed:()=>e(n=>({sidebarCollapsed:!n.sidebarCollapsed})),setMobileMenuOpen:n=>e({mobileMenuOpen:n}),activeModal:null,modalData:null,openModal:(n,s=null)=>e({activeModal:n,modalData:s}),closeModal:()=>e({activeModal:null,modalData:null}),confirmDialog:null,showConfirmDialog:({title:n,message:s,onConfirm:i,onCancel:a,confirmText:o="Confirm",cancelText:l="Cancel",variant:u="default"})=>e({confirmDialog:{title:n,message:s,onConfirm:i,onCancel:a,confirmText:o,cancelText:l,variant:u}}),hideConfirmDialog:()=>e({confirmDialog:null}),globalLoading:!1,loadingMessage:"",navigationLoading:!1,setGlobalLoading:(n,s="")=>e({globalLoading:n,loadingMessage:s}),setNavigationLoading:n=>e({navigationLoading:n}),pendingOperations:new Set,addPendingOperation:n=>e(s=>{const i=new Set(s.pendingOperations);return i.add(n),{pendingOperations:i}}),removePendingOperation:n=>e(s=>{const i=new Set(s.pendingOperations);return i.delete(n),{pendingOperations:i}}),isPending:n=>t().pendingOperations.has(n),toasts:[],addToast:n=>{const s=Date.now().toString(36)+Math.random().toString(36).slice(2),i={id:s,...n,createdAt:Date.now()};return e(a=>({toasts:[...a.toasts,i]})),n.duration!==0&&setTimeout(()=>{t().removeToast(s)},n.duration||5e3),s},removeToast:n=>e(s=>({toasts:s.toasts.filter(i=>i.id!==n)})),clearToasts:()=>e({toasts:[]}),selectedItems:[],selectionMode:!1,setSelectionMode:n=>e({selectionMode:n,selectedItems:n?[]:[]}),toggleItemSelection:n=>e(s=>({selectedItems:s.selectedItems.includes(n)?s.selectedItems.filter(i=>i!==n):[...s.selectedItems,n]})),selectAll:n=>e({selectedItems:n}),clearSelection:()=>e({selectedItems:[],selectionMode:!1}),scrollPositions:{},setScrollPosition:(n,s)=>e(i=>({scrollPositions:{...i.scrollPositions,[n]:s}})),getScrollPosition:n=>t().scrollPositions[n]||0,isMobile:typeof window<"u"?window.innerWidth<768:!1,isTablet:typeof window<"u"?window.innerWidth>=768&&window.innerWidth<1024:!1,isDesktop:typeof window<"u"?window.innerWidth>=1024:!0,updateBreakpoints:()=>{if(typeof window>"u")return;const n=window.innerWidth;e({isMobile:n<768,isTablet:n>=768&&n<1024,isDesktop:n>=1024})}})));let st=null,qt=null;function Ib(){return typeof window>"u"?()=>{}:(st&&window.removeEventListener("resize",st),st=()=>{qt&&clearTimeout(qt),qt=setTimeout(()=>{Fr.getState().updateBreakpoints()},100)},window.addEventListener("resize",st),()=>{qt&&clearTimeout(qt),st&&(window.removeEventListener("resize",st),st=null)})}typeof window<"u"&&Ib();const xb=()=>{const e=Fr(n=>n.addToast),t=Fr(n=>n.removeToast);return{toast:(n,s={})=>e({message:n,type:"default",...s}),success:(n,s={})=>e({message:n,type:"success",...s}),error:(n,s={})=>e({message:n,type:"error",...s}),warning:(n,s={})=>e({message:n,type:"warning",...s}),info:(n,s={})=>e({message:n,type:"info",...s}),dismiss:t}},Eb=(e,t)=>{if(!e||!t||t<1||e<=0)return 0;if(t===1)return e;if(t>15)return null;const n=e*(1+t/30),s=e*(36/(37-t)),i=e*Math.pow(t,.1),a=(n+s+i)/3;return Math.round(a*10)/10},Hs={WARMUP:"warmup",WORKING:"working"},Yu=[{label:"30s",seconds:30,description:"Short rest (endurance/circuits)"},{label:"60s",seconds:60,description:"Moderate rest (hypertrophy)"},{label:"90s",seconds:90,description:"Standard rest (general training)"},{label:"2m",seconds:120,description:"Extended rest (strength)"},{label:"3m",seconds:180,description:"Long rest (heavy compounds)"},{label:"5m",seconds:300,description:"Full recovery (max strength/powerlifting)"}],ak={autoStartAfterSet:!0,soundEnabled:!0,vibrationEnabled:!0,soundType:"beep",soundVolume:.5,showFloatingTimer:!0,countdownWarningAt:10,quickAdjustAmount:30},re=ht(wn(Jr((e,t)=>({isActive:!1,sessionId:null,startTime:null,pausedAt:null,totalPausedTime:0,currentExercise:null,currentExerciseIndex:0,exercises:[],sets:[],currentSetIndex:0,targetSets:3,targetReps:10,restTimer:0,restTimerActive:!1,restTimerStartedAt:null,restTimerTotalDuration:0,defaultRestDuration:90,restTimerInterval:null,exerciseRestDefaults:{},restTimerSettings:{autoStartAfterSet:!0,soundEnabled:!0,vibrationEnabled:!0,soundType:"beep",soundVolume:.5,showFloatingTimer:!0,countdownWarningAt:10,quickAdjustAmount:30},totalVolume:0,totalReps:0,estimatedCalories:0,musclesWorked:new Set,sessionPRs:[],exerciseHistory:{},exerciseGroups:[],activeGroup:null,activeGroupExerciseIndex:0,activeGroupRound:1,groupSets:[],onWorkoutComplete:null,onPRAchieved:null,onLevelUp:null,startSession:n=>{const s=`workout_${Date.now()}`;return e({isActive:!0,sessionId:s,startTime:Date.now(),pausedAt:null,totalPausedTime:0,exercises:n?.exercises||[],currentExercise:n?.exercises?.[0]||null,currentExerciseIndex:0,sets:[],currentSetIndex:0,totalVolume:0,totalReps:0,estimatedCalories:0,musclesWorked:new Set}),s},pauseSession:()=>{!t().isActive||t().pausedAt||(e({pausedAt:Date.now()}),t().stopRestTimer())},resumeSession:()=>{const{pausedAt:n,totalPausedTime:s}=t();if(!n)return;const i=Date.now()-n;e({pausedAt:null,totalPausedTime:s+i})},endSession:()=>{t().stopRestTimer();const n=t().getSessionSummary();return e({isActive:!1,sessionId:null,startTime:null,pausedAt:null,totalPausedTime:0,currentExercise:null,currentExerciseIndex:0,exercises:[],sets:[],currentSetIndex:0,restTimer:0,restTimerActive:!1}),n},completeWorkout:(n={})=>{const s=t().getSessionSummary(),{onWorkoutComplete:i,onLevelUp:a}=t(),o={...s,xpEarned:n.xpEarned||Math.round(s.totalVolume*.01),duration:s.duration,exerciseCount:s.exercisesCompleted,totalSets:s.totalSets,totalVolume:s.totalVolume,prsAchieved:s.sessionPRs.length,musclesWorked:s.musclesWorked,completedAt:Date.now()};if(i)try{i(o)}catch{}if(n.leveledUp&&a)try{a({newLevel:n.newLevel,xpEarned:o.xpEarned})}catch{}return t().endSession(),o},setOnWorkoutComplete:n=>e({onWorkoutComplete:n}),setOnPRAchieved:n=>e({onPRAchieved:n}),setOnLevelUp:n=>e({onLevelUp:n}),registerCelebrationCallbacks:({onComplete:n,onPR:s,onLevelUp:i})=>{e({onWorkoutComplete:n||null,onPRAchieved:s||null,onLevelUp:i||null})},clearCelebrationCallbacks:()=>{e({onWorkoutComplete:null,onPRAchieved:null,onLevelUp:null})},setCurrentExercise:(n,s)=>{e({currentExercise:n,currentExerciseIndex:s,currentSetIndex:0})},nextExercise:()=>{const{exercises:n,currentExerciseIndex:s}=t(),i=s+1;return i<n.length?(e({currentExercise:n[i],currentExerciseIndex:i,currentSetIndex:0}),!0):!1},previousExercise:()=>{const{exercises:n,currentExerciseIndex:s}=t(),i=s-1;return i>=0?(e({currentExercise:n[i],currentExerciseIndex:i,currentSetIndex:0}),!0):!1},logSet:({weight:n,reps:s,rpe:i,rir:a,tag:o,notes:l})=>{const{currentExercise:u,sets:d,totalVolume:h,totalReps:f,musclesWorked:g,sessionPRs:y,exerciseHistory:v}=t(),T=Eb(n,s),b={id:`set_${Date.now()}`,exerciseId:u?.id,exerciseName:u?.name,weight:n||0,reps:s||0,rpe:i||null,rir:a!==void 0?a:null,tag:o||Hs.WORKING,notes:l||"",estimated1RM:T,timestamp:Date.now()},I=b.weight*b.reps,x=new Set(g);u?.primaryMuscles&&u.primaryMuscles.forEach(R=>x.add(R)),u?.secondaryMuscles&&u.secondaryMuscles.forEach(R=>x.add(R));const w=u?.id,_=v[w]||{best1RM:0,bestWeight:0,bestVolume:0},A=[],k={..._};if(o!==Hs.WARMUP&&n>_.bestWeight&&(A.push({type:"weight",exerciseId:w,exerciseName:u?.name,value:n,previous:_.bestWeight}),k.bestWeight=n),T&&T>_.best1RM&&(A.push({type:"1rm",exerciseId:w,exerciseName:u?.name,value:T,previous:_.best1RM}),k.best1RM=T),o!==Hs.WARMUP&&I>_.bestVolume&&(A.push({type:"volume",exerciseId:w,exerciseName:u?.name,value:I,previous:_.bestVolume}),k.bestVolume=I),e({sets:[...d,b],currentSetIndex:d.filter(R=>R.exerciseId===u?.id).length+1,totalVolume:h+I,totalReps:f+b.reps,musclesWorked:x,estimatedCalories:t().estimatedCalories+Math.round(I*.002),sessionPRs:[...y,...A],exerciseHistory:{...v,[w]:k}}),A.length>0){const{onPRAchieved:R}=t();if(R)try{R({prs:A,exerciseName:u?.name,set:b})}catch{}}return{set:b,prs:A}},updateSet:(n,s)=>{e(i=>({sets:i.sets.map(a=>a.id===n?{...a,...s}:a)}))},deleteSet:n=>{const s=t().sets.find(a=>a.id===n);if(!s)return;const i=s.weight*s.reps;e(a=>({sets:a.sets.filter(o=>o.id!==n),totalVolume:a.totalVolume-i,totalReps:a.totalReps-s.reps}))},getCurrentExerciseSets:()=>{const{sets:n,currentExercise:s}=t();return n.filter(i=>i.exerciseId===s?.id)},startRestTimer:n=>{const{restTimerInterval:s,defaultRestDuration:i,exerciseRestDefaults:a,currentExercise:o}=t();s&&clearInterval(s);const l=o?.id?a[o.id]:null,u=n||l||i;e({restTimer:u,restTimerActive:!0,restTimerStartedAt:Date.now(),restTimerTotalDuration:u});const d=setInterval(()=>{const h=t().restTimer,f=t().restTimerSettings;h<=1?(clearInterval(d),e({restTimer:0,restTimerActive:!1,restTimerInterval:null,restTimerStartedAt:null,restTimerTotalDuration:0}),f.soundEnabled&&t().playTimerSound("complete"),f.vibrationEnabled&&"vibrate"in navigator&&navigator.vibrate([200,100,200,100,300])):(e({restTimer:h-1}),h===f.countdownWarningAt&&f.soundEnabled&&t().playTimerSound("warning"))},1e3);e({restTimerInterval:d})},playTimerSound:n=>{const{restTimerSettings:s}=t(),i=s.soundVolume;try{const a=new(window.AudioContext||window.webkitAudioContext),o=a.createOscillator(),l=a.createGain();if(o.connect(l),l.connect(a.destination),l.gain.value=i,n==="warning")o.frequency.value=660,o.type="sine",o.start(),l.gain.exponentialRampToValueAtTime(.01,a.currentTime+.15),setTimeout(()=>{o.stop(),a.close()},150);else if(n==="complete"){const u=s.soundType;let d=[880,880,1100],h=[150,150,300];u==="chime"?(d=[523,659,784],h=[200,200,400]):u==="bell"&&(d=[440,554,659],h=[300,300,500]),o.frequency.value=d[0],o.type="sine",o.start(),l.gain.exponentialRampToValueAtTime(.01,a.currentTime+h[0]/1e3),setTimeout(()=>{o.stop(),a.close();const f=new(window.AudioContext||window.webkitAudioContext),g=f.createOscillator(),y=f.createGain();g.connect(y),y.connect(f.destination),y.gain.value=i,g.frequency.value=d[1],g.type="sine",g.start(),y.gain.exponentialRampToValueAtTime(.01,f.currentTime+h[1]/1e3),setTimeout(()=>{g.stop(),f.close();const v=new(window.AudioContext||window.webkitAudioContext),T=v.createOscillator(),b=v.createGain();T.connect(b),b.connect(v.destination),b.gain.value=i,T.frequency.value=d[2],T.type="sine",T.start(),b.gain.exponentialRampToValueAtTime(.01,v.currentTime+h[2]/1e3),setTimeout(()=>{T.stop(),v.close()},h[2])},h[1]+50)},h[0]+50)}}catch{}},startRestTimerWithPreset:n=>{const s=Yu[n];s&&t().startRestTimer(s.seconds)},stopRestTimer:()=>{const{restTimerInterval:n}=t();n&&clearInterval(n),e({restTimer:0,restTimerActive:!1,restTimerInterval:null,restTimerStartedAt:null,restTimerTotalDuration:0})},adjustRestTimer:n=>{const{restTimer:s,restTimerTotalDuration:i}=t(),a=Math.max(0,s+n),o=n>0?Math.max(i,a):i;e({restTimer:a,restTimerTotalDuration:o})},updateRestTimerSettings:n=>{e(s=>({restTimerSettings:{...s.restTimerSettings,...n}}))},getRestTimerProgress:()=>{const{restTimer:n,restTimerTotalDuration:s}=t();return!s||s===0?0:(s-n)/s*100},setDefaultRestDuration:n=>{e({defaultRestDuration:n})},setExerciseRestDefault:(n,s)=>{e(i=>({exerciseRestDefaults:{...i.exerciseRestDefaults,[n]:s}}))},getRestDurationForExercise:n=>{const{exerciseRestDefaults:s,defaultRestDuration:i}=t();return s[n]||i},getSessionDuration:()=>{const{startTime:n,pausedAt:s,totalPausedTime:i,isActive:a}=t();return!n||!a?0:(s||Date.now())-n-i},getSessionSummary:()=>{const n=t(),s={};return n.sets.forEach(i=>{i.estimated1RM&&(!s[i.exerciseId]||i.estimated1RM>s[i.exerciseId])&&(s[i.exerciseId]=i.estimated1RM)}),{sessionId:n.sessionId,duration:n.getSessionDuration(),totalSets:n.sets.length,totalReps:n.totalReps,totalVolume:n.totalVolume,estimatedCalories:n.estimatedCalories,exercisesCompleted:new Set(n.sets.map(i=>i.exerciseId)).size,musclesWorked:Array.from(n.musclesWorked),sets:n.sets,sessionPRs:n.sessionPRs,exerciseBest1RMs:s}},getProgressForExercise:n=>{const{sets:s,targetSets:i}=t(),a=s.filter(o=>o.exerciseId===n);return{completed:a.length,target:i,percentage:Math.min(100,a.length/i*100)}},getSessionPRs:()=>t().sessionPRs,getExerciseHistory:n=>t().exerciseHistory[n]||{best1RM:0,bestWeight:0,bestVolume:0},loadExerciseHistory:n=>{e({exerciseHistory:n})},setExerciseGroups:n=>{e({exerciseGroups:n})},startGroup:n=>{e({activeGroup:n,activeGroupExerciseIndex:0,activeGroupRound:1,groupSets:[]})},advanceGroupExercise:()=>{const{activeGroup:n,activeGroupExerciseIndex:s,activeGroupRound:i}=t();if(!n)return{completed:!0,nextRound:!1};const a=n.exercises?.length||0,o=s>=a-1,l=n.circuitRounds||1,u=i>=l;return o?u?{completed:!0,nextRound:!1}:(e({activeGroupExerciseIndex:0,activeGroupRound:i+1}),{completed:!1,nextRound:!0}):(e({activeGroupExerciseIndex:s+1}),{completed:!1,nextRound:!1})},previousGroupExercise:()=>{const{activeGroupExerciseIndex:n}=t();return n>0?(e({activeGroupExerciseIndex:n-1}),!0):!1},logGroupSet:n=>{const{activeGroup:s,activeGroupExerciseIndex:i,activeGroupRound:a,groupSets:o}=t();if(!s)return null;const l=s.exercises?.[i],u={id:`gset_${Date.now()}`,groupId:s.id,exerciseId:l?.exerciseId,exerciseIndex:i,round:a,...n,timestamp:Date.now()};return e({groupSets:[...o,u]}),u},completeGroup:()=>{const{activeGroup:n,groupSets:s,sets:i}=t();if(!n)return null;const a={groupId:n.id,groupType:n.groupType,totalSets:s.length,completedRounds:t().activeGroupRound,sets:s};return e({sets:[...i,...s.map(o=>({...o,isGroupSet:!0,groupId:n.id,groupType:n.groupType}))],activeGroup:null,activeGroupExerciseIndex:0,activeGroupRound:1,groupSets:[]}),a},cancelGroup:()=>{const{activeGroup:n,groupSets:s}=t(),i={groupId:n?.id,cancelled:!0,setsLogged:s.length};return e({activeGroup:null,activeGroupExerciseIndex:0,activeGroupRound:1,groupSets:[]}),i},getCurrentGroupExercise:()=>{const{activeGroup:n,activeGroupExerciseIndex:s}=t();return n&&n.exercises?.[s]||null},getGroupProgress:()=>{const{activeGroup:n,activeGroupExerciseIndex:s,activeGroupRound:i,groupSets:a}=t();if(!n)return null;const o=n.exercises?.length||0,l=n.circuitRounds||1,u=o*l;return{currentExercise:s+1,totalExercises:o,currentRound:i,totalRounds:l,setsCompleted:a.length,totalSetsExpected:u,progress:u>0?a.length/u*100:0}}}),{name:"musclemap-workout-session",storage:ln(()=>ds),partialize:e=>({defaultRestDuration:e.defaultRestDuration,exerciseRestDefaults:e.exerciseRestDefaults,exerciseHistory:e.exerciseHistory,restTimerSettings:e.restTimerSettings})}))),ok=()=>{const e=re(g=>g.restTimer),t=re(g=>g.restTimerActive),n=re(g=>g.restTimerTotalDuration),s=re(g=>g.defaultRestDuration),i=re(g=>g.startRestTimer),a=re(g=>g.startRestTimerWithPreset),o=re(g=>g.stopRestTimer),l=re(g=>g.adjustRestTimer),u=re(g=>g.setDefaultRestDuration),d=re(g=>g.setExerciseRestDefault),h=re(g=>g.getRestTimerProgress),f=n>0?(n-e)/n*100:0;return{time:e,isActive:t,totalDuration:n,defaultDuration:s,presets:Yu,start:i,startWithPreset:a,stop:o,adjust:l,setDefault:u,setExerciseDefault:d,getProgress:h,progress:f,formatted:`${Math.floor(e/60)}:${(e%60).toString().padStart(2,"0")}`}},ck=()=>{const e=re(s=>s.restTimerSettings),t=re(s=>s.updateRestTimerSettings),n=re(s=>s.playTimerSound);return{settings:e,update:t,playSound:n,toggleAutoStart:()=>t({autoStartAfterSet:!e.autoStartAfterSet}),toggleSound:()=>t({soundEnabled:!e.soundEnabled}),toggleVibration:()=>t({vibrationEnabled:!e.vibrationEnabled}),toggleFloating:()=>t({showFloatingTimer:!e.showFloatingTimer}),setSoundType:s=>t({soundType:s}),setSoundVolume:s=>t({soundVolume:s}),setWarningThreshold:s=>t({countdownWarningAt:s}),setQuickAdjust:s=>t({quickAdjustAmount:s})}},lk=()=>{const e=re(a=>a.registerCelebrationCallbacks),t=re(a=>a.clearCelebrationCallbacks),n=re(a=>a.setOnWorkoutComplete),s=re(a=>a.setOnPRAchieved),i=re(a=>a.setOnLevelUp);return{register:e,clear:t,setOnComplete:n,setOnPR:s,setOnLevelUp:i}},Gs={FRONT:{x:0,y:0,z:5,rotation:{x:0,y:0,z:0}},BACK:{x:0,y:0,z:-5,rotation:{x:0,y:Math.PI,z:0}},LEFT:{x:-5,y:0,z:0,rotation:{x:0,y:-Math.PI/2,z:0}},RIGHT:{x:5,y:0,z:0,rotation:{x:0,y:Math.PI/2,z:0}},TOP:{x:0,y:5,z:0,rotation:{x:-Math.PI/2,y:0,z:0}},ISOMETRIC:{x:3,y:2,z:4,rotation:{x:-.3,y:.6,z:0}}};ht(wn((e,t)=>({highlightedMuscles:[],hoverMuscle:null,selectedMuscle:null,highlightMuscle:n=>e(s=>({highlightedMuscles:s.highlightedMuscles.includes(n)?s.highlightedMuscles:[...s.highlightedMuscles,n]})),unhighlightMuscle:n=>e(s=>({highlightedMuscles:s.highlightedMuscles.filter(i=>i!==n)})),setHighlightedMuscles:n=>e({highlightedMuscles:n}),clearHighlights:()=>e({highlightedMuscles:[]}),setHoverMuscle:n=>e({hoverMuscle:n}),setSelectedMuscle:n=>e({selectedMuscle:n}),muscleIntensity:{},setMuscleIntensity:(n,s)=>e(i=>({muscleIntensity:{...i.muscleIntensity,[n]:Math.max(0,Math.min(1,s))}})),setAllIntensities:n=>e({muscleIntensity:n}),clearIntensities:()=>e({muscleIntensity:{}}),setIntensityFromWorkout:n=>{const s={};n.forEach(o=>{const l=(o.weight||0)*(o.reps||0);[...o.primaryMuscles||[],...o.secondaryMuscles||[]].forEach((d,h)=>{const f=h<(o.primaryMuscles?.length||0)?1:.5;s[d]=(s[d]||0)+l*f})});const i=Math.max(...Object.values(s),1),a={};Object.keys(s).forEach(o=>{a[o]=s[o]/i}),e({muscleIntensity:a})},cameraPosition:Gs.FRONT,cameraTarget:{x:0,y:0,z:0},autoRotate:!1,zoom:1,setCameraPosition:n=>e({cameraPosition:n}),setCameraPreset:n=>{const s=Gs[n];s&&e({cameraPosition:s})},setCameraTarget:n=>e({cameraTarget:n}),setAutoRotate:n=>e({autoRotate:n}),toggleAutoRotate:()=>e(n=>({autoRotate:!n.autoRotate})),setZoom:n=>e({zoom:Math.max(.5,Math.min(3,n))}),zoomIn:()=>e(n=>({zoom:Math.min(3,n.zoom+.1)})),zoomOut:()=>e(n=>({zoom:Math.max(.5,n.zoom-.1)})),resetCamera:()=>e({cameraPosition:Gs.FRONT,cameraTarget:{x:0,y:0,z:0},zoom:1,autoRotate:!1}),showLabels:!0,showSkeleton:!1,wireframeMode:!1,transparencyMode:!1,colorScheme:"heatmap",setShowLabels:n=>e({showLabels:n}),toggleShowLabels:()=>e(n=>({showLabels:!n.showLabels})),setShowSkeleton:n=>e({showSkeleton:n}),toggleShowSkeleton:()=>e(n=>({showSkeleton:!n.showSkeleton})),setWireframeMode:n=>e({wireframeMode:n}),toggleWireframeMode:()=>e(n=>({wireframeMode:!n.wireframeMode})),setTransparencyMode:n=>e({transparencyMode:n}),setColorScheme:n=>e({colorScheme:n}),animationState:"idle",animationProgress:0,setAnimationState:n=>e({animationState:n}),setAnimationProgress:n=>e({animationProgress:n}),getMuscleIntensity:n=>t().muscleIntensity[n]||0,getActiveMuscles:()=>Object.entries(t().muscleIntensity).filter(([n,s])=>s>0).map(([n])=>n),getMuscleColor:n=>{const s=t().muscleIntensity[n]||0,{colorScheme:i,highlightedMuscles:a,hoverMuscle:o,selectedMuscle:l}=t();if(l===n)return{r:.2,g:.6,b:1,a:1};if(o===n)return{r:.8,g:.8,b:1,a:.9};if(a.includes(n))return{r:1,g:.8,b:.2,a:.9};if(i==="heatmap"){if(s<.25)return{r:.2,g:.2+s*2,b:.8,a:.6+s};if(s<.5){const u=(s-.25)*4;return{r:u,g:.7,b:.8-u*.8,a:.7+s*.3}}else return s<.75?{r:1,g:.7-(s-.5)*4*.3,b:0,a:.8+s*.2}:{r:1,g:.4-(s-.75)*4*.4,b:0,a:.9+s*.1}}return{r:.8,g:.3,b:.3,a:.7}}})));const qr={TU:{term:"Training Units",explanation:"Training Units (TU) measure your workout effort. You earn TU based on exercise volume, intensity, and muscle activation. The more you push, the more you earn.",learnMoreUrl:"/docs/training-units"},XP:{term:"Experience Points",explanation:"Experience Points track your overall progress. Earn XP by completing workouts, hitting milestones, and achieving goals. Level up to unlock new features.",learnMoreUrl:"/docs/xp-system"},credits:{term:"Credits",explanation:"Credits are the in-app currency you earn through workouts and achievements. Spend them on premium features, challenges, and to support other users.",learnMoreUrl:"/docs/credits"},archetype:{term:"Archetype",explanation:"Your Archetype defines your training focus and playstyle. Each archetype has unique strengths, progression paths, and visual themes.",learnMoreUrl:"/docs/archetypes"},journey:{term:"Journey",explanation:"Your Journey is the progression path within your Archetype. Complete stages to unlock new abilities, badges, and exclusive challenges.",learnMoreUrl:"/docs/journey"},rank:{term:"Rank",explanation:"Your Rank shows your standing in the community. Rise through ranks by earning XP, completing challenges, and maintaining consistency.",learnMoreUrl:"/docs/ranks"},wealthTier:{term:"Wealth Tier",explanation:"Wealth Tier reflects your accumulated credits. Higher tiers unlock exclusive visual badges and profile effects.",learnMoreUrl:"/docs/wealth-tiers"},muscleActivation:{term:"Muscle Activation",explanation:"Muscle Activation shows how intensely a muscle group is being worked during an exercise. Higher activation means more targeted muscle engagement.",learnMoreUrl:"/docs/muscle-activation"},restTimer:{term:"Rest Timer",explanation:"The Rest Timer helps you optimize recovery between sets. Recommended rest times vary by exercise type and training goal."},set:{term:"Set",explanation:"A Set is a group of consecutive repetitions of an exercise. Log your sets to track progress and earn TU."},rep:{term:"Rep (Repetition)",explanation:"A Rep is one complete movement of an exercise. Multiple reps make up a set."},oneRM:{term:"1RM (One Rep Max)",explanation:"Your One Rep Max is the maximum weight you can lift for a single repetition. It's used to calculate training percentages.",learnMoreUrl:"/docs/one-rep-max"},volume:{term:"Volume",explanation:"Training Volume is the total amount of work performed, calculated as sets x reps x weight. Higher volume generally means more muscle growth stimulus."},crew:{term:"Crew",explanation:"A Crew is your training group. Join or create a Crew to share workouts, compete on leaderboards, and motivate each other.",learnMoreUrl:"/docs/crews"},highFive:{term:"High Five",explanation:"High Fives are quick kudos you can send to celebrate others' achievements. Spread the motivation!"},streak:{term:"Streak",explanation:"Your Streak counts consecutive days with logged workouts. Maintain your streak for bonus XP and achievements."},transfer:{term:"Credit Transfer",explanation:"Send credits to other users as tips, gifts, or payments. A small fee helps maintain the economy."},dailyReward:{term:"Daily Reward",explanation:"Log in daily to claim free credits. Longer streaks mean bigger rewards!"},competition:{term:"Competition",explanation:"Competitions are time-limited challenges where you compete with others. Win credits, badges, and bragging rights.",learnMoreUrl:"/docs/competitions"},milestone:{term:"Milestone",explanation:"Milestones mark significant achievements in your fitness journey. Each milestone unlocks rewards and recognition."},achievement:{term:"Achievement",explanation:"Achievements are special badges earned by completing specific challenges or reaching goals. Collect them all!",learnMoreUrl:"/docs/achievements"},skill:{term:"Skill",explanation:"Skills represent specific exercise competencies. Level up skills by performing exercises with proper form and consistency.",learnMoreUrl:"/docs/skills"},graphQL:{term:"GraphQL",explanation:"GraphQL is the technology powering our API. It allows efficient data fetching with exactly what you need."},websocket:{term:"WebSocket",explanation:"WebSockets enable real-time updates. See live activity, instant notifications, and sync across devices."}};function Ab(e){return qr[e]||null}const _b=m.createContext(null);function uk(){const e=m.useContext(_b);return e||{getHelp:Ab,hasHelp:t=>!!qr[t],getAllTerms:()=>Object.keys(qr),addHelp:()=>{},addHelpBatch:()=>{},removeHelp:()=>{},activeTooltip:null,openTooltip:()=>{},closeTooltip:()=>{},isTooltipActive:()=>!1,baseDocsUrl:""}}const J={WORKOUT_COMPLETE:"workout_complete",FIRST_LOGIN:"first_login",EARNED_CREDITS:"earned_credits",NEW_ACHIEVEMENT:"new_achievement",STREAK_MILESTONE:"streak_milestone",LEVEL_UP:"level_up",NO_WORKOUT_3_DAYS:"no_workout_3_days",PROFILE_INCOMPLETE:"profile_incomplete",LOW_CREDITS:"low_credits",INACTIVE_3_DAYS:"inactive_3_days",STREAK_AT_RISK:"streak_at_risk",FIRST_WORKOUT:"first_workout",MILESTONE_REACHED:"milestone_reached",COMMUNITY_JOIN:"community_join",ARCHETYPE_SELECTED:"archetype_selected"},dk={action:{icon:"zap",color:"from-blue-500/30 to-cyan-500/30",glow:"rgba(0, 102, 255, 0.3)"},progress:{icon:"trending-up",color:"from-green-500/30 to-emerald-500/30",glow:"rgba(34, 197, 94, 0.3)"},reward:{icon:"award",color:"from-yellow-500/30 to-orange-500/30",glow:"rgba(245, 158, 11, 0.3)"},social:{icon:"users",color:"from-purple-500/30 to-pink-500/30",glow:"rgba(139, 92, 246, 0.3)"},reminder:{icon:"bell",color:"from-red-500/30 to-rose-500/30",glow:"rgba(239, 68, 68, 0.3)"}},Ku={workout_complete_view_map:{id:"workout_complete_view_map",trigger:J.WORKOUT_COMPLETE,category:"action",message:"Great workout! View your muscle activation map",action:{label:"View Map",to:"/stats"},priority:1},workout_complete_share:{id:"workout_complete_share",trigger:J.WORKOUT_COMPLETE,category:"social",message:"Nice work! Share your progress with the community.",action:{label:"Share",to:"/community/share"},priority:2},first_login_welcome:{id:"first_login_welcome",trigger:J.FIRST_LOGIN,category:"action",message:"Welcome! Start with the guided tour",action:{label:"Start Tour",to:"/onboarding"},priority:1},first_login_complete_profile:{id:"first_login_complete_profile",trigger:J.FIRST_LOGIN,category:"action",message:"Complete your profile to unlock all features and earn bonus credits!",action:{label:"Complete Profile",to:"/profile"},priority:2},first_login_choose_archetype:{id:"first_login_choose_archetype",trigger:J.FIRST_LOGIN,category:"action",message:"Choose your training archetype to get personalized workouts.",action:{label:"Choose Archetype",to:"/journey"},priority:3},profile_completed:{id:"profile_completed",trigger:"profile_completed",category:"achievement",message:"🎉 Profile complete! You're all set to start your fitness journey.",action:{label:"Start Workout",to:"/workout"},priority:1},earned_credits_store:{id:"earned_credits_store",trigger:J.EARNED_CREDITS,category:"reward",message:"You earned credits! Visit the store",action:{label:"Visit Store",to:"/store"},priority:1},streak_milestone_amazing:{id:"streak_milestone_amazing",trigger:J.STREAK_MILESTONE,category:"progress",message:"Amazing streak! Keep it going",action:{label:"View Streak",to:"/stats"},priority:1},no_workout_3_days_comeback:{id:"no_workout_3_days_comeback",trigger:J.NO_WORKOUT_3_DAYS,category:"reminder",message:"Time to get back in the gym!",action:{label:"Start Workout",to:"/workout"},priority:1},low_credits_earn:{id:"low_credits_earn",trigger:J.LOW_CREDITS,category:"reward",message:"Running low on credits? Complete workouts to earn more!",action:{label:"Start Workout",to:"/workout"},priority:1},low_credits_daily:{id:"low_credits_daily",trigger:J.LOW_CREDITS,category:"reward",message:"Claim your daily bonus credits to keep your streak going.",action:{label:"Claim Bonus",to:"/rewards"},priority:2},new_achievement_view:{id:"new_achievement_view",trigger:J.NEW_ACHIEVEMENT,category:"reward",message:"You unlocked an achievement! View all achievements",action:{label:"View Achievements",to:"/achievements"},priority:1},inactive_3_days_welcome_back:{id:"inactive_3_days_welcome_back",trigger:J.INACTIVE_3_DAYS,category:"reminder",message:"Ready to get back to training? Let's pick up where you left off.",action:{label:"Resume Training",to:"/workout"},priority:1},inactive_3_days_quick_workout:{id:"inactive_3_days_quick_workout",trigger:J.INACTIVE_3_DAYS,category:"action",message:"Haven't worked out in a while? Try a quick 15-minute session.",action:{label:"Quick Workout",to:"/workout/quick"},priority:2},profile_incomplete_bonus:{id:"profile_incomplete_bonus",trigger:J.PROFILE_INCOMPLETE,category:"action",message:"Complete your profile for bonus XP",action:{label:"Complete Profile",to:"/profile"},priority:1},profile_incomplete_avatar:{id:"profile_incomplete_avatar",trigger:J.PROFILE_INCOMPLETE,category:"action",message:"Add a profile photo to personalize your experience.",action:{label:"Add Photo",to:"/profile"},priority:2},streak_at_risk:{id:"streak_at_risk",trigger:J.STREAK_AT_RISK,category:"reminder",message:"Your streak is at risk! Don't lose your progress.",action:{label:"Quick Workout",to:"/workout"},priority:1},level_up_view:{id:"level_up_view",trigger:J.LEVEL_UP,category:"reward",message:"You leveled up! Check your new stats",action:{label:"View Stats",to:"/stats/progression"},priority:1},first_workout_welcome:{id:"first_workout_welcome",trigger:J.FIRST_WORKOUT,category:"progress",message:"You've completed your first workout! You're on your way to greatness.",action:{label:"View Stats",to:"/stats"},priority:1},milestone_reached:{id:"milestone_reached",trigger:J.MILESTONE_REACHED,category:"reward",message:"You've reached a new milestone! Celebrate your progress.",action:{label:"View Milestone",to:"/achievements/milestones"},priority:1},community_join_welcome:{id:"community_join_welcome",trigger:J.COMMUNITY_JOIN,category:"social",message:"Welcome to the community! Introduce yourself in the feed.",action:{label:"Say Hi",to:"/community"},priority:1},archetype_selected_explore:{id:"archetype_selected_explore",trigger:J.ARCHETYPE_SELECTED,category:"action",message:"Great choice! Explore your personalized training journey.",action:{label:"Start Journey",to:"/journey"},priority:1}};function Cb(e){return Object.values(Ku).filter(t=>t.trigger===e).sort((t,n)=>t.priority-n.priority)}function Qu(e){const t=Cb(e);return t.length>0?t[0]:null}function kb(e){return Ku[e]||null}const Ju="musclemap_dismissed_tips",Xu="musclemap_tip_cooldowns",Rb=24*60*60*1e3;function Pb(){if(typeof window>"u")return new Set;try{const e=localStorage.getItem(Ju);return e?new Set(JSON.parse(e)):new Set}catch{return new Set}}function Ys(e){if(!(typeof window>"u"))try{localStorage.setItem(Ju,JSON.stringify([...e]))}catch{}}function Mb(){if(typeof window>"u")return{};try{const e=localStorage.getItem(Xu);return e?JSON.parse(e):{}}catch{return{}}}function Ks(e){if(!(typeof window>"u"))try{localStorage.setItem(Xu,JSON.stringify(e))}catch{}}const Zu=m.createContext(null);function Ob({children:e}){const[t,n]=m.useState([]),[s,i]=m.useState(Pb),[a,o]=m.useState(Mb),l=t.length>0?t[0]:null,u=m.useCallback((w,_=Rb)=>{const A=a[w];return A?Date.now()-A<_:!1},[a]),d=m.useCallback(w=>!(s.has(w)||u(w)||t.some(_=>_.id===w)),[s,u,t]),h=m.useCallback((w,_={})=>{const{data:A={},forceShow:k=!1}=_,R=Qu(w);if(!R||!k&&!d(R.id))return null;const P={...R,instanceId:`${R.id}-${Date.now()}`,data:A,shownAt:Date.now()};return n(O=>[...O,P]),o(O=>{const N={...O,[R.id]:Date.now()};return Ks(N),N}),R.id},[d]),f=m.useCallback((w,_={})=>{const{data:A={},forceShow:k=!1}=_,R=kb(w);if(!R||!k&&!d(R.id))return!1;const P={...R,instanceId:`${R.id}-${Date.now()}`,data:A,shownAt:Date.now()};return n(O=>[...O,P]),o(O=>{const N={...O,[R.id]:Date.now()};return Ks(N),N}),!0},[d]),g=m.useCallback((w=!1)=>{l&&(n(_=>_.slice(1)),w&&i(_=>{const A=new Set(_);return A.add(l.id),Ys(A),A}))},[l]),y=m.useCallback((w,_=!1)=>{const A=t.find(k=>k.instanceId===w);A&&(n(k=>k.filter(R=>R.instanceId!==w)),_&&i(k=>{const R=new Set(k);return R.add(A.id),Ys(R),R}))},[t]),v=m.useCallback(()=>{n([])},[]),T=m.useCallback(()=>{if(i(new Set),Ys(new Set),o({}),Ks({}),typeof window<"u")try{localStorage.removeItem("musclemap_shown_once_tips")}catch{}},[]),b=T,I=m.useCallback(w=>s.has(w),[s]),x=m.useMemo(()=>({activeTip:l,visibleTips:t,hasTips:t.length>0,showTip:h,showTipById:f,dismissTip:g,dismissTipById:y,clearAllTips:v,resetDismissedTips:T,resetTips:b,canShowTip:d,isTipDismissed:I,isOnCooldown:u,triggers:J}),[l,t,h,f,g,y,v,T,b,d,I,u]);return c.jsx(Zu.Provider,{value:x,children:e})}function Nb(){const e=m.useContext(Zu);if(!e)throw new Error("useContextualTips must be used within a ContextualTipProvider");return e}function mk(e,t,n={}){const{showTip:s,canShowTip:i}=Nb(),{delay:a=0,data:o={}}=n;m.useEffect(()=>{if(!t)return;const l=Qu(e);if(!l||!i(l.id))return;const u=setTimeout(()=>{s(e,{data:o})},a);return()=>clearTimeout(u)},[t,e,a,o,s,i])}const $b={HelpCircle:$u,Sparkles:ns,TrendingUp:ss,X:Di,ArrowRight:Rt,Dumbbell:Mi,Target:Vu,Users:$i,Trophy:Bu,Zap:ji,Heart:ju,Brain:iS,Flame:_S,Star:dT,Crown:xS,Settings:Ni,Calendar:Ou,BarChart3:Nu,Activity:Mu,Compass:Pi,Map:Lu,MessageCircle:Uu};function Yt(e){return!e||typeof e!="string"?!1:/^(?:\p{Emoji_Presentation}|\p{Emoji}\uFE0F)/u.test(e)}function Ko(e,t={}){if(!e)return null;if(Yt(e)){const{className:s,style:i}=t;return c.jsx("span",{className:ke("flex items-center justify-center",s),style:i,children:e})}const n=$b[e]||$u;return c.jsx(n,{...t})}const hk=m.forwardRef(function({feature:t,variant:n="default",onTry:s,onDismiss:i,onClick:a,isActive:o=!1,showPulse:l=!0,index:u=0,className:d},h){const{name:f,description:g,icon:y,color:v="#0066FF",isNew:T=!1,isPopular:b=!1}=t,I=s||a,x={hidden:{opacity:0,y:20,scale:.95},visible:{opacity:1,y:0,scale:1,transition:{type:"spring",stiffness:400,damping:25,delay:u*.1}},exit:{opacity:0,x:-100,scale:.9,transition:{duration:.2,ease:"easeOut"}}},w=R=>{R.stopPropagation(),I&&I(t)},_=R=>{R.stopPropagation(),i&&i(t.id)},A=l&&n!=="compact";if(n==="compact")return c.jsxs(B.button,{ref:h,layout:!0,variants:x,initial:"hidden",animate:"visible",exit:"exit",className:ke("flex-shrink-0 px-4 py-3 rounded-xl","bg-white/5 backdrop-blur-md border border-white/10","flex items-center gap-3","cursor-pointer relative","hover:bg-white/10 hover:border-white/20","transition-colors duration-200",d),onClick:w,whileHover:{scale:1.02},whileTap:{scale:.98},children:[(T||b)&&c.jsx("div",{className:"absolute -top-1.5 -right-1.5 w-5 h-5 rounded-full flex items-center justify-center",style:{background:`linear-gradient(135deg, ${v}, ${v}CC)`},children:T?c.jsx(ns,{className:"w-3 h-3 text-white"}):c.jsx(ss,{className:"w-3 h-3 text-white"})}),c.jsx("div",{className:"w-9 h-9 rounded-lg flex items-center justify-center",style:{background:`${v}20`},children:Ko(y,{className:Yt(y)?"text-xl":"w-5 h-5",style:Yt(y)?{}:{color:v},strokeWidth:1.5})}),c.jsx("span",{className:"text-sm font-medium text-white whitespace-nowrap",children:f})]});const k=n==="highlighted";return c.jsxs(B.div,{ref:h,layout:!0,variants:x,initial:"hidden",animate:"visible",exit:"exit",className:ke("relative overflow-hidden rounded-2xl","bg-white/5 backdrop-blur-md","cursor-pointer touch-action-manipulation select-none","transition-all duration-200",o&&"ring-2 ring-white/20",k&&"p-1",d),onClick:w,whileHover:{scale:1.02,y:-2},whileTap:{scale:.98},children:[A&&c.jsx(B.div,{className:"absolute inset-0 rounded-2xl pointer-events-none",style:{border:"2px solid transparent",background:`linear-gradient(#0a0a0a, #0a0a0a) padding-box,
                         linear-gradient(135deg, ${v}60, ${v}20, ${v}60) border-box`},animate:{opacity:[.5,1,.5]},transition:{duration:2,repeat:1/0,ease:"easeInOut"}}),!A&&c.jsx("div",{className:"absolute inset-0 rounded-2xl pointer-events-none",style:{border:"1px solid rgba(255, 255, 255, 0.1)"}}),c.jsx(B.div,{className:"absolute inset-0 rounded-2xl pointer-events-none",style:{background:`radial-gradient(circle at 30% 30%, ${v}15, transparent 60%)`},animate:A?{opacity:[.5,.8,.5]}:{},transition:{duration:2,repeat:1/0,ease:"easeInOut"}}),(T||b)&&c.jsx(B.div,{className:"absolute top-3 right-3 z-10",initial:{scale:0,rotate:-12},animate:{scale:1,rotate:0},transition:{type:"spring",stiffness:500,damping:20,delay:u*.1+.2},children:c.jsx("div",{className:"px-2 py-0.5 rounded-full text-xs font-bold text-white flex items-center gap-1",style:{background:`linear-gradient(135deg, ${v}, ${v}CC)`,boxShadow:`0 2px 8px ${v}50`},children:T?c.jsxs(c.Fragment,{children:[c.jsx(ns,{className:"w-3 h-3"}),"New!"]}):c.jsxs(c.Fragment,{children:[c.jsx(ss,{className:"w-3 h-3"}),"Popular!"]})})}),i&&c.jsx("button",{onClick:_,className:ke("absolute top-3 z-10",T||b?"right-20":"right-3","w-6 h-6 rounded-full","flex items-center justify-center","bg-white/5 hover:bg-white/15","text-gray-500 hover:text-gray-300","transition-all duration-150","opacity-60 hover:opacity-100"),"aria-label":`Dismiss ${f} suggestion`,children:c.jsx(Di,{className:"w-3.5 h-3.5"})}),c.jsxs("div",{className:ke("relative p-4 flex gap-4",k&&"p-5"),children:[c.jsx("div",{className:"flex-shrink-0",children:c.jsx(B.div,{className:ke("rounded-xl flex items-center justify-center relative",k?"w-14 h-14":"w-12 h-12"),style:{background:`linear-gradient(135deg, ${v}30, ${v}10)`,boxShadow:A?`0 0 20px ${v}40`:"none"},animate:A?{boxShadow:[`0 0 15px ${v}30`,`0 0 25px ${v}50`,`0 0 15px ${v}30`]}:{},transition:{duration:2,repeat:1/0,ease:"easeInOut"},children:Ko(y,{className:Yt(y)?k?"text-3xl":"text-2xl":k?"w-7 h-7":"w-6 h-6",style:Yt(y)?{}:{color:v},strokeWidth:1.5})})}),c.jsxs("div",{className:"flex-1 min-w-0 pr-6",children:[c.jsx("h3",{className:ke("font-bold text-white mb-1 truncate",k?"text-lg":"text-base"),children:f}),c.jsx("p",{className:ke("text-gray-400 line-clamp-2 leading-relaxed",k?"text-base":"text-sm"),children:g})]})]}),c.jsx("div",{className:ke("relative px-4 pb-4 pt-0",k&&"px-5 pb-5"),children:c.jsxs(B.button,{className:ke("w-full rounded-xl","flex items-center justify-center gap-2","font-medium text-white","transition-colors duration-150",k?"py-3 text-base":"py-2.5 text-sm"),style:{background:`linear-gradient(135deg, ${v}, ${v}CC)`},whileHover:{filter:"brightness(1.1)"},whileTap:{scale:.98},onClick:w,children:["Try it",c.jsx(Rt,{className:k?"w-5 h-5":"w-4 h-4"})]})}),c.jsx("div",{className:"absolute inset-0 rounded-2xl pointer-events-none",style:{background:"linear-gradient(135deg, rgba(255,255,255,0.08) 0%, transparent 50%)"}})]})}),Wt="musclemap_tour_",Db=ht((e,t)=>({isActive:!1,steps:[],currentStep:0,tourId:null,onComplete:null,onSkip:null,onStepChange:null,config:{showProgress:!0,showSkip:!0,backdropColor:"rgba(0, 0, 0, 0.75)",allowBackdropClick:!0,scrollBehavior:"smooth",spotlightPadding:8},startTour:(n,s={})=>{const{tourId:i=null,onComplete:a=null,onSkip:o=null,onStepChange:l=null,showProgress:u=!0,showSkip:d=!0,backdropColor:h="rgba(0, 0, 0, 0.75)",allowBackdropClick:f=!0,scrollBehavior:g="smooth",spotlightPadding:y=8}=s;return i&&localStorage.getItem(`${Wt}${i}`)==="true"&&!s.force?!1:(e({isActive:!0,steps:n,currentStep:0,tourId:i,onComplete:a,onSkip:o,onStepChange:l,config:{showProgress:u,showSkip:d,backdropColor:h,allowBackdropClick:f,scrollBehavior:g,spotlightPadding:y}}),!0)},nextStep:()=>{const{currentStep:n,steps:s,tourId:i,onComplete:a,onStepChange:o}=t();if(n<s.length-1){const l=n+1;e({currentStep:l}),o?.(l,s[l])}else i&&localStorage.setItem(`${Wt}${i}`,"true"),e({isActive:!1,steps:[],currentStep:0,tourId:null}),a?.()},prevStep:()=>{const{currentStep:n,steps:s,onStepChange:i}=t();if(n>0){const a=n-1;e({currentStep:a}),i?.(a,s[a])}},goToStep:n=>{const{steps:s,onStepChange:i}=t();n>=0&&n<s.length&&(e({currentStep:n}),i?.(n,s[n]))},skipTour:()=>{const{tourId:n,onSkip:s}=t();n&&localStorage.setItem(`${Wt}${n}`,"true"),e({isActive:!1,steps:[],currentStep:0,tourId:null}),s?.()},endTour:()=>{e({isActive:!1,steps:[],currentStep:0,tourId:null})},resetTour:n=>{n&&localStorage.removeItem(`${Wt}${n}`)},isTourComplete:n=>localStorage.getItem(`${Wt}${n}`)==="true"}));function pk(){const e=Db(),t=m.useCallback((d,h)=>{const f=typeof h=="string"?{tourId:h}:h||{};return e.startTour(d,f)},[e]),n=m.useCallback(()=>e.nextStep(),[e]),s=m.useCallback(()=>e.prevStep(),[e]),i=m.useCallback(d=>e.goToStep(d),[e]),a=m.useCallback(()=>e.skipTour(),[e]),o=m.useCallback(()=>e.endTour(),[e]),l=m.useCallback(d=>e.resetTour(d),[e]),u=m.useCallback(d=>e.isTourComplete(d),[e]);return{isActive:e.isActive,steps:e.steps,currentStep:e.currentStep,tourId:e.tourId,config:e.config,totalSteps:e.steps.length,currentStepData:e.steps[e.currentStep]||null,isFirstStep:e.currentStep===0,isLastStep:e.currentStep===e.steps.length-1,progress:e.steps.length>0?(e.currentStep+1)/e.steps.length*100:0,startTour:t,nextStep:n,prevStep:s,goToStep:i,skipTour:a,endTour:o,resetTour:l,isTourComplete:u,hasCompletedTour:u}}const is={glass:"rgba(255, 255, 255, 0.35)",primary:"rgba(0, 102, 255, 0.4)",pulse:"rgba(255, 51, 102, 0.4)",ghost:"rgba(255, 255, 255, 0.25)"},Qo={glass:"rgba(255, 255, 255, 0.15)",primary:"rgba(0, 102, 255, 0.35)",pulse:"rgba(255, 51, 102, 0.35)",ghost:"rgba(255, 255, 255, 0.1)"},Mt={ripple:600,success:600,burst:800},jb=[10];function fk(e=jb){if(!(typeof window<"u"&&window.matchMedia?.("(prefers-reduced-motion: reduce)").matches)&&typeof navigator<"u"&&"vibrate"in navigator)try{navigator.vibrate(e)}catch{}}let Qs=null;function ed(){if(typeof window>"u")return null;if(!Qs)try{const e=window.AudioContext||window.webkitAudioContext;e&&(Qs=new e)}catch{return null}return Qs}function Lb({frequency:e=1200,duration:t=.05,volume:n=.15}={}){const s=ed();if(s){s.state==="suspended"&&s.resume();try{const i=s.createOscillator(),a=s.createGain();i.connect(a),a.connect(s.destination),i.type="sine",i.frequency.setValueAtTime(e,s.currentTime),i.frequency.exponentialRampToValueAtTime(e*.5,s.currentTime+t),a.gain.setValueAtTime(n,s.currentTime),a.gain.exponentialRampToValueAtTime(.001,s.currentTime+t),i.start(s.currentTime),i.stop(s.currentTime+t)}catch{}}}function Ub({volume:e=.12}={}){const t=ed();if(t){t.state==="suspended"&&t.resume();try{const n=t.createOscillator(),s=t.createGain();n.connect(s),s.connect(t.destination),n.type="sine",n.frequency.value=880,s.gain.setValueAtTime(e,t.currentTime),s.gain.exponentialRampToValueAtTime(.001,t.currentTime+.15),n.start(t.currentTime),n.stop(t.currentTime+.15);const i=t.createOscillator(),a=t.createGain();i.connect(a),a.connect(t.destination),i.type="sine",i.frequency.value=1320,a.gain.setValueAtTime(0,t.currentTime),a.gain.setValueAtTime(e,t.currentTime+.08),a.gain.exponentialRampToValueAtTime(.001,t.currentTime+.25),i.start(t.currentTime+.08),i.stop(t.currentTime+.25)}catch{}}}function gk({enabled:e=!1,variant:t="primary"}={}){const n=ze(),s=m.useCallback(()=>{if(!e||n)return;Lb({frequency:{glass:1100,primary:1200,pulse:1400,ghost:1e3}[t]||1200})},[e,n,t]),i=m.useCallback(()=>{!e||n||Ub()},[e,n]);return{playClick:s,playSuccess:i}}const Vb=m.forwardRef(({variant:e="glass",className:t=""},n)=>{const s=m.useRef(null),i=m.useRef([]),a=m.useRef(null),o=ze();m.useImperativeHandle(n,()=>({trigger:(d,h)=>{o||u(d,h)}}));const l=m.useCallback(()=>{const d=s.current;if(!d)return;const h=d.getContext("2d"),f=performance.now();h.clearRect(0,0,d.width,d.height),i.current=i.current.filter(g=>{const y=f-g.startTime,v=Math.min(y/Mt.ripple,1);if(v>=1)return!1;const T=1-Math.pow(1-v,3),b=g.maxRadius*T,I=1-v;return h.beginPath(),h.arc(g.x,g.y,b,0,Math.PI*2),h.fillStyle=g.color.replace(/[\d.]+\)$/,`${I*parseFloat(g.color.match(/[\d.]+\)$/)[0])})`),h.fill(),!0}),i.current.length>0?a.current=requestAnimationFrame(l):a.current=null},[]),u=m.useCallback((d,h)=>{const f=s.current;if(!f)return;const g=f.getBoundingClientRect(),y=Math.sqrt(Math.pow(Math.max(d,g.width-d),2)+Math.pow(Math.max(h,g.height-h),2));i.current.push({x:d,y:h,startTime:performance.now(),maxRadius:y,color:is[e]||is.glass}),a.current||l()},[e,l]);return m.useEffect(()=>{const d=s.current;if(!d)return;const h=()=>{const g=d.parentElement?.getBoundingClientRect();g&&(d.width=g.width,d.height=g.height)};h();const f=new ResizeObserver(h);return d.parentElement&&f.observe(d.parentElement),()=>{f.disconnect(),a.current&&cancelAnimationFrame(a.current)}},[]),c.jsx("canvas",{ref:s,className:`absolute inset-0 pointer-events-none rounded-inherit ${t}`,style:{borderRadius:"inherit"}})});Vb.displayName="RippleEffect";const Jo={glass:{check:"#00ff88",glow:"rgba(0, 255, 136, 0.6)",brand:"rgba(255, 255, 255, 0.4)"},primary:{check:"#ffffff",glow:"rgba(0, 255, 136, 0.6)",brand:"rgba(0, 102, 255, 0.6)"},pulse:{check:"#ffffff",glow:"rgba(255, 51, 102, 0.6)",brand:"rgba(255, 51, 102, 0.6)"},ghost:{check:"#00ff88",glow:"rgba(0, 255, 136, 0.4)",brand:"rgba(255, 255, 255, 0.3)"}},yk=({active:e,variant:t="primary",animationType:n="checkmark",onComplete:s})=>{const i=ze(),[a,o]=m.useState(!1),l=m.useRef(null),u=m.useRef([]),d=m.useRef(null),h=Jo[t]||Jo.primary;m.useEffect(()=>{if(e&&n!=="none"){o(!0),n==="burst"&&!i&&f();const y=n==="burst"?Mt.burst:Mt.success,v=setTimeout(()=>{o(!1),s?.()},y);return()=>clearTimeout(v)}},[e,n,s,i]);const f=m.useCallback(()=>{const y=l.current;if(!y)return;const v=y.getBoundingClientRect(),T=v.width/2,b=v.height/2,I={glass:["#ffffff","#0066ff","#00aaff","#00ff88"],primary:["#0066ff","#00aaff","#ffffff","#00ff88"],pulse:["#ff3366","#ff6699","#ffffff","#ff99bb"],ghost:["#ffffff","#94a3b8","#64748b","#00ff88"]},x=I[t]||I.primary;for(let w=0;w<30;w++){const _=Math.PI*2*w/30+(Math.random()-.5)*.3,A=Math.random()*4+3;u.current.push({x:T,y:b,vx:Math.cos(_)*A,vy:Math.sin(_)*A,size:Math.random()*5+2,color:x[Math.floor(Math.random()*x.length)],opacity:1,decay:Math.random()*.02+.012,rotation:Math.random()*Math.PI*2,rotationSpeed:(Math.random()-.5)*.3})}d.current||g()},[t]),g=m.useCallback(()=>{const y=l.current;if(!y)return;const v=y.getContext("2d");v.clearRect(0,0,y.width,y.height),u.current=u.current.filter(T=>{if(T.x+=T.vx,T.y+=T.vy,T.vx*=.96,T.vy*=.96,T.vy+=.08,T.opacity-=T.decay,T.rotation+=T.rotationSpeed,T.opacity<=0)return!1;v.save(),v.translate(T.x,T.y),v.rotate(T.rotation),v.globalAlpha=T.opacity,v.fillStyle=T.color,v.beginPath();for(let b=0;b<5;b++){const I=b*Math.PI*2/5-Math.PI/2,x=T.size,w=T.size*.4;b===0?v.moveTo(Math.cos(I)*x,Math.sin(I)*x):v.lineTo(Math.cos(I)*x,Math.sin(I)*x);const _=I+Math.PI/5;v.lineTo(Math.cos(_)*w,Math.sin(_)*w)}return v.closePath(),v.fill(),v.restore(),!0}),u.current.length>0?d.current=requestAnimationFrame(g):d.current=null},[]);return m.useEffect(()=>{const y=l.current;if(!y)return;const v=()=>{const b=y.parentElement?.getBoundingClientRect();b&&(y.width=b.width,y.height=b.height)};v();const T=new ResizeObserver(v);return y.parentElement&&T.observe(y.parentElement),()=>{T.disconnect(),d.current&&cancelAnimationFrame(d.current)}},[]),!a||n==="none"?null:n==="burst"?c.jsx("div",{className:"absolute inset-0 pointer-events-none overflow-hidden",style:{borderRadius:"inherit"},children:c.jsx("canvas",{ref:l,className:"absolute inset-0",style:{borderRadius:"inherit"}})}):n==="glow"?c.jsxs("div",{className:"absolute inset-0 flex items-center justify-center pointer-events-none",style:{borderRadius:"inherit"},children:[c.jsx("div",{className:"absolute inset-0",style:{background:`radial-gradient(circle at center, ${h.brand} 0%, transparent 60%)`,animation:i?"none":"success-intense-glow 0.6s ease-out forwards",borderRadius:"inherit"}}),c.jsx("div",{className:"absolute inset-0",style:{boxShadow:`0 0 30px 10px ${h.brand}, inset 0 0 20px 5px ${h.brand}`,animation:i?"none":"success-ring-pulse 0.6s ease-out forwards",borderRadius:"inherit"}})]}):c.jsxs("div",{className:"absolute inset-0 flex items-center justify-center pointer-events-none",style:{animation:i?"none":"success-glow 0.6s ease-out forwards",borderRadius:"inherit"},children:[c.jsx("div",{className:"absolute inset-0",style:{background:`radial-gradient(circle at center, ${h.glow} 0%, transparent 70%)`,animation:i?"none":"success-glow-pulse 0.6s ease-out forwards",borderRadius:"inherit"}}),c.jsx("svg",{viewBox:"0 0 24 24",className:"w-6 h-6 relative z-10",style:{animation:i?"none":"success-check 0.4s ease-out forwards",filter:i?"none":`drop-shadow(0 0 8px ${h.glow})`},children:c.jsx("path",{fill:"none",stroke:h.check,strokeWidth:"3",strokeLinecap:"round",strokeLinejoin:"round",d:"M5 13l4 4L19 7",style:{strokeDasharray:24,strokeDashoffset:i?0:24,animation:i?"none":"success-check-path 0.4s ease-out 0.1s forwards"}})})]})};function vk({feedback:e="ripple",onSuccess:t,onError:n,disabled:s=!1}={}){const[i,a]=m.useState(!1),[o,l]=m.useState(!1),[u,d]=m.useState(!1),[h,f]=m.useState(!1),g=m.useRef(null),y=m.useRef(null),v=ze(),T=m.useCallback(()=>{if(v){t?.();return}l(!0)},[v,t]),b=m.useCallback(()=>{if(v){n?.();return}d(!0)},[v,n]),I=m.useCallback(()=>{v||(f(!0),y.current?.trigger())},[v]),x=m.useCallback(()=>{l(!1),t?.()},[t]),w=m.useCallback(()=>{d(!1),n?.()},[n]),_=m.useCallback(()=>{f(!1)},[]),A=m.useCallback(P=>{if(!s){if(a(!0),e==="ripple"&&g.current){const O=P.currentTarget.getBoundingClientRect(),N=P.clientX-O.left,F=P.clientY-O.top;g.current.trigger(N,F)}e==="burst"&&I()}},[s,e,I]),k=m.useCallback(()=>{a(!1)},[]);return{handlers:{onMouseDown:A,onMouseUp:k,onMouseLeave:k,onTouchStart:A,onTouchEnd:k},isPressed:i,showSuccess:o,showError:u,showBurst:h,rippleRef:g,burstRef:y,triggerSuccess:T,triggerError:b,triggerBurst:I,handleSuccessComplete:x,handleErrorComplete:w,handleBurstComplete:_,reducedMotion:v}}function ze(){const[e,t]=m.useState(!1);return m.useEffect(()=>{if(typeof window>"u")return;const n="musclemap_motion_preference";localStorage.getItem(n);const s=window.matchMedia("(prefers-reduced-motion: reduce)"),i=()=>{const l=s.matches,u=localStorage.getItem(n);t(u==="reduced"?!0:u==="full"?!1:l)};i();const a=()=>i();s.addEventListener("change",a);const o=l=>{l.key===n&&i()};return window.addEventListener("storage",o),()=>{s.removeEventListener("change",a),window.removeEventListener("storage",o)}},[]),e}const Sk=({active:e,variant:t="primary"})=>{const[n,s]=m.useState([]),i=ze();m.useEffect(()=>{if(e&&!i){const o=Date.now();s(u=>[...u,o]);const l=setTimeout(()=>{s(u=>u.filter(d=>d!==o))},Mt.ripple);return()=>clearTimeout(l)}},[e,i]);const a=is[t]||is.primary;return c.jsx("div",{className:"absolute inset-0 pointer-events-none overflow-hidden",style:{borderRadius:"inherit"},children:n.map(o=>c.jsx("div",{className:"absolute inset-0 flex items-center justify-center",children:c.jsx("div",{className:"w-4 h-4 rounded-full",style:{backgroundColor:a,animation:`pulse-expand ${Mt.ripple}ms ease-out forwards`}})},o))})},Tk=({active:e,variant:t="primary"})=>{const n=ze(),s=Qo[t]||Qo.primary;return n?null:c.jsx("div",{className:"absolute inset-0 pointer-events-none transition-all duration-300",style:{borderRadius:"inherit",opacity:e?1:0,boxShadow:e?`0 0 20px 4px ${s}, 0 0 40px 8px ${s.replace(/[\d.]+\)$/,"0.15)")}`:"none",transform:e?"scale(1.02)":"scale(1)"}})},Bb=m.forwardRef(({active:e,variant:t="primary",onComplete:n},s)=>{const i=m.useRef(null),a=m.useRef([]),o=m.useRef(null),l=ze(),u={glass:["#ffffff","#0066ff","#00aaff"],primary:["#0066ff","#00aaff","#ffffff"],pulse:["#00ff88","#22c55e","#10b981"],ghost:["#ffffff","#94a3b8","#64748b"]};m.useImperativeHandle(s,()=>({trigger:()=>{l||d()}}));const d=m.useCallback(()=>{const f=i.current;if(!f)return;const g=f.getBoundingClientRect(),y=g.width/2,v=g.height/2,T=u[t]||u.primary,b=25;for(let I=0;I<b;I++){const x=Math.PI*2*I/b+(Math.random()-.5)*.5,w=Math.random()*3+2,_=T[Math.floor(Math.random()*T.length)];a.current.push({x:y,y:v,vx:Math.cos(x)*w,vy:Math.sin(x)*w,size:Math.random()*4+2,color:_,opacity:1,decay:Math.random()*.02+.015,startTime:performance.now()})}o.current||h(),setTimeout(()=>{n?.()},Mt.burst)},[t,n,l]),h=m.useCallback(()=>{const f=i.current;if(!f)return;const g=f.getContext("2d");g.clearRect(0,0,f.width,f.height),a.current=a.current.filter(y=>(y.x+=y.vx,y.y+=y.vy,y.vx*=.96,y.vy*=.96,y.vy+=.1,y.opacity-=y.decay,y.opacity<=0?!1:(g.beginPath(),g.arc(y.x,y.y,y.size,0,Math.PI*2),g.fillStyle=y.color,g.globalAlpha=y.opacity,g.fill(),g.globalAlpha=1,!0))),a.current.length>0?o.current=requestAnimationFrame(h):o.current=null},[]);return m.useEffect(()=>{const f=i.current;if(!f)return;const g=()=>{const v=f.parentElement?.getBoundingClientRect();v&&(f.width=v.width,f.height=v.height)};g();const y=new ResizeObserver(g);return f.parentElement&&y.observe(f.parentElement),()=>{y.disconnect(),o.current&&cancelAnimationFrame(o.current)}},[]),m.useEffect(()=>{e&&!l&&d()},[e,d,l]),c.jsx("canvas",{ref:i,className:"absolute inset-0 pointer-events-none",style:{borderRadius:"inherit"}})});Bb.displayName="BurstEffect";if(typeof document<"u"){const e="button-effects-keyframes";if(!document.getElementById(e)){const t=document.createElement("style");t.id=e,t.textContent=`
      @keyframes success-check {
        0% {
          transform: scale(0);
          opacity: 0;
        }
        50% {
          transform: scale(1.2);
          opacity: 1;
        }
        100% {
          transform: scale(1);
          opacity: 1;
        }
      }

      @keyframes success-check-path {
        to {
          stroke-dashoffset: 0;
        }
      }

      @keyframes success-glow {
        0% {
          opacity: 0;
        }
        30% {
          opacity: 1;
        }
        100% {
          opacity: 0;
        }
      }

      @keyframes success-glow-pulse {
        0% {
          transform: scale(0.8);
          opacity: 0;
        }
        30% {
          transform: scale(1);
          opacity: 1;
        }
        100% {
          transform: scale(1.2);
          opacity: 0;
        }
      }

      @keyframes pulse-expand {
        0% {
          transform: scale(1);
          opacity: 0.8;
        }
        100% {
          transform: scale(20);
          opacity: 0;
        }
      }

      @keyframes error-shake {
        0%, 100% {
          transform: translateX(0);
        }
        10%, 30%, 50%, 70%, 90% {
          transform: translateX(-4px);
        }
        20%, 40%, 60%, 80% {
          transform: translateX(4px);
        }
      }

      @keyframes error-flash {
        0%, 100% {
          box-shadow: none;
        }
        50% {
          box-shadow: 0 0 0 2px rgba(239, 68, 68, 0.5), 0 0 12px rgba(239, 68, 68, 0.4);
        }
      }

      @keyframes success-intense-glow {
        0% {
          opacity: 0;
          transform: scale(0.8);
        }
        30% {
          opacity: 1;
          transform: scale(1.1);
        }
        60% {
          opacity: 0.8;
          transform: scale(1);
        }
        100% {
          opacity: 0;
          transform: scale(1.2);
        }
      }

      @keyframes success-ring-pulse {
        0% {
          opacity: 0;
          transform: scale(0.95);
        }
        30% {
          opacity: 1;
          transform: scale(1);
        }
        100% {
          opacity: 0;
          transform: scale(1.05);
        }
      }

      @keyframes loading-breathe {
        0%, 100% {
          opacity: 0.8;
          transform: scale(1);
        }
        50% {
          opacity: 1;
          transform: scale(1.02);
        }
      }

      @keyframes spinner-pulse {
        0%, 100% {
          opacity: 0.9;
          filter: drop-shadow(0 0 2px currentColor);
        }
        50% {
          opacity: 1;
          filter: drop-shadow(0 0 6px currentColor);
        }
      }

      @media (prefers-reduced-motion: reduce) {
        @keyframes success-check {
          0%, 100% {
            transform: scale(1);
            opacity: 1;
          }
        }
        @keyframes success-check-path {
          0%, 100% {
            stroke-dashoffset: 0;
          }
        }
        @keyframes success-glow {
          0%, 100% {
            opacity: 0;
          }
        }
        @keyframes success-glow-pulse {
          0%, 100% {
            transform: scale(1);
            opacity: 0;
          }
        }
        @keyframes pulse-expand {
          0%, 100% {
            transform: scale(1);
            opacity: 0;
          }
        }
        @keyframes error-shake {
          0%, 100% {
            transform: translateX(0);
          }
        }
        @keyframes error-flash {
          0%, 100% {
            box-shadow: none;
          }
        }
        @keyframes success-intense-glow {
          0%, 100% {
            opacity: 0;
            transform: scale(1);
          }
        }
        @keyframes success-ring-pulse {
          0%, 100% {
            opacity: 0;
            transform: scale(1);
          }
        }
        @keyframes loading-breathe {
          0%, 100% {
            opacity: 1;
            transform: scale(1);
          }
        }
        @keyframes spinner-pulse {
          0%, 100% {
            opacity: 1;
            filter: none;
          }
        }
      }
    `,document.head.appendChild(t)}}const Fb=m.forwardRef(({color:e,duration:t,className:n=""},s)=>{const i=m.useRef(null),a=m.useRef([]),o=m.useRef(null),[l,u]=m.useState(!1);m.useEffect(()=>{if(typeof window>"u")return;const f=window.matchMedia("(prefers-reduced-motion: reduce)");u(f.matches);const g=y=>u(y.matches);return f.addEventListener("change",g),()=>f.removeEventListener("change",g)},[]),m.useImperativeHandle(s,()=>({trigger:(f,g)=>{if(l)return;const y=i.current;if(!y)return;const v=y.getBoundingClientRect(),T=f-v.left,b=g-v.top;h(T,b)}}));const d=m.useCallback(()=>{const f=i.current;if(!f)return;const g=f.getContext("2d"),y=performance.now();g.clearRect(0,0,f.width,f.height),a.current=a.current.filter(v=>{const T=y-v.startTime,b=Math.min(T/t,1);if(b>=1)return!1;const I=1-Math.pow(1-b,3),x=v.maxRadius*I,w=1-b;g.beginPath(),g.arc(v.x,v.y,x,0,Math.PI*2);const _=e.match(/rgba?\(([^)]+)\)/);if(_){const A=_[1].split(",").map(k=>k.trim());if(A.length>=4){const k=parseFloat(A[3]);g.fillStyle=`rgba(${A[0]}, ${A[1]}, ${A[2]}, ${w*k})`}else g.fillStyle=`rgba(${A[0]}, ${A[1]}, ${A[2]}, ${w*.4})`}else g.fillStyle=e;return g.fill(),!0}),a.current.length>0?o.current=requestAnimationFrame(d):o.current=null},[e,t]),h=m.useCallback((f,g)=>{const y=i.current;if(!y)return;const v=y.getBoundingClientRect(),T=Math.sqrt(Math.pow(Math.max(f,v.width-f),2)+Math.pow(Math.max(g,v.height-g),2));a.current.push({x:f,y:g,startTime:performance.now(),maxRadius:T}),o.current||d()},[d]);return m.useEffect(()=>{const f=i.current;if(!f)return;const g=()=>{const v=f.parentElement?.getBoundingClientRect();v&&(f.width=v.width,f.height=v.height)};g();const y=new ResizeObserver(g);return f.parentElement&&y.observe(f.parentElement),()=>{y.disconnect(),o.current&&cancelAnimationFrame(o.current)}},[]),c.jsx("canvas",{ref:i,className:`absolute inset-0 pointer-events-none ${n}`,style:{borderRadius:"inherit"},"aria-hidden":"true"})});Fb.displayName="RippleCanvas";const as={achievement:{particleCount:100,spread:360,colors:["#0066ff","#00aaff","#ff3366","#ffd700","#22c55e"],duration:3e3,gravity:.15,velocityMultiplier:1.2,shapes:["circle","rect","star"],glow:!0},workout:{particleCount:60,spread:180,colors:["#22c55e","#10b981","#34d399","#6ee7b7"],duration:2500,gravity:.12,velocityMultiplier:1,shapes:["circle","rect"],glow:!0},levelup:{particleCount:150,spread:360,colors:["#0066ff","#8b5cf6","#d946ef","#f59e0b","#ffd700"],duration:4e3,gravity:.1,velocityMultiplier:1.5,shapes:["circle","rect","star","diamond"],glow:!0},subtle:{particleCount:30,spread:120,colors:["#0066ff","#00aaff","#94a3b8"],duration:2e3,gravity:.18,velocityMultiplier:.7,shapes:["circle"],glow:!1}};class td{constructor(t,n,s){this.x=t,this.y=n,this.color=s.color,this.size=Math.random()*8+4,this.shape=s.shape,this.glow=s.glow;const i=s.spread/360*Math.PI*2,a=Math.random()*i-i/2-Math.PI/2,o=(Math.random()*8+4)*s.velocityMultiplier;this.vx=Math.cos(a)*o,this.vy=Math.sin(a)*o,this.gravity=s.gravity,this.friction=.99,this.rotation=Math.random()*Math.PI*2,this.rotationSpeed=(Math.random()-.5)*.3,this.opacity=1,this.decay=Math.random()*.015+.01,this.aspect=Math.random()*.5+.5}update(){return this.vy+=this.gravity,this.vx*=this.friction,this.vy*=this.friction,this.x+=this.vx,this.y+=this.vy,this.rotation+=this.rotationSpeed,this.opacity-=this.decay,this.opacity>0}draw(t){switch(t.save(),t.translate(this.x,this.y),t.rotate(this.rotation),t.globalAlpha=this.opacity,this.glow&&(t.shadowColor=this.color,t.shadowBlur=this.size*2),t.fillStyle=this.color,this.shape){case"rect":t.fillRect(-this.size/2,-this.size*this.aspect/2,this.size,this.size*this.aspect);break;case"star":this.drawStar(t,this.size/2);break;case"diamond":t.beginPath(),t.moveTo(0,-this.size/2),t.lineTo(this.size/3,0),t.lineTo(0,this.size/2),t.lineTo(-this.size/3,0),t.closePath(),t.fill();break;case"circle":default:t.beginPath(),t.arc(0,0,this.size/2,0,Math.PI*2),t.fill();break}t.restore()}drawStar(t,n){const i=n,a=n/2;t.beginPath();for(let o=0;o<5*2;o++){const l=o%2===0?i:a,u=o*Math.PI/5-Math.PI/2,d=Math.cos(u)*l,h=Math.sin(u)*l;o===0?t.moveTo(d,h):t.lineTo(d,h)}t.closePath(),t.fill()}}const qb=m.createContext(null);Tc.node.isRequired;function Wb(){const e=m.useRef(null),t=m.useRef([]),n=m.useRef(null),s=ze();m.useEffect(()=>{let o=document.getElementById("standalone-confetti-canvas");o||(o=document.createElement("canvas"),o.id="standalone-confetti-canvas",o.style.cssText=`
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        pointer-events: none;
        z-index: 9999;
      `,o.width=window.innerWidth,o.height=window.innerHeight,document.body.appendChild(o)),e.current=o;const l=()=>{e.current&&(e.current.width=window.innerWidth,e.current.height=window.innerHeight)};return window.addEventListener("resize",l),()=>{window.removeEventListener("resize",l)}},[]);const i=m.useCallback(()=>{const o=e.current;if(!o)return;const l=o.getContext("2d");l.clearRect(0,0,o.width,o.height),t.current=t.current.filter(u=>{const d=u.update();return d&&u.draw(l),d}),t.current.length>0?n.current=requestAnimationFrame(i):n.current=null},[]);return{fireConfetti:m.useCallback(({preset:o="achievement",origin:l={x:.5,y:.5},colors:u,particleCount:d,spread:h,duration:f}={})=>{if(s)return;const g=e.current;if(!g)return;const v={...as[o]||as.achievement,...u&&{colors:u},...d!==void 0&&{particleCount:d},...h!==void 0&&{spread:h},...f!==void 0&&{duration:f}},T=l.x*g.width,b=l.y*g.height;for(let I=0;I<v.particleCount;I++){const x=v.colors[Math.floor(Math.random()*v.colors.length)],w=v.shapes[Math.floor(Math.random()*v.shapes.length)];t.current.push(new td(T,b,{color:x,shape:w,spread:v.spread,gravity:v.gravity,velocityMultiplier:v.velocityMultiplier,glow:v.glow}))}n.current||i(),setTimeout(()=>{t.current=[],n.current&&(cancelAnimationFrame(n.current),n.current=null),g.getContext("2d").clearRect(0,0,g.width,g.height)},v.duration)},[s,i])}}function bk(){const e=m.useContext(qb),t=Wb();return e||t}const zb=m.forwardRef(function({className:t=""},n){const s=m.useRef(null),i=m.useRef([]),a=m.useRef(null),o=ze();m.useEffect(()=>{const u=s.current;if(!u)return;const d=()=>{u.width=window.innerWidth,u.height=window.innerHeight};return d(),window.addEventListener("resize",d),()=>{window.removeEventListener("resize",d),a.current&&cancelAnimationFrame(a.current)}},[]);const l=m.useCallback(()=>{const u=s.current;if(!u)return;const d=u.getContext("2d");d.clearRect(0,0,u.width,u.height),i.current=i.current.filter(h=>{const f=h.update();return f&&h.draw(d),f}),i.current.length>0?a.current=requestAnimationFrame(l):a.current=null},[]);return m.useImperativeHandle(n,()=>({fire:({preset:u="achievement",origin:d={x:.5,y:.5},colors:h,particleCount:f,spread:g,duration:y}={})=>{if(o)return;const v=s.current;if(!v)return;const b={...as[u]||as.achievement,...h&&{colors:h},...f!==void 0&&{particleCount:f},...g!==void 0&&{spread:g},...y!==void 0&&{duration:y}},I=d.x*v.width,x=d.y*v.height;for(let w=0;w<b.particleCount;w++){const _=b.colors[Math.floor(Math.random()*b.colors.length)],A=b.shapes[Math.floor(Math.random()*b.shapes.length)];i.current.push(new td(I,x,{color:_,shape:A,spread:b.spread,gravity:b.gravity,velocityMultiplier:b.velocityMultiplier,glow:b.glow}))}a.current||l(),setTimeout(()=>{i.current=[],a.current&&(cancelAnimationFrame(a.current),a.current=null),v.getContext("2d").clearRect(0,0,v.width,v.height)},b.duration)}}),[o,l]),c.jsx("canvas",{ref:s,className:`fixed inset-0 pointer-events-none ${t}`,style:{zIndex:9999}})});zb.propTypes={className:Tc.string};function Bn(){return typeof navigator>"u"?null:navigator.connection||navigator.mozConnection||navigator.webkitConnection||null}function Xo(e){if(typeof navigator>"u"||!navigator.onLine)return"offline";if(!e)return"fast";const{effectiveType:t,downlink:n,rtt:s,saveData:i}=e;if(i)return"slow";switch(t){case"4g":return n&&n<1||s&&s>200?"medium":"fast";case"3g":return"medium";case"2g":case"slow-2g":return"slow";default:return n&&n>=5?"fast":n&&n>=1?"medium":"slow"}}function Hb(){if(typeof navigator>"u")return"high";let e=0;const t=navigator.hardwareConcurrency||4;t>=8?e+=3:t>=4?e+=2:e+=1;const n=navigator.deviceMemory||4;return n>=8?e+=3:n>=4?e+=2:e+=1,/iPhone|iPad|iPod|Android/i.test(navigator.userAgent)&&(e-=1),e>=5?"high":e>=3?"medium":"low"}async function Gb(){if(typeof navigator>"u"||!navigator.getBattery)return!1;try{const e=await navigator.getBattery();return e.level<.2&&!e.charging}catch{return!1}}function Yb(){const[e,t]=m.useState(()=>{const f=Bn();return Xo(f)}),[n]=m.useState(()=>Hb()),[s,i]=m.useState(()=>typeof navigator<"u"?navigator.onLine:!0),[a,o]=m.useState(!1),[l]=m.useState(()=>typeof window<"u"?window.matchMedia("(prefers-reduced-motion: reduce)").matches:!1),u=m.useCallback(()=>{const f=Bn();t(Xo(f))},[]),d=m.useCallback(()=>{i(navigator.onLine),u()},[u]);return m.useEffect(()=>{window.addEventListener("online",d),window.addEventListener("offline",d);const f=Bn();return f&&f.addEventListener("change",u),Gb().then(o),navigator.getBattery&&navigator.getBattery().then(g=>{const y=()=>{o(g.level<.2&&!g.charging)};g.addEventListener("levelchange",y),g.addEventListener("chargingchange",y)}).catch(()=>{}),()=>{window.removeEventListener("online",d),window.removeEventListener("offline",d),f&&f.removeEventListener("change",u)}},[u,d]),m.useMemo(()=>{const y=Bn()?.saveData||!1||e==="slow"||e==="offline"||a,T={fast:5e3,medium:15e3,slow:6e4,offline:0}[e];let b="full";e==="offline"||n==="low"?b="placeholder":(e==="slow"||n==="medium"||y)&&(b="static");let I="high";l?I="disabled":a||e==="slow"?I="low":(e==="medium"||n==="medium")&&(I="medium");let x="original";return e==="slow"||y?x="thumbnail":e==="medium"&&(x="compressed"),{connectionTier:e,deviceTier:n,isOnline:s,shouldReduceData:y,shouldReduceMotion:l,isLowPowerMode:a,pollingInterval:T,visualizationMode:b,animationLevel:I,imageQuality:x,prefetchEnabled:e==="fast"&&!y,autoplayEnabled:e==="fast"&&!y&&!a}},[e,n,s,a,l])}const vn=typeof window<"u"?m.useLayoutEffect:m.useEffect;function Zo(e){if(e!==void 0)switch(typeof e){case"number":return e;case"string":{if(e.endsWith("px"))return parseFloat(e);break}}}function Kb({box:e,defaultHeight:t,defaultWidth:n,disabled:s,element:i,mode:a,style:o}){const{styleHeight:l,styleWidth:u}=m.useMemo(()=>({styleHeight:Zo(o?.height),styleWidth:Zo(o?.width)}),[o?.height,o?.width]),[d,h]=m.useState({height:t,width:n}),f=s||l!==void 0||a==="only-width"||l!==void 0&&u!==void 0;return vn(()=>{if(i===null||f)return;const g=new ResizeObserver(y=>{for(const v of y){const{contentRect:T,target:b}=v;i===b&&h(I=>I.height===T.height&&I.width===T.width?I:{height:T.height,width:T.width})}});return g.observe(i,{box:e}),()=>{g?.unobserve(i)}},[e,f,i,l,u]),m.useMemo(()=>({height:l??d.height,width:u??d.width}),[d,l,u])}function Qb(e){const t=m.useRef(()=>{throw new Error("Cannot call during render.")});return vn(()=>{t.current=e},[e]),m.useCallback(n=>t.current?.(n),[t])}function Js({containerElement:e,direction:t,isRtl:n,scrollOffset:s}){return s}function Je(e,t="Assertion error"){if(!e)throw Error(t)}function an(e,t){if(e===t)return!0;if(!!e!=!!t||(Je(e!==void 0),Je(t!==void 0),Object.keys(e).length!==Object.keys(t).length))return!1;for(const n in e)if(!Object.is(t[n],e[n]))return!1;return!0}function nd({cachedBounds:e,itemCount:t,itemSize:n}){if(t===0)return 0;if(typeof n=="number")return t*n;{const s=e.get(e.size===0?0:e.size-1);Je(s!==void 0,"Unexpected bounds cache miss");const i=(s.scrollOffset+s.size)/e.size;return t*i}}function Jb({align:e,cachedBounds:t,index:n,itemCount:s,itemSize:i,containerScrollOffset:a,containerSize:o}){if(n<0||n>=s)throw RangeError(`Invalid index specified: ${n}`,{cause:`Index ${n} is not within the range of 0 - ${s-1}`});const l=nd({cachedBounds:t,itemCount:s,itemSize:i}),u=t.get(n),d=Math.max(0,Math.min(l-o,u.scrollOffset)),h=Math.max(0,u.scrollOffset-o+u.size);switch(e==="smart"&&(a>=h&&a<=d?e="auto":e="center"),e){case"start":return d;case"end":return h;case"center":return u.scrollOffset<=o/2?0:u.scrollOffset+u.size/2>=l-o/2?l-o:u.scrollOffset+u.size/2-o/2;case"auto":default:return a>=h&&a<=d?a:a<h?h:d}}function Xs({cachedBounds:e,containerScrollOffset:t,containerSize:n,itemCount:s,overscanCount:i}){const a=s-1;let o=0,l=-1,u=0,d=-1,h=0;for(;h<a;){const f=e.get(h);if(f.scrollOffset+f.size>t)break;h++}for(o=h,u=Math.max(0,o-i);h<a;){const f=e.get(h);if(f.scrollOffset+f.size>=t+n)break;h++}return l=Math.min(a,h),d=Math.min(s-1,l+i),o<0&&(o=0,l=-1,u=0,d=-1),{startIndexVisible:o,stopIndexVisible:l,startIndexOverscan:u,stopIndexOverscan:d}}function Xb({itemCount:e,itemProps:t,itemSize:n}){const s=new Map;return{get(i){for(Je(i<e,`Invalid index ${i}`);s.size-1<i;){const o=s.size;let l;switch(typeof n){case"function":{l=n(o,t);break}case"number":{l=n;break}}if(o===0)s.set(o,{size:l,scrollOffset:0});else{const u=s.get(o-1);Je(u!==void 0,`Unexpected bounds cache miss for index ${i}`),s.set(o,{scrollOffset:u.scrollOffset+u.size,size:l})}}const a=s.get(i);return Je(a!==void 0,`Unexpected bounds cache miss for index ${i}`),a},set(i,a){s.set(i,a)},get size(){return s.size}}}function Zb({itemCount:e,itemProps:t,itemSize:n}){return m.useMemo(()=>Xb({itemCount:e,itemProps:t,itemSize:n}),[e,t,n])}function ew({containerSize:e,itemSize:t}){let n;switch(typeof t){case"string":{Je(t.endsWith("%"),`Invalid item size: "${t}"; string values must be percentages (e.g. "100%")`),Je(e!==void 0,"Container size must be defined if a percentage item size is specified"),n=e*parseInt(t)/100;break}default:{n=t;break}}return n}function tw({containerElement:e,containerStyle:t,defaultContainerSize:n=0,direction:s,isRtl:i=!1,itemCount:a,itemProps:o,itemSize:l,onResize:u,overscanCount:d}){const{height:h=n,width:f=n}=Kb({defaultHeight:n,defaultWidth:void 0,element:e,mode:"only-height",style:t}),g=m.useRef({height:0,width:0}),y=h,v=ew({containerSize:y,itemSize:l});m.useLayoutEffect(()=>{if(typeof u=="function"){const N=g.current;(N.height!==h||N.width!==f)&&(u({height:h,width:f},{...N}),N.height=h,N.width=f)}},[h,u,f]);const T=Zb({itemCount:a,itemProps:o,itemSize:v}),b=m.useCallback(N=>T.get(N),[T]),[I,x]=m.useState(()=>Xs({cachedBounds:T,containerScrollOffset:0,containerSize:y,itemCount:a,overscanCount:d})),{startIndexVisible:w,startIndexOverscan:_,stopIndexVisible:A,stopIndexOverscan:k}={startIndexVisible:Math.min(a-1,I.startIndexVisible),startIndexOverscan:Math.min(a-1,I.startIndexOverscan),stopIndexVisible:Math.min(a-1,I.stopIndexVisible),stopIndexOverscan:Math.min(a-1,I.stopIndexOverscan)},R=m.useCallback(()=>nd({cachedBounds:T,itemCount:a,itemSize:v}),[T,a,v]),P=m.useCallback(N=>{const F=Js({containerElement:e,direction:s,isRtl:i,scrollOffset:N});return Xs({cachedBounds:T,containerScrollOffset:F,containerSize:y,itemCount:a,overscanCount:d})},[T,e,y,s,i,a,d]);vn(()=>{const N=e?.scrollTop??0;x(P(N))},[e,s,P]),vn(()=>{if(!e)return;const N=()=>{x(F=>{const{scrollLeft:Z,scrollTop:z}=e,H=Js({containerElement:e,direction:s,isRtl:i,scrollOffset:z}),Q=Xs({cachedBounds:T,containerScrollOffset:H,containerSize:y,itemCount:a,overscanCount:d});return an(Q,F)?F:Q})};return e.addEventListener("scroll",N),()=>{e.removeEventListener("scroll",N)}},[T,e,y,s,a,d]);const O=Qb(({align:N="auto",containerScrollOffset:F,index:Z})=>{let z=Jb({align:N,cachedBounds:T,containerScrollOffset:F,containerSize:y,index:Z,itemCount:a,itemSize:v});if(e){if(z=Js({containerElement:e,direction:s,isRtl:i,scrollOffset:z}),typeof e.scrollTo!="function"){const H=P(z);an(I,H)||x(H)}return z}});return{getCellBounds:b,getEstimatedSize:R,scrollToIndex:O,startIndexOverscan:_,startIndexVisible:w,stopIndexOverscan:k,stopIndexVisible:A}}function nw(e){return m.useMemo(()=>e,Object.values(e))}function sw(e,t){const{ariaAttributes:n,style:s,...i}=e,{ariaAttributes:a,style:o,...l}=t;return an(n,a)&&an(s,o)&&an(i,l)}function rw(e){return e!=null&&typeof e=="object"&&"getAverageRowHeight"in e&&typeof e.getAverageRowHeight=="function"}const iw="data-react-window-index";function aw({children:e,className:t,defaultHeight:n=0,listRef:s,onResize:i,onRowsRendered:a,overscanCount:o=3,rowComponent:l,rowCount:u,rowHeight:d,rowProps:h,tagName:f="div",style:g,...y}){const v=nw(h),T=m.useMemo(()=>m.memo(l,sw),[l]),[b,I]=m.useState(null),x=rw(d),w=m.useMemo(()=>x?z=>d.getRowHeight(z)??d.getAverageRowHeight():d,[x,d]),{getCellBounds:_,getEstimatedSize:A,scrollToIndex:k,startIndexOverscan:R,startIndexVisible:P,stopIndexOverscan:O,stopIndexVisible:N}=tw({containerElement:b,containerStyle:g,defaultContainerSize:n,direction:"vertical",itemCount:u,itemProps:v,itemSize:w,onResize:i,overscanCount:o});m.useImperativeHandle(s,()=>({get element(){return b},scrollToRow({align:z="auto",behavior:H="auto",index:Q}){const _e=k({align:z,containerScrollOffset:b?.scrollTop??0,index:Q});typeof b?.scrollTo=="function"&&b.scrollTo({behavior:H,top:_e})}}),[b,k]),vn(()=>{if(!b)return;const z=Array.from(b.children).filter((H,Q)=>{if(H.hasAttribute("aria-hidden"))return!1;const _e=`${R+Q}`;return H.setAttribute(iw,_e),!0});if(x)return d.observeRowElements(z)},[b,x,d,R,O]),m.useEffect(()=>{R>=0&&O>=0&&a&&a({startIndex:P,stopIndex:N},{startIndex:R,stopIndex:O})},[a,R,P,O,N]);const F=m.useMemo(()=>{const z=[];if(u>0)for(let H=R;H<=O;H++){const Q=_(H);z.push(m.createElement(T,{...v,ariaAttributes:{"aria-posinset":H+1,"aria-setsize":u,role:"listitem"},key:H,index:H,style:{position:"absolute",left:0,transform:`translateY(${Q.scrollOffset}px)`,height:x?void 0:Q.size,width:"100%"}}))}return z},[T,_,x,u,v,R,O]),Z=c.jsx("div",{"aria-hidden":!0,style:{height:A(),width:"100%",zIndex:-1}});return m.createElement(f,{role:"list",...y,className:t,ref:I,style:{position:"relative",maxHeight:"100%",flexGrow:1,overflowY:"auto",...g}},F,e,Z)}m.forwardRef(function({items:t=[],itemHeight:n=72,renderItem:s,height:i=400,width:a="100%",onItemsRendered:o,emptyState:l,loadingState:u,isLoading:d=!1,className:h="",overscanCount:f,...g},y){const v=m.useRef(null),{deviceTier:T}=Yb(),b=m.useMemo(()=>{if(f!==void 0)return f;switch(T){case"low-end":return 1;case"mid-tier":return 3;case"high-end":default:return 5}},[T,f]),I=m.useCallback(({index:w,style:_})=>{const A=t[w];return s(A,w,_)},[t,s]),x=m.useCallback(w=>{if(!v.current)return;const{scrollOffset:_}=v.current.state,A=Math.floor(i/n);switch(w.key){case"ArrowDown":w.preventDefault(),v.current.scrollTo(_+n);break;case"ArrowUp":w.preventDefault(),v.current.scrollTo(Math.max(0,_-n));break;case"PageDown":w.preventDefault(),v.current.scrollTo(_+A*n);break;case"PageUp":w.preventDefault(),v.current.scrollTo(Math.max(0,_-A*n));break;case"Home":w.preventDefault(),v.current.scrollTo(0);break;case"End":w.preventDefault(),v.current.scrollToItem(t.length-1);break}},[i,n,t.length]);return d&&u?u:t.length===0&&l?l:t.length===0?null:c.jsx("div",{className:`virtual-list-container ${h}`,onKeyDown:x,tabIndex:0,role:"listbox","aria-label":"Scrollable list",children:c.jsx(aw,{ref:w=>{v.current=w,y&&(typeof y=="function"?y(w):y.current=w)},height:i,width:a,itemCount:t.length,itemSize:n,overscanCount:b,onItemsRendered:o,...g,children:I})})});new Date().toISOString();const ow={...xm,async get(e){return{data:await S(e,{method:"GET"})}},async post(e,t){return{data:await S(e,{method:"POST",body:t})}},async put(e,t){return{data:await S(e,{method:"PUT",body:t})}},async delete(e){return{data:await S(e,{method:"DELETE"})}}},cw=m.createContext(null);function lw({children:e,builtInPlugins:t=[]}){const n=Ot(),s=xb(),i=Ue(),a=m.useMemo(()=>({api:ow,navigate:n,toast:s,graphql:null}),[n,s]);m.useEffect(()=>(t.length>0&&Sb(t,a).then(l=>{l.filter(d=>!d.success).length>0}),ae.emit("app:ready",{timestamp:Date.now()}),()=>{for(const[l]of i.plugins)Yo(l)}),[]),m.useEffect(()=>{const l=()=>{ae.emit("route:changed",{path:window.location.pathname,search:window.location.search,hash:window.location.hash})};return window.addEventListener("popstate",l),()=>{window.removeEventListener("popstate",l)}},[]);const o=m.useMemo(()=>({registry:i,eventBus:ae,on:ae.on.bind(ae),emit:ae.emit.bind(ae),hookRegistry:le,addFilter:le.addFilter.bind(le),addAction:le.addAction.bind(le),applyFilters:le.applyFilters.bind(le),getActions:le.getActions.bind(le),services:a,loadPlugin:(l,u)=>Gu(l,u,a),unloadPlugin:Yo}),[i,a]);return c.jsx(cw.Provider,{value:o,children:e})}const He={id:"default",name:"MuscleMap Default",colors:{"brand-primary":"#0066FF","brand-secondary":"#00D4FF","brand-accent":"#FF6B00","bg-primary":"#0a0a0f","bg-secondary":"#12121a","bg-tertiary":"#1a1a25","bg-card":"rgba(255, 255, 255, 0.03)","bg-card-hover":"rgba(255, 255, 255, 0.06)","text-primary":"#ffffff","text-secondary":"rgba(255, 255, 255, 0.7)","text-tertiary":"rgba(255, 255, 255, 0.5)","text-muted":"rgba(255, 255, 255, 0.3)","border-primary":"rgba(255, 255, 255, 0.1)","border-secondary":"rgba(255, 255, 255, 0.05)","border-focus":"#0066FF",success:"#00FF88",warning:"#FFB800",error:"#FF4757",info:"#00D4FF","muscle-inactive":"#2a2a35","muscle-low":"#3d5a80","muscle-medium":"#ee6c4d","muscle-high":"#e63946","glass-bg":"rgba(255, 255, 255, 0.03)","glass-border":"rgba(255, 255, 255, 0.08)","glass-shadow":"rgba(0, 0, 0, 0.3)"},fonts:{heading:"Bebas Neue, sans-serif",body:"Inter, system-ui, sans-serif",mono:"JetBrains Mono, monospace"},spacing:{xs:"0.25rem",sm:"0.5rem",md:"1rem",lg:"1.5rem",xl:"2rem","2xl":"3rem"},radius:{sm:"0.375rem",md:"0.5rem",lg:"0.75rem",xl:"1rem",full:"9999px"}},sd=m.createContext(null);function ec(e){const t=document.documentElement;e.colors&&Object.entries(e.colors).forEach(([n,s])=>{t.style.setProperty(`--${n}`,s)}),e.fonts&&Object.entries(e.fonts).forEach(([n,s])=>{t.style.setProperty(`--font-${n}`,s)}),e.spacing&&Object.entries(e.spacing).forEach(([n,s])=>{t.style.setProperty(`--spacing-${n}`,s)}),e.radius&&Object.entries(e.radius).forEach(([n,s])=>{t.style.setProperty(`--radius-${n}`,s)}),document.body.setAttribute("data-theme",e.id)}function uw({children:e}){const t=db(),n=ub(),s=Ue(o=>o.setActiveTheme),i=m.useMemo(()=>t?{...He,...t,colors:{...He.colors,...t.colors},fonts:{...He.fonts,...t.fonts},spacing:{...He.spacing,...t.spacing},radius:{...He.radius,...t.radius}}:He,[t]);m.useEffect(()=>{ec(i),ae.emit("theme:changed",{themeId:i.id,theme:i})},[i]),m.useEffect(()=>{ec(He)},[]);const a=m.useMemo(()=>({currentTheme:i,themes:[He,...n],setTheme:s,resetTheme:()=>s(null),getColor:o=>i.colors?.[o],getFont:o=>i.fonts?.[o]}),[i,n,s]);return c.jsx(sd.Provider,{value:a,children:e})}function dw(){const e=m.useContext(sd);if(!e)throw new Error("usePluginTheme must be used within a PluginThemeProvider");return e}function mw({theme:e,isActive:t,onClick:n}){const s=e.colors||{};return c.jsxs("button",{onClick:n,className:`
        relative p-3 rounded-xl border transition-all
        ${t?"border-blue-500 ring-2 ring-blue-500/30":"border-white/10 hover:border-white/20"}
      `,style:{backgroundColor:s["bg-primary"]||"#0a0a0f"},children:[c.jsxs("div",{className:"flex gap-1 mb-2",children:[c.jsx("div",{className:"w-4 h-4 rounded-full",style:{backgroundColor:s["brand-primary"]||"#0066FF"}}),c.jsx("div",{className:"w-4 h-4 rounded-full",style:{backgroundColor:s["brand-secondary"]||"#00D4FF"}}),c.jsx("div",{className:"w-4 h-4 rounded-full",style:{backgroundColor:s.success||"#00FF88"}}),c.jsx("div",{className:"w-4 h-4 rounded-full",style:{backgroundColor:s.error||"#FF4757"}})]}),c.jsx("p",{className:"text-xs font-medium truncate",style:{color:s["text-primary"]||"#ffffff"},children:e.name}),t&&c.jsx("div",{className:"absolute top-1 right-1 w-2 h-2 bg-blue-500 rounded-full"})]})}function wk({className:e=""}){const{themes:t,currentTheme:n,setTheme:s,resetTheme:i}=dw();return c.jsx("div",{className:`grid grid-cols-2 sm:grid-cols-3 gap-3 ${e}`,children:t.map(a=>c.jsx(mw,{theme:a,isActive:n.id===a.id,onClick:()=>a.id==="default"?i():s(a.id)},a.id))})}const hw=m.createContext(null);function pw({children:e}){const t=et();m.useEffect(()=>{ch(t.pathname,{search:t.search,hash:t.hash})},[t]);const n=m.useMemo(()=>({getTrace:sh,createTrace:Tn,startSpan:cs,endSpan:ls,addSpanAttributes:ah,traceInteraction:lh,flush:fr}),[]);return c.jsx(hw.Provider,{value:n,children:e})}let tc;try{tc=require("./TransitionProvider").useTransitionContext}catch{tc=()=>null}const fw=300,gw=m.createContext(null);function yw({isVisible:e,progress:t=0}){return c.jsx(Wm,{isVisible:e,progress:t})}class vw{constructor(){this.elements=new Map,this.listeners=new Set}register(t,n,s=100){this.elements.set(t,{element:n,zIndex:s,timestamp:Date.now()}),this.notifyListeners()}unregister(t){this.elements.delete(t),this.notifyListeners()}get(t){return this.elements.get(t)}has(t){return this.elements.has(t)}getAll(){return new Map(this.elements)}subscribe(t){return this.listeners.add(t),()=>this.listeners.delete(t)}notifyListeners(){this.listeners.forEach(t=>t(this.getAll()))}clear(){this.elements.clear(),this.notifyListeners()}}function Sw({children:e,defaultDuration:t=fw,showProgressBar:n=!0}){const s=et(),i=Ot(),a=vc(),[o,l]=m.useState(!1),[u,d]=m.useState(0),[h,f]=m.useState("forward"),g=m.useRef([]),y=m.useRef(new vw),v=m.useRef(null),T=m.useRef(null);m.useEffect(()=>{const P=g.current;if(a==="POP"){const O=P.findIndex(N=>N===s.pathname);O!==-1&&O<P.length-1?f("back"):f("forward"),g.current=P.slice(0,O+1)}else a==="PUSH"?(f("forward"),P.push(s.pathname)):a==="REPLACE"&&(f("forward"),P.length>0?P[P.length-1]=s.pathname:P.push(s.pathname))},[s.pathname,a]);const b=m.useCallback(()=>{l(!0),d(0),T.current=setInterval(()=>{d(P=>{const O=P<30?15:P<60?10:P<80?5:2;return Math.min(P+O,90)})},100)},[]),I=m.useCallback(()=>{T.current&&clearInterval(T.current),d(100),v.current=setTimeout(()=>{l(!1),d(0)},200)},[]);m.useEffect(()=>{b();const P=setTimeout(()=>{I()},t);return()=>{clearTimeout(P),v.current&&clearTimeout(v.current),T.current&&clearInterval(T.current)}},[s.pathname,b,I,t]);const x=m.useCallback((P,O={})=>{b(),i(P,O)},[i,b]),w=m.useCallback((P,O,N)=>{y.current.register(P,O,N)},[]),_=m.useCallback(P=>{y.current.unregister(P)},[]),A=m.useCallback(P=>y.current.get(P),[]),k=m.useCallback(P=>y.current.has(P),[]),R=m.useMemo(()=>({isTransitioning:o,direction:h,progress:u,duration:t,transitionTo:x,registerSharedElement:w,unregisterSharedElement:_,getSharedElement:A,hasSharedElement:k,registry:y.current}),[o,h,u,t,x,w,_,A,k]);return c.jsxs(gw.Provider,{value:R,children:[n&&c.jsx(yw,{isVisible:o,progress:u}),e]})}let os;try{os=require("./TransitionProvider").useTransitionContext}catch{os=()=>null}const rd=50;function id(e){return e?typeof e=="object"&&e.pathname?e.pathname:e==="/"?"/":e.replace(/\/$/,""):"/"}m.forwardRef(function({to:t,prefetch:n=!0,transition:s="fade",children:i,className:a="",state:o,replace:l=!1,onClick:u,onTransitionStart:d,onPrefetch:h,prefetchDelay:f=rd,...g},y){Ot();const v=Kc(),T=m.useRef(null),b=m.useRef(!1),I=os(),x=id(t),w=m.useCallback(()=>{!n||b.current||(T.current&&clearTimeout(T.current),T.current=setTimeout(()=>{b.current=!0,Ui(x),h?.(x)},f))},[n,x,h,f]),_=m.useCallback(()=>{T.current&&clearTimeout(T.current)},[]),A=m.useCallback(k=>{u?.(k),!k.defaultPrevented&&s!=="morph"&&I&&v&&s!=="none"&&(k.preventDefault(),d?.(x,s),I.transitionTo(x,{state:{...o,_transition:s},replace:l}))},[u,I,v,s,x,o,l,d]);return c.jsx(bd,{ref:y,to:t,className:`transition-link ${a}`.trim(),state:{...o,_transition:s},replace:l,onClick:A,onMouseEnter:w,onFocus:w,onMouseLeave:_,onTouchStart:w,...g,children:i})});m.forwardRef(function({to:t,prefetch:n=!0,transition:s="fade",children:i,className:a,state:o,replace:l=!1,onClick:u,onTransitionStart:d,onPrefetch:h,prefetchDelay:f=rd,end:g,caseSensitive:y,...v},T){Ot();const b=Kc(),I=m.useRef(null),x=m.useRef(!1),w=os(),_=id(t),A=m.useCallback(()=>{!n||x.current||(I.current&&clearTimeout(I.current),I.current=setTimeout(()=>{x.current=!0,Ui(_),h?.(_)},f))},[n,_,h,f]),k=m.useCallback(()=>{I.current&&clearTimeout(I.current)},[]),R=m.useCallback(P=>{u?.(P),!P.defaultPrevented&&s!=="morph"&&w&&b&&s!=="none"&&(P.preventDefault(),d?.(_,s),w.transitionTo(_,{state:{...o,_transition:s},replace:l}))},[u,w,b,s,_,o,l,d]);return c.jsx(wd,{ref:T,to:t,className:typeof a=="function"?P=>`transition-link ${a(P)}`.trim():`transition-link ${a||""}`.trim(),state:{...o,_transition:s},replace:l,onClick:R,onMouseEnter:A,onFocus:A,onMouseLeave:k,onTouchStart:A,end:g,caseSensitive:y,...v,children:i})});const ve={coaching:{maxCoachVisible:!1,mascotVisible:!0,coachTipsEnabled:!0,motivationalQuotes:!0,formCuesEnabled:!0,voiceGuidanceEnabled:!1},guidanceLevel:"intermediate",dashboard:{layout:"default",showQuickActions:!0,showDailyTip:!0,showMilestones:!0,showAdventureMap:!0,showMuscleMap:!0,showNutrition:!0,showChallenges:!0,showInsights:!0,showActivity:!0,showHydration:!0,showMusicPlayer:!0,showCoachTips:!0,showXpProgress:!0,showDailyQuests:!0},notifications:{achievementsEnabled:!0,goalSuccessEnabled:!0,workoutReminders:!0,socialNotifications:!0,systemAnnouncements:!0,quietHoursEnabled:!1,quietHoursStart:"22:00",quietHoursEnd:"07:00",pushEnabled:!0,emailEnabled:!0},hydration:{enabled:!0,intervalMinutes:15,soundEnabled:!0,vibrationEnabled:!0,showDuringWorkout:!0,showOutsideWorkout:!1,dailyGoalOz:64},sounds:{masterVolume:.7,timerSoundEnabled:!0,timerSoundType:"beep",timerVibrationEnabled:!0,metronomeEnabled:!1,metronomeBpm:60,metronomeAccent:4,repCountSoundEnabled:!1,setCompleteSoundEnabled:!0,workoutCompleteSoundEnabled:!0,achievementSoundEnabled:!0,customSoundPackId:null,systemSoundPackId:"default"},workout:{defaultRestSeconds:90,autoStartTimer:!0,showFloatingTimer:!0,countdownWarningSeconds:10,warmupReminder:!0,cooldownReminder:!0,stretchReminder:!1,quickAdjustAmount:30},display:{theme:"dark",reducedMotion:!1,highContrast:!1,textSize:"normal",colorBlindMode:"none",animationsEnabled:!0},units:{weight:"lbs",distance:"mi",height:"ft_in",temperature:"f"},privacy:{publicProfile:!0,showLocation:!1,showProgress:!0,showWorkoutDetails:!0,showOnLeaderboards:!0,showAchievementsOnProfile:!0},music:{autoPlayOnWorkout:!0,bpmMatchingEnabled:!1,defaultProvider:null,defaultPlaylistId:null,fadeOnRest:!0,volumeReductionOnTips:!0,tipVolumeReduction:.5}};function nc(e){return{coaching:{...ve.coaching,...e.coaching},guidanceLevel:e.guidanceLevel??ve.guidanceLevel,dashboard:{...ve.dashboard,...e.dashboard},notifications:{...ve.notifications,...e.notifications},hydration:{...ve.hydration,...e.hydration},sounds:{...ve.sounds,...e.sounds},workout:{...ve.workout,...e.workout},display:{...ve.display,...e.display},units:{...ve.units,...e.units},privacy:{...ve.privacy,...e.privacy},music:{...ve.music,...e.music}}}function Tw(e,t){return{coaching:{...e.coaching,...t.coaching},guidanceLevel:t.guidanceLevel??e.guidanceLevel,dashboard:{...e.dashboard,...t.dashboard},notifications:{...e.notifications,...t.notifications},hydration:{...e.hydration,...t.hydration},sounds:{...e.sounds,...t.sounds},workout:{...e.workout,...t.workout},display:{...e.display,...t.display},units:{...e.units,...t.units},privacy:{...e.privacy,...t.privacy},music:{...e.music,...t.music}}}async function Be(e,t={}){const n=Wc(),s={"Content-Type":"application/json",...t.headers||{}};return n&&(s.Authorization=`Bearer ${n}`),fetch(e,{...t,headers:s})}const bt=ht()(wn(Jr((e,t)=>({preferences:ve,activeProfileId:null,profiles:[],version:0,isLoading:!1,isSaving:!1,error:null,lastSyncAt:null,deviceId:null,loadPreferences:async()=>{if(!Wc()){e({isLoading:!1});return}e({isLoading:!0,error:null});try{const s=await Be("/api/me/preferences");if(!s.ok)throw new Error("Failed to load preferences");const i=await s.json();if(i.success&&i.data){const a=nc(i.data.preferences||{});e({preferences:a,activeProfileId:i.data.activeProfileId||null,version:i.data.version||1,isLoading:!1,lastSyncAt:new Date().toISOString()})}}catch(s){e({error:s instanceof Error?s.message:"Failed to load preferences",isLoading:!1})}},updatePreferences:async n=>{e({isSaving:!0,error:null});const s=t().preferences,i={coaching:{...s.coaching,...n.coaching},guidanceLevel:n.guidanceLevel??s.guidanceLevel,dashboard:{...s.dashboard,...n.dashboard},notifications:{...s.notifications,...n.notifications},hydration:{...s.hydration,...n.hydration},sounds:{...s.sounds,...n.sounds},workout:{...s.workout,...n.workout},display:{...s.display,...n.display},units:{...s.units,...n.units},privacy:{...s.privacy,...n.privacy},music:{...s.music,...n.music}};e({preferences:i});try{const a=await Be("/api/me/preferences",{method:"PATCH",body:JSON.stringify(n)});if(!a.ok)throw new Error("Failed to save preferences");const o=await a.json();o.success&&o.data&&e({preferences:nc(o.data.preferences),version:o.data.version,isSaving:!1})}catch(a){e({preferences:s,error:a instanceof Error?a.message:"Failed to save preferences",isSaving:!1})}},resetPreferences:async()=>{e({isSaving:!0,error:null});try{if(!(await Be("/api/me/preferences/reset",{method:"PUT"})).ok)throw new Error("Failed to reset preferences");e({preferences:ve,isSaving:!1})}catch(n){e({error:n instanceof Error?n.message:"Failed to reset preferences",isSaving:!1})}},loadProfiles:async()=>{try{const n=await Be("/api/me/preferences/profiles");if(!n.ok)throw new Error("Failed to load profiles");const s=await n.json();s.success&&s.data&&e({profiles:s.data.profiles||[]})}catch(n){e({error:n instanceof Error?n.message:"Failed to load profiles"})}},createProfile:async(n,s,i)=>{try{const a=await Be("/api/me/preferences/profiles",{method:"POST",body:JSON.stringify({name:n,description:s,preferencesOverride:i})});if(!a.ok)throw new Error("Failed to create profile");const o=await a.json();return o.success&&o.data?.profile?(e(l=>({profiles:[...l.profiles,o.data.profile]})),o.data.profile):null}catch(a){return e({error:a instanceof Error?a.message:"Failed to create profile"}),null}},updateProfile:async(n,s)=>{try{const i=await Be(`/api/me/preferences/profiles/${n}`,{method:"PATCH",body:JSON.stringify(s)});if(!i.ok)throw new Error("Failed to update profile");const a=await i.json();a.success&&a.data?.profile&&e(o=>({profiles:o.profiles.map(l=>l.id===n?a.data.profile:l)}))}catch(i){e({error:i instanceof Error?i.message:"Failed to update profile"})}},deleteProfile:async n=>{try{if(!(await Be(`/api/me/preferences/profiles/${n}`,{method:"DELETE"})).ok)throw new Error("Failed to delete profile");e(i=>({profiles:i.profiles.filter(a=>a.id!==n),activeProfileId:i.activeProfileId===n?null:i.activeProfileId}))}catch(s){e({error:s instanceof Error?s.message:"Failed to delete profile"})}},activateProfile:async n=>{try{if(!(await Be(`/api/me/preferences/profiles/${n}/activate`,{method:"POST"})).ok)throw new Error("Failed to activate profile");e({activeProfileId:n})}catch(s){e({error:s instanceof Error?s.message:"Failed to activate profile"})}},deactivateProfile:async()=>{try{if(!(await Be("/api/me/preferences/profiles/deactivate",{method:"POST"})).ok)throw new Error("Failed to deactivate profile");e({activeProfileId:null})}catch(n){e({error:n instanceof Error?n.message:"Failed to deactivate profile"})}},getEffectivePreferences:()=>{const{preferences:n,activeProfileId:s,profiles:i}=t();if(!s)return n;const a=i.find(o=>o.id===s);return a?Tw(n,a.preferencesOverride):n},setGuidanceLevel:async n=>{await t().updatePreferences({guidanceLevel:n})},toggleMaxCoach:async()=>{const n=t().preferences.coaching.maxCoachVisible;await t().updatePreferences({coaching:{...t().preferences.coaching,maxCoachVisible:!n}})},toggleMascot:async()=>{const n=t().preferences.coaching.mascotVisible;await t().updatePreferences({coaching:{...t().preferences.coaching,mascotVisible:!n}})},toggleMetronome:async()=>{const n=t().preferences.sounds.metronomeEnabled;await t().updatePreferences({sounds:{...t().preferences.sounds,metronomeEnabled:!n}})},setMetronomeBpm:async n=>{await t().updatePreferences({sounds:{...t().preferences.sounds,metronomeBpm:n}})},toggleHydrationReminders:async()=>{const n=t().preferences.hydration.enabled;await t().updatePreferences({hydration:{...t().preferences.hydration,enabled:!n}})},setHydrationInterval:async n=>{await t().updatePreferences({hydration:{...t().preferences.hydration,intervalMinutes:n}})},_setPreferences:n=>{e(s=>({preferences:{...s.preferences,...n}}))},_setProfiles:n=>e({profiles:n}),_setLoading:n=>e({isLoading:n}),_setError:n=>e({error:n})}),{name:"musclemap-preferences",storage:ln(()=>ds),partialize:e=>({preferences:e.preferences,activeProfileId:e.activeProfileId,profiles:e.profiles,version:e.version,lastSyncAt:e.lastSyncAt,deviceId:e.deviceId})}))),bw=()=>{const e=bt(i=>i.preferences.coaching),t=bt(i=>i.toggleMaxCoach),n=bt(i=>i.toggleMascot),s=bt(i=>i.updatePreferences);return{...e,toggleMaxCoach:t,toggleMascot:n,toggleTips:()=>s({coaching:{...e,coachTipsEnabled:!e.coachTipsEnabled}}),toggleMotivationalQuotes:()=>s({coaching:{...e,motivationalQuotes:!e.motivationalQuotes}}),toggleFormCues:()=>s({coaching:{...e,formCuesEnabled:!e.formCuesEnabled}})}},Ik=()=>{const e=bt(n=>n.preferences.units),t=bt(n=>n.updatePreferences);return{...e,setWeightUnit:n=>t({units:{...e,weight:n}}),setDistanceUnit:n=>t({units:{...e,distance:n}}),setHeightUnit:n=>t({units:{...e,height:n}}),setTemperatureUnit:n=>t({units:{...e,temperature:n}}),setMetric:()=>t({units:{weight:"kg",distance:"km",height:"cm",temperature:"c"}}),setImperial:()=>t({units:{weight:"lbs",distance:"mi",height:"ft_in",temperature:"f"}}),isMetric:e.weight==="kg"&&e.height==="cm",isImperial:e.weight==="lbs"&&e.height==="ft_in",lengthUnit:e.height==="cm"?"cm":"in"}},zt={thresholds:{warning:.7,critical:.85,emergency:.95},checkInterval:1e4,warningCooldown:6e4};class ww{intervalId=null;callbacks=new Set;lastWarnings=new Map;isSupported;history=[];maxHistorySize=100;constructor(){this.isSupported=typeof performance<"u"&&"memory"in performance&&typeof performance.memory=="object"}get supported(){return this.isSupported}getMemoryInfo(){if(!this.isSupported)return null;const t=performance.memory;return{usedJSHeapSize:t.usedJSHeapSize,totalJSHeapSize:t.totalJSHeapSize,jsHeapSizeLimit:t.jsHeapSizeLimit,percentUsed:t.usedJSHeapSize/t.jsHeapSizeLimit,usedMB:(t.usedJSHeapSize/(1024*1024)).toFixed(1),totalMB:(t.totalJSHeapSize/(1024*1024)).toFixed(1),limitMB:(t.jsHeapSizeLimit/(1024*1024)).toFixed(1)}}start(){this.intervalId||this.isSupported&&(this.check(),this.intervalId=setInterval(()=>this.check(),zt.checkInterval))}stop(){this.intervalId&&(clearInterval(this.intervalId),this.intervalId=null)}onWarning(t){return this.callbacks.add(t),()=>this.callbacks.delete(t)}check(){const t=this.getMemoryInfo();return t?(this.history.push({timestamp:new Date,info:t}),this.history.length>this.maxHistorySize&&this.history.shift(),t.percentUsed>=zt.thresholds.emergency?this.handleEmergency(t):t.percentUsed>=zt.thresholds.critical?this.handleCritical(t):t.percentUsed>=zt.thresholds.warning&&this.handleWarning(t),t):null}handleWarning(t){if(!this.shouldWarn("warning"))return;const n={level:"warning",message:`Memory usage is elevated: ${t.usedMB}MB / ${t.limitMB}MB (${Math.round(t.percentUsed*100)}%)`,memoryInfo:t,timestamp:new Date,suggestions:["Consider closing unused tabs","Cache garbage collection will run automatically"]};this.notifyCallbacks(n),this.lastWarnings.set("warning",Date.now()),Ye()}handleCritical(t){if(!this.shouldWarn("critical"))return;const n={level:"critical",message:`Memory usage is HIGH: ${t.usedMB}MB / ${t.limitMB}MB (${Math.round(t.percentUsed*100)}%)`,memoryInfo:t,timestamp:new Date,suggestions:["Close other browser tabs","Refresh the page if performance is degraded","Clear application cache from Settings"]};this.notifyCallbacks(n),this.lastWarnings.set("critical",Date.now()),Ye()}handleEmergency(t){const n={level:"emergency",message:`CRITICAL: Memory usage is dangerous: ${t.usedMB}MB / ${t.limitMB}MB (${Math.round(t.percentUsed*100)}%)`,memoryInfo:t,timestamp:new Date,suggestions:["The page may crash soon - save any work","Refresh the page immediately","Close other browser tabs and applications"]};this.notifyCallbacks(n),this.lastWarnings.set("emergency",Date.now()),this.emergencyCleanup()}shouldWarn(t){const n=this.lastWarnings.get(t);return n?Date.now()-n>=zt.warningCooldown:!0}notifyCallbacks(t){this.callbacks.forEach(n=>{try{n(t)}catch{}})}emergencyCleanup(){Ye(),"caches"in window&&caches.keys().then(t=>{t.forEach(n=>{n.includes("musclemap")&&caches.delete(n)})});try{const t=[];for(let n=0;n<localStorage.length;n++){const s=localStorage.key(n);(s?.startsWith("mm_cache_")||s?.startsWith("cache:"))&&t.push(s)}t.forEach(n=>localStorage.removeItem(n))}catch{}typeof window.gc=="function"&&window.gc()}getHistory(){return[...this.history]}getSummary(){const t=this.getMemoryInfo(),n=us();if(this.history.length<2)return{current:t,trend:"unknown",averageUsage:t?.percentUsed||0,peakUsage:t?.percentUsed||0,cacheStats:n};const s=this.history.slice(-10),i=s[0].info.percentUsed,o=s[s.length-1].info.percentUsed-i;let l;o>.05?l="increasing":o<-.05?l="decreasing":l="stable";const u=this.history.map(f=>f.info.percentUsed),d=u.reduce((f,g)=>f+g,0)/u.length,h=Math.max(...u);return{current:t,trend:l,averageUsage:d,peakUsage:h,cacheStats:n}}forceGC(){const t=this.getMemoryInfo(),n=Ye(),s=this.getMemoryInfo();return{cacheCollected:n.collected,memoryBefore:t,memoryAfter:s}}}const Se=new ww;function xk(e={}){const{autoStart:t=!0}=e,[n,s]=m.useState(null),[i,a]=m.useState(null);m.useEffect(()=>{if(!Se.supported)return;s(Se.getMemoryInfo()),t&&Se.start();const d=Se.onWarning(f=>{a(f),f.level!=="emergency"&&setTimeout(()=>a(null),1e4)}),h=setInterval(()=>{s(Se.getMemoryInfo())},5e3);return()=>{d(),clearInterval(h)}},[t]);const o=m.useCallback(()=>Se.forceGC(),[]),l=m.useCallback(()=>Se.getSummary(),[]),u=m.useCallback(()=>{a(null)},[]);return{supported:Se.supported,memoryInfo:n,warning:i,forceGC:o,getSummary:l,clearWarning:u}}const Sn={memory:{maxSize:100,defaultTTL:6e4},localStorage:{prefix:"mm_cache_"},indexedDB:{dbName:"musclemap-cache",storeName:"cache"}},Zs={"ref:exercises":36e5,"ref:muscles":36e5,"ref:equipment":36e5,"ref:archetypes":36e5,"user:profile":3e5,"user:stats":3e5,"user:achievements":6e5,"user:settings":6e4,"workout:active":1e4,"feed:activity":3e4,leaderboard:6e4,presence:5e3,credits:1e4};class Iw{constructor(t=Sn.memory.maxSize){this.cache=new Map,this.maxSize=t}get(t){const n=this.cache.get(t);return n?n.expiresAt&&Date.now()>n.expiresAt?(this.cache.delete(t),null):(this.cache.delete(t),this.cache.set(t,n),n.value):null}set(t,n,s){if(this.cache.size>=this.maxSize){const a=this.cache.keys().next().value;this.cache.delete(a)}const i={value:n,createdAt:Date.now(),expiresAt:s?Date.now()+s:null};this.cache.set(t,i)}delete(t){return this.cache.delete(t)}clear(){this.cache.clear()}has(t){const n=this.cache.get(t);return n?n.expiresAt&&Date.now()>n.expiresAt?(this.cache.delete(t),!1):!0:!1}size(){return this.cache.size}keys(){return Array.from(this.cache.keys())}}function xw(){try{if(typeof localStorage>"u"||localStorage===null)return!1;const e="__mm_ls_test__";localStorage.setItem(e,"test");const t=localStorage.getItem(e);return localStorage.removeItem(e),t==="test"}catch{return!1}}class Ew{prefix;available;constructor(t=Sn.localStorage.prefix){this.prefix=t,this.available=xw()}_key(t){return`${this.prefix}${t}`}get(t){if(!this.available)return null;try{const n=localStorage.getItem(this._key(t));if(!n)return null;const s=JSON.parse(n);return s.expiresAt&&Date.now()>s.expiresAt?(this.delete(t),null):s.value}catch{return null}}set(t,n,s){if(!this.available)return!1;try{const i={value:n,createdAt:Date.now(),expiresAt:s?Date.now()+s:null};return localStorage.setItem(this._key(t),JSON.stringify(i)),!0}catch(i){if(i?.name==="QuotaExceededError"){this.evictOldest(10);try{const a={value:n,createdAt:Date.now(),expiresAt:s?Date.now()+s:null};return localStorage.setItem(this._key(t),JSON.stringify(a)),!0}catch{return!1}}return!1}}delete(t){if(!this.available)return!1;try{return localStorage.removeItem(this._key(t)),!0}catch{return!1}}clear(){if(this.available)try{const t=[];for(let n=0;n<localStorage.length;n++){const s=localStorage.key(n);s&&s.startsWith(this.prefix)&&t.push(s)}t.forEach(n=>localStorage.removeItem(n))}catch{}}evictOldest(t=5){if(this.available)try{const n=[];for(let s=0;s<localStorage.length;s++){const i=localStorage.key(s);if(i&&i.startsWith(this.prefix))try{const a=localStorage.getItem(i);if(a){const o=JSON.parse(a);n.push({key:i,createdAt:o.createdAt||0})}}catch{n.push({key:i,createdAt:0})}}n.sort((s,i)=>s.createdAt-i.createdAt),n.slice(0,t).forEach(({key:s})=>{localStorage.removeItem(s)})}catch{}}has(t){return this.get(t)!==null}keys(){if(!this.available)return[];try{const t=[];for(let n=0;n<localStorage.length;n++){const s=localStorage.key(n);s&&s.startsWith(this.prefix)&&t.push(s.slice(this.prefix.length))}return t}catch{return[]}}}class Aw{constructor(){this.dbName=Sn.indexedDB.dbName,this.storeName=Sn.indexedDB.storeName,this.db=null}async open(){return this.db?this.db:new Promise((t,n)=>{try{if(typeof indexedDB>"u"){t(null);return}}catch{t(null);return}const s=indexedDB.open(this.dbName,1);s.onerror=()=>n(s.error),s.onsuccess=()=>{this.db=s.result,t(this.db)},s.onupgradeneeded=i=>{const a=i.target.result;a.objectStoreNames.contains(this.storeName)||a.createObjectStore(this.storeName,{keyPath:"key"})}})}async get(t){try{const n=await this.open();return n?new Promise(s=>{const o=n.transaction(this.storeName,"readonly").objectStore(this.storeName).get(t);o.onsuccess=()=>{const l=o.result;if(!l){s(null);return}if(l.expiresAt&&Date.now()>l.expiresAt){this.delete(t),s(null);return}s(l.value)},o.onerror=()=>s(null)}):null}catch{return null}}async set(t,n,s){try{const i=await this.open();return i?new Promise((a,o)=>{const u=i.transaction(this.storeName,"readwrite").objectStore(this.storeName),d={key:t,value:n,createdAt:Date.now(),expiresAt:s?Date.now()+s:null},h=u.put(d);h.onsuccess=()=>a(!0),h.onerror=()=>o(h.error)}):!1}catch{return!1}}async delete(t){try{const n=await this.open();return n?new Promise(s=>{const o=n.transaction(this.storeName,"readwrite").objectStore(this.storeName).delete(t);o.onsuccess=()=>s(!0),o.onerror=()=>s(!1)}):!1}catch{return!1}}async clear(){try{const t=await this.open();return t?new Promise(n=>{const a=t.transaction(this.storeName,"readwrite").objectStore(this.storeName).clear();a.onsuccess=()=>n(!0),a.onerror=()=>n(!1)}):!1}catch{return!1}}}class _w{constructor(){this.memory=new Iw,this.localStorage=new Ew,this.indexedDB=new Aw}getTTL(t){if(Zs[t])return Zs[t];for(const[n,s]of Object.entries(Zs))if(t.startsWith(n.split(":")[0]+":"))return s;return Sn.memory.defaultTTL}async get(t,n={}){const{skipMemory:s=!1,skipLocal:i=!1,skipIndexedDB:a=!1}=n;if(!s){const o=this.memory.get(t);if(o!==null)return o}if(!i){const o=this.localStorage.get(t);if(o!==null)return this.memory.set(t,o,this.getTTL(t)),o}if(!a){const o=await this.indexedDB.get(t);if(o!==null)return this.memory.set(t,o,this.getTTL(t)),o}return null}async set(t,n,s={}){const{ttl:i=this.getTTL(t),persist:a=!0,persistLarge:o=!1}=s;this.memory.set(t,n,i),a&&(o?await this.indexedDB.set(t,n,i):this.localStorage.set(t,n,i))}async delete(t){this.memory.delete(t),this.localStorage.delete(t),await this.indexedDB.delete(t)}async clear(){this.memory.clear(),this.localStorage.clear(),await this.indexedDB.clear()}async invalidate(t){const n=new RegExp(t.replace("*",".*"));for(const s of this.memory.keys())n.test(s)&&this.memory.delete(s);for(const s of this.localStorage.keys())n.test(s)&&this.localStorage.delete(s)}async warm(t){return await Promise.allSettled(Object.entries(t).map(async([s,i])=>{try{const a=await i();return await this.set(s,a,{ttl:this.getTTL(s)}),{key:s,success:!0}}catch(a){return{key:s,success:!1,error:a}}}))}getStats(){return{memory:{size:this.memory.size(),keys:this.memory.keys()},localStorage:{keys:this.localStorage.keys()}}}}const ad=new _w;async function od(){const e=Se.getSummary(),t=us(),n=await Hm(),s=ad.getStats();let i=0,a=0;try{const u="__mm_ls_test__";localStorage.setItem(u,"test"),localStorage.removeItem(u);for(let d=0;d<localStorage.length;d++){const h=localStorage.key(d);if(h){const f=localStorage.getItem(h)||"";a+=h.length+f.length,(h.startsWith("mm_cache_")||h.startsWith("cache:")||h.startsWith("musclemap"))&&i++}}}catch{i=-1,a=-1}const o=[];e.current&&e.current.percentUsed>.7&&o.push("Memory usage is high. Consider refreshing the page."),t.estimatedSizeKB>5e3&&o.push("Apollo cache is large (>5MB). Consider clearing with clearApolloCache()."),t.totalEntries>1e3&&o.push("Apollo cache has many entries. Run garbageCollectCache()."),i>50?o.push("Many localStorage cache entries. Consider clearing old entries."):i===-1&&o.push("localStorage unavailable (Brave Shields or private mode)."),e.trend==="increasing"&&o.push("Memory usage is trending up. Possible memory leak."),n&&parseFloat(n.percentUsed)>80&&o.push("IndexedDB cache is nearly full. Clear with clearPersistedCache().");let l=0;try{typeof localStorage<"u"&&localStorage!==null&&(l=localStorage.length)}catch{}return{timestamp:new Date().toISOString(),browser:{supported:Se.supported,memory:e.current,trend:e.trend},apollo:{cacheStats:t,cacheLimits:he},localStorage:{totalKeys:l,cacheKeys:i,estimatedSizeKB:Math.round(a/1024)},indexedDB:{apolloPersist:n},appCache:{memoryKeys:s.memory.keys,localStorageKeys:s.localStorage.keys},recommendations:o}}async function cd(){const e=await od();e.browser.supported&&e.browser.memory,e.indexedDB.apolloPersist,e.recommendations.length>0&&e.recommendations.forEach((t,n)=>{})}async function Cw(){await Vc(),await ad.clear();try{const e="__mm_ls_test__";localStorage.setItem(e,"test"),localStorage.removeItem(e);const t=[];for(let n=0;n<localStorage.length;n++){const s=localStorage.key(n);(s?.startsWith("mm_cache_")||s?.startsWith("cache:"))&&t.push(s)}t.forEach(n=>localStorage.removeItem(n))}catch{}Ye(),await cd()}async function kw(){await bh()}let on=null;const wt=[];function Rw(e=300){if(on)return;wt.length=0;const t=()=>{const n=Se.getMemoryInfo(),s=us();n&&wt.push({timestamp:new Date,memoryMB:parseFloat(n.usedMB),cacheEntries:s.totalEntries})};t(),on=setInterval(t,1e4),setTimeout(()=>{ld()},e*1e3)}function ld(){if(!on||(clearInterval(on),on=null,wt.length<2))return;const e=wt[0],t=wt[wt.length-1];t.memoryMB-e.memoryMB,t.cacheEntries-e.cacheEntries,(t.timestamp.getTime()-e.timestamp.getTime())/6e4}function Pw(e){const t=window.__APOLLO_CLIENT__?.cache?.extract();if(!t)return;const n=t.ROOT_QUERY;if(!n)return;Object.keys(n).filter(i=>i.toLowerCase().includes(e.toLowerCase())).forEach(i=>{const a=n[i];JSON.stringify(a).length})}function Mw(e){Th(e)}const sc={getReport:od,printReport:cd,clearAll:Cw,clearApollo:kw,gc:Ye,forceGC:()=>Se.forceGC(),trackLeaks:Rw,stopTrackingLeaks:ld,inspectQuery:Pw,evict:Mw,monitor:Se,getCacheStats:us,CACHE_LIMITS:he};if(typeof window<"u"){const e=window;e.__MUSCLEMAP_DEBUG__?e.__MUSCLEMAP_DEBUG__.memory=sc:e.__MUSCLEMAP_DEBUG__={memory:sc}}const Ow=m.lazy(()=>E(()=>Promise.resolve().then(()=>Vv),void 0)),Nw=m.lazy(()=>E(()=>Promise.resolve().then(()=>eb),void 0)),fe=(e,t,n)=>{const s=t instanceof Error?t.message:String(t),i=t instanceof Error?t.stack:"No stack";try{const a=new XMLHttpRequest;a.open("POST","/api/client-error",!0),a.setRequestHeader("Content-Type","application/json"),a.send(JSON.stringify({type:"app_error",message:`[App:${e}] ${s}`,source:"App.tsx",stack:i,time:new Date().toISOString(),extra:{phase:e,...n}}))}catch{}},pt=(e,t)=>m.lazy(()=>t().catch(n=>(fe(`lazy:${e}`,n),{default:()=>$e.createElement("div",{style:{padding:"20px",color:"red",background:"#1a1a1a"}},`Failed to load ${e}: ${n?.message||"Unknown error"}`)}))),$w=m.lazy(()=>E(()=>import("./SpotlightTour-f5dxh1la.js"),__vite__mapDeps([41,1,42,22,5,6])).then(e=>({default:e.SpotlightTourRenderer}))),Dw=pt("AICoach",()=>E(()=>import("./AICoach-ibblprua.js"),__vite__mapDeps([131,1,5,6]))),jw=pt("LootDrop",()=>E(()=>import("./LootDrop-rknhl7qc.js"),__vite__mapDeps([47,1,5,6]))),Lw=pt("FloatingRestTimer",()=>E(()=>import("./FloatingRestTimer-jcp0ydii.js"),__vite__mapDeps([65,1,4,66,67,60,68,69,5,6]))),Uw=pt("OfflineIndicator",()=>E(()=>import("./OfflineIndicator-hw2xmx00.js"),__vite__mapDeps([132,1,12,133,134,33,5,6]))),Vw=pt("MobileDebugOverlay",()=>E(()=>import("./MobileDebugOverlay-likvzvt9.js"),__vite__mapDeps([135,1,31,74,38,72,39,32,5,6]))),Bw=pt("MemoryWarningBanner",()=>E(()=>import("./MemoryWarningBanner-lceurren.js"),__vite__mapDeps([136,1,72,33,87,5,6]))),Fw=pt("Landing",()=>E(()=>import("./Landing-j4pzoegb.js"),__vite__mapDeps([10,1,11,12,3,5,6]))),qw=m.lazy(()=>E(()=>import("./Login-j0zyug61.js"),__vite__mapDeps([13,1,14,11,15,16,17,5,6]))),Ww=m.lazy(()=>E(()=>import("./Signup-p1pfugla.js"),__vite__mapDeps([18,1,11,15,16,17,14,5,6]))),zw=m.lazy(()=>E(()=>import("./ForgotPassword-lwrp13l4.js"),__vite__mapDeps([137,1,11,15,16,17,5]))),Hw=m.lazy(()=>E(()=>import("./ResetPassword-6frbzynl.js"),__vite__mapDeps([138,1,11,15,5]))),Gw=m.lazy(()=>E(()=>import("./Dashboard-mmc1ijmj.js"),__vite__mapDeps([19,1,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,15,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,5,6]))),Yw=m.lazy(()=>E(()=>import("./Onboarding-gradixe6.js"),__vite__mapDeps([58,1,59,37,2,33,15,60,5,6]))),Kw=m.lazy(()=>E(()=>import("./Workout-ki77an0n.js"),__vite__mapDeps([61,1,20,62,63,64,23,24,65,4,66,67,60,68,69,32,30,35,21,33,70,39,71,22,72,73,74,75,76,77,78,79,80,45,46,5,6]))),Qw=m.lazy(()=>E(()=>import("./ActivityLog-hq2lj7oj.js").then(e=>e.A),__vite__mapDeps([139,1,43,37,140,34,86,22,5]))),Jw=m.lazy(()=>E(()=>import("./Journey-lit2kfd6.js"),__vite__mapDeps([81,1,59,37,2,33,44,47,48,63,82,5,6]))),Xw=m.lazy(()=>E(()=>import("./Profile-enzivbk0.js"),__vite__mapDeps([83,1,16,17,44,47,48,84,63,5,6]))),Zw=m.lazy(()=>E(()=>import("./Settings-hgxsxzru.js"),__vite__mapDeps([85,1,23,24,66,39,79,71,68,69,35,73,86,33,72,87,22,25,36,51,5,6]))),eI=m.lazy(()=>E(()=>import("./Progression-bqwvjqk2.js"),__vite__mapDeps([88,1,5,6]))),tI=m.lazy(()=>E(()=>import("./Exercises-d6ldu9ra.js"),__vite__mapDeps([89,1,62,63,64,90,52,33,5,6]))),nI=m.lazy(()=>E(()=>import("./Stats-hgrx3zhq.js"),__vite__mapDeps([91,1,25,36,51,23,24,49,84,63,82,50,5,6]))),sI=m.lazy(()=>E(()=>import("./PersonalRecords-okirovbp.js"),__vite__mapDeps([141,1,25,36,51,23,24,54,55,5,6]))),rI=m.lazy(()=>E(()=>import("./Progress-photos-cb2y40ti.js"),__vite__mapDeps([142,1,25,36,51,5,6]))),iI=m.lazy(()=>E(()=>import("./WorkoutTemplates-kfmu50e4.js"),__vite__mapDeps([143,1,52,33,37,144,74,145,72,39,80,5,6]))),aI=m.lazy(()=>E(()=>import("./BodyMeasurements-gwv5qauk.js"),__vite__mapDeps([146,1,37,39,145,72,35,77,5,6]))),oI=m.lazy(()=>E(()=>import("./CommunityDashboard-lpcew5l7.js"),__vite__mapDeps([92,1,90,93,94,5,6]))),cI=m.lazy(()=>E(()=>import("./Competitions-dczglajf.js"),__vite__mapDeps([95,1,5,6]))),lI=m.lazy(()=>E(()=>import("./Locations-gfz0zi4p.js"),__vite__mapDeps([96,1,5,6]))),uI=m.lazy(()=>E(()=>import("./HighFives-259zdss5.js"),__vite__mapDeps([97,1,5,6]))),dI=m.lazy(()=>E(()=>import("./Messages-n5pis5xh.js"),__vite__mapDeps([98,1,16,17,23,54,55,94,5,6]))),mI=m.lazy(()=>E(()=>import("./Crews-mpso8dk2.js"),__vite__mapDeps([99,1,25,36,51,23,24,5,6]))),hI=m.lazy(()=>E(()=>import("./Rivals-m7irxk6w.js"),__vite__mapDeps([100,1,25,36,51,23,24,5,6]))),pI=m.lazy(()=>E(()=>import("./Credits-e7vpmz38.js"),__vite__mapDeps([101,1,5,6]))),fI=m.lazy(()=>E(()=>import("./Wallet-jkqnm7ii.js"),__vite__mapDeps([102,1,25,36,51,5,6]))),gI=m.lazy(()=>E(()=>import("./SkinsStore-gqcjici5.js"),__vite__mapDeps([103,1,5,6]))),yI=m.lazy(()=>E(()=>import("./Trainers-3i3bv8t8.js"),__vite__mapDeps([147,1,25,36,51,23,24,5,6]))),vI=m.lazy(()=>E(()=>import("./Marketplace-f6pg7nm4.js"),__vite__mapDeps([148,1,5,6]))),SI=m.lazy(()=>E(()=>import("./Trading-eh1wu730.js"),__vite__mapDeps([149,1,5,6]))),TI=m.lazy(()=>E(()=>import("./Collection-ociff6yw.js"),__vite__mapDeps([150,1,5,6]))),bI=m.lazy(()=>E(()=>import("./MysteryBoxes-lr47o8o9.js"),__vite__mapDeps([151,1,5,6]))),wI=m.lazy(()=>E(()=>import("./Health-fd6rpwbz.js"),__vite__mapDeps([104,1,23,24,5,6]))),II=m.lazy(()=>E(()=>import("./Recovery-gcuvvi6d.js"),__vite__mapDeps([152,1,25,36,51,23,24,49,45,22,32,46,5,6]))),xI=m.lazy(()=>E(()=>import("./Goals-dz86d6ug.js"),__vite__mapDeps([105,1,16,17,23,24,54,55,63,5,6]))),EI=m.lazy(()=>E(()=>import("./Limitations-oi6bavlw.js"),__vite__mapDeps([106,1,25,36,51,23,24,54,55,5,6]))),AI=m.lazy(()=>E(()=>import("./PTTests-papi75q2.js"),__vite__mapDeps([107,1,25,36,51,23,24,54,55,5,6]))),_I=m.lazy(()=>E(()=>import("./CareerReadiness-lejx454y.js"),__vite__mapDeps([153,1,23,24,54,55,5,6]))),CI=m.lazy(()=>E(()=>import("./Leaderboard-xmq3yn42.js"),__vite__mapDeps([154,1,5,6]))),kI=m.lazy(()=>E(()=>import("./JourneyHealth-bsesblqn.js"),__vite__mapDeps([155,1,31,70,130,87,22,37,33,32,5,6]))),RI=m.lazy(()=>E(()=>import("./RecoveryDashboard-ml3xusfx.js"),__vite__mapDeps([156,1,43,32,66,39,71,22,27,33,5,6]))),PI=m.lazy(()=>E(()=>import("./ProgressionTargets-hdirizyn.js"),__vite__mapDeps([157,1,31,144,5,6]))),MI=m.lazy(()=>E(()=>import("./CareerPage-ou5wij7s.js"),__vite__mapDeps([158,1,23,24,54,55,159,5,6]))),OI=m.lazy(()=>E(()=>import("./CareerGoalPage-o7mh4c8i.js"),__vite__mapDeps([160,1,23,24,54,55,159,5,6]))),NI=m.lazy(()=>E(()=>import("./CareerStandardPage-cn9kru4a.js"),__vite__mapDeps([161,1,25,36,51,23,24,54,55,159,5,6]))),$I=m.lazy(()=>E(()=>import("./DesignSystem-eqh94s47.js"),__vite__mapDeps([108,1,23,24,53,54,55,56,5,6]))),DI=m.lazy(()=>E(()=>import("./Features-dqmznmq6.js"),__vite__mapDeps([109,1,23,24,55,56,11,5,6]))),jI=m.lazy(()=>E(()=>import("./MuscleMapUIShowcase-ldl6i8sc.js"),__vite__mapDeps([162,1,5]))),LI=m.lazy(()=>E(()=>import("./Technology-esd2c5dh.js"),__vite__mapDeps([110,1,23,24,55,111,112,5,6]))),UI=m.lazy(()=>E(()=>import("./Science-khtwvj9z.js"),__vite__mapDeps([113,1,23,24,55,5,6]))),VI=m.lazy(()=>E(()=>import("./Design-esylxu93.js"),__vite__mapDeps([114,1,23,24,54,55,56,5,6]))),er=m.lazy(()=>E(()=>import("./Docs-liufbhwg.js"),__vite__mapDeps([115,1,111,116,11,5,6]))),BI=m.lazy(()=>E(()=>import("./Privacy-ee491jka.js"),__vite__mapDeps([117,1,5]))),rc=m.lazy(()=>E(()=>import("./Skills-j40bmmdu.js"),__vite__mapDeps([118,1,5,6]))),ic=m.lazy(()=>E(()=>import("./MartialArts-ohefcpc5.js"),__vite__mapDeps([119,1,5,6]))),FI=m.lazy(()=>E(()=>import("./Achievements-i4d1djbr.js"),__vite__mapDeps([163,1,44,47,5,6]))),qI=m.lazy(()=>E(()=>import("./AchievementVerification-jyyxe379.js"),__vite__mapDeps([164,1,5,6]))),WI=m.lazy(()=>E(()=>import("./MyVerifications-k7zvgwin.js"),__vite__mapDeps([165,1,5,6]))),zI=m.lazy(()=>E(()=>import("./WitnessAttestation-nkpc0u6i.js"),__vite__mapDeps([166,1,5,6]))),HI=m.lazy(()=>E(()=>import("./Issues-cjxi9nyt.js"),__vite__mapDeps([120,1,94,5,6]))),GI=m.lazy(()=>E(()=>import("./IssueDetail-j8j68yp1.js"),__vite__mapDeps([167,1,16,17,94,5,6]))),YI=m.lazy(()=>E(()=>import("./NewIssue-ntmimfin.js"),__vite__mapDeps([121,1,16,17,5,6]))),KI=m.lazy(()=>E(()=>import("./MyIssues-hesxyfmz.js"),__vite__mapDeps([122,1,94,5,6]))),QI=m.lazy(()=>E(()=>import("./DevUpdates-et6drnm9.js"),__vite__mapDeps([123,1,94,5,6]))),JI=m.lazy(()=>E(()=>import("./Roadmap-dmgdgdsi.js"),__vite__mapDeps([124,1,111,125,11,94,5,6]))),XI=m.lazy(()=>E(()=>import("./AdminControl-1hblt4l3.js"),__vite__mapDeps([126,1,94,5,6]))),ZI=m.lazy(()=>E(()=>import("./AdminIssues-fzl6pcm9.js"),__vite__mapDeps([127,1,94,5,6]))),ex=m.lazy(()=>E(()=>import("./AdminMonitoring-fsh23maf.js"),__vite__mapDeps([128,1,23,87,129,33,31,130,39,22,5,6]))),tx=m.lazy(()=>E(()=>import("./AdminMetrics-pd9vycr6.js"),__vite__mapDeps([168,1,23,87,169,33,66,170,171,31,130,5,6]))),nx=m.lazy(()=>E(()=>import("./AdminDisputes-n1d3ezh6.js"),__vite__mapDeps([172,1,23,24,5,6]))),sx=m.lazy(()=>E(()=>import("./AdminFraud-ircxz5jj.js"),__vite__mapDeps([173,1,5,6]))),rx=m.lazy(()=>E(()=>import("./EmpireControl-lw3p775v.js").then(e=>e.E),__vite__mapDeps([174,1,23,129,171,175,176,87,177,178,22,33,21,32,38,31,179,180,30,5]))),ix=m.lazy(()=>E(()=>import("./EmpireUserDetail-huz6jk9v.js"),__vite__mapDeps([181,1,23,30,37,33,182,178,21,5,6]))),ax=m.lazy(()=>E(()=>import("./TestScorecard-jc4zsl1k.js"),__vite__mapDeps([183,1,23,24,87,37,33,31,130,39,22,5,6]))),ox=m.lazy(()=>E(()=>import("./DeploymentControl-cpmxowmk.js"),__vite__mapDeps([184,1,11,30,176,185,33,144,140,39,22,74,130,180,186,187,188,31,171,129,189,87,5,6]))),cx=m.lazy(()=>E(()=>import("./CommandCenter-jrinxsiz.js"),__vite__mapDeps([190,1,11,30,176,86,31,74,87,39,22,185,130,191,33,192,175,193,177,169,188,194,195,196,186,140,80,70,72,129,197,187,198,171,189,5,6]))),lx=m.lazy(()=>E(()=>import("./BugTracker-gapt5vmx.js"),__vite__mapDeps([199,1,23,30,38,39,22,133,31,200,87,33,194,197,32,5,6]))),ux=m.lazy(()=>E(()=>import("./AdminExerciseImages-hwwogv6n.js"),__vite__mapDeps([201,1,23,37,202,33,87,144,30,179,31,130,71,5,6]))),dx=m.lazy(()=>E(()=>import("./AnatomyViewer-kj6cd9lq.js"),__vite__mapDeps([203,1,8,204,5]))),mx=m.lazy(()=>E(()=>import("./LiveActivityMonitor-h7dsjtzz.js"),__vite__mapDeps([205,1,206,198,207,22,144,39,37,134,133,33,5,6]))),hx=m.lazy(()=>E(()=>import("./AdventureMap-jiqm9qr1.js"),__vite__mapDeps([208,1,209,51,5,6])));m.lazy(()=>E(()=>import("./index-m2xga5tt.js"),__vite__mapDeps([210,209,1,51,5,6])).then(e=>({default:e.AdventureMapFullscreen})));const px=m.lazy(()=>E(()=>import("./MapExplore-kzh6z0t6.js").then(e=>e.M),__vite__mapDeps([211,1,207,169,37,67,5]))),Fn=m.lazy(()=>E(()=>import("./Discover-jx3igaar.js"),__vite__mapDeps([212,1,213,144,5,6]))),fx=m.lazy(()=>E(()=>import("./PluginMarketplace-fqmg984q.js"),__vite__mapDeps([214,1,23,24,54,55,186,33,215,213,32,180,140,30,71,5,6]))),gx=m.lazy(()=>E(()=>import("./PluginSettings-okpoy0fx.js"),__vite__mapDeps([216,1,23,24,54,55,186,70,33,215,22,180,72,5,6]))),yx=m.lazy(()=>E(()=>import("./CommunityBulletinBoard-fpenvdm4.js"),__vite__mapDeps([217,1,11,5,6]))),vx=m.lazy(()=>E(()=>import("./PluginGuide-jik14ls7.js"),__vite__mapDeps([218,1,11,5,6]))),Sx=m.lazy(()=>E(()=>import("./ContributeIdeas-gkx2uy0e.js"),__vite__mapDeps([219,1,11,5,6]))),Tx=m.lazy(()=>E(()=>import("./Nutrition-hgex45px.js"),__vite__mapDeps([220,1,23,24,54,55,28,25,29,30,31,32,33,26,34,35,27,57,42,22,5,6]))),bx=m.lazy(()=>E(()=>import("./NutritionSettings-klp5pk8t.js"),__vite__mapDeps([221,1,23,24,54,222,55,25,29,71,37,179,72,22,32,5,6]))),ac=m.lazy(()=>E(()=>import("./Recipes-d64wkok5.js"),__vite__mapDeps([223,1,23,24,54,222,55,29,25,37,144,26,5,6]))),oc=m.lazy(()=>E(()=>import("./MealPlans-bjd88iey.js"),__vite__mapDeps([224,1,23,24,54,222,55,29,25,37,57,22,71,225,5,6]))),wx=m.lazy(()=>E(()=>import("./ShoppingList-ea89zxd1.js"),__vite__mapDeps([226,1,23,24,54,222,55,29,25,37,191,227,33,71,225,186,79,39,72,5,6]))),Ix=m.lazy(()=>E(()=>import("./NutritionHistory-ggsyvwy9.js"),__vite__mapDeps([228,1,23,24,54,222,55,29,25,37,42,22,77,35,71,5,6])));function xx({isNavigating:e}){return e?c.jsxs("div",{className:"fixed top-0 left-0 right-0 z-[9999] h-1 bg-black/20",children:[c.jsx("div",{className:"h-full bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500 animate-pulse",style:{animation:"progress 1s ease-in-out infinite",width:"100%"}}),c.jsx("style",{children:`
        @keyframes progress {
          0% { transform: translateX(-100%); }
          50% { transform: translateX(0%); }
          100% { transform: translateX(100%); }
        }
      `})]}):null}function ud(){return m.useEffect(()=>{try{const e=new XMLHttpRequest;e.open("POST","/api/client-error",!0),e.setRequestHeader("Content-Type","application/json"),e.send(JSON.stringify({type:"component_mount",message:"[PageSkeleton] Suspense fallback is showing",source:"App.tsx",time:new Date().toISOString()}))}catch{}},[]),c.jsxs("div",{className:"min-h-screen bg-[#0a0a0f] p-6",style:{minHeight:"100vh",backgroundColor:"#0a0a0f",padding:"24px",color:"white"},children:[c.jsxs("div",{style:{textAlign:"center",paddingTop:"40px"},children:[c.jsx("div",{style:{fontSize:"24px",marginBottom:"16px"},children:"Loading MuscleMap..."}),c.jsx("div",{style:{fontSize:"14px",opacity:.7},children:"Please wait"})]}),c.jsxs("div",{className:"max-w-5xl mx-auto",style:{maxWidth:"64rem",margin:"0 auto"},children:[c.jsxs("div",{className:"flex items-center justify-between mb-8",children:[c.jsx("div",{className:"h-10 w-32 bg-white/5 rounded-lg animate-pulse",style:{height:"40px",width:"128px",backgroundColor:"rgba(255,255,255,0.05)",borderRadius:"8px"}}),c.jsxs("div",{className:"flex gap-4",style:{display:"flex",gap:"16px"},children:[c.jsx("div",{className:"h-10 w-24 bg-white/5 rounded-lg animate-pulse",style:{height:"40px",width:"96px",backgroundColor:"rgba(255,255,255,0.05)",borderRadius:"8px"}}),c.jsx("div",{className:"h-10 w-24 bg-white/5 rounded-lg animate-pulse",style:{height:"40px",width:"96px",backgroundColor:"rgba(255,255,255,0.05)",borderRadius:"8px"}})]})]}),c.jsxs("div",{className:"space-y-6",children:[c.jsx("div",{className:"h-8 w-64 bg-white/5 rounded animate-pulse",style:{height:"32px",width:"256px",backgroundColor:"rgba(255,255,255,0.05)",borderRadius:"4px"}}),c.jsx("div",{className:"h-4 w-full max-w-md bg-white/5 rounded animate-pulse",style:{height:"16px",maxWidth:"28rem",backgroundColor:"rgba(255,255,255,0.05)",borderRadius:"4px"}})]})]})]})}const dd=()=>c.jsx("div",{className:"min-h-screen bg-[#0a0a0f] flex items-center justify-center",children:c.jsx("div",{className:"w-8 h-8 border-2 border-violet-500 border-t-transparent rounded-full animate-spin"})});function Ex(){return c.jsx("a",{href:"#main-content",className:"sr-only focus:not-sr-only focus:absolute focus:top-4 focus:left-4 focus:z-[10000] focus:px-4 focus:py-2 focus:bg-violet-600 focus:text-white focus:rounded-lg focus:outline-none focus:ring-2 focus:ring-violet-400",children:"Skip to main content"})}function Ax(){const e=et(),[t,n]=m.useState("");return m.useEffect(()=>{const s=e.pathname.split("/").filter(Boolean),i=s.length>0?s[s.length-1].replace(/-/g," "):"home",a=i.charAt(0).toUpperCase()+i.slice(1);n(`Navigated to ${a} page`),ab(e.pathname,`${a} | MuscleMap`);const o=setTimeout(()=>{Ye()},500);return()=>clearTimeout(o)},[e.pathname]),c.jsx("div",{role:"status","aria-live":"polite","aria-atomic":"true",className:"sr-only",children:t})}const tr="musclemap_scroll_";function _x(){const e=et(),t=vc(),n=$e.useRef(null);return m.useEffect(()=>{if(n.current&&n.current!==e.key&&sessionStorage.setItem(`${tr}${n.current}`,window.scrollY.toString()),t==="POP"){const s=sessionStorage.getItem(`${tr}${e.key}`);s!==null&&requestAnimationFrame(()=>{window.scrollTo(0,parseInt(s,10))})}else if(t==="PUSH"){window.scrollTo(0,0),document.documentElement.scrollTop=0,document.body.scrollTop=0;const s=document.getElementById("main-content")||document.querySelector("main");s&&(s.setAttribute("tabindex","-1"),s.focus({preventScroll:!0}))}n.current=e.key},[e.key,e.pathname,t]),m.useEffect(()=>{const s=Object.keys(sessionStorage).filter(i=>i.startsWith(tr)).sort();s.length>50&&s.slice(0,s.length-50).forEach(i=>sessionStorage.removeItem(i))},[e.key]),null}function Cx(){const[e,t]=m.useState(!1),n=et();return m.useEffect(()=>{t(!0);const s=setTimeout(()=>t(!1),300);return()=>clearTimeout(s)},[n.pathname]),e}function kx(){const e=et();return m.useEffect(()=>{De.pageView(e.pathname,{search:e.search})},[e]),null}const Rx=["/workout","/log","/exercises","/journey","/community","/profile"],$=({children:e,name:t})=>{const{user:n,loading:s,hasHydrated:i}=ms();return ib(n?Rx:[]),m.useEffect(()=>{!s&&n&&De.debug("route_access",{route:t,userId:n.id})},[s,n,t]),s||!i?c.jsx(dd,{}):n?c.jsx(V,{name:t,children:e}):c.jsx(at,{to:"/login",replace:!0})},me=({children:e,name:t})=>{const{user:n,loading:s,hasHydrated:i}=ms(),a=$e.useMemo(()=>Array.isArray(n?.roles)?n.roles:typeof n?.roles=="string"?[n.roles]:[],[n?.roles]),o=$e.useMemo(()=>n?.is_admin===!0||n?.is_owner===!0||n?.isAdmin===!0||n?.isOwner===!0||a.includes("admin")||a.includes("owner"),[n?.is_admin,n?.is_owner,n?.isAdmin,n?.isOwner,a]);return m.useEffect(()=>{s||De.info("admin_route_access",{route:t,userId:n?.id,isAdmin:o,roles:a})},[s,n?.id,t,o,a]),s||!i?c.jsx(dd,{}):n?o?c.jsx(V,{name:t,children:e}):(De.warn("admin_access_denied",{userId:n.id,route:t,roles:a}),c.jsx(at,{to:"/dashboard",replace:!0})):c.jsx(at,{to:"/login",replace:!0})};function nr({route:e}){const t=e.component;return t?c.jsx(m.Suspense,{fallback:c.jsx(ud,{}),children:typeof t=="function"?c.jsx(t,{}):t}):c.jsx("div",{className:"min-h-screen bg-[#0a0a0f] flex items-center justify-center text-white",children:c.jsx("p",{children:"Plugin component not found"})})}function Px(){const e=Cx(),t=cb(),n=et();return m.useEffect(()=>{try{const s=new XMLHttpRequest;s.open("POST","/api/client-error",!0),s.setRequestHeader("Content-Type","application/json"),s.send(JSON.stringify({type:"component_mount",message:`[AppRoutes] Mounted at ${n.pathname}`,source:"App.tsx",time:new Date().toISOString()}))}catch{}},[n.pathname]),c.jsxs(c.Fragment,{children:[c.jsx(xx,{isNavigating:e}),c.jsx(Ex,{}),c.jsx(Ax,{}),c.jsx(_x,{}),c.jsx(kx,{}),c.jsx(m.Suspense,{fallback:c.jsx(ud,{}),children:c.jsx(qm,{mode:"wait",initial:!1,children:c.jsxs(xd,{location:n,children:[c.jsx(M,{path:"/",element:c.jsx(V,{name:"Landing",children:c.jsx(Fw,{})})}),c.jsx(M,{path:"/login",element:c.jsx(V,{name:"Login",children:c.jsx(qw,{})})}),c.jsx(M,{path:"/signup",element:c.jsx(V,{name:"Signup",children:c.jsx(Ww,{})})}),c.jsx(M,{path:"/forgot-password",element:c.jsx(V,{name:"ForgotPassword",children:c.jsx(zw,{})})}),c.jsx(M,{path:"/reset-password",element:c.jsx(V,{name:"ResetPassword",children:c.jsx(Hw,{})})}),c.jsx(M,{path:"/design-system",element:c.jsx(V,{name:"DesignSystem",children:c.jsx($I,{})})}),c.jsx(M,{path:"/ui-showcase",element:c.jsx(V,{name:"UIShowcase",children:c.jsx(jI,{})})}),c.jsx(M,{path:"/features",element:c.jsx(V,{name:"Features",children:c.jsx(DI,{})})}),c.jsx(M,{path:"/technology",element:c.jsx(V,{name:"Technology",children:c.jsx(LI,{})})}),c.jsx(M,{path:"/science",element:c.jsx(V,{name:"Science",children:c.jsx(UI,{})})}),c.jsx(M,{path:"/design",element:c.jsx(V,{name:"Design",children:c.jsx(VI,{})})}),c.jsx(M,{path:"/docs",element:c.jsx(V,{name:"Docs",children:c.jsx(er,{})})}),c.jsx(M,{path:"/docs/plugins",element:c.jsx(V,{name:"PluginGuide",children:c.jsx(vx,{})})}),c.jsx(M,{path:"/docs/:docId",element:c.jsx(V,{name:"Docs",children:c.jsx(er,{})})}),c.jsx(M,{path:"/docs/*",element:c.jsx(V,{name:"Docs",children:c.jsx(er,{})})}),c.jsx(M,{path:"/privacy",element:c.jsx(V,{name:"Privacy",children:c.jsx(BI,{})})}),c.jsx(M,{path:"/skills",element:c.jsx(V,{name:"Skills",children:c.jsx(rc,{})})}),c.jsx(M,{path:"/skills/:treeId",element:c.jsx(V,{name:"Skills",children:c.jsx(rc,{})})}),c.jsx(M,{path:"/martial-arts",element:c.jsx(V,{name:"MartialArts",children:c.jsx(ic,{})})}),c.jsx(M,{path:"/martial-arts/:disciplineId",element:c.jsx(V,{name:"MartialArts",children:c.jsx(ic,{})})}),c.jsx(M,{path:"/issues",element:c.jsx(V,{name:"Issues",children:c.jsx(HI,{})})}),c.jsx(M,{path:"/issues/:id",element:c.jsx(V,{name:"IssueDetail",children:c.jsx(GI,{})})}),c.jsx(M,{path:"/updates",element:c.jsx(V,{name:"DevUpdates",children:c.jsx(QI,{})})}),c.jsx(M,{path:"/roadmap",element:c.jsx(V,{name:"Roadmap",children:c.jsx(JI,{})})}),c.jsx(M,{path:"/dashboard",element:c.jsx($,{name:"Dashboard",children:c.jsx(Gw,{})})}),c.jsx(M,{path:"/adventure-map",element:c.jsx($,{name:"AdventureMap",children:c.jsx(hx,{})})}),c.jsx(M,{path:"/explore",element:c.jsx($,{name:"MapExplore",children:c.jsx(px,{})})}),c.jsx(M,{path:"/discover",element:c.jsx($,{name:"Discover",children:c.jsx(Fn,{})})}),c.jsx(M,{path:"/discover/venue/:venueId",element:c.jsx($,{name:"Discover",children:c.jsx(Fn,{})})}),c.jsx(M,{path:"/discover/add",element:c.jsx($,{name:"Discover",children:c.jsx(Fn,{})})}),c.jsx(M,{path:"/discover/contribute",element:c.jsx($,{name:"Discover",children:c.jsx(Fn,{})})}),c.jsx(M,{path:"/onboarding",element:c.jsx($,{name:"Onboarding",children:c.jsx(Yw,{})})}),c.jsx(M,{path:"/workout",element:c.jsx($,{name:"Workout",children:c.jsx(Kw,{})})}),c.jsx(M,{path:"/log",element:c.jsx($,{name:"ActivityLog",children:c.jsx(Qw,{})})}),c.jsx(M,{path:"/journey",element:c.jsx($,{name:"Journey",children:c.jsx(Jw,{})})}),c.jsx(M,{path:"/profile",element:c.jsx($,{name:"Profile",children:c.jsx(Xw,{})})}),c.jsx(M,{path:"/settings",element:c.jsx($,{name:"Settings",children:c.jsx(Zw,{})})}),c.jsx(M,{path:"/progression",element:c.jsx($,{name:"Progression",children:c.jsx(eI,{})})}),c.jsx(M,{path:"/community",element:c.jsx($,{name:"CommunityDashboard",children:c.jsx(oI,{})})}),c.jsx(M,{path:"/competitions",element:c.jsx($,{name:"Competitions",children:c.jsx(cI,{})})}),c.jsx(M,{path:"/locations",element:c.jsx($,{name:"Locations",children:c.jsx(lI,{})})}),c.jsx(M,{path:"/highfives",element:c.jsx($,{name:"HighFives",children:c.jsx(uI,{})})}),c.jsx(M,{path:"/credits",element:c.jsx($,{name:"Credits",children:c.jsx(pI,{})})}),c.jsx(M,{path:"/messages",element:c.jsx($,{name:"Messages",children:c.jsx(dI,{})})}),c.jsx(M,{path:"/wallet",element:c.jsx($,{name:"Wallet",children:c.jsx(fI,{})})}),c.jsx(M,{path:"/skins",element:c.jsx($,{name:"SkinsStore",children:c.jsx(gI,{})})}),c.jsx(M,{path:"/trainers",element:c.jsx($,{name:"Trainers",children:c.jsx(yI,{})})}),c.jsx(M,{path:"/marketplace",element:c.jsx($,{name:"Marketplace",children:c.jsx(vI,{})})}),c.jsx(M,{path:"/trading",element:c.jsx($,{name:"Trading",children:c.jsx(SI,{})})}),c.jsx(M,{path:"/collection",element:c.jsx($,{name:"Collection",children:c.jsx(TI,{})})}),c.jsx(M,{path:"/mystery-boxes",element:c.jsx($,{name:"MysteryBoxes",children:c.jsx(bI,{})})}),c.jsx(M,{path:"/exercises",element:c.jsx($,{name:"Exercises",children:c.jsx(tI,{})})}),c.jsx(M,{path:"/stats",element:c.jsx($,{name:"Stats",children:c.jsx(nI,{})})}),c.jsx(M,{path:"/personal-records",element:c.jsx($,{name:"PersonalRecords",children:c.jsx(sI,{})})}),c.jsx(M,{path:"/progress-photos",element:c.jsx($,{name:"ProgressPhotos",children:c.jsx(rI,{})})}),c.jsx(M,{path:"/templates",element:c.jsx($,{name:"WorkoutTemplates",children:c.jsx(iI,{})})}),c.jsx(M,{path:"/body-measurements",element:c.jsx($,{name:"BodyMeasurements",children:c.jsx(aI,{})})}),c.jsx(M,{path:"/crews",element:c.jsx($,{name:"Crews",children:c.jsx(mI,{})})}),c.jsx(M,{path:"/rivals",element:c.jsx($,{name:"Rivals",children:c.jsx(hI,{})})}),c.jsx(M,{path:"/wellness",element:c.jsx($,{name:"Wellness",children:c.jsx(wI,{})})}),c.jsx(M,{path:"/health",element:c.jsx(at,{to:"/wellness",replace:!0})})," ",c.jsx(M,{path:"/recovery",element:c.jsx($,{name:"Recovery",children:c.jsx(II,{})})}),c.jsx(M,{path:"/goals",element:c.jsx($,{name:"Goals",children:c.jsx(xI,{})})}),c.jsx(M,{path:"/limitations",element:c.jsx($,{name:"Limitations",children:c.jsx(EI,{})})}),c.jsx(M,{path:"/pt-tests",element:c.jsx($,{name:"PTTests",children:c.jsx(AI,{})})}),c.jsx(M,{path:"/career-readiness",element:c.jsx($,{name:"CareerReadiness",children:c.jsx(_I,{})})}),c.jsx(M,{path:"/leaderboard",element:c.jsx($,{name:"Leaderboard",children:c.jsx(CI,{})})}),c.jsx(M,{path:"/journey-health",element:c.jsx($,{name:"JourneyHealth",children:c.jsx(kI,{})})}),c.jsx(M,{path:"/recovery-dashboard",element:c.jsx($,{name:"RecoveryDashboard",children:c.jsx(RI,{})})}),c.jsx(M,{path:"/progression-targets",element:c.jsx($,{name:"ProgressionTargets",children:c.jsx(PI,{})})}),c.jsx(M,{path:"/career",element:c.jsx($,{name:"CareerPage",children:c.jsx(MI,{})})}),c.jsx(M,{path:"/career/goals/:goalId",element:c.jsx($,{name:"CareerGoalPage",children:c.jsx(OI,{})})}),c.jsx(M,{path:"/career/standards/:standardId",element:c.jsx($,{name:"CareerStandardPage",children:c.jsx(NI,{})})}),c.jsx(M,{path:"/issues/new",element:c.jsx($,{name:"NewIssue",children:c.jsx(YI,{})})}),c.jsx(M,{path:"/my-issues",element:c.jsx($,{name:"MyIssues",children:c.jsx(KI,{})})}),c.jsx(M,{path:"/nutrition",element:c.jsx($,{name:"Nutrition",children:c.jsx(Tx,{})})}),c.jsx(M,{path:"/nutrition/settings",element:c.jsx($,{name:"NutritionSettings",children:c.jsx(bx,{})})}),c.jsx(M,{path:"/nutrition/recipes",element:c.jsx($,{name:"Recipes",children:c.jsx(ac,{})})}),c.jsx(M,{path:"/nutrition/recipes/:recipeId",element:c.jsx($,{name:"Recipes",children:c.jsx(ac,{})})}),c.jsx(M,{path:"/nutrition/plans",element:c.jsx($,{name:"MealPlans",children:c.jsx(oc,{})})}),c.jsx(M,{path:"/nutrition/plans/:planId",element:c.jsx($,{name:"MealPlans",children:c.jsx(oc,{})})}),c.jsx(M,{path:"/nutrition/plans/:planId/shopping-list",element:c.jsx($,{name:"ShoppingList",children:c.jsx(wx,{})})}),c.jsx(M,{path:"/nutrition/history",element:c.jsx($,{name:"NutritionHistory",children:c.jsx(Ix,{})})}),c.jsx(M,{path:"/milestones",element:c.jsx(at,{to:"/achievements",replace:!0})})," ",c.jsx(M,{path:"/achievements",element:c.jsx($,{name:"Achievements",children:c.jsx(FI,{})})}),c.jsx(M,{path:"/achievements/verify/:achievementId",element:c.jsx($,{name:"AchievementVerification",children:c.jsx(qI,{})})}),c.jsx(M,{path:"/achievements/my-verifications",element:c.jsx($,{name:"MyVerifications",children:c.jsx(WI,{})})}),c.jsx(M,{path:"/verifications/:verificationId/witness",element:c.jsx($,{name:"WitnessAttestation",children:c.jsx(zI,{})})}),c.jsx(M,{path:"/admin",element:c.jsx(at,{to:"/admin-control",replace:!0})})," ",c.jsx(M,{path:"/admin-control",element:c.jsx(me,{name:"AdminControl",children:c.jsx(XI,{})})}),c.jsx(M,{path:"/admin/issues",element:c.jsx(me,{name:"AdminIssues",children:c.jsx(ZI,{})})}),c.jsx(M,{path:"/admin/monitoring",element:c.jsx(me,{name:"AdminMonitoring",children:c.jsx(ex,{})})}),c.jsx(M,{path:"/admin/metrics",element:c.jsx(me,{name:"AdminMetrics",children:c.jsx(tx,{})})}),c.jsx(M,{path:"/admin/disputes",element:c.jsx(me,{name:"AdminDisputes",children:c.jsx(nx,{})})}),c.jsx(M,{path:"/admin/fraud",element:c.jsx(me,{name:"AdminFraud",children:c.jsx(sx,{})})}),c.jsx(M,{path:"/empire",element:c.jsx(me,{name:"EmpireControl",children:c.jsx(rx,{})})}),c.jsx(M,{path:"/empire/user/:userId",element:c.jsx(me,{name:"EmpireUserDetail",children:c.jsx(ix,{})})}),c.jsx(M,{path:"/empire/scorecard",element:c.jsx(me,{name:"TestScorecard",children:c.jsx(ax,{})})}),c.jsx(M,{path:"/empire/deploy",element:c.jsx(me,{name:"DeploymentControl",children:c.jsx(ox,{})})}),c.jsx(M,{path:"/empire/commands",element:c.jsx(me,{name:"CommandCenter",children:c.jsx(cx,{})})}),c.jsx(M,{path:"/empire/bugs",element:c.jsx(me,{name:"BugTracker",children:c.jsx(lx,{})})}),c.jsx(M,{path:"/empire/exercise-images",element:c.jsx(me,{name:"AdminExerciseImages",children:c.jsx(ux,{})})}),c.jsx(M,{path:"/live",element:c.jsx(V,{name:"LiveActivityMonitor",children:c.jsx(mx,{})})}),c.jsx(M,{path:"/plugins",element:c.jsx($,{name:"PluginMarketplace",children:c.jsx(fx,{})})}),c.jsx(M,{path:"/plugins/settings",element:c.jsx($,{name:"PluginSettings",children:c.jsx(gx,{})})}),c.jsx(M,{path:"/community/bulletin",element:c.jsx(V,{name:"CommunityBulletinBoard",children:c.jsx(yx,{})})}),c.jsx(M,{path:"/contribute",element:c.jsx(V,{name:"ContributeIdeas",children:c.jsx(Sx,{})})}),c.jsx(M,{path:"/dev/anatomy-viewer",element:c.jsx(me,{name:"AnatomyViewer",children:c.jsx(dx,{})})}),t.map(s=>c.jsx(M,{path:s.path,element:s.admin?c.jsx(me,{name:`Plugin:${s.pluginId}`,children:c.jsx(nr,{route:s})}):s.protected!==!1?c.jsx($,{name:`Plugin:${s.pluginId}`,children:c.jsx(nr,{route:s})}):c.jsx(V,{name:`Plugin:${s.pluginId}`,children:c.jsx(nr,{route:s})})},s.id)),c.jsx(M,{path:"*",element:c.jsx(at,{to:"/dashboard",replace:!0})})]},n.pathname)})})]})}function Mx(){const{isOpen:e,close:t,handleSelect:n}=tb(),s=Ot(),i=a=>{a.action&&typeof a.action=="function"?a.action(s):a.path&&s(a.path),n?.(a)};return c.jsx(Nw,{isOpen:e,onClose:t,onSelect:i,placeholder:"Search exercises, pages, actions...",recentSearches:!0,maxResults:6})}function Ox(){const{maxCoachVisible:e}=bw();return e?c.jsx(m.Suspense,{fallback:null,children:c.jsx(Dw,{position:"bottom-right"})}):null}function Nx(){return m.useEffect(()=>{eh(),pr();try{const n=new XMLHttpRequest;n.open("POST","/api/client-error",!0),n.setRequestHeader("Content-Type","application/json"),n.send(JSON.stringify({type:"app_mount",message:"[App] Component mounted successfully",source:"App.tsx",time:new Date().toISOString()}))}catch{}De.info("app_initialized",{version:"1.0.0",env:"production"});let e=null,t=null;if(window.performance){const n=window.performance.timing;e=()=>{t=setTimeout(()=>{const s=n.loadEventEnd-n.navigationStart,i=n.domContentLoadedEventEnd-n.navigationStart;De.performance("page_load",s,{domReady:i})},0)},window.addEventListener("load",e)}return()=>{e&&window.removeEventListener("load",e),t&&clearTimeout(t)}},[]),c.jsx(V,{name:"App",onError:e=>fe("ErrorBoundary:App",e),children:c.jsx(Od,{client:Qr,children:c.jsx(V,{name:"ThemeProvider",onError:e=>fe("ErrorBoundary:ThemeProvider",e),children:c.jsx(sp,{children:c.jsx(V,{name:"LocaleProvider",onError:e=>fe("ErrorBoundary:LocaleProvider",e),children:c.jsx(cp,{children:c.jsx(V,{name:"MotionProvider",onError:e=>fe("ErrorBoundary:MotionProvider",e),children:c.jsx(mp,{children:c.jsx(V,{name:"BrowserRouter",onError:e=>fe("ErrorBoundary:BrowserRouter",e),children:c.jsx(Id,{children:c.jsx(V,{name:"TraceProvider",onError:e=>fe("ErrorBoundary:TraceProvider",e),children:c.jsx(pw,{children:c.jsx(V,{name:"TransitionProvider",onError:e=>fe("ErrorBoundary:TransitionProvider",e),children:c.jsx(Sw,{showProgressBar:!0,children:c.jsx(V,{name:"UserProvider",onError:e=>fe("ErrorBoundary:UserProvider",e),children:c.jsx(Xh,{children:c.jsx(V,{name:"PluginProvider",onError:e=>fe("ErrorBoundary:PluginProvider",e),children:c.jsx(lw,{children:c.jsx(V,{name:"PluginThemeProvider",onError:e=>fe("ErrorBoundary:PluginThemeProvider",e),children:c.jsx(uw,{children:c.jsx(V,{name:"CommandPaletteProvider",onError:e=>fe("ErrorBoundary:CommandPaletteProvider",e),children:c.jsx(sb,{children:c.jsx(V,{name:"CompanionProvider",onError:e=>fe("ErrorBoundary:CompanionProvider",e),children:c.jsx(Mv,{children:c.jsx(V,{name:"ContextualTipProvider",onError:e=>fe("ErrorBoundary:ContextualTipProvider",e),children:c.jsxs(Ob,{children:[c.jsx("div",{id:"main-content",role:"main",children:c.jsx(Px,{})}),c.jsx(m.Suspense,{fallback:null,children:c.jsx(Ow,{})}),c.jsx(m.Suspense,{fallback:null,children:c.jsx(Mx,{})}),c.jsx(m.Suspense,{fallback:null,children:c.jsx($w,{})}),c.jsx(Ox,{}),c.jsx(m.Suspense,{fallback:null,children:c.jsx(jw,{})}),c.jsx(m.Suspense,{fallback:null,children:c.jsx(Lw,{enabled:!0})}),c.jsx(m.Suspense,{fallback:null,children:c.jsx(Uw,{position:"top",showQuality:!0})}),c.jsx(m.Suspense,{fallback:null,children:c.jsx(Vw,{})}),c.jsx(m.Suspense,{fallback:null,children:c.jsx(Bw,{position:"top"})})]})})})})})})})})})})})})})})})})})})})})})})})})})})}let md=-1;const jt=e=>{addEventListener("pageshow",t=>{t.persisted&&(md=t.timeStamp,e(t))},!0)},je=(e,t,n,s)=>{let i,a;return o=>{t.value>=0&&(o||s)&&(a=t.value-(i??0),(a||i===void 0)&&(i=t.value,t.delta=a,t.rating=((l,u)=>l>u[1]?"poor":l>u[0]?"needs-improvement":"good")(t.value,n),e(t)))}},Fi=e=>{requestAnimationFrame(()=>requestAnimationFrame(()=>e()))},qi=()=>{const e=performance.getEntriesByType("navigation")[0];if(e&&e.responseStart>0&&e.responseStart<performance.now())return e},kn=()=>qi()?.activationStart??0,Le=(e,t=-1)=>{const n=qi();let s="navigate";return md>=0?s="back-forward-cache":n&&(document.prerendering||kn()>0?s="prerender":document.wasDiscarded?s="restore":n.type&&(s=n.type.replace(/_/g,"-"))),{name:e,value:t,rating:"good",delta:0,entries:[],id:`v5-${Date.now()}-${Math.floor(8999999999999*Math.random())+1e12}`,navigationType:s}},sr=new WeakMap;function Wi(e,t){return sr.get(e)||sr.set(e,new t),sr.get(e)}class $x{t;i=0;o=[];h(t){if(t.hadRecentInput)return;const n=this.o[0],s=this.o.at(-1);this.i&&n&&s&&t.startTime-s.startTime<1e3&&t.startTime-n.startTime<5e3?(this.i+=t.value,this.o.push(t)):(this.i=t.value,this.o=[t]),this.t?.(t)}}const Rn=(e,t,n={})=>{try{if(PerformanceObserver.supportedEntryTypes.includes(e)){const s=new PerformanceObserver(i=>{Promise.resolve().then(()=>{t(i.getEntries())})});return s.observe({type:e,buffered:!0,...n}),s}}catch{}},zi=e=>{let t=!1;return()=>{t||(e(),t=!0)}};let It=-1;const hd=new Set,cc=()=>document.visibilityState!=="hidden"||document.prerendering?1/0:0,Wr=e=>{if(document.visibilityState==="hidden"){if(e.type==="visibilitychange")for(const t of hd)t();isFinite(It)||(It=e.type==="visibilitychange"?e.timeStamp:0,removeEventListener("prerenderingchange",Wr,!0))}},vs=()=>{if(It<0){const e=kn();It=(document.prerendering?void 0:globalThis.performance.getEntriesByType("visibility-state").filter(n=>n.name==="hidden"&&n.startTime>e)[0]?.startTime)??cc(),addEventListener("visibilitychange",Wr,!0),addEventListener("prerenderingchange",Wr,!0),jt(()=>{setTimeout(()=>{It=cc()})})}return{get firstHiddenTime(){return It},onHidden(e){hd.add(e)}}},Ss=e=>{document.prerendering?addEventListener("prerenderingchange",()=>e(),!0):e()},lc=[1800,3e3],pd=(e,t={})=>{Ss(()=>{const n=vs();let s,i=Le("FCP");const a=Rn("paint",o=>{for(const l of o)l.name==="first-contentful-paint"&&(a.disconnect(),l.startTime<n.firstHiddenTime&&(i.value=Math.max(l.startTime-kn(),0),i.entries.push(l),s(!0)))});a&&(s=je(e,i,lc,t.reportAllChanges),jt(o=>{i=Le("FCP"),s=je(e,i,lc,t.reportAllChanges),Fi(()=>{i.value=performance.now()-o.timeStamp,s(!0)})}))})},uc=[.1,.25],Dx=(e,t={})=>{const n=vs();pd(zi(()=>{let s,i=Le("CLS",0);const a=Wi(t,$x),o=u=>{for(const d of u)a.h(d);a.i>i.value&&(i.value=a.i,i.entries=a.o,s())},l=Rn("layout-shift",o);l&&(s=je(e,i,uc,t.reportAllChanges),n.onHidden(()=>{o(l.takeRecords()),s(!0)}),jt(()=>{a.i=0,i=Le("CLS",0),s=je(e,i,uc,t.reportAllChanges),Fi(()=>s())}),setTimeout(s))}))};let fd=0,rr=1/0,qn=0;const jx=e=>{for(const t of e)t.interactionId&&(rr=Math.min(rr,t.interactionId),qn=Math.max(qn,t.interactionId),fd=qn?(qn-rr)/7+1:0)};let zr;const dc=()=>zr?fd:performance.interactionCount??0,Lx=()=>{"interactionCount"in performance||zr||(zr=Rn("event",jx,{type:"event",buffered:!0,durationThreshold:0}))};let mc=0;class Ux{u=[];l=new Map;m;p;v(){mc=dc(),this.u.length=0,this.l.clear()}L(){const t=Math.min(this.u.length-1,Math.floor((dc()-mc)/50));return this.u[t]}h(t){if(this.m?.(t),!t.interactionId&&t.entryType!=="first-input")return;const n=this.u.at(-1);let s=this.l.get(t.interactionId);if(s||this.u.length<10||t.duration>n.P){if(s?t.duration>s.P?(s.entries=[t],s.P=t.duration):t.duration===s.P&&t.startTime===s.entries[0].startTime&&s.entries.push(t):(s={id:t.interactionId,entries:[t],P:t.duration},this.l.set(s.id,s),this.u.push(s)),this.u.sort((i,a)=>a.P-i.P),this.u.length>10){const i=this.u.splice(10);for(const a of i)this.l.delete(a.id)}this.p?.(s)}}}const gd=e=>{const t=globalThis.requestIdleCallback||setTimeout;document.visibilityState==="hidden"?e():(e=zi(e),addEventListener("visibilitychange",e,{once:!0,capture:!0}),t(()=>{e(),removeEventListener("visibilitychange",e,{capture:!0})}))},hc=[200,500],Vx=(e,t={})=>{if(!globalThis.PerformanceEventTiming||!("interactionId"in PerformanceEventTiming.prototype))return;const n=vs();Ss(()=>{Lx();let s,i=Le("INP");const a=Wi(t,Ux),o=u=>{gd(()=>{for(const h of u)a.h(h);const d=a.L();d&&d.P!==i.value&&(i.value=d.P,i.entries=d.entries,s())})},l=Rn("event",o,{durationThreshold:t.durationThreshold??40});s=je(e,i,hc,t.reportAllChanges),l&&(l.observe({type:"first-input",buffered:!0}),n.onHidden(()=>{o(l.takeRecords()),s(!0)}),jt(()=>{a.v(),i=Le("INP"),s=je(e,i,hc,t.reportAllChanges)}))})};class Bx{m;h(t){this.m?.(t)}}const pc=[2500,4e3],Fx=(e,t={})=>{Ss(()=>{const n=vs();let s,i=Le("LCP");const a=Wi(t,Bx),o=u=>{t.reportAllChanges||(u=u.slice(-1));for(const d of u)a.h(d),d.startTime<n.firstHiddenTime&&(i.value=Math.max(d.startTime-kn(),0),i.entries=[d],s())},l=Rn("largest-contentful-paint",o);if(l){s=je(e,i,pc,t.reportAllChanges);const u=zi(()=>{o(l.takeRecords()),l.disconnect(),s(!0)}),d=h=>{h.isTrusted&&(gd(u),removeEventListener(h.type,d,{capture:!0}))};for(const h of["keydown","click","visibilitychange"])addEventListener(h,d,{capture:!0});jt(h=>{i=Le("LCP"),s=je(e,i,pc,t.reportAllChanges),Fi(()=>{i.value=performance.now()-h.timeStamp,s(!0)})})}})},fc=[800,1800],Hr=e=>{document.prerendering?Ss(()=>Hr(e)):document.readyState!=="complete"?addEventListener("load",()=>Hr(e),!0):setTimeout(e)},qx=(e,t={})=>{let n=Le("TTFB"),s=je(e,n,fc,t.reportAllChanges);Hr(()=>{const i=qi();i&&(n.value=Math.max(i.responseStart-kn(),0),n.entries=[i],s(!0),jt(()=>{n=Le("TTFB",0),s=je(e,n,fc,t.reportAllChanges),s(!0)}))})},gc="/api/vitals";function Ht(e){const t=JSON.stringify({metric:e.name,value:Math.round(e.name==="CLS"?e.delta*1e3:e.delta),rating:e.rating,id:e.id,navigationType:e.navigationType,page:window.location.pathname,timestamp:Date.now(),...e.attribution&&{attribution:{element:e.attribution.element,largestShiftTarget:e.attribution.largestShiftTarget,largestShiftTime:e.attribution.largestShiftTime}}});if(navigator.sendBeacon){const n=new Blob([t],{type:"application/json"});navigator.sendBeacon(gc,n)}else fetch(gc,{method:"POST",body:t,headers:{"Content-Type":"application/json"},keepalive:!0}).catch(()=>{})}function Wx(){Dx(Ht),Vx(Ht),Fx(Ht),pd(Ht),qx(Ht)}function yd(){return"serviceWorker"in navigator}let ir=null;async function zx(){if(!yd())return null;try{const e=await navigator.serviceWorker.register("/sw.js",{scope:"/",updateViaCache:"none"});return e.addEventListener("updatefound",()=>{const t=e.installing;t&&t.addEventListener("statechange",()=>{t.state==="installed"&&navigator.serviceWorker.controller&&Hx(e)})}),ir&&clearInterval(ir),ir=setInterval(()=>{e.update()},60*60*1e3),e}catch{return null}}function Hx(e){window.dispatchEvent(new CustomEvent("sw-update-available",{detail:{registration:e}})),e.waiting&&e.waiting.postMessage({type:"SKIP_WAITING"})}function Gx(){if(!yd())return;let e=!1;navigator.serviceWorker.addEventListener("controllerchange",()=>{e||(e=!0,window.location.reload())})}const Yx=.8,Kx=.95,Qx=30;function Hi(){try{return!(typeof indexedDB>"u"||indexedDB===null||typeof IDBFactory>"u")}catch{return!1}}async function Jx(){try{if(navigator.storage?.estimate){const{usage:e,quota:t}=await navigator.storage.estimate();return{usage:e,quota:t,usageMB:(e/(1024*1024)).toFixed(2),quotaMB:(t/(1024*1024)).toFixed(2),percentUsed:(e/t*100).toFixed(1),isWarning:e/t>Yx,isCritical:e/t>Kx}}}catch{}return null}async function Xx(){try{if(navigator.storage?.persist)return await navigator.storage.persisted()?!0:await navigator.storage.persist()}catch{}return!1}async function Zx(){if(!Hi())return{pruned:!1,level:"unavailable"};const e=await Jx();return e?e.isCritical?(await yc(7),{pruned:!0,level:"critical"}):e.isWarning?(await yc(Qx),{pruned:!0,level:"warning"}):{pruned:!1,level:"ok"}:{pruned:!1}}async function yc(e){if(!Hi())return;const t=new Date;t.setDate(t.getDate()-e);try{await eE(t),await tE(e),await nE(t)}catch{}}async function Gi(e,t){if(!Hi())return null;try{if(!(await indexedDB.databases?.()||[]).some(a=>a.name===e))return null;const{openDB:i}=await E(async()=>{const{openDB:a}=await import("./index-n74ppay5.js");return{openDB:a}},[]);return await i(e,t)}catch{return null}}async function eE(e){try{const t=await Gi("musclemap-offline",1);if(!t||!t.objectStoreNames.contains("queue"))return;const n=t.transaction("queue","readwrite"),s=n.objectStore("queue"),i=await s.getAll();let a=0;for(const o of i)new Date(o.timestamp||o.createdAt)<e&&(await s.delete(o.id),a++);await n.done}catch{}}async function tE(e){try{const n=await Gi("musclemap-cache",1);if(!n||!n.objectStoreNames.contains("workouts"))return;const s=n.transaction("workouts","readwrite"),i=s.objectStore("workouts"),o=(await i.getAll()).sort((l,u)=>{const d=new Date(l.completedAt||l.createdAt);return new Date(u.completedAt||u.createdAt).getTime()-d.getTime()});if(o.length>100){const l=o.slice(100);for(const u of l)await i.delete(u.id)}await s.done}catch{}}async function nE(e){try{const t=await Gi("musclemap-multi-cache",1);if(!t||!t.objectStoreNames.contains("entries"))return;const n=t.transaction("entries","readwrite"),s=n.objectStore("entries"),i=await s.getAll();let a=0;for(const o of i){const l=new Date(o.timestamp||o.createdAt),u=o.expiresAt&&new Date(o.expiresAt)<new Date,d=l<e;(u||d)&&(await s.delete(o.key),a++)}await n.done}catch{}}const q=(e,t,n)=>{const s=n instanceof Error?n.message:n?String(n):"",i=`[${e}] ${t}${s?": "+s:""}`;if(n&&n)try{const a=new XMLHttpRequest;a.open("POST","/api/client-error",!0),a.setRequestHeader("Content-Type","application/json"),a.send(JSON.stringify({type:"boot_error",message:i,source:"main.tsx",line:0,col:0,stack:n instanceof Error?n.stack:"No stack trace",time:new Date().toISOString(),extra:{phase:e,msg:t,error:s}}))}catch{}};q("init","Module imports completed successfully");function At(e,t){const n={phase:e,message:t instanceof Error?t.message:String(t),stack:t instanceof Error?t.stack:void 0,userAgent:navigator.userAgent,timestamp:new Date().toISOString()};try{fetch("/api/trace/frontend-log",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({entries:[{level:"error",type:"boot_error",data:n,sessionId:"boot_"+Date.now().toString(36),url:window.location.pathname,userAgent:navigator.userAgent,screenWidth:window.innerWidth,screenHeight:window.innerHeight,timestamp:new Date().toISOString(),userId:null}]}),keepalive:!0}).catch(()=>{})}catch{}}const sE={async getItem(e){try{q("storage",`Getting item: ${e}`);const t=de.getItem("musclemap-auth");if(!t)return q("storage",`No auth data found for ${e}`),null;const s=JSON.parse(t)?.state;return s?e==="musclemap_token"?s.token||null:e==="musclemap_user"&&s.user?JSON.stringify(s.user):null:(q("storage",`No state in auth data for ${e}`),null)}catch(t){return q("storage",`Error getting ${e}`,t),null}},async setItem(){},async removeItem(){},async clear(){}};try{q("config","Setting storage adapter"),Dd(sE),q("config","Storage adapter set")}catch(e){q("config","FAILED to set storage adapter",e)}try{q("config","Configuring HTTP client"),Hd({baseUrl:"/api",onUnauthorized:()=>{de.removeItem("musclemap-auth"),window.location.href="/login"}}),q("config","HTTP client configured")}catch(e){q("config","FAILED to configure HTTP client",e)}function vd(){try{q("render","Starting render");const e=document.getElementById("root");if(!e){At("render",new Error("Root element not found"));return}q("render","Root element found"),q("render","Creating React root");const t=Ed.createRoot(e);q("render","Rendering App component"),t.render(c.jsx($e.StrictMode,{children:c.jsx(Nx,{})})),q("render","Render completed")}catch(e){At("render",e),q("render","FAILED",e);const t=document.getElementById("root");t&&(t.innerHTML=`
        <div style="min-height:100vh;display:flex;flex-direction:column;align-items:center;justify-content:center;background:#0a0a0f;color:white;padding:20px;text-align:center;font-family:system-ui,sans-serif;">
          <h1 style="font-size:24px;margin-bottom:16px;">Something went wrong</h1>
          <p style="color:#999;margin-bottom:20px;">We're having trouble loading MuscleMap.</p>
          <button onclick="window.location.reload()" style="background:#6366f1;color:white;border:none;padding:12px 24px;border-radius:8px;font-size:16px;cursor:pointer;">
            Reload Page
          </button>
          <p style="color:#666;font-size:12px;margin-top:20px;">Error: ${e instanceof Error?e.message:"Unknown error"}</p>
        </div>
      `)}}async function rE(){q("init","Starting app initialization");try{q("init","Requesting persistent storage"),await Xx(),q("init","Persistent storage requested")}catch(e){At("requestPersistentStorage",e),q("init","Persistent storage request failed (non-fatal)",e)}try{q("init","Initializing Apollo cache"),await Sh(),q("init","Apollo cache initialized")}catch(e){At("initializeApolloCache",e),q("init","Apollo cache init failed (non-fatal)",e)}try{q("init","Checking and pruning storage"),await Zx(),q("init","Storage pruned")}catch(e){At("checkAndPruneStorage",e),q("init","Storage prune failed (non-fatal)",e)}q("init","Initialization complete, rendering app"),vd()}q("init","Calling initializeApp");rE().catch(e=>{At("initializeApp",e),q("init","initializeApp failed, rendering anyway",e),vd()});q("vitals","Setting up production web vitals"),Wx();q("sw","Registering service worker"),zx(),Gx();q("init","main.tsx execution complete");export{hE as $,Ct as A,oS as B,Lo as C,Oi as D,jr as E,hk as F,ek as G,pk as H,De as I,mk as J,lk as K,z_ as L,U_ as M,QS as N,Mi as O,XS as P,Ou as Q,W_ as R,ZC as S,PE as T,$i as U,bE as V,ik as W,Di as X,cA as Y,ji as Z,E as _,xm as a,A_ as a$,$E as a0,AC as a1,ms as a2,NS as a3,WC as a4,ME as a5,OE as a6,pE as a7,NE as a8,J_ as a9,Q_ as aA,TE as aB,SE as aC,p_ as aD,f_ as aE,g_ as aF,_C as aG,re as aH,ak as aI,cT as aJ,Ik as aK,d_ as aL,m_ as aM,h_ as aN,xC as aO,EC as aP,R_ as aQ,P_ as aR,M_ as aS,O_ as aT,BC as aU,wE as aV,IE as aW,IC as aX,xE as aY,uA as aZ,Eb as a_,X_ as aa,Z_ as ab,e1 as ac,t1 as ad,n1 as ae,s1 as af,r1 as ag,i1 as ah,S as ai,ok as aj,Vu as ak,_S as al,LS as am,Du as an,Ni as ao,Nu as ap,Mu as aq,WS as ar,mE as as,H_ as at,N1 as au,qC as av,ck as aw,Bu as ax,uS as ay,vE as az,xk as b,af as b$,__ as b0,NC as b1,$C as b2,YA as b3,KA as b4,GA as b5,$1 as b6,D1 as b7,j1 as b8,L1 as b9,LC as bA,UC as bB,ze as bC,bk as bD,Zr as bE,iu as bF,ey as bG,Pr as bH,Yv as bI,V_ as bJ,ht as bK,Jr as bL,ln as bM,ds as bN,wn as bO,Wc as bP,gk as bQ,vk as bR,fk as bS,Tk as bT,Vb as bU,Sk as bV,yk as bW,Zf as bX,Vl as bY,G as bZ,Xe as b_,U1 as ba,V1 as bb,dT as bc,Qv as bd,EE as be,AE as bf,_E as bg,TC as bh,bC as bi,wC as bj,rT as bk,CE as bl,kE as bm,dE as bn,pA as bo,dn as bp,VC as bq,Ke as br,fA as bs,gA as bt,B1 as bu,F1 as bv,D_ as bw,j_ as bx,L_ as by,jC as bz,Vc as c,dA as c$,mn as c0,el as c1,Dl as c2,cf as c3,qe as c4,xe as c5,ce as c6,Ef as c7,Qc as c8,si as c9,v1 as cA,S1 as cB,T1 as cC,w1 as cD,E1 as cE,A1 as cF,jE as cG,qE as cH,BE as cI,x1 as cJ,FE as cK,I1 as cL,b1 as cM,TA as cN,bA as cO,wA as cP,G1 as cQ,Y1 as cR,yA as cS,vA as cT,q1 as cU,W1 as cV,z1 as cW,H1 as cX,SA as cY,lA as cZ,RE as c_,_t as ca,bi as cb,Ua as cc,V as cd,y_ as ce,v_ as cf,S_ as cg,T_ as ch,CC as ci,DE as cj,LE as ck,UE as cl,WE as cm,VE as cn,a1 as co,o1 as cp,c1 as cq,u1 as cr,l1 as cs,d1 as ct,m1 as cu,h1 as cv,p1 as cw,f1 as cx,g1 as cy,y1 as cz,Iv as d,PC as d$,mA as d0,kC as d1,qA as d2,WA as d3,zA as d4,HA as d5,fC as d6,gC as d7,yC as d8,IA as d9,PA as dA,MA as dB,OA as dC,tC as dD,nC as dE,sC as dF,rC as dG,VA as dH,FA as dI,BA as dJ,pC as dK,C_ as dL,k_ as dM,DC as dN,JA as dO,t_ as dP,QA as dQ,vC as dR,SC as dS,fE as dT,gE as dU,G_ as dV,Y_ as dW,K_ as dX,b_ as dY,w_ as dZ,RC as d_,xA as da,EA as db,AA as dc,_A as dd,K1 as de,Q1 as df,J1 as dg,X1 as dh,NA as di,$A as dj,DA as dk,iC as dl,aC as dm,oC as dn,cC as dp,jA as dq,LA as dr,UA as ds,uC as dt,dC as du,mC as dv,kA as dw,lC as dx,CA as dy,RA as dz,Zh as e,YS as e$,MC as e0,I_ as e1,x_ as e2,E_ as e3,OC as e4,i_ as e5,a_ as e6,n_ as e7,r_ as e8,o_ as e9,aA as eA,M1 as eB,O1 as eC,KE as eD,QE as eE,JE as eF,XE as eG,hC as eH,zE as eI,HE as eJ,GE as eK,C1 as eL,_1 as eM,YE as eN,k1 as eO,xS as eP,kS as eQ,yS as eR,Uu as eS,ET as eT,vT as eU,fS as eV,wT as eW,hA as eX,Zv as eY,Lu as eZ,rk as e_,Z1 as ea,yE as eb,B_ as ec,F_ as ed,q_ as ee,ju as ef,XA as eg,ZA as eh,e_ as ei,N_ as ej,$_ as ek,c_ as el,l_ as em,u_ as en,eC as eo,s_ as ep,ZE as eq,nA as er,eA as es,tA as et,R1 as eu,P1 as ev,rA as ew,sA as ex,iA as ey,oA as ez,nk as f,Ql as f$,eT as f0,ub as f1,Ue as f2,wk as f3,Tp as f4,Rf as f5,El as f6,Oa as f7,ul as f8,ri as f9,cy as fA,H0 as fB,N0 as fC,Iy as fD,dy as fE,K as fF,Qp as fG,of as fH,_l as fI,sy as fJ,ne as fK,cg as fL,oy as fM,iy as fN,ty as fO,n0 as fP,uu as fQ,Xn as fR,pf as fS,xn as fT,yn as fU,Bg as fV,Fs as fW,We as fX,qg as fY,Cf as fZ,lu as f_,$l as fa,vi as fb,$t as fc,Dt as fd,tg as fe,If as ff,L as fg,Me as fh,ut as fi,Ia as fj,ue as fk,ps as fl,yi as fm,Oe as fn,kf as fo,Al as fp,Si as fq,ni as fr,$n as fs,Xr as ft,vg as fu,Fl as fv,Tg as fw,Kg as fx,z0 as fy,Oy as fz,xv as g,YC as g$,fs as g0,zC as g1,pg as g2,fg as g3,nn as g4,Ny as g5,pe as g6,bg as g7,ei as g8,mg as g9,An as gA,vp as gB,ll as gC,Sp as gD,nl as gE,sl as gF,Vf as gG,GC as gH,Of as gI,kl as gJ,Ff as gK,ci as gL,li as gM,_r as gN,Sr as gO,uf as gP,tn as gQ,hi as gR,Jn as gS,Xf as gT,gi as gU,wf as gV,lf as gW,Gt as gX,Lf as gY,Tl as gZ,dl as g_,Gn as ga,KC as gb,Bl as gc,Zn as gd,QC as ge,_g as gf,Xl as gg,Zl as gh,i0 as gi,oo as gj,By as gk,ti as gl,HC as gm,Jc as gn,Xc as go,Zc as gp,En as gq,ii as gr,Ie as gs,al as gt,ai as gu,il as gv,rl as gw,oi as gx,cl as gy,ol as gz,Un as h,ge as h0,jl as h1,Ae as h2,ng as h3,sg as h4,og as h5,Ul as h6,Ti as h7,wr as h8,Ir as h9,Yf as hA,hn as hB,Nt as hC,Dn as hD,Ge as hE,Ne as hF,xa as hG,Mp as hH,Op as hI,Pl as hJ,Nl as hK,ug as hL,ks as hM,XC as hN,Ov as hO,$v as hP,nT as hQ,yf as ha,xf as hb,Rl as hc,Sl as hd,_a as he,Ms as hf,mi as hg,vl as hh,Yp as hi,Hp as hj,Qn as hk,yr as hl,Wp as hm,Af as hn,te as ho,gr as hp,gt as hq,Bp as hr,Rs as hs,ot as ht,pn as hu,Ze as hv,Ml as hw,Da as hx,Kf as hy,Ol as hz,D as i,uk as j,ns as k,Nb as l,B as m,dk as n,tS as o,ss as p,FS as q,_v as r,tk as s,sk as t,FC as u,$u as v,DS as w,sS as x,xb as y,ow as z};
