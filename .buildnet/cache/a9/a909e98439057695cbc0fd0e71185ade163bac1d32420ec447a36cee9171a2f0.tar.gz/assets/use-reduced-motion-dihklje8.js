import{r as o}from"./react-vendor-jlwrghqw.js";import{bF as r,bG as t,bH as s}from"./index-jpts4ub0.js";function i(){!r.current&&t();const[e]=o.useState(s.current);return e}export{i as u};
