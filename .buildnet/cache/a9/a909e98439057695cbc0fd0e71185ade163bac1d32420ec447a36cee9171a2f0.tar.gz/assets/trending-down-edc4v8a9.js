import{i as n}from"./index-jpts4ub0.js";const o=[["path",{d:"M16 17h6v-6",key:"t6n2it"}],["path",{d:"m22 17-8.5-8.5-5 5L2 7",key:"x473p"}]],e=n("trending-down",o);export{e as T};
