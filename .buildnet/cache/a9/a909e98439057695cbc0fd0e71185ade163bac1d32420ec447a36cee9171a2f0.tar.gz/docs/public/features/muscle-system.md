# Muscle Tracking System

A deep dive into how MuscleMap tracks and visualizes your muscle training.

## The 3D Muscle Model

MuscleMap tracks **40+ individual muscles** across your entire body:

```
                          MUSCLE GROUPS OVERVIEW
═══════════════════════════════════════════════════════════════════════════

                              FRONT VIEW
                            ┌───────────┐
                            │   HEAD    │
                            └─────┬─────┘
                                  │
                    ┌─────────────┼─────────────┐
                    │                           │
              ┌─────┴─────┐               ┌─────┴─────┐
              │  ANTERIOR │               │  ANTERIOR │
              │  DELTOID  │               │  DELTOID  │
              └─────┬─────┘               └─────┬─────┘
                    │       ┌───────┐           │
              ┌─────┴─────┐ │ PECS  │ ┌─────────┴───┐
              │  BICEPS   │ │       │ │   BICEPS    │
              │           │ └───┬───┘ │             │
              └─────┬─────┘     │     └─────┬───────┘
                    │     ┌─────┴─────┐     │
              ┌─────┴─────┤   ABS     ├─────┴─────┐
              │ FOREARMS  │  OBLIQUES │ FOREARMS  │
              └─────┬─────┴───────────┴─────┬─────┘
                    │                       │
              ┌─────┴─────────────────────┴─────┐
              │           HIP FLEXORS           │
              └─────┬─────────────────────┬─────┘
                    │                     │
              ┌─────┴─────┐         ┌─────┴─────┐
              │   QUADS   │         │   QUADS   │
              │           │         │           │
              │ • Rectus  │         │ • Rectus  │
              │ • Vastus  │         │ • Vastus  │
              │   Lat/Med │         │   Lat/Med │
              └─────┬─────┘         └─────┬─────┘
                    │                     │
              ┌─────┴─────┐         ┌─────┴─────┐
              │   CALVES  │         │   CALVES  │
              └───────────┘         └───────────┘


                              BACK VIEW
                            ┌───────────┐
                            │   NECK    │
                            └─────┬─────┘
                                  │
                    ┌─────────────┼─────────────┐
              ┌─────┴─────┐  ┌────┴────┐  ┌─────┴─────┐
              │ POSTERIOR │  │  TRAPS  │  │ POSTERIOR │
              │  DELTOID  │  └────┬────┘  │  DELTOID  │
              └─────┬─────┘       │       └─────┬─────┘
                    │       ┌─────┴─────┐       │
              ┌─────┴─────┐ │   LATS    │ ┌─────┴─────┐
              │  TRICEPS  │ │           │ │  TRICEPS  │
              │           │ │ RHOMBOIDS │ │           │
              └─────┬─────┘ └─────┬─────┘ └─────┬─────┘
                    │             │             │
              ┌─────┴─────┐ ┌─────┴─────┐ ┌─────┴─────┐
              │ FOREARMS  │ │  ERECTOR  │ │ FOREARMS  │
              └───────────┘ │  SPINAE   │ └───────────┘
                            └─────┬─────┘
                                  │
                            ┌─────┴─────┐
                            │  GLUTES   │
                            └─────┬─────┘
                                  │
                    ┌─────────────┼─────────────┐
              ┌─────┴─────┐             ┌───────┴───┐
              │HAMSTRINGS │             │HAMSTRINGS │
              │           │             │           │
              │ • Biceps  │             │ • Biceps  │
              │   Femoris │             │   Femoris │
              │ • Semi-   │             │ • Semi-   │
              │   tendin. │             │   tendin. │
              └─────┬─────┘             └─────┬─────┘
                    │                         │
              ┌─────┴─────┐             ┌─────┴─────┐
              │   CALVES  │             │   CALVES  │
              │ • Gastroc │             │ • Gastroc │
              │ • Soleus  │             │ • Soleus  │
              └───────────┘             └───────────┘

═══════════════════════════════════════════════════════════════════════════
```

---

## Complete Muscle List

### Upper Body

| Muscle Group | Individual Muscles | Bias Weight |
|--------------|-------------------|-------------|
| **Chest** | Pectoralis Major, Pectoralis Minor | 8-10 |
| **Back** | Latissimus Dorsi, Trapezius (Upper/Mid/Lower), Rhomboids, Erector Spinae | 6-10 |
| **Shoulders** | Anterior Deltoid, Lateral Deltoid, Posterior Deltoid | 10-14 |
| **Biceps** | Biceps Brachii (Long/Short Head), Brachialis | 14-18 |
| **Triceps** | Triceps Brachii (Long/Lateral/Medial Head) | 14-18 |
| **Forearms** | Flexors, Extensors, Brachioradialis | 18-22 |

### Core

| Muscle Group | Individual Muscles | Bias Weight |
|--------------|-------------------|-------------|
| **Abs** | Rectus Abdominis, Transverse Abdominis | 10-14 |
| **Obliques** | External Obliques, Internal Obliques | 12-16 |
| **Lower Back** | Erector Spinae, Quadratus Lumborum | 8-12 |

### Lower Body

| Muscle Group | Individual Muscles | Bias Weight |
|--------------|-------------------|-------------|
| **Quadriceps** | Rectus Femoris, Vastus Lateralis, Vastus Medialis, Vastus Intermedius | 4-6 |
| **Hamstrings** | Biceps Femoris, Semimembranosus, Semitendinosus | 6-8 |
| **Glutes** | Gluteus Maximus, Gluteus Medius, Gluteus Minimus | 4-6 |
| **Calves** | Gastrocnemius, Soleus | 16-20 |
| **Hip Flexors** | Iliopsoas, Rectus Femoris | 14-18 |

---

## How Activation Works

Every exercise in our database has researched muscle activation percentages:

```
EXAMPLE: BARBELL BENCH PRESS
═══════════════════════════════════════════════════════════════════════════

    PRIMARY MUSCLES (>50% activation):
    ───────────────────────────────────────────────────────────────────────
    Pectoralis Major    ████████████████████████████████████████░░░░  80%

    SECONDARY MUSCLES (25-50% activation):
    ───────────────────────────────────────────────────────────────────────
    Anterior Deltoid    ████████████████████████████░░░░░░░░░░░░░░░░  60%
    Triceps Brachii     ██████████████████████████░░░░░░░░░░░░░░░░░░  50%

    TERTIARY MUSCLES (<25% activation):
    ───────────────────────────────────────────────────────────────────────
    Serratus Anterior   ███████████████░░░░░░░░░░░░░░░░░░░░░░░░░░░░░  30%
    Biceps (Stabilizer) ████████░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░  15%

═══════════════════════════════════════════════════════════════════════════


EXAMPLE: BARBELL SQUAT
═══════════════════════════════════════════════════════════════════════════

    PRIMARY MUSCLES (>50% activation):
    ───────────────────────────────────────────────────────────────────────
    Quadriceps          ██████████████████████████████████████████░░  85%
    Gluteus Maximus     ████████████████████████████████████░░░░░░░░  70%

    SECONDARY MUSCLES (25-50% activation):
    ───────────────────────────────────────────────────────────────────────
    Hamstrings          ██████████████████████████░░░░░░░░░░░░░░░░░░  50%
    Erector Spinae      ████████████████████████░░░░░░░░░░░░░░░░░░░░  45%

    TERTIARY MUSCLES (<25% activation):
    ───────────────────────────────────────────────────────────────────────
    Calves              ████████████░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░  25%
    Core (Stabilizers)  ███████████░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░  20%

═══════════════════════════════════════════════════════════════════════════
```

---

## Training Units (TU) Explained

### What is TU?

**Training Units (TU)** is MuscleMap's proprietary metric that normalizes work across different muscles and exercises. This allows you to compare "apples to apples" across your training.

### The Problem TU Solves

```
WITHOUT TU:                              WITH TU:
═══════════════════                      ═══════════════════════

Bench Press: 100 kg x 10 = ???           Bench Press: 45 TU
Bicep Curl:  15 kg x 12 = ???            Bicep Curl:  18 TU
Squat:       120 kg x 8 = ???            Squat:       72 TU

How do you compare these?                Now you can compare!
```

### How TU is Calculated

```
TU = Volume × Activation × Bias

WHERE:
───────────────────────────────────────────────────────────────────────────
Volume     = Sets × Reps × Weight Factor
Activation = Percentage of muscle activation (0-100%)
Bias       = Muscle-specific multiplier (accounts for size/recovery)
```

### Bias Weights Explained

Larger muscles need more volume; smaller muscles need less:

```
BIAS WEIGHT SPECTRUM
═══════════════════════════════════════════════════════════════════════════

LOW BIAS (4-8)                    HIGH BIAS (16-22)
Large Muscles                     Small Muscles
Need more volume                  Need less volume
Recover slower                    Recover faster

├────────────┬────────────┬────────────┬────────────┬────────────┤
4           8            12           16           20           22

QUADS      BACK         CHEST       BICEPS      FOREARMS
GLUTES     HAMSTRINGS   SHOULDERS   TRICEPS     CALVES
           LATS         ABS

Example:
• 100 TU of quad work = A LOT of squats/leg press
• 100 TU of bicep work = Moderate curls
• 100 TU of forearm work = Minimal grip work

This ensures balanced development across all muscle groups!
═══════════════════════════════════════════════════════════════════════════
```

---

## Muscle Balance Tracking

MuscleMap tracks your muscle balance over time:

```
YOUR MUSCLE BALANCE (Last 30 Days)
═══════════════════════════════════════════════════════════════════════════

UPPER BODY:
───────────────────────────────────────────────────────────────────────────
Chest           ████████████████████████████████████████░░░░  89%   ✓ Good
Back            ██████████████████████████████████░░░░░░░░░░  78%   ✓ Good
Shoulders       ██████████████████████████░░░░░░░░░░░░░░░░░░  65%   ⚠ Needs work
Biceps          ████████████████████████████████░░░░░░░░░░░░  72%   ✓ Good
Triceps         ██████████████████████████████░░░░░░░░░░░░░░  68%   ✓ Good

CORE:
───────────────────────────────────────────────────────────────────────────
Abs             ████████████████████████░░░░░░░░░░░░░░░░░░░░  58%   ⚠ Needs work
Obliques        ██████████████████░░░░░░░░░░░░░░░░░░░░░░░░░░  42%   ⚠ Needs work
Lower Back      ████████████████████████████████░░░░░░░░░░░░  71%   ✓ Good

LOWER BODY:
───────────────────────────────────────────────────────────────────────────
Quads           ████████████████████████████████████████░░░░  88%   ✓ Good
Hamstrings      ██████████████████████████████████░░░░░░░░░░  76%   ✓ Good
Glutes          ████████████████████████████████████░░░░░░░░  82%   ✓ Good
Calves          ██████████████░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░  34%   ❌ Neglected

═══════════════════════════════════════════════════════════════════════════

INTERPRETATION:
───────────────────────────────────────────────────────────────────────────
✓ Good (70-100%)    = Well-trained, maintain current volume
⚠ Needs work (40-69%) = Could use more attention
❌ Neglected (<40%)   = Add exercises targeting this area!

RECOMMENDATIONS:
───────────────────────────────────────────────────────────────────────────
• Add calf raises (standing + seated) 3x15 twice per week
• Include side planks or cable crunches for obliques
• Consider lateral raises for shoulder balance
```

---

## Visualization Colors

The 3D muscle model uses color coding:

```
ACTIVATION LEVEL LEGEND
═══════════════════════════════════════════════════════════════════════════

    COLOR           ACTIVATION       MEANING
    ─────────────────────────────────────────────────────────────────────
    🔴 Red          70-100%          High activation - Primary mover
    🟠 Orange       40-69%           Medium activation - Secondary
    🟡 Yellow       20-39%           Low activation - Stabilizer
    ⚪ White/Gray   0-19%            Minimal - Not significantly engaged

EXAMPLE WORKOUT VIEW:
───────────────────────────────────────────────────────────────────────────

    After logging: Bench Press, Incline Press, Cable Fly

                    [3D MODEL]

    Chest:      🔴🔴🔴🔴🔴  (90% - Primary in all exercises)
    Triceps:    🟠🟠🟠      (55% - Secondary in presses)
    Front Delt: 🟠🟠🟠      (50% - Secondary in presses)
    Biceps:     🟡          (25% - Stabilizer in flies)

═══════════════════════════════════════════════════════════════════════════
```

---

## Using Muscle Data for Programming

### Finding Gaps

The muscle visualization helps you:

1. **Identify weak points** - See which muscles need more work
2. **Ensure balance** - Don't over-develop one area
3. **Plan workouts** - Fill gaps with targeted exercises

### Sample Weekly Balance

```
IDEAL WEEKLY DISTRIBUTION
═══════════════════════════════════════════════════════════════════════════

    MUSCLE GROUP        TARGET TU    YOUR TU    STATUS
    ─────────────────────────────────────────────────────────────────────
    Chest               80-120       98         ✓ On target
    Back                100-150      112        ✓ On target
    Shoulders           60-90        45         ↑ Need more
    Biceps              40-60        52         ✓ On target
    Triceps             40-60        48         ✓ On target
    Quads               100-150      135        ✓ On target
    Hamstrings          80-120       89         ✓ On target
    Glutes              80-120       95         ✓ On target
    Calves              40-60        28         ↑ Need more
    Abs                 50-80        42         ↑ Need more

═══════════════════════════════════════════════════════════════════════════
```

---

## The Exercise Database

MuscleMap includes **90+ exercises** with full activation data:

### Sample Entries

```
EXERCISE DATABASE SAMPLE
═══════════════════════════════════════════════════════════════════════════

BARBELL BACK SQUAT
├── Type: Compound
├── Equipment: Barbell, Squat Rack
├── Difficulty: Intermediate
├── Primary: Quadriceps (85%), Glutes (70%)
├── Secondary: Hamstrings (50%), Erector Spinae (45%)
├── Tertiary: Core (20%), Calves (25%)
└── Variations: Front Squat, Box Squat, Pause Squat

PULL-UP
├── Type: Compound
├── Equipment: Pull-up Bar
├── Difficulty: Intermediate
├── Primary: Latissimus Dorsi (90%), Biceps (70%)
├── Secondary: Rhomboids (60%), Rear Delts (40%)
├── Tertiary: Forearms (35%), Core (25%)
└── Variations: Chin-up, Wide-grip, Weighted

LATERAL RAISE
├── Type: Isolation
├── Equipment: Dumbbells
├── Difficulty: Beginner
├── Primary: Lateral Deltoid (95%)
├── Secondary: Anterior Deltoid (30%), Traps (25%)
├── Tertiary: Forearms (15%)
└── Variations: Cable, Machine, Leaning

═══════════════════════════════════════════════════════════════════════════
```

---

[Back to Features](/docs/features) | [Back to Documentation](/docs)
