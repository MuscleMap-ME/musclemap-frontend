import{i as o}from"./index-o0ztnmnw.js";const t=[["polygon",{points:"3 11 22 2 13 21 11 13 3 11",key:"1ltx0t"}]],n=o("navigation",t);export{n as N};
