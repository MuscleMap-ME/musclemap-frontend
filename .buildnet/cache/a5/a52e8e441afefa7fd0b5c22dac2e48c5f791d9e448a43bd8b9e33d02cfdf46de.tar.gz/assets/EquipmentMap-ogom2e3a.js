const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/leaflet-vendor-iccovecq.css"])))=>i.map(i=>d[i]);
import{i as te,X as V,ay as se,_ as T}from"./index-o0ztnmnw.js";import{r as n,j as e}from"./react-vendor-jlwrghqw.js";import{u as O,g as C}from"./apollo-vendor-buzfmx8b.js";import{L as oe}from"./layers-ig1n8cd4.js";import{F as ne}from"./funnel-eu4hx1oo.js";import{C as R}from"./circle-check-big-n55wmk38.js";import{C as ae}from"./chevron-right-dih2tw2d.js";import"./reactflow-vendor-fc60audz.js";import"./d3-vendor-esoaovas.js";import"./recharts-vendor-mjjw1g2w.js";import"./leaflet-vendor-miye99o2.js";const re=[["line",{x1:"2",x2:"5",y1:"12",y2:"12",key:"bvdh0s"}],["line",{x1:"19",x2:"22",y1:"12",y2:"12",key:"1tbv5k"}],["line",{x1:"12",x2:"12",y1:"2",y2:"5",key:"11lu5j"}],["line",{x1:"12",x2:"12",y1:"19",y2:"22",key:"x3vr5v"}],["circle",{cx:"12",cy:"12",r:"7",key:"fim9np"}]],ie=te("locate",re);C`
  query GetVenueClusters($input: ClusterInput!) {
    venueMapClusters(input: $input) {
      id
      latitude
      longitude
      count
      expansion_zoom
      venues {
        id
        name
        slug
        venueType
        isVerified
      }
    }
  }
`;const le=C`
  query GetVenueGeoJSON($input: GeoJSONInput) {
    venueMapGeoJSON(input: $input) {
      type
      features {
        type
        geometry {
          type
          coordinates
        }
        properties {
          id
          name
          slug
          venueType
          equipmentCount
          hasPhotos
          isVerified
        }
      }
      totalCount
      bounds {
        north
        south
        east
        west
      }
    }
  }
`,ce=C`
  query GetEquipmentTypes {
    outdoorEquipmentTypes {
      id
      name
      slug
      category
      iconName
    }
  }
`,d={north:40.92,south:40.49,east:-73.68,west:-74.27},k=[40.7128,-74.006];function ue({totalCount:p}){return e.jsxs("div",{className:"bg-gray-800 rounded-xl p-6 min-h-[400px] flex flex-col items-center justify-center",children:[e.jsx("div",{className:"text-6xl mb-4",children:"🗺️"}),e.jsx("h3",{className:"text-xl font-bold text-white mb-4",children:"NYC Outdoor Equipment Map"}),e.jsx("p",{className:"text-gray-400 mb-4",children:p>0?`${p} locations available`:"Loading locations..."}),e.jsx("p",{className:"text-sm text-gray-500",children:"Map loading..."})]})}function je({className:p="",onVenueSelect:m,initialFilters:E={},showFilters:$=!0,showControls:F=!0,height:M=500}){const g=n.useRef(null),r=n.useRef(null),f=n.useRef([]),[b,P]=n.useState(!1),[y,B]=n.useState(!1),[a,G]=n.useState(null),[de,J]=n.useState(11),[D,q]=n.useState(d),[l,L]=n.useState(null),[w,S]=n.useState(!1),[x,_]=n.useState(E.equipmentTypes||[]),[v,z]=n.useState(E.verifiedOnly||!1),{data:N}=O(ce),{data:h,loading:I}=O(le,{variables:{input:{bounds:D,equipmentTypes:x.length>0?x:void 0,verifiedOnly:v}},skip:!b});n.useEffect(()=>{(async()=>{try{const s=await T(()=>import("./leaflet-vendor-miye99o2.js").then(o=>o.l),__vite__mapDeps([0]));await T(()=>import("./leaflet-vendor-miye99o2.js").then(o=>o.b),__vite__mapDeps([0])),G(s),B(!0)}catch{}})()},[]),n.useEffect(()=>{if(!y||!a||!g.current||r.current)return;const t=a.map(g.current,{center:k,zoom:11,minZoom:10,maxZoom:18,maxBounds:a.latLngBounds(a.latLng(d.south-.1,d.west-.1),a.latLng(d.north+.1,d.east+.1))});a.tileLayer("https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png",{attribution:'&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors &copy; <a href="https://carto.com/attributions">CARTO</a>',subdomains:"abcd",maxZoom:19}).addTo(t),t.on("moveend",()=>{const o=t.getBounds();q({north:o.getNorth(),south:o.getSouth(),east:o.getEast(),west:o.getWest()}),J(t.getZoom())}),r.current=t,P(!0);const s=t.getBounds();return q({north:s.getNorth(),south:s.getSouth(),east:s.getEast(),west:s.getWest()}),()=>{r.current&&(r.current.remove(),r.current=null)}},[y,a]),n.useEffect(()=>{if(!b||!a||!r.current||!h?.venueMapGeoJSON?.features)return;const t=r.current;f.current.forEach(s=>t.removeLayer(s)),f.current=[],h.venueMapGeoJSON.features.forEach(s=>{const[o,X]=s.geometry.coordinates,i=s.properties,u=i.equipmentCount>5?36:28,H=i.isVerified?"#22c55e":"#FF6B00",K=a.divIcon({className:"equipment-marker",html:`
          <div style="
            width: ${u}px;
            height: ${u}px;
            background: ${H};
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: bold;
            font-size: 12px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.4);
            border: 2px solid white;
            cursor: pointer;
            transition: transform 0.2s;
          "
          onmouseover="this.style.transform='scale(1.2)'"
          onmouseout="this.style.transform='scale(1)'"
          >
            ${i.equipmentCount}
          </div>
        `,iconSize:[u,u],iconAnchor:[u/2,u/2]}),j=a.marker([X,o],{icon:K}).addTo(t),ee=`
        <div style="min-width: 180px; padding: 8px;">
          <h4 style="margin: 0 0 8px 0; font-weight: 600; font-size: 14px; color: #1f2937;">
            ${i.name}
          </h4>
          <div style="display: flex; gap: 8px; margin-bottom: 8px;">
            ${i.isVerified?'<span style="background: #dcfce7; color: #166534; padding: 2px 8px; border-radius: 9999px; font-size: 11px;">✓ Verified</span>':""}
            ${i.hasPhotos?'<span style="background: #dbeafe; color: #1e40af; padding: 2px 8px; border-radius: 9999px; font-size: 11px;">📷 Photos</span>':""}
          </div>
          <p style="margin: 0 0 8px 0; font-size: 12px; color: #6b7280;">
            ${i.equipmentCount} equipment items
          </p>
          <button
            onclick="window.dispatchEvent(new CustomEvent('venueSelect', { detail: '${i.id}' }))"
            style="
              background: #FF6B00;
              color: white;
              border: none;
              padding: 6px 12px;
              border-radius: 6px;
              font-size: 12px;
              cursor: pointer;
              width: 100%;
            "
          >
            View Details
          </button>
        </div>
      `;j.bindPopup(ee,{closeButton:!0,className:"equipment-popup"}),j.on("click",()=>{L(i)}),f.current.push(j)})},[b,a,h]),n.useEffect(()=>{const t=s=>{m&&m(s.detail)};return window.addEventListener("venueSelect",t),()=>{window.removeEventListener("venueSelect",t)}},[m]);const Z=n.useCallback(()=>{!r.current||!a||navigator.geolocation.getCurrentPosition(t=>{const{latitude:s,longitude:o}=t.coords;r.current.setView([s,o],15)},t=>{r.current.setView(k,12)})},[a]),A=n.useCallback(()=>{r.current&&r.current.setView(k,11)},[]),Y=n.useCallback(t=>{_(s=>s.includes(t)?s.filter(o=>o!==t):[...s,t])},[]),U=n.useCallback(()=>{_([]),z(!1)},[]),Q=n.useMemo(()=>N?.outdoorEquipmentTypes?N.outdoorEquipmentTypes.reduce((t,s)=>{const o=s.category||"other";return t[o]||(t[o]=[]),t[o].push(s),t},{}):{},[N]),W=h?.venueMapGeoJSON?.totalCount||0,c=x.length+(v?1:0);return y?e.jsxs("div",{className:`relative ${p}`,style:{height:M},children:[e.jsx("div",{ref:g,className:"w-full h-full rounded-xl overflow-hidden"}),I&&e.jsx("div",{className:"absolute inset-0 bg-black/30 flex items-center justify-center z-10",children:e.jsx("div",{className:"bg-white rounded-lg px-4 py-2 shadow-lg",children:e.jsx("span",{className:"text-sm text-gray-700",children:"Loading locations..."})})}),e.jsx("div",{className:"absolute top-3 left-3 right-3 z-10 flex justify-between items-start pointer-events-none",children:e.jsxs("div",{className:"bg-black/70 backdrop-blur-sm text-white px-3 py-2 rounded-lg text-sm pointer-events-auto",children:[e.jsx("span",{className:"font-medium",children:W})," locations",c>0&&e.jsxs("span",{className:"text-orange-400 ml-2",children:["(",c," filters)"]})]})}),F&&e.jsxs("div",{className:"absolute right-3 top-16 z-[1000] flex flex-col gap-2",children:[e.jsx("button",{onClick:Z,className:"bg-white p-3 rounded-lg shadow-lg hover:bg-gray-50 transition-colors",title:"My Location",children:e.jsx(ie,{className:"w-5 h-5 text-gray-700"})}),e.jsx("button",{onClick:A,className:"bg-white p-3 rounded-lg shadow-lg hover:bg-gray-50 transition-colors",title:"Reset View",children:e.jsx(oe,{className:"w-5 h-5 text-gray-700"})})]}),$&&e.jsxs("button",{onClick:()=>S(!w),className:`absolute left-3 bottom-3 z-10 flex items-center gap-2 px-4 py-2 rounded-lg shadow-lg transition-colors ${w||c>0?"bg-orange-500 text-white":"bg-white text-gray-700 hover:bg-gray-50"}`,children:[e.jsx(ne,{className:"w-4 h-4"}),e.jsx("span",{className:"text-sm font-medium",children:"Filter"}),c>0&&e.jsx("span",{className:"bg-white text-orange-500 text-xs font-bold px-1.5 py-0.5 rounded-full",children:c})]}),w&&e.jsxs("div",{className:"absolute left-3 bottom-16 z-20 bg-white rounded-xl shadow-xl w-72 max-h-96 overflow-y-auto",children:[e.jsxs("div",{className:"sticky top-0 bg-white border-b p-3 flex justify-between items-center",children:[e.jsx("h3",{className:"font-semibold text-gray-800",children:"Filters"}),e.jsxs("div",{className:"flex items-center gap-2",children:[c>0&&e.jsx("button",{onClick:U,className:"text-xs text-orange-500 hover:text-orange-600",children:"Clear all"}),e.jsx("button",{onClick:()=>S(!1),className:"p-1 hover:bg-gray-100 rounded",children:e.jsx(V,{className:"w-4 h-4 text-gray-500"})})]})]}),e.jsxs("div",{className:"p-3 space-y-4",children:[e.jsxs("label",{className:"flex items-center gap-3 cursor-pointer",children:[e.jsx("input",{type:"checkbox",checked:v,onChange:t=>z(t.target.checked),className:"w-4 h-4 text-orange-500 rounded border-gray-300 focus:ring-orange-500"}),e.jsxs("span",{className:"flex items-center gap-2 text-sm text-gray-700",children:[e.jsx(R,{className:"w-4 h-4 text-green-500"}),"Verified locations only"]})]}),Object.entries(Q).map(([t,s])=>e.jsxs("div",{children:[e.jsx("h4",{className:"text-xs font-semibold text-gray-500 uppercase tracking-wide mb-2",children:t.replace(/_/g," ")}),e.jsx("div",{className:"space-y-1",children:s.map(o=>e.jsxs("label",{className:"flex items-center gap-2 cursor-pointer py-1 px-2 rounded hover:bg-gray-50",children:[e.jsx("input",{type:"checkbox",checked:x.includes(o.id),onChange:()=>Y(o.id),className:"w-4 h-4 text-orange-500 rounded border-gray-300 focus:ring-orange-500"}),e.jsx("span",{className:"text-sm text-gray-700",children:o.name})]},o.id))})]},t))]})]}),l&&e.jsx("div",{className:"absolute right-3 bottom-3 z-10 bg-white rounded-xl shadow-xl w-72 overflow-hidden",children:e.jsxs("div",{className:"p-4",children:[e.jsxs("div",{className:"flex justify-between items-start mb-2",children:[e.jsx("h3",{className:"font-semibold text-gray-800 pr-6",children:l.name}),e.jsx("button",{onClick:()=>L(null),className:"p-1 hover:bg-gray-100 rounded",children:e.jsx(V,{className:"w-4 h-4 text-gray-500"})})]}),e.jsxs("div",{className:"flex gap-2 mb-3",children:[l.isVerified&&e.jsxs("span",{className:"flex items-center gap-1 bg-green-50 text-green-700 text-xs px-2 py-1 rounded-full",children:[e.jsx(R,{className:"w-3 h-3"}),"Verified"]}),l.hasPhotos&&e.jsxs("span",{className:"flex items-center gap-1 bg-blue-50 text-blue-700 text-xs px-2 py-1 rounded-full",children:[e.jsx(se,{className:"w-3 h-3"}),"Photos"]})]}),e.jsxs("p",{className:"text-sm text-gray-600 mb-3",children:[l.equipmentCount," equipment items"]}),e.jsxs("button",{onClick:()=>m?.(l.id),className:"w-full flex items-center justify-center gap-2 bg-orange-500 hover:bg-orange-600 text-white py-2 px-4 rounded-lg transition-colors",children:[e.jsx("span",{children:"View Details"}),e.jsx(ae,{className:"w-4 h-4"})]})]})}),e.jsx("style",{children:`
        .equipment-marker {
          background: transparent !important;
          border: none !important;
        }
        .equipment-popup .leaflet-popup-content-wrapper {
          border-radius: 12px;
          box-shadow: 0 4px 20px rgba(0,0,0,0.15);
        }
        .equipment-popup .leaflet-popup-content {
          margin: 0;
        }
        .equipment-popup .leaflet-popup-tip {
          box-shadow: 0 4px 20px rgba(0,0,0,0.15);
        }
        /* Move Leaflet attribution to bottom-left to not cover controls */
        .leaflet-control-attribution {
          position: absolute !important;
          left: 0 !important;
          right: auto !important;
          bottom: 0 !important;
          background: rgba(255,255,255,0.7) !important;
          font-size: 10px !important;
          padding: 2px 5px !important;
        }
        /* Ensure zoom controls don't interfere */
        .leaflet-control-zoom {
          margin-top: 60px !important;
        }
      `})]}):e.jsx(ue,{totalCount:0})}export{je as EquipmentMap,je as default};
