import{i as o}from"./index-o0ztnmnw.js";const s=[["path",{d:"M5 12h14",key:"1ays0h"}]],e=o("minus",s);export{e as M};
