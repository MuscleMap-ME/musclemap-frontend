import{i as e}from"./index-o0ztnmnw.js";const t=[["rect",{width:"18",height:"18",x:"3",y:"3",rx:"2",key:"afitv7"}]],r=e("square",t);export{r as S};
