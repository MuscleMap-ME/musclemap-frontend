import{i as t}from"./index-o0ztnmnw.js";const e=[["rect",{width:"14",height:"20",x:"5",y:"2",rx:"2",ry:"2",key:"1yt0o3"}],["path",{d:"M12 18h.01",key:"mhygvu"}]],r=t("smartphone",e);export{r as S};
