# MuscleMap Onboarding Flow

A visual guide to your first steps with MuscleMap.

## The Onboarding Journey

```
                    ┌─────────────────────────────────────────────────┐
                    │                                                 │
                    │            WELCOME TO MUSCLEMAP                 │
                    │                                                 │
                    └──────────────────────┬──────────────────────────┘
                                           │
                                           ▼
┌──────────────────────────────────────────────────────────────────────────────┐
│                                                                              │
│   STEP 1: CREATE YOUR ACCOUNT                                                │
│   ═══════════════════════════                                                │
│                                                                              │
│   ┌──────────────────────────────────────────────────────────────────────┐   │
│   │  Email:     [________________________]                               │   │
│   │  Password:  [________________________]                               │   │
│   │  Username:  [________________________]                               │   │
│   │                                                                      │   │
│   │              [ CREATE ACCOUNT ]                                      │   │
│   └──────────────────────────────────────────────────────────────────────┘   │
│                                                                              │
│   Why we ask:                                                                │
│   • Email: For login and notifications                                       │
│   • Password: Keep your account secure                                       │
│   • Username: How others see you                                             │
│                                                                              │
└──────────────────────────────────────────────────────────────────────────────┘
                                           │
                                           ▼
┌──────────────────────────────────────────────────────────────────────────────┐
│                                                                              │
│   STEP 2: WHAT'S YOUR GOAL?                                                  │
│   ═════════════════════════                                                  │
│                                                                              │
│   Select your primary fitness objective:                                     │
│                                                                              │
│   ┌───────────────┐ ┌───────────────┐ ┌───────────────┐ ┌───────────────┐   │
│   │               │ │               │ │               │ │               │   │
│   │  BUILD        │ │  LOSE         │ │  GET          │ │  INCREASE     │   │
│   │  MUSCLE       │ │  WEIGHT       │ │  STRONGER     │ │  ENDURANCE    │   │
│   │     💪        │ │     ⚖️        │ │     🏋️        │ │     🏃        │   │
│   │               │ │               │ │               │ │               │   │
│   └───────────────┘ └───────────────┘ └───────────────┘ └───────────────┘   │
│                                                                              │
│   ┌───────────────┐ ┌───────────────┐                                        │
│   │               │ │               │                                        │
│   │  IMPROVE      │ │  GENERAL      │                                        │
│   │  FLEXIBILITY  │ │  FITNESS      │                                        │
│   │     🧘        │ │     ⭐        │                                        │
│   │               │ │               │                                        │
│   └───────────────┘ └───────────────┘                                        │
│                                                                              │
└──────────────────────────────────────────────────────────────────────────────┘
                                           │
                                           ▼
┌──────────────────────────────────────────────────────────────────────────────┐
│                                                                              │
│   STEP 3: YOUR EXPERIENCE LEVEL                                              │
│   ═════════════════════════════                                              │
│                                                                              │
│   How long have you been training?                                           │
│                                                                              │
│   ○ BEGINNER                                                                 │
│     Just starting out or returning after a long break                        │
│                                                                              │
│   ○ INTERMEDIATE                                                             │
│     Training consistently for 6+ months                                      │
│                                                                              │
│   ○ ADVANCED                                                                 │
│     Training seriously for 2+ years                                          │
│                                                                              │
└──────────────────────────────────────────────────────────────────────────────┘
                                           │
                                           ▼
┌──────────────────────────────────────────────────────────────────────────────┐
│                                                                              │
│   STEP 4: AVAILABLE EQUIPMENT                                                │
│   ═══════════════════════════                                                │
│                                                                              │
│   What do you have access to? (Select all that apply)                        │
│                                                                              │
│   ☐ Full Gym           Barbells, machines, cables, everything                │
│   ☐ Home Gym           Basic equipment at home                               │
│   ☐ Dumbbells Only     Just dumbbells                                        │
│   ☐ Bodyweight Only    No equipment                                          │
│   ☐ Resistance Bands   Bands and bodyweight                                  │
│   ☐ Kettlebells        Kettlebells available                                 │
│                                                                              │
│   This helps us recommend appropriate exercises!                             │
│                                                                              │
└──────────────────────────────────────────────────────────────────────────────┘
                                           │
                                           ▼
┌──────────────────────────────────────────────────────────────────────────────┐
│                                                                              │
│   STEP 5: ANY LIMITATIONS? (Optional)                                        │
│   ═══════════════════════════════════                                        │
│                                                                              │
│   Let us know about any restrictions so we can keep you safe:                │
│                                                                              │
│   ☐ Lower back issues                                                        │
│   ☐ Shoulder problems                                                        │
│   ☐ Knee injuries                                                            │
│   ☐ Other: [_________________________]                                       │
│                                                                              │
│   We'll automatically avoid exercises that might aggravate these!            │
│                                                                              │
│   [ SKIP ] [ CONTINUE ]                                                      │
│                                                                              │
└──────────────────────────────────────────────────────────────────────────────┘
                                           │
                                           ▼
┌──────────────────────────────────────────────────────────────────────────────┐
│                                                                              │
│   STEP 6: CHOOSE YOUR ARCHETYPE                                              │
│   ═════════════════════════════                                              │
│                                                                              │
│   Your archetype defines your training philosophy.                           │
│   Choose what resonates with you:                                            │
│                                                                              │
│   ┌─────────────────────────────────────────────────────────────────────┐    │
│   │                                                                     │    │
│   │  ⚔️ SPARTAN       Raw strength, mental toughness                    │    │
│   │  🏃 ATHLETE       Balanced performance, sports                      │    │
│   │  💃 DANCER        Grace, flexibility, control                       │    │
│   │  🧘 MONK          Mind-body connection                              │    │
│   │  🥊 WARRIOR       Combat readiness                                  │    │
│   │  🏔️ EXPLORER      Functional outdoor fitness                        │    │
│   │  🛡️ GUARDIAN      Protective strength                               │    │
│   │  📚 SCHOLAR       Scientific optimization                           │    │
│   │  💚 HEALER        Recovery and longevity                            │    │
│   │  🎨 ARTISAN       Aesthetic physique                                │    │
│   │                                                                     │    │
│   └─────────────────────────────────────────────────────────────────────┘    │
│                                                                              │
│   Don't worry - you can change this anytime!                                 │
│                                                                              │
└──────────────────────────────────────────────────────────────────────────────┘
                                           │
                                           ▼
                    ┌─────────────────────────────────────────────────┐
                    │                                                 │
                    │        YOU'RE READY TO START!                   │
                    │                                                 │
                    │    Your companion creature has hatched 🐣       │
                    │    Level up as you train together!              │
                    │                                                 │
                    │        [ BEGIN YOUR JOURNEY ]                   │
                    │                                                 │
                    └─────────────────────────────────────────────────┘
```

---

## What Happens Next

After onboarding, you'll land on your **Dashboard**:

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                             │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │  DASHBOARD                                          Level 1 Spartan │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
│  ┌─────────────────────┐  ┌─────────────────────┐  ┌─────────────────────┐ │
│  │                     │  │                     │  │                     │ │
│  │  [ START WORKOUT ]  │  │   WEEKLY GOAL       │  │   COMPANION         │ │
│  │                     │  │   0 / 500 TU        │  │      🥚             │ │
│  │   Tap to begin!     │  │   ░░░░░░░░░░        │  │   Just hatched!     │ │
│  │                     │  │                     │  │                     │ │
│  └─────────────────────┘  └─────────────────────┘  └─────────────────────┘ │
│                                                                             │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                                                                     │   │
│  │                    3D MUSCLE VISUALIZATION                          │   │
│  │                                                                     │   │
│  │                         (No data yet)                               │   │
│  │                    Complete your first workout!                     │   │
│  │                                                                     │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │  TIPS                                                               │   │
│  │  ────                                                               │   │
│  │  • Tap "Start Workout" to log your first session                    │   │
│  │  • Try "Get Prescription" for an AI-generated workout               │   │
│  │  • Join a Hangout to find your local gym community                  │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## Your First Week Checklist

```
WEEK 1 GOALS:
═════════════════════════════════════════════════════════════════════════════

Day 1: Setup                                                           Status
───────────────────────────────────────────────────────────────────────────────
☐ Complete onboarding                                                    ○
☐ Explore the dashboard                                                  ○
☐ Check out your companion                                               ○

Day 2: First Workout
───────────────────────────────────────────────────────────────────────────────
☐ Log your first workout                                                 ○
☐ See the muscle visualization light up                                  ○
☐ Check your TU earned                                                   ○

Day 3: Explore
───────────────────────────────────────────────────────────────────────────────
☐ Browse the exercise database                                           ○
☐ Try an AI prescription                                                 ○
☐ Review your stats                                                      ○

Day 4: Connect
───────────────────────────────────────────────────────────────────────────────
☐ Find your gym in Locations                                             ○
☐ Join a Hangout                                                         ○
☐ Give someone a high-five                                               ○

Day 5-7: Build Habits
───────────────────────────────────────────────────────────────────────────────
☐ Complete 3 total workouts                                              ○
☐ Earn your first achievement                                            ○
☐ Set a personal goal                                                    ○
☐ Check your companion's progress                                        ○

═════════════════════════════════════════════════════════════════════════════
Progress: 0/13 completed
```

---

## Quick Reference Card

```
╔═══════════════════════════════════════════════════════════════════════════╗
║                    MUSCLEMAP QUICK REFERENCE                              ║
╠═══════════════════════════════════════════════════════════════════════════╣
║                                                                           ║
║  ACTION              │ WHERE TO FIND IT                                   ║
║  ────────────────────┼─────────────────────────────────────────────────── ║
║  Start workout       │ Dashboard > "Start Workout"                        ║
║  Log exercise        │ Workout > Search > Add sets                        ║
║  Get AI workout      │ Dashboard > "Get Prescription"                     ║
║  View muscle map     │ Workout > Muscle tab                               ║
║  Check stats         │ Bottom nav > Stats                                 ║
║  Find community      │ Bottom nav > Locations                             ║
║  Message someone     │ Profile > Message                                  ║
║  Start rivalry       │ Profile > Challenge                                ║
║  Join crew           │ Crews > Browse > Join                              ║
║  Change archetype    │ Settings > Profile > Archetype                     ║
║  Report issue        │ Settings > Issues > New                            ║
║                                                                           ║
╚═══════════════════════════════════════════════════════════════════════════╝
```

---

[Back to Getting Started](/docs/getting-started) | [Back to Documentation](/docs)
