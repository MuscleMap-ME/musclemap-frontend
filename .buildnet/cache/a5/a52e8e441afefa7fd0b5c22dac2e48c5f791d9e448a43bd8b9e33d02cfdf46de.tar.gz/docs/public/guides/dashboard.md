# Understanding the Dashboard

Your home base in MuscleMap - everything you need at a glance.

---

## Dashboard Overview

```
┌─────────────────────────────────────────────────────┐
│                     DASHBOARD                       │
├─────────────────────────────────────────────────────┤
│ ┌─────────────┐  ┌─────────────┐  ┌─────────────┐  │
│ │   TODAY'S   │  │   WEEKLY    │  │   YOUR      │  │
│ │   WORKOUT   │  │   PROGRESS  │  │   LEVEL     │  │
│ │             │  │             │  │             │  │
│ │ [START]     │  │ 456/800 TU  │  │  Lvl 7      │  │
│ │             │  │ ████████░░  │  │  Spartan    │  │
│ └─────────────┘  └─────────────┘  └─────────────┘  │
│                                                     │
│ ┌─────────────────────────────────────────────────┐│
│ │              MUSCLE OVERVIEW                    ││
│ │                                                 ││
│ │    [Interactive 3D muscle visualization]       ││
│ │                                                 ││
│ │    Last 7 Days: Well-balanced coverage         ││
│ └─────────────────────────────────────────────────┘│
│                                                     │
│ ┌─────────────────────────────────────────────────┐│
│ │              RECENT ACTIVITY                    ││
│ │ • Yesterday: Upper Body - 89 TU                ││
│ │ • 2 days ago: Leg Day - 102 TU                 ││
│ │ • 3 days ago: Full Body - 76 TU                ││
│ └─────────────────────────────────────────────────┘│
│                                                     │
│ ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌────────┐ │
│ │ COMPANION│ │  GOALS   │ │RIVALRIES │ │ HANGOUT│ │
│ │   🐣     │ │  2/3 ✓   │ │  1 Active│ │  12 👥 │ │
│ └──────────┘ └──────────┘ └──────────┘ └────────┘ │
└─────────────────────────────────────────────────────┘
```

---

## Key Areas Explained

### 1. Quick Start Button
Jump into a workout instantly. This is your primary action button - tap it to:
- Start a new workout session
- Get an AI-generated prescription
- Load a saved template

### 2. Weekly Progress
Shows your Training Units (TU) target and current status:
- Progress bar fills as you train
- Resets every Monday
- Helps you stay consistent

### 3. Your Level
Displays your archetype and current level:
- Tap to see level details
- View progress to next level
- See your rank in the community

### 4. Muscle Overview
Interactive 3D visualization showing:
- Recent muscle activation
- Color-coded intensity (red = high, blue = low)
- 7-day rolling view
- Tap to rotate and explore

### 5. Recent Activity
Your last few workouts at a glance:
- Workout type/name
- TU earned
- Time since completion

### 6. Quick Access Cards

| Card | What It Shows |
|------|---------------|
| **Companion** | Your evolving fitness companion |
| **Goals** | Active goals and progress |
| **Rivalries** | Current competitions |
| **Hangout** | Your local gym community |

---

## Tips for Using Your Dashboard

- **Check daily** to see your muscle balance
- **Set weekly TU goals** using the progress tracker
- **Review recent activity** to avoid overtraining
- **Tap the muscle map** to identify neglected areas

---

[← Your First Week](./first-week.md) | [Back to Guides](./README.md) | [Next: Logging Workouts →](./logging-workouts.md)
