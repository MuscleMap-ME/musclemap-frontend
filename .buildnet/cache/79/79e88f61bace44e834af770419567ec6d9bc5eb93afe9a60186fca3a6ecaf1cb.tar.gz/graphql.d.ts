/**
 * @musclemap/plugin-sdk - GraphQL Plugin API
 *
 * Extends the plugin system with GraphQL capabilities:
 * - Schema extensions via SDL
 * - Custom resolvers
 * - Subscriptions
 * - DataLoader integration
 */
import type { PluginContext } from './backend';
/**
 * GraphQL type definitions as SDL string.
 */
export type TypeDefs = string;
/**
 * Resolver function signature.
 */
export type ResolverFn<TParent = unknown, TArgs = Record<string, unknown>, TResult = unknown> = (parent: TParent, args: TArgs, context: GraphQLPluginContext, info: unknown) => TResult | Promise<TResult>;
/**
 * Resolver map for a single type.
 */
export interface TypeResolvers {
    [fieldName: string]: ResolverFn;
}
/**
 * Complete resolver map.
 */
export interface Resolvers {
    Query?: TypeResolvers;
    Mutation?: TypeResolvers;
    Subscription?: SubscriptionResolvers;
    [typeName: string]: TypeResolvers | SubscriptionResolvers | undefined;
}
/**
 * Subscription resolver with subscribe and resolve functions.
 */
export interface SubscriptionResolver {
    subscribe: ResolverFn;
    resolve?: ResolverFn;
}
export interface SubscriptionResolvers {
    [fieldName: string]: SubscriptionResolver;
}
/**
 * Extended context available in GraphQL resolvers.
 */
export interface GraphQLPluginContext extends PluginContext {
    /**
     * Current authenticated user (if any).
     */
    user?: {
        id: string;
        email: string;
        username: string;
        roles: string[];
    };
    /**
     * DataLoader for batching queries.
     */
    loaders: DataLoaderRegistry;
    /**
     * Pub/Sub for subscriptions.
     */
    pubsub: PubSubService;
    /**
     * Request-scoped cache.
     */
    cache: RequestCache;
}
/**
 * DataLoader registry for batched loading.
 */
export interface DataLoaderRegistry {
    /**
     * Get or create a DataLoader for a given key.
     */
    get<K, V>(name: string, batchFn: (keys: readonly K[]) => Promise<(V | Error)[]>): DataLoader<K, V>;
}
/**
 * Simple DataLoader interface.
 */
export interface DataLoader<K, V> {
    load(key: K): Promise<V>;
    loadMany(keys: K[]): Promise<(V | Error)[]>;
    clear(key: K): void;
    clearAll(): void;
    prime(key: K, value: V): void;
}
/**
 * Pub/Sub service for subscriptions.
 */
export interface PubSubService {
    /**
     * Publish an event to a topic.
     */
    publish(topic: string, payload: unknown): Promise<void>;
    /**
     * Subscribe to a topic. Returns an async iterator.
     */
    subscribe(topic: string): AsyncIterator<unknown>;
    /**
     * Subscribe with filtering.
     */
    asyncIterator<T>(triggers: string | string[], options?: {
        filter?: (payload: T) => boolean | Promise<boolean>;
    }): AsyncIterator<T>;
}
/**
 * Request-scoped cache.
 */
export interface RequestCache {
    get<T>(key: string): T | undefined;
    set<T>(key: string, value: T): void;
    has(key: string): boolean;
    delete(key: string): boolean;
    clear(): void;
}
/**
 * GraphQL schema extension from a plugin.
 */
export interface GraphQLSchemaExtension {
    /**
     * Unique name for this extension.
     */
    name: string;
    /**
     * SDL type definitions to merge into the schema.
     * Can extend existing types or add new ones.
     *
     * @example
     * ```graphql
     * extend type Query {
     *   leaderboard(limit: Int): [LeaderboardEntry!]!
     * }
     *
     * type LeaderboardEntry {
     *   rank: Int!
     *   user: User!
     *   score: Float!
     * }
     * ```
     */
    typeDefs: TypeDefs;
    /**
     * Resolvers for the extended types.
     */
    resolvers: Resolvers;
    /**
     * Directives provided by this extension.
     */
    directives?: GraphQLDirective[];
}
/**
 * Custom GraphQL directive.
 */
export interface GraphQLDirective {
    name: string;
    description?: string;
    locations: DirectiveLocation[];
    args?: Record<string, {
        type: string;
        defaultValue?: unknown;
    }>;
    transformer: (schema: unknown) => unknown;
}
export type DirectiveLocation = 'QUERY' | 'MUTATION' | 'SUBSCRIPTION' | 'FIELD' | 'FIELD_DEFINITION' | 'OBJECT' | 'INTERFACE' | 'UNION' | 'ENUM' | 'INPUT_OBJECT';
/**
 * GraphQL plugin registration.
 */
export interface GraphQLPluginRegistration {
    /**
     * Schema extensions to merge.
     */
    schema?: GraphQLSchemaExtension;
    /**
     * Subscription topics this plugin provides.
     */
    subscriptionTopics?: string[];
    /**
     * Middleware to run before resolvers.
     */
    middleware?: GraphQLMiddleware[];
    /**
     * Field-level authorization rules.
     */
    fieldAuthorization?: FieldAuthorizationRule[];
}
/**
 * GraphQL middleware function.
 */
export type GraphQLMiddleware = (resolve: ResolverFn, parent: unknown, args: Record<string, unknown>, context: GraphQLPluginContext, info: unknown) => Promise<unknown>;
/**
 * Field-level authorization rule.
 */
export interface FieldAuthorizationRule {
    /**
     * Type.Field pattern (e.g., "User.email", "Query.*")
     */
    pattern: string;
    /**
     * Required permission or custom check.
     */
    check: string | ((context: GraphQLPluginContext, args: unknown) => boolean | Promise<boolean>);
}
/**
 * Full plugin entry with GraphQL support.
 */
export interface GraphQLPluginEntry {
    /**
     * REST routes (legacy).
     */
    rest?: {
        registerRoutes(router: unknown): void;
    };
    /**
     * GraphQL extensions.
     */
    graphql?: GraphQLPluginRegistration;
    /**
     * Lifecycle hooks.
     */
    hooks?: {
        onServerStart?(ctx: PluginContext): Promise<void>;
        onShutdown?(ctx: PluginContext): Promise<void>;
    };
}
export type GraphQLPluginFactory = (ctx: PluginContext) => GraphQLPluginEntry | Promise<GraphQLPluginEntry>;
/**
 * Define a GraphQL-enabled plugin.
 */
export declare function defineGraphQLPlugin(factory: GraphQLPluginFactory): GraphQLPluginFactory;
/**
 * Standard subscription topics in MuscleMap.
 */
export declare const SubscriptionTopics: {
    readonly WORKOUT_COMPLETED: "WORKOUT_COMPLETED";
    readonly COMPETITION_UPDATE: "COMPETITION_UPDATE";
    readonly COMMUNITY_ACTIVITY: "COMMUNITY_ACTIVITY";
    readonly MESSAGE_RECEIVED: "MESSAGE_RECEIVED";
    readonly PRESENCE_CHANGED: "PRESENCE_CHANGED";
    readonly CREDITS_CHANGED: "CREDITS_CHANGED";
};
export type SubscriptionTopic = (typeof SubscriptionTopics)[keyof typeof SubscriptionTopics];
/**
 * Create a filtered subscription resolver.
 */
export declare function withFilter<T>(asyncIteratorFn: (rootValue: unknown, args: Record<string, unknown>, context: GraphQLPluginContext) => AsyncIterator<T>, filterFn: (payload: T, args: Record<string, unknown>, context: GraphQLPluginContext) => boolean | Promise<boolean>): SubscriptionResolver;
/**
 * Wrap a resolver with authentication check.
 */
export declare function authenticated<T extends ResolverFn>(resolver: T): T;
/**
 * Wrap a resolver with permission check.
 */
export declare function authorized<T extends ResolverFn>(permission: string, resolver: T): T;
/**
 * Wrap a resolver with credit charge.
 */
export declare function withCreditCharge<T extends ResolverFn>(action: string, cost: number, resolver: T): T;
//# sourceMappingURL=graphql.d.ts.map