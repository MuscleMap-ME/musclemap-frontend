"use strict";
/**
 * @musclemap/plugin-sdk - Backend Plugin API
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.definePlugin = definePlugin;
exports.requireAuth = requireAuth;
exports.requirePermissions = requirePermissions;
function definePlugin(entry) {
    return entry;
}
// ============================================
// PLUGIN MIDDLEWARE HELPERS
// ============================================
function requireAuth(handler) {
    return (req, res, next) => {
        if (!req.user) {
            res.status(401).json({
                error: { code: 'UNAUTHORIZED', message: 'Authentication required' }
            });
            return;
        }
        handler(req, res, next);
    };
}
function requirePermissions(permissions, handler) {
    return (req, res, next) => {
        handler(req, res, next);
    };
}
//# sourceMappingURL=backend.js.map