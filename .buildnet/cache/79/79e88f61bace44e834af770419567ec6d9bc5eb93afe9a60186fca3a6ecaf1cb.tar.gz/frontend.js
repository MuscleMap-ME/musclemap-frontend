"use strict";
/**
 * @musclemap/plugin-sdk - Frontend Plugin API
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.definePlugin = definePlugin;
exports.usePluginContext = usePluginContext;
exports.useHasPermission = useHasPermission;
exports.usePluginApi = usePluginApi;
function definePlugin(entry) {
    return entry;
}
// ============================================
// HOOKS FOR PLUGINS (stubs - implemented by host)
// ============================================
function usePluginContext() {
    throw new Error('usePluginContext must be used within a PluginProvider');
}
function useHasPermission(_permission) {
    throw new Error('useHasPermission must be used within a PluginProvider');
}
function usePluginApi() {
    throw new Error('usePluginApi must be used within a PluginProvider');
}
//# sourceMappingURL=frontend.js.map