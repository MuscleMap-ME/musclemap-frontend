"use strict";
/**
 * @musclemap/plugin-sdk - GraphQL Plugin API
 *
 * Extends the plugin system with GraphQL capabilities:
 * - Schema extensions via SDL
 * - Custom resolvers
 * - Subscriptions
 * - DataLoader integration
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.SubscriptionTopics = void 0;
exports.defineGraphQLPlugin = defineGraphQLPlugin;
exports.withFilter = withFilter;
exports.authenticated = authenticated;
exports.authorized = authorized;
exports.withCreditCharge = withCreditCharge;
/**
 * Define a GraphQL-enabled plugin.
 */
function defineGraphQLPlugin(factory) {
    return factory;
}
// ============================================
// SUBSCRIPTION HELPERS
// ============================================
/**
 * Standard subscription topics in MuscleMap.
 */
exports.SubscriptionTopics = {
    WORKOUT_COMPLETED: 'WORKOUT_COMPLETED',
    COMPETITION_UPDATE: 'COMPETITION_UPDATE',
    COMMUNITY_ACTIVITY: 'COMMUNITY_ACTIVITY',
    MESSAGE_RECEIVED: 'MESSAGE_RECEIVED',
    PRESENCE_CHANGED: 'PRESENCE_CHANGED',
    CREDITS_CHANGED: 'CREDITS_CHANGED',
};
/**
 * Create a filtered subscription resolver.
 */
function withFilter(asyncIteratorFn, filterFn) {
    return {
        subscribe: async (parent, args, context, _info) => {
            const asyncIterator = asyncIteratorFn(parent, args, context);
            return {
                async next() {
                    while (true) {
                        const { value, done } = await asyncIterator.next();
                        if (done)
                            return { value: undefined, done: true };
                        const shouldInclude = await filterFn(value, args, context);
                        if (shouldInclude) {
                            return { value, done: false };
                        }
                    }
                },
                return() {
                    if (typeof asyncIterator.return === 'function') {
                        return asyncIterator.return();
                    }
                    return Promise.resolve({ value: undefined, done: true });
                },
                throw(error) {
                    if (typeof asyncIterator.throw === 'function') {
                        return asyncIterator.throw(error);
                    }
                    return Promise.reject(error);
                },
                [Symbol.asyncIterator]() {
                    return this;
                },
            };
        },
        resolve: (payload) => payload,
    };
}
// ============================================
// RESOLVER HELPERS
// ============================================
/**
 * Wrap a resolver with authentication check.
 */
function authenticated(resolver) {
    return ((parent, args, context, info) => {
        if (!context.user) {
            throw new Error('Authentication required');
        }
        return resolver(parent, args, context, info);
    });
}
/**
 * Wrap a resolver with permission check.
 */
function authorized(permission, resolver) {
    return ((parent, args, context, info) => {
        if (!context.user) {
            throw new Error('Authentication required');
        }
        if (!context.user.roles.includes('admin') && !hasPermission(context.user.roles, permission)) {
            throw new Error(`Permission denied: ${permission}`);
        }
        return resolver(parent, args, context, info);
    });
}
function hasPermission(roles, permission) {
    // Simple role-based check - actual implementation in core
    return roles.includes(permission) || roles.includes('admin');
}
/**
 * Wrap a resolver with credit charge.
 */
function withCreditCharge(action, cost, resolver) {
    return (async (parent, args, context, info) => {
        if (!context.user) {
            throw new Error('Authentication required');
        }
        const idempotencyKey = `${context.request?.requestId || Date.now()}-${action}`;
        const result = await context.credits.charge({
            userId: context.user.id,
            action,
            cost,
            idempotencyKey,
        });
        if (!result.success) {
            throw new Error(result.error || 'Insufficient credits');
        }
        return resolver(parent, args, context, info);
    });
}
//# sourceMappingURL=graphql.js.map