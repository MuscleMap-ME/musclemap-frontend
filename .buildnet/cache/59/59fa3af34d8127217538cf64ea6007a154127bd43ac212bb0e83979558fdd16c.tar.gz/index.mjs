// src/Button.tsx
import { Button as TamaguiButton, styled } from "tamagui";
var Button = styled(TamaguiButton, {
  name: "Button",
  // TOUCHSCREEN-FIRST: Base touch-friendly styles
  userSelect: "none",
  variants: {
    variant: {
      primary: {
        backgroundColor: "$blue10",
        color: "white",
        hoverStyle: {
          backgroundColor: "$blue11"
        },
        pressStyle: {
          backgroundColor: "$blue9",
          scale: 0.98
        }
      },
      secondary: {
        backgroundColor: "$gray4",
        color: "$gray12",
        hoverStyle: {
          backgroundColor: "$gray5"
        },
        pressStyle: {
          backgroundColor: "$gray6",
          scale: 0.98
        }
      },
      outline: {
        backgroundColor: "transparent",
        borderWidth: 1,
        borderColor: "$gray8",
        color: "$gray12",
        hoverStyle: {
          backgroundColor: "$gray3"
        },
        pressStyle: {
          backgroundColor: "$gray4",
          scale: 0.98
        }
      },
      danger: {
        backgroundColor: "$red10",
        color: "white",
        hoverStyle: {
          backgroundColor: "$red11"
        },
        pressStyle: {
          backgroundColor: "$red9",
          scale: 0.98
        }
      },
      success: {
        backgroundColor: "$green10",
        color: "white",
        hoverStyle: {
          backgroundColor: "$green11"
        },
        pressStyle: {
          backgroundColor: "$green9",
          scale: 0.98
        }
      },
      ghost: {
        backgroundColor: "transparent",
        color: "$gray11",
        hoverStyle: {
          backgroundColor: "$gray3"
        },
        pressStyle: {
          backgroundColor: "$gray4",
          scale: 0.98
        }
      }
    },
    size: {
      /**
       * TOUCHSCREEN-FIRST SIZES
       * All meet minimum 44px iOS / 48px Material touch target
       */
      sm: {
        height: 44,
        // Was 32, increased for touch
        paddingHorizontal: "$4",
        fontSize: "$3"
      },
      md: {
        height: 48,
        // Was 40, increased for touch
        paddingHorizontal: "$5",
        fontSize: "$4"
      },
      lg: {
        height: 56,
        // Was 48, increased for touch
        paddingHorizontal: "$6",
        fontSize: "$5"
      }
    },
    fullWidth: {
      true: {
        width: "100%"
      }
    }
  },
  defaultVariants: {
    variant: "primary",
    size: "md"
  }
});

// src/Card.tsx
import { Card as TamaguiCard, styled as styled2, YStack } from "tamagui";
var Card = styled2(TamaguiCard, {
  name: "Card",
  backgroundColor: "$background",
  borderRadius: "$4",
  padding: "$4",
  variants: {
    variant: {
      elevated: {
        elevate: true,
        shadowColor: "$shadowColor",
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.1,
        shadowRadius: 4
      },
      outlined: {
        borderWidth: 1,
        borderColor: "$borderColor"
      },
      filled: {
        backgroundColor: "$gray2"
      }
    },
    interactive: {
      true: {
        hoverStyle: {
          backgroundColor: "$gray3"
        },
        pressStyle: {
          backgroundColor: "$gray4",
          scale: 0.98
        },
        cursor: "pointer"
      }
    }
  },
  defaultVariants: {
    variant: "elevated"
  }
});
var CardHeader = styled2(YStack, {
  name: "CardHeader",
  paddingBottom: "$3",
  borderBottomWidth: 1,
  borderBottomColor: "$borderColor",
  marginBottom: "$3"
});
var CardContent = styled2(YStack, {
  name: "CardContent",
  space: "$2"
});
var CardFooter = styled2(YStack, {
  name: "CardFooter",
  paddingTop: "$3",
  borderTopWidth: 1,
  borderTopColor: "$borderColor",
  marginTop: "$3"
});

// src/Input.tsx
import { Input as TamaguiInput, styled as styled3, XStack, Text, YStack as YStack2 } from "tamagui";
import { jsx, jsxs } from "react/jsx-runtime";
var Input = styled3(TamaguiInput, {
  name: "Input",
  borderWidth: 1,
  borderColor: "$gray7",
  borderRadius: "$3",
  paddingHorizontal: "$3",
  backgroundColor: "$background",
  focusStyle: {
    borderColor: "$blue8",
    outlineWidth: 0
  },
  variants: {
    size: {
      sm: {
        height: 36,
        fontSize: "$3"
      },
      md: {
        height: 44,
        fontSize: "$4"
      },
      lg: {
        height: 52,
        fontSize: "$5"
      }
    },
    status: {
      error: {
        borderColor: "$red8",
        focusStyle: {
          borderColor: "$red9"
        }
      },
      success: {
        borderColor: "$green8",
        focusStyle: {
          borderColor: "$green9"
        }
      }
    },
    fullWidth: {
      true: {
        width: "100%"
      }
    }
  },
  defaultVariants: {
    size: "md"
  }
});
function InputField({
  label,
  error,
  hint,
  leftIcon,
  rightIcon,
  children
}) {
  return /* @__PURE__ */ jsxs(YStack2, { space: "$1", children: [
    label && /* @__PURE__ */ jsx(Text, { fontSize: "$3", fontWeight: "500", color: "$gray11", children: label }),
    /* @__PURE__ */ jsxs(XStack, { alignItems: "center", position: "relative", children: [
      leftIcon && /* @__PURE__ */ jsx(XStack, { position: "absolute", left: "$3", zIndex: 1, children: leftIcon }),
      children,
      rightIcon && /* @__PURE__ */ jsx(XStack, { position: "absolute", right: "$3", zIndex: 1, children: rightIcon })
    ] }),
    error && /* @__PURE__ */ jsx(Text, { fontSize: "$2", color: "$red10", children: error }),
    hint && !error && /* @__PURE__ */ jsx(Text, { fontSize: "$2", color: "$gray10", children: hint })
  ] });
}

// src/Text.tsx
import { styled as styled4, Text as TamaguiText, H1 as TamaguiH1, H2 as TamaguiH2, H3 as TamaguiH3, Paragraph as TamaguiParagraph } from "tamagui";
var Text2 = styled4(TamaguiText, {
  name: "Text",
  color: "$color",
  variants: {
    variant: {
      default: {},
      muted: {
        color: "$gray11"
      },
      accent: {
        color: "$blue10"
      },
      success: {
        color: "$green10"
      },
      warning: {
        color: "$yellow10"
      },
      error: {
        color: "$red10"
      }
    },
    weight: {
      regular: {
        fontWeight: "400"
      },
      medium: {
        fontWeight: "500"
      },
      semibold: {
        fontWeight: "600"
      },
      bold: {
        fontWeight: "700"
      }
    },
    align: {
      left: {
        textAlign: "left"
      },
      center: {
        textAlign: "center"
      },
      right: {
        textAlign: "right"
      }
    }
  },
  defaultVariants: {
    variant: "default",
    weight: "regular",
    align: "left"
  }
});
var H1 = styled4(TamaguiH1, {
  name: "H1"
});
var H2 = styled4(TamaguiH2, {
  name: "H2"
});
var H3 = styled4(TamaguiH3, {
  name: "H3"
});
var Paragraph = styled4(TamaguiParagraph, {
  name: "Paragraph",
  color: "$gray11"
});
var Label = styled4(TamaguiText, {
  name: "Label",
  fontSize: "$3",
  fontWeight: "500",
  color: "$gray11"
});
var Caption = styled4(TamaguiText, {
  name: "Caption",
  fontSize: "$2",
  color: "$gray10"
});

// src/theme/tokens.ts
var muscleMapColors = {
  // Primary brand colors
  primary: {
    50: "#e6f2ff",
    100: "#b3d9ff",
    200: "#80bfff",
    300: "#4da6ff",
    400: "#1a8cff",
    500: "#0073e6",
    600: "#005ab3",
    700: "#004080",
    800: "#00264d",
    900: "#000d1a"
  },
  // Muscle group colors for visualization
  muscle: {
    chest: "#ef4444",
    // Red
    back: "#3b82f6",
    // Blue
    shoulders: "#f97316",
    // Orange
    arms: "#8b5cf6",
    // Purple
    legs: "#22c55e",
    // Green
    core: "#eab308",
    // Yellow
    cardio: "#ec4899"
    // Pink
  },
  // Status colors
  success: "#22c55e",
  warning: "#f59e0b",
  error: "#ef4444",
  info: "#3b82f6"
};
var muscleMapSpacing = {
  xs: 4,
  sm: 8,
  md: 16,
  lg: 24,
  xl: 32,
  "2xl": 48,
  "3xl": 64
};
var muscleMapRadius = {
  sm: 4,
  md: 8,
  lg: 12,
  xl: 16,
  full: 9999
};

// src/index.ts
import {
  YStack as YStack3,
  XStack as XStack2,
  Stack,
  Separator,
  ScrollView,
  Avatar,
  Switch,
  Spinner,
  Sheet,
  Dialog,
  Popover,
  Tooltip,
  Tabs,
  Form,
  Label as Label2,
  Theme,
  useTheme,
  TamaguiProvider
} from "tamagui";
import {
  Home,
  Dumbbell,
  User,
  Settings,
  LogOut,
  Plus,
  Minus,
  Check,
  X,
  ChevronRight,
  ChevronLeft,
  ChevronDown,
  ChevronUp,
  Menu,
  Search,
  Bell,
  Moon,
  Sun,
  Shield,
  Play,
  Pause,
  RotateCcw,
  Trophy,
  Flame,
  Heart,
  Star,
  Target,
  Zap,
  Calendar,
  Clock,
  TrendingUp
} from "@tamagui/lucide-icons";
export {
  Avatar,
  Bell,
  Button,
  Calendar,
  Caption,
  Card,
  CardContent,
  CardFooter,
  CardHeader,
  Check,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  ChevronUp,
  Clock,
  Dialog,
  Dumbbell,
  Flame,
  Form,
  H1,
  H2,
  H3,
  Heart,
  Home,
  Input,
  InputField,
  Label,
  LogOut,
  Menu,
  Minus,
  Moon,
  Paragraph,
  Pause,
  Play,
  Plus,
  Popover,
  RotateCcw,
  ScrollView,
  Search,
  Separator,
  Settings,
  Sheet,
  Shield,
  Spinner,
  Stack,
  Star,
  Sun,
  Switch,
  Tabs,
  Label2 as TamaguiLabel,
  TamaguiProvider,
  Target,
  Text2 as Text,
  Theme,
  Tooltip,
  TrendingUp,
  Trophy,
  User,
  X,
  XStack2 as XStack,
  YStack3 as YStack,
  Zap,
  muscleMapColors,
  muscleMapRadius,
  muscleMapSpacing,
  useTheme
};
//# sourceMappingURL=index.mjs.map