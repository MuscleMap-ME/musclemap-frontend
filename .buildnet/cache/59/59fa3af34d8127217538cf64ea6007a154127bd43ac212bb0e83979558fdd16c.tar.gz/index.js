"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// src/index.ts
var src_exports = {};
__export(src_exports, {
  Avatar: () => import_tamagui5.Avatar,
  Bell: () => import_lucide_icons.Bell,
  Button: () => Button,
  Calendar: () => import_lucide_icons.Calendar,
  Caption: () => Caption,
  Card: () => Card,
  CardContent: () => CardContent,
  CardFooter: () => CardFooter,
  CardHeader: () => CardHeader,
  Check: () => import_lucide_icons.Check,
  ChevronDown: () => import_lucide_icons.ChevronDown,
  ChevronLeft: () => import_lucide_icons.ChevronLeft,
  ChevronRight: () => import_lucide_icons.ChevronRight,
  ChevronUp: () => import_lucide_icons.ChevronUp,
  Clock: () => import_lucide_icons.Clock,
  Dialog: () => import_tamagui5.Dialog,
  Dumbbell: () => import_lucide_icons.Dumbbell,
  Flame: () => import_lucide_icons.Flame,
  Form: () => import_tamagui5.Form,
  H1: () => H1,
  H2: () => H2,
  H3: () => H3,
  Heart: () => import_lucide_icons.Heart,
  Home: () => import_lucide_icons.Home,
  Input: () => Input,
  InputField: () => InputField,
  Label: () => Label,
  LogOut: () => import_lucide_icons.LogOut,
  Menu: () => import_lucide_icons.Menu,
  Minus: () => import_lucide_icons.Minus,
  Moon: () => import_lucide_icons.Moon,
  Paragraph: () => Paragraph,
  Pause: () => import_lucide_icons.Pause,
  Play: () => import_lucide_icons.Play,
  Plus: () => import_lucide_icons.Plus,
  Popover: () => import_tamagui5.Popover,
  RotateCcw: () => import_lucide_icons.RotateCcw,
  ScrollView: () => import_tamagui5.ScrollView,
  Search: () => import_lucide_icons.Search,
  Separator: () => import_tamagui5.Separator,
  Settings: () => import_lucide_icons.Settings,
  Sheet: () => import_tamagui5.Sheet,
  Shield: () => import_lucide_icons.Shield,
  Spinner: () => import_tamagui5.Spinner,
  Stack: () => import_tamagui5.Stack,
  Star: () => import_lucide_icons.Star,
  Sun: () => import_lucide_icons.Sun,
  Switch: () => import_tamagui5.Switch,
  Tabs: () => import_tamagui5.Tabs,
  TamaguiLabel: () => import_tamagui5.Label,
  TamaguiProvider: () => import_tamagui5.TamaguiProvider,
  Target: () => import_lucide_icons.Target,
  Text: () => Text2,
  Theme: () => import_tamagui5.Theme,
  Tooltip: () => import_tamagui5.Tooltip,
  TrendingUp: () => import_lucide_icons.TrendingUp,
  Trophy: () => import_lucide_icons.Trophy,
  User: () => import_lucide_icons.User,
  X: () => import_lucide_icons.X,
  XStack: () => import_tamagui5.XStack,
  YStack: () => import_tamagui5.YStack,
  Zap: () => import_lucide_icons.Zap,
  muscleMapColors: () => muscleMapColors,
  muscleMapRadius: () => muscleMapRadius,
  muscleMapSpacing: () => muscleMapSpacing,
  useTheme: () => import_tamagui5.useTheme
});
module.exports = __toCommonJS(src_exports);

// src/Button.tsx
var import_tamagui = require("tamagui");
var Button = (0, import_tamagui.styled)(import_tamagui.Button, {
  name: "Button",
  // TOUCHSCREEN-FIRST: Base touch-friendly styles
  userSelect: "none",
  variants: {
    variant: {
      primary: {
        backgroundColor: "$blue10",
        color: "white",
        hoverStyle: {
          backgroundColor: "$blue11"
        },
        pressStyle: {
          backgroundColor: "$blue9",
          scale: 0.98
        }
      },
      secondary: {
        backgroundColor: "$gray4",
        color: "$gray12",
        hoverStyle: {
          backgroundColor: "$gray5"
        },
        pressStyle: {
          backgroundColor: "$gray6",
          scale: 0.98
        }
      },
      outline: {
        backgroundColor: "transparent",
        borderWidth: 1,
        borderColor: "$gray8",
        color: "$gray12",
        hoverStyle: {
          backgroundColor: "$gray3"
        },
        pressStyle: {
          backgroundColor: "$gray4",
          scale: 0.98
        }
      },
      danger: {
        backgroundColor: "$red10",
        color: "white",
        hoverStyle: {
          backgroundColor: "$red11"
        },
        pressStyle: {
          backgroundColor: "$red9",
          scale: 0.98
        }
      },
      success: {
        backgroundColor: "$green10",
        color: "white",
        hoverStyle: {
          backgroundColor: "$green11"
        },
        pressStyle: {
          backgroundColor: "$green9",
          scale: 0.98
        }
      },
      ghost: {
        backgroundColor: "transparent",
        color: "$gray11",
        hoverStyle: {
          backgroundColor: "$gray3"
        },
        pressStyle: {
          backgroundColor: "$gray4",
          scale: 0.98
        }
      }
    },
    size: {
      /**
       * TOUCHSCREEN-FIRST SIZES
       * All meet minimum 44px iOS / 48px Material touch target
       */
      sm: {
        height: 44,
        // Was 32, increased for touch
        paddingHorizontal: "$4",
        fontSize: "$3"
      },
      md: {
        height: 48,
        // Was 40, increased for touch
        paddingHorizontal: "$5",
        fontSize: "$4"
      },
      lg: {
        height: 56,
        // Was 48, increased for touch
        paddingHorizontal: "$6",
        fontSize: "$5"
      }
    },
    fullWidth: {
      true: {
        width: "100%"
      }
    }
  },
  defaultVariants: {
    variant: "primary",
    size: "md"
  }
});

// src/Card.tsx
var import_tamagui2 = require("tamagui");
var Card = (0, import_tamagui2.styled)(import_tamagui2.Card, {
  name: "Card",
  backgroundColor: "$background",
  borderRadius: "$4",
  padding: "$4",
  variants: {
    variant: {
      elevated: {
        elevate: true,
        shadowColor: "$shadowColor",
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.1,
        shadowRadius: 4
      },
      outlined: {
        borderWidth: 1,
        borderColor: "$borderColor"
      },
      filled: {
        backgroundColor: "$gray2"
      }
    },
    interactive: {
      true: {
        hoverStyle: {
          backgroundColor: "$gray3"
        },
        pressStyle: {
          backgroundColor: "$gray4",
          scale: 0.98
        },
        cursor: "pointer"
      }
    }
  },
  defaultVariants: {
    variant: "elevated"
  }
});
var CardHeader = (0, import_tamagui2.styled)(import_tamagui2.YStack, {
  name: "CardHeader",
  paddingBottom: "$3",
  borderBottomWidth: 1,
  borderBottomColor: "$borderColor",
  marginBottom: "$3"
});
var CardContent = (0, import_tamagui2.styled)(import_tamagui2.YStack, {
  name: "CardContent",
  space: "$2"
});
var CardFooter = (0, import_tamagui2.styled)(import_tamagui2.YStack, {
  name: "CardFooter",
  paddingTop: "$3",
  borderTopWidth: 1,
  borderTopColor: "$borderColor",
  marginTop: "$3"
});

// src/Input.tsx
var import_tamagui3 = require("tamagui");
var import_jsx_runtime = require("react/jsx-runtime");
var Input = (0, import_tamagui3.styled)(import_tamagui3.Input, {
  name: "Input",
  borderWidth: 1,
  borderColor: "$gray7",
  borderRadius: "$3",
  paddingHorizontal: "$3",
  backgroundColor: "$background",
  focusStyle: {
    borderColor: "$blue8",
    outlineWidth: 0
  },
  variants: {
    size: {
      sm: {
        height: 36,
        fontSize: "$3"
      },
      md: {
        height: 44,
        fontSize: "$4"
      },
      lg: {
        height: 52,
        fontSize: "$5"
      }
    },
    status: {
      error: {
        borderColor: "$red8",
        focusStyle: {
          borderColor: "$red9"
        }
      },
      success: {
        borderColor: "$green8",
        focusStyle: {
          borderColor: "$green9"
        }
      }
    },
    fullWidth: {
      true: {
        width: "100%"
      }
    }
  },
  defaultVariants: {
    size: "md"
  }
});
function InputField({
  label,
  error,
  hint,
  leftIcon,
  rightIcon,
  children
}) {
  return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_tamagui3.YStack, { space: "$1", children: [
    label && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_tamagui3.Text, { fontSize: "$3", fontWeight: "500", color: "$gray11", children: label }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_tamagui3.XStack, { alignItems: "center", position: "relative", children: [
      leftIcon && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_tamagui3.XStack, { position: "absolute", left: "$3", zIndex: 1, children: leftIcon }),
      children,
      rightIcon && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_tamagui3.XStack, { position: "absolute", right: "$3", zIndex: 1, children: rightIcon })
    ] }),
    error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_tamagui3.Text, { fontSize: "$2", color: "$red10", children: error }),
    hint && !error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_tamagui3.Text, { fontSize: "$2", color: "$gray10", children: hint })
  ] });
}

// src/Text.tsx
var import_tamagui4 = require("tamagui");
var Text2 = (0, import_tamagui4.styled)(import_tamagui4.Text, {
  name: "Text",
  color: "$color",
  variants: {
    variant: {
      default: {},
      muted: {
        color: "$gray11"
      },
      accent: {
        color: "$blue10"
      },
      success: {
        color: "$green10"
      },
      warning: {
        color: "$yellow10"
      },
      error: {
        color: "$red10"
      }
    },
    weight: {
      regular: {
        fontWeight: "400"
      },
      medium: {
        fontWeight: "500"
      },
      semibold: {
        fontWeight: "600"
      },
      bold: {
        fontWeight: "700"
      }
    },
    align: {
      left: {
        textAlign: "left"
      },
      center: {
        textAlign: "center"
      },
      right: {
        textAlign: "right"
      }
    }
  },
  defaultVariants: {
    variant: "default",
    weight: "regular",
    align: "left"
  }
});
var H1 = (0, import_tamagui4.styled)(import_tamagui4.H1, {
  name: "H1"
});
var H2 = (0, import_tamagui4.styled)(import_tamagui4.H2, {
  name: "H2"
});
var H3 = (0, import_tamagui4.styled)(import_tamagui4.H3, {
  name: "H3"
});
var Paragraph = (0, import_tamagui4.styled)(import_tamagui4.Paragraph, {
  name: "Paragraph",
  color: "$gray11"
});
var Label = (0, import_tamagui4.styled)(import_tamagui4.Text, {
  name: "Label",
  fontSize: "$3",
  fontWeight: "500",
  color: "$gray11"
});
var Caption = (0, import_tamagui4.styled)(import_tamagui4.Text, {
  name: "Caption",
  fontSize: "$2",
  color: "$gray10"
});

// src/theme/tokens.ts
var muscleMapColors = {
  // Primary brand colors
  primary: {
    50: "#e6f2ff",
    100: "#b3d9ff",
    200: "#80bfff",
    300: "#4da6ff",
    400: "#1a8cff",
    500: "#0073e6",
    600: "#005ab3",
    700: "#004080",
    800: "#00264d",
    900: "#000d1a"
  },
  // Muscle group colors for visualization
  muscle: {
    chest: "#ef4444",
    // Red
    back: "#3b82f6",
    // Blue
    shoulders: "#f97316",
    // Orange
    arms: "#8b5cf6",
    // Purple
    legs: "#22c55e",
    // Green
    core: "#eab308",
    // Yellow
    cardio: "#ec4899"
    // Pink
  },
  // Status colors
  success: "#22c55e",
  warning: "#f59e0b",
  error: "#ef4444",
  info: "#3b82f6"
};
var muscleMapSpacing = {
  xs: 4,
  sm: 8,
  md: 16,
  lg: 24,
  xl: 32,
  "2xl": 48,
  "3xl": 64
};
var muscleMapRadius = {
  sm: 4,
  md: 8,
  lg: 12,
  xl: 16,
  full: 9999
};

// src/index.ts
var import_tamagui5 = require("tamagui");
var import_lucide_icons = require("@tamagui/lucide-icons");
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  Avatar,
  Bell,
  Button,
  Calendar,
  Caption,
  Card,
  CardContent,
  CardFooter,
  CardHeader,
  Check,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  ChevronUp,
  Clock,
  Dialog,
  Dumbbell,
  Flame,
  Form,
  H1,
  H2,
  H3,
  Heart,
  Home,
  Input,
  InputField,
  Label,
  LogOut,
  Menu,
  Minus,
  Moon,
  Paragraph,
  Pause,
  Play,
  Plus,
  Popover,
  RotateCcw,
  ScrollView,
  Search,
  Separator,
  Settings,
  Sheet,
  Shield,
  Spinner,
  Stack,
  Star,
  Sun,
  Switch,
  Tabs,
  TamaguiLabel,
  TamaguiProvider,
  Target,
  Text,
  Theme,
  Tooltip,
  TrendingUp,
  Trophy,
  User,
  X,
  XStack,
  YStack,
  Zap,
  muscleMapColors,
  muscleMapRadius,
  muscleMapSpacing,
  useTheme
});
//# sourceMappingURL=index.js.map