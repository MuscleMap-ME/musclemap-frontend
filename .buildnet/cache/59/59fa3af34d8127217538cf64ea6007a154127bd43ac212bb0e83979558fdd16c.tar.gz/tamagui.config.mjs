// src/tamagui.config.ts
import { createTamagui } from "tamagui";
import { config } from "@tamagui/config/v3";
var tamaguiConfig = createTamagui(config);
var tamagui_config_default = tamaguiConfig;
export {
  tamagui_config_default as default,
  tamaguiConfig
};
//# sourceMappingURL=tamagui.config.mjs.map